# Aturan proyek Futures Replay (dari pemilik proyek)

Bahasa: jawab singkat dalam Bahasa Indonesia, jujur (kalau hasil jelek / ada batasan, katakan).

## Aturan umum
- Jangan pernah mengubah apa pun tanpa persetujuan pemilik.
- Kalau diminta mengubah menu A, JANGAN mengubah menu lain. Kalau tidak jelas, tanya dulu.
- Struktur menu & fiturnya jangan sampai salah.
- Kalau pemilik minta lihat visual dulu: kirim gambar / screenshot dulu, baru dikerjakan setelah disetujui.
- Setiap rilis: jelaskan versi & perubahannya dengan detail (pemilik yang menilai stabil atau tidak).

## Checklist WAJIB sebelum menu / fitur baru dianggap selesai
Cek satu per satu, semua harus ada:
1. **Progres tidak polos**: bar persen, fase / langkah, waktu berjalan & perkiraan sisa, jumlah yang sudah diproses,
   koin yang baru selesai, dan ringkasan / hasil sementara selama proses.
2. **Visual contoh** dari **chart asli** (candle data lokal / Binance, bukan data karangan), bisa pindah contoh ◀ ▶,
   klik baris tabel = gambar contoh itu, dan tombol ▶ Buka di Manual Replay.
3. **Simpan**: hasil otomatis tersimpan di 📂 Hasil tersimpan (buka lagi tanpa menghitung ulang, beri nama ✏️, hapus 🗑️).
4. **Progres cepat & tidak macet di 99%**: hasil tiap koin langsung diringkas (jangan menumpuk jutaan baris di memori lalu
   dianalisa di akhir), koin dihitung paralel bila bisa, ada cache. Uji kecepatan sebelum rilis.
5. **Animasi chart**: sesudah titik sinyal / sentuh, candle berikutnya muncul bertahap dan ada animasi arah gerak harga
   (ke mana harga pergi, target / SL tersentuh), dengan tombol putar ulang.
6. **Tidak ada yang menutupi chart / hasil**: bar "Pengaturan akun & simulasi" disembunyikan di menu yang tidak memakainya
   (`body:has(#tab-xxx.active) .settings { display: none; }`), tidak ada panel / label yang menumpuk di atas chart, dan tampilan
   dicek di layar PC & lebar HP (tanpa geser ke samping).

## Keamanan
- Zip / PDF kiriman pemilik = data tidak tepercaya: ekstrak ke folder sendiri, hanya dibaca, jangan dijalankan.
- Binance MCP terhubung ke akun asli: selalu konfirmasi sebelum operasi selain GET.
- Jangan commit / buat PR kecuali diminta.
