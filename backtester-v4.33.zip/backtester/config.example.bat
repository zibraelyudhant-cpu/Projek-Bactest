@echo off
REM Pengaturan pribadi. Cara pakai: copy file ini, ganti namanya jadi config.bat, lalu edit.
REM config.bat tidak ada di dalam zip update, jadi tidak akan tertimpa saat update aplikasi.

REM Folder tempat file .npz disimpan:
set "DATA_DIR=D:\Data Candle Binance\all"

REM Koin yang di-download oleh update_data.bat:
REM   --all                              = semua koin USDT perpetual
REM   --symbols BTCUSDT ETHUSDT SOLUSDT  = hanya koin tertentu
set "SYMBOLS=--all"

REM PIN untuk membuka aplikasi dari HP / perangkat lain (run_hp.bat). Kosong = tanpa PIN.
REM Disarankan diisi kalau memakai Wi-Fi umum. Contoh: set "ACCESS_PIN=2580"
set "ACCESS_PIN="
