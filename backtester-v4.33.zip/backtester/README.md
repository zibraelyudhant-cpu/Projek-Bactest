# Futures Replay

Platform latihan trading dan backtest untuk data candle Binance Futures (USDT-M), dijalankan
di browser laptop sendiri. Ada dua mode:

- **Manual Replay:** seperti Bar Replay di TradingView. Candle muncul satu per satu, lu pasang
  order sendiri, ada alat gambar dan indikator.
- **Auto Backtest:** strategi Python dijalankan otomatis di data historis, hasilnya berupa statistik.
- **Screener:** saring semua koin Binance Futures secara **live** pakai indikator apa saja, mirip
  screener TradingView tapi tanpa batasan indikator.

Daftar isi:
1. [Instal dari nol (laptop baru)](#1-instal-dari-nol-laptop-baru)
2. [Pemakaian sehari-hari](#2-pemakaian-sehari-hari)
3. [Update data candle](#3-update-data-candle)
4. [Update aplikasi ke versi baru](#4-update-aplikasi-ke-versi-baru)
   · [Buka di HP](#buka-di-hp)
5. [Pindah ke laptop lain](#5-pindah-ke-laptop-lain)
6. [Cara pakai fitur](#6-cara-pakai-fitur)
7. [Kalau ada masalah](#7-kalau-ada-masalah)
8. [Detail teknis](#8-detail-teknis)

Isi folder:

| File / folder | Fungsinya |
|---|---|
| `run.bat` | **Menjalankan aplikasi** (yang paling sering dipakai) |
| `update_data.bat` | Download / update data candle dari Binance |
| `run_hp.bat` | Menjalankan aplikasi supaya **juga bisa dibuka dari HP** |
| `install.bat` | Instal library Python (sekali per laptop) |
| `config.example.bat` | Contoh pengaturan folder data dan daftar koin |
| `strategies\` | File strategi untuk Auto Backtest |
| `tools\` | Script download data dan cek kualitas data |
| `backend\`, `frontend\`, `tests\` | Kode aplikasi (tidak perlu diubah) |

---

## 1. Instal dari nol (laptop baru)

Ikuti urutannya. Langkah 1–3 cukup sekali per laptop.

### Langkah 1 — Instal Python

1. Buka https://www.python.org/downloads/, klik **Download Python 3.x**.
2. Jalankan installer-nya. Di layar pertama, **centang "Add python.exe to PATH"** (paling bawah).
   Ini penting, jangan sampai kelewat. Setelah itu klik **Install Now**.
3. Kalau sudah selesai, buka **PowerShell**: tekan tombol Windows, ketik `powershell`, Enter.
4. Ketik perintah ini lalu Enter:
   ```powershell
   python --version
   ```
   Kalau muncul `Python 3.x.x`, berarti berhasil. Kalau muncul error atau malah membuka
   Microsoft Store, lihat [bagian 7](#7-kalau-ada-masalah).

### Langkah 2 — Taruh folder aplikasi

1. Extract zip `backtester-vX.Y.zip` ke `D:\`: klik kanan zip → **Extract All…** → isi tujuan
   `D:\` → **Extract**.
2. Cek hasilnya. Harus ada file `D:\backtester\run.bat`.
   Kalau yang terbentuk malah `D:\backtester\backtester\run.bat` (folder dobel), pindahkan isinya
   satu tingkat ke atas, atau extract ulang dengan tujuan `D:\`.

Mau taruh di tempat lain juga boleh. Semua perintah di README ini mengasumsikan `D:\backtester`.

### Langkah 3 — Instal library

Klik dua kali **`install.bat`**. Tunggu sampai muncul tulisan "Instalasi selesai".

Cara manual lewat PowerShell (hasilnya sama):
```powershell
cd D:\backtester
python -m pip install -r requirements.txt
```

### Langkah 4 — Download data candle

Lewati langkah ini kalau folder `D:\Data Candle Binance\all` sudah berisi file `.npz`, misalnya
hasil copy dari laptop lama.

Klik dua kali **`update_data.bat`**. Script akan:
- mengambil data dari https://data.binance.vision (arsip resmi Binance) untuk **semua koin
  USDT perpetual**, mulai 2 tahun lalu sampai kemarin;
- mendownload candle **5m**, lalu merakit **15m, 1h, 4h, 1d** dari 5m itu, jadi semua TF
  pasti konsisten;
- menyimpan hasilnya ke `D:\Data Candle Binance\all` sebagai `BTCUSDT_5m.npz`, `BTCUSDT_1h.npz`, dst.

Download pertama untuk semua koin (sekitar 900, termasuk yang sudah delisting) bisa makan
**1–3 jam**, tergantung internet. Kalau berhenti di tengah jalan, jalankan lagi saja: koin yang
sudah selesai tidak akan diunduh ulang dari awal.

**Kalau cuma mau koin tertentu** (jauh lebih cepat), pakai PowerShell:
```powershell
cd D:\backtester
python tools\download_binance.py --symbols BTCUSDT ETHUSDT SOLUSDT
```

Opsi lain:
```powershell
# mulai dari tanggal tertentu
python tools\download_binance.py --symbols BTCUSDT --start 2023-01-01

# simpan ke folder lain
python tools\download_binance.py --all --out "E:\data candle"

# unduh ulang dari nol (abaikan file yang sudah ada)
python tools\download_binance.py --symbols BTCUSDT --full

# lihat semua opsi
python tools\download_binance.py --help
```

### Langkah 5 — Jalankan

Klik dua kali **`run.bat`**. Browser akan terbuka di http://127.0.0.1:8000.
Pastikan pojok kiri atas menampilkan versi yang benar, misalnya **Futures Replay v2.7**.

> **⚠️ Scan / analisa tidak jalan? Nyalakan VPN.** Binance sering **memblokir IP** dari provider / negara tertentu.
> Semua menu yang mengambil data live dari Binance bisa kena: Screener, 🐋 Whale (pelacak, Cari setup, Cek entry,
> Flow, perekam order book), 📐 Market Structure (Screener & Cek entry posisi), 📒 Jurnal, dan download data
> (`update_data.bat`). Tandanya ada pesan **"Binance menolak akses (HTTP 451 / 403)"**, **"Tidak bisa terhubung ke
> https://fapi.binance.com"**, atau scan diam / gagal terus. Solusinya:
> 1. Nyalakan **VPN** (paling ampuh), lalu klik scan lagi. Aplikasi tidak perlu ditutup.
> 2. Kalau tanpa VPN: ganti DNS ke `1.1.1.1` / `8.8.8.8`, atau pakai jaringan lain (mis. hotspot HP).
>
> Manual Replay & Auto Backtest memakai data lokal, jadi tetap jalan tanpa internet.

### (Opsional) Folder data atau daftar koin berbeda

Kalau data lu tidak ada di `D:\Data Candle Binance\all`, atau `update_data.bat` cukup
mendownload koin tertentu saja:
1. Copy `config.example.bat`, lalu ganti nama hasil copy-nya jadi `config.bat`.
2. Klik kanan `config.bat` → **Edit**, ubah baris `DATA_DIR` dan/atau `SYMBOLS`, lalu simpan.

`config.bat` tidak ikut dalam zip update, jadi tidak akan tertimpa saat update aplikasi.

---

## 2. Pemakaian sehari-hari

1. Klik dua kali **`run.bat`**. Akan muncul jendela hitam, lalu browser terbuka sendiri.
2. **Biarkan jendela hitam tetap terbuka** selama aplikasi dipakai. Jendela itu adalah servernya.
3. Selesai? **Tutup jendela hitamnya.** Tab browser boleh ikut ditutup.

Kalau browser tidak terbuka otomatis, buka manual di http://127.0.0.1:8000.

### Buka di HP

Aplikasi tetap **berjalan di PC**; HP hanya membuka tampilannya lewat browser (Chrome/Safari). Semua fitur
jalan di HP: replay, order, alat gambar, indikator, backtest, screener. PC harus menyala dan `run_hp.bat`
terbuka selama dipakai.

**A. HP dan PC di Wi-Fi yang sama (di rumah)**
1. Tutup `run.bat` kalau sedang terbuka.
2. Klik dua kali **`run_hp.bat`**. Kalau Windows menampilkan peringatan firewall, centang **Private networks**
   lalu klik **Allow access**.
3. Di aplikasi (di PC), klik tombol **📱 HP** di pojok kanan atas. Muncul QR code dan alamat seperti
   `http://192.168.1.5:8000`.
4. Scan QR code itu dengan kamera HP, atau ketik alamatnya di browser HP.
5. Supaya gampang dibuka lagi: di Chrome HP, menu ⋮ → **Add to Home screen**.

**B. Dari luar rumah (pakai Tailscale, gratis)**
1. Instal **Tailscale** di PC (https://tailscale.com/download) dan di HP (Play Store / App Store),
   lalu login dengan akun yang sama di keduanya.
2. Jalankan `run_hp.bat` di PC.
3. Di tombol **📱 HP** akan muncul alamat **Tailscale** (`http://100.x.x.x:8000`). Buka alamat itu di HP;
   bisa dari mana saja selama Tailscale di HP aktif dan PC menyala.

**PIN (disarankan kalau memakai Wi-Fi umum)**
Tanpa PIN, siapa pun di Wi-Fi yang sama bisa membuka aplikasi. Untuk memasang PIN: buat `config.bat`
(lihat bagian *Folder data atau daftar koin berbeda*) dan isi misalnya `set "ACCESS_PIN=2580"`. HP akan
diminta PIN sekali (diingat 30 hari); PC sendiri tidak perlu PIN.

**Tips di HP**
- Mengisi harga order dari chart: sentuh chart di harga yang diinginkan, lalu tekan **📍** di samping kolom
  Harga / Take profit / Stop loss.
- Geser chart dengan satu jari, zoom dengan dua jari.
- Toolbar gambar ada di atas chart (geser ke samping untuk melihat semua alat).

---

## 3. Update data candle

Data dari Binance bertambah tiap hari. Untuk menambahkan data terbaru:

- Klik dua kali **`update_data.bat`**.

Hanya data yang belum ada yang diunduh: bulan terakhir di file diunduh ulang supaya lengkap, lalu
disambung sampai kemarin. Data lama tetap disimpan. Biasanya beberapa menit saja.
Kalau `run.bat` sedang jalan, tutup dulu lalu buka lagi setelah update selesai supaya data baru terbaca.

> Data Binance Vision terbit per hari, sehingga data paling baru adalah **kemarin** (UTC).

---

## 4. Update aplikasi ke versi baru

1. **Tutup jendela hitam `run.bat`** kalau masih terbuka.
2. Extract zip versi baru ke `D:\` dan **timpa** file lama:
   - Lewat Explorer: klik kanan zip → **Extract All…** → tujuan `D:\` → **Extract**. Kalau Windows
     bertanya soal file yang sudah ada, pilih **Replace the files in the destination**.
   - Atau lewat PowerShell (ganti nama zip-nya sesuai file yang lu punya):
     ```powershell
     Expand-Archive -Path "$HOME\Downloads\backtester-v2.7.zip" -DestinationPath D:\ -Force
     ```
3. Klik dua kali **`install.bat`** (aman diulang, hanya perlu kalau ada library baru).
4. Klik dua kali **`run.bat`**, lalu tekan **Ctrl+F5** di browser.
5. Cek versi di pojok kiri atas sudah berubah.

**Yang tetap aman setelah update:**
- data candle (folder data terpisah dari folder aplikasi);
- `config.bat`;
- strategi buatan lu sendiri di `strategies\`, selama namanya beda dengan file contoh
  (`ema_cross.py` akan ditimpa, jadi jangan simpan strategi di file itu);
- gambar, indikator, dan pilihan koin terakhir (disimpan di browser);
- threshold yang disimpan dengan 💾 (file `saved\thresholds.json`) dan hasil Studi Fibonacci yang disimpan
  (folder `saved\fibstudy\`). Zip update tidak berisi folder `saved`. Kalau pindah laptop, salin folder `saved` juga.

---

## 5. Pindah ke laptop lain

Ada dua pilihan untuk data:
- **Download ulang:** ikuti [bagian 1](#1-instal-dari-nol-laptop-baru) dari awal (langkah 1–5).
- **Copy dari laptop lama:** copy folder `D:\Data Candle Binance\all` (pakai flashdisk/HDD), lalu
  ikuti bagian 1 tapi **lewati langkah 4**. Setelah itu cukup jalankan `update_data.bat` untuk
  menambah data terbaru.

Juga copy dari laptop lama kalau ada: `config.bat` dan strategi buatan sendiri di `strategies\`.

Gambar (trendline dll.) disimpan di browser laptop lama, jadi **tidak ikut pindah**.

---

## 6. Cara pakai fitur

### Manual Replay

| Aksi | Cara |
|---|---|
| Pilih koin | Ketik di kolom **Simbol** (misal `BTCUSDT`), Enter. Replay langsung dimulai |
| Mulai dari tanggal lain | Isi **Mulai (UTC)** → klik **Mulai Replay** (posisi & order di-reset) |
| Maju 1 candle | **Step ▶\|** atau `→` |
| Maju 1 candle M5 | **+1 M5** atau `Shift+→` |
| Mundur 1 candle | **\|◀ Back** atau `←` |
| Mundur 1 candle M5 | **−1 M5** atau `Shift+←` |
| Play / pause otomatis | **▶ Play** atau `Spasi`; kecepatan di dropdown sebelahnya |
| Ganti timeframe | Tombol **5M 15M 1H 4H 1D** (posisi tetap) |
| Lihat candle lama | Drag / scroll chart ke kiri, candle lama dimuat otomatis |

- Semua waktu dalam **UTC** (WIB = UTC + 7 jam).
- Candle TF besar yang belum close (misalnya H4 yang baru berjalan 2 jam) dirakit dari M5, jadi
  bentuknya berubah seiring replay berjalan, sama seperti live.
- **Mundur bekerja seperti undo.** Order, cancel, dan close yang dibuat di titik itu atau sesudahnya
  dibatalkan, lalu posisi dan saldo kembali seperti saat itu. Boleh mundur sampai sebelum tanggal mulai.

### Order

1. Pilih **Buy / Long** atau **Sell / Short**, lalu tipe **Limit / Market / Stop**.
2. Isi **Harga**. Bisa juga dengan **Shift+klik** di chart. **Alt+klik** mengisi Stop loss,
   **Ctrl+klik** mengisi Take profit.
3. Tentukan ukuran posisi. Klik label di atas kolomnya untuk memilih cara:
   - **Size (USDT):** nilai posisi. Contoh: size 100 USDT, harga naik 2% = untung 2 USDT.
   - **Risiko di SL (USDT):** berapa rugi kalau kena SL, misalnya `0.5`. Qty dihitung otomatis dari
     jarak entry ke SL, **sudah termasuk fee dan slippage**, jadi rugi saat kena SL ≈ angka itu.
     Mode ini wajib mengisi Stop loss.

   Di bawah kolom ada pratinjau: qty, nilai posisi, rugi kalau kena SL, dan untung kalau kena TP.
   Defaultnya **tanpa margin/leverage/likuidasi**.
4. Klik **Kirim Order**. Order, TP, SL, entry, dan harga likuidasi tampil sebagai garis di chart.
5. Batalkan order lewat tombol **×** di panel Order Aktif, atau **Batal Semua**. **Tutup Posisi**
   menutup posisi dengan market order.

Saldo awal, fee, slippage, dan aturan fill bisa diatur di **Pengaturan akun & simulasi**
(paling bawah), lalu klik **Mulai Replay** supaya berlaku. Mau simulasi leverage dan likuidasi?
Centang **Simulasikan margin, leverage & likuidasi**, nanti muncul kolom Leverage dan Maintenance margin.

### Suara

| Kejadian | Bunyi |
|---|---|
| Order entry ke-fill | "tik" pendek |
| Kena **TP** (atau ditutup manual dalam kondisi profit) | lonceng "ding-ding" |
| Kena **SL** (atau ditutup manual dalam kondisi rugi, atau likuidasi) | dua nada rendah turun |

Bisa dimatikan, diatur volumenya, atau dites lewat tombol **Tes suara** di **Pengaturan akun & simulasi**.

### Long / Short Position

Ada dua ikon kotak hijau-merah di toolbar kiri: **Long Position** dan **Short Position**.
1. Klik ikonnya, lalu klik sekali di chart pada harga entry. Kotak langsung muncul dengan RR 1:2.
2. Drag titik biru untuk mengubah entry, TP (batas zona hijau), dan SL (batas zona merah).
   Label menunjukkan harga, persentase, dan untung/rugi dalam USDT sesuai ukuran posisi di panel Order
   (Size atau Risiko di SL). Contoh: pilih "Risiko di SL" = 0.5, maka kotak menampilkan qty supaya rugi di SL = 0.50.
3. Di panel atas: **Pasang Order** memasang limit order dengan TP/SL persis seperti kotaknya,
   **Balik arah** menukar long ↔ short, ◂▸ dan ◂ ▸ untuk mengecilkan/melebarkan kotak.

### Alat gambar (toolbar kiri)

Tersedia: trendline, ray, garis extended, garis horizontal, ray horizontal, garis vertikal,
parallel channel, price channel, Fibonacci retracement, persegi (zona), label harga, Long/Short
Position, dan teks.

- Klik alatnya, lalu klik titik-titik di chart.
- Klik gambar untuk memilih, lalu drag untuk memindah.
- Saat gambar terpilih, muncul panel di atas chart untuk mengatur **warna**, **tebal garis**,
  **putus-putus**, **teks/label**, dan **ukuran teks**. Gaya terakhir jadi default gambar berikutnya.
- `Delete` menghapus gambar terpilih, `Esc` membatalkan/menutup panel.
- 🧲 magnet: titik gambar menempel ke open/high/low/close candle.
- Gambar disimpan per koin di browser, jadi tetap ada setelah ganti TF atau reload.
- **Fibonacci retracement**: klik pertama = awal swing (level 1), klik kedua = ujung swing (level 0). Angkanya:
  1.618 · 1.414 · 1.272 · 1.13 · 1 · 0.886 · 0.786 · 0.705 · 0.618 · 0.5 · 0.382 · 0.236 · 0 · −0.13 · −0.272 · −0.414 · −0.618.

### Indikator (gaya TradingView)

- Klik **ƒx Indikator**: dialog dengan **pencarian** (mis. "rsi", "bollinger") dan 27 indikator: di atas candle (MA, EMA,
  SMA, BOLL, SAR, BBI, AVP) dan panel bawah (VOL, MACD, RSI, KDJ, DMI/ADX, CCI, WR, OBV, AO, MTM, ROC, TRIX, BIAS, PSY,
  BRAR, CR, DMA, VR, EMV, PVT). Klik untuk menambah / menghapus.
- Di chart, tiap indikator punya legend dengan ikon **◉** sembunyikan, **⚙** pengaturan, **✕** hapus.
- **⚙ Pengaturan** indikator: tab **Input** (periode, dll.) dan **Gaya** (warna tiap garis, tebal garis, tinggi panel,
  tampil / sembunyi), plus **Kembali ke bawaan**. Semua tersimpan otomatis.

- **MA / EMA / RSI: jumlah garis bebas.** Di ⚙ pengaturan indikator, hapus garis dengan ✕ (mis. tinggal 1 EMA 300) atau
  **+ Tambah garis** (maks 6). Kolom periode yang dikosongkan = garis itu tidak dipakai.

- **Dorongan %** (indikator buatan sendiri, panel bawah): gabungan **ADX** (kekuatan tren, bobot 40%), **Force Index**
  (dorongan harga × volume, 35%) dan **Volume** (25%) jadi satu angka 0–100%, tampil satu garis seperti RSI (ADX 25 = 50%,
  Force Index 1× rata-rata 100 candle = 50%, volume normal = 33%, 3× rata-rata = 100%). **Garis tengah** (putus-putus): di atas = condong
  breakout, di bawah = condong pullback / retest. Default 50; setelah Tes SNR lolos uji, garisnya diganti angka hasil
  backtest untuk TF itu (bisa diubah sendiri di ⚙). **Penghalusan** (default 10) membuat angkanya tidak cepat naik-turun
  (perubahan per candle ±2× lebih kecil dari versi awal) — makin besar makin tenang tapi makin telat. Batas "breakout" /
  "cuma nyentuh" dicari lewat tab 📍 Tes SNR (samakan pengaturan penghalusannya).

### Pengaturan chart (⚙️ Chart)

- **Candle**: tipe (Candle, Hollow candle, Hollow naik saja, Bar OHLC, Line / Area), warna body naik/turun, border dan
  wick (bisa dimatikan, warnanya bisa beda).
- **Tampilan**: warna latar, grid vertikal / horizontal + warnanya, crosshair putus-putus / garis penuh, garis & label
  harga terakhir, legend OHLC. **Kembali ke bawaan** mengembalikan semuanya.

### Alat gambar tambahan & pengaturan alat (gaya TradingView)

- Alat baru di toolbar kiri: **Fib Extension** (3 klik: awal tren, ujung tren, ujung koreksi; level 0 … 2.618),
  **Panah**, **Tanda panah naik / turun** (1 klik), **Penggaris** (selisih harga, %, jumlah candle), **Lingkaran**, **Segitiga**.
- Tombol **⚙** di toolbar gambar membuka pengaturan dengan tab:
  - **Gaya**: warna, tebal, putus-putus, teks, ukuran teks;
  - **Koordinat**: ubah harga & waktu (UTC) tiap titik dengan angka;
  - **Visibilitas**: pilih di TF mana gambar ditampilkan (**Semua** / **Hanya TF ini**).
- **Indikator yang sama bisa dipasang lagi** di panel bawah: tombol **+1** di dialog ƒx Indikator (mis. RSI 14 dan RSI 7).
- **Template indikator**: di dialog ƒx Indikator, **Simpan set ini** lalu **Terapkan** kapan saja.

### Fibonacci retracement (gaya TradingView)

- Tiap level punya warna sendiri, area di antara level diberi latar transparan, label `angka (harga)` sewarna level,
  dan garis tren putus-putus antara dua titik. Klik 1 = awal swing (1), klik 2 = ujung swing (0).
- Toolbar saat fibo dipilih: tebal / putus-putus, **Latar**, **◂ Kiri** / **Kanan ▸** (perpanjang garis), **Angka**,
  **Harga**, **Tren**, **⇅ Balik**, **⚙️ Level** (centang level, ubah angka & warna, tambah level, transparansi latar,
  posisi label, **Jadikan default** untuk fibo berikutnya), **🔒 kunci**, **📋 duplikat**, Hapus.
- Semua alat gambar lain juga punya **🔒 kunci** dan **📋 duplikat**.

### Auto Backtest

> **Sejak v3.17 backtest murni teknikal.** Yang dihitung hanya trade, menang (kena TP), kalah (kena SL), dan WR.
> Uang, R, profit factor, fee, slippage, ukuran posisi, dan equity tidak dihitung dan tidak ditampilkan; urusan uang
> kamu atur sendiri. Saran evaluasi dinilai dari WR, dan ada blok **🎯 Presisi entry / SL / TP** (dalam ATR TF
> eksekusi) yang menunjukkan apakah entry terlalu awal, SL terlalu ketat/longgar, dan seberapa jauh harga bergerak
> dibanding TP.

**Langkah:**
1. Pilih koin di kolom **Simbol** (paling atas), misalnya `AVAXUSDT`.
2. Buka tab **Auto Backtest**.
3. Di **Strategi**, pilih strateginya, misalnya `BreakoutD1H1 (1h)`.
   - Periode: klik tombol cepat di bawah tanggal (**1/2/3/6 bln**, **1–5 thn**, **Semua**), dihitung mundur dari
     akhir data koin terpilih. Kalau datanya lebih pendek (mis. pilih 5 thn tapi data cuma 4 thn), otomatis
     dipakai semua data. Tanggal tetap bisa diketik manual. Tombol yang sama ada di Studi Fibonacci.
4. Di **Parameter**, ubah nilainya langsung di formulir. Baris berwarna kuning adalah **timeframe**
   (`tf`, `htf`, `trend_tf`, `confirm_tf`, …): pilih dari dropdown, misalnya H4 + M15. Nilai yang diubah
   diingat per strategi; tombol **reset** mengembalikan ke default.
5. Atur **Dari** dan **Sampai** (UTC). Defaultnya seluruh data koin itu.
6. **Hitung fee & slippage** (di atas tombol Jalankan) defaultnya **mati**, artinya backtest murni analisa teknikal:
   - tanpa fee dan tanpa slippage;
   - entry limit terisi begitu harga menyentuh harganya;
   - TP / SL kena begitu harga menyentuhnya.

   Dengan risk 0.5 USDT dan RR 2, setiap trade kalah = −0.50 dan setiap trade menang = +1.00, jadi win rate
   dan PF murni mencerminkan kualitas analisa. Centang kotak ini kalau mau memakai fee, slippage, dan aturan
   fill dari **Pengaturan akun & simulasi** (lebih dekat ke trading sungguhan). Manual Replay tetap memakai
   pengaturan tersebut.
7. Klik **Jalankan Backtest**. Untuk 2 tahun data biasanya selesai dalam beberapa detik.

**Backtest di semua koin sekaligus:**

1. Di formulir backtest, ubah **Koin** menjadi:
   - **Semua koin**: semua koin yang ada di folder data, atau
   - **Daftar koin tertentu**: ketik daftarnya, misalnya `BTCUSDT, ETHUSDT, SOLUSDT`.
2. (Opsional) **Proses paralel**: berapa koin yang diuji bersamaan. Biarkan kosong untuk otomatis
   (jumlah core CPU − 1). Kalau laptop jadi berat, kecilkan angkanya.
   Koin yang datanya pendek (baru listing) tetap diuji. Trade dihitung selama strategi mendapat sinyal;
   kalau datanya kurang untuk indikator, hasilnya 0 trade. Koin hanya dilewati kalau sama sekali
   tidak punya data di rentang tanggal yang dipilih.
3. Klik **Jalankan di Semua Koin**. Selama berjalan:
   - Bar progres menampilkan jumlah koin yang sudah selesai dan perkiraan sisa waktu.
   - Hasil tiap koin langsung masuk ke tabel.
   - Tombol **Batal** menghentikan proses.
4. Kartu ringkasan menampilkan:
   - Jumlah koin yang profit.
   - Total trade dan **Net PnL total**.
   - **PF gabungan**: total profit semua koin ÷ total rugi semua koin.
   - Win rate dan expectancy per trade.
5. Tabel per koin bisa diurutkan dengan mengklik judul kolom (Net PnL, PF, Win %, MDD, …) dan dicari lewat kotak "Cari koin".
   Tombol **CSV** menyimpan tabel ke file Excel/CSV.
6. **Klik nama koin** di tabel untuk menjalankan backtest koin itu saja. Grafik equity dan daftar trade-nya
   muncul di bawah tabel.

Perkiraan waktu:
- Strategi H1/H4 butuh sekitar 1–3 detik per koin.
- Strategi M5 (mis. RetestPullback) butuh sekitar 10–20 detik per koin.
- Total waktu dibagi jumlah proses paralel. Misalnya 500 koin dengan strategi M5 di 8 core memakan sekitar
  10–20 menit.

Hasil gabungan banyak koin jauh lebih jujur daripada satu koin yang kebetulan bagus. Strategi
dianggap layak kalau **PF gabungan > 1** dan sebagian besar koin profit, bukan hanya beberapa koin di puncak tabel.

**Copy / simpan / bandingkan threshold:**

- **copy** (di samping tulisan Parameter): menyalin semua threshold strategi sebagai teks, misalnya:
  ```
  # threshold EmaRsi (Futures Replay)
  # hasil: BTCUSDT 2024-10-01 → 2026-10-24 · 126 trade · WR 30.16% · PF 0.72 · net -12.41
  strategy = EmaRsi
  rsi_long = 60
  ...
  ```
  Baris `# hasil` ikut tersalin kalau threshold di formulir sama dengan backtest terakhir. Teks ini bisa
  disimpan di catatan atau chat.
- **paste**: tempel teks tadi (format `key = value` atau JSON), lalu klik **Terapkan**. Strategi dan
  semua nilainya langsung terpasang di formulir.
- **💾 Simpan threshold + hasil** (di bawah tombol Jalankan): menyimpan threshold yang barusan dites
  beserta hasilnya (Trade, Win %, PF, Net, koin, periode). Bisa dipakai untuk mode satu koin maupun semua koin.
- **Threshold tersimpan** (kotak paling atas di kanan, klik untuk membuka):
  - Daftar diurutkan dari win rate tertinggi; 🏆 = terbaik. Kolom "Beda dari default" menunjukkan
    nilai apa saja yang lu ubah.
  - Tombol **Lihat** mengembalikan tampilan **persis seperti saat backtest itu selesai**, tanpa menghitung ulang:
    formulir (strategi, parameter, periode, koin), ringkasan, tabel per koin (atau daftar trade untuk satu koin), dan
    kartu Evaluasi. Ini berlaku untuk yang disimpan sejak v3.18; yang lebih lama
    hanya punya ringkasan. Hasil lengkap disimpan di `saved\results\`.
  - Tombol **Pakai** memuat threshold ke formulir, **Copy** menyalinnya sebagai teks, dan **Hapus**
    menghapusnya. Klik dua kali di nama untuk menggantinya.
  - WR di daftar adalah hasil saat disimpan, jadi koin atau periodenya bisa beda-beda. Untuk perbandingan
    yang adil, **centang** beberapa threshold lalu klik **Bandingkan ulang yang dicentang**. Semuanya
    dites ulang di koin (pilihan "Koin" di kiri: satu koin / semua / daftar) dan periode yang sama, lalu
    hasilnya ditampilkan berdampingan.

**Evaluasi strategi (otomatis setelah backtest):**

Setelah backtest selesai, kartu **Evaluasi strategi** muncul. Pada mode satu koin, kartunya ada di bawah grafik
equity. Pada mode semua koin, kartunya ada di dalam kotak "Semua koin" dan berisi gabungan dari semua koin.
Evaluasi melihat apa yang terjadi pada harga **sesudah** tiap trade. Ini hanya dipakai untuk menilai hasil;
strategi sendiri tetap tidak melihat data masa depan.

- **Saran perbaikan**: diurutkan dari yang paling penting. Tiap saran berisi penjelasan, bukti angkanya,
  dan variasi parameter yang bisa dicoba.
- **Uji saran**: menjalankan ulang backtest dengan tiap variasi di data yang sama, lalu menampilkan tabel
  perbandingan Trade, Win %, PF, dan Net PnL terhadap parameter sekarang. Tombol **Pakai** memasang
  parameter variasi itu ke formulir.
- **Penyebab trade kalah**: tiap trade yang kena SL dimasukkan ke satu kategori:

| Kategori | Artinya | Biasanya diperbaiki dengan |
|---|---|---|
| SL kena sweep tipis, lalu harga lanjut ke TP | SL hanya tersentuh ≤ 0.5R lalu harga ke TP | SL lebih jauh dari likuiditas, entry lebih dalam |
| Arah benar, tapi entry terlalu awal | harga tembus jauh di bawah SL dulu, baru ke TP | limit lebih dalam / tunggu konfirmasi TF eksekusi |
| Sudah hampir TP, lalu berbalik ke SL | sempat ≥ 70% jalan ke TP | TP lebih dekat / geser SL ke titik impas |
| Melawan struktur TF besar saat entry | BOS terakhir di TF besar berlawanan arah | filter struktur TF besar |
| TF besar berbalik setelah entry | entry di ujung tren | filter tren lebih ketat |
| Struktur TF eksekusi masih melawan | TF besar searah tapi TF kecil belum CHoCH/BOS | konfirmasi struktur TF eksekusi |
| Pasar sideways | ADX TF besar < 20 | filter ADX |
| Setup valid tapi gagal | semua kondisi bagus tapi tetap kalah | wajar; kalau dominan berarti ide entry-nya lemah |

  Garis putih di bar menunjukkan seberapa sering kejadian itu terjadi **kalau harga bergerak acak**.
  Kategori baru dianggap masalah kalau jelas lebih sering dari garis itu, jadi saran tidak muncul hanya
  karena kebetulan.
- **Kondisi saat entry**: Win %, PF, dan Net dari trade yang **searah** dibandingkan dengan yang **melawan**
  struktur TF besar dan TF eksekusi, per level ADX, dan per sisi long/short. Kalau trade yang melawan
  struktur jelas lebih buruk, berarti strategi salah membaca struktur di TF itu.
- **Daftar trade** punya kolom SL, TP, alasan keluar (TP/SL), dan **Evaluasi** (kategori trade itu). Arahkan
  kursor ke baris untuk melihat detailnya. **Klik baris** untuk membuka Manual Replay tepat di momen sinyal,
  lalu Step maju untuk melihat sendiri apa yang terjadi.

**Filter tambahan (berlaku untuk semua strategi)**, ada di bagian bawah formulir parameter. Defaultnya mati:

| Parameter | Fungsi |
|---|---|
| `ms_filter_tf` | entry hanya searah Break of Structure terakhir di TF ini (mis. 4H) |
| `ms_confirm_tf` | entry hanya kalau struktur TF eksekusi juga sudah searah (sudah CHoCH/BOS) |
| `ms_swing` | ukuran swing untuk dua filter di atas |
| `adx_filter_tf`, `adx_filter_min` | entry hanya kalau ADX 14 di TF itu di atas batas |
| `rules` | filter indikator bebas, mis. `slope@1h >= 0.12; adx@4h >= 20; sl_atr <= 1.5` (lihat daftar fitur di bawah) |
| `sl_mult` | kali jarak SL dari strategi (1 = tetap) |
| `tp_rr` | TP = N × jarak SL, menimpa TP strategi (0 = pakai TP strategi) |
| `entry_shift_r` | geser entry N × jarak SL ke arah SL, jadi order limit lebih dalam (0 = mati) |

**Analisa mendalam & rencana perbaikan** (bagian atas kartu Evaluasi strategi):

Setiap trade, menang maupun kalah, diukur saat sinyal dengan ±90 kondisi indikator di beberapa timeframe:
TF eksekusi, TF besar strategi, 15M, 1H, 4H, dan 1D. Semua nilai dihitung dari candle yang sudah close.
Kemudian dicari kondisi mana yang membedakan trade menang dari trade kalah.

Supaya saran tidak sekadar kebetulan (overfitting), trade dibagi menurut waktu:

| Bagian | Isi | Dipakai untuk |
|---|---|---|
| Latih | 50% trade pertama | mencari aturan |
| Validasi | 20% berikutnya | menerima / menolak aturan |
| **Uji** | **30% trade terakhir** | **hanya untuk laporan**, tidak ikut dipakai mencari |

Label tiap saran:
- **lolos uji**: membaik juga di data uji. Inilah yang direkomendasikan.
- **perlu diuji**: belum bisa dibuktikan dengan simulasi, jadi coba dengan Uji saran.
- **tidak konsisten**: bagus di data latih tapi tidak di data uji. Jangan dipakai.

Isi **Rencana perbaikan**, diurutkan dari yang paling bisa dipercaya:
1. **Tambah filter indikator**: threshold baru untuk parameter `rules`, lengkap dengan WR dan R/trade
   sebelum → sesudah di data uji.
2. **Ubah jarak TP / SL**: `sl_mult` dan `tp_rr` terbaik dari simulasi ulang 54 kombinasi SL × TP.
3. **Resep WR > 50%**: kombinasi supaya trade menang lebih banyak dari kalah, dengan R/trade tetap positif.
4. **Entry limit lebih dalam**: `entry_shift_r` kalau banyak kalah karena entry terlalu awal.
5. **Perketat / longgarkan / hapus threshold yang sudah ada**: mis. `adx_min`, `min_rr`, `rsi_long`, `vol_mult`.
   Trade yang nilainya dekat batas dibandingkan dengan sisanya.

Tombol **Pakai di formulir** memasang perubahan itu. Tombol **Uji saran** menjalankan semua langkah sebagai variasi
dan menampilkan perbandingannya.

Klik **Analisa mendalam** untuk melihat detailnya:
- **Pola kesalahan**: indikator yang paling membedakan menang vs kalah, ditandai apakah konsisten di dua
  periode (✔) atau berubah-ubah (✖). Pola yang berubah-ubah jangan dijadikan filter.
- **Timeframe paling berpengaruh**: TF mana yang paling banyak menyimpan "celah" kesalahan.
- **Simulasi TP / SL**: heatmap WR dan R/trade untuk tiap kombinasi SL × TP, sebelum dan sesudah filter baru.
- **Simulasi entry lebih dalam**: berapa persen sinyal tetap terisi, dan WR / R-nya.
- **Filter yang ditolak**: kandidat yang bagus di data latih tapi gagal di validasi.

Daftar fitur untuk `rules` (pakai `@TF`, mis. `rsi@1h`). Semua nilai **searah** arah trade: untuk short dibalik,
jadi satu aturan berlaku untuk long dan short.

| Fitur | Arti |
|---|---|
| `e50`, `e200` | jarak harga ke EMA50 / EMA200 dalam ATR (positif = harga di sisi arah trade) |
| `slope` | kemiringan EMA50 searah (ATR per 5 candle) |
| `stack` | susunan EMA 20/50/200: +1 berurutan searah, −1 melawan |
| `bos` | struktur Break of Structure terakhir: +1 searah, −1 melawan |
| `rsi`, `stoch` | RSI 14 / Stochastic %K searah (long = nilai asli, short = 100 − nilai) |
| `adx`, `di` | ADX 14, dan DI+ − DI− searah |
| `macd`, `fi` | histogram MACD dan Force Index EMA2 searah (dinormalisasi) |
| `atrp`, `atrx` | ATR % harga; ATR ÷ rata-rata ATR 50 (> 1 = volatilitas melebar) |
| `vol` | volume ÷ rata-rata 20 |
| `rpos` | posisi di range 50 candle searah (0 = area murah untuk arah trade, 1 = sudah di ujung) |
| `bbw` | lebar Bollinger % (kecil = squeeze) |
| `candle` | body candle terakhir searah (−1..1) |

Fitur tanpa `@TF`:
- `sl_atr`: jarak SL ÷ ATR TF eksekusi.
- `rr`: RR rencana.
- `depth`: kedalaman entry dari harga sinyal, dalam R.
- `side`: +1 long, −1 short.
- `asia`, `london`, `ny`, `late`: sesi UTC, bernilai 1 kala trade dibuka di sesi itu.

Selalu cek ulang perbaikan di periode atau koin lain. Parameter yang hanya bagus di data yang dipakai untuk
mencarinya (overfitting) biasanya gagal di pasar sungguhan.

**Membaca hasil:**

| Angka | Artinya |
|---|---|
| Net PnL / Return | total untung-rugi setelah fee |
| Trade / Win rate | jumlah trade dan persentase yang profit |
| Profit factor | total profit ÷ total rugi. Di atas 1 = untung; makin besar makin bagus |
| Expectancy | rata-rata hasil per trade (USDT) |
| Avg win / Avg loss | rata-rata untung dan rugi per trade |
| Max drawdown | penurunan equity terbesar dari puncak (%) |
| Grafik equity | perjalanan saldo dari awal sampai akhir |
| Tabel trade | setiap trade: waktu masuk, arah, harga entry/exit, PnL |

Untuk melihat trade di chart: catat waktu masuknya, buka tab **Manual Replay**, lalu isi
**Mulai** sedikit sebelum waktu itu.

#### Strategi bawaan: `BreakoutD1H1` (breakout D1 + ADX + breakout S/R H1 + volume)

Aturan strateginya:
1. **Arah besar (D1):** close D1 menembus high 20 hari terakhir → arah **LONG**. Close menembus
   low 20 hari → arah **SHORT**. Arah bertahan sampai terjadi breakout ke sisi sebaliknya.
   Hanya candle D1 yang sudah close yang dipakai (candle hari ini belum dihitung).
2. **Filter tren:** ADX(14) D1 ≥ 25. Kalau di bawah 25, tidak ada entry.
3. **Trigger (H1):** candle H1 close di atas resistance (high tertinggi 48 candle H1 sebelumnya)
   untuk long, atau di bawah support (low terendah 48 candle) untuk short, **dan** volume candle
   itu ≥ 1.5 × MA20 volume.
4. **Entry:** market di open candle H1 berikutnya.
5. **SL** di low terendah 10 candle H1 terakhir (long) atau high tertinggi (short), ditambah buffer 0.1%.
   **TP** = 2 × jarak SL (RR 1:2).
6. **Ukuran posisi:** rugi kalau kena SL = `risk_usdt` (default 0.5 USDT, sudah termasuk fee).
7. Hanya satu posisi dalam satu waktu.

Parameter:

| Parameter | Default | Arti |
|---|---|---|
| `trend_donchian` | 20 | **arah trend** D1 (bukan entry): close D1 tembus high 20 hari = naik, tembus low = turun |
| `adx_len` / `adx_min` | 14 / 25 | periode ADX D1 dan nilai minimalnya |
| `sr_lookback` | 48 | jumlah candle H1 untuk menentukan support/resistance |
| `vol_ma` / `vol_mult` | 20 / 1.5 | volume breakout harus ≥ vol_mult × MA(vol_ma) volume |
| `sl_lookback` / `sl_buffer_pct` | 10 / 0.1 | SL di swing N candle H1 + buffer % |
| `rr` | 2.0 | TP = rr × risiko |
| `risk_usdt` | 0.5 | rugi per trade kalau kena SL (USDT). Isi `0` untuk memakai `risk_pct` |
| `risk_pct` | 1.0 | % equity per trade (hanya kalau `risk_usdt` = 0) |
| `long` / `short` | true / true | ubah ke `false` untuk menonaktifkan salah satu arah |

Contoh: hanya long, ADX minimal 30, RR 1:3:
```json
{ "trend_donchian": 20, "adx_len": 14, "adx_min": 30, "sr_lookback": 48, "vol_ma": 20, "vol_mult": 1.5,
  "sl_lookback": 10, "sl_buffer_pct": 0.1, "rr": 3, "risk_usdt": 0.5, "risk_pct": 1, "long": true, "short": false }
```

Definisi "S/R" dan "breakout D1" di atas hanyalah salah satu cara menerjemahkan strategi ke kode.
Kalau definisi lu beda (misalnya S/R dari swing high yang sudah disentuh 2×), aturannya ada di
`strategies\breakout_d1_h1.py`. Copy file itu dengan nama lain (misalnya `breakout_saya.py`),
ganti nama class-nya, lalu ubah aturannya. File baru otomatis muncul di dropdown Strategi.

#### Strategi bawaan: `BreakoutSNR` (market structure + EMA 50 + ADX, breakout S/R, SL 1× ATR)

1. **Trend besar** (`trend_tf`, default **D1**): arah market structure = Break of Structure terakhir
   (swing fractal `trend_swing`), lalu divalidasi **EMA 50**: LONG hanya kalau struktur bullish **dan** close
   di atas EMA 50 (SHORT kebalikannya), **dan ADX(14) ≥ 25** (`adx_min`, isi 0 untuk mematikan).
2. **S/R** di TF entry (`tf`, default **H1**) = swing high / swing low terakhir yang sudah terkonfirmasi (`sr_swing`).
3. **Breakout:** candle pertama yang close menembus S/R itu, dengan volume ≥ 1.5 × MA20 (`vol_mult`, 0 = mati).
4. **Entry** (`entry`): `retest` = limit order **di level S/R yang ter-breakout** (batal setelah `expire_bars`
   candle kalau tidak tersentuh), atau `close` = market di open candle berikutnya.
5. **SL = 1 × ATR(14)** dari harga entry (`sl_atr`), **TP = 2 × risiko** (`rr`).

#### Strategi bawaan: `RetestPullback` (H1 arah, M5 retest Fibonacci 0.5–0.618 + konfluensi)

1. **H1 (100 candle):** bullish kalau close di atas **EMA 26 dan EMA 60**, bearish kalau di bawah keduanya;
   **ADX > 25**; **Force Index EMA 2** H1 **positif** untuk long, **negatif** untuk short (`fi_len`).
2. **M5 (200 candle):** close di atas/bawah EMA 26 & 60, wajib **searah H1** (`ltf_trend`).
3. **Struktur M5:** muncul **Swing High baru** yang lebih tinggi dari swing high sebelumnya (long) / Swing Low
   baru yang lebih rendah (short). Swing = fractal 3 candle (`swing`).
4. **Fibonacci** dari Swing Low (low terendah di antara dua swing high) ke Swing High. **Zona entry 0.5–0.618.**
5. **Konfluensi** di dalam zona (scan 200 candle M5), minimal `min_confluence` jenis dari:
   FVG, Order Block (candle berlawanan yang lalu ditembus), S/R (swing lama), role reversal
   (resistance lama yang sudah ditembus jadi support). Dengan `fresh_only`, FVG/OB yang sudah terisi/ditembus
   tidak dihitung.
6. **Entry:** limit di konfluensi terdekat di dalam zona (`entry_at: confluence`), atau di level fib tertentu
   (`entry_at: fib` + `entry_fib`, mis. 0.618). Batal setelah `expire_bars` candle M5 (default 24 = 2 jam).
7. **SL** di bawah Swing Low acuan − 0.05%, **TP** = Fibonacci extension **1.272** (`tp_ext`, bisa 1.618).
   Setup dilewati kalau RR < `min_rr`.

Jenis konfluensi yang ditemukan tercatat sebagai label entry (mis. `fvg+rr+sr`).

#### Strategi bawaan: `BreakoutFibo` (H1 EMA50/200 → breakout S/R M5 → retest fibo)

1. **H1**: close di atas EMA50 & EMA200 = bullish, di bawah keduanya = bearish.
2. **M5**: breakout S/R searah H1, yaitu candle close menembus swing high/low terakhir dengan volume ≥ 1.6 × MA20.
3. **Tunggu swing high baru** (bullish) atau swing low baru (bearish) terbentuk, lalu tarik fibo swing low → swing high
   (0 = high). Setup batal kalau close balik melewati level yang ditembus.
4. **Entry limit di zona 0.382–0.618**:
   - `entry_at = confluence`: pakai FVG yang belum terisi atau S/R yang ditembus (S/R flip) di zona; kalau tidak ada,
     pakai `entry_fib`.
   - `entry_at = fib`: selalu di `entry_fib`.
5. **SL dan TP**:
   - SL = 2 × ATR M5 dari entry.
   - TP1 = RR 1:2.
   - TP2 = `tp2_level`. Angka minus = lewat ujung swing; −0.272 sama dengan "1.272" kalau fibo ditarik terbalik.
   - `tp_mode`: tp1 / tp2 / split.

**🔎 Cari angka fibo terbaik** (tombol di bawah Jalankan, hanya muncul untuk strategi ini):
- Semua setup yang ditemukan strategi disimulasikan untuk setiap kombinasi **entry** (0.236 · 0.382 · 0.5 · 0.618 ·
  0.705 · 0.786 · FVG/S/R) × **TP** (RR 1:2 · 0 · −0.13 · −0.272 · −0.414 · −0.618), dengan SL yang sama.
- Hasil dipisah per kondisi: **🟢 Bullish koreksi → BUY** dan **🔴 Bearish koreksi → SELL** (angka fibo terbaiknya
  bisa beda). Tidak ada sideways karena strategi ini hanya entry searah tren H1.
- Tiap kondisi punya kesimpulan singkat: **entry presisi terbaik** (dibandingkan adil di kolom RR 1:2), seberapa sering
  harga pullback/retest ke angka itu, dan **TP** yang biasanya tercapai (WR ≥ 50%) serta yang kadang tercapai (WR ≥ 35%).
- Tabel: warna = WR (hijau ≥ 50%, merah < 50%), **bukan** arah buy/sell. ✔ = konsisten di 30% data terakhir.
- Tombol **Pakai** di kartu Bullish memasang `entry_fib` / `tp2_level` (BUY). Di kartu Bearish memasang `entry_fib_sell` /
  `tp2_level_sell` dan mematikan `sell_same`, jadi BUY dan SELL bisa punya angka sendiri.

#### Strategi bawaan: `MoneyMagnetScalping` (H1 → M5 CRT, entry limit di CE FVG)

Pilih **MoneyMagnetScalping (5m)** di daftar strategi. Alurnya:
1. **Bias H1** dari candle H1 tertutup terakhir:
   - Posisi harga < 50% range candle itu = discount, ≥ 50% = premium.
   - Range ÷ ATR14 H1: di bawah 0.70 skip, 0.70–1.50 valid (+1 poin), 1.50–2.00 hati-hati (0 poin), di atas 2.00 skip.
2. **Liquidity M5**, 28 candle terakhir:
   - Swing fractal 2-2, maksimal 3 swing terbaru per sisi.
   - Wajib ada minimal 2 swing high dan 2 swing low.
   - ATR M5 = RMA 14 dari 35 candle.
3. **Sweep → reclaim → displacement → FVG**:
   - Sweep dalam 14 candle terakhir, menembus swing minimal 0.10 × ATR.
   - Reversal: reclaim maks 8 candle sejak sweep, lalu displacement maks 5 candle setelahnya.
     Continuation: displacement maks 10 candle setelah sweep tanpa reclaim.
   - Displacement: body ≥ 0.8 × ATR dan body ≥ 60% range candle.
   - FVG ≥ 0.10 × ATR. CE (50% FVG) harus di sisi yang benar dari ekstrem sweep.
4. **Skor** (maks 16, entry kalau ≥ `min_score` 12, A+ mulai 14):

   | Komponen | Poin |
   |---|---|
   | Setup lengkap | +11 |
   | Searah posisi H1 (long di discount / short di premium) | +2 |
   | Range H1 valid | +1 |
   | RR ke TP2 ≥ 3.5 | +2 |
   | RR ke TP2 3.0–3.5 | +1 |

5. **Entry, SL, TP**:
   - Entry LIMIT di CE.
   - SL = ekstrem sweep ∓ 0.15 × ATR. Dilewati kalau jarak entry–SL < 0.8 × ATR.
   - TP1 = RR 2. TP2 = swing liquidity berlawanan dengan RR ≥ 3, kalau tidak ada RR 3.
   - Entry maksimal 2% dari harga (BUY harus di bawah harga, SELL di atas).
   - Limit batal setelah 36 candle M5 (~3 jam). Isi `expire_bars = 288` untuk 24 jam seperti evaluator Jurnal.
6. **Filter korelasi BTC** (M15, 20 candle):
   - BTC bergerak < ±0.15% dianggap ranging dan tidak berefek.
   - Korelasi ≥ 0.75 dan BTC berlawanan arah: sinyal diblokir.
   - Korelasi 0.50–0.75 dan BTC berlawanan: tetap entry, trade diberi tag `btc-warn`.
   - Filter ini butuh data lokal `BTCUSDT`. Kalau datanya tidak ada, filter dilewati.

`tp_mode`:
- `tp1` (default): semua di TP1 RR 2.
- `tp2`: semua di TP2.
- `split`: 50% risiko di TP1 dan 50% di TP2. Satu sinyal tetap dihitung satu trade dengan PnL gabungan.

Tag trade: `A` / `A+`, `reclaim` / `continuation`, dan `btc-warn`. Bandingkan hasil per tag di kartu Evaluasi,
bagian **Kondisi saat entry → Tag / konfluensi**.

#### Strategi bawaan: `FibPrecision` (limit entry di level Fibonacci, per kondisi pasar)

Biasanya diisi otomatis dari tab **Studi Fibonacci** lewat tombol **Pakai di strategi FibPrecision**. Aturannya:
1. **Gelombang** di TF `tf`:
   - Naik = swing low → swing high. Turun = swing high → swing low.
   - Swing memakai fractal `swing`, dan panjang gelombang minimal `min_leg_atr` × ATR.
   - Fibonacci ditarik dari ujung gelombang (0) ke titik awal (1.0) begitu swing ujungnya terkonfirmasi.
2. **Kondisi pasar** di `regime_tf`:
   - Bullish = BOS terakhir naik + close di atas EMA50 + ADX ≥ `adx_min`.
   - Bearish = kebalikannya.
   - Selain itu Sideways.
3. **Level limit per kelompok** (`0` = tidak trade di kelompok itu):

   | Parameter | Kondisi pasar | Gelombang | Order |
   |---|---|---|---|
   | `lvl_bull_up` | Bullish | naik | BUY |
   | `lvl_bull_down` | Bullish | turun | SELL |
   | `lvl_bear_up` | Bearish | naik | BUY |
   | `lvl_bear_down` | Bearish | turun | SELL |
   | `lvl_side_up` | Sideways | naik | BUY |
   | `lvl_side_down` | Sideways | turun | SELL |

4. **SL dan TP**:
   - SL = di angka fibo `sl_<kondisi>` (kalau 0 pakai `sl_level`, default 1.0; mis. 0.886 lebih ketat, 1.13 lebih
     longgar) + `sl_buffer_atr` × ATR.
   - TP = `tp_<kondisi>` (kalau kosong pakai `target`).
   - TP = level `target`: `0` = ujung gelombang, `-0.272` / `-0.618` = extension.
5. **Limit batal** kalau candle close tembus 0, close tembus 1.0 (BOS), atau lewat `max_bars` candle.

#### Pilihan entry (semua strategi)

Setiap strategi punya parameter **`entry`**:

| Pilihan | Harga entry |
|---|---|
| `market` | langsung, di open candle berikutnya setelah sinyal |
| `limit_close` | limit di harga close candle sinyal |
| `limit_pct` | limit `limit_offset_pct` % lebih bagus dari close sinyal (default 0.2%) |
| `limit_atr` | limit `limit_atr` × ATR(14) lebih bagus dari close sinyal (default 0.5) |
| `limit_level` | limit di **level kunci** strategi (lihat tabel di bawah) |
| `limit_mid` | limit di **tengah zona** strategi (kalau strategi tidak punya zona = sama dengan `limit_level`) |

| Strategi | `limit_level` | `limit_mid` |
|---|---|---|
| BreakoutD1H1, BreakoutSNR | level S/R yang ditembus (retest) | sama |
| EmaRsi, Pullback | EMA fast | sama |
| CRT | CRT Low (long) / CRT High (short) | 50% range |
| SMC | tepi Order Block | tengah Order Block |
| ICT | tepi FVG | tengah FVG (CE) |
| EmaCross | close sinyal | sama |

Aturan yang berlaku untuk semua:
- Limit order **batal** kalau tidak tersentuh dalam `expire_bars` candle.
- Kalau saat sinyal harga **sudah melewati** level limit (atau level limit melewati SL), entry jatuh ke **market**
  supaya sinyal tidak hilang.
- **SL** tetap di level struktural strategi (swing, sweep, OB, FVG). Untuk strategi yang SL-nya berbasis ATR
  (BreakoutSNR, EmaRsi), SL dihitung dari harga entry yang sebenarnya.
- **TP** dihitung dari harga entry yang sebenarnya, jadi RR tetap sesuai `rr` (kecuali CRT `tp_mode: "range"`).

Entry limit yang terisi kena **fee maker** (lebih murah dari taker), tapi tidak semua sinyal akan terisi.

#### Ganti timeframe

Semua strategi punya parameter timeframe di formulir (baris kuning). Pilihan: **5M, 15M, 30M, 1H, 2H,
4H, 6H, 8H, 12H, 1D**. TF yang tidak punya file (30M, 2H, 6H, 8H, 12H) dirakit otomatis dari M5, jadi
tidak perlu download apa-apa. TF ini juga muncul di tombol TF Manual Replay.
Pastikan TF trend lebih besar dari TF entry (misalnya trend H4, entry M15).

#### Strategi bawaan lainnya

Konsep seperti CRT, SMC, dan ICT biasanya dibaca secara diskresioner. Supaya bisa di-backtest otomatis,
setiap konsep sudah diterjemahkan jadi aturan pasti. Semua strategi memakai `risk_usdt` (rugi per SL,
default 0.5 USDT, termasuk fee) dan `rr`. Versi **Scalp** = aturan yang sama di TF kecil.

| Strategi | TF | Aturan singkat |
|---|---|---|
| `EmaRsi` / `EmaRsiScalp` | H1 / M5 | EMA 9 memotong EMA 21, RSI ≥ 55 (long) / ≤ 45 (short), searah EMA 200. SL = 1.5 × ATR |
| `Pullback` / `PullbackScalp` | H1 (tren H4) / M5 (tren H1) | Tren: close HTF di atas EMA 50 HTF + EMA 20 > EMA 50. Harga menyentuh EMA 20 dalam 5 candle, lalu candle bullish close di atas EMA 20 dan high candle sebelumnya. SL di ujung pullback − 0.3 ATR |
| `CRT` / `CRTDaily` / `CRTScalp` | range H4 / D1 / H1; konfirmasi – / H1 / M5 | Candle range = candle HTF sebelumnya. Candle berikutnya menyapu low range lalu close kembali di dalam range → setup long (kebalikannya untuk short). Versi Daily/Scalp menunggu break struktur di TF kecil. **Entry** (`entry`): `limit_level` = limit di CRT Low/High (default), `limit_mid` = limit di 50% range, `market` = langsung; limit batal setelah `expire_bars` candle. SL di ujung sapuan, TP di sisi lain range (atau `tp_mode: "rr"`) |
| `SMC` / `SMCScalp` | H1, bias H4 / M5, bias H1 | Bias = arah BOS terakhir di HTF. Di TF entry: BOS searah bias (close tembus swing high), wajib ada FVG di kaki impuls. Limit di tepi Order Block (candle berlawanan terakhir sebelum impuls). SL di bawah OB, batal setelah 12 candle |
| `ICT` / `ICTScalp` | M15 / M5 | Hanya di killzone (UTC 07–10 London, 12–15 New York). Sweep swing low → MSS (close tembus swing high sebelum sweep) → limit di FVG setelah sweep. Filter: di atas EMA 50 H1/M15. SL di bawah low sweep |

Parameter penting yang sering diubah:
- `swing`: ukuran swing/fractal (3 = 3 candle kiri & kanan). Makin besar = struktur makin besar.
- `entry`: `"edge"` = tepi OB/FVG, `"mid"` = tengah (CE/50%).
- `require_fvg` (SMC): wajib ada FVG/displacement atau tidak.
- `killzones` (ICT): misalnya `"7-10"` hanya London, `""` semua jam. Jam dalam UTC (WIB − 7).
- `expire_bars`: limit order batal kalau tidak tersentuh dalam N candle.
- `tf`, `htf`, `confirm_tf`: timeframe, bisa diganti, misalnya SMC `"tf": "15m", "htf": "4h"`.

> **Soal scalping dan fee.** Dengan risiko tetap (misalnya 0.5 USDT) dan SL yang sempit, nilai posisi jadi
> besar, sehingga fee ikut besar. Contoh EmaRsiScalp di BTC selama 2 tahun: tanpa fee profit factor 1.04,
> dengan fee normal (maker 0.02% / taker 0.05%) jadi 0.40. Selalu backtest dengan fee yang sesuai akun lu
> (ubah di **Pengaturan akun & simulasi**). Strategi scalping biasanya butuh fee rendah atau entry pakai limit.

Hasil di data asli 2 tahun (Okt 2024 – Okt 2026, parameter default) hanya sebagai gambaran,
**bukan rekomendasi**: hampir semua strategi bawaan masih rugi tipis sampai sedang, terutama
versi scalping. Strategi bawaan adalah titik awal untuk diubah, bukan strategi yang sudah terbukti.

#### Membuat strategi sendiri

Buat file baru di `strategies\` (contoh `strategi_saya.py`). Strategi dimuat ulang setiap backtest
dijalankan, jadi tidak perlu restart. Jangan menyimpan strategi sendiri di file bawaan (`ema_cross.py`, `breakout_d1_h1.py`, `ema_rsi.py`,
`pullback.py`, `crt.py`, `smc.py`, `ict.py`, `breakout_snr.py`, `retest_pullback.py`), karena file-file itu ditimpa saat update. Copy dulu ke nama baru.

```python
from backend.indicators import adx, atr, ema, rsi, sma   # indikator siap pakai
from backend.strategy import Strategy

class Breakout(Strategy):
    """Breakout high 20 candle H4, rugi 0.5 USDT per trade, RR 1:2."""
    timeframe = "4h"                        # on_bar dipanggil tiap candle H4 close
    params = {"risk_usdt": 0.5, "rr": 2.0}

    def on_bar(self, ctx):
        h4 = ctx.closed("4h", 50)           # hanya candle yang SUDAH close
        if ctx.position.flat and not ctx.open_orders() and h4.c[-1] > h4.h[-21:-1].max():
            entry, sl = h4.c[-1], h4.l[-5:].min()
            qty = ctx.qty_for_loss(entry, sl, self.p.risk_usdt)
            ctx.buy(qty, "market", tp=entry + self.p.rr * (entry - sl), sl=sl)
```

Yang bisa dipakai di `ctx`:

| | |
|---|---|
| `ctx.closed(tf, n)` | n candle terakhir yang sudah close, isinya `.t .o .h .l .c .v` (array) |
| `ctx.position` | `.qty .entry .flat .long .short .liq` |
| `ctx.equity`, `ctx.now` | equity saat ini, waktu replay (ms UTC) |
| `ctx.buy(...)`, `ctx.sell(...)` | `(qty, type="market"/"limit"/"stop", price, tp, sl, expire_bars, reduce_only)` |
| `ctx.close()`, `ctx.cancel(id)`, `ctx.cancel_all()`, `ctx.open_orders()` | |
| `ctx.qty_for_loss(entry, sl, usdt)` | qty supaya rugi saat kena SL = `usdt` (termasuk fee & slippage) |
| `ctx.size_by_risk(entry, sl, risk_pct)` | qty supaya rugi saat kena SL = risk_pct% equity (tanpa fee) |
| `ctx.trade(side, entry, sl, tp, risk_usdt, risk_pct, type, expire_bars)` | pasang order dengan qty otomatis dari risiko |
| `backend.indicators` | `sma`, `ema`, `EMAStream` (EMA cepat per candle), `atr`, `adx`, `rsi`, `pivots` (swing high/low terkonfirmasi), `fvg`, `bos_bias` |

### 📍 Tes SNR + Dorongan % (batas Dorongan % untuk entry limit pullback/retest vs entry breakout)

- **SNR** ditandai dari swing high (resistance) / swing low (support) di **TF SNR** yang kamu pilih (fractal, baru dipakai
  setelah terkonfirmasi; level yang berdekatan < 0.3 ATR digabung; berlaku sampai tembus atau "umur SNR").
- Saat harga **mendekat** (dari > 2 ATR), **Dorongan %** (indikator di chart, rumus sama persis — dicek tes otomatis) dicatat
  **sebelum harga sampai**: di jarak 2, 1, 0.5 ATR, dan saat menyentuh. Pilihan default: hanya saat dorongan menuju SNR
  (beli ke resistance / jual ke support).
- Lalu dinilai: **breakout** = ada close melewati SNR; **respect** = menyentuh (wick ± 0.1 ATR) lalu close menjauh ≥ 1 ATR
  tanpa close tembus; **tidak sampai** = balik sebelum menyentuh (untuk limit: tidak terisi). Candle yang langsung tembus
  tidak dipakai sebagai pembacaan (nilainya sudah berisi gerakan tembus).
- Hasil: **batas Dorongan %** — *entry limit*: Dorongan di bawah X% → respect ≥ target; *entry breakout*: Dorongan ≥ Z% →
  breakout ≥ target — dicari di 70% data awal & dicek di 30% terakhir, dibandingkan dengan tanpa filter. Plus tabel per
  10% Dorongan, dan contoh kejadian yang bisa dibuka di Manual Replay.
- **🔎 Penghalusan terbaik otomatis** (default aktif): penghalusan Dorongan % 3 / 5 / 10 / 15 / 20 dibandingkan. Skor =
  seberapa baik Dorongan % (dibaca sebelum sampai SNR) membedakan breakout dari respect (50% = tebak koin). **Dipilih dari
  data cari (70%), dibuktikan di data uji (30%)**. Kalau skor data uji ≥ 55%, penghalusan itu **jadi default TF tersebut**
  (disimpan di `saved/dorongan_default.json`) dan otomatis dipakai indikator Dorongan % di chart — kecuali kamu sudah
  mengatur sendiri (tombol "Kembali ke bawaan" memakai default lagi). Kalau tidak lolos, default tidak diubah.
- **🧩 Faktor yang mempengaruhi SNR** (dibaca 1 ATR sebelum SNR, hanya yang sampai): **tren TF besar** (EMA 50/200 di TF
  SNR, searah / berlawanan dengan dorongan menuju SNR), **sentuhan sebelumnya** (0× / 1× / 2×+), **umur level** (< 1 / 1–3 /
  3–7 / > 7 hari), **kecepatan datang** (gerak 10 candle terakhir menuju SNR: < 1 / 1–3 / ≥ 3 ATR). Tiap kondisi: respect %,
  breakout %, % breakout yang lanjut, dan respect di data uji. Plus **kombinasi 2 faktor terbaik** untuk entry limit
  (respect tertinggi) dan entry breakout (tembus & lanjut tertinggi), dipilih di data cari & dibuktikan di data uji.
- **Contoh kejadian** (Tes SNR) dan **Lihat contoh trade** (Penemu Strategi): klik baris → Manual Replay terbuka di koin, TF &
  candle kejadian yang sudah close, dengan **garis otomatis**: SNR (kuning putus-putus, R = resistance / S = support) atau
  entry (biru) / SL (merah) / TP (hijau), plus garis vertikal di waktu kejadian. Garis ini tidak ikut tersimpan sebagai
  gambarmu. Kalau koneksi chart ke server sempat putus, otomatis tersambung lagi (dulu chart lama tetap tampil).
- **Lanjutan breakout**: dari close tembus, harga **lanjut ≥ 1 ATR** sebelum close balik ke dalam SNR = lanjut; close
  balik dulu = **fakeout** (kalau di candle yang sama dua-duanya terjadi = fakeout). ≈ WR entry breakout di close tembus
  dengan target 1 ATR dan batal saat close balik ke dalam SNR.
- **📝 Ringkasan simpel** (paling bawah, dibaca 1 ATR sebelum SNR): *entry limit pullback/retest* = rentang Dorongan % yang
  respect-nya di atas rata-rata (mis. "Dorongan 20% – 30% → respect 38%"), *entry breakout* = rentang yang breakout-nya di
  atas rata-rata (plus % yang lanjut ≥ 1 ATR). Dicari di data cari, dicek di data uji (✅ bertahan / ⚠️ turun).
- **Garis tengah**: batas Dorongan % yang paling memisahkan breakout (di atas) dari respect (di bawah), dicari di data cari
  & dicek di data uji (ditampilkan % breakout di atas garis dan % respect di bawah garis). Ikut jadi default indikator chart
  kalau penghalusannya lolos uji dan garisnya tetap memisahkan di data uji.

### 🧠 Penemu Strategi (komputer "mengamati chart" lalu menamai pola yang sering berhasil)

Seperti trader yang mengamati chart bertahun-tahun, tapi oleh komputer. Setiap candle (yang sudah close, tanpa intip masa
depan) dicek kejadiannya, lalu ribuan pola dirakit dan di-backtest:

| Bagian | Pilihan |
|---|---|
| Konteks (arah) | tanpa syarat / searah tren EMA 50/200 TF besar / searah market structure (BOS terakhir) / keduanya |
| Setup (dalam K candle terakhir) | tanpa / liquidity sweep / CHoCH / BOS / FVG terbentuk |
| Pemicu (candle entry) | pin bar penolakan / engulfing / tembus high-low candle sebelumnya / sentuh FVG / retest level BOS |
| Volume | semua / volume besar (≥ 1.5× rata-rata 20 candle) |
| SL | **dicari otomatis**: 1× / 1.5× / 2× ATR, atau di balik swing / sweep terakhir (+0.1 ATR, 0.5–4 ATR) |
| Lama trade maksimal | **dicari otomatis**: Scalping 2 / 4 / 8 jam, Intraday 12 jam / 1 hari / 2 hari |
| TP | **RR ditentukan kamu** (satu angka, atau beberapa — ditampilkan RR terbaik tiap pola) |

- **Gaya**: ⚡ **Scalping** (entry 5M, tren 1H) atau 🕐 **Intraday** (entry 15M, tren 4H). Tiap pola menampilkan
  **🔎 Ditemukan backtest**: SL, lama trade, dan RR terbaiknya. Titik kena SL / TP tiap candle dihitung sekali lalu
  dipakai ulang untuk semua kombinasi, jadi pencarian tetap cepat.
- Entry di close candle pemicu; TP & SL di candle sama = kalah; belum kena sampai batas = keluar (tidak menang). Sinyal yang
  berulang dalam K candle dihitung sekali.
- **✅ Lolos** hanya kalau: untung rata-rata di 70% data awal **dan** 30% data terakhir, mengalahkan entry sembarang (WR &
  rata-rata R), cukup trade, dan (kalau ≥ 3 koin) untung di ≥ 60% koin. Juga ditampilkan **stabil x/8** (untung di berapa
  bagian periode) dan **% waktu habis**.
- **Min. WR (%)**: pola dengan WR di bawah angka ini dianggap gagal dan tidak ditampilkan; WR data uji juga harus ≥ angka ini
  supaya ✅ lolos. Di bawah kolom tertulis WR impas tiap RR (mis. 1:2 = 33%).
- Tiap pola diberi **nama & aturan dalam bahasa biasa**. **Lihat contoh trade** menampilkan daftar trade pola itu di satu koin;
  klik baris untuk membuka momen sinyalnya di Manual Replay.
- Dari ribuan pola, sebagian pasti kelihatan bagus karena kebetulan: pakai banyak koin & periode panjang, dan percayai hanya
  yang ✅ lolos.
- Selama scan berjalan, pola yang sudah ketemu **langsung tampil** (⏳ Hasil sementara, diperbarui tiap koin selesai).

### 🧪 Indikator Tester (cari angka indikator yang cocok untuk TF yang di-backtest)

Tab **🧪 Indikator Tester** mencari set angka indikator yang paling cocok untuk TF tertentu, atau menguji angka kamu sendiri.
Semua dari backtest candle tanpa intip masa depan: entry di close candle sinyal, **SL = k × ATR**, **TP = RR × SL**
(keduanya kamu atur), batas waktu N candle (belum kena TP = tidak menang), TP & SL di candle yang sama = kalah, trade
tidak tumpang tindih. **70% data awal untuk mencari, 30% terakhir untuk menguji** (kolom *Data uji*, ✅ konsisten / ⚠️ belum).

| Tester | Peran | Sinyal |
|---|---|---|
| **📈 EMA Tester** | tren & market structure | MA hanya penentu arah: harga di atas MA utama & MA kedua = hanya LONG, di bawah keduanya = hanya SHORT, di antaranya = sideways (tidak trade). **Entry = pullback / retest**: close menembus swing terakhir searah tren (BOS) → harga balik menyentuh level BOS (± toleransi × ATR) dalam N candle dan close tetap di sisi tren → entry di close. Batal kalau close menembus balik level / waktu habis / keluar zona tren |
| **RSI** | validasi LONG / SHORT | balik keluar zona (SHORT saat RSI turun dari overbought) atau langsung saat masuk zona |
| **Stochastic** | validasi LONG / SHORT | %K memotong %D di zona overbought (SHORT) / oversold (LONG) |
| **MACD** | validasi LONG / SHORT | MACD memotong signal (di bawah 0 = LONG, di atas 0 = SHORT, atau semua cross) |
| **Force Index** | kekuatan tren | Force Index baru saja > k × rata-rata \|FI\| 100 candle (LONG) / < −k × (SHORT) |
| **ADX** | kekuatan tren | ADX baru saja di atas batas; arah dari +DI / −DI |
| **🧩 Kombinasi** | set kombinasi | RSI / Stoch / MACD = pemicu, MA pasangan / ADX / Force = syarat arah (semua harus searah). Tanpa pemicu: kalau ada MA pasangan, entry = pullback / retest seperti EMA Tester; tanpa MA pasangan, entry saat semua syarat baru saja searah |

- **Jenis MA**: EMA, SMA, WMA, RMA, HMA, DEMA, TEMA (MA utama & MA kedua boleh beda jenis). RSI / Stoch / MACD bisa
  diberi **filter tren** MA (hanya LONG di atas MA).
- **EMA Tester — yang dicari**: dua-duanya, cari MA kedua (MA utama sudah punya, pakai angka pertama di kolom MA utama),
  cari MA utama (MA kedua sudah punya), atau **test pasangan sendiri**.
- **WR struktur** (akurasi MA kedua, seperti fibo 0.7): harga sedang di atas kedua MA lalu candle **close** menembus MA kedua
  ke bawah dengan **body ≥ X%** dan **volume ≥ Y × rata-rata 20 candle** (kebalikannya untuk SHORT). Dihitung *valid* kalau
  dalam N candle terjadi **CHoCH** (close menembus swing low/high terakhir yang sudah terkonfirmasi) **dan** close menembus
  MA utama, sebelum harga close kembali ke sisi tren lama. Semua syarat bisa diatur.
- **Aturan pasangan**: MA utama (tren) **selalu angka lebih besar**, MA kedua **lebih kecil** (mis. 200 & 50). Saat bullish
  MA kedua ada di atas MA utama: harga tembus MA kedua dulu (peringatan), lalu MA utama (konfirmasi). Pasangan terbalik
  tidak diuji.
- Panjang MA boleh sampai **5000** (mis. EMA 1600); butuh data minimal ±3× panjangnya. Angka di luar batas ditolak dengan pesan, tidak dipotong.
- **Lama trade maksimal (candle)** = berapa lama trade boleh terbuka; belum kena TP / SL sampai batas ini = tidak menang.
  Di bawah kolom langsung tertulis lamanya (mis. "96 candle ≈ 1 hari di TF 15M"), dan ada tombol cepat 4 jam / 1 hari /
  2 hari / 1 minggu yang menyesuaikan TF. **Waktu tunggu konfirmasi** (WR struktur), panjang ATR, syarat badan candle,
  volume, dan swing ada di **⚙️ Pengaturan lanjutan** (tertutup, ada tombol kembalikan ke default).
- **Kolom dikosongkan = dicari otomatis** dari daftar angka umum (mis. MA kedua 5 … 100, RSI 5 … 28). Di mode *Cari MA
  kedua*, isi MA utama kamu (boleh beberapa, mis. `21, 55, 200`) dan kosongkan MA kedua: setiap MA utama dicarikan MA
  kedua terbaiknya (tabel 📌). Mode *Cari MA utama* kebalikannya. Mode *Test pasangan sendiri* wajib diisi dua-duanya.
  WR struktur dari < 10 kejadian diberi tanda ⚠️ sampel sedikit.
- **Pencarian bertahap**: kalau kombinasi lebih dari 3.000 (mis. semua kolom Kombinasi dikosongkan = ±300 ribu), tidak
  error tapi dicari bertahap: tahap 1 tiap indikator diuji sendiri, tahap 2 gabungan 2–6 angka terbaik tiap indikator.
  Cepat, tapi bisa melewatkan kombinasi yang hanya bagus kalau digabung; untuk lebih teliti isi daftar angka sendiri.
- Daftar angka: `20, 50, 100` atau `10-100:10` (dari-sampai:langkah). Maksimal 3.000 kombinasi per jalan; jumlahnya
  terlihat sebelum mulai.
- Kolom hasil: Trade (LONG / SHORT), **WR**, **Rata-rata R**, **WR dasar** (entry di semua candle dengan SL & TP sama),
  **Edge** (WR − WR dasar; ≤ 0 = indikator tidak membantu), WR struktur, **Sideways %**, Data uji. Kartu 🏆 menjelaskan
  hasil terbaik dengan bahasa biasa. **Test angka ini** memasang angka ke form (mode test) untuk diuji di TF / periode / koin lain.

### Studi Fibonacci

Tab **Studi Fibonacci** menjawab: *"Kalau harga koreksi, biasanya mantul di angka fibo berapa? Kalau gua pasang limit
di situ, sering menang nggak? Kalau candle close tembus angka fibo tertentu, apakah biasanya jadi BOS?"*

**Cara pakai:**
1. Pilih **TF gelombang** (tempat fibo ditarik, mis. M15) dan **TF kondisi pasar** (mis. H4).
2. Pilih koin: semua, koin terpilih, atau daftar. Atur periode kalau perlu.
3. Klik **Jalankan Studi**.

Aplikasi lalu bekerja otomatis di ribuan gelombang:
- mencari setiap gelombang naik/turun;
- menarik fibo begitu swing ujungnya terkonfirmasi (sama seperti di chart live);
- mencatat apa yang terjadi sesudahnya.

**📐 BOS / CHoCH saat tren EMA 50/200** (pilih **TF tren**, default H1, bisa diubah):
- Tren bullish = EMA50 > EMA200 di TF tren, bearish = EMA50 < EMA200. Yang dihitung hanya swing searah tren
  (bullish: swing naik, fibo low → high; bearish: swing turun, fibo high → low).
- **BOS** = close tembus 0 (lanjut tren). **CHoCH** = close tembus 1 (struktur berubah). Semua pakai close candle TF fibo.
- Hasilnya per bullish/bearish:
  - 🔻 **CHoCH**: angka fibo pertama yang kalau di-close tembus, ≥ 70% akhirnya jadi CHoCH.
  - 🔁 **Retest sebelum CHoCH**: setelah close tembus angka CHoCH itu (dan memang jadi CHoCH), sebelum tembus 1 harga
    biasanya balik (retest) sampai angka berapa, dan berapa persen yang langsung tanpa retest.
  - 🔺 **BOS**: angka fibo terdalam yang kalau harga close balik melewatinya, ≥ 70% akhirnya lanjut BOS.
  - 📏 Kedalaman koreksi biasa sebelum BOS.
  - 🎯 Sejauh apa setelah BOS (−0.13 … −0.618) dan setelah CHoCH (1.13 … 1.618).
- Angka dicek di 30% data terakhir (data uji). Tabel lengkap ada di **Detail per angka fibo**.

**Angka fibo yang dipakai:**

| Kegunaan | Level |
|---|---|
| Koreksi / limit entry | 0.236 · 0.382 · 0.5 · 0.618 · 0.65 · 0.705 · 0.786 · 0.886 · 1.0 |
| Setelah BOS | 1.13 · 1.272 · 1.414 · 1.618 |
| Target pantulan | 0 · −0.272 · −0.618 |

**Pengaturan:**
- **Swing**: fractal N candle kiri & kanan.
- **Min. gelombang**: panjang minimal × ATR, supaya gerakan kecil tidak dihitung.
- **ADX tren minimal**: batas untuk dianggap Bullish/Bearish; di bawah itu Sideways.
- **Buffer SL**: SL = di luar 1.0 + N × ATR.
- **Maks. candle**: batas menunggu.

Label **ATR · M15** di samping kolom menunjukkan ATR dihitung dari TF gelombang yang dipilih.

**Hasil:** dipisah per kelompok, yaitu Semua, Bullish/Bearish/Sideways × gelombang naik/turun. Harga contoh memakai
gelombang 100 → 200 supaya mudah dibayangkan.
- **🎯 Level limit terbaik**: level + target dengan hasil terbaik per gelombang, dicek di 30% data terakhir
  (lolos uji / tidak). Ada juga **WR tertinggi yang tetap untung** (hanya level yang terisi minimal 15% gelombang).
- **🚨 Level alarm**: level yang kalau candle **close** tembus, ≥ 70% akhirnya jadi BOS. Ini tanda awal pasar
  berubah arah, jadi jangan entry searah gelombang lagi.
- **📍 Target setelah BOS**: extension yang dicapai ≥ 50% gelombang setelah BOS.
- **Tabel 1**: per level, berapa persen tersentuh (wick), terisi, WR ke 0 / −0.272 / −0.618, pantulan median
  (dalam R dan %), dan R per gelombang.
- **Grafik 2**: di level mana harga paling sering berbalik sebelum lanjut.
- **Tabel 3**: close tembus level → jadi BOS / palsu (malah bikin high/low baru) / belum jelas, dan median berapa
  candle sampai BOS. Tembusan yang terjadi di candle BOS itu sendiri tidak dihitung, karena bukan tanda awal.
- **Tabel 4**: setelah BOS, sampai extension berapa sebelum harga close balik ke dalam struktur.

**🧾 Kesimpulan: kekuatan level fibo** (sejak v3.13, tanpa RR). Per kondisi pasar (Bullish/Bearish koreksi
searah tren, Sideways BUY/SELL) isinya:
- **Zona tempat pullback paling sering berhenti**: 0.236–0.382 · 0.382–0.5 · 0.5–0.618 · 0.618–0.786 · 0.786–1.0.
- **Tabel per level** (0.382 sampai sebelum level alarm), berisi:
  - **Tersentuh**: % setup yang koreksinya sampai level itu.
  - **Respek**: dari yang menyentuh, % yang memantul sampai 0 tanpa menembus level lebih dari k × ATR dan tanpa
    close tembus 1.0.
  - **+S/R flip / Tanpa**: respek kalau di level itu ada swing high lama yang sudah ditembus (resistance → support;
    untuk SELL support → resistance, jarak ±0.25 ATR), dibandingkan dengan yang tanpa.
  - **Pantul s/d**: median level fibo yang dicapai pantulan.
- **⭐ Level terkuat** = paling sering tersentuh × paling sering respek, dicek di data uji.
- **🛡️ SL oke** = level ∓ k × ATR TF eksekusi. k = seberapa dalam harga biasanya menusuk level sebelum memantul
  (melindungi ±80% pantulan).
- **🚨 Batal** kalau candle close tembus level alarm.
- Rencana entry/TP lama tetap ada di bagian **Rencana entry / TP (opsional)**.

Format kesimpulan (v3.14+) dibuat singkat, contoh:
```
📈 Bullish · koreksi turun → BUY
📍 0.5 → biasanya sampai -0.272, kadang -0.618
⭐ Terkuat: 0.382 (memantul 53%)
🛡️ SL: 1.5 × ATR 15M dari entry
🚨 Batal: candle close tembus 0.786
```
- "biasanya sampai" = level terjauh yang dicapai ≥ 50% pantulan.
- "kadang" = level yang dicapai ≥ 30%.
- Klik **Detail angka** untuk tabel lengkapnya.

**🚀 Breakout sideways** (paling bawah kesimpulan, untuk pasang buy stop / sell stop): kalau candle **close** tembus
level fibo di luar ujung range (0 · −0.05 · −0.1 · −0.13 · −0.2 · −0.272), berapa persen yang benar-benar lanjut.
- **Lanjut** = harga bergerak lagi minimal 0.382 × lebar range sebelum close balik ke dalam range.
- **Palsu** = harga balik ke dalam range dulu.
- Yang dipilih = level terdekat yang ≥ 70% lanjut, plus rata-rata sampai mana dan hasil di data uji.

Di tampilan per kelompok ada tabel **Kekuatan level** dengan pilihan k (SL = level ∓ k × ATR). Ganti k untuk melihat
respek tiap level di threshold mana pun.

**🧾 Kesimpulan** ada di paling atas hasil, satu kotak per kondisi pasar:

| Kondisi pasar | Arah | Cara tarik fibo |
|---|---|---|
| 📈 Bullish | BUY retest di koreksi gelombang naik | swing **low → high**: 0 = high, 1 = low; koreksi turun |
| 📉 Bearish | SELL retest di koreksi gelombang turun | swing **high → low**: 0 = low, 1 = high; koreksi naik |
| ↔️ Sideways | BUY dan SELL | sesuai arah gelombangnya |

Angka fibo yang sama berarti kedalaman koreksi yang sama, hanya arahnya terbalik. Contoh gelombang 100 & 200:
- Bullish 0.618 = 138.2 (BUY).
- Bearish 0.618 = 161.8 (SELL).
- Extension −0.272 = 227.2 untuk bullish dan 72.8 untuk bearish.

Setiap kesimpulan berisi:
- **Entry retest terbaik**: level limit dengan hasil per trade terbaik saat TP di TP1, dan harus tetap untung.
- **TP1**: level fibo terjauh yang dicapai **≥ 60%** trade sebelum kena SL.
- **TP2**: level yang dicapai **≥ 35%** trade.
- **Rata-rata (median) pantulan**: sampai level berapa harga biasanya memantul.
- **SL**: di luar 1.0 + buffer ATR.
- **Data uji**: WR ke TP1 di 30% data terakhir (lolos / tidak lolos uji).
- **🚨 Alarm**: kalau candle close tembus level ini, kemungkinan besar jadi BOS, jadi berhenti entry ke arah itu.
  Kalau level alarm sama atau lebih dangkal dari entry, muncul peringatan untuk cut lebih awal.
- **📍 Target setelah BOS** untuk posisi arah sebaliknya.

- **SL terbaik / SL aman**: hasil uji letak SL di angka fibo 0.886 · 0.94 · 1.0 · 1.05 · 1.13 · 1.2 · 1.272 · 1.414 ·
  1.618 · 2.0. Entry dan TP1 tetap, hanya SL yang digeser.
  - ⭐ **SL terbaik** = hasil per trade (R) tertinggi.
  - 🛡️ **SL aman** = SL paling longgar yang hasilnya masih ≥ 80% dari yang terbaik, jadi lebih tahan sweep dan
    profitnya hampir sama.
  - Klik **Lihat uji semua letak SL** untuk tabel lengkap: WR, RR, dan R/trade, di data latih dan data uji.
  - Kalau tidak ada letak SL yang untung, setup itu ditandai **tidak lolos uji**.

**Entry tidak pernah di/lewat level alarm.** Kalau candle close tembus level alarm, struktur biasanya patah, jadi
entry hanya dicari di level yang lebih dangkal dari alarm. Di tabel per level, level di/lewat alarm diberi tanda ⚠️.
Kartu 🎯 di tiap kelompok memakai rencana yang sama persis dengan Kesimpulan (entry + TP1/TP2 + SL terbaik/aman).

**Istilah kelompok:**
- **Bullish · koreksi searah tren (BUY)** dan **Bearish · koreksi searah tren (SELL)**: ini yang disarankan.
- **⚠️ ... koreksi melawan tren**: hanya data, tidak disarankan untuk entry. Yang berguna dari kelompok ini hanya
  level alarm dan target setelah BOS.
- **Sideways · BUY / SELL**.

Tombol **Pakai di strategi FibPrecision** mengisi rencana tiap kondisi pasar yang lolos uji ke strategi:
- `lvl_<kondisi>` = entry;
- `tp_<kondisi>` = TP1;
- `sl_<kondisi>` = SL terbaik;
- `sl_buffer_atr` = 0.

Kondisi yang tidak lolos uji dan semua koreksi melawan tren diisi 0 (tidak trade).

Tombol **Salin kesimpulan** menyalin semuanya sebagai teks. Hasil yang disimpan sebelum v3.8 belum punya data
TP1/TP2, jadi jalankan ulang studinya.

**Selama studi berjalan** ada panel progres yang berisi:
- persentase dan garis progres beranimasi;
- jumlah koin dan gelombang yang sudah dihitung;
- kecepatan (koin/menit), waktu berjalan, dan perkiraan sisa waktu. Sisa waktu dihitung dari kecepatan
  sebenarnya setelah semua proses paralel berjalan, jadi di awal tertulis "menghitung…";
- daftar koin yang baru selesai dan koin dengan gelombang terbanyak;
- **bocoran hasil sementara**: persen tersentuh dan WR per level, diperbarui tiap beberapa detik;
- tips cara membaca hasil.

Hasil setiap koin langsung diringkas per bulan, jadi studi ratusan koin di M5 tetap hemat memori. Data uji =
bulan-bulan terakhir yang berisi ±30% gelombang.

Level 1.0 tetap ditampilkan di tabel, tapi tidak dipakai sebagai rekomendasi limit. Limit tepat di titik awal
gelombang membuat SL sangat dekat, sehingga R terlihat besar padahal sangat sensitif terhadap slippage.

**Simpan & buka lagi hasil studi:**
- Setelah studi selesai, klik **💾 Simpan hasil studi** dan beri nama. Defaultnya berisi TF, kondisi pasar, jumlah koin, dan tanggal.
- Semua hasil ada di **📂 Hasil studi tersimpan**, di bawah tombol Jalankan Studi. Tiap item menampilkan TF, jumlah
  gelombang, periode, dan waktu disimpan.
- **Buka** menampilkan lagi hasil lengkapnya, semua kelompok kondisi pasar, tanpa menghitung ulang.
- **Hapus** untuk menghapus. Klik 2x nama untuk ganti nama.
- File tersimpan di `saved\fibstudy\` di folder aplikasi. Tidak tertimpa saat update; kalau pindah laptop, salin
  juga folder `saved`.

Tombol **Pakai di strategi FibPrecision** mengisi level yang lolos uji ke strategi FibPrecision di Auto Backtest.
Tinggal klik Jalankan untuk menguji sebagai strategi lengkap dengan evaluasinya.

#### 📘 Cara pakai fibo (untuk pemula)

Bagian paling atas di Kesimpulan (Studi Fibonacci v1 & v2) berisi panduan langkah demi langkah untuk **Bullish → BUY**,
**Bearish → SELL**, dan **Sideways**. Tiap kartu punya gambar posisi swing ("klik 1" / "klik 2") dan angka-angka dari hasil
studi itu sendiri:
1. cek tren (TF & EMA yang dipilih);
2. cari dorongan terakhir yang sudah selesai: bullish dari **swing low → swing high**, bearish dari **swing high → swing low**,
   sideways dari **swing terakhir** (naik: low → high, turun: high → low);
3. tarik fibo: klik 1 di awal dorongan (= 1), klik 2 di ujung dorongan (= 0);
4. pasang limit, SL, TP; kapan membatalkan (alarm); dan kapan menarik ulang fibo;
5. sideways: main di dalam range atau main breakout (buy/sell stop, retest, kalau breakout gagal).

Angka yang belum lolos uji diberi tanda "(belum pasti, pakai kecil dulu)". Panduan ikut tersalin lewat **Salin kesimpulan**.

### Studi Fibonacci v2

Tab **Studi Fibonacci v2** sama persis dengan Studi Fibonacci (cara pakai, kesimpulan, BOS/CHoCH, breakout sideways,
simpan hasil). Bedanya cuma dua:
- **Set angka fibo:** −0.618 · −0.414 · −0.272 · −0.13 · 0 · 0.295 · 0.382 · 0.441 · 0.5 · 0.559 · 0.618 · 0.705 · 1 ·
  1.13 · 1.272 · 1.414 · 1.618.
  - Entry/koreksi: 0.295 … 0.705.
  - CHoCH: 1, lalu target 1.13 … 1.618.
  - BOS: 0, lalu target −0.13 … −0.618.
  - Breakout sideways: 0 / −0.13 / −0.272.
- **TF default:** fibo **M5**, kondisi pasar **H1**, tren EMA **H1**. Semua bisa diganti.

**EMA tren bisa diganti** di v2 (kolom **EMA cepat** / **EMA lambat**, default 50 / 200).

**🔍 Angka rahasia market** (hanya v2): angka fibo dipindai tiap 0.01 (bukan cuma angka umum). Tiap angka diberi peran
dan penjelasan, dipilih di 70% data awal lalu dicek di 30% data terakhir (✅ lolos uji / ⚠️ belum pasti). 🆕 = angka
yang bukan angka fibo biasa. Peran yang dicari per kondisi pasar (bullish, bearish, sideways buy/sell):
- 🎯 **Limit entry pullback / retest + S/R kuat**: angka yang lebih sering direspek (memantul sampai 0 sebelum ada close
  tembus) dibanding angka di sekitarnya. Kalau tidak ada yang menonjol, ditulis jujur "tidak ada".
- 🛑 **Koreksi biasanya berhenti di sini**: titik balik koreksi paling sering di swing yang lanjut BOS, juga per
  kemiringan impuls (landai / sedang / curam).
- 🚨 **Alarm**: close tembus angka ini → ≥ 70% jadi CHoCH. 🛡️ **SL aman**: 80% / 90% koreksi yang lanjut BOS tidak lewat angka ini.
- 💰 **TP jauh** (ditahan sampai struktur patah) dan 🏁 **TP cepat**: dorongan pertama setelah BOS biasanya habis di sini.
- 🚀 **Awal breakout valid** (sideways): close tembus angka ini → ≥ 70% lanjut. 🔁 **Retest setelah breakout valid**.
- 🪤 **Gagal breakout**: kalau close tembus 0 lalu balik ke dalam range, harga biasanya lari sampai angka ini sebelum
  mencoba breakout lagi.

Di bawahnya ada **📋 Saran set fibo**: gabungan angka yang lolos uji (angka yang berdekatan digabung), lengkap dengan
kegunaan tiap angka dan tombol **Salin set** untuk dimasukkan ke level Fibonacci di chart.

Hasil v1 dan v2 disimpan terpisah (`saved\fibstudy\` dan `saved\fibstudy2\`). Seperti proses berat lain, hanya satu
studi yang boleh berjalan sekaligus.

### Paralel, jeda / lanjutkan & hasil tersimpan di semua menu studi

- **📍 Tes SNR, 🧠 Penemu Strategi, 🧪 Indikator Tester** sekarang berjalan **paralel di semua inti CPU** (seperti Auto
  Backtest & Studi Fibonacci). Hasil tiap koin digabung **urut sesuai daftar koin**, jadi hasilnya sama persis dengan
  dihitung satu per satu (dicek tes otomatis). Tes SNR juga jauh lebih cepat: Dorongan % dihitung sekali per koin, dan
  penyusunan hasil memakai perhitungan sekaligus (jutaan kejadian dalam beberapa detik, tidak lagi "macet di 100%").
- Semua menu itu punya tombol **⏸️ Jeda / ▶️ Lanjutkan / ✖ Batal**, dan ikut di bar "dijeda" di atas (tetap bisa
  dilanjutkan walau aplikasi ditutup). Koin yang sedang dihitung saat dijeda diselesaikan dulu (tidak ada hasil hilang).
- **💾 Hasil tersimpan** (di bawah tombol Jalankan, termasuk 🎯 Cari setup Whale): setiap hasil otomatis disimpan di
  `saved/results/<menu>/`. Bisa **dibuka lagi tanpa menghitung ulang**, diberi nama ✏️, atau dihapus 🗑️.
- Whale & Screener tidak dipercepat dengan cara ini: yang membatasi adalah batas permintaan Binance, bukan CPU.

### 🐋 Whale: perbaikan celah logika Cari setup (A–F) — layak harus terbukti di data uji, gerak beda, limit diuji saat tersentuh (v4.33)

Perbaikan celah logika 🐋 Whale › 🎯 Cari setup (hasil pemeriksaan kode, disetujui pemilik: A–F). Semua bisa diatur di
⚙️ Threshold › **Syarat setup layak (v4.33)**; nilai "tidak" / angka kecil = perilaku lama.
- **(A) Layak harus untung di data cari (70% awal) DAN data uji (30% terakhir)**, dengan data uji minimal 10 trade. Dulu cukup
  rata-rata untung di semua data — setup terbaik dari ratusan percobaan (3 entry × RR × arah × ratusan koin) sering hanya kebetulan.
- **(B) "Gerak beda"**: jumlah trade yang tidak tumpang tindih (1 posisi sekali jalan) ditampilkan di kolom WR; layak butuh ≥ 15.
  Backtest entry di setiap candle menghitung pergerakan harga yang sama berkali-kali (390 trade bisa hanya belasan gerak).
- **(C) SL terlalu jauh: default sekarang "tolak"** (dulu "potong" ke 4% sehingga SL bisa masuk zona gocekan), dan **WR di atas batas
  ⚠️ curiga (85%) = tidak layak**.
- **(D) Backtest entry limit dimulai saat harga benar-benar menyentuh harga limit** (dalam batas peluang tersentuh 24 jam), SL / TP
  diukur dari harga limit, candle terisi ikut dicek SL. Dulu limit diuji seperti market (masuk di close setiap candle). Contoh trade
  (🔍) memakai aturan yang sama. Ditandai "uji: saat limit tersentuh".
- **(E) "⚠ tren campur"**: kalau trade dengan kondisi tren sama seperti sekarang kurang dari sampel minimal, backtest memakai semua
  candle — sekarang ditandai di tabel (dulu diam-diam).
- **(F) Jurnal: sinyal Whale dicatat saat harga koin dibaca waktu scan**, dan candle yang sedang berjalan ikut dicek SL / TP
  (dulu ±15–30 menit pertama sesudah scan tidak dicek). Sinyal menu lain (dicatat di close candle) tidak berubah.
- Alasan tidak layak ditulis di kolom rata-rata (mis. "rugi di data uji (30% terakhir)", "pergerakan berbeda kurang (9 < 15)").
- Catatan: jumlah setup ✅ layak akan jauh lebih sedikit — itu disengaja. Teks "syarat layak sama dengan Whale" di menu Chart Pattern
  & TA Pro belum diubah (menu lain, belum diminta).

### 🐋 Whale: hanya setup searah kondisi pasar · 📒 Jurnal: jumlah scan di evaluasi jam & hari (v4.32)

- **🐋 Whale › 🎯 Cari setup: pilihan baru "Hanya setup searah kondisi pasar"** (default menyala). Setup yang arahnya melawan
  kondisi pasar Whale (kolom Tren merah, mis. SELL saat BULLISH) atau saat SIDEWAYS **tidak ditampilkan dan tidak dicatat ke 📒 Jurnal**.
  Jumlah setup yang disembunyikan ditulis di atas tabel. Alasan: di jurnal pemilik, sinyal melawan tren rugi −0,52R/trade (84 trade),
  dan kerugian besar 23 Nov datang dari SELL saat market naik. Matikan centang untuk melihat semua setup seperti sebelumnya.
- **📒 Jurnal › 🔍 Evaluasi › ⏰ Waktu & hari MULAI scan: kolom "Scan"** (berapa scan berbeda yang menghasilkan trade itu) di tabel
  jam & hari dan di peta hari × jam ("trade · scan"). Jam / hari dari < 5 scan ditandai **"sedikit scan"**, tidak dipilih sebagai
  ✅ terbaik dan tidak dipakai untuk saran — banyak trade dari 1–2 scan mencerminkan kondisi market saat itu, bukan jam / hari scan.
  Peringatan muncul kalau total scan masih < 20.
- Perbaikan: kelompok RR di evaluasi dibulatkan ke 0,5 (Chart Pattern punya RR pecahan seperti 1:1.01367).

### 📒 Jurnal: kartu 🔍 Evaluasi (pecahan hasil, analisa SL, koin, jam & hari MULAI scan, saran) (v4.31)

- **📒 Jurnal · kartu baru 🔍 Evaluasi** di tiap sumber sinyal (Whale, Market Structure, TA Pro, Chart Pattern, Entry kamu):
  kenapa hasil live beda dengan backtest. Dihitung dari trade yang sudah selesai, **hanya info** (tidak ada setelan yang berubah).
  - **Pecahan hasil** live vs backtest: arah BUY/SELL, searah / melawan / tanpa tren, RR, TF, entry market/limit, versi aplikasi —
    WR live, WR backtest, R/trade, tanda ✅ / ⚠️ / ❌ (kelompok kecil ditandai "sedikit").
  - **Analisa SL**: % trade yang sempat ≥ +1R lalu kena SL, % kena SL lalu harga tetap sampai TP (SL terlalu sempit), % langsung
    kena SL, median waktu sampai SL, sebaran seberapa jauh harga sempat jalan ke TP, dan perkiraan hasil kalau SL dipindah ke entry
    setelah +1R (dihitung ulang dari candle Binance asli tiap trade; candle diambil sekali saat 🔄 Perbarui / pantau otomatis lalu disimpan).
  - **Koin** paling rugi & paling untung (min. 5 trade).
  - **⏰ Waktu & hari MULAI scan** (WIB): dihitung dari saat tombol scan ditekan, bukan saat scan selesai. Tabel jam (07–11, 11–15,
    15–19, 19–23, 23–03, 03–07 WIB), tabel hari Senin–Minggu, peta hari × jam, jeda scan → entry terisi, limit yang terisi > 12 jam
    setelah scan, scan yang menghasilkan banyak sinyal sekaligus.
  - **Saran otomatis** (hanya dari kelompok ≥ min. trade) + ringkasan 1 kalimat. Pilihan: TF, min. trade per kelompok (5–50),
    "hanya sinyal dengan waktu scan pasti"; versi ikut pilihan Versi jurnal.
- **Waktu mulai scan dicatat** di setiap sinyal baru (`scan_start`). Sinyal lama belum punya: diperkirakan dengan mengelompokkan
  sinyal yang tercatat berdekatan (≤ 30 menit, per sumber) sebagai 1 scan, waktu = sinyal paling awal; ditandai "perkiraan".
- Bar "Pengaturan akun & simulasi" disembunyikan di tab Jurnal (tidak dipakai, menutupi hasil).

### 🧭 Menu baru Penentu Arah: model membalik arah sinyal strategi hanya kalau yakin (belajar 70%, uji 30%) (v4.30)

- **Tab baru 🧭 Penentu Arah** (menu atas, sesudah 📈 Moving Average Analisis): semua sinyal strategi **tetap diambil**, model hanya
  **membalik arah** kalau yakin arah sebaliknya lebih sering benar. Jumlah sinyal tidak berkurang.
- **Sumber sinyal**: 🐋 Whale · 📐 Market Structure · 🧠 TA Pro · 🧩 Chart Pattern · 🔄 Find Reversal (logika sama dengan 🛡️ SL Backtest),
  💧 Liquidity Sweep, 📈 MA Analisis (EMA 200 + RSI 14). Beberapa jenis entry di candle yang sama = 1 sinyal.
- **Jawaban** tiap sinyal: harga lebih dulu bergerak +2 ATR atau −2 ATR dari close sinyal (batas 5 hari). Tidak sampai keduanya = tidak dihitung.
- **Faktor** (bisa dipilih, hanya data yang sudah ada saat candle sinyal close):
  - Tren TF besar + arah BTC: tren 4H & 1D (dirakit dari data lokal), arah BTC TF sama & 4H, gerak BTC 12 candle.
  - Momentum & kondisi market: RSI, ADX, jarak EMA200, gerak 12 candle, volatilitas.
  - Order transaksi: perkiraan delta volume 3 & 12 candle (posisi close × volume), lonjakan volume. Data candle lokal tidak punya taker asli.
  - Flow whale: OI × harga, taker beli/jual asli, long/short top trader, funding (Binance, hanya ±30 hari terakhir). Kalau Binance tidak
    terjangkau, 2 koin gagal → flow dilewati otomatis (tidak menunggu tiap koin).
  - Waktu & struktur: sesi, akhir pekan, struktur swing HH/HL – LH/LL, posisi di range 50 candle.
- **Model** regresi logistik belajar di 70% data awal tiap koin. **Ambang yakin** (minimal 55%) dipilih di bagian akhir data belajar yang tidak
  dipakai saat model belajar, lalu model dilatih ulang dengan seluruh 70%. Dinilai di 30% terakhir.
- **✅ Terbukti** hanya kalau akurasi uji naik ≥ 0,5 poin, ≥ 20 sinyal dibalik, dan yang dibalik benar > 50% bukan kebetulan (uji z ≥ 1,64).
  Kalau tidak: **❌ tidak membantu — tetap pakai arah asli**.
- **Hasil**: 3 kotak (arah asli / dengan penentu arah / yang dibalik), R/trade RR 1:2, tabel per tingkat keyakinan, pengaruh tiap grup faktor
  (model dihitung ulang tanpa grup itu), rincian per faktor (akurasi saat mendukung vs melawan), contoh sinyal (filter "dibalik"), visual chart
  asli + animasi (panah arah strategi vs arah model, target ±2 ATR, candle muncul bertahap, 🔁 putar ulang, ◀ ▶, ▶ Manual Replay), 📂 Hasil tersimpan.
- **Cepat**: ± 2 detik untuk 22 koin 15M (koin paralel, cache memori & file). *Koreksi v4.31: data uji saat itu BTC 2 tahun, 21 koin lain hanya 60 hari (Agu–Okt 2026) — bukan 22 koin × 2 tahun.*
- **Hasil di data asli (22 koin, 15M: BTC 2 tahun, 21 koin lain hanya 60 hari Agu–Okt 2026; tanpa flow karena Binance tidak bisa diakses dari tempat uji)** — data uji 30% terakhir. *Data pendek & pasar bertren → angka ini kemungkinan terlalu optimis; uji ulang dengan data lokal yang panjang:*
  - 💧 Sweep 47,6% → 56,3% ✅ (2.395 dibalik, R/trade −0,05 → +0,13) · 🧩 Chart Pattern 51,6% → 57,4% ✅ · 📐 Market Structure 53,8% → 56,5% ✅
  - 🧠 TA Pro 49,5% → 52,6% ✅ (sampel kecil) · 🐋 Whale 55,5% → 55,9% ❌ · 🔄 Reversal 51,9% → 52,9% ❌ · 📈 MA Analisis: sinyal terlalu sedikit.
- Batasan: flow & taker asli hanya ±30 hari (hampir semuanya jatuh di data uji, jadi model hampir tidak bisa belajar darinya — dinilai terpisah
  di rincian per faktor); tembok order book tidak punya riwayat (tidak dipakai).

### 📈 Moving Average Analisis: periode MA otomatis 13–993, batas gagal 2,5 ATR, aturan sentuh dipertegas, visual dirapikan (v4.29)

- **Batas gagal 1 ATR → 2,5 ATR** (pilihan pemilik "A"): respect = harga bergerak ≥ 2 ATR searah sebelum melawan **2,5 ATR**.
  Satu ekor gocekan di dekat MA tidak langsung dihitung gagal lagi. Garis merah di visual & teks ikut 2,5 ATR. Hasil lama yang
  tersimpan tetap tampil dengan batas 1 ATR (seperti saat dihitung).
- **Periode MA otomatis**: pilih "otomatis 13–993 (tiap 10)" di Periode MA → semua MA 13, 23, 33, … 993 (99 periode) dipasangkan
  dengan semua periode indikator yang diuji (6 atau 56). Untuk tiap pasangan: candle RSI overbought / oversold (atau MACD
  berbalik / Stochastic 80/20) yang ekornya **cuma menyentuh** MA itu, lalu dinilai sama (respect / gagal / poin). Pasangan
  dengan skor tertinggi (≥ 30 sinyal) dipakai, lalu dihitung detail + contoh + visual animasi untuk MA itu.
  - Kartu baru **🔎 Periode MA terbaik**: ⭐ pasangan, skor di 30% data terakhir, grafik skor terbaik tiap periode MA, peta skor
    MA × periode indikator, 15 pasangan teratas, peringatan "ribuan pasangan diuji → cek skor uji & jumlah sinyal".
  - Progres 3 tahap: 1️⃣ cari periode MA (x/y koin, pasangan terbaik sementara) → 2️⃣ detail & contoh MA terbaik → 3️⃣ urutkan & simpan.
  - Cepat: ± 2 detik per koin (15M, 200 hari, 5.544 pasangan) di data contoh; koin dihitung paralel.
- **Aturan sentuh dipertegas**: ekor "cuma menyentuh" = paling jauh 0,3 ATR dari MA, di atas **atau menembus** (dulu tembusan
  ekor tidak dibatasi), close tetap di sisinya.
- **Visual dirapikan**: label "sentuh MA + …" pindah ke atas chart dengan garis penunjuk (tidak menumpuk dengan tanda ❌ / ✅),
  angka harga di kanan yang bertabrakan dengan label target / gagal tidak ditulis.

### 📈 Menu baru Moving Average Analisis (RSI / MACD / Stochastic paling cocok dengan MA, visual chart asli + animasi) · EMA Tester dihapus (v4.28)

- **Tab baru 📈 Moving Average Analisis** (menu atas): mencari setelan indikator yang paling cocok dengan 1 MA.
  Pilih tipe MA (EMA / SMA), periode MA, indikator (RSI / MACD / Stochastic), periode yang diuji (8 · 16 · 21 · 34 · 48 · 55
  atau otomatis 5–60), TF dan jumlah koin lokal (maks 150, dihitung paralel).
- **Aturan**: sentuh MA = ekor candle ≤ 0,3 ATR dari MA (atau menembus), close tetap di sisinya. Di atas MA + oversold →
  harap naik; di bawah MA + overbought → harap turun. RSI 70/30 · Stochastic %K (smooth 3, %D 3) 80/20 · MACD fast = angka,
  slow = angka × 26/12, signal = angka × 9/12, sinyal = histogram berbalik.
- **Respect** = harga bergerak ≥ 2 ATR searah sebelum melawan 1 ATR (candle sama = gagal), batas 5 hari.
  **Poin**: gagal −1 · 2 ATR = 1 · bonus +0,5 di 3 ATR, 4 ATR, ≥ 5 ATR. Skor = rata-rata poin per sinyal (dinilai ≥ 30 sinyal),
  dibandingkan dengan semua sentuhan MA tanpa indikator. 30% data terakhir tiap koin = data uji.
- **Hasil**: ⭐ setelan paling cocok, tabel tiap setelan (respect ≥ 2 / 3 / 4 / 5 ATR, gagal, skor, skor uji), grafik skor per
  periode (mode otomatis), hasil arah naik vs turun, contoh sinyal.
- **🖼️ Visual chart asli + animasi**: candle asli, garis MA, panel indikator (RSI / Stochastic %K-%D / MACD + histogram).
  Sesudah candle sentuh, candle berikutnya muncul bertahap, garis menunjukkan ke mana harga bergerak, target 2 / 3 / 4 / 5 ATR
  diberi ✓ saat tersentuh, lalu hasil ✅ / ❌. Tombol 🔁 Putar ulang, ◀ ▶, ▶ Buka di Manual Replay.
- **Progres** lengkap (persen, fase, waktu & sisa, jumlah sentuhan, koin terbaru, ⭐ sementara), **📂 Hasil tersimpan** otomatis.
- **🧪 Indikator Tester**: fitur **📈 EMA Tester dihapus** (permintaan pemilik); RSI / Stochastic / MACD / Kombinasi / Hyperopt tetap.
- File **CLAUDE.md** baru: aturan pemilik + checklist wajib menu baru (progres tidak polos, visual contoh chart asli, simpan,
  tidak macet di 99%, animasi chart).

### 🛡️ Menu baru SL Backtest: SL ATR 1–6 mana yang paling sering WIN per TF (sinyal Whale / Market Structure / TA Pro / Chart Pattern / Reversal) (v4.27)

- **Tab baru 🛡️ SL Backtest** (menu atas): mencari SL yang paling sering WIN untuk TF yang dipilih, dari sinyal riwayat data
  lokal banyak koin (maks 150 koin, beberapa koin dihitung bersamaan).
- **Sumber sinyal (pilih satu)**: 🐋 Whale · 🎯 Cari setup (logika candle: swing searah tren EMA20/EMA50, entry market &
  limit depan swing; tembok order book / flow tidak punya riwayat jadi tidak dipakai) · 📐 Market Structure · Scan banyak
  koin (HH→HL = LONG, LL→LH = SHORT, entry Penemu Strategi) · 🧠 TA Pro Advance (setup A–D) · 🧩 Chart Pattern Screener ·
  🔄 Find Reversal (fresh & terkonfirmasi). Entry & pengisian limit sama dengan menu asalnya.
- **Cara hitung**: SL default strategi diuji dulu (TP RR 1:2). Lalu tiap trade diuji dengan **SL = entry ∓ k × ATR(14)**,
  k = 1 · 1,5 · 2 · 2,5 · 3 · 3,5 · 4 · 4,5 · 5 · 5,5 · 6, **TP = entry ± 2k × ATR** (selalu RR 1:2).
  - **Kotak ATR**: trade masuk ATR terkecil yang SL-nya tidak tersentuh (harga lewat ATR 3 tapi belum ATR 4 → kotak ATR 4);
    ATR yang lebih lebar tidak dihitung. Harga lewat ATR 6 = **benar-benar LOSE**.
  - **Batas 5 hari** sejak entry tersentuh: sampai TP = WIN +2R. Waktu habis: pernah RR 1:1 = **TP1 +1R** · di area
    entry–TP = **+0,5R** · masih di area SL = **LOSE −1R**.
- **⭐ SL terbaik** = SL ATR yang paling banyak WIN kalau dipakai ke semua trade (+ WR, R/trade, WR di 30% data terakhir).
  Sebaran 📦 kotak ATR per trade ditampilkan di samping (selalu condong ke ATR kecil, karena trade yang langsung jalan selalu
  masuk kotak ATR 1, jadi bukan pemilih utama). Juga: SL default strategi sebagai pembanding, % trade lewat ATR 6, seberapa
  jauh harga melawan entry, dan kotak terbaik per jenis entry.
- **🔍 Contoh trade + 🖼️ visual** (candle asli): entry, SL default (kena / tidak), garis SL ATR 1…6, SL kotak trade itu,
  TP RR 1:2, titik harga paling jauh melawan entry, hasil. ◀ ▶ & ▶ Buka di Manual Replay.
- **Progres** lengkap (persen, fase, waktu berjalan & sisa, jumlah trade, koin terbaru, ⭐ SL terbaik sementara) — hasil tiap
  koin langsung diringkas (tidak macet di 99%). **📂 Hasil tersimpan** otomatis.

### 💧 Liquidity Sweep backtest: uji SL ATR 1–5, RR minimal 1:2, info ADX / RSI / kondisi market tiap trade (v4.26)

- **🛡️ Uji 10 pilihan SL sekaligus**: SL anti-gocekan (cara lama, maks 4%) + **SL ATR 1 · 1,5 · 2 · 2,5 · 3 · 3,5 · 4 · 4,5 · 5**.
  SL ATR diukur **dari harga entry**: BUY = entry − k × ATR(14), SELL = entry + k × ATR(14) (ATR TF sinyal di candle konfirmasi,
  tanpa batas 4%). Cara yang diuji jadi konfirmasi × entry × TP × SL (270 cara).
- **Tabel baru "🛡️ SL terbaik untuk TF ini"**: tiap pilihan SL → cara terbaiknya sendiri (trade, WR, R/trade, data cari, data uji,
  layak) + hasil cara juara ⭐ kalau SL-nya diganti. Baris SL juara ditandai ⭐.
- **RR minimal 1:2**: TP = RR 1:2 · RR 1:3 · likuiditas seberang (hanya dipakai kalau jaraknya ≥ 2× risiko).
- **Info tiap trade** (tabel 🔍 Contoh trade & gambar visual): pilihan SL, **ADX(14)** di candle sweep, **RSI(14) entry → hit**
  (candle terisi → candle kena TP/SL/waktu habis; ≥ 70 merah, ≤ 30 hijau), **kondisi market** TF sinyal: *trend* (ADX ≥ 20) /
  *sideway* (ADX < 20), condong *bullish/bearish* (close vs EMA50 & arah EMA50), dan **lamanya** kondisi itu (jam / hari).
- **Penyaring baru**: *Kondisi market* (trend searah / trend melawan / sideway condong searah / sideway condong melawan) dan
  *Lama kondisi market* (< 12 jam / 12–48 jam / > 2 hari) — ikut dinilai menaikkan / menurunkan & ikut kombinasi terbaik.
- **Perhitungan trade dipercepat** (hasil sama persis dengan cara lama, dicek tes otomatis) dan trade langsung diringkas tanpa
  ditumpuk di memori. Walau begitu simulasi 10× lebih banyak → backtest lebih lama dari v4.25. Hasil lama (v4.25) dihitung ulang.

### 💧 Liquidity Sweep backtest: tidak macet lagi di 99%, lebih cepat, progres lengkap, hasil tersimpan, visual contoh (v4.25)

- **Penyebab macet**: semua trade dari semua koin (bisa jutaan) disimpan dulu di memori lalu dianalisa sekaligus di akhir →
  dengan 150 koin habis memori / sangat lambat di 99%. Sekarang tiap koin langsung **diringkas** (jumlah sinyal, terisi, menang,
  total R per cara × kondisi penyaring) — memori kecil & analisa akhir hanya beberapa detik. Hasil angka sama persis.
- **Lebih cepat**: beberapa koin dihitung **bersamaan** (proses terpisah, jumlah = core CPU − 1, maks 8).
- **Progres lengkap**: bar persen, fase 1️⃣ cari sweep & uji trade (x/y koin) → 2️⃣ nilai penyaring, waktu berjalan & sisa,
  jumlah sweep ditemukan & candle dibaca, koin yang baru selesai (+ jumlah sweep-nya), dan **ringkasan sementara** (cara terbaik
  & penyaring yang sejauh ini menaikkan) yang diperbarui selama proses.
- **📂 Hasil tersimpan**: setiap backtest otomatis tersimpan; buka lagi tanpa menghitung ulang, beri nama ✏️, hapus 🗑️.
- **🖼️ Contoh visual**: gambar candle asli (data lokal) satu contoh trade — level likuiditas yang disapu, candle sweep, candle
  konfirmasi, area entry / SL / TP sampai trade selesai, dan hasil (✅ TP / ❌ SL / ⏱ waktu habis). Tombol ◀ ▶ untuk contoh lain,
  klik baris tabel 🔍 Contoh trade untuk menggambar contoh itu, ▶ Buka di Manual Replay.
- Riwayat koin maksimal 150 (isi lebih besar otomatis dibatasi 150).

### 🧠 TA Pro: sub-tab baru 💧 Liquidity Sweep backtest — penyaring mana yang benar-benar menaikkan hasil (v4.24)

- Menu 🧠 TA Pro Advance sekarang punya 2 sub-tab: **🧠 Analisa setup A–D** (lama, tidak berubah) dan **💧 Liquidity Sweep
  backtest** (baru). Menu lain tidak berubah.
- Backtest memakai **data candle lokal** banyak koin (pilih TF 5M–4H & jumlah koin). Pertama kali dihitung, lalu disimpan
  ke `saved/results/sweeplab/` (dihitung ulang kalau data candle / koin / pengaturan Whale berubah).
- **Likuiditas** (diketahui sebelum sweep & masih utuh): high/low hari kemarin, high/low sesi Asia (00–07 UTC), equal
  high/low (selisih ≤ 0,2 ATR), swing high/low terakhir, angka bulat. **Sweep** = ekor menembus ≥ 0,05 ATR lalu candle itu
  **close kembali di dalam** (close di luar = breakout, bukan sweep). Sweep low = calon BUY, sweep high = calon SELL.
- Diuji semua **cara**: 3 konfirmasi (close balik saja / CHoCH kecil / displacement) × 3 entry (market di close konfirmasi /
  limit 50% ekor / limit retest level) × 3 TP (RR 1:2 / 1:3 / likuiditas seberang). SL = yang terjauh dari ujung ekor ± 0,2 ATR
  dan SL anti-gocekan Whale; SL lebih jauh dari batas Whale (4%) dilewati. Batas waktu: TF < 1H = 24 jam, ≥ 1H = 2 hari;
  hasil memakai rumus Whale (belum kena TP = tidak menang).
- **Hasil**: ringkasan (cara terbaik, penyaring yang terbukti menaikkan / menurunkan, kombinasi terbaik), tabel **efek tiap
  penyaring** (tren 4H, tren 1D, tren 4H & 1D, sesi Asia / London / London–New York / New York / malam, volume candle sweep
  ≥ 1,5×, kedalaman ekor, jenis level) dibanding tanpa penyaring di data cari 70% & data uji 30%, perbandingan konfirmasi,
  semua cara, dan 🔍 contoh trade (klik = buka di Manual Replay dengan garis level, entry, SL, TP).
- **✅ menaikkan** = naik ≥ +0,05R per trade di data cari **dan** tetap lebih baik di data uji, sampel ≥ 30.
  Kombinasi terbaik: penyaring ditambah satu per satu (dipilih di data cari, dicek di data uji), maksimal 3.
- Hanya backtest (tidak memberi sinyal live & tidak mencatat ke jurnal).

### 📒 Jurnal: info tren yang dipakai sinyal + TF-nya (v4.23)

- Di 📒 Jurnal ada kolom baru **Tren** di sebelah kanan **Arah**, berisi label kecil: TF + **Bullish / Bearish / Sideway**, dan kalau
  searah posisi ditulis **"searah Bullish"** / **"searah Bearish"** (mis. "15M searah Bearish", "4H Bullish"). Hijau = Bullish,
  merah = Bearish, abu = Sideway. Arahkan mouse untuk melihat dasar trennya.
- Tren yang ditulis = **tren yang memang dipakai logika sumber sinyal itu** (tanpa permintaan Binance tambahan):
  - 🐋 Whale · Cari setup: EMA20 vs EMA50 di TF backtest setup (15M, atau 1H kalau SL ≥ 1.5%).
  - 📐 Market Structure (scan 1 koin / banyak koin) & 🧪 Cek entry: struktur swing TF besar (mis. 4H) — naik / turun / belum jelas.
  - 🧠 TA Pro Advance: TF besar gaya itu (4H+1D untuk Intraday, 1H untuk Scalping) — close vs EMA50 vs EMA200 & arah EMA50.
  - 🧩 Chart Pattern / 🔄 Reversal: EMA20 vs EMA50 di TF sinyal.
- Hanya **sinyal baru** (mulai v4.23) yang punya info ini; sinyal lama tidak bisa diisi karena kondisi saat itu tidak tersimpan.
  Logika sinyal tidak berubah.

### 📡 Scan tidak lagi "diam" kalau Binance membatasi / memblokir IP · status Binance di progres Whale (v4.22)

- **Penyebab scan terlihat tidak jalan**: kalau Binance membalas **HTTP 418** (IP diblokir sementara karena terlalu banyak
  permintaan) atau **429** (kena batas), aplikasi sebelumnya **diam menunggu** sesuai waktu blokir dari Binance (bisa
  menit–jam, diulang 4×) tanpa keterangan apa pun.
- Sekarang (client Binance, dipakai semua menu live):
  - **418 / blokir > 2 menit** → scan langsung berhenti dengan pesan jelas: "Binance memblokir IP kamu sementara … coba lagi
    sekitar jam HH:MM". Selama masa blokir, permintaan berikutnya **tidak dikirim** ke Binance (supaya blokir tidak diperpanjang).
  - **429** → semua scan yang sedang jalan **ikut berhenti sebentar** sesuai Retry-After (tidak menambah permintaan), lalu lanjut.
  - Jatah per menit hampir habis (> 2000/2400) → semua scan menunggu menit berikutnya.
  - Semua kejadian itu **ditulis di jendela server (run.bat)** dengan jam, mis. `[Binance] HTTP 429: …`.
- **🐋 Whale · progres scan**: baris status baru — ✅ "Binance OK · jatah dipakai X/2400", ⏳ "menunggu batas Binance … lanjut
  ±X dtk", ⛔ "IP diblokir sampai HH:MM", 📡 "koneksi gagal / lambat, mencoba ulang", dan ⚠️ peringatan kalau masih ada scan
  lain yang berjalan di belakang (berbagi jatah). Selama koin pertama dianalisa ditulis "bisa ±20–60 dtk".
- Logika scan, setup, dan hasil tidak berubah.

### 🎨 23 tema + tema kustom · 📊 Screener 3 sub-tab + tombol kembali · ikon menu atas · teks Jurnal (v4.21)

- **🎨 Tema**: tombol baru **🎨 Tema** di kanan atas (sebelah 📱 HP) membuka panel tema. 23 tema bawaan:
  Asli, Neon Cyber, Aurora Glass, Terminal Amber, Midnight Gold, Clean Light, **Cyberpunk**, **Artificial Intelligence**,
  Matrix Code, Synthwave, Ocean Deep, Ungu Malam, Nord Frost, Sakura, Hutan Malam, Solar Flare, Kontras Tinggi, Kertas Sepia,
  **Anime Pastel**, **Anime Malam**, **Hantu**, **Halloween**, **Galaxy**.
  - **Tiap tema punya efek & animasi sendiri (tidak ada yang kembar)**, bukan cuma warna: 23 efek latar berbeda (mis. Asli =
    chart candle berjalan, Cyberpunk = hujan neon, AI = jaringan saraf, Matrix = hujan kode, Hantu = hantu melayang + kabut,
    Halloween = kelelawar, Galaxy = nebula + meteor, Anime = kilau bintang, Anime Malam = bintang jatuh, Sakura = kelopak,
    Kertas = tetes tinta, Kontras Tinggi = garis detak harga, ...) + 23 animasi pindah menu berbeda (pecah RGB, piksel terurai,
    meluncur dari cakrawala, pintu berputar, jatuh memantul, tirai, lilin berkedip, muncul seperti hantu, lompat warp, ...)
    + animasi tombol (riak air, gelombang neon, kedip, kilau, memantul, percikan bintang). Kartu tema di panel menuliskan
    efek & animasinya.
  - **Tema kustom**: "+ Buat dari tema sekarang" → atur 13 warna, huruf teks & judul, efek latar, animasi menu & tombol, sudut,
    glow, panel kaca, terang/gelap → 💾 Simpan (bisa banyak, bisa diubah ✏️ / dihapus). 📋 Salin kode tema / tempel kode untuk
    berbagi tema.
  - Centang "Animasi menu & tombol" dan "Efek latar" bisa dimatikan (ringan untuk laptop lama); otomatis mati kalau Windows
    memakai "kurangi animasi". Pilihan tersimpan di browser ini.
  - Hanya tampilan: fitur, angka, dan logika tidak berubah. Chart Manual Replay & kartu visual sinyal tetap memakai warna
    chart gelap. Huruf tema diambil dari Google Fonts (tanpa internet = huruf bawaan Windows).

- **📊 Screener** sekarang punya 3 sub-tab terpisah: **📊 Screener filter & market structure** (fitur lama, tidak berubah) ·
  **🧩 Chart Pattern** · **🔄 Find Reversal**. Hanya sub-tab yang dipilih yang tampil, jadi fitur baru tidak lagi menumpuk /
  menutupi screener lama, dan tiap panel bisa di-scroll sendiri.
- Tiap sub-tab **menyimpan hasil scan-nya sendiri** (pindah sub-tab lalu kembali, hasil masih ada; scan tetap jalan di latar).
- Kartu sinyal punya baris navigasi: **← Kembali ke daftar** (tabel muncul lagi), **◀ Sebelumnya / Berikutnya ▶**.
- Pilihan "Fitur" di form dihapus (diganti sub-tab). Logika pola, backtest, entry / SL / TP tidak berubah.
- Tombol menu atas: semua diberi ikon (🎮 Manual Replay, 🤖 Auto Backtest, 🌀 Studi Fibonacci v2, 📊 Screener); urutan sama.
- 📒 Jurnal: teks centang pencatatan otomatis diperbarui (Market Structure · Cari setup Whale · TA Pro Advance · Chart
  Pattern / Reversal). Fungsinya tidak berubah.
- 🕘 History Update: alur kerja Screener ditambah fitur 🧩 Chart Pattern & 🔄 Find Reversal.

### 🧩 Screener: bar "Pengaturan akun & simulasi" tidak menutupi chart lagi (v4.20)

- Hanya menu **Screener**: bar "Pengaturan akun & simulasi" (dipakai Manual Replay / Auto Backtest, tidak dipakai Screener)
  disembunyikan saat tab Screener dibuka, jadi kartu visual Chart Pattern / Reversal tidak tertutup. Menu lain tidak berubah.

### 🧩 Screener: fitur baru Chart Pattern Screener & 🔄 Find Reversal (v4.19)

- Bagian baru di bawah menu **Screener** (filter & scan market structure yang lama tidak berubah). TF bisa dipilih (5M–1D),
  jumlah / daftar koin, swing fractal 3 / 5, "valid dalam N candle terakhir", tampilkan yang menunggu.
- **Pola** (dari swing, toleransi ATR): Head & Shoulders / Inverse, Double & Triple Top / Bottom, **Quasimodo** bearish /
  bullish, Rising / Falling Wedge, Ascending / Descending / Symmetrical Triangle, Rectangle, Bull / Bear Flag, Pennant,
  Channel, Cup & Handle.
- **✅ Valid** = ada candle yang **close** menembus garis pemicu (neckline, trendline, sisi datar, L/H untuk QM) sebelum pola
  batal / kadaluarsa — tidak ada intip masa depan (tembus sebelum pola diketahui tidak dipakai).
  **⏳ Menunggu** = pola sudah terbentuk tapi belum tembus: ditulis **kenapa menunggu**, **harga pemicu**, dan
  **entry\* / SL / TP** yang sudah dihitung (berlaku kalau nanti valid).
- **🔄 Find Reversal**: tren (puncak tertinggi baru + HL, atau kebalikannya) → **CHoCH** (close tembus HL / LH terakhir) →
  swing pertama arah baru terkonfirmasi = valid; fresh = dalam N candle terakhir. CHoCH tanpa konfirmasi = menunggu.
- **Entry**: market saat break, limit retest garis yang ditembus, QM: limit di **QML**; reversal: market saat terkonfirmasi
  atau limit retest level CHoCH. **SL anti-gocekan Whale** (live ikut tembok order book). **TP = measured move atau
  RR 1:2 / 1:3**, dipilih yang terbaik di backtest.
- **Batas waktu**: TF di bawah 1H = **24 jam**, TF 1H ke atas = **2 hari** (lama trade & umur limit).
- **Backtest** semua pola di data lokal banyak koin (TF sama, disimpan ke file `saved/results/cpat/`). Syarat layak
  **sama dengan Whale**: sampel ≥ 30 trade & rata-rata untung (WR × RR − kalah > 0); untung di 30% terakhir & limit tersentuh
  ≥ 70% = info.
- **Kartu visual** seperti menu lain: candle live + **trendline / neckline / QML, bentuk pola diarsir, label titik pola**,
  garis PEMICU untuk pola menunggu, kotak entry / SL / TP (📋 salin pakai koma) dan animasi prediksi harga.
- **🔍 Contoh trade**: 150 kejadian terbaru pola yang sama di riwayat; klik = buka di Manual Replay dengan titik pola & garis
  entry / SL / TP.
- **📒 Jurnal**: sinyal valid & layak dicatat otomatis (sumber baru "🧩 Chart Pattern / Reversal").
- Kartu visual bersama (`msacard.js`) mendapat lapisan opsional untuk garis pola — hanya dipakai fitur ini; tampilan
  menu lain tidak berubah.

### 🧠 TA Pro: 🔍 Contoh trade di kartu (v4.18)

- Hanya menu **🧠 TA Pro Advance**; logika, syarat & angka backtest tidak berubah.
- Di kartu tiap rencana ada bagian lipat **🔍 Contoh trade**: 150 kejadian terbaru (semua koin riwayat) untuk setup × arah ×
  entry yang dipilih — waktu (UTC), koin, entry, SL, TP1, TP2, terisi (berapa lama) / tidak terisi, hasil (SL, waktu habis,
  TP1 → TP2, TP1 → BE, TP1 → waktu habis) dengan R-nya, data cari / uji (30% terakhir), dan 🏓 mantul bersih.
- Ringkasan di judul: jumlah ✅ TP1, ❌ tidak kena TP1, dan tidak terisi.
- **Klik baris** = buka kejadian itu di Manual Replay dengan garis entry, SL, TP1 & TP2 (butuh data candle lokal koin itu).
- Entry depan tembok tidak punya contoh trade (tidak bisa diuji di riwayat setup) — ditulis di kartu.
- Backtest riwayat dihitung ulang sekali (cache lama belum berisi contoh trade).

### 🧠 TA Pro: syarat layak, entry, order book & batas waktu DISAMAKAN dengan 🐋 Whale › 🎯 Cari setup (v4.17)

- Hanya menu **🧠 TA Pro Advance**; menu Whale sendiri dan menu lain tidak berubah. Setup A–D, SL anti-gocekan,
  TP1 1:2 (ambil 50%) + TP2, sentimen & fundamental tidak berubah.
- **Hitung untung** = rumus Whale di TP1 1:2: **peluang TP1 × 2 − kalah** (belum kena TP1 sampai batas waktu = tidak menang).
  Hasil nyata TP1 50% + TP2 tetap ditampilkan sebagai info.
- **Syarat layak** = Whale: **sampel ≥ 30 trade** (bt.min_trades Whale) dan **rata-rata untung > 0**. Tidak ada WR minimal
  lagi (batas 40% dihapus, juga di keputusan live).
- **Untung di 30% terakhir** dan **entry tersentuh ≥ 70%** = **INFO** (ditulis di kartu, tidak menggagalkan).
- **Kandidat entry** = Whale: **market** (candle pemicu setup), **limit depan swing** terdekat (+0,15 ATR) dan — live saja —
  **limit depan tembok** whale terkuat (+0,1 ATR, tembok asli kalau terlihat ≥ 2 scan, jarak ≤ 3%). Limit lama per setup
  (Fib, retest, tepi band, 50% ekor) dihapus. Tembok tidak bisa diuji di riwayat setup (riwayat order book tidak ada), jadi
  dinilai **cara Whale**: backtest dari candle koin itu (jarak SL% & TP1% sama, tren EMA20 vs EMA50 sama seperti sekarang)
  + peluang tersentuh 24 jam. Semua angka dari ⚙️ Threshold Whale (entry.*).
- **Order book** = Whale: tembok dipakai untuk entry & SL; "tembok di jalur TP1" dan "antrean pelindung tipis" sekarang
  **info** (ℹ️), tidak dihitung ke TUNGGU. Peringatan sentimen & fundamental tetap dihitung.
- **Batas waktu** disamakan waktunya: trade maks **2 hari** (Intraday 192 candle 15M, Scalping 576 candle 5M), limit
  tersentuh dihitung dalam **24 jam** (96 / 288 candle). Jurnal ikut memakai batas ini.
- Backtest riwayat dihitung ulang otomatis sekali (cache lama tidak dipakai).
- Catatan jujur: syarat jadi selonggar Whale — sinyal ENTRY akan lebih sering muncul, termasuk yang belum terbukti di 30%
  terakhir atau jarang tersentuh (lihat info di kartu). Pantau hasilnya di 📒 Jurnal (tercatat per versi).

### 🧠 TA Pro: syarat layak lebih seimbang — WR TP1 ≥ 40%, R ≥ +0,05R, terisi tetap ≥ 70% (v4.16)

- Hanya menu **🧠 TA Pro Advance**; menu lain tidak berubah. Logika setup, entry, SL anti-gocekan, TP1/TP2 tidak berubah.
- Sebelumnya hampir selalu 0 ENTRY: semua setup punya peluang TP1 ±32–35% dan limit terisi ±43–55%, jadi tertolak syarat
  WR ≥ 50% walau R/trade-nya sedikit positif. Setup yang limitnya jarang terisi (< 70%) tetap ditolak.
- Syarat layak sekarang (semua wajib, di data cari 70% awal **dan** data uji 30% terakhir):
  - peluang TP1 (1:2) kena duluan **≥ 40%** (sebelumnya 50%);
  - hasil rata-rata **≥ +0,05R per trade** (sebelumnya cukup > 0) — untung nyata, bukan nyaris impas;
  - entry limit terisi **≥ 70%** (tetap, sama seperti sebelumnya); data uji minimal 10 trade (sama).
- Keputusan live: JANGAN kalau peluang TP1 sinyal < 40% (sebelumnya < 50%); TUNGGU / veto lain sama.
- Backtest riwayat dihitung ulang otomatis sekali (cache lama tidak dipakai karena syarat berubah).
- Catatan jujur: WR 40% = ±6 dari 10 trade kena SL duluan; untung datang dari TP1 + sisa yang sampai TP2. Kalah beruntun
  lebih sering — cek kolom kalah beruntun & pantau di 📒 Jurnal.

### 🛡️ SL anti-gocekan (logika Whale) di 📐 Market Structure & 🧠 TA Pro · 🐋 "setup bagus" = rata-rata untung (v4.15)

- **🐋 Whale · 🎯 Cari setup** — "kapan setup dianggap bagus" dikembalikan seperti **v3.45**: cukup **rata-rata untung**
  (WR × RR − kalah > 0). Uji 30% data terakhir, peluang entry tersentuh, dan flow whale sekarang **INFO saja** (ditulis di
  kesimpulan kartu, tidak menggagalkan setup). Akibatnya jurnal Whale akan mencatat **lebih banyak** sinyal. Logika lain
  (entry, SL anti-gocekan, TP, skor) tidak berubah.
- **SL anti-gocekan** (sama dengan menu Whale, angka dari ⚙️ Threshold Whale) **menggantikan SEMUA pilihan SL lama** di:
  📐 Market Structure (🔎 Scan 1 koin, 🔎 Scan banyak koin, 🧪 Cek entry posisi, 🧠 Penemu Strategi) dan 🧠 TA Pro Advance.
  - Cara hitung: swing terdekat (fractal 3, dalam 200 candle) di balik entry ∓ (kedalaman 90% gocekan + 0.1) × ATR;
    lewati angka bulat; tanpa swing = 1.5 ATR H1 (≈ 3 ATR); maksimal **4%** dari entry (mode potong / tolak ikut Whale).
  - **Backtest riwayat** = tanpa tembok order book (riwayat order book tidak ada) dan tanpa intip masa depan (gocekan baru
    dihitung setelah selesai, swing setelah terkonfirmasi). **Sinyal sekarang** = ikut **tembok order book live** seperti Whale
    (kalau Binance tidak bisa dibaca: tanpa tembok, ditulis di alasan SL).
  - Bedanya dengan Whale: Whale selalu membaca candle 15M; di sini memakai TF menu itu (jumlah candle sama). SL dihitung
    dari **harga entry** (limit maupun market), jadi SL selalu di balik entry.
  - Market Structure / Penemu Strategi: kolom SL sekarang hanya satu ("anti-gocekan"); pilihan lama "di balik swing terakhir"
    / "titik terjauh pola" tidak dipakai lagi. Hasil Penemu Strategi tersimpan versi lama tetap bisa dibuka.
  - 🧪 Cek entry posisi: saran SL = SL anti-gocekan (dengan angka backtest-nya), **selalu ditampilkan** sebagai pembanding —
    kalau di riwayat tidak lebih baik dari SL kamu, ditulis jelas. Geseran entry / TP tetap seperti sebelumnya.
  - 🧠 TA Pro: backtest riwayat dihitung ulang otomatis (cache lama tidak dipakai karena SL berubah); kartu menulis alasan SL.
  - Angka backtest MS & TA Pro **berubah** karena SL berubah — sinyal lama di jurnal tetap tercatat versinya (v4.14 / lama).

### 🧠 TA Pro: hasil langsung tampil, progres lengkap, scan lebih cepat · 🐋 flow = info saja (v4.14)

- **🧠 TA Pro Advance** (logika & hasil analisa tidak berubah):
  - **Setup langsung tampil** selama scan: tiap koin yang selesai langsung masuk tabel dan kartunya bisa dibuka tanpa
    menunggu scan selesai (kartu yang sedang dibuka tidak diulang animasinya saat tabel bertambah).
  - **Panel progres lengkap**: bar persen, fase 1️⃣ backtest riwayat (x/y koin lokal) → 2️⃣ scan live (x/y koin), waktu
    berjalan & perkiraan sisa, jumlah ✅ ENTRY / ⏳ TUNGGU / ❌ JANGAN sementara, koin yang baru diproses, tips.
  - **Lebih cepat**:
    - pencarian setup B/C/D memeriksa semua candle sekaligus (15–20× lebih cepat, kejadian yang ditemukan dicek sama persis);
    - hasil backtest riwayat **disimpan ke file** (`saved/results/tapro/`): scan berikutnya, juga sesudah aplikasi dibuka
      ulang, langsung memakainya — dihitung ulang hanya kalau data candle / gaya / koin riwayat berubah;
    - pemeriksa live (sentimen, order book, fundamental) dilewati untuk setup yang backtest-nya tidak lolos (pasti JANGAN);
    - fase live membaca **6 koin sekaligus** (tetap di bawah batas permintaan Binance; klien otomatis menunggu kalau mendekati batas).
- **🐋 Whale · 🎯 Cari setup**: **flow whale (OI, taker, long/short, funding) hanya INFO, tidak menyaring**. Di kode flow memang
  tidak pernah mengubah status layak; yang diubah teksnya: kotak uji gabungan menulis "flow hanya info", dan kesimpulan
  kartu tetap ✅ sesuai 3 syarat layak (kalau flow melawan, ditulis sebagai info).

### 🧠 Menu baru: Teknikal Analisis Pro Advance (v4.13)

- **Menu baru** di atas (sebelah 🐋 Whale). Menu lain tidak berubah (Jurnal hanya mendapat sumber baru "🧠 TA Pro Advance").
- **Logika baru** (tidak memakai logika Whale maupun Market Structure):
  - **Setup price action** dengan aturan pasti: **A** pullback ke zona confluence (tren TF besar + Fib OTE 0.618–0.786 + minimal
    1 confluence lain: EMA 50 / S-R flip), **B** sweep likuiditas (low/high hari sebelumnya atau equal low/high, close balik ke
    dalam), **C** breakout–retest (volume ≥ 1.5× rata-rata, searah tren), **D** squeeze → ekspansi (Bollinger paling sempit,
    close keluar band searah tren, ADX naik).
  - **Mode entry seperti Whale**: MARKET dan beberapa LIMIT dicoba; dipakai yang lolos syarat → paling sering 🏓 mantul bersih →
    R/sinyal terbaik. Kalau entry terbaik sudah tidak berlaku (limit sudah tersentuh / harga lari), dipakai cara berikutnya.
  - **SL** di luar struktur + buffer ATR. **TP1 = 1:2** (ambil 50%, SL pindah ke entry). **TP2 minimal 1:3**, dipilih dari
    1:3 / 1:4 / 1:5 / 1:6 / 1:8 yang memberi hasil terbaik di data cari (peluang tiap TP2 tercapai ditampilkan).
  - **Backtest** semua kejadian di data lokal banyak koin (Riwayat backtest, default 30 koin): 70% data awal cari, 30% terakhir uji.
    Lolos hanya kalau peluang TP1 ≥ 50% di data cari **dan** uji, untung di keduanya, limit terisi ≥ 70%, data uji ≥ 10 trade.
  - **Model peluang TP1** (regresi logistik: ADX, kemiringan tren, volume, RSI, tren BTC, Fear & Greed). Bobot faktor dipelajari
    di data cari; dipakai hanya kalau terbukti di data uji, kalau tidak dipakai rata-rata setup.
  - **Pemeriksa live** (tidak bisa di-backtest): sentimen (funding, Open Interest 24 jam, long/short top trader, Fear & Greed),
    order book (tembok di jalur TP1, antrean pelindung entry–SL), fundamental CoinGecko (market cap, FDV ÷ market cap,
    volume ÷ market cap). Tiap peringatan −8 skor; market cap < 15 jt USD = veto.
  - **Keputusan**: ✅ ENTRY / ⏳ TUNGGU / ❌ JANGAN + kelas A/B/C + alasan.
- **Gaya**: Intraday (entry 15M, tren 4H + D1) atau Scalping (entry 5M, tren 1H). **Mode**: 1 koin atau banyak koin.
- **Tampilan**: tabel dengan **📋 salin harga (koma)** untuk Entry, SL, TP1, TP2; **kartu visual + animasi prediksi** price action;
  panel 4 pilar; cara entry lain yang diuji; tabel hasil backtest semua setup.
- Sinyal **ENTRY** dicatat otomatis di 📒 Jurnal (TP1 dipantau, TP2 di catatan) beserta versi aplikasi.
- Butuh internet: Binance (candle live, sentimen, order book), CoinGecko (fundamental), alternative.me (Fear & Greed).
  Yang tidak bisa diakses ditandai "tidak tersedia" dan tidak dihitung. Scan pertama menghitung backtest (±1–4 menit), lalu di-cache.
- Jujur: logika ini baru, angka bagusnya baru terbukti di 📒 Jurnal setelah dipakai live.

### 📒 Jurnal: perkiraan versi untuk sinyal lama (v4.12)

- **Hanya menu 📒 Jurnal** yang berubah.
- Sinyal baru tetap dicatat dengan versi pastinya saat scan (sejak v4.11), mis. **v4.12**.
- Sinyal **lama** (dicatat sebelum v4.11, belum ada catatan versi) sekarang diberi perkiraan **"≤ vX (perkiraan)"** =
  versi PALING BARU yang mungkin dipakai saat itu, yaitu versi terakhir yang sudah dirilis (waktu zip-nya dikirim, dari data
  🕘 History Update) saat candle sinyal close. Versi yang dipakai bisa juga lebih lama, karena itu ditulis "≤". Perkiraan ini
  hanya untuk tampilan dan tidak disimpan ke file jurnal.
- Pilihan **Versi** di jurnal sekarang berisi: versi pasti (v4.11, v4.12, …), kelompok sinyal lama per perkiraan
  (mis. "≤ v4.06 (perkiraan, versi lama)"), dan "semua versi lama (sebelum v4.11)". Kartu ringkasan ikut pilihan itu.

### 📒 Jurnal per versi aplikasi (v4.11)

- **Hanya menu 📒 Jurnal** yang berubah (scan & sinyal di menu lain tidak berubah; sinyal hanya ditambah catatan versi).
- Setiap sinyal baru (otomatis dari 🔎 Scan banyak koin & 🎯 Cari setup Whale, atau entry kamu dari Cek entry posisi) sekarang
  dicatat bersama **nomor versi aplikasi** yang membuatnya. Kolom **Versi** ada di tabel sinyal.
- Pilihan **Versi** di atas jurnal: *Semua versi*, *v4.11*, …, atau *versi lama (sebelum v4.11)* = sinyal yang tercatat sebelum
  ada catatan versi. Semua kartu ringkasan (sinyal, terisi, WR, menang/kalah, R per sinyal, total, kalah beruntun) ikut dihitung
  hanya dari versi yang dipilih, jadi hasil live antar versi bisa dibandingkan langsung.
- Sinyal lama tidak dihapus dan tidak diubah; semuanya masuk kelompok "versi lama".

### 🔎 Scan banyak koin: definisi "mantul bersih" + 🔬 pilihan entry dievaluasi (v4.10)

- **Hanya fitur 🔎 Scan banyak koin** (Market Structure) yang berubah. Scan 1 koin, Cek entry posisi & menu lain tidak
  berubah (sudah dicek: hasil scan 1 koin sama persis dengan v4.09).
- **🏓 Mantul bersih** (menggantikan definisi "mantul" v4.07), dihitung di riwayat untuk setiap entry yang terisi:
  1. candle yang menyentuh entry hanya kena **ekor**: close-nya kembali di sisi untung (entry market: syarat ini tidak berlaku);
  2. sebelum harga bergerak **+1R**, tidak ada satu candle pun yang **close di area antara entry dan SL**;
  3. +1R tercapai dalam **12 candle**.
  Kalau ada close di area entry–SL (atau candle sentuh close di sana) = **⏳ main dulu** (jelek), walaupun akhirnya ke arah TP.
  Kolom tabel: **🏓 Mantul bersih** dan **⏳ Main dulu**. Dari setup yang layak, entry sinyal dipilih yang paling sering mantul bersih.
- **🔬 Entry dievaluasi** (otomatis saat scan, di baris bawah tiap sinyal): entry sinyal digeser −20% … +60% risiko
  (+ = ke arah SL, − = menjauhi SL; SL tetap, TP dihitung ulang dengan RR yang sama), diuji di SEMUA kejadian pola yang sama
  di riwayat, lalu dipilih yang paling sering mantul bersih dengan syarat tetap terisi ≥ 70%, untung, untung di 30% data
  terakhir, dan WR ≥ 50%. Ditampilkan: entry / SL / TP (📋), terisi, mantul bersih, main dulu, WR, R/sinyal, data uji.
- **Kamu yang memilih**: pilihan **Sinyal** / **🔬 Dievaluasi** di tiap baris. Kartu visual (klik baris) ikut pilihanmu; untuk
  entry dievaluasi animasi prediksi tidak ditampilkan (animasinya dibuat dari entry sinyal). Kalau entry sinyal sudah yang
  terbaik atau tidak ada geseran yang lolos syarat, ditulis begitu.
- Sinyal yang dicatat otomatis ke 📒 Jurnal tetap entry **sinyal**.

### 🕘 Bandingkan versi berdampingan (v4.09)

- **Hanya menu 🕘 History Update › ⚖️ Bandingkan versi** yang berubah.
- Versi A (kiri) dan Versi B (kanan) sekarang tampil **berdampingan**, masing-masing dengan pilihan versi dan **scroll sendiri**,
  jadi tidak perlu scroll ke bawah untuk melihat versi pembanding. Isinya lengkap seperti di Riwayat versi (permintaan,
  catatan rilis, catatan README, 🔧 perubahan kode).
- Di atas kolom: jumlah versi perubahan di antara A dan B, menu yang paling sering diubah, dan tombol **versi di antaranya**
  (klik = tampilkan versi itu di kolom kanan). Filter menu tetap ada.
- Di layar sempit (HP) kedua kolom otomatis bertumpuk atas-bawah.

### 🕘 History Update lebih lengkap: perubahan kode tiap versi + label menu yang akurat (v4.08)

- **Hanya menu 🕘 History Update** yang berubah (menu lain tidak disentuh).
- Tiap versi sekarang berisi: obrolan / permintaanmu, catatan rilis asli, **📖 catatan README versi itu**, dan
  **🔧 perubahan kode** yang dibaca langsung dari zip versi sebelumnya → versi itu:
  - tabel **menu › fitur yang kodenya berubah** (+ jumlah baris),
  - jumlah tes otomatis (+/− dari versi sebelumnya), endpoint API baru / dihapus,
  - daftar file yang berubah, fungsi baru, fungsi dihapus.
- **Label menu** tiap versi (v2.8 ke atas) sekarang diambil dari bagian KODE yang berubah, bukan ditebak dari teks.
  v1.1–v2.7 (zip-nya sudah tidak ada) tetap dari isi catatan.
- **🧭 Alur kerja tiap menu** disusun ulang persis mengikuti tab & sub-tab di aplikasi (mis. Indikator Tester: EMA Tester,
  RSI, Stochastic, MACD, Kombinasi, Hyperopt; Tes SNR: pilihan Dorongan % / ADX / ADX + arah Force Index; Whale: pelacak,
  Cek entry kamu, Perekam order book, Flow whale, Cari setup terbaik).
- Versi yang pesan rilisnya tidak tersimpan (v3.56, v3.97) diisi dari README / pesan terakhir sebelum zip-nya dikirim.

### 🕘 Menu History Update · 📒 Jurnal menang/kalah · 🏓 Scan banyak koin pilih entry yang sering mantul (v4.07)

- **🕘 History Update** (menu baru di atas, sebelah 📚 Info Trading):
  - **📜 Riwayat versi**: semua versi dari v1.1 sampai sekarang (terbaru di atas). Tiap versi berisi permintaanmu waktu itu
    + catatan rilis asli yang dikirim bersama zip-nya. Bisa difilter per menu dan dicari kata.
  - **⚖️ Bandingkan versi**: pilih versi A dan B → semua perubahan di antaranya (bisa difilter per menu), plus menu yang paling
    sering diubah. Cocok untuk melihat apa saja yang beda antara mis. v4.03 dan v4.04.
  - **🧭 Alur kerja tiap menu**: langkah demi langkah tiap menu & fitur (apa yang diisi, apa yang dihitung, cara membaca hasil).
- **📒 Jurnal** (hanya menu ini): kartu WR live sekarang menampilkan **✅ jumlah menang (TP) · ❌ jumlah kalah (SL)** dan
  ⏱ waktu habis (kalau ada).
- **🔎 Scan banyak koin** (Market Structure; hanya fitur ini): dari setup yang ✅ layak, dipilih entry yang di riwayat paling
  sering **langsung mantul** 🏓 = sesudah entry tersentuh, harga bergerak searah ≥ 0.5× risiko dalam 6 candle **sebelum**
  menembus melawan ≥ 0.5× risiko (candle yang sama naik & turun dihitung tidak mantul). Kolom baru **🏓 Mantul** di tabel.
  Syarat layak tidak bertambah, jadi jumlah sinyal tidak berkurang; yang berubah hanya pilihan entry-nya.

### 📚 Info Trading: 17 topik indikator, pola & alat + 📋 salin angka pakai koma (v4.06)

**📚 Info Trading** (hanya menu ini, materi lama tidak berubah). Topik sekarang dikelompokkan: *Price Action & SMC* (12 topik
lama), *Indikator*, dan *Pola & alat*. Semua contoh baru juga dicari otomatis dari **candle asli** Binance dan diputar candle per
candle (20 bar/detik). Indikatornya ikut "terbentuk" bersama candle: garis di atas harga (MA, Bollinger, VWAP) dan **panel
indikator di bawah chart** (RSI, Stochastic, MACD, ADX, ATR, Volume, Force Index, kemiringan tren).

| Kelompok | Topik (contoh) |
|---|---|
| Indikator | RSI Divergence (bullish & bearish) · Stochastic (cross di bawah 20 & jebakan oversold) · Semua tipe Moving Average (SMA, EMA, WMA, HMA, SMMA/RMA, VWMA, DEMA, TEMA + golden cross) · Force Index · MACD (bullish & bearish cross) · ADX · ATR · Cara baca Volume (breakout bervolume vs sepi) · Bollinger Band (squeeze & mean reversion) · VWAP (mantul & ditolak) |
| Pola & alat | Chart Pattern (double bottom, double top, head & shoulders, bull flag) · Candlestick Pattern (bullish/bearish engulfing, hammer, morning star) · Swing minimal 1–5 ATR (chart sama, 5 tab) · Fibonacci Tools (semua level + extension) · Fib Extension berbasis tren (A-B-C) · Trendline & SNR dinamis (3 sentuhan, EMA 20) · Kemiringan tren & tanda reversal |

- Aturan pencarian tiap contoh ada di `tools/edu_ind.py` (rumus indikator juga di sana, tanpa look-ahead).
- Perbarui materi: `python tools/edu_build.py --download` (atau folder candle JSON sendiri).

**📋 Salin angka pakai koma** di menu **🐋 Whale** (Cari setup terbaik: tabel, kartu visual, rencana entry, anti gocekan,
saran Cek entry), **📐 Market Structure** (scan 1 koin, scan banyak koin, saran Cek entry posisi) dan **Screener** (kartu live):
- Ikon 📋 kecil di sebelah angka Entry / SL / TP. Klik → angka tersalin dengan **koma** (contoh `1.8178` → `1,8178`), siap di-paste
  ke kolom harga Binance satu per satu. Tidak ikut di gambar unduhan.
- Tombol "📋 Salin sinyal" yang lama tidak diubah.

### 🔎 Scan banyak koin: swing kecil tidak dihitung (v4.05)

- **Hanya fitur "Scan banyak koin"** yang berubah. Screen 1 koin, 🧪 Cek entry, Penemu Strategi dan menu lain tetap.
- Sebelumnya swing = fractal saja (titik tertinggi/terendah di antara N candle) tanpa syarat ukuran, jadi goyangan kecil di
  TF kecil ikut dilabeli LH/HL/HH/LL.
- Sekarang ada pilihan **Swing minimal** (default **1 ATR**): swing baru dihitung kalau jaraknya dari swing sebelumnya minimal
  sekian kali ATR. Pilihan: semua (tanpa batas) / 0.5 / 1 / 1.5 / 2 ATR. Berlaku untuk struktur sekarang **dan** pencarian
  pola yang sama di riwayat, jadi contoh kejadian juga hanya berisi swing yang cukup besar.
- Angka terbaik belum di-backtest (data riwayat ada di PC kamu): bandingkan 0.5 / 1 / 1.5 / 2 ATR dengan scan yang sama.

### 🔎 Scan banyak koin (Screener Market Structure): hanya setup yang lebih sering MENANG (v4.04)

- **Hanya fitur "Scan banyak koin"** yang berubah. Screen 1 koin, 🧪 Cek entry dan menu lain tetap seperti v4.03.
- RR yang dicoba di scan banyak koin: **1:2, 1:3, 1:4, 1:5** (sebelumnya 1:3–1:5).
- Setup baru **✅ layak** kalau **lebih sering menang daripada kalah: WR ≥ 50%** di data cari **dan** di 30% data terakhir
  (data uji), selain syarat lama (berlaku, terisi ≥ 70%, untung & terbukti). Yang di bawah itu masuk daftar "jangan entry dulu"
  dengan alasan "lebih sering kalah (WR xx%)".
- Sebelumnya yang dipilih = total untung terbesar di riwayat, yang sering berarti RR besar dengan WR 8–27% (lebih sering kena SL).
- Konsekuensi: sinyal bisa lebih sedikit; kalau tidak ada yang lolos, artinya jangan entry dulu.

### 📚 Info Trading: label tidak bertumpuk & candle lebih besar (v4.03)

- Tulisan di chart (EQL, SSL, BOS, Swing High, dll.) **tidak saling menumpuk** lagi: kalau bertabrakan, label otomatis digeser
  ke tempat kosong terdekat, dan tiap tulisan diberi bayangan gelap supaya tetap terbaca di atas candle/garis.
- Contoh dipilih yang **candle-nya cukup besar di layar** (tinggi candle rata-rata ≥ 6% tinggi chart). Contoh Market Structure
  diganti (ETHUSDT 15m) karena contoh lama tertekan oleh crash besar sesudahnya sehingga candle tampak kecil & numpuk.

### 📚 Info Trading jadi tab sendiri (v4.02)

- **📚 Info Trading** pindah dari dalam Auto Backtest menjadi tab sendiri di menu atas, sebelah **📒 Jurnal**.
  Isinya sama (12 topik animasi + 📖 kamus 50 istilah).
- Bar **Pengaturan akun & simulasi** disembunyikan di tab ini supaya tidak menutupi chart
  (bar itu tetap muncul di Manual Replay / Auto Backtest). Halaman Info Trading bisa di-scroll sendiri.

### 📖 Kamus 50 istilah + 5 topik baru di 📚 Info Trading (v4.01)

- **📖 Kamus 50 istilah** Price Action + SMC/ICT (tombol kuning paling kiri). Isinya definisi singkat, kolom cari, dan
  **▶ lihat animasi** di **setiap** istilah. Tombol itu membuka animasi candle asli tepat di langkah yang menunjukkan
  istilah tersebut, dan istilahnya diberi label di chart.
- **Topik baru** (semua dari candle asli Binance, dicari otomatis):
  - 🎭 **Fakeout & BSL**: EQH, buy-side liquidity, distribusi, fakeout di resistance, MSS turun.
  - 📦 **Range & Expansion**: range/konsolidasi, EQH-EQL, dealing range + EQ 50%, compression, breakout +
    displacement, expansion. Dua contoh: akumulasi (naik) & distribusi (turun).
  - 🟩 **Supply & Demand**: drop-base-rally (demand) & rally-base-drop (supply).
  - 🔻 **Breaker & Mitigation**: OB yang gagal (sesudah sapu high = breaker, tanpa high baru = mitigation) lalu jadi
    resistance.
  - ⚖️ **Premium, Discount & OTE**: dealing range, premium/discount (PDA), OTE 0.62–0.79.
  - 🟦 Order Block mendapat contoh kedua: **Inducement (IDM) → POI**.
- **Topik lama ditambah label**:
  - Sweep: EQL, SSL, stop hunt, rejection block.
  - Market Structure: swing high/low, tren, LH/LL, reversal.
  - Order Block: POI, displacement, mean threshold 50%.
  - FVG: imbalance, CE 50%.
  - Fibonacci: pullback/retracement.
  - S/R Flip: support, resistance, breakout, retest.
- Contoh yang sama tidak dipakai dua kali. Contoh dengan candle ekstrem (yang membuat chart tergencet) dilewati.

### 📚 Info Trading di menu Auto Backtest (v4.00)

Menu baru **📚 Info Trading** (sejak v4.02 tab sendiri di menu atas, sebelah 📒 Jurnal). Materi edukasi beranimasi dengan **candle ASLI
Binance Futures**, diputar candle per candle (**20 bar/detik**, bisa 10 / 40). Candle penting diperlambat dan animasi
berhenti sejenak di momen kunci. Penjelasan tampil di bawah chart, dan panel **Langkah-langkah** di kanan ikut menyala
(klik langkah untuk loncat). Ada juga ⏮ ▶ ⏭, penggeser waktu, dan tag harga di sumbu kanan.

Topik:
1. **💧 Liquidity Sweep**: equal lows → ekor menembus → close balik → MSS → TP. Dibandingkan dengan **breakdown asli**
   (close di bawah, retest gagal).
2. **🧱 Market Structure**: HH / HL, **BOS** (tren lanjut), **CHoCH** (tren berubah).
3. **🟦 Order Block**: candle turun terakhir sebelum dorongan kuat yang menembus high → harga kembali ke zona → mantul.
4. **🩷 Fair Value Gap**: celah 3 candle → diisi → mantul.
5. **🔁 Support / Resistance Flip**: resistance ditembus close → retest dari atas bertahan → lanjut.
6. **📐 Fibonacci Retracement**: dorongan → koreksi ke zona 0.5–0.786 → tembus high dorongan.
7. **🌊 Elliott Wave**: impuls 1-2-3-4-5 (aturan baku) + koreksi A-B-C.

Contohnya **dicari otomatis** dari data asli dengan aturan tertulis di `tools/edu_build.py` (bukan digambar tangan).
Materinya ada di `frontend/edu_data.json`. Untuk memperbarui dengan data terbaru: `python tools/edu_build.py --download`
(butuh internet; kalau Binance diblokir, nyalakan VPN). Ini contoh sejarah untuk belajar, bukan sinyal.

### 🌐 Petunjuk VPN di README & pesan error (v3.99)

- README: kotak **"Scan / analisa tidak jalan? Nyalakan VPN"** di bagian **Langkah 5 — Jalankan**, berlaku untuk semua
  menu yang memakai data live Binance. Tabel masalah juga diperbarui.
- Pesan error koneksi Binance (HTTP 451 / 403 atau tidak bisa terhubung) di **semua menu** sekarang langsung
  menyarankan: nyalakan VPN (atau ganti DNS ke 1.1.1.1), lalu coba lagi.

### 🌊 Elliott Wave + 🏅 kelas A/B/C + 🎬 animasi price action (v3.98)

Dipasang di semua fitur yang memberi entry / SL / TP: **🐋 Whale · 🎯 Cari setup**, **🐋 Whale · 🧪 Cek entry kamu**,
**🔎 Screener Market Structure** (termasuk scan banyak koin) dan **🧪 Cek entry posisi**.

- **🌊 Elliott Wave otomatis** (aturan baku, tidak dicari-cari angkanya per koin): swing ≥ 2 ATR dibaca tanpa intip masa
  depan, lalu ditentukan posisi sekarang. Contohnya: impuls 1-2-3-4-5 ("gel. 4 koreksi 38% → tunggu gel. 5 naik"),
  koreksi ABC zigzag / flat ("gel. C berjalan"), "ABC selesai → arah baru", atau segitiga.
  - Aturan yang dipakai: gel. 2 tidak melewati awal gel. 1, gel. 3 melewati puncak gel. 1 & bukan yang terpendek,
    gel. 4 tidak masuk wilayah gel. 1.
  - Dibaca di TF entry dan TF derajat lebih besar (5M/15M → 1H, 1H → 4H, 4H → 1D). D1 dipakai sebagai arah tren besar.
  - Kalau ada 2 hitungan yang sama-sama sah dan arahnya bertentangan, ditulis **"hitungan belum jelas"** (tidak dipakai).
  - Target rasio Fibonacci umum (mis. gel. 3 = 1.618 × gel. 1) ditampilkan hanya kalau belum terlewati.
- **🏅 Kelas A / B / C**: setiap setup **tetap tampil** (bukti tidak menyaring sinyal), tapi diberi kelas dari 6 bukti:
  Elliott TF entry, Elliott TF besar, tren D1, **arah BTC**, **kekuatan relatif vs BTC**, **sapuan likuiditas** (stop hunt),
  ditambah sesi Asia / London / New York.
  - **BTC dihitung hanya kalau koin itu sedang bergerak bersama BTC** (korelasi ≥ 0.5, 96 candle). Kalau koinnya
    jalan sendiri, BTC diabaikan. Koin yang naik saat BTC turun justru dihitung kuat (+).
  - Bobot tiap bukti dipelajari dari **70% trade awal** (WR saat searah − WR saat melawan; bobot 0 kalau beda < 3 poin
    atau sampel < 30). Di Cari setup dan Market Structure, data semua koin digabung, supaya tidak pas-pasan dengan 1 koin.
  - **WR tiap kelas dinilai di 30% trade terakhir** dan ditampilkan (mis. "A 64% · B 55% · C 41%").
    "✓" berarti kelas A memang lebih baik dari C di data uji. "⚠ belum terbukti" berarti belum.
  - Di kartu: baris 🌊 Elliott, baris 🏅 kelas, dan ✓ / ✗ per bukti. Di tabel Cari setup dan scan banyak koin ada kolom 🏅 Kelas.
- **🎬 Animasi price action**: jalur animasi tidak lagi lurus. Harga bergerak bertahap: ke entry (limit) → mantul di
  **SNR minor** di jalur (swing high/low terakhir + tembok whale) → koreksi normal tiap ±3 ATR kalau tidak ada SNR → TP / SL.
  - Dalam mantul = median balikan leg koin itu sendiri.
  - Hasil akhir = yang **paling sering** di backtest / riwayat (TP kalau WR ≥ 50%, di Cek entry posisi: TP vs SL mana
    yang lebih sering), lamanya = median riwayat.
  - Mantul tidak pernah menyentuh SL / TP sebelum waktunya. Titik mantul diberi label di chart.
  - Ini **ilustrasi bentuk gerak**. Yang diuji tetap arah, TP / SL, WR dan waktu.
- **🐋 Whale · Cari setup** sekarang juga punya animasi sampai kena TP / SL, plus pita 25–75% gerak harga semua trade backtest-nya.

### 🔬 Struktur candle di Manual Replay — isi candle dilihat di TF kecil (v3.97)

- **Klik kanan candle mana saja** di chart replay (HP: tekan lama), di TF apa pun:
  - **🔬 Lihat isi candle ini**: popup beranimasi. Candle TF kecil muncul satu per satu sementara candle besar ikut
    "terbentuk" di kiri. High / low sejauh ini ikut bergerak (▲ high baru / ▼ low baru). Di akhir: ① ② = urutan
    high & low beserta jamnya, jenis candle (doji, marubozu, sumbu panjang), persen sumbu atas / badan / sumbu bawah.
    Sesi Asia / London / New York diberi warna. Tombol ⏮ ▶ ⏸, geser waktu, kecepatan 0.5× – 4×, ⬇ Gambar (PNG).
  - **➕ Tambah ke perbandingan**: pilih candle bebas (mis. beberapa doji), maksimal 12. Candle pilihan diberi kotak
    kuning bernomor; **🖼 Bandingkan isinya** memutar semuanya berdampingan secara serempak.
  - **↔ Pilih rentang**: klik kanan candle awal, lalu klik kanan candle akhir. Beberapa candle dilihat sekaligus
    (garis biru putus-putus = batas tiap candle).
  - **📅 Lihat 1 minggu (W → D1)** dari chart 4H–1D: minggu Senin–Minggu (UTC, seperti Binance).
  - **📉 Buka di TF kecil + garis**: chart pindah ke TF kecil, candle di luar candle besar dibuat pudar, garis batas
    awal / akhir, garis open / high / low / close candle besar, dan ① ② di titik high / low.
- TF kecil bisa dipilih (paling kecil = data dasar koin, mis. 5M; maksimal 2.000 candle kecil per candle besar).
- Jujur: hanya data sampai waktu replay sekarang. Candle yang masih terbentuk ditandai "masih terbentuk".

### 🧱 Penyusun aturan di Auto Backtest — strategi tanpa coding (v3.96)

Di menu **Auto Backtest**, klik **🧱 Penyusun aturan (buat strategi tanpa coding)**:
1. Isi nama, **TF strategi**, arah (LONG & SHORT / LONG / SHORT). SHORT bisa **cermin LONG otomatis** (RSI 30 → 70,
   memotong ke atas → ke bawah, Bollinger atas ↔ bawah, +DI ↔ −DI; ADX / ATR / volume tidak dibalik) atau diisi sendiri.
2. Susun kondisi (semua harus benar): **indikator A** (setting bisa diubah, boleh dari **TF lebih besar**, boleh
   "N candle lalu") — **operator** (>, <, ≥, ≤, memotong ke atas / bawah, naik / turun k candle) — **angka** atau
   **indikator B**. Maksimal 12 kondisi per arah.
3. Atur **entry** (market / limit X × ATR / limit X % / limit di close; batas berlaku N candle), **SL** (X × ATR / X % /
   di balik swing N candle + buffer) dan **TP = RR**.
4. **👁 Lihat Python** = kalimat aturan (termasuk SHORT hasil cermin) + kode Python-nya. **💾 Simpan** = file
   `strategies/rb_<nama>.py` (+ `.rules.json` untuk diedit lagi), langsung terpilih di daftar strategi → klik Jalankan
   Backtest seperti biasa. Aturan tersimpan bisa ✏️ diedit, ▶ dipakai, 🗑️ dihapus.
Indikator (37): harga open / high / low / close, EMA, SMA, WMA, VWMA, RSI, Stochastic %K / %D, MACD line / signal /
histogram, ADX, +DI, −DI, ATR, ATR %, Bollinger atas / tengah / bawah / %B / lebar, CCI, Williams %R, ROC, MFI, Force
Index, Supertrend, Donchian atas / bawah, volume, volume rata-rata, volume ÷ rata-rata, badan candle %, warna candle,
perubahan close %.
Penerjemahannya **pasti (tanpa AI)**: kode hanya memakai candle yang sudah close (termasuk TF besar), satu posisi sekali
jalan. Dicek tes otomatis: setiap trade terjadi tepat di candle yang aturannya terpenuhi.

### 📒 Jurnal sinyal — forward test otomatis (v3.95)

Menu baru **📒 Jurnal**. Setiap sinyal ✅ **layak** dari 🔎 Screener Market Structure (1 koin & scan banyak koin) dan
🎯 Cari setup Whale **dicatat otomatis** (bisa dimatikan), plus entry kamu dari 🧪 Cek entry posisi lewat tombol
**📒 Pantau di jurnal**. Sinyal dipantau **tiap 5 menit** (selama aplikasi menyala; disimpan di `saved/journal.json`)
dengan candle Binance yang sudah close, memakai aturan yang **sama dengan backtest-nya**: batas tunggu limit (Market
Structure: batal juga kalau harga lari melewati ujung leg), candle terisi ikut dicek SL, TP mulai candle berikutnya,
TP & SL di candle sama = SL, lewat batas lama trade = ditutup di close (R dibatasi −1 … RR).
Per sumber: sinyal, terisi live vs backtest, WR live vs backtest, **R per sinyal live vs janji backtest** (batal = 0R),
total R, kalah beruntun & drawdown live. Kesimpulan ("sesuai harapan" / "di bawah harapan") baru dinilai setelah ≥ 20
sinyal selesai. Daftar sinyal terbuka (R berjalan) & riwayat, hapus per sinyal / semua, link TradingView.

### 🐋 Flow + tembok digabung ke 🎯 Cari setup, 📼 perekam order book (v3.94)

- **🧭 Flow di 🎯 Cari setup**: sesudah scan, flow whale (OI, taker, long/short top trader, funding — TF sama dengan TF
  backtest setup, + 10 koin volume terbesar sebagai pembanding) dibaca untuk setup yang tampil. Kolom **🧭 Flow**: ▲/▼
  + **searah / melawan / netral**; baris flow di kartu visual (sejak v4.14 flow hanya info, tidak mengubah kesimpulan).
- **Uji gabungan flow** (kotak di atas tabel): trade backtest setup yang waktunya punya data flow dibagi saat flow searah /
  melawan. Cara membaca flow dipelajari dari **70% waktu awal saja**; WR searah vs melawan dibandingkan di 70% awal & 30%
  terakhir. **Terbukti membantu** hanya kalau WR searah ≥ melawan + 5 poin di keduanya (≥ 30 trade). Kalau tidak, flow
  tetap hanya info (bukan syarat).
- **📼 Perekam order book** (menu Whale): rekam tembok order besar (≥ min USDT, ±3% dari harga) tiap 1 / 5 / 15 menit
  untuk N koin volume terbesar atau daftar koin, ke `saved/orderbook/<KOIN>.jsonl`. Menyala lagi otomatis saat aplikasi
  dibuka (selama terakhir dinyalakan). Status: koin, snapshot, hari, ukuran file.
- **🧪 Uji tembok dari rekaman**: tiap tembok (bertahan ≥ 2 snapshot / sebentar / **spoof** = hilang saat harga sudah
  mendekat ≥ 50%) dicek dengan candle 5M: sesudah disentuh, **mantul** (1 ATR menjauh) atau **tembus** (close 0.3 ATR
  melewati) duluan — dibanding **level pembanding tanpa tembok** di jarak yang sama. Tembok terbukti kalau mantulnya ≥ 5
  poin lebih sering (≥ 30 kejadian). Butuh ±2 minggu rekaman.
- Kalah beruntun & drawdown di 🎯 Cari setup sekarang dihitung **satu posisi sekali jalan** (backtest entry tiap candle
  tumpang tindih sehingga dulu terlihat berlebihan, mis. 90×).

### 🧹 Menu lebih ringkas + scan banyak koin + "seberat apa" (v3.93)

- **🧠 Penemu Strategi pindah ke menu 📐 Market Structure** sebagai sub-tab (🔎 Screener & 🧪 Cek entry posisi |
  🧠 Penemu Strategi). Isinya tidak berubah; menu atas berkurang satu. Proses yang dijeda tetap bisa dilanjutkan.
- **Tombol ADX & Force Index di Indikator Tester dibuang** (pengujiannya tetap di 📍 Tes SNR).
- **😓 Seberat apa dijalani**: kalah beruntun terpanjang & drawdown terdalam (dalam R, urut waktu) di Screener Market
  Structure (rencana terbaik + tabel aturan), 🧪 Cek entry posisi, 🎯 Cari setup Whale, dan 🔍 Contoh trade Penemu Strategi
  (per koin). Ada peringatan kalau ≥ 8× kalah beruntun / drawdown ≥ 8R.
- **🔎 Scan banyak koin** (Screener Market Structure): ketik jumlah (mis. 50 = 50 koin volume terbesar Binance) atau daftar
  koin. Tiap koin dibaca live dari Binance; TF, ukuran swing, riwayat & TF besar ikut form. Tabel hanya menampilkan koin
  dengan setup ✅ layak (entry / SL / TP, terisi, WR, R per sinyal, kalah beruntun, prediksi pola, tren TF besar; tanda ⚠
  kalau arah setup melawan prediksi / tren). Klik baris = kartu visual. Koin lain dilipat dengan alasannya.
- Pencarian pola di riwayat dipercepat (label pola disimpan sebagai kode angka) — hasilnya identik dengan cara lama.
- **Animasi prediksi sampai selesai**: candle bayangan (kejadian nyata di riwayat) sekarang diteruskan dengan level entry /
  SL / TP rencana sekarang (dalam ATR) sampai **kena TP**, **kena SL**, **limit tidak terisi** (48 candle), atau batas trade
  — titik akhirnya ditandai, mis. "✅ kena TP ±1.3 hari sesudah entry". Ini SATU contoh nyata (bukan janji); peluangnya ada
  di WR & R per sinyal.
- **⏱ Perkiraan waktu** (median riwayat): limit terisi ±…, kena TP ±…, kena SL ±… — di Screener Market Structure (per
  aturan) dan 🧪 Cek entry posisi (entry kamu), dalam menit / jam / hari sesuai TF.

### 🖼 Zona TP tidak lagi tampak kecil (v3.92)

Di kartu visual (Market Structure, Cek entry, Whale), kalau TP jauh di luar layar, zona untung dulu hanya tergambar
sebagai garis tipis sementara zona SL tampak besar — sekilas seperti SL / TP kebalik. Sekarang skala chart selalu
menyisakan **minimal 1R di sisi TP**, jadi zona untung tidak pernah tampak lebih kecil dari zona rugi. TP yang lebih jauh
tetap ditandai "↓ / ↑ di luar layar" (harga aslinya di tag sumbu & kotak angka).

### 🐋 Whale: setup lebih jujur + 🧭 Flow whale (v3.91)

**🎯 Cari setup terbaik** sekarang memakai disiplin yang sama dengan Market Structure. Setup baru **layak dipasang** kalau:
1. rata-rata untung (WR × RR − kalah), 2. **tetap untung di 30% data terakhir** (≥ 10 trade, dinilai terpisah dari 70%
awal — dihitung dari backtest yang sama, tidak memperlambat scan), 3. entry **tersentuh ≥ 70%** dalam 24 jam.
Setup yang layak selalu di urutan atas; yang tidak layak dipudarkan + alasannya (rugi / rugi di data terbaru / jarang
tersentuh). Kalau tidak ada yang layak: peringatan **JANGAN ENTRY DULU**. Kartu visual setup kini punya panel ringkasan
(rencana, backtest + uji 30% terakhir, tren & tembok lawan, kesimpulan).

**📐 Market Structure — Riwayat bisa diketik** (Screener & Cek entry posisi): `semua`, `koin ini`, angka (mis. `100` =
100 koin dengan volume USDT terbesar 30 hari terakhir **di data lokal**, koin pilihanmu selalu ikut), atau daftar koin
(mis. `btc, eth, sol`). Baris status menulis berapa koin riwayat yang benar-benar dipakai.

**🧭 Flow whale** (form baru di menu Whale): data uang besar yang riwayatnya disediakan Binance (±30 hari) —
**Open Interest + harga** (long baru / short tutup / short baru / long tutup), **taker buy/sell** (beli/jual agresif),
**rasio long/short top trader** (posisi) dan **funding**. Keadaan sekarang (perubahan 4 candle terakhir, candle sudah
close) dibandingkan dengan riwayat koin itu (+ 10/20/50 koin volume terbesar): harga +2 ATR atau −2 ATR duluan (48
candle) berapa %, dibanding **normal**. **Terbukti** = keunggulan positif di 70% waktu awal **dan** 30% waktu terakhir
(≥ 30 sampel, ≥ 10 di data uji). Sinyal terbukti yang arahnya berlawanan = **SINYAL BERTENTANGAN** (tidak ada arah).
TF 15M / 1H / 4H. Hasilnya satu kartu visual (5 kotak: OI, taker buy, long/short top, funding, kesimpulan + panel per
sinyal), 📋 Salin hasil & ⬇ Unduh gambar. Dipakai sebagai **penguat arah**, bukan sinyal entry sendiri.

### ✅ Hanya entry yang sering kesentuh & tidak rugi (v3.90)

Screener Market Structure (dan 📐 Visual di Screener) hanya memberi sinyal kalau **dua syarat** terpenuhi:
1. **Sering kesentuh**: entry-nya di riwayat **terisi ≥ 70%** (entry market = 100%).
2. **Tidak rugi**: hasil per sinyal **positif** dan **tetap positif di 30% data terakhir** (data uji).
Kalau tidak ada yang lolos, kartu menulis **⏳ JANGAN ENTRY DULU** + alasannya (mis. "jarang terisi (31% < 70%)",
"rugi di data uji", atau setup sudah lewat). Rencana lain tetap bisa dilihat lewat tombol LONG / SHORT, ditandai ⚠ dan
label abu-abu (JARANG TERISI / RUGI · JANGAN / LEWAT).
Di chart, garis ENTRY limit sekarang bertuliskan **"terisi X% · s/d HH:MM UTC"** (batas tunggu limit = 48 candle).
🧪 Cek entry posisi: saran entry wajib terisi ≥ 70%, dan semua saran (entry / SL / TP / gabungan) wajib untung di data
cari **dan** data uji. Kalau limit kamu sendiri terisi < 70%, panel memberi peringatan.

### 🖼 Satu gambar menjelaskan semuanya (v3.89)

Kartu visual 🔎 Screener Market Structure, 📐 Visual (menu Screener) dan 🧪 Cek entry posisi sekarang memuat semua inti
di **satu gambar** (ikut terunduh & bisa dibagikan):
- Header: chip **Tren TF besar** (mis. "Tren 4H ▼ TURUN · ✓ dipakai penyaring").
- Kotak Arah selanjutnya: **normal x% · keunggulan +y%**.
- **Panel ringkasan di bawah chart** (tidak menutupi chart): prediksi + keunggulan, tren TF besar & kejadian yang dipakai,
  rencana entry / SL / TP (atau "tunggu setup baru"), saran entry / SL / TP + alasan singkat (Cek entry), dan **kesimpulan**.
Penjelasan panjang & tabel di bawah kartu dilipat ke **📄 Detail lengkap** (tidak wajib dibaca).

### 🎯 Prediksi lebih teruji: pembanding, tren TF besar, leg mirip (v3.89)

Berlaku untuk 🔎 Screener Market Structure, 📐 Visual di Screener, dan 🧪 Cek entry posisi.
1. **Pembanding**: arah 2 ATR duluan setelah pola dibandingkan dengan **arah normal** setelah swing apa pun di koin & TF
   yang sama → **keunggulan pola** (mis. "turun 72% · normal 49% · +23% meyakinkan"). Uji binomial kasar: *meyakinkan*
   (z ≥ 2), *lemah* (z ≥ 1), atau *bisa kebetulan*. Tertulis juga di kartu (kotak Arah selanjutnya) & teks sinyal.
2. **Tren TF besar** (bisa dipilih: Otomatis / Mati / 15M / 1H / 4H / 1D; otomatis 5M→1H, 15M→4H, 1H→1D, …): tren dari
   struktur TF besar yang sudah diketahui saat itu (HH + HL = naik, LH + LL = turun). Sekarang dibaca live dari Binance.
3. **Leg mirip**: ukuran tiap leg pola (dalam ATR) dibandingkan dengan pola sekarang; separuh kejadian yang paling mirip.
Kombinasi (pola / + tren / + leg mirip / ketiganya) dinilai di **30% kejadian terakhir**: arah mayoritas dari 70% awal
dipakai menebak 30% terakhir. Penyaring hanya dipakai kalau tebakan benar naik ≥ 2% dan sampel cukup (≥ 30 kejadian,
≥ 10 di data uji). Tabel "🎯 Seberapa akurat prediksi ini?" menunjukkan semua kombinasi & mana yang dipakai.

### 📏 Skala kartu visual sama di semua menu (v3.88)

Prediksi 🔎 Screener dan 🧪 Cek entry selalu sama (pola, kejadian & jalur yang sama), tapi dulu skala chart ikut melebar
sampai SL / TP — TP yang jauh membuat jalur prediksi terpencet jadi garis datar, sehingga kelihatan beda. Sekarang skala
mengikuti **candle + jalur prediksi + entry**; SL / TP / garis saran yang terlalu jauh ditempel di tepi chart dengan tanda
**↑ / ↓ di luar layar** (harga aslinya tetap tertulis di tag sumbu & kotak angka).

### 🧪 Cek entry posisi: pilihan riwayat (v3.87)

Form Cek entry posisi sekarang punya pilihan **Riwayat**: *Semua koin* (lebih banyak kejadian) atau *Koin ini saja*
(lebih cepat & khas koin itu; butuh data lokal koin itu di TF yang dipilih).

### 🧪 Cek entry posisi (v3.86, menggantikan 📐 Analisa Market Structure)

Di menu **📐 Market Structure**, di bawah Screener. Isi **koin, TF, entry, SL, TP** dan **status posisi**
(belum kesentuh / sudah masuk). Arah LONG / SHORT dibaca otomatis dari susunan harga.
1. Struktur swing sekarang dibaca seperti 🔎 Screener (live Binance) → pola; pola yang sama dicari di riwayat semua koin.
2. Entry / SL / TP kamu diubah ke **jarak ATR dari harga sekarang** lalu dipasang di tiap kejadian (harga & ATR saat itu).
3. **Belum kesentuh**: % limit terisi & **berapa lama** (jam / hari, rentang umum), lalu kena TP duluan / SL duluan,
   hasil per sinyal (R risiko kamu; tidak terisi = 0), % kena wick (kena SL lalu tetap ke TP), seberapa jauh pola ini
   biasanya **bergerak melawan dulu**, dan gerak maksimal searah.
   **Saran entry / SL / TP** (masing-masing digeser ±ATR, dipilih di 70% kejadian awal, dicek di 30% terakhir) lengkap
   dengan **alasannya** (mis. "48% trade kamu kena SL dulu lalu tetap ke TP → SL dijauhkan ke X"), plus gabungan semua saran.
   Tombol **Pakai saran ini** mengisi form untuk diuji ulang.
4. **Sudah masuk**: prediksi arah + peluang **kena TP duluan vs kena SL duluan** dari sekarang, dan **saran TP saja**.
5. Kartu visual (entry / SL / TP kamu + garis saran + animasi prediksi), 📋 Salin hasil, ⬇ Unduh gambar, dan
   🔍 Contoh kejadian (level kamu digambar di Manual Replay).

### ⏳ "Tunggu setup baru" (v3.85)

Screener Market Structure hanya menjadikan **sinyal utama** setup yang **masih bisa dipasang sekarang**. Kalau setup dari
pola sekarang sudah lewat (kena SL / kena TP / batal / kedaluwarsa), kartu menulis **⏳ TUNGGU SETUP BARU** + status
setup terakhir, tanpa zona entry / SL / TP — prediksi arah tetap tampil. Entry dihitung saat swing terakhir terkonfirmasi,
jadi setup baru muncul setelah swing / pola berikutnya terbentuk. Setup lama tetap bisa dilihat lewat tombol LONG / SHORT.
Label SEKARANG dipindah ke bawah chart supaya tidak menumpuk dengan label TP.

**Entry dipilih dari R per sinyal** (bukan lagi R per trade yang terisi): R per sinyal = rata-rata R per trade × peluang
limit terisi. Sebelumnya limit yang jauh bisa terpilih karena hasilnya bagus di sedikit kejadian yang terisi, padahal di
kebanyakan kejadian harga langsung pergi tanpa menyentuh entry (seperti yang terlihat di animasi). Kartu sekarang
menampilkan **"terisi X%"** di kotak Entry dan **R / sinyal** di kotak Backtest; tabel aturan punya kolom R/sinyal.
Keterangan animasi (candle bayangan / median / pita) dipindah ke bawah kartu supaya tidak menutupi garis SL / entry.

### 🖼 Kartu visual entry di Whale & Screener + status setup jujur (v3.84)

- **🐋 Whale · 🎯 Cari setup terbaik**: hasil scan sekarang diawali **kartu visual entry** (candle 15M live, zona entry /
  SL / TP, garis 1R…, **tembok order whale** sebagai garis putus-putus, WR & rata-rata R backtest, peluang entry tersentuh
  24 jam). Pilih setup lain lewat tombol di bawah kartu atau **🖼 Visual** di tiap baris tabel. Ada 📋 Salin sinyal & ⬇ Unduh gambar.
- **Screener**: tiap koin hasil scan punya tombol **📐 Visual** = Screener Market Structure koin itu di TF screener
  (struktur live → pola sama di riwayat → entry / SL / TP + animasi prediksi). Bisa dibuka lengkap di menu Market Structure.
- **Status setup jujur** (Screener Market Structure): setelah limit tersentuh, dicek lanjut apakah sudah **kena SL**, **kena
  TP**, atau masih berjalan. Setup yang sudah lewat ditandai **· LEWAT** (abu-abu) dan tidak dipilih sebagai sinyal utama
  kalau masih ada setup lain yang berlaku. Sebelumnya bisa tampil "BUY LIMIT · sudah tersentuh" padahal harga sudah di bawah SL.
- **Entry baru: limit 0,5 / 1 / 1,5 ATR** di bawah (LONG) / di atas (SHORT) harga saat pola terkonfirmasi — untuk pola yang
  biasanya "turun dulu baru naik". Ikut di-backtest bersama entry lain; dipakai hanya kalau hasilnya memang lebih baik.
- Diperbaiki: filter market structure di Screener sempat membaca kolom "Ukuran swing" dari menu Analisa Market Structure
  (ID elemen sama), dan centang "hitung swing yang sedang berjalan" tidak terbaca.

### 🔎 Screener Market Structure: gambar visual paling atas (v3.83)

Tata letak baru: baris form ringkas (koin, TF, swing, riwayat, Scan) di paling atas, lalu **gambar visual entry selebar
layar**, lalu tombol (salin / unduh / putar ulang), baru **penjelasan & tabel** di bawahnya. Selama scan, panel menampilkan
⏳; kalau gagal, pesan error tampil jelas di panel dan di bawah tombol (tidak lagi kosong hitam).

### 🔎 Screener Market Structure: petunjuk & hasil terakhir (v3.82)

Sebelum scan, panel kanan menampilkan petunjuk (tidak kosong hitam lagi). Hasil scan terakhir disimpan di browser dan
muncul lagi otomatis saat aplikasi dibuka, dengan keterangan waktu candle-nya. Klik **Scan sekarang** untuk data terbaru.

### 🔎 Screener Market Structure (v3.81, di menu 📐 Market Structure)

Pilih **1 koin**, **TF**, ukuran swing, dan riwayat (**semua koin** atau **koin ini saja**), lalu klik **🔎 Scan sekarang**.
1. **Struktur sekarang** dibaca dari candle yang **sudah close** langsung dari Binance (1000 candle terakhir). Kalau Binance
   tidak bisa diakses, dipakai data lokal terakhir (ada catatannya).
2. Urutan swing terakhir (HH / LH / HL / LL) = **pola**. Panjang pola otomatis: 6 swing, dipendekkan sampai 3 kalau di
   riwayat kejadiannya kurang dari 30.
3. Pola yang sama dicari di **riwayat data lokal**. Hasilnya: % harga **naik / turun 2 ATR duluan** (dan median berapa
   candle), swing berikutnya yang biasanya terbentuk, dan **entry / SL / TP terbaik** dari backtest pola itu (entry market /
   limit fib / retest × SL swing / pola × **RR 3, 4, 5**, minimal 15 trade). **✓ terbukti** = tetap untung di 30% data
   terakhir yang tidak dipakai memilih. Aturan terbaik diterapkan ke **harga sekarang** dengan status *aktif / sudah
   tersentuh / batal / kedaluwarsa*. Kalau tidak ada aturan yang untung, ditulis jujur "tidak ada setup".
4. **Kartu sinyal** seperti grup trading: entry / SL / TP, zona untung-rugi, garis 1R–4R, label swing, dan **animasi
   prediksi**. Candle bayangan = **1 kejadian nyata** di riwayat yang paling mirip rata-rata (jadi ada naik dulu / turun
   dulu sesuai riwayat), garis kuning putus-putus = median, pita kuning = tempat 50% kejadian bergerak.
5. Tombol **📋 Salin sinyal** (teks siap tempel), **⬇ Unduh gambar** (PNG), **▶ Putar ulang animasi**, pilihan rencana
   LONG / SHORT, tabel semua aturan yang diuji, dan **🔍 Contoh kejadian** (dibuka di Manual Replay dengan label swing).

### 🎛️ Hyperopt Tester disederhanakan (v3.81)

Yang diatur sekarang cuma: **centang indikator**, **TF**, **RR**, periode, dan koin. Sisanya otomatis dan tetap:
semua angka indikator dari daftar otomatis, **SL 1 / 1,5 / 2 × ATR**, **lama tahan 4 / 12 / 24 jam**, LONG & SHORT,
minimal 30 trade, dioptimasi rata-rata R per trade. **Test angka ini** membuka angka hasil temuan di tester biasa
(Kombinasi / RSI / Stochastic / MACD) lengkap dengan SL & lama tahannya. Juga diperbaiki: hyperopt sempat error karena
perhitungan lama tahan per TF.

### 🎛️ Hyperopt Tester di Indikator Tester (v3.80)

Seperti **hyperopt Freqtrade**: angka indikator (pilih ≥ 1: MA pasangan, RSI, Stochastic, MACD, ADX, Force Index; kolom
kosong = daftar otomatis) dan **SL** (× ATR, mis. `1, 1.5, 2`) dicari otomatis; **RR dari kamu**. Lebih dari 3.000
kombinasi = diambil acak 3.000 (seed tetap). Yang dioptimasi: rata-rata R / WR / rata-rata R × √trade.
Bedanya dengan hyperopt biasa, langsung dicek **anti-overfitting**:
- Data dibagi 5 bagian waktu: **cari** = 80% awal, **uji** = 20% terakhir (tidak dipakai mencari).
- **Walk-forward**: cari di bagian 1–2 lalu pakai di bagian 3, cari di 1–3 lalu pakai di 4, cari di 1–4 lalu pakai di 5
  = meniru hyperopt ulang tiap periode. Hasil gabungannya = perkiraan paling jujur.
- **Kestabilan**: rata-rata R angka "tetangga" (satu angka digeser ke nilai sebelah). ✅ lolos = untung di data uji, cukup
  trade, dan stabil; ⚠️ rapuh = angka sebelahnya jauh lebih jelek (kemungkinan kebetulan).
- Ukuran **overfitting**: rata-rata 10 angka terbaik di data cari vs data uji, plus pembanding semua kombinasi.
- Tiap baris: **Test angka ini** dan **🔍 Contoh trade**. Kesimpulan "belum bisa disimpulkan" kalau trade walk-forward < 30.

### 📐 Analisa Market Structure (v3.79, menggantikan menu Studi Fibonacci v1)

Menu baru untuk membaca **kebiasaan struktur pasar** (deskriptif, bukan sinyal). Yang diatur: **TF**, **jumlah candle**
terbaru per koin (mis. 2000 / 10000), **ukuran swing** (kecil = fractal 3, sedang = 5, besar = 10), dan koin.
- **Koreksi**: berapa candle sebelum breakout (BOS berikutnya), seberapa dalam (fib impuls, ATR, %), berapa % berakhir
  breakout vs berbalik.
- **Impuls**: berapa candle & seberapa jauh (ATR, %).
- **Umur tren**: lama tren (CHoCH → CHoCH), jumlah BOS (HH / LL) per tren, isi swing per tren (HH / HL / LH / LL), dan
  **tabel peluang**: setelah BOS ke-k, berapa % tren berubah (CHoCH) sebelum BOS berikutnya.
- **HH / LL berturut-turut**: setelah k× HH (di urutan swing high), berapa % swing high berikutnya sudah tidak HH (LH /
  koreksi) — menjawab "kalau sudah 3× HH biasanya koreksi?". Sama untuk LL.
- **Perubahan tren**: % CHoCH valid (tren baru membuat ≥ 1 BOS) vs palsu, lama sampai BOS pertama, dan **urutan 4 swing
  yang paling sering muncul sebelum tren berubah**.
- **Kestabilan**: angka separuh data awal vs akhir. **🔍 Contoh tren** dibuka di Manual Replay dengan label swing.
- Angka ditulis sebagai median & rentang umum (25%–75%). Definisi lengkap ada di panel *Definisi*.
- Studi Fibonacci v2 tetap ada.

### 🧠 Penemu Strategi baru: pola market structure (v3.78)

Penemu Strategi diganti total jadi **price action murni** (pola indikator lama dihapus). Yang diatur cuma **TF**
(single TF), **RR** (mis. `2, 3`), Min. WR, periode, dan koin.
1. Swing fractal 3 (diketahui 3 candle sesudahnya) diberi label: HH / LH / **EH** (double top) / **XH** (sweep high),
   HL / LL / **EL** (double bottom) / **XL** (sweep low). Urutan 3–4 swing terakhir = **pola**.
2. Tiap pola dicoba LONG & SHORT dengan **entry** market / limit fib 0.382–0.786 dari leg terakhir / limit retest BOS,
   **SL** di balik swing terakhir atau ujung pola (+0.1 ATR), **TP** = RR kamu. Limit berlaku 48 candle, batal kalau harga
   lebih dulu membuat high/low baru; lama trade maks 200 candle; TP & SL di candle sama = kalah.
3. 70% data awal untuk mencari, 30% untuk menguji. ✅ Lolos = untung di keduanya, lebih baik dari aturan entry/SL yang
   sama di semua pola, ≥ 30 trade, dan (≥ 3 koin) untung di ≥ 60% koin.
- Tiap pola: entry / SL / RR terbaik + tabel varian lain yang juga diuji, **🔍 Contoh** (Manual Replay: label swing,
  entry, SL, TP tergambar), dan **📄 Threshold & workflow**: aturan lengkap + spesifikasi program scan (jumlah candle,
  rumus tiap langkah, aturan batal) dengan tombol **Salin untuk AI coding**.
- Hasil tersimpan dari versi lama tidak bisa dibuka di tampilan baru — jalankan ulang.

### 🧠 Penemu Strategi bisa single TF (v3.77)

TF tren boleh **sama** dengan TF entry (mis. entry 15M, tren 15M) = **single TF**: konteks tren EMA50/200 dihitung dari
candle TF entry itu sendiri yang sudah close (tanpa intip masa depan). TF tren tetap tidak boleh lebih kecil dari TF entry.

### 📈 EMA Tester baru & ADX / Force Index model Tes SNR (v3.75 – v3.76)

**EMA Tester** (disederhanakan di v3.76): yang diatur **cuma TF dan angka EMA** (plus periode & koin), EMA bisa
sampai **5000** (mis. 3000). Aturan lain tetap:
1. **Berapa kali EMA disentuh, mantul ≥ 2R, tembus lalu tren berubah** — tiap EMA di *Daftar EMA yang diuji* (kosong =
   daftar otomatis) diuji sendiri. Dihitung saat tren searah EMA (harga sudah ≥ 1 ATR di atas / bawah EMA), lalu ekor
   candle **menyentuh** EMA. **1R = 1 ATR** saat menyentuh, diukur dari harga EMA saat disentuh. Mana yang lebih dulu:
   **mantul** = close 2R searah tren; **tembus & tren berubah** = close 2R di seberang EMA. Tanpa batas waktu.
2. **EMA kedua dijebol → EMA pertama tembus & bertahan 200 candle = tren berubah** — semua pasangan dari dua daftar,
   asal **EMA pertama minimal 30 lebih besar** dari EMA kedua (mis. 200 & 50, 1120 & 640). Peringatan = candle close
   menembus EMA kedua tapi masih tertahan EMA pertama (masuk range antara kedua EMA; yang langsung jebol keduanya tidak
   dihitung). **Valid** = lanjut close menembus EMA pertama dan tidak close balik selama 200 candle. **Pengecualian**:
   harga balik lagi melewati EMA kedua = **tren berlanjut**. Tembus EMA pertama tapi balik sebelum 200 candle = gagal.
- Pemanasan dihitung **per EMA** (3× panjangnya): EMA 3000 butuh 9.000 candle dan dilewati di koin yang datanya kurang,
  tapi EMA pendek tetap pakai data penuh.
- Ditampilkan kalau kejadiannya ≥ 30. Tiap baris punya **🔍 Contoh** (Manual Replay; EMA di chart otomatis diganti, garis
  target 2R ikut digambar) & **Pakai**.

**ADX** dan **Force Index** sekarang dites seperti **📍 Tes SNR** (tombolnya di Indikator Tester membuka Tes SNR):
- Pilih **Indikator yang dites**: Dorongan % / **ADX** / **ADX + arah Force Index**.
- Nilai indikator dibaca saat harga mendekati SNR: **2, 1.5, 1, 0.5 ATR** sebelum SNR dan saat menyentuh. Ringkasan simpel
  dibaca di **1.5 ATR** (bisa diganti di Pengaturan lanjutan). Hasil: rentang ADX untuk entry limit (respect) & breakout.
- **ADX + Force Index**: hasil dipisah **FI menuju SNR** (FI positif mendekati resistance / negatif mendekati support) vs
  **FI melawan**. Catatan jujur: saat harga bergerak mendekati SNR, FI hampir selalu searah gerakan itu, jadi kelompok
  "melawan" datanya sedikit.
- Panjang ADX 7 / 10 / 14 / 20 / 28 dibandingkan otomatis (dipilih di data cari, dibuktikan di data uji). ADX tidak
  mengubah default indikator Dorongan % di chart.

### 🐋 Cek entry selalu tampil (v3.74)

Sebelumnya **🧪 Cek entry kamu** hanya muncul di mode "1 koin", jadi hilang kalau Mode = "Semua koin". Sekarang selalu
tampil; di mode "Semua koin" ada kolom **Koin** sendiri. Saat tombol Cek entry diklik, halaman otomatis pindah ke mode
1 koin (analisa koin itu + hasil cek entry).

### Tanggal "Mulai (UTC)" otomatis ikut data koin (v3.73)

- Di bawah kolom **Mulai (UTC)** tertulis rentang data koin yang dipilih (mis. `data: 2025-06-13 → 2026-10-27`).
- Tombol cepat **awal data** (awal data + 3 hari, supaya chart sudah ada candle) dan **terbaru** (data paling baru − 1 hari).
- Kalau tanggal yang diketik **sebelum data ada** → otomatis diganti ke awal data + 3 hari; **setelah data habis** → ke
  data terakhir. Muncul pesan kenapa diganti. Kalender juga hanya bisa memilih tanggal di dalam data.

### 🧭 Workflow & threshold strategi di Studi Fibonacci v2 (v3.72)

Di paling bawah hasil **Studi Fibonacci v2** sekarang ada ringkasan siap pakai, angkanya otomatis dari hasil backtest itu:
- **⚙️ Pengaturan**: TF fibo, TF kondisi pasar (EMA50 + ADX ≥ batas + BOS), EMA tren, syarat swing selesai, dorongan
  minimal (× ATR), batas umur limit, dan **set angka fibo** untuk dipasang di chart.
- **📊 Threshold per kondisi pasar** (Bullish BUY, Bearish SELL, Sideways BUY/SELL): cara tarik fibo, entry limit, SL,
  TP1, TP2, kapan batal, breakout (sideways), target setelah BOS, dan **status**: ✅ lolos uji / ❓ belum pasti / ⚠️ tidak lolos.
- **🔁 Workflow** langkah demi langkah dan **📐 Cara pakai fibo** (1 = awal dorongan, 0 = ujung, minus = target, > 1 = patah).
- Tombol **Salin workflow** untuk menyalin semuanya sebagai teks.

### 🔍 Contoh kejadian di semua menu backtest (v3.71)

Setiap menu backtest sekarang punya **contoh kejadian** supaya hasil hitungan bisa dicek langsung di chart (seperti kasus
Tes SNR yang ternyata salah golongan). Klik baris → **Manual Replay** terbuka di koin, TF & waktu itu dengan garis otomatis.

| Menu | Di mana | Yang digambar |
|---|---|---|
| Auto Backtest | tabel trade (sudah ada) | momen sinyal |
| 🧠 Penemu Strategi | 📋 Lihat contoh trade (sudah ada) | entry, SL, TP |
| 📍 Tes SNR | 🔍 Contoh kejadian saat menyentuh SNR (sudah ada) | garis SNR |
| 🧪 Indikator Tester | tombol **🔍 Contoh trade** di tiap baris hasil (bisa pilih koin) | entry, SL, TP |
| Studi Fibonacci v1 / v2 | **5. 🔍 Contoh kejadian** di bawah hasil, ikut kelompok yang dipilih | 0 & 1.0 (kuning), level fibo, limit terbaik (biru), SL, TP |
| 🐋 Whale · 🎯 Cari setup | tombol **🔍 Contoh trade** di tiap setup | entry, SL, TP |

- Contoh dihitung dengan kode yang **sama persis** dengan hasilnya (dicek tes otomatis: jumlah trade & WR sama).
- Studi Fibonacci menyimpan 60 setup terbaru per kelompok (kondisi pasar × arah). Kolomnya: koreksi terdalam, hasil limit
  terbaik (TP / SL / tidak terisi / dilewati karena level sudah tersentuh sebelum fibo digambar) dan akhir gelombang
  (lanjut tembus 0 / BOS tembus 1.0 / belum selesai). Hasil studi tersimpan dari versi lama belum punya contoh → jalankan ulang.
- Whale memakai data terbaru dari Binance, jadi bisa sedikit beda dengan saat scan (ada keterangannya). Membuka di chart
  butuh data lokal sampai tanggal itu; kalau belum, muncul pesan untuk update data candle dulu.

### Dorongan % di TradingView (v3.69)

File `tradingview/dorongan.pine` = indikator Dorongan % untuk TradingView, rumusnya **sama persis** dengan versi di
aplikasi (dicek: hasilnya identik candle per candle). Cara pasang:
1. Buka file itu dengan Notepad → pilih semua → copy.
2. TradingView → bawah chart klik **Pine Editor** → hapus isi yang ada → paste → **Save** → **Add to chart**.
3. Klik ⚙️ indikator untuk mengatur Panjang ADX (14), Force Index (13), Volume (20), Penghalusan (10), Garis tengah (50).
   Samakan dengan pengaturan di aplikasi / hasil Tes SNR.
4. Bisa pasang alert: "Dorongan naik di atas garis" / "Dorongan turun di bawah garis".

Catatan: angka di awal chart bisa sedikit beda karena TradingView mulai dari candle pertama yang dimuat; setelah
±100 candle angkanya sama. Pakai chart **Binance perpetual (mis. BINANCE:BTCUSDT.P)** supaya volumenya sama.

### Tes SNR: hasil harus "bertahan" dulu baru dihitung (v3.68)

- **Breakout** baru dihitung kalau setelah close tembus SNR, harga **tidak close balik ke dalam SNR selama N candle**.
  Kalau balik = **🪤 fakeout** → dihitung **SNR bertahan (respect)**. Contoh: BTC 27-10 12:40 resistance 80364.2.
- **Respect** juga begitu: setelah menyentuh lalu memantul ≥ 1 ATR, **N candle berikutnya tidak boleh ada close tembus**.
  Kalau ada, pantulan kecil itu belum dihitung dan kejadiannya dinilai terus sampai hasilnya jelas. Contoh: BTC 24-10
  22:35 resistance 80620.1 — sempat turun ±100 USD, tapi 23:30 close tembus 80827 → sekarang **breakout**.
- Lamanya diatur di Pengaturan lanjutan → **Hasil sah kalau bertahan (jam)**, default **1 jam** (v3.70; sebelumnya dalam
  candle). Dalam jam supaya syaratnya sama untuk semua TF; jumlah candle dihitung otomatis (5m = 12, 15m = 4, 1h = 1)
  dan ditulis di bawah kolomnya.
- Hasil Tes SNR yang tersimpan dari versi lama memakai aturan lama — jalankan ulang.

### Jeda / lanjutkan proses berat

Backtest semua koin, Studi Fibonacci v1/v2, dan "Cari angka fibo terbaik" punya tombol **⏸️ Jeda**.
- Saat dijeda, koin yang sedang dihitung diselesaikan dulu ("Menjeda… menunggu N koin"), lalu proses berhenti dan CPU/RAM dilepas.
- Hasil yang sudah selesai tidak hilang. **▶️ Lanjutkan** hanya mengerjakan koin yang belum selesai, tidak dari awal.
- Proses yang dijeda disimpan di `saved\paused\`, jadi tetap bisa dilanjutkan walaupun aplikasi ditutup atau PC
  dimatikan. Daftarnya muncul di bar kuning di atas halaman: **Lanjutkan**, **Lihat**, atau **Buang**.
- Selama dijeda, proses lain boleh dijalankan. Lanjutkan setelah proses lain itu selesai.

### Simpan hasil otomatis

Centang **💾 Simpan hasil otomatis setelah selesai** (di atas tombol Jalankan, di Auto Backtest dan Studi Fibonacci)
supaya hasil langsung tersimpan dengan nama otomatis tanpa klik Simpan. Pilihan centang diingat.

### Label ATR di formulir

Setiap parameter yang memakai ATR diberi label kecil **ATR · TF**, misalnya `sl_atr ATR · 1H`, supaya jelas ATR
dihitung dari candle TF berapa. Labelnya ikut berubah kalau TF di formulir diganti:
- Kebanyakan strategi memakai ATR TF entry (`tf`).
- CRT memakai TF konfirmasi (atau TF range kalau konfirmasi kosong).
- MoneyMagnetScalping: filter Range/ATR memakai ATR H1 (`htf`), sisanya ATR M5.
- Studi Fibonacci dan FibPrecision memakai ATR TF gelombang.

### 🐋 Whale (pelacak whale live)

Binance tidak membuka identitas pemilik order, jadi yang dilacak adalah **jejak uang besar** di N koin volume terbesar:
- **Tembok order terbesar (limit)**: harga, sisi BUY (bid, di bawah harga) / SELL (ask, di atas harga), jarak dari harga,
  nilai USDT, **kekuatan** (porsi dari semua order di sisinya dalam ±2%), dan **dampak**.
- **Transaksi whale terbaru (market)**: BUY (pembeli agresif) / SELL, harga, nilai, **× volume per menit**, dampak, waktu.
- **Tekanan whale per koin**: total uang besar di sisi BUY vs SELL (+ = condong beli, − = condong jual).
- **Dampak** = kalau order sebesar itu dieksekusi market sekarang, harga bergerak berapa persen menyapu order book lawan.
  Filter **Min. dampak harga** menyisakan whale yang benar-benar mampu menggerakkan harga.
- Pengaturan: jumlah koin dipantau, **jumlah daftar whale (5 / 10 / 15 / 20 / 30 / 50)**, min. nilai USDT, min. dampak,
  auto refresh. Klik nama koin untuk membuka chart, ↗ untuk Binance.
- **Mode 1 koin (analisa detail)**: pilih Mode **1 koin**, ketik koinnya (mis. `btc` / `BTCUSDT`), atau klik nama koin di
  ranking. Isinya: kesimpulan singkat (whale condong BELI / JUAL, order book ±2%, support & resistance whale terdekat,
  lebih mudah naik atau turun), bar transaksi whale BELI vs JUAL, bar order book, **USDT yang dibutuhkan untuk
  menggerakkan harga** 0.5 / 1 / 2 / 5%, **peta likuiditas ±5%** (antrean BELI hijau & JUAL merah per 0.25%),
  daftar support & resistance whale, serta transaksi whale terbesar & terbaru (order book 1000 level, ±3000 transaksi).
- Di mode 1 koin juga ada (semuanya **perkiraan**, bukan kepastian):
  - **Kekuatan pasar Bullish / Bearish / Sideways (%)** dari tren EMA 20/50/200 H1, ADX H1, tekanan transaksi whale,
    dan order book ±2%.
  - **Perkiraan gerak** dari volatilitas asli koin (ATR H1 & harian): kisaran ±4 jam dan ±1 hari, arah condongnya,
    dan berapa lama rata-rata sampai ke support / resistance whale terdekat.
  - **Rencana SL & TP** untuk LONG dan SHORT: SL di balik tembok whale terkuat (±3%) + 0.25 ATR H1, TP1 di depan tembok
    lawan terdekat, TP2 di tembok lawan terbesar berikutnya (kalau tidak ada tembok: jarak ATR). Kartu yang searah
    kekuatan pasar diberi tanda.
  - **Kalau harga menyentuh tembok whale ini**: perkiraan memantul (tembok BELI → naik, tembok JUAL → turun) berapa
    persen, ke harga berapa, dan kira-kira berapa lama. Besarnya dari kekuatan tembok & ATR, dibatasi tembok lawan.
  - Riwayat order book tidak tersedia publik, jadi bagian ini tidak bisa di-backtest.
- **🛡️ Anti gocekan** (mode 1 koin), supaya SL tidak kena sapu harga yang tiba-tiba naik / turun lalu balik:
  - **Alarm lonjakan** (candle 1 menit): volume 5 menit terakhir vs normal 1 jam + gerak harga vs ATR 1m →
    NORMAL / WASPADA / BAHAYA (berkedip), dan siapa yang agresif (pembeli / penjual).
  - **Backtest gocekan** dari 1000 candle 15M koin itu: berapa % swing high/low yang ditembus ekor candle ternyata cuma
    gocekan (close balik ≤ 4 candle), dan sedalam apa tembusnya (50 / 80 / 90% dalam ATR).
  - **Zona gocekan**: swing high/low terdekat + angka bulat, beserta rentang yang biasa disapu. Jangan taruh SL di dalamnya.
  - **Zona tipis**: rentang ±5% yang antrean ordernya < 25% rata-rata (harga bisa loncat cepat), juga ditandai garis
    kuning di peta likuiditas.
  - **Tembok palsu (spoofing)**: tembok yang ada di scan sebelumnya lalu hilang saat harga mendekat. Di tabel
    support/resistance, **✅ n×** = tembok bertahan n scan berturut-turut (lebih bisa dipercaya). Butuh ≥ 2 scan —
    nyalakan **Auto refresh**.
  - **🧪 Cek entry kamu** (mode 1 koin): isi Entry, SL, TP, **wajib pilih arah BUY / SELL** (SL & TP dicek sesuai arah)
    dan **wajib pilih status**:
    **Sudah berjalan** (peluang dihitung dari harga sekarang + untung/rugi & progres ke TP; kalau harga sudah lewat TP/SL
    ditandai) atau **Belum kena entry** (+ peluang limit tersentuh dalam 24 jam & peluang harga kabur tanpa mengisi).
    Hasil: **lebih dominan kena TP (PROFIT) / kena SL (LOSE) / 50:50** dengan peluang %, dari **backtest asli** 1000 candle
    15M koin itu (entry di setiap candle dengan jarak SL & TP yang sama; semua kondisi & kondisi tren seperti sekarang;
    TP & SL di candle yang sama = kena SL), digeser maks ±12 poin oleh cek whale & gocekan (✅ ⚠️ ❌ satu per satu:
    SL di zona gocekan, SL vs SL anti-gocekan, tembok pelindung SL, tembok penghalang TP, arah vs kekuatan pasar, alarm,
    zona tipis, RR & WR impas). Untuk yang **belum kena entry** ada **💡 saran entry, SL, TP** (entry di depan tembok
    whale asli, SL anti-gocekan, TP di depan tembok lawan) yang juga di-backtest, plus tombol **Pakai saran ini**.
    Saran **tidak pernah di bawah "Min. RR saran"** (default 1:2). Beberapa kandidat entry (depan tembok, entry kamu,
    lebih dalam di atas swing) dibandingkan dan dipilih yang **rata-rata hasil per trade** (WR × RR − kalah, dalam R,
    dikali peluang entry tersentuh) paling bagus. Kalau semuanya rata-rata rugi, saran menulis "tunggu setup lain".
    **Saran wajib lebih baik dari setup kamu**: hanya ditampilkan kalau peluang TP-nya **≥ punya kamu** DAN rata-rata
    hasil per trade-nya **lebih tinggi**. SL saran tidak lagi dipotong 4% (potongan itu bisa menaruh SL di dalam zona
    gocekan → peluang TP jatuh). Kandidat SL: SL anti-gocekan & SL kamu; TP: TP kamu & entry + Min. RR × risiko.
    Kalau tidak ada yang lebih baik, muncul "Setup kamu sudah yang terbaik dari kandidat yang dicoba".
  - **Min. nilai (USDT)** bisa diketik bebas (ada saran cepat 50 rb … 5 jt).
  - **🎯 Cari setup terbaik (scan koin)**: atur **RR** sendiri (mis. 1:2 / 1:3), arah (BUY / SELL / keduanya), jumlah koin
    (10–50 volume terbesar) dan jumlah setup ditampilkan. Untuk tiap koin & arah dicoba entry di harga sekarang, di
    depan tembok whale, dan di atas/bawah swing; SL = anti-gocekan; TP = entry + RR × risiko. Tiap kandidat di-backtest
    lalu diurutkan dari **rata-rata hasil per trade** (WR × RR − kalah) × peluang entry tersentuh. Tabel menandai
    searah / melawan tren, tembok di jalur TP, alarm, dan WR &gt; 85% (⚠️ curiga pasar satu arah). **Cek detail**
    mengisi form Cek entry & langsung menganalisanya. Selama scan berjalan, setup yang sudah ketemu **langsung tampil** (ditandai ⏳ Hasil sementara) dan terus
    diperbarui; Cek detail bisa diklik setelah scan selesai. Di halaman detail ada tombol **← Kembali ke hasil scan setup** (hasil scan disimpan, tidak perlu
    scan ulang); setup yang sudah dibuka ditandai **✓ Sudah dicek**.
    Kolom **RR** boleh diisi beberapa angka (mis. `1, 1.5, 2, 3`): semua diuji sekaligus dan muncul tabel
    **📊 Perbandingan RR per koin** (WR & rata-rata R tiap RR, 🏆 = RR terbaik koin itu). **Min. WR (%)** = hanya tampilkan
    setup dengan WR backtest minimal sekian (mis. 50%).
    **Koin di-scan** bisa diketik: angka (mis. `300` = 300 koin volume terbesar; `semua` = semua koin USDT perpetual; di atas ±100 koin scan
    jalan pelan ±25–30 koin/menit karena batas permintaan Binance). Jumlahnya **pas**: koin yang gagal / datanya belum cukup
    (mis. koin baru listing) otomatis diganti koin berikutnya di urutan volume, jadi minta 500 = 500 koin ter-scan atau nama koin dipisah koma
    (mis. `btc, eth, sol` — "USDT" ditambahkan otomatis). Koin yang tidak ada / gagal diambil disebut di baris status.
  - **⚙️ Threshold** (di bawah tombol Cari setup terbaik): semua angka yang dipakai Cari setup, Cek entry & pelacak
    whale bisa diubah dari tampilan (±48 angka: tembok whale, swing & gocekan, SL anti-gocekan, kandidat entry, backtest WR,
    kekuatan pasar, alarm, aturan saran). Arahkan mouse ke label untuk penjelasan & nilai default; yang beda dari default
    ditandai kuning. Disimpan di `saved/whale_config.json`; angka di luar batas aman otomatis disesuaikan.
    Pilihan **"Kalau SL lebih jauh dari batas" = tolak** membuat Cari setup melewati koin yang SL anti-gocekannya
    harus dipotong (daripada SL masuk zona gocekan). Spesifikasi lengkap: `docs/spesifikasi_setup_finder.md`.
  - Backtest entry (cek entry, saran, scan setup): SL &lt; 1.5% pakai ±15 hari candle 15M (batas 2 hari per trade),
    SL lebar pakai ±62 hari candle 1H (batas 5 hari). Trade yang **belum kena TP dalam batas waktu dihitung tidak
    menang** (bukan dibuang), supaya WR tidak terlalu bagus.
  - **SL anti-gocekan** LONG / SHORT: di luar swing terdekat + kedalaman 90% gocekan, di balik tembok asli, melewati
    angka bulat, maksimal 4% dari harga. SL ini juga dipakai di kartu Rencana SL & TP.

- Catatan: tembok bisa ditarik kapan saja (spoofing). Pakai sebagai info tambahan, bukan sinyal pasti.

### Screener (live)

Tab **Screener** mengambil data **langsung dari API Binance Futures** (publik, tanpa API key), khusus
kontrak **USDT perpetual yang sedang aktif** (koin delisting dan kontrak kuartalan otomatis tidak ikut).
Butuh internet, dan tidak memakai data lokal.

1. Pilih **Timeframe** (1M sampai 1W).
2. Atur **filter**. Semua filter harus terpenuhi (AND). Tiap filter terdiri dari:
   - indikator + periodenya (misalnya ADX 14),
   - operator: `≥ > ≤ <`, `antara`, `=`, `cross ↑` (baru saja memotong ke atas), `cross ↓`,
   - pembanding: **angka** (misalnya 25) atau **indikator lain** (misalnya Harga > EMA 200, EMA 50 cross ↑ EMA 200).
3. Klik **Scan**. Scan pertama butuh sekitar 10–30 detik untuk ~500 koin. Scan berikutnya jauh lebih
   cepat karena cuma mengambil candle terbaru.
4. Klik judul kolom untuk mengurutkan. Klik nama koin untuk membuka chart-nya di Manual Replay
   (pakai data lokal), atau ↗ untuk membuka halaman Binance.

Pilihan lain:
- **Hanya candle yang sudah close:** tanpa centang, nilai dihitung termasuk candle yang sedang berjalan
  (seperti TradingView, angkanya bisa berubah sampai candle close). Dengan centang, hanya candle yang sudah close.
- **Auto refresh** 30 detik / 1 menit / 5 menit (hanya berjalan saat tab Screener terbuka).
- **Preset:** simpan kombinasi filter dengan nama, lalu pilih lagi kapan saja.
- **Export CSV:** simpan hasil ke file Excel/CSV.

Indikator yang tersedia: Harga, perubahan candle / 24 jam / 7 hari / 30 hari, volume 24 jam, volume
candle, volume ÷ rata-rata, EMA, SMA, jarak harga ke EMA (%), ADX, +DI, −DI, MACD (line/signal/histogram),
Supertrend, market structure, breakout high/low N candle, RSI, Stochastic %K/%D, CCI, Williams %R,
ROC, MFI, Force Index, ATR %, Bollinger %B dan width.

Contoh filter:
| Tujuan | Filter |
|---|---|
| Tren kuat | ADX 14 ≥ 25 |
| Tren naik kuat | ADX 14 ≥ 25, +DI 14 > −DI 14 (indikator), Harga > EMA 50 (indikator) |
| Golden cross baru terjadi | EMA 50 cross ↑ EMA 200 (indikator) |
| Oversold di tren naik | RSI 14 < 30, Harga > EMA 200 (indikator) |
| Breakout dengan volume | Breakout high 20 candle = 1, Volume ÷ rata-rata 20 ≥ 1.5 |
| Koin likuid saja | Volume 24 jam ≥ 50000000 |

Kalau muncul **"Tidak bisa terhubung ke https://fapi.binance.com"** atau **"Binance menolak akses"**,
berarti jaringan lu memblokir Binance. Coba ganti DNS ke `1.1.1.1` / `8.8.8.8`, pakai VPN, atau
jaringan lain. Screener memakai batas API Binance dengan hemat (sekitar 1000 dari 2400 weight per menit
per scan), jadi aman untuk auto refresh.

---


**Jumlah koin** (Screener): pilih 5 / 10 / 20 / 50 / 100 / 200 / semua koin. Yang dipindai koin dengan volume 24 jam
terbesar, jadi makin sedikit makin cepat (default 50). Selama scan berjalan ada panel progres: persen, jumlah koin,
waktu berjalan & sisa, koin yang baru dicek, ringkasan yang dicari, dan tips.

#### Scan market structure

Centang **Scan market structure** di Screener untuk mencari koin berdasarkan urutan swing terakhir.
- **Jumlah baris:** pilih 3, 4, 5, atau 6.
- **Isi tiap baris:** klik ▲ / ▼ seperti gembok angka untuk ganti kode: HH → HL → LH → LL → Bebas.
  - **HH** = swing high lebih tinggi dari swing high sebelumnya; **LH** = lebih rendah.
  - **HL** = swing low lebih tinggi dari swing low sebelumnya; **LL** = lebih rendah.
  - **Bebas** = apa saja.
- **Urutan:** baris 1 = swing paling lama, baris terakhir = swing terbaru. Contoh tren naik: HH → HL → HH → HL.
  Tren turun: LH → LL → LH → LL.
- **Scan candle terakhir** (default 200, maks. 1500) dan **Swing (fractal)** (default 3) bisa diubah.
  TF memakai pilihan **Timeframe** di atas.
- Swing high dan swing low dibuat selang-seling. Kalau polanya tidak mungkin (misalnya HH → HL → HL), muncul peringatan.
- Mengklik ▲ / ▼ atau mengganti jumlah baris otomatis mencentang **Scan market structure**. Di bawah gembok tertulis
  ✅ Aktif / ⛔ Mati, dan status hasil scan juga menyebut kalau scan struktur sedang mati.
- **Min. besar swing (×ATR)** (default 1): swing yang jaraknya dari swing sebelumnya lebih kecil dari N × ATR14
  diabaikan, supaya struktur mikro (pantulan kecil di dalam tren besar) tidak dihitung. Naikkan (mis. 2–3) atau pakai
  swing fractal lebih besar / TF lebih tinggi untuk membaca struktur yang lebih besar.
- **Hitung swing yang sedang berjalan** (default aktif): gerakan terakhir yang belum terkonfirmasi (belum ada N candle
  di kanannya) ikut dihitung sebagai swing sementara, ditandai `*` (mis. `LL*`). Jadi kalau harga baru saja menembus
  swing low terakhir, struktur langsung terlihat patah, tidak menunggu konfirmasi.
- Kolom hasil: **Struktur (lama → baru)** dan **Swing terakhir (candle lalu)**. Filter biasa tetap ikut berlaku.

## 7. Kalau ada masalah

| Masalah | Solusi |
|---|---|
| `python` is not recognized / membuka Microsoft Store | Python belum masuk PATH. Instal ulang Python dan centang **Add python.exe to PATH**. Atau ganti `python` dengan `py` di perintah. Setelah instal, tutup lalu buka lagi PowerShell |
| Jendela `run.bat` langsung tertutup / error `No module named uvicorn` | Jalankan `install.bat` |
| Saat backtest semua koin / Studi Fibonacci muncul `OpenBLAS error: Memory allocation still failed`, `MemoryError`, atau `UnpicklingError` | RAM habis karena terlalu banyak proses paralel. Sejak v3.9 numpy dibatasi 1 thread per proses dan default "Proses paralel" disesuaikan dengan RAM bebas (maks. 8). Kalau masih terjadi, isi **Proses paralel** dengan angka kecil (2–4) dan tutup aplikasi berat lain (browser dengan banyak tab, game) |
| Muncul "Masih ada proses berjalan…" | Hanya satu proses berat (semua koin / uji saran / studi) yang boleh jalan sekaligus. Pilih OK untuk membatalkan proses lama, atau tunggu sampai selesai. Kalau halaman di-refresh saat proses berjalan, tampilannya otomatis tersambung lagi |
| Error `address already in use` / `[Errno 10048]` | `run.bat` lama masih terbuka. Tutup semua jendela hitam, lalu jalankan lagi |
| Muncul "Tidak ada file .npz di ..." | Folder data salah atau kosong. Cek `DATA_DIR` di `config.bat`, atau jalankan `update_data.bat` |
| Tampilan masih versi lama setelah update | Tutup `run.bat`, jalankan lagi, tekan **Ctrl+F5** di browser. Pastikan tidak terjadi folder dobel `D:\backtester\backtester` |
| Download data gagal / berhenti | Jalankan `update_data.bat` lagi; yang sudah selesai tidak diulang. Kalau terus gagal, coba jaringan lain (beberapa provider memblokir Binance) |
| Koin baru belum muncul | Jalankan `update_data.bat`, lalu restart `run.bat` |
| Scan / analisa apa pun (Screener, Whale, Market Structure, Jurnal, Flow): "Tidak bisa terhubung" / "Binance menolak akses" / scan gagal terus | Binance memblokir IP jaringan lu. **Nyalakan VPN** lalu scan lagi. Tanpa VPN: ganti DNS (1.1.1.1 / 8.8.8.8) atau coba jaringan lain |
| HP tidak bisa membuka alamat dari tombol 📱 HP | Pastikan memakai `run_hp.bat` (bukan `run.bat`), HP dan PC di Wi-Fi yang sama, dan firewall Windows mengizinkan Python di **Private networks** (Windows Security → Firewall → Allow an app). Wi-Fi kantor/kafe sering memblokir antar perangkat: pakai Tailscale |
| HP terus minta PIN / "Butuh PIN" | Masukkan PIN sesuai `ACCESS_PIN` di `config.bat`. Kalau lupa, hapus barisnya lalu jalankan ulang `run_hp.bat` |
| Chart kosong / hitam | Tekan Ctrl+F5. Kalau masih, buka `http://127.0.0.1:8000/api/version` dan lihat error di jendela hitam |

Cek kualitas data (opsional):
```powershell
cd D:\backtester
python tools\validate_data.py "D:\Data Candle Binance\all" BTCUSDT ETHUSDT
```
Menampilkan jumlah gap dan apakah TF besar cocok dengan gabungan M5 (`beda_vs_5m` harus 0).

---

## 8. Detail teknis

Format data: `{SIMBOL}_{tf}.npz` dengan key `t,o,h,l,c,v`, di mana `t` = open time (ms, UTC)
dan `v` = volume dalam koin.

Aturan simulasi (sama di Manual Replay dan Auto Backtest):

| Hal | Aturan |
|---|---|
| Waktu | Maju per candle M5; candle TF apa pun terlihat hanya kalau sudah close |
| Order baru | Aktif mulai candle berikutnya (tidak bisa fill di candle yang sudah terlihat) |
| Market | Harga open candle berikutnya ± slippage, fee taker |
| Limit (menunggu) | Fill di harga limit kalau harga **menembus** limit (opsi: cukup menyentuh), fee maker |
| Limit yang langsung kena | Fill di harga pasar, fee taker |
| Stop | Trigger saat tersentuh; fill di harga stop, atau di harga open kalau gap (lebih jelek) + slippage |
| Urutan harga dalam candle | Candle hijau O→L→H→C, merah O→H→L→C; mode pesimis = arah yang merugikan posisi |
| TP / SL | Aktif sejak titik entry, satu kena yang lain batal (OCO), reduce-only |
| Margin | Default **mati**: order tidak dibatasi margin, tidak ada likuidasi |
| Likuidasi (kalau margin dinyalakan) | Isolated, `entry × (1 ∓ 1/leverage ± mmr)` |

Belum disimulasikan: funding rate, tier maintenance margin Binance, mark price, partial fill.

Tes otomatis (termasuk tes anti look-ahead):
```powershell
cd D:\backtester
python -m pytest -q
```
