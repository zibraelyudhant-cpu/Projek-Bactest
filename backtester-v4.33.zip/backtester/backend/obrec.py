"""📼 Perekam order book: Binance TIDAK menyimpan riwayat order book, jadi program merekam sendiri tembok order besar
tiap beberapa menit. Setelah cukup lama (>= ±2 minggu), rekaman bisa diuji: harga yang menyentuh tembok lebih sering
mantul dibanding level biasa? Tembok yang hilang saat harga mendekat (spoof) dipisah.

Rekaman: saved/orderbook/<SYMBOL>.jsonl, satu baris per snapshot: {"t": ms, "mid": harga, "w": [[side, price, usdt], ...]}
"""
import json
import os
import threading
import time

import numpy as np

from .indicators import atr as _atr

BASE = os.environ.get("OBREC_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "saved", "orderbook")
DEFAULTS = {"on": False, "coins": "20", "interval_min": 5, "min_usdt": 100_000, "band_pct": 3.0}
_LOCK = threading.Lock()
_ST = {"thread": None, "stop": None, "last": None, "last_n": 0, "errors": [], "syms": [], "runs": 0}


def _dir():
    os.makedirs(BASE, exist_ok=True)
    return BASE


def get_cfg():
    try:
        with open(os.path.join(_dir(), "config.json")) as f:
            return {**DEFAULTS, **json.load(f)}
    except (OSError, ValueError):
        return dict(DEFAULTS)


def set_cfg(c):
    q = {**get_cfg(), **{k: v for k, v in (c or {}).items() if k in DEFAULTS}}
    q["on"] = bool(q["on"])
    q["interval_min"] = int(min(max(int(q["interval_min"]), 1), 60))
    q["min_usdt"] = float(min(max(float(q["min_usdt"]), 10_000), 1e9))
    q["band_pct"] = float(min(max(float(q["band_pct"]), 0.5), 10))
    q["coins"] = str(q["coins"] or "20").strip()
    with open(os.path.join(_dir(), "config.json"), "w") as f:
        json.dump(q, f)
    return q


def _symbols(c, coins):
    t = str(coins).strip()
    if t.isdigit():
        tick = c.get("/fapi/v1/ticker/24hr")
        info = c.get("/fapi/v1/exchangeInfo")
        perp = {x["symbol"] for x in info["symbols"] if x.get("contractType") == "PERPETUAL" and x.get("quoteAsset") == "USDT"
                and x.get("status") == "TRADING"}
        return [x["symbol"] for x in sorted((x for x in tick if x["symbol"] in perp), key=lambda x: -float(x["quoteVolume"]))][:max(1, min(int(t), 100))]
    L = [x.strip().upper() for x in t.replace(";", ",").replace(" ", ",").split(",") if x.strip()]
    return [x if x.endswith("USDT") else x + "USDT" for x in L][:100]


def snapshot(c, sym, min_usdt, band_pct, now=None):
    """Satu snapshot tembok (dalam +-band% dari harga tengah)."""
    d = c.get("/fapi/v1/depth", symbol=sym, limit=500)
    bids = [(float(p), float(q)) for p, q in d["bids"]]
    asks = [(float(p), float(q)) for p, q in d["asks"]]
    if not bids or not asks:
        return None
    mid = (bids[0][0] + asks[0][0]) / 2
    lo, hi = mid * (1 - band_pct / 100), mid * (1 + band_pct / 100)
    w = [["BUY", p, round(p * q, 2)] for p, q in bids if p * q >= min_usdt and p >= lo]
    w += [["SELL", p, round(p * q, 2)] for p, q in asks if p * q >= min_usdt and p <= hi]
    return {"t": int(now if now is not None else time.time() * 1000), "mid": mid, "w": w}


def record_once(c, cfg=None):
    cfg = cfg or get_cfg()
    syms = _symbols(c, cfg["coins"])
    n, errs = 0, []
    for s in syms:
        try:
            snap = snapshot(c, s, cfg["min_usdt"], cfg["band_pct"])
            if snap:
                with _LOCK, open(os.path.join(_dir(), f"{s}.jsonl"), "a") as f:
                    f.write(json.dumps(snap, separators=(",", ":")) + "\n")
                n += 1
        except Exception as ex:                                    # noqa: BLE001 - satu koin gagal tidak menghentikan
            errs.append(f"{s}: {ex}")
    _ST.update(last=int(time.time() * 1000), last_n=n, errors=errs[-10:], syms=syms, runs=_ST["runs"] + 1)
    return n


def _loop(c, stop):
    while not stop.is_set():
        cfg = get_cfg()
        if not cfg["on"]:
            break
        try:
            record_once(c, cfg)
        except Exception as ex:                                    # noqa: BLE001
            _ST["errors"] = (_ST["errors"] + [f"{type(ex).__name__}: {ex}"])[-10:]
        stop.wait(cfg["interval_min"] * 60)


def start(c):
    if _ST["thread"] and _ST["thread"].is_alive():
        return
    stop = threading.Event()
    th = threading.Thread(target=_loop, args=(c, stop), daemon=True)
    _ST.update(thread=th, stop=stop)
    th.start()


def stop():
    if _ST["stop"]:
        _ST["stop"].set()


def status():
    files = [x for x in os.listdir(_dir()) if x.endswith(".jsonl")] if os.path.isdir(BASE) else []
    n, t0, t1, size = 0, None, None, 0
    for fn in files:
        p = os.path.join(BASE, fn)
        size += os.path.getsize(p)
        with open(p) as f:
            lines = f.readlines()
        n += len(lines)
        if lines:
            a, b = json.loads(lines[0])["t"], json.loads(lines[-1])["t"]
            t0 = a if t0 is None else min(t0, a)
            t1 = b if t1 is None else max(t1, b)
    return {"cfg": get_cfg(), "running": bool(_ST["thread"] and _ST["thread"].is_alive()), "last": _ST["last"],
            "last_n": _ST["last_n"], "errors": _ST["errors"], "coins": len(files), "snapshots": n, "from": t0, "to": t1,
            "days": ((t1 - t0) / 86_400_000) if t0 and t1 else 0, "size_mb": size / 1e6, "symbols_now": _ST["syms"][:20]}


def load(sym):
    p = os.path.join(_dir(), f"{sym}.jsonl")
    if not os.path.exists(p):
        return []
    with open(p) as f:
        return [json.loads(x) for x in f if x.strip()]


# ---------------------------------------------------------------- uji tembok dari rekaman
TOUCH_TOL = 0.1           # ATR: harga dianggap menyentuh level
BOUNCE = 1.0              # ATR: mantul = bergerak menjauh 1 ATR searah tembok ...
BREAK = 0.3               # ATR: ... sebelum close menembus tembok 0.3 ATR
WAIT = 288                # candle 5m (24 jam) menunggu harga menyentuh level
MIN_SEEN = 2              # tembok "bertahan" = terlihat >= 2 snapshot berturut-turut


def _walls(snaps):
    """Gabung snapshot jadi tembok unik (side, price): kapan pertama terlihat, berapa snapshot bertahan, ukuran maks,
    dan apakah HILANG saat harga mendekat (spoof: jarak harga ke tembok turun >= 50% tapi belum menyentuh)."""
    W = {}
    prev = set()
    for k, sn in enumerate(snaps):
        cur = set()
        for side, px, usdt in sn["w"]:
            key = (side, round(px, 10))
            cur.add(key)
            w = W.setdefault(key, {"side": side, "price": px, "t0": sn["t"], "mid0": sn["mid"], "seen": 0, "usdt": 0.0,
                                   "spoof": False, "gone_t": None, "last_k": k})
            w["seen"] = w["seen"] + 1 if w["last_k"] >= k - 1 else 1
            w["last_k"], w["usdt"] = k, max(w["usdt"], usdt)
        for key in prev - cur:                                     # hilang di snapshot ini
            w = W[key]
            d0, d1 = abs(w["mid0"] - w["price"]), abs(sn["mid"] - w["price"])
            touched = (sn["mid"] <= w["price"]) if w["side"] == "BUY" else (sn["mid"] >= w["price"])
            if d0 > 0 and d1 <= 0.5 * d0 and not touched:
                w["spoof"] = True
            w["gone_t"] = sn["t"]
        prev = cur
    return list(W.values())


def _outcome(t, h, l, c, a, t_from, level, side):
    """Sesudah t_from: harga menyentuh level (<= WAIT candle)? Kalau ya: mantul (1 ATR searah tembok) atau tembus
    (close menembus 0.3 ATR) duluan. Hasil: None (tidak tersentuh) / 1 mantul / -1 tembus / 0 belum jelas."""
    i0 = int(np.searchsorted(t, t_from))
    e = min(len(c), i0 + WAIT)
    for i in range(i0, e):
        A = a[i]
        if not (A == A) or A <= 0:
            continue
        hit = (l[i] <= level + TOUCH_TOL * A) if side == "BUY" else (h[i] >= level - TOUCH_TOL * A)
        if not hit:
            continue
        for j in range(i, min(len(c), i + WAIT)):
            # candle sentuhan: high/low-nya bisa terjadi SEBELUM menyentuh -> hanya dicek tembus; mantul mulai candle berikutnya
            if side == "BUY":
                if c[j] < level - BREAK * A:
                    return -1
                if j > i and h[j] >= level + BOUNCE * A:
                    return 1
            else:
                if c[j] > level + BREAK * A:
                    return -1
                if j > i and l[j] <= level - BOUNCE * A:
                    return 1
        return 0
    return None


def wall_test(c, symbols=None, min_usdt=None):
    """Uji tembok dari rekaman: % mantul tembok (bertahan / spoof, per ukuran) vs level PEMBANDING (jarak sama dari harga,
    sisi sama, tanpa tembok) — kalau tembok tidak lebih sering mantul daripada pembanding, tembok tidak terbukti."""
    files = [x[:-6] for x in os.listdir(_dir()) if x.endswith(".jsonl")]
    syms = [s for s in (symbols or files) if s in files]
    rows = {"tembok bertahan": [], "tembok spoof (hilang saat didekati)": [], "tembok sebentar": [], "pembanding (tanpa tembok)": []}
    by_size = {}
    info = []
    for s in syms:
        snaps = load(s)
        if len(snaps) < 3:
            continue
        t_a, t_b = snaps[0]["t"], snaps[-1]["t"]
        k = []
        st = t_a - 86_400_000
        for _ in range(40):                                        # candle 5m dari awal rekaman sampai sekarang (+1 hari)
            part = c.get("/fapi/v1/klines", symbol=s, interval="5m", startTime=int(st), limit=1500)
            if not part:
                break
            k += part
            st = int(part[-1][0]) + 300_000
            if len(part) < 1500 or st > t_b + 86_400_000 * 2:
                break
        if len(k) < 50:
            continue
        t = np.array([int(r[0]) for r in k], np.int64)
        h, l, cl = (np.array([float(r[j]) for r in k]) for j in (2, 3, 4))
        a = _atr(h, l, cl, 14)
        walls = _walls(snaps)
        info.append({"symbol": s, "snapshots": len(snaps), "walls": len(walls)})
        for w in walls:
            if min_usdt and w["usdt"] < min_usdt:
                continue
            o = _outcome(t, h, l, cl, a, w["t0"], w["price"], w["side"])
            if o is None:
                continue
            grp = "tembok spoof (hilang saat didekati)" if w["spoof"] else "tembok bertahan" if w["seen"] >= MIN_SEEN else "tembok sebentar"
            rows[grp].append(o)
            if grp == "tembok bertahan":
                b = "≥ 1 jt USDT" if w["usdt"] >= 1e6 else "250 rb – 1 jt" if w["usdt"] >= 250_000 else "< 250 rb"
                by_size.setdefault(b, []).append(o)
            # pembanding: level di jarak yang sama dari harga, sisi sama, saat yang sama (tanpa tembok)
            dist = abs(w["mid0"] - w["price"])
            lvl = w["mid0"] - 0.5 * dist if w["side"] == "BUY" else w["mid0"] + 0.5 * dist
            ob = _outcome(t, h, l, cl, a, w["t0"], lvl, w["side"])
            if ob is not None:
                rows["pembanding (tanpa tembok)"].append(ob)

    def rate(L):
        m = [x for x in L if x]
        return {"n": len(m), "touched": len(L), "bounce_pct": (100 * sum(1 for x in m if x == 1) / len(m)) if m else None}
    out = {k: rate(v) for k, v in rows.items()}
    sizes = {k: rate(v) for k, v in by_size.items()}
    base, keep = out["pembanding (tanpa tembok)"], out["tembok bertahan"]
    ok = keep["n"] >= 30 and base["n"] >= 30
    edge = (keep["bounce_pct"] - base["bounce_pct"]) if ok else None
    return {"groups": out, "sizes": sizes, "coins": info, "edge": edge, "enough": ok,
            "verdict": ("belum cukup rekaman (butuh >= 30 sentuhan tembok bertahan & pembanding)" if not ok else
                        "tembok TERBUKTI lebih sering memantulkan harga" if edge >= 5 else
                        "tembok TIDAK terbukti lebih kuat dari level biasa"),
            "rules": {"touch_atr": TOUCH_TOL, "bounce_atr": BOUNCE, "break_atr": BREAK, "wait_hours": WAIT * 5 / 60, "min_seen": MIN_SEEN}}
