"""Evaluasi strategi sesudah backtest: kenapa trade kalah, dan saran perbaikan.

Analisa ini sengaja MELIHAT harga sesudah trade selesai (apa yang terjadi setelah kena SL / TP).
Itu boleh karena hanya untuk evaluasi; strategi sendiri tetap tidak pernah melihat data masa depan.

Alur: diagnose() per koin -> hasil mentah yang bisa dijumlah antar koin (merge) -> advise() jadi laporan.
"""
import math

import numpy as np

from .data import TF_MS
from .indicators import adx, atr, bos_bias
from .mining import analyze

CATS = {   # urutan = urutan prioritas klasifikasi trade kalah
    "stop_hunt": ("SL kena sweep tipis, lalu harga lanjut ke TP",
                  "Arah dan entry sudah benar, tapi SL terlalu dekat / tepat di area likuiditas."),
    "early_entry": ("Arah benar, tapi entry terlalu awal",
                    "Harga turun jauh melewati SL dulu, baru kemudian berbalik ke TP. Entry belum di titik terbaik."),
    "near_tp": ("Sudah hampir TP, lalu berbalik ke SL",
                "Trade sempat profit besar (≥ 70% jalan ke TP) tapi tidak diamankan."),
    "htf_against": ("Melawan struktur TF besar saat entry",
                    "Struktur (Break of Structure terakhir) di TF besar berlawanan dengan arah trade."),
    "htf_reversal": ("TF besar berbalik setelah entry",
                     "Saat entry struktur TF besar searah, tapi lalu patah ke arah berlawanan: masuk di ujung tren."),
    "ltf_against": ("Struktur TF eksekusi masih melawan",
                    "TF besar searah, tapi struktur di TF eksekusi belum berbalik (belum ada BOS/CHoCH searah)."),
    "chop": ("Pasar sideways", "ADX TF besar di bawah 20 saat entry: tidak ada tren yang jelas."),
    "noise": ("Setup valid tapi gagal", "Struktur TF besar & kecil searah, pasar tren. Kalah yang wajar."),
    "fee_loss": ("Kena TP tapi rugi karena fee", "Jarak TP terlalu kecil dibanding fee + slippage."),
    "other_exit": ("Ditutup strategi / akhir tes", "Trade tidak keluar lewat SL/TP."),
}

NEXT_TF = {"5m": "1h", "15m": "1h", "30m": "4h", "1h": "4h", "2h": "1d", "4h": "1d", "6h": "1d",
           "8h": "1d", "12h": "1d", "1d": "1d"}
BIGGER = {"5m": "15m", "15m": "1h", "30m": "1h", "1h": "4h", "2h": "4h", "4h": "1d", "6h": "1d",
          "8h": "1d", "12h": "1d"}


def tfs_of(params, cls_tf):
    """(TF eksekusi, TF besar, nama parameter TF besar) dari parameter strategi."""
    exec_tf = params.get("tf") or params.get("confirm_tf") or cls_tf
    for k in ("trend_tf", "htf", "bias_tf"):
        if params.get(k) and params[k] != exec_tf:
            return exec_tf, params[k], k
    return exec_tf, NEXT_TF.get(exec_tf, "1d"), None


B_ATR = [round(0.1 * i, 1) for i in range(61)]     # 0 .. 6 ATR


def _bin(v):
    return min(int(v / 0.1), len(B_ATR) - 1)


def _q(hist, q):
    """Kuantil dari histogram ATR (nilai batas atas bin)."""
    tot = sum(hist)
    if not tot:
        return None
    c = 0
    for i, h in enumerate(hist):
        c += h
        if c >= q * tot:
            return round(0.1 * (i + 1), 1)
    return B_ATR[-1]


class _Closed:
    """Candle TF tertentu yang sudah close sebelum waktu `ms` (sama seperti yang dilihat strategi)."""

    def __init__(self, store, sym, tf):
        self.b = store.get(sym, tf)
        self.dur = TF_MS[tf]

    def last(self, ms, n=300):
        k = int(np.searchsorted(self.b.t, ms - self.dur, side="right"))
        s = max(0, k - n)
        return self.b.h[s:k], self.b.l[s:k], self.b.c[s:k]

    def atr_at(self, ms):
        if not hasattr(self, "_atr"):
            self._atr = atr(self.b.h, self.b.l, self.b.c, 14)
        k = int(np.searchsorted(self.b.t, ms - self.dur, side="right")) - 1
        v = self._atr[k] if k >= 0 else np.nan
        return float(v) if np.isfinite(v) and v > 0 else None

    def bias(self, ms, swing=3):
        h, l, c = self.last(ms)
        return bos_bias(h, l, c, swing) if len(c) > 4 * swing else 0

    def adx(self, ms):
        h, l, c = self.last(ms, 150)
        if len(c) < 45:
            return None
        v = adx(h, l, c, 14)[-1]
        return float(v) if np.isfinite(v) else None


def _first(mask):
    i = int(np.argmax(mask)) if len(mask) else 0
    return i if len(mask) and mask[i] else None


def _rate(e):
    return {"n": e["n"], "win_rate": 100 * e["w"] / e["n"] if e["n"] else 0.0, "pnl": e["pnl"],
            "pf": e["gw"] / e["gl"] if e["gl"] else None}


def diagnose(store, sym, res, cls_tf):
    """Klasifikasi tiap trade. Return (raw, labels): raw bisa dijumlah antar koin, labels = kategori per trade."""
    params = res.get("params") or {}
    exec_tf, htf, _ = tfs_of(params, cls_tf)
    base_tf = store.base_tf(sym)
    b = store.get(sym, base_tf)
    bms = TF_MS[base_tf]
    k = max(1, TF_MS.get(exec_tf, bms) // bms)
    H, X = _Closed(store, sym, htf), _Closed(store, sym, exec_tf)

    raw = {"trades": 0, "losses": 0, "wins": 0, "cats": {}, "wcats": {}, "sides": {}, "hours": {}, "tags": {},
           "f_htf": {}, "f_ltf": {}, "f_adx": {}, "exp": {"stop_hunt": 0.0, "near_tp": 0.0, "tp_too_close": 0.0},
           "fees": 0.0, "gross_win": 0.0, "gross_loss": 0.0, "max_streak": 0, "mfe_loss_r": 0.0, "n_mfe": 0,
           "cont_r": 0.0, "n_cont": 0, "missed": 0, "missed_win": 0, "missed_loss": 0, "limit_trades": 0,
           "exec_tf": {exec_tf: 1}, "htf": {htf: 1},
           # presisi entry / SL / TP dalam ATR TF eksekusi (histogram 0..6 ATR, langkah 0.1)
           "prec": {"win_mae": [0] * len(B_ATR) , "loss_mfe": [0] * len(B_ATR), "sl_atr": 0.0, "tp_atr": 0.0, "n": 0}}
    labels, streak = [], 0
    ALIGN = {1: "searah", -1: "melawan", 0: "netral"}

    def add(d, key, pnl, win):
        e = d.setdefault(key, {"n": 0, "w": 0, "pnl": 0.0, "gw": 0.0, "gl": 0.0})
        e["n"] += 1
        e["w"] += int(win)
        e["pnl"] += pnl
        e["gw" if pnl > 0 else "gl"] += abs(pnl)

    for tr in res["trades"]:
        pnl, d = tr["pnl"], 1 if tr["side"] == "long" else -1
        why0 = tr.get("exit_reason")
        win = why0 == "tp" if why0 in ("tp", "sl") else pnl > 0      # teknikal: kena TP = menang, kena SL = kalah
        raw["trades"] += 1
        raw["fees"] += tr.get("fees", 0.0)
        raw["gross_win" if win else "gross_loss"] += abs(pnl)
        streak = 0 if win else streak + 1
        raw["max_streak"] = max(raw["max_streak"], streak)
        add(raw["sides"], tr["side"], pnl, win)
        add(raw["hours"], str((tr["entry_time"] // 3_600_000) % 24), pnl, win)
        add(raw["tags"], tr.get("tag") or "-", pnl, win)
        if tr.get("order_type") == "limit":
            raw["limit_trades"] += 1

        # kondisi pasar saat sinyal (hanya candle yang sudah close saat itu)
        st = tr.get("signal_time") or tr["entry_time"]
        hb, lb, a = H.bias(st) * d, X.bias(st) * d, H.adx(st)
        ab = "-" if a is None else "< 20" if a < 20 else "20-25" if a < 25 else "> 25"
        add(raw["f_htf"], ALIGN[hb], pnl, win)
        add(raw["f_ltf"], ALIGN[lb], pnl, win)
        add(raw["f_adx"], ab, pnl, win)
        info = {"htf": ALIGN[hb], "ltf": ALIGN[lb], "adx": None if a is None else round(a, 1)}

        entry, sl, tp, why = tr["entry"], tr.get("sl"), tr.get("tp"), tr.get("exit_reason")
        i0 = int(np.searchsorted(b.t, tr["entry_time"]))
        i1 = min(int(np.searchsorted(b.t, tr["exit_time"])), len(b.t) - 1)
        span = int(np.clip(2 * (i1 - i0), 12 * k, 100 * k))
        j1 = min(len(b.t), i1 + 1 + span)
        R = abs(entry - sl) if sl else 0.0
        rr = abs(tp - entry) / R if R and tp else None
        a_x = X.atr_at(tr.get("signal_time") or tr["entry_time"]) if R else None
        if a_x and tp and why in ("tp", "sl"):
            pr = raw["prec"]
            pr["n"] += 1
            pr["sl_atr"] += R / a_x
            pr["tp_atr"] += abs(tp - entry) / a_x
            seg_l, seg_h = b.l[i0:i1 + 1], b.h[i0:i1 + 1]
            if why == "tp":       # trade menang: sejauh apa minus dulu sebelum ke TP
                mae = (entry - seg_l.min()) if d > 0 else (seg_h.max() - entry)
                pr["win_mae"][_bin(max(0.0, mae) / a_x)] += 1
            else:                 # trade kalah: sejauh apa sempat jalan searah sebelum kena SL
                mfe_p = (b.h[i0:i1].max() - entry) if d > 0 and i1 > i0 else (entry - b.l[i0:i1].min()) if i1 > i0 else 0.0
                pr["loss_mfe"][_bin(max(0.0, mfe_p) / a_x)] += 1

        if win:
            raw["wins"] += 1
            cat = "win"
            if why == "tp" and R > 0:   # setelah TP: lanjut >= 1R sebelum mundur 1R dari TP?
                fh, fl = b.h[i1 + 1:j1], b.l[i1 + 1:j1]
                back = _first(fl <= tp - R) if d > 0 else _first(fh >= tp + R)
                seg = slice(i1, i1 + 1 + (back if back is not None else len(fh)))
                ext = (b.h[seg].max() - tp) if d > 0 else (tp - b.l[seg].min())
                info["cont_r"] = round(float(ext / R), 2)
                raw["cont_r"] += max(0.0, float(ext / R))
                raw["n_cont"] += 1
                raw["exp"]["tp_too_close"] += 0.5            # jalan acak: peluang +1R sebelum -1R = 50%
                if ext >= R:
                    cat = "tp_too_close"
            raw["wcats"][cat] = raw["wcats"].get(cat, 0) + 1
            labels.append({"cat": cat, **info})
            continue

        raw["losses"] += 1
        if why == "tp":
            cat = "fee_loss"
        elif why != "sl" or not rr:
            cat = "other_exit"
        else:
            raw["exp"]["stop_hunt"] += 0.5 / (1.5 + rr)       # jalan acak: ke TP sebelum turun 0.5R lagi
            raw["exp"]["near_tp"] += 0.3 / (1 + 0.7 * rr)     # jalan acak: sempat 70% ke TP lalu kalah
            hh, ll = b.h[i0:i1], b.l[i0:i1]   # selama trade (tanpa candle kena SL)
            mfe = ((hh.max() - entry) if d > 0 else (entry - ll.min())) / R if len(hh) else 0.0
            info["mfe_r"] = round(float(mfe), 2)
            raw["mfe_loss_r"] += max(0.0, float(mfe))
            raw["n_mfe"] += 1
            fh, fl = b.h[i1:j1], b.l[i1:j1]   # sesudah SL (termasuk candle SL-nya)
            hit = _first(fh >= tp) if d > 0 else _first(fl <= tp)
            if hit is not None:
                beyond = ((sl - fl[:hit + 1].min()) if d > 0 else (fh[:hit + 1].max() - sl)) / R
                info["beyond_sl_r"] = round(float(beyond), 2)
                cat = "stop_hunt" if beyond <= 0.5 else "early_entry"
            elif mfe >= 0.7 * rr:
                cat = "near_tp"
            elif hb == -1:
                cat = "htf_against"
            elif H.bias(int(b.t[j1 - 1])) == -d:
                cat = "htf_reversal"
            elif lb == -1:
                cat = "ltf_against"
            elif a is not None and a < 20:
                cat = "chop"
            else:
                cat = "noise"
        e = raw["cats"].setdefault(cat, {"n": 0, "pnl": 0.0})
        e["n"] += 1
        e["pnl"] += pnl
        labels.append({"cat": cat, **info})

    # limit yang kadaluarsa: kalau harga ke TP tanpa pernah menyentuh harga limit = peluang yang terlewat
    for m in res.get("missed", []):
        raw["missed"] += 1
        if not m.get("tp"):
            continue
        d = 1 if m["side"] == "long" else -1
        i = int(np.searchsorted(b.t, m["expired"]))
        j = min(len(b.t), i + 100 * k)
        fh, fl = b.h[i:j], b.l[i:j]
        t_tp = _first(fh >= m["tp"]) if d > 0 else _first(fl <= m["tp"])
        t_px = _first(fl <= m["price"]) if d > 0 else _first(fh >= m["price"])
        if t_tp is not None and (t_px is None or t_tp < t_px):
            raw["missed_win"] += 1
        elif m.get("sl") and t_px is not None:
            t_sl = _first(fl[t_px:] <= m["sl"]) if d > 0 else _first(fh[t_px:] >= m["sl"])
            if t_sl is not None:
                raw["missed_loss"] += 1
    return raw, labels


def merge(a, b):
    """Jumlahkan dua hasil diagnose (antar koin). Kunci max_* diambil maksimumnya, array numpy disambung."""
    if a is None:
        return b
    if b is None:
        return a
    if "names" in a and "names" in b and a["names"] != b["names"]:
        return a   # fitur beda (TF dasar koin beda): lewati
    out = dict(a)
    for key, v in b.items():
        if key not in out or out[key] is None:
            out[key] = v
        elif v is None or isinstance(v, tuple):
            pass
        elif isinstance(v, np.ndarray):
            out[key] = np.concatenate([out[key], v])
        elif isinstance(v, list):
            out[key] = [x + y for x, y in zip(out[key], v)]
        elif isinstance(v, dict):
            out[key] = merge(out[key], v)
        elif key.startswith("max_"):
            out[key] = max(out[key], v)
        else:
            out[key] = out[key] + v
    return out


# ------------------------------------------------------------------ saran
def _try(label, params, **kw):
    ch = {k: v for k, v in kw.items() if k in params and v is not None and params[k] != v}
    return {"label": label, "params": ch} if ch else None


def _pf(e):
    return e["gw"] / e["gl"] if e and e["gl"] else (math.inf if e and e["gw"] else 0.0)


def _wr(e):
    return 100 * e["w"] / e["n"] if e and e["n"] else 0.0


def _fmt(e):
    return f"{e['n']} trade, WR {_wr(e):.0f}%"


def advise(raw, params):
    p = params or {}
    n, nl, w = raw["trades"], raw["losses"], raw["wins"]
    exec_tf = max(raw["exec_tf"], key=raw["exec_tf"].get)
    htf = max(raw["htf"], key=raw["htf"].get)
    htf_key = next((k for k in ("trend_tf", "htf", "bias_tf") if p.get(k) and p[k] != exec_tf), None)
    cats, exp = raw["cats"], raw["exp"]
    cn = lambda c: cats.get(c, {}).get("n", 0)   # noqa: E731
    out = []

    def tip(key, level, title, detail, evidence, tries):
        out.append({"key": key, "level": level, "title": title, "detail": detail, "evidence": evidence,
                    "try": [t for t in tries if t]})

    def vs_random(c, total):   # (terjadi, normalnya kalau harga acak)
        return f"{cn(c)} dari {total} ({100 * cn(c) / total:.0f}%), kalau harga acak ≈ {100 * exp[c] / total:.0f}%"

    sl_wider = {"sl_atr": round(p.get("sl_atr", 1) * 1.5, 2), "sl_atr_buffer": round(p.get("sl_atr_buffer", 0) + 0.5, 2),
                "sl_buffer_pct": round(max(p.get("sl_buffer_pct", 0) * 3, 0.15), 3)}
    deeper = ({"entry": "limit_atr", "limit_atr": 0.5} if p.get("entry") in ("market", "limit_close")
              else {"entry_at": "fib", "entry_fib": 0.618} if "entry_at" in p
              else {"entry": "limit_mid"} if p.get("entry") == "limit_level"
              else {"limit_offset_pct": round(p.get("limit_offset_pct", 0.2) * 2, 2),
                    "limit_atr": round(p.get("limit_atr", 0.5) * 2, 2)})
    ms_htf = {"ms_filter_tf": htf}
    ms_ltf = {"ms_confirm_tf": exec_tf}

    # ---- struktur pasar: bandingkan trade yang searah vs melawan BOS terakhir
    for fkey, tfname, var, label, why in (
            ("f_htf", htf, ms_htf, "Filter struktur TF besar",
             "Strategi tetap entry walau Break of Structure terakhir di {tf} berlawanan arah: filter arah "
             "(EMA / Donchian / dll.) belum menangkap struktur pasar. Tambahkan syarat entry hanya searah BOS terakhir {tf}."),
            ("f_ltf", exec_tf, ms_ltf, "Konfirmasi struktur TF eksekusi",
             "Entry dilakukan saat struktur {tf} masih melawan (belum ada CHoCH / BOS searah). Tunggu struktur {tf} "
             "berbalik dulu baru entry.")):
        f = raw[fkey]
        a, s_ = f.get("melawan"), f.get("searah")
        if not a or not s_ or a["n"] < 5 or s_["n"] < 5:
            continue
        if _wr(a) < _wr(s_) - 5:
            share_loss = (a["n"] - a["w"]) / nl if nl else 0
            tip(fkey, "high" if share_loss >= 0.25 else "medium",
                f"Salah baca struktur {tfname.upper()}: trade yang melawan struktur lebih sering kalah",
                why.format(tf=tfname.upper()),
                f"Melawan BOS {tfname.upper()}: {_fmt(a)}. Searah: {_fmt(s_)}.", [_try(label, p, **var)])
        elif _wr(a) >= _wr(s_):
            out.append({"key": fkey + "_ok", "level": "good", "title": f"Struktur {tfname.upper()} bukan penyebab utama",
                        "detail": f"Trade yang melawan BOS {tfname.upper()} hasilnya tidak lebih buruk dari yang searah, "
                                  "jadi filter struktur di TF ini kemungkinan tidak menolong.",
                        "evidence": f"Melawan: {_fmt(a)}. Searah: {_fmt(s_)}.", "try": []})

    lo = raw["f_adx"].get("< 20")
    hi = merge(raw["f_adx"].get("20-25"), raw["f_adx"].get("> 25") or {}) if raw["f_adx"].get("20-25") else raw["f_adx"].get("> 25")
    if lo and hi and lo["n"] >= 5 and hi["n"] >= 5 and _wr(lo) < _wr(hi) - 5:
        tip("chop", "medium", f"Lebih sering kalah saat pasar sideways (ADX {htf.upper()} < 20)",
            f"Saat ADX {htf.upper()} di bawah 20 tidak ada tren jelas dan setup lebih sering gagal. Tambahkan filter ADX.",
            f"ADX < 20: {_fmt(lo)}. ADX ≥ 20: {_fmt(hi)}.", [_try("Filter ADX", p, adx_filter_tf=htf, adx_filter_min=20)])

    if nl and cn("htf_reversal") >= 5 and cn("htf_reversal") / nl >= 0.25:
        tip("htf_reversal", "low", CATS["htf_reversal"][0],
            f"Struktur {htf.upper()} searah saat entry, tapi tidak lama kemudian patah. Entry sering di ujung tren: "
            "hindari entry kalau harga sudah jauh dari EMA / swing terakhir, atau minta ADX yang masih naik.",
            f"{cn('htf_reversal')} dari {nl} trade kalah ({100 * cn('htf_reversal') / nl:.0f}%)",
            [_try("ADX lebih ketat", p, adx_min=(p.get("adx_min") or 20) + 5)])

    # ---- SL / entry / TP: bandingkan dengan yang terjadi kalau harga bergerak acak
    sl_n = raw["n_mfe"]
    if sl_n and cn("stop_hunt") >= 3 and cn("stop_hunt") >= 1.3 * exp["stop_hunt"]:
        tip("stop_hunt", "high" if cn("stop_hunt") >= 2 * exp["stop_hunt"] else "medium", CATS["stop_hunt"][0],
            "Harga menyentuh SL hanya tipis (≤ 0.5R) lalu lanjut sampai TP, lebih sering dari kebetulan. SL kemungkinan "
            "diletakkan tepat di area likuiditas (di bawah swing low / di atas swing high yang jelas) sehingga ikut "
            "tersapu. Letakkan SL lebih jauh (buffer ATR), atau entry lebih dalam.",
            vs_random("stop_hunt", sl_n) + " dari trade yang kena SL",
            [_try("SL lebih lebar", p, **sl_wider), _try("Entry limit lebih dalam", p, **deeper)])
    if sl_n and cn("early_entry") >= 3 and cn("early_entry") / sl_n >= 0.12:
        tip("early_entry", "medium", CATS["early_entry"][0],
            "Arah analisa benar (harga akhirnya sampai TP), tapi sebelumnya turun jauh melewati SL. Entry dilakukan "
            "sebelum pullback selesai. Coba limit lebih dalam (zona diskon/premium lebih jauh) atau tunggu konfirmasi "
            f"di {exec_tf.upper()} (CHoCH / BOS kecil searah).",
            f"{cn('early_entry')} dari {sl_n} trade yang kena SL ({100 * cn('early_entry') / sl_n:.0f}%)",
            [_try("Entry limit lebih dalam", p, **deeper), _try("Konfirmasi struktur TF eksekusi", p, **ms_ltf)])
    if sl_n and cn("near_tp") >= 3 and cn("near_tp") >= 1.3 * exp["near_tp"]:
        tip("near_tp", "medium", CATS["near_tp"][0],
            "Trade sempat berjalan ≥ 70% ke TP lalu berbalik sampai SL, lebih sering dari kebetulan. Target terlalu jauh "
            "untuk karakter koin ini: coba RR lebih kecil, atau (kalau manual) geser SL ke titik impas setelah 1R.",
            vs_random("near_tp", sl_n) + " dari trade yang kena SL",
            [_try("TP lebih dekat", p, rr=max(1.0, round(p.get("rr", 2) - 0.5, 2)), tp_ext=1.0)])
    nc, tc = raw["n_cont"], raw["wcats"].get("tp_too_close", 0)
    if nc >= 10 and tc >= 1.25 * exp["tp_too_close"]:
        tip("tp_too_close", "medium", "TP terlalu dekat",
            f"Setelah kena TP, harga lebih sering lanjut sejauh jarak SL lagi daripada balik (rata-rata lanjut "
            f"{raw['cont_r'] / nc:.1f}× jarak SL). Target bisa dipasang lebih jauh (RR / Fibonacci extension lebih besar).",
            f"{tc} dari {nc} trade menang ({100 * tc / nc:.0f}%), kalau harga acak ≈ 50%",
            [_try("TP lebih jauh", p, rr=round(p.get("rr", 2) + 1, 2), tp_ext=1.618)])
    m, mw, ml = raw["missed"], raw["missed_win"], raw["missed_loss"]
    if m >= 5 and mw > ml and mw / m >= 0.3:
        tip("missed", "medium", "Limit sering tidak terisi, padahal harga lanjut ke TP",
            f"Harga langsung ke TP tanpa menyentuh harga limit. Limit terlalu dalam atau terlalu cepat batal "
            f"({p.get('expire_bars', '?')} candle).",
            f"{m} limit kadaluarsa: {mw} jadi peluang terlewat (ke TP), {ml} justru selamat (kalau terisi kena SL)",
            [_try("Limit lebih dangkal", p, entry="limit_close"),
             _try("Kadaluarsa lebih lama", p, expire_bars=int(p.get("expire_bars", 6) * 2))])
    elif m >= 5 and ml > mw:
        out.append({"key": "missed_good", "level": "good", "title": "Limit yang batal kebanyakan menyelamatkan",
                    "detail": "Order limit yang tidak terisi lebih sering akan kena SL kalau terisi. Entry limit + "
                              "kadaluarsa bekerja sebagai filter yang baik.",
                    "evidence": f"{m} limit kadaluarsa: {ml} akan kena SL, {mw} akan ke TP", "try": []})

    for side, other in (("long", "short"), ("short", "long")):
        s_, o = raw["sides"].get(side), raw["sides"].get(other)
        if s_ and o and s_["n"] >= 10 and _wr(s_) < _wr(o) - 10:
            tip("side_" + side, "medium", f"Sisi {side.upper()} jauh lebih sering kalah dari {other.upper()}",
                f"Bisa jadi pasar periode ini condong satu arah, atau sinyal {side} strategi ini memang lemah.",
                f"{side.upper()}: {_fmt(s_)}. {other.upper()}: {_fmt(o)}.", [_try(f"Hanya {other.upper()}", p, **{side: False})])

    if n >= 40:
        wr_all = 100 * w / n
        bad = sorted([(int(h), e) for h, e in raw["hours"].items() if e["n"] >= max(6, n // 30) and _wr(e) < wr_all - 12],
                     key=lambda x: _wr(x[1]))[:4]
        if bad:
            tip("hours", "low", "Kalah terkonsentrasi di jam tertentu (UTC)",
                "Kalau polanya sama di banyak koin, pertimbangkan filter sesi (hindari jam sepi likuiditas).",
                ", ".join(f"{h:02d}:00 ({e['n']} trade, WR {_wr(e):.0f}%)" for h, e in bad), [])

    precision = None
    pr = raw.get("prec")
    if pr and pr["n"] >= 20:
        sl_m, tp_m = pr["sl_atr"] / pr["n"], pr["tp_atr"] / pr["n"]
        wm50, wm80, wm90 = _q(pr["win_mae"], 0.5), _q(pr["win_mae"], 0.8), _q(pr["win_mae"], 0.9)
        lm50 = _q(pr["loss_mfe"], 0.5)
        precision = {"n": pr["n"], "sl_atr": sl_m, "tp_atr": tp_m, "win_mae50": wm50, "win_mae80": wm80,
                     "win_mae90": wm90, "loss_mfe50": lm50, "tf": exec_tf}
        if wm80 and sl_m < 0.9 * wm80:
            tip("sl_tight", "high" if sl_m < 0.7 * wm80 else "medium", "SL terlalu ketat (sering kena sweep dulu)",
                f"Dari trade yang akhirnya kena TP, 20% sempat bergerak melawan lebih dari {wm80} ATR dulu. SL kamu rata-rata "
                f"{sl_m:.1f} ATR, jadi setup yang sebenarnya benar ikut kena SL. Pasang SL minimal ±{wm80} ATR dari entry.",
                f"SL rata-rata {sl_m:.1f} ATR {exec_tf.upper()} · 80% trade menang minus maksimal {wm80} ATR",
                [_try("SL sesuai gerak trade menang", p, sl_mult=round(wm80 / sl_m, 2))])
        elif wm90 and sl_m > 1.6 * wm90:
            tip("sl_loose", "low", "SL lebih jauh dari yang dibutuhkan",
                f"90% trade yang akhirnya kena TP tidak pernah melawan lebih dari {wm90} ATR, tapi SL kamu {sl_m:.1f} ATR. "
                "Invalidasi setup bisa dipasang lebih dekat.",
                f"SL rata-rata {sl_m:.1f} ATR · 90% trade menang minus maksimal {wm90} ATR",
                [_try("SL lebih dekat", p, sl_mult=round(wm90 / sl_m, 2))])
        if wm50 and sl_m and wm50 >= 0.3:
            sh = round(min(0.5, wm50 / sl_m) / 0.05) * 0.05
            tip("entry_early", "medium" if wm50 >= 0.5 else "low", "Entry kurang presisi (masuk terlalu awal)",
                f"Separuh trade yang akhirnya kena TP sempat minus ≥ {wm50} ATR dulu setelah entry. Limit entry sekitar "
                f"{wm50} ATR lebih dalam akan lebih dekat ke titik balik yang sebenarnya.",
                f"Median trade menang minus {wm50} ATR sebelum ke TP",
                [_try("Entry lebih dalam", p, entry_shift_r=round(sh, 2))] if sh >= 0.05 else [])
    if n < 30:
        out.insert(0, {"key": "sample", "level": "info", "title": "Sampel trade masih sedikit",
                       "detail": f"Baru {n} trade. Kesimpulan di bawah belum kuat; coba periode lebih panjang atau semua koin.",
                       "evidence": "", "try": []})
    rank = {"info": 0, "high": 1, "medium": 2, "low": 3, "good": 4}
    out.sort(key=lambda x: rank.get(x["level"], 9))

    loss_rows = [{"key": c, "label": CATS[c][0], "desc": CATS[c][1], "n": e["n"], "pnl": e["pnl"],
                  "share": 100 * e["n"] / nl if nl else 0,
                  "random": 100 * exp[c] / raw["n_mfe"] if c in exp and raw["n_mfe"] else None}
                 for c, e in cats.items()]
    loss_rows.sort(key=lambda r: -r["n"])
    seen, variants = set(), []
    for t in out:
        for v in t["try"]:
            key = tuple(sorted(v["params"].items()))
            if key not in seen:
                seen.add(key)
                variants.append(v)
    deep, plan = None, []
    if raw.get("mine"):
        try:
            deep = analyze(raw["mine"], p, exec_tf, htf)
            plan = _plan(deep, p) if deep.get("enough") else []
        except Exception as ex:   # analisa mendalam gagal tidak boleh menggagalkan evaluasi
            deep = {"enough": False, "message": f"Analisa mendalam gagal: {type(ex).__name__}: {ex}"}
    plan_vars = [s["variant"] for s in plan if s.get("variant")]
    keys = {tuple(sorted(v["params"].items())) for v in plan_vars}
    variants = plan_vars + [v for v in variants if tuple(sorted(v["params"].items())) not in keys]
    pf = raw["gross_win"] / raw["gross_loss"] if raw["gross_loss"] > 0 else None
    return {"deep": deep, "plan": plan, "precision": precision, "trades": n, "losses": nl, "wins": w, "profit_factor": pf, "exec_tf": exec_tf, "htf": htf,
            "loss_causes": loss_rows,
            "tp_cont": {"n": nc, "more": tc, "avg_r": raw["cont_r"] / nc if nc else None},
            "avg_mfe_loss_r": raw["mfe_loss_r"] / raw["n_mfe"] if raw["n_mfe"] else None,
            "max_streak": raw["max_streak"], "missed": m, "missed_win": mw, "missed_loss": ml,
            "context": {k: {kk: _rate(vv) for kk, vv in raw[k].items()} for k in ("f_htf", "f_ltf", "f_adx", "sides")},
            "tags": {k: _rate(v) for k, v in raw["tags"].items()} if len(raw["tags"]) > 1 else {},
            "suggestions": out, "variants": variants[:8], "cats": {k: v[0] for k, v in CATS.items()}}


def _st(x):
    return f"WR {x['win_rate']:.1f}% · {x['exp_r']:+.2f}R/trade · {x['n']} trade"


def _plan(deep, p):
    """Ubah hasil analisa mendalam jadi langkah perbaikan. Hanya yang lolos uji data terpisah yang jadi rekomendasi
    (valid=True); sisanya tetap ditampilkan sebagai 'tidak konsisten' supaya jelas sudah dicoba."""
    steps = []
    base = deep["base"]
    old_rules = (p.get("rules") or "").strip()
    join_rules = lambda txt: f"{old_rules}; {txt}" if old_rules else txt   # noqa: E731

    if deep["rules"]:
        f = deep["rules_final"]
        steps.append({
            "kind": "filter", "valid": deep["rules_valid"], "title": "Tambah filter indikator (threshold baru)",
            "why": "Kondisi indikator yang paling memisahkan trade menang dari kalah. Trade yang tidak memenuhinya adalah "
                   "sumber kekalahan berulang, jadi dibuang dengan filter ini.",
            "how": [f"{r['text']}   ← {r['label']} ({r['desc']})" for r in deep["rules"]],
            "param": {"rules": join_rules(deep["rules_text"])},
            "before": base["test"], "after": f["test"], "fit_before": base["train"], "fit_after": f["train"]})

    def tpsl(kind, title, why, b, extra=None):
        if not b:
            return
        prm = {"tp_rr": b["rr"], **({"sl_mult": b["sl_mult"]} if b["sl_mult"] != 1.0 else {}), **(extra or {})}
        steps.append({"kind": kind, "valid": b["valid"], "title": title, "why": why,
                      "how": (["Pakai juga filter indikator di atas"] if extra else []) +
                             [f"sl_mult = {b['sl_mult']:g}  (jarak SL × {b['sl_mult']:g})",
                              f"tp_rr = {b['rr']:g}  (TP = {b['rr']:g} × jarak SL)"],
                      "param": prm, "before": b["test_now"], "after": b["test"], "fit_before": b["fit_now"], "fit_after": b["fit"]})

    # entry lebih dalam (SL & TP tetap di harga semula): dinilai dari WR order yang terisi
    base_fit = _stats_fit(base)
    dps = [d for d in deep["depth"] if d["fill_pct"] >= 30 and d["fit"].get("win_rate") is not None]
    dp = max(dps, key=lambda d: d["fit"]["win_rate"]) if dps else None
    if dp and dp["fit"]["win_rate"] > base_fit + 3:
        steps.append({
            "kind": "entry", "valid": dp["test"]["n"] >= 15 and dp["test"]["win_rate"] > base["test"]["win_rate"] + 2,
            "title": "Entry limit lebih dalam (lebih presisi)",
            "why": f"Banyak trade masuk terlalu awal. Limit {dp['x']:g} × jarak SL lebih dalam (SL & TP tetap) masih terisi di "
                   f"{dp['fill_pct']:.0f}% sinyal, dan yang terisi lebih sering kena TP.",
            "how": [f"entry_shift_r = {dp['x']:g}  (entry digeser {dp['x']:g} × jarak SL ke arah SL, jadi order limit)"],
            "param": {"entry_shift_r": dp["x"]},
            "before": {"n": base["test"]["n"], "win_rate": base["test"]["win_rate"]},
            "after": {"n": dp["test"]["n"], "win_rate": dp["test"]["win_rate"]},
            "note": f"WR dihitung dari order yang terisi. Terisi {dp['fill_pct']:.0f}% sinyal."})

    for e in deep["existing"]:
        if e["action"] in ("perketat", "longgarkan"):
            steps.append({
                "kind": "existing", "valid": None,
                "title": f"{'Perketat' if e['action'] == 'perketat' else 'Longgarkan / hapus'} threshold {e['param']}",
                "why": e["text"], "how": [f"{e['param']} = {e['value']} → {e['new']}"],
                "param": {e["param"]: e["new"], **({"rsi_short": 100 - e["new"]} if e["param"] == "rsi_long" and "rsi_short" in p else {})},
                "before": e["near"], "after": e["rest"], "note": "Angka = trade di dekat batas vs sisanya (perlu Uji saran)."})
    steps.sort(key=lambda s: {True: 0, None: 1, False: 2}[s["valid"]])
    for i, s in enumerate(steps, 1):
        s["step"] = i
        if s["valid"] is not False:
            s["variant"] = {"label": f"Langkah {i}: {s['title'][:40]}", "params": s["param"]}
    return steps


def _stats_fit(base):
    n1, n2 = base["train"]["n"], base["valid"]["n"]
    return (base["train"]["win_rate"] * n1 + base["valid"]["win_rate"] * n2) / max(1, n1 + n2)
