"""🧩 Chart Pattern Screener & 🔄 Find Reversal (menu Screener).

Cara kerja (tanpa intip masa depan):
1. Swing high / low fractal k (default 3) -> urutan selang-seling. Swing baru diketahui k candle sesudahnya.
2. Setiap swing baru terkonfirmasi, swing-swing terakhir dicocokkan ke bentuk pola (toleransi dalam ATR):
   Head & Shoulders, Double / Triple Top-Bottom, Quasimodo, Wedge, Triangle (naik / turun / simetris), Rectangle,
   Flag, Pennant, Channel, Cup & Handle. Semua pola dibuat versi "turun"; versi "naik" = harga dibalik (cermin).
3. Pola baru VALID kalau ada candle yang CLOSE menembus garis pemicu (neckline / garis pola / L untuk QM) sebelum
   harga close di sisi lain (pola batal) dan sebelum batas waktu. Belum tembus = MENUNGGU (entry* sudah dihitung).
4. 🔄 Reversal: tren sebelumnya (puncak tertinggi baru + HL / lembah terendah baru + LH) -> CHoCH (close tembus HL / LH terakhir) -> swing pertama arah
   baru terkonfirmasi (LH / HL) = VALID. CHoCH tanpa konfirmasi = MENUNGGU.
5. Entry: market di close candle break, atau limit retest garis yang ditembus (QM: limit di QML).
   SL = anti-gocekan logika menu Whale (antigocek.py; live ikut tembok order book). TP = measured move (tinggi pola
   diproyeksikan dari garis yang ditembus) atau RR 1:2 / 1:3 — dipakai yang terbaik di backtest.
6. Batas waktu: TF di bawah 1H = 24 jam, TF 1H ke atas = 2 hari (lama trade & umur limit).
7. Syarat layak = seperti Whale: sampel >= 30 trade & rata-rata untung (WR x RR - kalah > 0; belum kena TP dalam batas
   waktu = tidak menang). Untung di 30% terakhir & limit tersentuh >= 70% = info.
"""
import json
import os
import time

import numpy as np

from . import antigocek as AG
from .data import TF_MS
from .indicators import atr as _atr, pivots

VERSION = 1
NAMES = {("hs", -1): "Head & Shoulders", ("hs", 1): "Inverse Head & Shoulders", ("dt", -1): "Double Top", ("dt", 1): "Double Bottom",
         ("tt", -1): "Triple Top", ("tt", 1): "Triple Bottom", ("qm", -1): "Quasimodo bearish", ("qm", 1): "Quasimodo bullish",
         ("wg", -1): "Rising Wedge", ("wg", 1): "Falling Wedge", ("fl", -1): "Bear Flag", ("fl", 1): "Bull Flag",
         ("pn", -1): "Bear Pennant", ("pn", 1): "Bull Pennant", ("tri", -1): "Descending Triangle", ("tri", 1): "Ascending Triangle",
         ("st", -1): "Symmetrical Triangle ↓", ("st", 1): "Symmetrical Triangle ↑", ("rc", -1): "Rectangle ↓", ("rc", 1): "Rectangle ↑",
         ("cn", -1): "Channel naik → break turun", ("cn", 1): "Channel turun → break naik", ("cup", 1): "Cup & Handle",
         ("rv", -1): "Reversal naik → turun", ("rv", 1): "Reversal turun → naik"}
KIND = {"hs": "reversal", "dt": "reversal", "tt": "reversal", "qm": "reversal", "wg": "reversal", "cup": "lanjutan", "fl": "lanjutan",
        "pn": "lanjutan", "tri": "lanjutan", "st": "lanjutan", "rc": "lanjutan", "cn": "reversal", "rv": "find reversal"}
VALID_TXT = {"hs": "close tembus neckline", "dt": "close tembus lembah / puncak tengah", "tt": "close tembus support / resistance tengah",
             "qm": "close tembus L (bearish) / H (bullish) setelah HH / LL = QM valid", "wg": "close keluar garis wedge",
             "fl": "close keluar channel bendera searah tiang", "pn": "close keluar pennant searah tiang", "tri": "close tembus sisi datar",
             "st": "close keluar garis segitiga", "rc": "close keluar range", "cn": "close keluar channel", "cup": "close tembus bibir cup",
             "rv": "tren (puncak tertinggi baru + HL) → CHoCH (close tembus HL / LH terakhir) → swing pertama arah baru terkonfirmasi"}
TP_MODES = ("measured", "rr2", "rr3")
TP_TXT = {"measured": "measured move", "rr2": "RR 1:2", "rr3": "RR 1:3"}
ENTRY_TXT = {"market": "market saat break", "retest": "limit retest garis yang ditembus", "qml": "limit di QML",
             "conf": "market saat terkonfirmasi"}
TOL = 0.3            # ATR: dua puncak / lembah dianggap sama
N_EXAMPLES = 150
FRESH_DEF = 10       # candle: pola valid dianggap "baru" kalau break dalam sekian candle terakhir
_CACHE = {}


# ================================================================== waktu
def window_bars(tf):
    """Batas waktu (permintaan user): TF di bawah 1H = 24 jam, TF 1H ke atas = 2 hari. Dalam candle TF itu (min 2)."""
    ms = TF_MS[tf]
    hours = 24 if ms < 3_600_000 else 48
    return max(2, int(round(hours * 3_600_000 / ms)))


# ================================================================== swing
def swings(h, l, k):
    """[(i, harga, tipe +1 high / -1 low, candle terkonfirmasi)] selang-seling (dua tipe sama berturut: ambil yang ekstrem)."""
    hi, lo = pivots(h, l, k)
    ev = sorted([(int(i), float(h[i]), 1) for i in hi] + [(int(i), float(l[i]), -1) for i in lo], key=lambda x: (x[0], -x[2]))
    out = []
    for i, p, t in ev:
        if out and out[-1][2] == t:
            if (t == 1 and p > out[-1][1]) or (t == -1 and p < out[-1][1]):
                out[-1] = (i, p, t, i + k)
            continue
        if out and out[-1][0] == i:
            continue
        out.append((i, p, t, i + k))
    return out


def _lv(line, j):
    i1, p1, i2, p2 = line[:4]
    return p1 if i2 == i1 else p1 + (p2 - p1) * (j - i1) / (i2 - i1)


# ================================================================== detektor (versi TURUN; versi naik = cermin)
def _lab(bull, bear_txt, bull_txt):
    return bull_txt if bull else bear_txt


def _det_tops(S, a, bull):
    """Head & Shoulders > Triple Top > Double Top (yang paling lengkap dipakai)."""
    out = []
    if len(S) >= 5 and [x[2] for x in S[-5:]] == [1, -1, 1, -1, 1]:
        (i1, H1, _, _), (j1, L1, _, _), (i2, H2, _, _), (j2, L2, _, _), (i3, H3, _, _) = S[-5:]
        if H2 > max(H1, H3) + 0.5 * a and abs(H1 - H3) <= 1.0 * a and min(H1, H3) - max(L1, L2) >= 0.5 * a and abs(L1 - L2) <= 1.5 * a:
            nk = (j1, L1, j2, L2)
            out.append(dict(code="hs", trig=nk, inv=(i2, H2, i2, H2), height=H2 - _lv(nk, i2),
                            pts=[(i1, H1, _lab(bull, "bahu kiri", "bahu kiri")), (i2, H2, "kepala"), (i3, H3, "bahu kanan")],
                            lines=[(j1, L1, i3, _lv(nk, i3), "neckline")],
                            shape=[(j1, L1), (i1, H1), (j1, L1), (i2, H2), (j2, L2), (i3, H3), (i3, _lv(nk, i3))], start=i1))
            return out
        hs_ = [H1, H2, H3]
        if max(hs_) - min(hs_) <= 2 * TOL * a and min(hs_) - min(L1, L2) >= 1.0 * a:
            s_ = min(L1, L2)
            out.append(dict(code="tt", trig=(j1, s_, j2, s_), inv=(i1, max(hs_), i3, max(hs_)), height=max(hs_) - s_,
                            pts=[(i1, H1, "1"), (i2, H2, "2"), (i3, H3, "3")], lines=[(j1, s_, i3, s_, _lab(bull, "support", "resistance")),
                            (i1, max(hs_), i3, max(hs_), "")], shape=[(i1, s_), (i1, H1), (j1, L1), (i2, H2), (j2, L2), (i3, H3), (i3, s_)], start=i1))
            return out
    if len(S) >= 3 and [x[2] for x in S[-3:]] == [1, -1, 1]:
        (i1, H1, _, _), (j1, L1, _, _), (i2, H2, _, _) = S[-3:]
        if abs(H1 - H2) <= TOL * a and min(H1, H2) - L1 >= 1.0 * a and i2 - i1 >= 5:
            out.append(dict(code="dt", trig=(j1, L1, j1, L1), inv=(i1, max(H1, H2), i2, max(H1, H2)), height=max(H1, H2) - L1,
                            pts=[(i1, H1, _lab(bull, "top 1", "bottom 1")), (j1, L1, _lab(bull, "lembah", "puncak")), (i2, H2, _lab(bull, "top 2", "bottom 2"))],
                            lines=[(i1, L1, i2, L1, "neckline"), (i1, H1, i2, H2, "")],
                            shape=[(i1, L1), (i1, H1), (j1, L1), (i2, H2), (i2, L1)], start=i1))
    return out


def _det_qm(S, a, bull):
    """Quasimodo turun: H -> L -> HH (lebih tinggi >= 0.3 ATR). Valid saat close tembus L (= LL). Entry limit di QML (= H)."""
    if len(S) >= 3 and [x[2] for x in S[-3:]] == [1, -1, 1]:
        (i1, H1, _, _), (j1, L1, _, _), (i2, H2, _, _) = S[-3:]
        if H2 > H1 + TOL * a and H1 - L1 >= 1.0 * a:
            return [dict(code="qm", trig=(j1, L1, j1, L1), inv=(i2, H2, i2, H2), height=H2 - L1, qml=H1,
                         pts=[(i1, H1, _lab(bull, "H", "L")), (j1, L1, _lab(bull, "L", "H")), (i2, H2, _lab(bull, "HH", "LL"))],
                         lines=[(i1, H1, i2 + 3, H1, "QML"), (j1, L1, i2 + 3, L1, "")], shape=None, start=i1)]
    return []


def _det_lines(S, a, bull):
    """Dua garis dari 5 swing terakhir: wedge naik, channel naik, triangle turun, simetris, rectangle (break ke BAWAH)."""
    if len(S) < 5:
        return []
    W = S[-5:]
    H = [(x[0], x[1]) for x in W if x[2] == 1]
    L = [(x[0], x[1]) for x in W if x[2] == -1]
    if len(H) < 2 or len(L) < 2:
        return []
    st, en = W[0][0], W[-1][0]
    if en - st < 10:
        return []
    up = (H[0][0], H[0][1], H[-1][0], H[-1][1])
    lo = (L[0][0], L[0][1], L[-1][0], L[-1][1])
    dU, dL = (H[-1][1] - H[0][1]) / a, (L[-1][1] - L[0][1]) / a
    w0, w1 = _lv(up, st) - _lv(lo, st), _lv(up, en) - _lv(lo, en)
    if w0 < 1.5 * a or w1 < 0.3 * a:
        return []
    for i, p in H:                                             # semua swing menghormati garis (sentuhan)
        if abs(p - _lv(up, i)) > 0.5 * a:
            return []
    for i, p in L:
        if abs(p - _lv(lo, i)) > 0.5 * a:
            return []
    code = None
    if dU > 0.8 and dL > 0.8:
        code = "wg" if (dL > dU + 0.5 and w1 < 0.8 * w0) else "cn" if abs(w1 - w0) <= 0.35 * w0 else None
    elif dU < -0.8 and abs(dL) <= 0.6:
        code = "tri"
    elif dU < -0.8 and dL > 0.8:
        code = "st"
    elif abs(dU) <= 0.6 and abs(dL) <= 0.6:
        code = "rc"
    if code is None:
        return []
    nm = {"wg": "", "cn": "", "tri": _lab(bull, "lantai", "atap"), "st": "", "rc": _lab(bull, "bawah range", "atas range")}[code]
    return [dict(code=code, trig=lo, inv=up, height=w0, pts=[],
                 lines=[(st, _lv(up, st), en, _lv(up, en), "trendline"), (st, _lv(lo, st), en, _lv(lo, en), nm or "trendline")],
                 shape=[(st, _lv(up, st)), (en, _lv(up, en)), (en, _lv(lo, en)), (st, _lv(lo, st))], start=st, ext=en - st)]


def _det_flag(S, a, bull):
    """Bendera / pennant turun: tiang H0 -> L0 >= 3 ATR, lalu konsolidasi L0, H1, L1, H2 (<= 50% tiang)."""
    if len(S) < 5 or [x[2] for x in S[-5:]] != [1, -1, 1, -1, 1]:
        return []
    (i0, H0, _, _), (j0, L0, _, _), (i1, H1, _, _), (j1, L1, _, _), (i2, H2, _, _) = S[-5:]
    pole = H0 - L0
    if pole < 3 * a or j0 - i0 > 30 or max(H1, H2) - L0 > 0.5 * pole or i2 - j0 > 2 * (j0 - i0) + 12 or L1 < L0 - 0.2 * a:
        return []
    lo = (j0, L0, j1, L1)
    up = (i1, H1, i2, H2)
    if H2 >= H1 - 0.2 * a and L1 >= L0 - 0.2 * a:
        code = "fl"                                            # bendera: naik pelan (melawan tiang), sejajar
    elif H2 < H1 - 0.2 * a and L1 > L0 + 0.2 * a:
        code = "pn"                                            # pennant: menyempit
    else:
        return []
    return [dict(code=code, trig=lo, inv=(i1, max(H1, H2), i2, max(H1, H2)), height=pole,
                 pts=[(i0, H0, ""), (j0, L0, _lab(bull, "tiang", "tiang"))],
                 lines=[(j0, L0, i2, _lv(lo, i2), "trendline"), (i1, H1, i2, H2, "trendline")],
                 shape=[(j0, L0), (i1, H1), (i2, H2), (i2, _lv(lo, i2))], start=i0, ext=max(6, i2 - j0))]


def _det_cup(S, a, bull):
    """Cup (dibuat dari versi terbalik): bibir L1, puncak cup Hc, bibir L2 ~ L1, handle Hh kecil. Hanya dipakai versi naik."""
    if not bull or len(S) < 4 or [x[2] for x in S[-4:]] != [-1, 1, -1, 1]:
        return []
    (j1, L1, _, _), (ic, Hc, _, _), (j2, L2, _, _), (ih, Hh, _, _) = S[-4:]
    rim = min(L1, L2)
    depth = Hc - max(L1, L2)
    if abs(L1 - L2) > 0.6 * a or depth < 2 * a or j2 - j1 < 15 or Hh - L2 > 0.5 * depth or Hh >= Hc or ih - j2 > (j2 - j1) / 2:
        return []
    return [dict(code="cup", trig=(j1, rim, ih, rim), inv=(ih, Hh, ih, Hh), height=Hc - rim,
                 pts=[(ic, Hc, "cup"), (ih, Hh, "handle")], lines=[(j1, rim, ih + 3, rim, "bibir cup")],
                 shape=[(j1, L1), (ic, Hc), (j2, L2)], start=j1)]


def _det_rev(S, a, bull):
    """Reversal naik -> turun: tren naik (H_b puncak tertinggi dari 3 high terakhir & L_a < L_b = HL), lalu L_c, H_c (LH < H_b)
    terkonfirmasi.
    Valid kalau di antara H_b dan konfirmasi H_c ada close < L_b (CHoCH)."""
    if len(S) < 7 or [x[2] for x in S[-7:]] != [1, -1, 1, -1, 1, -1, 1]:
        return []
    (ix, Hx, _, _), (ja, La, _, _), (ia, Ha, _, _), (jb, Lb, _, _), (ib, Hb, _, _), (jc, Lc, _, _), (ic, Hc, _, _) = S[-7:]
    top = max(Ha, Hb)                                           # puncak tren (boleh double top kecil: Hb ~ Ha)
    if not (top > Hx + 0.3 * a and La < Lb and Hc < top and Lc < Lb):           # tren naik: puncak tertinggi baru + HL
        return []
    return [dict(code="rv", trig=(jb, Lb, jb, Lb), inv=(ib, Hb, ib, Hb), height=Hb - Lb, rev=dict(ib=ib, hb=Hb, jb=jb, lb=Lb, ic=ic, hc=Hc),
                 pts=[(ia, Ha, _lab(bull, "HH" if Ha >= Hb else "H", "LL" if Ha >= Hb else "L")), (jb, Lb, _lab(bull, "HL", "LH")),
                      (ib, Hb, _lab(bull, "HH" if Hb > Ha else "H", "LL" if Hb > Ha else "L")),
                      (jc, Lc, "CHoCH"), (ic, Hc, _lab(bull, "LH ✓", "HL ✓"))],
                 lines=[(ja, La, jb + (jb - ja), _lv((ja, La, jb, Lb), jb + (jb - ja)), _lab(bull, "trendline naik", "trendline turun")),
                        (jb, Lb, ic + 3, Lb, "level CHoCH")], shape=None, start=ix)]


DETECTORS = (_det_tops, _det_qm, _det_lines, _det_flag, _det_cup, _det_rev)


def _mirror(x):
    neg = lambda ln: (ln[0], -ln[1], ln[2], -ln[3]) + tuple(ln[4:])      # noqa: E731
    y = dict(x)
    y["trig"], y["inv"] = neg(x["trig"]), neg(x["inv"])
    y["pts"] = [(i, -p, t) for i, p, t in x["pts"]]
    y["lines"] = [neg(ln) for ln in x["lines"]]
    y["shape"] = [(i, -p) for i, p in x["shape"]] if x.get("shape") else None
    if x.get("qml") is not None:
        y["qml"] = -x["qml"]
    if x.get("rev"):
        r = x["rev"]
        y["rev"] = dict(r, hb=-r["hb"], lb=-r["lb"], hc=-r["hc"])
    return y


def formations(h, l, c, a, k=3, codes=None):
    """Semua pola yang terbentuk (diketahui di candle f = konfirmasi swing terakhir), versi turun & naik."""
    out = []
    for bull in (False, True):
        sw = swings(-l, -h, k) if bull else swings(h, l, k)    # cermin: high cermin = -low asli
        for m in range(2, len(sw)):
            f = sw[m][3]
            if f >= len(c):
                break
            A = a[f]
            if not (A == A and A > 0):
                continue
            S = sw[max(0, m - 6):m + 1]
            for det in DETECTORS:
                for x in det(S, A, bull):
                    if codes and x["code"] not in codes:
                        continue
                    x = _mirror(x) if bull else x
                    x["dir"], x["f"], x["last"] = (1 if bull else -1), f, sw[m][0]
                    if x["code"] == "rv":
                        x["f"] = f                                   # valid = saat LH / HL terkonfirmasi
                    out.append(x)
    return out


def find_break(x, h, l, c, end=None):
    """Candle break (close tembus pemicu) atau None; status: 'break' / 'batal' / 'kadaluarsa' / 'menunggu'."""
    n = len(c) if end is None else end
    d, f = x["dir"], x["f"]
    if x["code"] == "rv":                                        # reversal: harus ada CHoCH sebelum konfirmasi
        r = x["rev"]
        seg = c[r["ib"] + 1:f + 1]
        hit = np.flatnonzero(seg < r["lb"]) if d == -1 else np.flatnonzero(seg > r["lb"])
        return (f, "break") if len(hit) else (None, "batal")
    exp = f + max(10, int(x.get("ext") or (x["last"] - x["start"])))
    j0 = max(x["last"] + 1, 0)
    for j in range(j0, min(n, exp + 1)):
        tv, iv = _lv(x["trig"], j), _lv(x["inv"], j)
        if (d == -1 and c[j] > iv) or (d == 1 and c[j] < iv):
            return None, "batal"
        if (d == -1 and c[j] < tv) or (d == 1 and c[j] > tv):
            return (j, "break") if j >= f else (None, "terlambat")  # tembus sebelum pola diketahui = tidak dipakai
    return None, ("kadaluarsa" if n > exp else "menunggu")


# ================================================================== trade
def _trade(h, l, d, f, e, sl, tp, hold, market):
    """(1 TP / -1 SL / 0 waktu habis, candle keluar) dari candle terisi f. TP & SL di candle sama = kalah."""
    n = len(h)
    end = min(n - 1, f + hold)
    if f + hold >= n:
        return None
    first = f + 1 if market else f
    for j in range(first, end + 1):
        if (d == 1 and l[j] <= sl) or (d == -1 and h[j] >= sl):
            return -1, j
        if j > f and ((d == 1 and h[j] >= tp) or (d == -1 and l[j] <= tp)):
            return 1, j
    return 0, end


def _fill(h, l, d, b, e, tp, wait):
    """Limit terisi (candle) sesudah candle break b; batal kalau harga lebih dulu sampai TP."""
    for j in range(b + 1, min(len(h), b + 1 + wait)):
        if (d == 1 and l[j] <= e) or (d == -1 and h[j] >= e):
            return j
        if (d == 1 and h[j] >= tp) or (d == -1 and l[j] <= tp):
            return None
    return None


def plan_levels(x, b, c, d):
    """Kandidat entry {nama: harga} untuk pola x yang break di candle b."""
    E = {}
    if x["code"] == "rv":
        E["conf"] = float(c[b])
        lb = x["rev"]["lb"]
        if (d == -1 and lb > c[b]) or (d == 1 and lb < c[b]):
            E["retest"] = float(lb)
        return E
    E["market"] = float(c[b])
    if x["code"] == "qm":
        q = x["qml"]
        if (d == -1 and q > c[b]) or (d == 1 and q < c[b]):
            E["qml"] = float(q)
        return E
    tv = _lv(x["trig"], b)
    if (d == -1 and tv > c[b]) or (d == 1 and tv < c[b]):
        E["retest"] = float(tv)
    return E


def tp_price(x, b, e, sl, d, mode):
    risk = abs(e - sl)
    if mode == "rr2":
        return e + d * 2 * risk
    if mode == "rr3":
        return e + d * 3 * risk
    base = x["qml"] if x["code"] == "qm" else x["rev"]["lb"] if x["code"] == "rv" else _lv(x["trig"], b)
    tp = base + d * x["height"]
    return tp if (tp - e) * d > 0.3 * risk else None


# ================================================================== riwayat (backtest)
def coin_rows(sym, t, o, h, l, c, tf, k=3):
    """Semua trade riwayat 1 koin: tiap pola yang break x tiap entry x tiap TP."""
    a = _atr(h, l, c, 14)
    g = AG.get_ctx({}, h, l, c)
    hold = wait = window_bars(tf)
    rows = []
    for x in formations(h, l, c, a, k):
        b, st = find_break(x, h, l, c)
        if b is None:
            continue
        d = x["dir"]
        for en, e in plan_levels(x, b, c, d).items():
            sl = AG.sl_at(g, b, d == 1, e)
            if sl is None:
                continue
            for mode in TP_MODES:
                tp = tp_price(x, b, e, sl, d, mode)
                if tp is None:
                    continue
                mk = en in ("market", "conf")
                f = b if mk else _fill(h, l, d, b, e, tp, wait)
                row = {"sym": sym, "t": int(t[b]), "code": x["code"], "d": d, "entry": en, "tp_mode": mode, "e": e, "sl": float(sl),
                       "tp": float(tp), "rr": abs(tp - e) / abs(e - sl), "filled": f is not None}
                if f is not None:
                    r = _trade(h, l, d, f, e, sl, tp, hold, mk)
                    if r is None:
                        continue
                    row.update(win=r[0] == 1, res={1: "TP", -1: "SL", 0: "waktu habis"}[r[0]], bars=r[1] - f, fb=f - b,
                               R=row["rr"] if r[0] == 1 else -1.0)
                elif b + wait >= len(c):
                    continue
                row["pts"] = [[int(t[i]), float(p), s_] for i, p, s_ in x["pts"] if 0 <= i < len(t)]
                rows.append(row)
    return rows


def _min_trades():
    return int(AG.whale_cfg.get()["bt.min_trades"])


def stats(rows):
    """Per (pola, arah, entry, TP): seperti Whale -> layak = sampel >= 30 & rata-rata untung (WR x RR - kalah > 0)."""
    if not rows:
        return {}
    t_split = float(np.quantile([r["t"] for r in rows], 0.7))
    G = {}
    for r in rows:
        G.setdefault((r["code"], r["d"], r["entry"], r["tp_mode"]), []).append(r)
    out = {}
    for key, R in G.items():
        F = [r for r in R if r["filled"]]
        if not F:
            continue
        Ff, Ft = [r for r in F if r["t"] < t_split], [r for r in F if r["t"] >= t_split]
        mk = key[2] in ("market", "conf")
        fill = 100.0 if mk else 100 * len(F) / len(R)
        ex = lambda X: float(np.mean([r["R"] for r in X])) if X else None        # noqa: E731
        wr = lambda X: 100 * float(np.mean([r["win"] for r in X])) if X else None  # noqa: E731
        S_ = {"code": key[0], "d": key[1], "entry": key[2], "tp_mode": key[3], "n": len(F), "n_test": len(Ft), "fill_pct": fill,
              "wr": wr(F), "wr_test": wr(Ft), "exp_r": ex(F), "exp_fit": ex(Ff), "exp_test": ex(Ft),
              "rr_med": float(np.median([r["rr"] for r in F])), "bars_med": float(np.median([r["bars"] for r in F])),
              "name": NAMES[(key[0], key[1])], "entry_txt": ENTRY_TXT[key[2]], "tp_txt": TP_TXT[key[3]]}
        S_["exp_sig"] = S_["exp_r"] * fill / 100                   # skor Whale: R x peluang tersentuh
        S_["proven"] = bool(len(Ft) >= 10 and (S_["exp_test"] or 0) > 0)
        S_["fill_ok"] = bool(mk or fill >= 70)
        S_["ok"] = bool(S_["n"] >= _min_trades() and S_["exp_r"] > 0)
        ex_ = []
        for r in sorted(R, key=lambda r: r["t"])[-N_EXAMPLES:]:
            ex_.append({k_: r.get(k_) for k_ in ("sym", "t", "e", "sl", "tp", "filled", "res", "R", "fb", "pts")} | {"test": r["t"] >= t_split})
        S_["examples"] = ex_
        out[key] = S_
    return out


def best(ST, code, d):
    """Kombinasi entry x TP terbaik untuk 1 pola (seperti Whale: layak dulu, lalu skor)."""
    C = [v for (c_, d_, _, _), v in ST.items() if c_ == code and d_ == d]
    if not C:
        return None
    return max(C, key=lambda v: (v["ok"], v["exp_sig"]))


def history_symbols(store, tf, n=30, include=None):
    syms = [s_ for s_ in store.symbols() if tf in store.timeframes(s_)] if hasattr(store, "symbols") else []
    syms.sort(key=lambda s_: -len(store.get(s_, tf).c))
    out = ([include] if include and include in syms else []) + [s_ for s_ in syms if s_ != include]
    return out[:n]


def _disk(tf, k):
    from .results_store import BASE
    return os.path.join(BASE, "cpat", f"learn_{tf}_k{k}.json")


def learn(store, tf, syms, k=3, progress=None):
    """Backtest semua pola di koin riwayat (data lokal). Disimpan di memori & file; dihitung ulang kalau data berubah."""
    key = (VERSION, tf, k, tuple(syms), tuple(int(store.get(s_, tf).t[-1]) for s_ in syms), _min_trades(), window_bars(tf),
           AG._cfg_sig(AG.whale_cfg.get()))
    if key in _CACHE:
        return _CACHE[key]
    kstr = json.dumps([list(x) if isinstance(x, tuple) else x for x in key], default=str)
    try:
        with open(_disk(tf, k), encoding="utf-8") as f_:
            D = json.load(f_)
        if D.get("key") == kstr:
            R = D["res"]
            R["stats"] = {tuple(x): v for x, v in R["stats"]}
            R["from_file"] = True
            _CACHE[key] = R
            return R
    except (OSError, ValueError, KeyError, TypeError):
        pass
    rows = []
    for i, s_ in enumerate(syms):
        if progress:
            progress(i, len(syms), s_, None)
        try:
            b = store.get(s_, tf)
            if len(b.c) < 300:
                continue
            rows += coin_rows(s_, np.asarray(b.t, np.int64), *(np.asarray(z, float) for z in (b.o, b.h, b.l, b.c)), tf, k)
        except (ValueError, KeyError, IndexError):
            continue
    res = {"stats": stats(rows), "n_rows": len(rows), "n_coins": len(syms), "coins": list(syms)}
    if len(_CACHE) > 6:
        _CACHE.clear()
    _CACHE[key] = res
    try:
        os.makedirs(os.path.dirname(_disk(tf, k)), exist_ok=True)
        tmp = _disk(tf, k) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f_:
            json.dump({"key": kstr, "saved": int(time.time() * 1000), "res": {**res, "stats": [[list(x), v] for x, v in res["stats"].items()]}},
                      f_, default=float)
        os.replace(tmp, _disk(tf, k))
    except (OSError, TypeError, ValueError):
        pass
    return res


# ================================================================== sinyal sekarang (live)
WHY_WAIT = {
    "hs": "bentuk kepala & kedua bahu sudah ada, tapi belum ada candle yang close {arah} neckline",
    "dt": "dua {puncak} sudah sama tinggi, tapi belum close {arah} {tengah} tengah",
    "tt": "tiga {puncak} sudah terbentuk, belum close {arah} {sr} tengah",
    "qm": "{urut} sudah ada, harga belum close {arah} {lv} — belum ada {ll} = belum Quasimodo (bisa jadi hanya koreksi)",
    "wg": "harga masih di dalam wedge (di antara 2 trendline)",
    "cn": "harga masih di dalam channel",
    "tri": "harga masih di dalam segitiga, belum close {arah} sisi datar",
    "st": "harga masih di dalam segitiga simetris (arah break belum diketahui)",
    "rc": "harga masih bolak-balik di dalam range",
    "fl": "bendera sedang terbentuk, harga masih di dalam channel bendera",
    "pn": "pennant sedang menyempit, harga masih di dalamnya",
    "cup": "cup sudah selesai, handle sedang terbentuk, belum close di atas bibir cup",
    "rv": "CHoCH sudah terjadi, tapi swing pertama arah baru ({sw}) belum terkonfirmasi — CHoCH tanpa konfirmasi bisa cuma koreksi",
}


def why_wait(x, trig):
    d = x["dir"]
    arah = "di bawah" if d == -1 else "di atas"
    t = WHY_WAIT[x["code"]].format(arah=arah, puncak="puncak" if d == -1 else "lembah", tengah="lembah" if d == -1 else "puncak",
                                   sr="support" if d == -1 else "resistance", urut="H → L → HH" if d == -1 else "L → H → LL",
                                   lv="L" if d == -1 else "H", ll="LL" if d == -1 else "HH", sw="LH" if d == -1 else "HL")
    return t[0].upper() + t[1:] + f". Valid kalau close {arah} {trig:.6g}."


def live_rev_waiting(h, l, c, a, k):
    """Reversal MENUNGGU: tren naik (puncak tertinggi baru + HL) lalu CHoCH (close < HL terakhir) setelah HH terakhir, tapi LH belum
    terkonfirmasi dan harga belum close di atas HH itu. Versi naik = cermin."""
    out = []
    n = len(c)
    for bull in (False, True):
        sw = swings(-l, -h, k) if bull else swings(h, l, k)
        cc = -c if bull else c
        hs_ = [x for x in sw if x[2] == 1]
        if len(hs_) < 3:
            continue
        Hb = hs_[-1]
        ph = [x for x in hs_ if x[0] < Hb[0]][-2:]
        pl = [x for x in sw if x[2] == -1 and x[0] < Hb[0]][-2:]
        if len(ph) < 2 or len(pl) < 2 or not (Hb[1] > max(ph[0][1], ph[1][1]) and pl[0][1] < pl[1][1]):
            continue
        if any(x[2] == 1 and x[0] > Hb[0] for x in sw):
            continue                                            # sudah ada swing high sesudahnya -> ditangani formations()
        Lb = pl[-1]
        hit = np.flatnonzero(cc[Hb[0] + 1:] < Lb[1])
        if not len(hit) or cc[-1] >= Hb[1]:
            continue
        j = Hb[0] + 1 + int(hit[0])
        if n - 1 - j > 40:
            continue
        x = dict(code="rv", dir=-1, f=n - 1, last=n - 1, start=ph[0][0], height=Hb[1] - Lb[1], choch=j,
                 trig=(Lb[0], Lb[1], Lb[0], Lb[1]), inv=(Hb[0], Hb[1], Hb[0], Hb[1]),
                 rev=dict(ib=Hb[0], hb=Hb[1], jb=Lb[0], lb=Lb[1], ic=n - 1, hc=float(cc[-1])),
                 pts=[(ph[1][0], ph[1][1], "LL" if bull else "HH"), (Lb[0], Lb[1], "LH" if bull else "HL"), (Hb[0], Hb[1], "LL" if bull else "HH"),
                      (j, float(cc[j]), "CHoCH")],
                 lines=[(Lb[0], Lb[1], n + 2, Lb[1], "level CHoCH")], shape=None)
        if bull:
            x = _mirror(x)
            x["dir"] = 1
        out.append(x)
    return out


def current(sym, t, o, h, l, c, tf, ST, k=3, fresh=FRESH_DEF, walls=None, codes=None):
    """Pola VALID (break dalam `fresh` candle terakhir, belum kena SL / TP) dan MENUNGGU (belum break) di candle terakhir."""
    n = len(c)
    a = _atr(h, l, c, 14)
    g = AG.Ctx(h, l, c)
    hold = wait = window_bars(tf)
    out, seen = [], set()
    from .indicators import ema as _ema
    up_now = bool(_ema(c, 20)[-1] > _ema(c, 50)[-1])                      # info jurnal: tren EMA20 vs EMA50 di TF sinyal
    trend = {"tf": tf, "dir": 1 if up_now else -1, "txt": "EMA20 > EMA50" if up_now else "EMA20 < EMA50"}
    F = [x for x in formations(h, l, c, a, k, codes) if x["f"] >= n - 200]
    if not codes or "rv" in codes:
        F += live_rev_waiting(h, l, c, a, k)
    for x in F:
        d = x["dir"]
        B = best(ST, x["code"], d)
        if x.get("choch") is not None:
            b, st = None, "menunggu"
        else:
            b, st = find_break(x, h, l, c)
        if st == "break" and n - 1 - b > fresh:
            continue
        if st not in ("break", "menunggu"):
            continue
        key = (x["code"], d, x["start"])
        if key in seen:
            continue
        seen.add(key)
        if st == "break":
            E = plan_levels(x, b, c, d)
            en = B["entry"] if B and B["entry"] in E else ("market" if "market" in E else "conf")
            mode = B["tp_mode"] if B else "measured"
            e = E[en]
            inf = AG.sl_at(g, n - 1, d == 1, e, walls, detail=True)
            if inf is None:
                continue
            tp = tp_price(x, b, e, inf["sl"], d, mode) or tp_price(x, b, e, inf["sl"], d, "rr2")
            mk = en in ("market", "conf")
            # status sejak break: sudah kena SL / TP?
            seg = slice(b + 1, n)
            if mk:
                hit_sl = (l[seg] <= inf["sl"]).any() if d == 1 else (h[seg] >= inf["sl"]).any()
                hit_tp = (h[seg] >= tp).any() if d == 1 else (l[seg] <= tp).any()
                if hit_sl or hit_tp:
                    continue
                status = "✅ valid · entry market"
            else:
                fj = _fill(h, l, d, b, e, tp, wait)
                if fj is not None or (n - 1 - b) > wait:
                    continue                                     # limit sudah tersentuh / kadaluarsa: tidak dikejar
                status = "✅ valid · pasang limit"
            trig_now = None
            why = None
        else:
            trig_now = _lv(x["trig"], n) if x["code"] != "rv" else float(c[-1])
            if x["code"] != "rv" and ((d == -1 and c[-1] < trig_now) or (d == 1 and c[-1] > trig_now)):
                continue
            # entry* = cara entry terbaik di backtest pola ini (market saat break = harga pemicu; limit retest = garis pemicu;
            # QM limit = QML; reversal = harga sekarang saat terkonfirmasi)
            en = B["entry"] if B else ("conf" if x["code"] == "rv" else "market")
            if x["code"] == "rv":
                en = "conf" if en not in ("conf", "retest") else en
                e = float(x["rev"]["lb"]) if en == "retest" else float(trig_now)
                if en == "retest" and ((d == -1 and e <= c[-1]) or (d == 1 and e >= c[-1])):
                    en, e = "conf", float(trig_now)
            elif en == "qml" and x.get("qml") is not None:
                e = float(x["qml"])
            else:
                en = "market" if en not in ("market", "retest") else en
                e = float(trig_now)
            mode = B["tp_mode"] if B else "measured"
            inf = AG.sl_at(g, n - 1, d == 1, e, walls, detail=True)
            if inf is None:
                continue
            bx = n
            tp = tp_price(x, bx, e, inf["sl"], d, mode) or tp_price(x, bx, e, inf["sl"], d, "rr2")
            status = "⏳ menunggu"
            if x["code"] == "rv":
                why = why_wait(x, 0).split(". Valid")[0] + (f". Valid kalau {'LH' if d == -1 else 'HL'} pertama terkonfirmasi ({k} candle sesudah "
                                                            f"puncaknya) tanpa close {'di atas' if d == -1 else 'di bawah'} {x['rev']['hb']:.6g}.")
            else:
                why = why_wait(x, trig_now)
            b = None
        if tp is None or (tp - e) * d <= 0:
            continue
        risk = abs(e - inf["sl"])
        out.append({"symbol": sym, "code": x["code"], "dir": d, "name": NAMES[(x["code"], d)], "kind": KIND[x["code"]],
                    "status": "valid" if b is not None else "wait", "status_txt": status, "why": why,
                    "valid_txt": VALID_TXT[x["code"]], "entry_name": en, "entry_txt": ENTRY_TXT[en], "entry_kind": "market" if en in ("market", "conf") else "limit",
                    "tp_mode": mode, "tp_txt": TP_TXT[mode], "price_entry": float(e), "price_sl": float(inf["sl"]), "price_tp": float(tp),
                    "rr": abs(tp - e) / risk if risk else None, "risk_pct": 100 * risk / e, "sl_reasons": inf["reasons"], "sl_walls": walls is not None,
                    "trigger": None if trig_now is None else float(trig_now),
                    "break_time": int(t[b]) if b is not None else None, "age": (n - 1 - b) if b is not None else None,
                    "formed_time": int(t[min(n - 1, x["f"])]), "start_time": int(t[max(0, x["start"])]),
                    "pts": [[int(t[i]), float(p), s_] for i, p, s_ in x["pts"] if 0 <= i < n],
                    "lines": [[int(t[max(0, min(n - 1, ln[0]))]), float(ln[1]), int(t[min(n - 1, ln[2])]) if ln[2] < n else int(t[-1] + (ln[2] - n + 1) * (t[-1] - t[-2])),
                               float(ln[3]), ln[4] if len(ln) > 4 else ""] for ln in x["lines"]],
                    "shape": [[int(t[max(0, min(n - 1, i))]), float(p)] for i, p in (x["shape"] or [])],
                    "stats": {k_: v for k_, v in (B or {}).items() if k_ != "examples"} if B else None, "trend": trend,
                    "examples": (B or {}).get("examples", [])})
    out.sort(key=lambda r: (r["status"] == "valid", bool(r["stats"] and r["stats"]["ok"]), (r["stats"] or {}).get("exp_sig") or -9), reverse=True)
    return out


def card_data(t, o, h, l, c, p, nbar=120):
    """Kartu visual (candle + animasi prediksi price action) seperti menu lain."""
    from . import papath as PA
    n = len(c)
    k0 = max(0, n - nbar)
    candles = [[int(t[i]), float(o[i]), float(h[i]), float(l[i]), float(c[i])] for i in range(k0, n)]
    A = float(_atr(h, l, c, 14)[-1])
    price = float(c[-1])
    S_ = p.get("stats") or {}
    wr = S_.get("wr") or 0
    outcome = "tp" if wr >= 50 else "sl"
    proj = None
    try:
        pa = PA.build(price, p["price_entry"], p["price_sl"], p["price_tp"], p["dir"] == 1, outcome,
                      int(min(200, max(3, S_.get("bars_med") or 10))), A, levels=PA.minor_levels(h, l), retr=PA.median_retrace(h, l, c),
                      fill_bars=None if p["entry_kind"] == "market" else 3, seed=sum(map(ord, p["symbol"])))
        if pa:
            lbl = f"{'✅ kena TP' if outcome == 'tp' else '❌ kena SL'} paling sering di backtest (WR {wr:.0f}%)" if S_ else "prediksi (belum ada backtest)"
            proj = {"atr": A, "path": {"pa": pa, "close": pa["close"], "p25": pa["close"], "p75": pa["close"], "n": S_.get("n") or 0,
                                       "n_all": S_.get("n") or 0, "dir": 1 if pa["close"][-1] >= 0 else -1, "label": lbl, "target_r": pa["close"][-1]}}
    except Exception:                                                    # noqa: BLE001 - animasi gagal: kartu tetap tampil
        proj = None
    return {"candles": candles, "now_price": price, "now_time": int(t[-1]), "proj": proj, "atr": A}
