"""Backtest satu strategi di banyak koin sekaligus (paralel di beberapa proses)."""
import math
import os
import time
import uuid

from .backtest import load_strategies, run_backtest
from .data import DataStore
from .engine import AccountConfig
from .evaluate import advise, diagnose, merge, tfs_of
from .mining import mine
from .pausable import PausableJobs
from .sysinfo import recommended_workers

_W = {}   # cache per proses worker: data store & strategi
MINE_CAP = 250   # maksimal trade per koin yang disimpan untuk analisa pola (sampel acak), supaya memori aman


def _worker_init(data_dir, strategy_dir):
    _W["store"] = DataStore(data_dir, cache_size=8)
    _W["strategies"] = load_strategies(strategy_dir)


def run_one(sym, strategy, params, start, end, cfg, min_days, diag=True, label=None):
    """Dijalankan di proses worker. Return ringkasan metrik satu koin (tanpa daftar trade lengkap)."""
    store = _W["store"]
    try:
        base = store.get(sym, store.base_tf(sym))
        s = base.t[0] if start is None else max(start, int(base.t[0]))
        e = base.t[-1] if end is None else min(end, int(base.t[-1]))
        days = (e - s) / 86_400_000
        if days <= 0:
            return {"symbol": sym, "label": label, "skipped": "tidak ada data di rentang tanggal ini"}
        if days < min_days:
            return {"symbol": sym, "label": label, "skipped": f"data hanya {days:.0f} hari"}
        t0 = time.time()
        cls = _W["strategies"][strategy]
        r = run_backtest(store, sym, cls, params, start, end, AccountConfig.from_dict(cfg))
        m = r["metrics"]
        pnl = [t["pnl"] for t in r["trades"]]
        # teknikal: kena TP = menang, kena SL = kalah (exit lain: dari arah harga)
        wins_t = sum(1 for t in r["trades"] if (t.get("exit_reason") == "tp") or (t.get("exit_reason") not in ("tp", "sl") and t["pnl"] > 0))
        if diag:
            raw = diagnose(store, sym, r, cls.timeframe)[0]
            exec_tf, htf, _ = tfs_of(r["params"], cls.timeframe)
            raw["mine"] = mine(store, sym, r, exec_tf, htf, cap=MINE_CAP, seed=sum(map(ord, sym)))
        return {"symbol": sym, "label": label, "diag": raw if diag else None, "days": round(days, 1) if days < 10 else round(days), "trades": m["trades"], "win_rate": m["win_rate"],
                "profit_factor": m["profit_factor"], "net_pnl": m["net_pnl"], "return_pct": m["return_pct"],
                "max_drawdown_pct": m["max_drawdown_pct"], "expectancy": m["expectancy"], "fees": m["fees"],
                "gross_win": sum(x for x in pnl if x > 0), "gross_loss": -sum(x for x in pnl if x <= 0),
                "wins": wins_t, "losses": m["trades"] - wins_t,
                "wr": 100 * wins_t / m["trades"] if m["trades"] else 0.0, "seconds": round(time.time() - t0, 1)}
    except Exception as ex:   # satu koin error tidak menghentikan yang lain
        return {"symbol": sym, "label": label, "error": f"{type(ex).__name__}: {ex}"}


def friendly_error(ex):
    from concurrent.futures.process import BrokenProcessPool
    if isinstance(ex, (MemoryError, BrokenProcessPool)) or "memory" in str(ex).lower():
        return "Proses paralel kehabisan memori (RAM). Kecilkan isian 'Proses paralel' (mis. 2–4), tutup aplikasi lain yang berat, lalu jalankan lagi."
    return f"{type(ex).__name__}: {ex}"


def summarize(rows):
    ok = [r for r in rows if "trades" in r]
    gw, gl = sum(r["gross_win"] for r in ok), sum(r["gross_loss"] for r in ok)
    trades = sum(r["trades"] for r in ok)
    return {"coins": len(ok), "coins_profit": sum(1 for r in ok if r["net_pnl"] > 0),
            "coins_with_trades": sum(1 for r in ok if r["trades"] > 0),
            "trades": trades, "net_pnl": sum(r["net_pnl"] for r in ok), "fees": sum(r["fees"] for r in ok),
            "win_rate": 100 * sum(r["wins"] for r in ok) / trades if trades else 0.0,
            "wins": sum(r["wins"] for r in ok), "losses": trades - sum(r["wins"] for r in ok),
            "coins_wr50": sum(1 for r in ok if r["trades"] and r["wins"] / r["trades"] >= 0.5),
            "profit_factor": gw / gl if gl > 0 else (math.inf if gw > 0 else 0.0),
            "expectancy": sum(r["net_pnl"] for r in ok) / trades if trades else 0.0,
            "skipped": sum(1 for r in rows if "skipped" in r), "errors": sum(1 for r in rows if "error" in r)}


class Jobs(PausableJobs):
    """Backtest banyak koin, paralel, bisa dijeda & dilanjutkan (lihat pausable.py)."""
    KIND = "backtest"

    def __init__(self, data_dir, strategy_dir, paused_dir=None):
        self.data_dir, self.strategy_dir = data_dir, strategy_dir
        super().__init__(paused_dir)

    def start(self, symbols, strategy, params, start, end, cfg, workers=None, min_days=0, variants=None):
        """variants = [{"label", "params"}]: uji beberapa variasi parameter (di atas `params`) di semua `symbols`."""
        workers = max(1, min(int(workers or recommended_workers()), 32))
        if variants:
            tasks = [(s, {**params, **v["params"]}, v["label"], False) for v in variants for s in symbols]
        else:
            tasks = [(s, params, None, True) for s in symbols]
        job = self._new(uuid.uuid4().hex[:10], len(tasks), workers, strategy=strategy, params=params, rows=[], raw=None,
                        variants=variants, req=None, tasks=tasks, targs=(strategy, start, end, cfg, min_days))
        self._launch(job)
        return job["id"]

    def pool_init(self):
        return _worker_init, (self.data_dir, self.strategy_dir)

    def task_call(self, job, i):
        s, p, lb, dg = job["tasks"][i]
        strategy, start, end, cfg, min_days = job["targs"]
        return run_one, (s, strategy, p, start, end, cfg, min_days, dg, lb)

    def on_error(self, job, i, ex):
        return {"symbol": job["tasks"][i][0], "error": str(ex)}

    def on_result(self, job, i, row):
        if row.get("diag"):
            job["raw"] = merge(job["raw"], row["diag"])
        row.pop("diag", None)
        job["rows"].append(row)

    def finish(self, job):
        if job["raw"] and not job["variants"]:
            job["evaluation"] = advise(job["raw"], job["params"])

    def get(self, jid, since=0):
        job = self.jobs.get(jid)
        if not job:
            return None
        with self.lock:
            rows = job["rows"][since:]
            all_rows = list(job["rows"])
        return {"id": jid, "status": job["status"], "done": job["done"], "total": job["total"],
                "workers": job["workers"], "elapsed": round(self.elapsed(job), 1), "inflight": job.get("inflight", 0),
                "rows": rows, "next": since + len(rows), "summary": summarize(all_rows),
                "error": job.get("error"), "evaluation": job.get("evaluation"),
                "by_label": {v["label"]: {**summarize([r for r in all_rows if r.get("label") == v["label"]]), "params": v["params"]}
                             for v in job["variants"]} if job["variants"] else None}
