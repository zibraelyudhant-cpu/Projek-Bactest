"""Struktur candle: isi satu / beberapa candle TF besar dilihat di TF kecil (Manual Replay).

Hanya memakai data yang sudah terjadi menurut waktu replay (DataView): candle kecil yang sudah close
plus candle kecil yang sedang terbentuk. Candle besar dirakit dari candle kecil di dalam rentangnya.
"""
from .data import TF_MS

MAX_ITEMS = 12        # candle / rentang yang dibandingkan sekaligus
MAX_BARS = 2000       # candle kecil per rentang


def structure(view, low_tf, ranges, now_ms):
    if low_tf not in TF_MS:
        raise ValueError(f"TF {low_tf} tidak dikenal")
    if not ranges:
        raise ValueError("belum ada candle yang dipilih")
    if len(ranges) > MAX_ITEMS:
        raise ValueError(f"maksimal {MAX_ITEMS} candle sekaligus")
    dur = TF_MS[low_tf]
    out = []
    for r in ranges:
        t0, t1 = int(r[0]), int(r[1])
        if t1 <= t0:
            raise ValueError("rentang candle tidak valid")
        if t1 - t0 < 2 * dur:
            raise ValueError(f"TF {low_tf.upper()} terlalu besar untuk candle ini — pilih TF yang lebih kecil")
        if (t1 - t0) // dur > MAX_BARS:
            raise ValueError(f"terlalu banyak candle {low_tf.upper()} ({(t1 - t0) // dur}) — pilih TF kecil yang lebih besar")
        out.append(_one(view, low_tf, t0, t1, now_ms))
    return out


def _one(view, low_tf, t0, t1, now_ms):
    dur = TF_MS[low_tf]
    bars = [b for b in view.closed_before(low_tf, t1, MAX_BARS + 1).to_list() if b["time"] * 1000 >= t0]
    partial = False
    f = view.forming(low_tf)
    if f and t0 <= f["time"] * 1000 < t1:
        bars.append(f)
        partial = True
    item = {"t0": t0, "t1": t1, "bars": bars, "expected": (t1 - t0) // dur,
            "done": (not partial) and t1 <= now_ms}
    if not bars:
        item.update(big=None, i_high=None, i_low=None, first=None)
        return item
    hi = max(b["high"] for b in bars)
    lo = min(b["low"] for b in bars)
    ih = next(i for i, b in enumerate(bars) if b["high"] == hi)
    il = next(i for i, b in enumerate(bars) if b["low"] == lo)
    big = {"time": t0 // 1000, "open": bars[0]["open"], "high": hi, "low": lo, "close": bars[-1]["close"],
           "volume": sum(b["volume"] for b in bars)}
    first = "high" if ih < il else "low" if il < ih else "sama"
    item.update(big=big, i_high=ih, i_low=il, first=first, stats=_stats(big))
    return item


def _stats(b):
    rng = b["high"] - b["low"]
    if rng <= 0:
        return {"range_pct": 0.0, "body_pct": 0.0, "upper_pct": 0.0, "lower_pct": 0.0, "change_pct": 0.0}
    top, bot = max(b["open"], b["close"]), min(b["open"], b["close"])
    return {"range_pct": 100 * rng / b["open"], "body_pct": 100 * (top - bot) / rng,
            "upper_pct": 100 * (b["high"] - top) / rng, "lower_pct": 100 * (bot - b["low"]) / rng,
            "change_pct": 100 * (b["close"] - b["open"]) / b["open"]}
