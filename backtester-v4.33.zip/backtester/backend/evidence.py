"""Bukti tambahan untuk setiap setup entry / SL / TP: Elliott Wave, tren D1, BTC (sesuai korelasi koin), kekuatan relatif,
sapuan likuiditas (stop hunt) dan sesi. Semua dihitung TANPA intip masa depan (di candle i hanya memakai data <= i).

Bukti TIDAK menyaring sinyal. Dipakai untuk memberi kelas A / B / C:
  - tiap bukti memberi suara +1 (naik) / -1 (turun) / 0 (tidak ada / tidak jelas),
  - bobot tiap bukti dipelajari dari 70% trade awal (WR saat searah - WR saat melawan; bobot 0 kalau tidak membedakan),
  - kelas = sepertiga skor teratas (A) / tengah (B) / terbawah (C) di 70% awal,
  - WR per kelas DINILAI di 30% trade terakhir (tidak dipakai saat belajar).
Aturan Elliott memakai aturan baku (tidak dicari-cari angkanya per koin):
  impuls 1-2-3-4-5: gel.2 tidak melewati awal gel.1, gel.3 melewati puncak gel.1 & bukan yang terpendek,
  gel.4 tidak masuk wilayah gel.1; koreksi ABC: zigzag (B balik < 90% A) / flat (B >= 90% A); segitiga = 5 leg menyempit.
"""
import numpy as np

from .indicators import atr as _atr
from .indicators import ema as _ema
from .indicators import pivots as _pivots

ZZ_ATR = 2.0          # swing Elliott: harga harus berbalik >= 2 ATR dari titik ekstrem
MIN_SIDE = 30         # trade minimal di sisi searah & melawan supaya bobot bukti dinilai
MIN_GAP = 3.0         # WR searah harus lebih tinggi minimal 3 poin dari WR melawan (di 70% awal)
CORR_WIN = 96         # candle untuk korelasi ke BTC
CORR_MIN = 0.5        # korelasi minimal supaya arah BTC dihitung
RS_WIN = 24           # candle untuk kekuatan relatif terhadap BTC
SWEEP_LOOK = 3        # sapuan likuiditas di 3 candle terakhir
HTF_OF = {"1m": "15m", "3m": "15m", "5m": "1h", "15m": "1h", "30m": "4h", "1h": "4h", "2h": "4h", "4h": "1d", "6h": "1d",
          "8h": "1d", "12h": "1d", "1d": None}
TF_MS = {"1m": 60_000, "3m": 180_000, "5m": 300_000, "15m": 900_000, "30m": 1_800_000, "1h": 3_600_000, "2h": 7_200_000,
         "4h": 14_400_000, "6h": 21_600_000, "8h": 28_800_000, "12h": 43_200_000, "1d": 86_400_000}
KEYS = ("ew", "ew_htf", "d1", "btc", "rs", "sweep")
NAMES = {"ew": "Elliott TF entry", "ew_htf": "Elliott TF besar", "d1": "Tren D1", "btc": "Arah BTC", "rs": "Kekuatan vs BTC",
         "sweep": "Sapuan likuiditas", "sess": "Sesi"}
SESS = ((0, 7, "Asia"), (7, 13, "London"), (13, 21, "New York"), (21, 24, "Malam US"))


# ------------------------------------------------------------------ swing Elliott (zigzag) tanpa intip masa depan
def zigzag(h, l, a, k=ZZ_ATR):
    """Titik balik: (indeks ekstrem, harga, +1 = high / -1 = low, indeks candle saat titik itu TERKONFIRMASI).
    Juga ujung leg berjalan per candle: run_p[i] = harga ekstrem leg yang sedang berjalan (belum terkonfirmasi)."""
    n = len(h)
    piv = []
    run_p = np.full(n, np.nan)
    if n == 0:
        return piv, run_p
    fb = np.nanmean(h - l) if n else 0.0
    trend, hi_i, lo_i = 0, 0, 0
    for i in range(n):
        thr = k * (a[i] if a[i] == a[i] and a[i] > 0 else fb)
        if h[i] > h[hi_i]:
            hi_i = i
        if l[i] < l[lo_i]:
            lo_i = i
        if trend == 0:
            if h[i] - l[lo_i] >= thr and lo_i < i:
                piv.append((lo_i, float(l[lo_i]), -1, i))
                trend, hi_i = 1, i
            elif h[hi_i] - l[i] >= thr and hi_i < i:
                piv.append((hi_i, float(h[hi_i]), 1, i))
                trend, lo_i = -1, i
        elif trend == 1:                                     # leg naik berjalan: cari high, konfirmasi saat turun >= thr
            if h[hi_i] - l[i] >= thr and hi_i < i:
                piv.append((hi_i, float(h[hi_i]), 1, i))
                trend, lo_i = -1, i
        else:
            if h[i] - l[lo_i] >= thr and lo_i < i:
                piv.append((lo_i, float(l[lo_i]), -1, i))
                trend, hi_i = 1, i
        run_p[i] = h[hi_i] if trend == 1 else l[lo_i] if trend == -1 else np.nan
    return piv, run_p


def _impulse_ok(p, s):
    """p = harga titik a0..ak (k <= 5) bergantian; s = +1 impuls naik / -1 turun. Cek aturan baku sejauh titik yang ada."""
    q = [s * x for x in p]                                 # dibalik untuk impuls turun -> aturan cukup ditulis untuk naik
    k = len(q) - 1
    if k >= 1 and not q[1] > q[0]:
        return False
    if k >= 2 and not (q[0] < q[2] < q[1]):                # gel.2 tidak melewati awal gel.1
        return False
    if k >= 3 and not q[3] > q[1]:                         # gel.3 melewati puncak gel.1
        return False
    if k >= 4 and not (q[1] < q[4] < q[3]):                # gel.4 tidak masuk wilayah gel.1
        return False
    if k >= 5:
        w1, w3, w5 = q[1] - q[0], q[3] - q[2], q[5] - q[4]
        if not (w5 > 0 and w3 >= min(w1, w5)):             # gel.3 bukan yang terpendek
            return False
    if k == 4 and (q[3] - q[2]) < (q[1] - q[0]) * 0.5:     # gel.3 jauh lebih pendek dari gel.1 -> bukan impuls
        return False
    return True


def _retr(a, b, x):
    """Seberapa jauh x membalik leg a->b (0..1+)."""
    d = b - a
    return (b - x) / d if d else 0.0


def ew_state(P, x):
    """P = titik balik terkonfirmasi [(harga, +1/-1)], x = harga ekstrem leg yang sedang berjalan.
    Hasil (label, suara +1/-1/0, target harga atau None). Dicek untuk naik & turun; kalau keduanya bertentangan = belum jelas."""
    if len(P) < 2 or x is None or x != x:
        return "belum cukup swing", 0, None
    out = []
    for s in (1, -1):
        r = _ew_one(P, x, s)
        if r:
            out.append(r)
    if not out:
        if len(P) >= 5:
            pr = [p for p, _ in P[-5:]] + [x]
            legs = np.abs(np.diff(pr))
            if np.all(np.diff(legs) < 0):
                return "segitiga (konsolidasi) — tunggu tembus", 0, None
        return "hitungan belum jelas", 0, None
    votes = {r[1] for r in out}
    if len(votes) > 1:
        return f"hitungan belum jelas ({out[0][0]} / {out[1][0]})", 0, None
    lab, v, tgt = out[0]
    if tgt is not None and v and (tgt - x) * v <= 0:               # target rasio umum sudah terlewati (gelombang memanjang)
        return lab + " · target umum sudah terlewati (memanjang)", v, None
    return lab, v, tgt


def _ew_one(P, x, s):
    """Pola Elliott arah s (+1 naik) yang cocok dengan titik terakhir. Urutan: impuls selesai, gel.5, gel.4, gel.3, gel.2,
    ABC gel.C, ABC selesai."""
    up = "naik" if s == 1 else "turun"
    dn = "turun" if s == 1 else "naik"
    pr = [p for p, _ in P]
    tp = [t for _, t in P]
    lead = -s                                              # impuls naik dimulai dari titik low (-1)
    cur_dir = -tp[-1]                                      # arah leg berjalan (+1 naik)

    def tail(k, first_type):
        if len(P) < k or tp[-k] != first_type:
            return None
        return pr[-k:]
    # 1) impuls 5 gelombang selesai (a0..a5 terkonfirmasi), leg berjalan = gel. A koreksi
    a = tail(6, lead)
    if a and cur_dir == -s and _impulse_ok(a, s):
        return f"impuls {up} 5 gelombang selesai → koreksi ABC {dn} (gel. A)", -s, a[4]
    # 2) a0..a4 terkonfirmasi = gel. 1-4, leg berjalan = gel. 5
    a = tail(5, lead)
    if a and cur_dir == s and _impulse_ok(a, s):
        tgt = a[4] + s * abs(a[1] - a[0])
        if _impulse_ok(a + [x], s) and s * (x - a[3]) > 0:
            return f"impuls {up} · gel. 5 berjalan (sudah lewat puncak gel. 3)", s, tgt
        return f"impuls {up} · gel. 5 berjalan", s, tgt
    # 3) a0..a3 = gel. 1-3, leg berjalan = gel. 4 (koreksi) -> searah impuls kalau koreksi sudah cukup & tidak masuk gel.1
    a = tail(4, lead)
    if a and cur_dir == -s and _impulse_ok(a, s):
        rt = _retr(a[2], a[3], x)
        if s * (x - a[1]) > 0 and rt >= 0.236:
            return f"impuls {up} · gel. 4 koreksi {rt * 100:.0f}% → tunggu gel. 5 {up}", s, a[3] + s * 0.1 * abs(a[3] - a[2])
        if s * (x - a[1]) <= 0:
            return None                                    # masuk wilayah gel.1 -> bukan gel.4
        return f"impuls {up} · gel. 4 baru mulai ({rt * 100:.0f}%)", 0, None
    # 4) a0..a2 = gel. 1-2, leg berjalan = gel. 3
    a = tail(3, lead)
    if a and cur_dir == s and _impulse_ok(a, s):
        rt = _retr(a[0], a[1], a[2])
        if 0.382 <= rt <= 0.886:
            tgt = a[2] + s * 1.618 * abs(a[1] - a[0])
            return (f"impuls {up} · gel. 3 berjalan" + (" (sudah lewat puncak gel. 1)" if s * (x - a[1]) > 0 else "")), s, tgt
    # 5) a0..a1 = gel. 1, leg berjalan = gel. 2 (koreksi 38-79%) -> searah impuls
    a = tail(2, lead)
    if a and cur_dir == -s and _impulse_ok(a, s):
        rt = _retr(a[0], a[1], x)
        if 0.382 <= rt <= 0.786:
            return f"impuls {up} · gel. 2 koreksi {rt * 100:.0f}% → tunggu gel. 3 {up}", s, a[1]
    # 6) koreksi ABC arah s (mis. s=-1: A turun, B naik, C turun) — titik: awal, A, B (terkonfirmasi), leg berjalan = C
    a = tail(3, lead)                                      # koreksi arah s dimulai dari titik lawan (turun: dari high)
    if a and cur_dir == s:
        st, A_, B_ = a
        if s * (A_ - st) > 0 and s * (B_ - A_) < 0 and s * (B_ - st) > 0:
            rb = _retr(st, A_, B_)
            if rb <= 1.0:
                kind = "flat" if rb >= 0.9 else "zigzag"
                return f"koreksi ABC {up} ({kind}) · gel. C berjalan", s, A_ + s * abs(A_ - st)
    # 7) ABC selesai (awal, A, B, C terkonfirmasi; C melewati A), leg berjalan berbalik = arah baru
    a = tail(4, lead)
    if a and cur_dir == -s:
        st, A_, B_, C_ = a
        if s * (A_ - st) > 0 and s * (B_ - A_) < 0 and s * (C_ - A_) > 0 and _retr(st, A_, B_) <= 1.0:
            return f"koreksi ABC {up} selesai → arah {dn}", -s, None
    return None


def ew_series(h, l, c, a, k=ZZ_ATR, at=None, zz=None):
    """Label & suara Elliott di tiap candle (hanya memakai titik balik yang sudah terkonfirmasi sampai candle itu).
    at = indeks candle yang perlu dihitung saja (riwayat panjang); None = semua. zz = hasil zigzag() yang sudah ada."""
    piv, run_p = zz if zz is not None else zigzag(h, l, a, k)
    n = len(c)
    vote = np.zeros(n, np.int8)
    lab = [None] * n
    tgt = np.full(n, np.nan)
    want = None if at is None else set(int(x) for x in at if 0 <= x < n) | {n - 1}
    j = 0
    P = []
    for i in range(n):
        while j < len(piv) and piv[j][3] <= i:
            P.append((piv[j][1], piv[j][2]))
            j += 1
        if want is not None and i not in want:
            continue
        s, v, t_ = ew_state(P[-8:], run_p[i])
        vote[i], lab[i] = v, s
        if t_ is not None:
            tgt[i] = t_
    return {"vote": vote, "label": lab, "target": tgt}


# ------------------------------------------------------------------ bukti lain
def _agg(t, o, h, l, c, ms):
    g = (t // ms) * ms
    keys, idx = np.unique(g, return_index=True)
    end = np.r_[idx[1:], len(t)] - 1
    return keys, o[idx], np.maximum.reduceat(h, idx), np.minimum.reduceat(l, idx), c[end]


def _asof_closed(t_big, ms_big, t_query):
    """Indeks candle TF besar terakhir yang SUDAH close pada waktu t_query (ms) -> -1 kalau belum ada."""
    return np.searchsorted(t_big + ms_big, t_query, side="right") - 1


def trend_votes(tb, cb, ms_b, t_close):
    """Tren EMA20 vs EMA50 di TF besar (candle yang sudah close) -> suara di tiap waktu t_close."""
    if len(cb) < 50:
        return np.zeros(len(t_close), np.int8)
    up = np.where(_ema(cb, 20) > _ema(cb, 50), 1, -1).astype(np.int8)
    k = _asof_closed(tb, ms_b, t_close)
    out = np.where(k >= 49, up[np.clip(k, 0, None)], 0)
    return out.astype(np.int8)


def sweep_votes(h, l, c, n=3, look=SWEEP_LOOK):
    """+1 = low swing sebelumnya ditembus ekor lalu close balik di atasnya (stop hunt bawah) dalam `look` candle terakhir,
    -1 = kebalikannya di high. Swing diketahui n candle setelah terbentuk (tanpa intip masa depan)."""
    N = len(c)
    hi, lo = _pivots(h, l, n)
    lastH, lastL = np.full(N, np.nan), np.full(N, np.nan)
    for arr, src, out in ((hi, h, lastH), (lo, l, lastL)):
        known = arr + n                                    # swing di indeks p diketahui pada candle p+n
        ok = known < N
        out[known[ok]] = src[arr[ok]]                       # swing berurutan -> yang terakhir menimpa (paling baru)
        idx = np.where(np.isfinite(out), np.arange(N), 0)
        np.maximum.accumulate(idx, out=idx)
        out[:] = np.where(np.isfinite(out[idx]), out[idx], np.nan)
    # level sebelum candle ini (swing yang sudah diketahui kemarin)
    pL = np.r_[np.nan, lastL[:-1]]
    pH = np.r_[np.nan, lastH[:-1]]
    up1 = (l < pL) & (c > pL)
    dn1 = (h > pH) & (c < pH)
    up = np.zeros(N, bool)
    dn = np.zeros(N, bool)
    for k in range(look):
        up[k:] |= up1[:N - k] if k else up1
        dn[k:] |= dn1[:N - k] if k else dn1
    v = np.where(up & ~dn, 1, np.where(dn & ~up, -1, 0))
    return v.astype(np.int8)


def btc_votes(t, c, a, bt, bc):
    """Arah BTC dihitung HANYA kalau koin itu sedang bergerak bersama BTC (korelasi return >= 0.5, 96 candle).
    Kekuatan relatif: koin naik/turun > 1 ATR lebih banyak dari BTC dalam 24 candle -> +1 / -1 (koin jalan sendiri)."""
    n = len(c)
    vb, vr = np.zeros(n, np.int8), np.zeros(n, np.int8)
    corr = np.full(n, np.nan)
    if bt is None or len(bt) < CORR_WIN + 2:
        return vb, vr, corr
    pos = np.searchsorted(bt, t)
    ok = (pos < len(bt)) & (bt[np.clip(pos, 0, len(bt) - 1)] == t)
    bcl = np.where(ok, bc[np.clip(pos, 0, len(bt) - 1)], np.nan)
    rc = np.r_[np.nan, np.diff(np.log(c))]
    rb = np.r_[np.nan, np.diff(np.log(bcl))]
    fill = np.nan_to_num(bcl, nan=np.nanmean(bcl) if np.isfinite(bcl).any() else 0.0)
    btr = np.where(_ema(fill, 20) > _ema(fill, 50), 1, -1)
    m = np.isfinite(rc) & np.isfinite(rb)
    x, y = np.where(m, rc, 0.0), np.where(m, rb, 0.0)

    def roll(z):
        cs = np.cumsum(np.r_[0.0, z])
        out = np.full(n, np.nan)
        out[CORR_WIN - 1:] = cs[CORR_WIN:] - cs[:-CORR_WIN]
        return out
    cnt, sx, sy = roll(m.astype(float)), roll(x), roll(y)
    sxx, syy, sxy = roll(x * x), roll(y * y), roll(x * y)
    with np.errstate(invalid="ignore", divide="ignore"):
        cov = sxy - sx * sy / cnt
        den = np.sqrt((sxx - sx * sx / cnt) * (syy - sy * sy / cnt))
        corr = np.where((cnt >= CORR_WIN * 0.8) & (den > 0), cov / den, np.nan)
    idx = np.arange(n)
    vb = np.where((corr >= CORR_MIN) & np.isfinite(bcl) & (idx >= 50), btr, 0).astype(np.int8)
    prev = np.r_[np.full(RS_WIN, np.nan), bcl[:-RS_WIN]] if n > RS_WIN else np.full(n, np.nan)
    prc = np.r_[np.full(RS_WIN, np.nan), c[:-RS_WIN]] if n > RS_WIN else np.full(n, np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        rs = (c / prc - 1) - (bcl / prev - 1)
        big = np.abs(rs) > a / c
    vr = np.where(np.isfinite(rs) & big & (a == a), np.sign(rs), 0).astype(np.int8)
    return vb, vr, corr


def session_of(t_ms):
    hr = (np.asarray(t_ms, np.int64) // 3_600_000) % 24
    out = np.empty(len(hr), object)
    for a_, b_, nm in SESS:
        out[(hr >= a_) & (hr < b_)] = nm
    return out


def coin_votes(t, o, h, l, c, tf, btc=None, d1=None, symbol="", at=None, memo=None):
    """Semua suara bukti di tiap candle 1 koin. btc = (t, c) TF sama, d1 = (t, c) candle harian (boleh None ->
    dirakit dari data ini kalau cukup). Hasil dict array + label Elliott (entry & TF besar)."""
    t = np.asarray(t, np.int64)
    o, h, l, c = (np.asarray(x, float) for x in (o, h, l, c))
    n = len(c)
    a = _atr(h, l, c, 14)
    dt = TF_MS.get(tf) or (int(t[1] - t[0]) if n > 1 else 60_000)
    tclose = t + dt
    memo = {} if memo is None else memo                  # simpan zigzag (bagian paling lama) untuk dipakai ulang
    if "zz" not in memo:
        memo["zz"] = zigzag(h, l, a)
    ew = ew_series(h, l, c, a, at=at, zz=memo["zz"])
    out = {"ew": ew["vote"], "ew_label": ew["label"], "ew_target": ew["target"]}
    # Elliott derajat lebih besar (dirakit dari data ini, candle yang sudah close)
    H = HTF_OF.get(tf)
    out["ew_htf"] = np.zeros(n, np.int8)
    out["ew_htf_label"] = [None] * n
    out["htf"] = H
    if H and TF_MS[H] > dt:
        hms = TF_MS[H]
        ht, ho, hh, hl, hc = _agg(t, o, h, l, c, hms)
        if len(hc) >= 30:
            ha = _atr(hh, hl, hc, 14)
            k0 = _asof_closed(ht, hms, tclose if at is None else tclose[np.asarray(list(at) + [n - 1], int)])
            if "zzh" not in memo:
                memo["zzh"] = zigzag(hh, hl, ha)
            e2 = ew_series(hh, hl, hc, ha, at=None if at is None else k0[k0 >= 0], zz=memo["zzh"])
            k = _asof_closed(ht, hms, tclose)
            okk = k >= 0
            kk = np.clip(k, 0, None)
            out["ew_htf"] = np.where(okk, e2["vote"][kk], 0).astype(np.int8)
            out["ew_htf_label"] = [e2["label"][x] if g else None for x, g in zip(kk, okk)]
    # tren D1
    if d1 is not None and len(d1[0]) >= 50:
        out["d1"] = trend_votes(np.asarray(d1[0], np.int64), np.asarray(d1[1], float), 86_400_000, tclose)
    else:
        dtt, _, _, _, dc = _agg(t, o, h, l, c, 86_400_000)
        out["d1"] = trend_votes(dtt, dc, 86_400_000, tclose)
    # BTC & kekuatan relatif (koin BTC sendiri: tidak dihitung)
    if btc is not None and not str(symbol).upper().startswith("BTCUSDT"):
        vb, vr, corr = btc_votes(t, c, a, np.asarray(btc[0], np.int64), np.asarray(btc[1], float))
    else:
        vb, vr, corr = np.zeros(n, np.int8), np.zeros(n, np.int8), np.full(n, np.nan)
    out["btc"], out["rs"], out["corr"] = vb, vr, corr
    out["sweep"] = sweep_votes(h, l, c)
    out["sess"] = session_of(t) if dt <= 3_600_000 else np.full(n, None, object)
    out["atr"] = a
    return out


def votes_at(V, i):
    """Suara semua bukti di candle i (untuk 1 sampel trade)."""
    return {k: int(V[k][i]) for k in KEYS}, (V["sess"][i] if V.get("sess") is not None else None)


# ------------------------------------------------------------------ mesin kelas A / B / C
SESS_NAMES = [nm for _, _, nm in SESS]


def pack(V, idx, dirs, wins, cut=None, test=None):
    """Sampel trade (array) dari suara bukti V di candle entry `idx`: votes (n x bukti), sesi (kode), arah, menang,
    data uji (idx >= cut, atau array `test`)."""
    idx = np.asarray(idx, int)
    sess = V.get("sess")
    sc = np.array([SESS_NAMES.index(x) if x in SESS_NAMES else -1 for x in sess[idx]], np.int8) if sess is not None and len(idx) \
        else np.full(len(idx), -1, np.int8)
    return {"v": np.stack([np.asarray(V[k])[idx] for k in KEYS], 1).astype(np.int8) if len(idx) else np.zeros((0, len(KEYS)), np.int8),
            "sess": sc, "dir": np.broadcast_to(np.asarray(dirs, np.int8), len(idx)).copy(),
            "win": np.asarray(wins, bool), "test": (idx >= cut) if test is None else np.asarray(test, bool)}


def concat(packs):
    packs = [p for p in packs if p is not None and len(p["win"])]
    if not packs:
        return None
    return {k: np.concatenate([p[k] for p in packs]) for k in ("v", "sess", "dir", "win", "test")}


def _wr(win):
    return 100.0 * float(np.mean(win)) if len(win) else None


def _scores(model, v, d, sess):
    w = np.array([model["w"].get(k, 0.0) for k in KEYS])
    sc = (np.sign(v * d[:, None]) * w).sum(1)
    for key, val in model["sess"].items():
        side, nm = key.split("|", 1)
        if nm in SESS_NAMES:
            sc = sc + val * ((d == int(side)) & (sess == SESS_NAMES.index(nm)))
    return sc


def learn_np(S):
    """S = pack(...) / concat(...). Bobot & batas kelas dari 70% awal (test=False), WR per kelas dinilai di 30% terakhir."""
    model = {"w": {}, "stats": {}, "sess": {}, "cut": None, "n_fit": 0, "n_test": 0}
    if S is None:
        model["note"] = "belum ada trade untuk menilai bukti"
        return model
    f, t = ~S["test"], S["test"]
    model["n_fit"], model["n_test"] = int(f.sum()), int(t.sum())
    if f.sum() < 2 * MIN_SIDE:
        model["note"] = "trade terlalu sedikit untuk menilai bukti"
        return model
    v, d, win, sess = S["v"], S["dir"].astype(int), S["win"], S["sess"]
    for j, k in enumerate(KEYS):
        ag, di = f & (v[:, j] * d > 0), f & (v[:, j] * d < 0)
        st = {"n_agree": int(ag.sum()), "n_against": int(di.sum()), "wr_agree": _wr(win[ag]), "wr_against": _wr(win[di])}
        w = 0.0
        if ag.sum() >= MIN_SIDE and di.sum() >= MIN_SIDE:
            gap = st["wr_agree"] - st["wr_against"]
            st["gap"] = gap
            if gap >= MIN_GAP:
                w = gap / 100
        model["w"][k], model["stats"][k] = w, st
    for side in (1, -1):
        bs = f & (d == side)
        base = _wr(win[bs])
        for ci, nm in enumerate(SESS_NAMES):
            g = bs & (sess == ci)
            if g.sum() >= MIN_SIDE and base is not None:
                dd = _wr(win[g]) - base
                if abs(dd) >= MIN_GAP:
                    model["sess"][f"{side}|{nm}"] = dd / 100
    if not any(model["w"].values()) and not model["sess"]:
        model["note"] = "belum ada bukti yang terbukti membedakan menang & kalah (di 70% data awal)"
        return model
    sc = _scores(model, v, d, sess)
    q1, q2 = np.quantile(sc[f], [1 / 3, 2 / 3])
    model["cut"] = (float(q1), float(q2))
    gr = np.where((sc > 0) & (sc >= q2), "A", np.where((sc < 0) & (sc <= q1), "C", "B"))
    res = {}
    for g in "ABC":
        m = gr == g
        res[g] = {"n": int((m & t).sum()), "wr": _wr(win[m & t]), "n_fit": int((m & f).sum()), "wr_fit": _wr(win[m & f])}
    model["grades"] = res
    a, c = res["A"], res["C"]
    model["proven"] = bool(a["n"] >= 10 and c["n"] >= 10 and a["wr"] is not None and c["wr"] is not None and a["wr"] > c["wr"])
    return model


def learn(samples):
    """Versi daftar dict: [{dir, win, test, v: {bukti: suara}, sess}] -> sama dengan learn_np."""
    if not samples:
        return learn_np(None)
    S = {"v": np.array([[s["v"].get(k, 0) for k in KEYS] for s in samples], np.int8),
         "sess": np.array([SESS_NAMES.index(s["sess"]) if s.get("sess") in SESS_NAMES else -1 for s in samples], np.int8),
         "dir": np.array([s["dir"] for s in samples], np.int8), "win": np.array([bool(s["win"]) for s in samples]),
         "test": np.array([bool(s["test"]) for s in samples])}
    return learn_np(S)


def score(model, v, d, sess=None):
    s = sum(model["w"].get(k, 0) * np.sign(v.get(k, 0) * d) for k in KEYS)
    return float(s + model["sess"].get(f"{d}|{sess}", 0.0))


def grade_of(model, sc):
    cut = model.get("cut")
    if not cut:
        return None
    q1, q2 = cut
    if sc > 0 and sc >= q2:                                # sepertiga teratas DAN bukti searah lebih berat
        return "A"
    if sc < 0 and sc <= q1:                                # sepertiga terbawah DAN bukti melawan lebih berat
        return "C"
    return "B"


def snapshot(V, i=-1):
    """Suara & label bukti di 1 candle (mis. candle terakhir = sekarang), cukup untuk describe(model, snap, 0, ...)."""
    keys = list(KEYS) + ["ew_label", "ew_htf_label", "corr", "ew_target", "sess"]
    snap = {k: [V[k][i]] for k in keys}
    snap["htf"] = V.get("htf")
    return snap


def describe(model, V, i, d, tf):
    """Ringkasan bukti untuk setup arah d (+1 BUY / -1 SELL) di candle i: kelas, searah / melawan, baris per bukti."""
    v, sess = votes_at(V, i)
    items = []
    for k in KEYS:
        x = v[k] * d
        lab = None
        if k == "ew":
            lab = V["ew_label"][i]
        elif k == "ew_htf":
            lab = V["ew_htf_label"][i]
        elif k == "btc":
            cr = V["corr"][i]
            lab = ("data BTC tidak ada untuk waktu ini" if cr != cr else
                   f"korelasi {cr:.2f}" + ("" if v[k] else " · koin jalan sendiri, BTC diabaikan"))
        items.append({"key": k, "name": NAMES[k] + (f" ({V['htf'].upper()})" if k == "ew_htf" and V.get("htf") else
                                                     f" ({tf.upper()})" if k == "ew" else ""),
                      "vote": int(v[k]), "agree": int(np.sign(x)), "label": lab,
                      "weight": float(model["w"].get(k, 0)) if model else 0.0})
    agree = sum(1 for x in items if x["agree"] > 0)
    against = sum(1 for x in items if x["agree"] < 0)
    sc = score(model, v, d, sess) if model and model.get("cut") else None
    g = grade_of(model, sc) if sc is not None else None
    return {"grade": g, "agree": agree, "against": against, "n_items": len(items), "items": items, "session": sess,
            "score": sc, "grades": model.get("grades") if model else None, "proven": model.get("proven") if model else None,
            "note": model.get("note") if model else None,
            "ew_target": (float(V["ew_target"][i]) if V["ew_target"][i] == V["ew_target"][i] else None)}
