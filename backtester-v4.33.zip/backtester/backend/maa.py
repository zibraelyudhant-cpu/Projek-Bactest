"""📈 Moving Average Analisis: setelan indikator (RSI / MACD / Stochastic) mana yang paling cocok dengan 1 MA.

Aturan (disetujui pemilik):
  - Sentuh MA: ekor candle "cuma menyentuh" = paling jauh 0.3 ATR dari MA (di atas atau menembus), close tetap di sisinya.
    Harga di ATAS MA (low mendekati MA) = calon NAIK; di BAWAH MA (high mendekati MA) = calon TURUN.
  - Sinyal = sentuhan + indikator: RSI <= 30 (naik) / >= 70 (turun); Stochastic %K (smooth 3) <= 20 / >= 80, %D 3;
    MACD (fast = angka, slow = angka x 26/12, signal = angka x 9/12) histogram berbalik naik / turun di candle sentuh.
  - Respect: dari close candle sinyal, harga bergerak >= 2 ATR searah SEBELUM melawan 2.5 ATR (candle sama = gagal),
    batas 5 hari. Bonus kalau lanjut 3 / 4 / >= 5 ATR (gerak maksimal sebelum melawan 2.5 ATR / waktu habis).
    (v4.29: batas gagal 1 ATR -> 2.5 ATR, pilihan pemilik "A", supaya 1 ekor gocekan di dekat MA tidak langsung gagal.)
  - Poin: gagal -1; 2 ATR = 1; +0.5 untuk 3 ATR, 4 ATR, >= 5 ATR (maks 2.5). Skor = rata-rata poin per sinyal,
    dinilai kalau >= 30 sinyal. 70% data awal / 30% terakhir (uji) per koin.
  - Sinyal searah yang masih berjalan tidak dihitung dobel (sinyal baru menunggu yang lama selesai).
"""
import json
import os
import time

import numpy as np

from .data import TF_MS
from .indicators import atr as _atr, ema as _ema, macd as _macd, rsi as _rsi, sma as _sma, stoch as _stoch

VERSION = 5
MA_TYPES = {"ema": "EMA", "sma": "SMA"}
INDS = {"rsi": "RSI (70/30)", "macd": "MACD (histogram berbalik)", "stoch": "Stochastic (80/20)"}
LIST = (8, 16, 21, 34, 48, 55)
MA_AUTO = tuple(range(13, 1001, 10))      # periode MA otomatis: 13, 23, 33, ... 993 (pilihan pemilik: tiap 10, maks 1000)
AUTO = tuple(range(5, 61))
TOUCH_ATR = 0.3
FAIL_ATR = 2.5
LEVELS = (2, 3, 4, 5)
HOLD_DAYS = 5
MIN_N = 30
EX_KEEP = 60
_CACHE = {}


def hold_bars(tf):
    return max(2, int(HOLD_DAYS * 86_400_000 // TF_MS[tf]))


def ma_of(c, typ, n):
    return _ema(c, n) if typ == "ema" else _sma(c, n)


def macd_par(p):
    return p, max(p + 1, round(p * 26 / 12)), max(2, round(p * 9 / 12))


def ind_series(D, ind, p):
    """Seri indikator untuk panel visual: dict nama -> array."""
    h, l, c = D["h"], D["l"], D["c"]
    if ind == "rsi":
        return {"rsi": _rsi(c, p)}
    if ind == "stoch":
        k, d = _stoch(h, l, c, p, 3, 3)
        return {"k": k, "d": d}
    f, s_, g = macd_par(p)
    line, sig, hist = _macd(c, f, s_, g)
    return {"macd": line, "signal": sig, "hist": hist}


def ind_cond(D, ind, p):
    """(syarat naik, syarat turun, nilai indikator per candle)."""
    S = ind_series(D, ind, p)
    with np.errstate(invalid="ignore"):
        if ind == "rsi":
            v = S["rsi"]
            return v <= 30, v >= 70, v
        if ind == "stoch":
            v = S["k"]
            return v <= 20, v >= 80, v
        hs = S["hist"]
        h1, h2 = np.r_[np.nan, hs[:-1]], np.r_[np.nan, np.nan, hs[:-2]]
        return (hs > h1) & (h1 <= h2), (hs < h1) & (h1 >= h2), hs


# ================================================================== sentuhan MA & hasil (sekali per koin)
def touches(D, ma):
    h, l, c, a = D["h"], D["l"], D["c"], D["a"]
    ok = np.isfinite(ma) & np.isfinite(a) & (a > 0)
    with np.errstate(invalid="ignore"):
        up = ok & (c > ma) & (np.abs(l - ma) <= TOUCH_ATR * a)       # v4.29: ekor cuma menyentuh: maks 0.3 ATR di atas ATAU menembus
        dn = ok & (c < ma) & (np.abs(h - ma) <= TOUCH_ATR * a)
    return up, dn


def outcome(D, i, d, hold):
    """-> (maks ATR searah sebelum melawan FAIL_ATR, respect?, candle keluar, melawan maks ATR) atau None (data kurang)."""
    n = len(D["c"])
    end = i + hold
    if end >= n:
        return None
    A = D["a"][i]
    e = D["c"][i]
    H, L = (D["h"], D["l"]) if d == 1 else (-D["l"], -D["h"])
    e = e * d
    seg_h, seg_l = H[i + 1:end + 1], L[i + 1:end + 1]
    bad = np.flatnonzero(seg_l <= e - FAIL_ATR * A)
    jb = int(bad[0]) if len(bad) else len(seg_h)                     # candle melawan FAIL_ATR (atau habis)
    fav = (seg_h - e) / A
    good = np.flatnonzero(fav >= 2.0)
    j2 = int(good[0]) if len(good) else None
    resp = j2 is not None and j2 < jb                                   # candle sama = gagal (konservatif)
    mx = float(fav[:jb].max()) if jb > 0 else 0.0
    adv = float(((e - seg_l[:jb + 1 if jb < len(seg_l) else jb]).max()) / A) if len(seg_l) else 0.0
    if resp:
        lv = max(k for k in LEVELS if mx >= k)
        xo = j2
        for k in LEVELS:                                                  # candle saat level tertinggi tercapai
            if mx >= k:
                xo = int(np.flatnonzero(fav[:jb] >= k)[0])
        adv = float(((e - seg_l[:xo + 1]).max()) / A)
        return {"mx": mx, "lv": lv, "resp": True, "x": i + 1 + xo, "adv": max(0.0, adv)}
    return {"mx": max(0.0, mx), "lv": 0, "resp": False, "x": i + 1 + (jb if jb < len(seg_h) else len(seg_h) - 1), "adv": max(0.0, adv)}


def points(o):
    if not o["resp"]:
        return -1.0
    return 1.0 + 0.5 * sum(1 for k in (3, 4, 5) if o["mx"] >= k)


# ================================================================== per koin
def _blank():
    return {"n": 0, "lv2": 0, "lv3": 0, "lv4": 0, "lv5": 0, "fail": 0, "pts": 0.0, "n_up": 0, "resp_up": 0, "n_dn": 0, "resp_dn": 0,
            "t_n": 0, "t_resp": 0, "t_pts": 0.0}


def _add(G, o, d, te):
    G["n"] += 1
    pt = points(o)
    G["pts"] += pt
    if o["resp"]:
        for k in LEVELS:
            if o["mx"] >= k:
                G[f"lv{k}"] += 1
    else:
        G["fail"] += 1
    if d == 1:
        G["n_up"] += 1; G["resp_up"] += o["resp"]
    else:
        G["n_dn"] += 1; G["resp_dn"] += o["resp"]
    if te:
        G["t_n"] += 1; G["t_resp"] += o["resp"]; G["t_pts"] += pt


def coin_eval(sym, D, tf, ma_type, ma_len, ind, periods):
    ma = ma_of(D["c"], ma_type, ma_len)
    up, dn = touches(D, ma)
    hold = hold_bars(tf)
    t = D["t"]
    n = len(t)
    split_t = int(t[int(n * 0.7)]) if n else 0
    cand = {}
    for i in np.flatnonzero(up | dn):
        d = 1 if up[i] else -1
        o = outcome(D, int(i), d, hold)
        if o is not None:
            cand[int(i)] = (d, o)
    idx = np.array(sorted(cand), int)

    def select(mask_up, mask_dn):
        busy = {1: -1, -1: -1}
        for i in idx:
            d, o = cand[i]
            if not (mask_up[i] if d == 1 else mask_dn[i]) or i <= busy[d]:
                continue
            busy[d] = o["x"]
            yield i, d, o
    out = {"base": _blank(), "per": {}}
    EX = {}
    allm = np.ones(n, bool)
    for i, d, o in select(allm, allm):
        _add(out["base"], o, d, int(t[i]) >= split_t)
    for p in periods:
        cu, cd, val = ind_cond(D, ind, p)
        G = _blank()
        ex = []
        for i, d, o in select(cu, cd):
            te = int(t[i]) >= split_t
            _add(G, o, d, te)
            ex.append({"sym": sym, "t": int(t[i]), "d": d, "c": float(D["c"][i]), "ma": float(ma[i]), "A": float(D["a"][i]),
                       "v": None if not np.isfinite(val[i]) else round(float(val[i]), 4 if ind == "macd" else 1),
                       "dist": round(float(d * ((D["l"][i] if d == 1 else D["h"][i]) - ma[i]) / D["a"][i]), 2),   # + = ekor di sisinya, - = menembus
                       "mx": round(o["mx"], 2), "lv": o["lv"], "resp": o["resp"], "adv": round(o["adv"], 2), "xo": int(o["x"] - i),
                       "pt": points(o), "test": te})
        out["per"][str(p)] = G
        EX[str(p)] = ex[-EX_KEEP:]
    out["n_touch"] = int((up | dn).sum())
    return out, EX


def coin_scan(sym, D, tf, ma_type, ind, periods, mas=MA_AUTO):
    """Periode MA otomatis: semua pasangan MA (13..993) x periode indikator di 1 koin -> agregat kecil per pasangan.
    Sinyal = indikator OB/OS (atau MACD berbalik) di candle yang ekornya cuma menyentuh MA itu (<= 0.3 ATR, close tidak tembus);
    hasil dinilai sama persis dengan mode biasa (respect 2 ATR sebelum melawan FAIL_ATR, poin + bonus)."""
    hold = hold_bars(tf)
    t = D["t"]
    n = len(t)
    split_t = int(t[int(n * 0.7)]) if n else 0
    conds = {p: ind_cond(D, ind, p)[:2] for p in periods}
    oc = {}

    def get(i, d):
        k = (i, d)
        if k not in oc:
            oc[k] = outcome(D, i, d, hold)
        return oc[k]

    def run_sel(mu, md, G):
        busy = {1: -1, -1: -1}
        for i in np.flatnonzero(mu | md):
            i = int(i)
            d = 1 if mu[i] else -1
            if i <= busy[d]:
                continue
            o = get(i, d)
            if o is None:
                continue
            busy[d] = o["x"]
            _add(G, o, d, int(t[i]) >= split_t)
    out = {"per": {}, "base": {}, "n_touch": 0}
    for m in mas:
        if m * 2 > n:
            continue
        ma = ma_of(D["c"], ma_type, m)
        up, dn = touches(D, ma)
        out["n_touch"] += int((up | dn).sum())
        G = out["base"][str(m)] = _blank()
        run_sel(up, dn, G)
        for p, (cu, cd) in conds.items():
            G = out["per"][f"{m}|{p}"] = _blank()
            run_sel(up & cu, dn & cd, G)
    return out


def scan_job(sym, tf, ma_type, ind, periods, store=None):
    st = store or _W["store"]
    try:
        D = load(st, sym, tf)
        if len(D["c"]) < 500:
            return f"data terlalu sedikit ({len(D['c'])} candle)"
        return coin_scan(sym, D, tf, ma_type, ind, periods), None, len(D["c"])
    except (ValueError, KeyError, IndexError, OSError, ZeroDivisionError) as ex:
        return f"{type(ex).__name__}: {ex}"


def merge_scan(S, g2):
    if not S:
        S.update(json.loads(json.dumps(g2)))
        return
    S["n_touch"] += g2["n_touch"]
    for grp in ("per", "base"):
        for k, G1 in g2[grp].items():
            G0 = S[grp].setdefault(k, _blank())
            for f, v in G1.items():
                G0[f] += v


def analyse_scan(S):
    """Pasangan MA x indikator terbaik + MA terbaik (dengan periode indikator terbaiknya) + kisi skor."""
    if not S or not S.get("per"):
        return {"best": None}
    combos = []
    for k, G in S["per"].items():
        m, p = (int(x) for x in k.split("|"))
        combos.append({"m": m, "p": p, **_st(G)})
    combos.sort(key=lambda r: (r["ok"], r["score"] if r["score"] is not None else -9), reverse=True)
    by_m = {}
    for r in combos:                                       # sudah urut: yang pertama per MA = terbaiknya
        by_m.setdefault(r["m"], r)
    mas = []
    for m, r in sorted(by_m.items()):
        b = _st(S["base"].get(str(m), _blank()))
        mas.append({**r, "base_score": b["score"], "base_n": b["n"], "base_resp": b["resp"]})
    grid = {}
    for r in combos:
        grid.setdefault(str(r["m"]), {})[str(r["p"])] = None if not r["ok"] else round(r["score"], 3)
    best = combos[0] if combos and combos[0]["n"] else None
    return {"best": best, "top": combos[:15], "mas": mas, "grid": grid, "n_combo": len(combos), "n_touch_all": S["n_touch"]}


def merge(T, g2, E, ex2):
    if not T:
        T.update(json.loads(json.dumps(g2)))
    else:
        T["n_touch"] += g2["n_touch"]
        for G0, G1 in [(T["base"], g2["base"])] + [(T["per"].setdefault(p, _blank()), G) for p, G in g2["per"].items()]:
            for k, v in G1.items():
                G0[k] += v
    for p, L in ex2.items():
        E[p] = sorted(E.get(p, []) + L, key=lambda x: x["t"])[-EX_KEEP * 3:]


def _st(G):
    n = G["n"]
    r = {"n": n, "score": G["pts"] / n if n else None, "resp": 100 * (n - G["fail"]) / n if n else None,
         "fail": 100 * G["fail"] / n if n else None, "t_n": G["t_n"], "t_resp": 100 * G["t_resp"] / G["t_n"] if G["t_n"] else None,
         "t_score": G["t_pts"] / G["t_n"] if G["t_n"] else None,
         "resp_up": 100 * G["resp_up"] / G["n_up"] if G["n_up"] else None, "resp_dn": 100 * G["resp_dn"] / G["n_dn"] if G["n_dn"] else None,
         "n_up": G["n_up"], "n_dn": G["n_dn"]}
    for k in LEVELS:
        r[f"lv{k}"] = 100 * G[f"lv{k}"] / n if n else None
    r["ok"] = bool(n >= MIN_N)
    return r


def analyse(T, E, ind):
    if not T:
        return {"best": None, "rows": []}
    rows = []
    for p, G in T["per"].items():
        rows.append({"p": int(p), **_st(G)})
    rows.sort(key=lambda r: (r["ok"], r["score"] if r["score"] is not None else -9), reverse=True)
    best = rows[0] if rows and rows[0]["n"] else None
    base = _st(T["base"])
    ex = E.get(str(best["p"]), [])[-EX_KEEP * 2:] if best else []
    return {"rows": rows, "best": best, "base": base, "n_touch": T["n_touch"], "examples": ex,
            "up_vs_base": None if not best or best["score"] is None or base["score"] is None else best["score"] - base["score"]}


# ================================================================== jalankan
_W = {}


def _init_worker(data_dir):
    from .data import DataStore
    _W["store"] = DataStore(data_dir, cache_size=4)


def load(store, sym, tf):
    b = store.get(sym, tf)
    D = {"t": np.asarray(b.t, np.int64)}
    for k in ("o", "h", "l", "c"):
        D[k] = np.asarray(getattr(b, k), float)
    D["a"] = _atr(D["h"], D["l"], D["c"], 14)
    return D


def coin_job(sym, tf, ma_type, ma_len, ind, periods, store=None):
    st = store or _W["store"]
    try:
        D = load(st, sym, tf)
        if len(D["c"]) < max(500, ma_len * 2):
            return f"data terlalu sedikit ({len(D['c'])} candle)"
        T, E = coin_eval(sym, D, tf, ma_type, ma_len, ind, periods)
        return T, E, len(D["c"])
    except (ValueError, KeyError, IndexError, OSError, ZeroDivisionError) as ex:
        return f"{type(ex).__name__}: {ex}"


def _disk(key_hash):
    from .results_store import BASE
    return os.path.join(BASE, "maa_cache", f"res_{key_hash}.json")


def _par(store, syms, job, args, take, workers):
    """Jalankan job(sym, *args) untuk semua koin (paralel kalau bisa); take(i, sym, hasil) dipanggil tiap koin selesai.
    -> False kalau paralel gagal di awal (lalu dihitung satu per satu)."""
    if workers > 1 and len(syms) > 2:
        try:
            from concurrent.futures import ProcessPoolExecutor, as_completed
            with ProcessPoolExecutor(max_workers=workers, initializer=_init_worker, initargs=(store.data_dir,)) as ex_:
                futs = {ex_.submit(job, s_, *args): s_ for s_ in syms}
                for i, fu in enumerate(as_completed(futs)):
                    try:
                        res = fu.result()
                    except Exception as e:                                     # noqa: BLE001 - 1 koin gagal: lanjut
                        res = f"{type(e).__name__}: {e}"
                    take(i, futs[fu], res)
            return True
        except (OSError, RuntimeError, ImportError):
            return False
    for i, s_ in enumerate(syms):
        take(i, s_, job(s_, *args, store=store))
    return True


def run(store, tf, ma_type, ma_len, ind, mode, syms, progress=None, push=None, workers=None):
    """ma_len = 0 / "auto" -> periode MA dicari otomatis (13..993 tiap 10) bersama periode indikator, lalu detail MA terbaik."""
    if ma_type not in MA_TYPES or ind not in INDS:
        raise ValueError("tipe MA / indikator tidak dikenal")
    periods = AUTO if mode == "auto" else LIST
    ma_auto = ma_len in (0, "auto", None)
    workers = workers if workers is not None else max(1, min(8, (os.cpu_count() or 2) - 1))
    scan = None
    if ma_auto:
        t0s = time.time()
        S, used_s, skipped_s, n_cs, pc = {}, [], [], 0, []

        def take_s(i, s_, res):
            nonlocal n_cs
            if isinstance(res, str):
                skipped_s.append(f"{s_}: {res}")
            else:
                merge_scan(S, res[0]); used_s.append(s_); n_cs += res[2]; pc.append({"sym": s_, "n": res[0]["n_touch"]})
            if progress:
                progress(i + 1, len(syms), s_, isinstance(res, str))
            if push and (i < 5 or (i + 1) % 3 == 0 or i + 1 == len(syms)):
                a_ = analyse_scan(S)
                push({"partial": True, "phase": "scan_ma", "tf": tf, "coins": list(used_s), "done": i + 1, "total": len(syms), "candles": n_cs,
                      "per_coin": pc[-12:], "skipped": skipped_s[-5:], "elapsed": round(time.time() - t0s, 1), "scan_best": a_.get("best"),
                      "n_touch": S.get("n_touch")})
        key_s = json.dumps([VERSION, "scan", tf, ma_type, ind, mode, list(syms), [int(store.get(s_, tf).t[-1]) for s_ in syms]])
        scan = _CACHE.get(key_s)
        if scan is None:
            if not _par(store, syms, scan_job, (tf, ma_type, ind, periods), take_s, workers):
                S, used_s, skipped_s, n_cs, pc = {}, [], [], 0, []
                _par(store, syms, scan_job, (tf, ma_type, ind, periods), take_s, 1)
            scan = analyse_scan(S)
            scan.update(elapsed=round(time.time() - t0s, 1), mas_tested=[m for m in MA_AUTO if str(m) in S.get("base", {})])
            _CACHE[key_s] = scan
        if not scan.get("best"):
            raise ValueError("tidak ada sinyal sama sekali di semua periode MA")
        ma_len = scan["best"]["m"]
        if push:
            push({"partial": True, "phase": "detail", "tf": tf, "done": 0, "total": len(syms), "scan_best": scan["best"]})
    key = json.dumps([VERSION, tf, ma_type, ma_len, ind, mode, list(syms), [int(store.get(s_, tf).t[-1]) for s_ in syms], bool(ma_auto)])
    if key in _CACHE:
        return _CACHE[key]
    import hashlib
    kh = hashlib.sha1(key.encode()).hexdigest()[:16]
    try:
        with open(_disk(kh), encoding="utf-8") as f_:
            Dk = json.load(f_)
        if Dk.get("key") == key:
            Dk["res"]["from_file"] = True
            _CACHE[key] = Dk["res"]
            return Dk["res"]
    except (OSError, ValueError, KeyError):
        pass
    t0 = time.time()
    T, E, used, skipped, n_c, per_coin = {}, {}, [], [], 0, []

    def take(i, s_, res):
        nonlocal n_c
        if isinstance(res, str):
            skipped.append(f"{s_}: {res}")
        else:
            g2, ex2, nc = res
            merge(T, g2, E, ex2)
            used.append(s_); n_c += nc
            per_coin.append({"sym": s_, "n": g2["n_touch"]})
        if progress:
            progress(i + 1, len(syms), s_, isinstance(res, str))
        if push and (i < 5 or (i + 1) % 3 == 0 or i + 1 == len(syms)):
            part = analyse(T, E, ind)
            part.pop("examples", None)
            part["rows"] = part.get("rows", [])[:8]
            part.update(partial=True, phase="detail" if ma_auto else "riwayat", scan_best=scan and scan["best"], tf=tf, coins=list(used), done=i + 1, total=len(syms), candles=n_c,
                        per_coin=per_coin[-12:], skipped=skipped[-5:], elapsed=round(time.time() - t0, 1))
            push(part)
    if not _par(store, syms, coin_job, (tf, ma_type, ma_len, ind, periods), take, workers):
        T, E, used, skipped, n_c, per_coin = {}, {}, [], [], 0, []
        _par(store, syms, coin_job, (tf, ma_type, ma_len, ind, periods), take, 1)
    if push:
        push({"partial": True, "phase": "analisa", "done": len(syms), "total": len(syms), "tf": tf, "coins": used})
    res = analyse(T, E, ind)
    res.update(ma_auto=bool(ma_auto), scan=scan, fail_atr=FAIL_ATR, tf=tf, ma_type=ma_type, ma_len=ma_len, ind=ind, mode=mode, periods=list(periods), coins=used, skipped=skipped[:20],
               n_skipped=len(skipped), candles=n_c, hold_bars=hold_bars(tf), elapsed=round(time.time() - t0, 1), v=VERSION, workers=workers)
    if len(_CACHE) > 6:
        _CACHE.clear()
    _CACHE[key] = res
    try:
        os.makedirs(os.path.dirname(_disk(kh)), exist_ok=True)
        with open(_disk(kh) + ".tmp", "w", encoding="utf-8") as f_:
            json.dump({"key": key, "res": res}, f_, default=float)
        os.replace(_disk(kh) + ".tmp", _disk(kh))
    except (OSError, TypeError, ValueError):
        pass
    return res


def history_symbols(store, tf, n=30):
    syms = [s_ for s_ in store.symbols() if tf in store.timeframes(s_)] if hasattr(store, "symbols") else []
    syms.sort(key=lambda s_: -len(store.get(s_, tf).c))
    return syms[:n]


def visual(store, sym, tf, t_ms, ma_type, ma_len, ind, p, before=80, after=150):
    """Candle asli + garis MA + seri indikator di sekitar 1 contoh (dihitung dari seluruh data supaya nilainya sama)."""
    D = load(store, sym, tf)
    ma = ma_of(D["c"], ma_type, ma_len)
    S = ind_series(D, ind, p)
    t = D["t"]
    i = int(np.searchsorted(t, int(t_ms)))
    a0, a1 = max(0, i - before), min(len(t), i + 1 + max(10, min(int(after), 700)))

    def f(x):
        return [None if not np.isfinite(v) else float(v) for v in x[a0:a1]]
    return {"candles": [[int(t[k]), float(D["o"][k]), float(D["h"][k]), float(D["l"][k]), float(D["c"][k])] for k in range(a0, a1)],
            "i": i - a0, "ma": f(ma), "ind": {k: f(v) for k, v in S.items()}}
