"""💧 Liquidity Sweep backtest (sub-tab di 🧠 TA Pro Advance).

Tujuan: melihat PENYARING mana yang benar-benar menaikkan hasil trading sweep, dari data candle lokal banyak koin.

1. Likuiditas (diketahui SEBELUM candle sweep): low/high hari kemarin (PDL/PDH), low/high sesi Asia (00–07 UTC, dipakai
   sesudah 07:00), equal low/high (2 swing terakhir selisih <= 0.2 ATR), swing low/high terakhir, angka bulat.
   Level harus masih "utuh" (belum disentuh sejak terbentuk).
2. Sweep = ekor candle menembus level >= 0.05 ATR lalu candle itu CLOSE kembali di dalam (bukan breakout).
3. Konfirmasi (diuji): close balik saja · CHoCH kecil (dalam 6 candle close menembus high/low 3 candle sebelum sweep tanpa
   membuat ekstrem baru) · displacement (candle searah dengan badan >= 1 ATR & >= 60% panjang candle, di candle sweep / sesudahnya).
4. Entry (diuji): market di close konfirmasi · limit 50% ekor sweep · limit retest level yang disapu.
   SL (diuji, v4.26): anti-gocekan = yang terjauh dari (ujung ekor sweep +- 0.2 ATR) dan SL Whale, lebih jauh dari 4% = dilewati;
   atau entry -+ k x ATR(14) dengan k = 1, 1.5, 2, ... 5 (diukur dari harga entry, tanpa batas 4%).
   TP (diuji): RR 1:2 · RR 1:3 · likuiditas seberang (swing high/low terdekat di seberang, RR minimal 1:2).
   Info tiap trade: ADX(14) di candle sweep, RSI(14) di candle entry & candle hit, kondisi market TF sinyal (ADX >= 20 trend /
   < 20 sideway, condong bullish/bearish dari close vs EMA50 & arah EMA50) dan lamanya kondisi itu.
   Batas waktu: TF < 1H = 24 jam, TF >= 1H = 2 hari. Belum kena TP sampai batas = tidak menang (rumus Whale).
5. Penyaring yang dinilai: tren 4H / 1D (searah / melawan / netral), sesi, volume candle sweep (>= 1.5x rata-rata 20),
   kedalaman ekor (ATR), jenis level, konfirmasi, kondisi market & lamanya. 70% data awal = data cari, 30% terakhir = data uji.
"""
import json
import math
import os
import time

import numpy as np

from . import antigocek as AG
from .chartpat import window_bars
from .data import TF_MS
from .indicators import adx as _adx, atr as _atr, ema as _ema, pivots, rsi as _rsi

VERSION = 2
CONFS = {"close": "close balik saja", "choch": "CHoCH kecil", "disp": "displacement"}
ENTRIES = {"market": "market di close konfirmasi", "wick50": "limit 50% ekor sweep", "retest": "limit retest level"}
TPS = {"rr2": "RR 1:2", "rr3": "RR 1:3", "liq": "likuiditas seberang (RR ≥ 1:2)"}
MIN_RR = 2                                       # permintaan user: RR minimal 1:2
SL_ATR = [(f"atr{x:g}", x) for x in (1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5)]
SLS = {"anti": "SL anti-gocekan Whale (ekor sweep ± 0.2 ATR, maks 4%)", **{k: f"SL {x:g} ATR dari entry" for k, x in SL_ATR}}
ADX_TREND = 20
REGS = (("ts", "trend searah"), ("tm", "trend melawan"), ("ss", "sideway condong searah"), ("sm", "sideway condong melawan"))
DURS = (("h12", "< 12 jam", 0, 12), ("h48", "12–48 jam", 12, 48), ("d2", "> 2 hari", 48, 1e12))
LEVELS = {"pd": "high/low hari kemarin", "asia": "high/low sesi Asia", "eq": "equal high/low", "swing": "swing high/low", "round": "angka bulat"}
SESSIONS = (("asia", "Asia 00–07 UTC", 0, 7), ("london", "London 07–12 UTC", 7, 12), ("overlap", "London–New York 12–16 UTC", 12, 16),
            ("ny", "New York 16–21 UTC", 16, 21), ("late", "Malam 21–24 UTC", 21, 24))
DEPTHS = (("d05", "≤ 0.5 ATR", 0, 0.5), ("d1", "0.5–1 ATR", 0.5, 1), ("d2", "1–2 ATR", 1, 2), ("d2p", "> 2 ATR", 2, 1e9))
MIN_N = 30
LV_KEYS = list(LEVELS)
N_EXAMPLES = 150
_CACHE = {}


def _sess(hour):
    for k, _, a, b in SESSIONS:
        if a <= hour < b:
            return k
    return "late"


# ================================================================== deteksi (sisi BELI: sweep LOW; sisi jual = harga dicermin)
def events_long(t, o, h, l, c, v, a, k=3):
    """Sweep low (calon BUY): list dict(s, L, types, depth, volx, hour)."""
    n = len(c)
    day = t // 86_400_000
    hour = (t // 3_600_000) % 24
    starts = np.r_[0, np.flatnonzero(np.diff(day)) + 1]
    ends = np.r_[starts[1:], n]
    pdl = np.full(n, np.nan)
    today_min = np.full(n, np.inf)                   # low hari ini SEBELUM candle s
    asia_low = np.full(n, np.nan)
    since7_min = np.full(n, np.inf)                  # low sejak 07:00 sebelum candle s
    prev_low = None
    for a0, b0 in zip(starts, ends):
        seg = l[a0:b0]
        if prev_low is not None:
            pdl[a0:b0] = prev_low
        cm = np.minimum.accumulate(seg)
        today_min[a0 + 1:b0] = cm[:-1]
        hh = hour[a0:b0]
        am = hh < 7
        if am.any() and (~am).any():
            al = seg[am].min()
            i7 = a0 + int(np.argmax(~am))
            asia_low[i7:b0] = al
            cm7 = np.minimum.accumulate(l[i7:b0])
            since7_min[i7 + 1:b0] = cm7[:-1]
        prev_low = seg.min()
    hi, lo = pivots(h, l, k)
    lo = np.asarray(lo, int)
    conf = lo + k
    vm = np.convolve(v, np.ones(20) / 20, "full")[:n]
    step = 5 * 10 ** (np.floor(np.log10(np.maximum(np.abs(c), 1e-12))) - 2)
    prev3 = np.full(n, np.nan)
    if n > 4:
        from numpy.lib.stride_tricks import sliding_window_view as swv
        prev3[3:] = swv(l, 3)[:n - 3].min(axis=1)
    ok = np.isfinite(a) & (a > 0)
    ev = {}

    def add(s, L, typ):
        e = ev.setdefault(s, {"s": int(s), "L": [], "types": set()})
        e["L"].append(float(L)); e["types"].add(typ)

    tol = 0.05 * np.where(ok, a, np.nan)
    with np.errstate(invalid="ignore"):
        m = ok & (l < pdl - tol) & (c > pdl) & (today_min >= pdl)
        for s in np.flatnonzero(m):
            add(s, pdl[s], "pd")
        m = ok & (hour >= 7) & (l < asia_low - tol) & (c > asia_low) & (since7_min >= asia_low)
        for s in np.flatnonzero(m):
            add(s, asia_low[s], "asia")
        R = np.floor(prev3 / step) * step
        m = ok & (l < R - tol) & (c > R) & (prev3 > R)
        for s in np.flatnonzero(m):
            add(s, R[s], "round")
    # swing & equal low terakhir yang sudah terkonfirmasi sebelum s dan belum tersentuh
    jj = np.searchsorted(conf, np.arange(n) - 1, side="right") - 1          # swing low terakhir dengan conf <= s-1
    for s in np.flatnonzero(ok):
        j = jj[s]
        if j < 0:
            continue
        i = lo[j]
        L = l[i]
        if s - i > 100 or not (l[s] < L - tol[s] and c[s] > L):
            continue
        if conf[j] + 1 <= s - 1 and l[conf[j] + 1:s].min() < L:
            continue                                               # sudah tersentuh sebelumnya
        add(s, L, "swing")
        if j >= 1:
            i2 = lo[j - 1]
            if s - i2 <= 100 and abs(l[i2] - L) <= 0.2 * a[s] and l[i2] >= L:
                add(s, L, "eq")
    out = []
    for s, e in sorted(ev.items()):
        L = max(e["L"])                                              # level terdekat di bawah close
        out.append({"s": s, "L": L, "types": sorted(e["types"]), "depth": float((L - l[s]) / a[s]),
                    "volx": bool(vm[s] > 0 and v[s] >= 1.5 * vm[s]), "hour": int(hour[s])})
    return out


def _confirm(o, h, l, c, a, s, mode):
    n = len(c)
    if mode == "close":
        return s
    if mode == "choch":
        if s < 3:
            return None
        ref = h[s - 3:s].max()
        for j in range(s + 1, min(n, s + 7)):
            if l[j] < l[s]:
                return None
            if c[j] > ref:
                return j
        return None
    for j in (s, s + 1):                                             # displacement
        if j >= n:
            return None
        body, rng = c[j] - o[j], h[j] - l[j]
        if body >= a[s] and rng > 0 and body / rng >= 0.6:
            return j
    return None


def _seg(H, L_, f, hold, market, cache):
    """Ringkasan jalur harga sesudah candle terisi f (dipakai ulang untuk semua SL & TP): min low / max high berjalan."""
    x = cache.get((f, market))
    if x is None:
        first = f + 1 if market else f
        end = f + hold
        x = cache[(f, market)] = (first, end, -np.minimum.accumulate(L_[first:end + 1]), np.maximum.accumulate(H[f + 1:end + 1]))
    return x


def _fast_trade(seg, f, sl, tp):
    """Sama persis dengan chartpat._trade (sisi beli): (1 TP / -1 SL / 0 waktu habis, candle keluar). SL & TP di candle sama = kalah."""
    first, end, nmin, cmax = seg
    i = int(np.searchsorted(nmin, -sl, "left"))
    sj = first + i if i < len(nmin) else None
    i = int(np.searchsorted(cmax, tp, "left"))
    tj = f + 1 + i if i < len(cmax) else None
    if sj is not None and (tj is None or sj <= tj):
        return -1, sj
    if tj is not None:
        return 1, tj
    return 0, end


def _regime(h, l, c, tf):
    """Kondisi market di TF sinyal per candle: ADX(14) >= 20 = trend, < 20 = sideway; condong bullish/bearish dari close vs EMA50
    dan arah EMA50 (5 candle); lama kondisi = berapa candle berturut-turut statusnya (trend/sideway) sama."""
    n = len(c)
    ad = _adx(h, l, c, 14)
    if isinstance(ad, tuple):
        ad = ad[0]
    em = _ema(c, 50)
    sl5 = em - np.r_[np.full(min(5, n), em[0] if n else 0.0), em[:-5]] if n > 5 else np.zeros(n)
    sc = np.sign(c - em) + np.sign(sl5)
    bias = np.where(sc > 0, 1, np.where(sc < 0, -1, np.where(c >= em, 1, -1))).astype(int)
    trend = np.nan_to_num(ad, nan=0.0) >= ADX_TREND
    idx = np.arange(n)
    chg = np.r_[True, trend[1:] != trend[:-1]] if n else np.zeros(0, bool)
    run = idx - np.maximum.accumulate(np.where(chg, idx, 0)) + 1
    dur_h = run * TF_MS[tf] / 3_600_000
    return ad, _rsi(c, 14), trend, bias, dur_h


def _durk(hrs):
    return next(k for k, _, x0, x1 in DURS if x0 <= hrs < x1)


def iter_rows(sym, t, o, h, l, c, v, tf, tr4=None, tr1=None, k=3):
    """Semua trade sweep riwayat 1 koin (BUY & SELL) x konfirmasi x entry x TP x SL — satu per satu (tidak ditumpuk di memori)."""
    a = _atr(h, l, c, 14)
    g = AG.get_ctx({}, h, l, c)
    C = AG.whale_cfg.get()
    mx = C["sl.max_pct"] / 100
    hold = wait = window_bars(tf)
    n = len(c)
    split_t = t[int(n * 0.7)] if n else 0
    ad, rs, trend, bias, dur_h = _regime(h, l, c, tf)
    for d in (1, -1):
        O, H, L_, Cc = (o, h, l, c) if d == 1 else (-o, -l, -h, -c)              # sisi jual = harga dicermin
        hi, _ = pivots(H, L_, k)
        hi = np.asarray(hi, int)
        for ev in events_long(t, O, H, L_, Cc, v, a, k):
            s, Lv = ev["s"], ev["L"]
            rel = int(bias[s] * d)
            regk = ("t" if trend[s] else "s") + ("s" if rel > 0 else "m")
            mask = 0
            for ty in ev["types"]:
                mask |= 1 << LV_KEYS.index(ty)
            sess = _sess(ev["hour"])
            depth = next(kk for kk, _, x0, x1 in DEPTHS if x0 <= ev["depth"] < x1)
            t4 = int(tr4[s] * d) if tr4 is not None else 0
            t1 = int(tr1[s] * d) if tr1 is not None else 0
            prof = (t4, t1, sess, bool(ev["volx"]), depth, mask, regk, _durk(dur_h[s]))
            test = bool(t[s] >= split_t)
            info = {"sym": sym, "t": int(t[s]), "d": d, "test": test, "p": prof, "types": ev["types"], "L": float(Lv * d),
                    "adx": None if not np.isfinite(ad[s]) else round(float(ad[s]), 1), "trend": bool(trend[s]),
                    "bias": int(bias[s]), "dur_h": float(dur_h[s])}
            segc = {}
            for cf in CONFS:
                j = _confirm(O, H, L_, Cc, a, s, cf)
                if j is None:
                    continue
                k0 = np.searchsorted(hi + k, j, side="right")
                piv = np.sort(np.array([H[i] for i in hi[max(0, k0 - 30):k0] if j - i <= 200]))
                Es = {"market": float(Cc[j]), "wick50": float((L_[s] + min(O[s], Cc[s])) / 2), "retest": float(Lv)}
                wick_sl = L_[s] - 0.2 * a[s]
                for en, e in Es.items():
                    mk = en == "market"
                    if not mk and not e < Cc[j]:
                        continue
                    SLs = {}
                    ag = AG.sl_at(g, j, d == 1, e if d == 1 else -e)
                    sl = wick_sl if ag is None else min(wick_sl, ag if d == 1 else -ag)
                    if 0 < e - sl <= abs(e) * mx:                                # anti: lebih jauh dari batas Whale (4%) = dilewati
                        SLs["anti"] = sl
                    for slm, kx in SL_ATR:
                        SLs[slm] = e - kx * a[j]                                # SL = entry - k x ATR (diukur dari harga entry)
                    if mk:
                        fi = j
                        hpre = None
                    else:                                                          # limit: candle pertama low <= entry dalam batas tunggu
                        w = L_[j + 1:min(n, j + 1 + wait)]
                        ii = np.flatnonzero(w <= e)
                        fi = j + 1 + int(ii[0]) if len(ii) else None
                        hpre = (float(H[j + 1:fi].max()) if fi is not None and fi > j + 1 else -np.inf)
                    for slm, sl in SLs.items():
                        risk = e - sl
                        if risk <= 0:
                            continue
                        for tpk in TPS:
                            if tpk == "rr2":
                                tp = e + 2 * risk
                            elif tpk == "rr3":
                                tp = e + 3 * risk
                            else:                                                  # likuiditas seberang, hanya kalau RR >= 1:2
                                ii = np.searchsorted(piv, e + MIN_RR * risk, "right")
                                if ii >= len(piv):
                                    continue
                                tp = float(piv[ii])
                            f = fi if (mk or (fi is not None and hpre < tp)) else None   # limit batal kalau harga lebih dulu sampai TP
                            row = {**info, "cara": f"{cf}|{en}|{tpk}|{slm}", "slm": slm, "rr": float((tp - e) / risk), "filled": f is not None,
                                   "jo": int(j - s), "e": e * d, "sl": float(sl * d), "tp": float(tp * d)}
                            if f is not None:
                                if f + hold >= n:
                                    continue
                                r = _fast_trade(_seg(H, L_, f, hold, mk, segc), f, sl, tp)
                                x = r[1]
                                row.update(win=r[0] == 1, res={1: "TP", -1: "SL", 0: "waktu habis"}[r[0]], R=row["rr"] if r[0] == 1 else -1.0,
                                           fb=int(f - j), xo=int(x - s), rsi_e=_r1(rs[f]), rsi_x=_r1(rs[x]))
                            elif j + wait >= n:
                                continue
                            yield row


def _r1(x):
    return round(float(x), 1) if np.isfinite(x) else None


def coin_rows(sym, t, o, h, l, c, v, tf, tr4=None, tr1=None, k=3):
    """Versi list (untuk tes / koin tunggal)."""
    return list(iter_rows(sym, t, o, h, l, c, v, tf, tr4, tr1, k))


# ================================================================== agregasi (hemat memori: tidak menyimpan jutaan trade)
EX_KEEP = 150                                   # contoh trade terbaru per cara (disimpan ringkas)
EXF = ("sym", "t", "d", "e", "sl", "tp", "L", "filled", "res", "R", "rr", "fb", "jo", "xo", "test", "types", "slm", "adx", "rsi_e", "rsi_x",
       "trend", "bias", "dur_h", "p")


def _prof(r):
    return tuple(r["p"])


def _ex_dict(x):
    r = dict(zip(EXF, x))
    p = r["p"]
    r.update(t4=p[0], t1=p[1], sess=p[2], volx=p[3], depth=p[4], regk=p[6], durk=p[7],
             reg=("trend " if r["trend"] else "sideway ") + ("bullish" if r["bias"] > 0 else "bearish"))
    return r


def aggregate(rows):
    """{(cara, profil, test): [sinyal, terisi, menang, jumlah R]} + contoh terbaru per cara + jumlah sweep."""
    from collections import deque
    A, EX, evs = {}, {}, set()
    for r in rows:
        k = (r["cara"], r["p"], r["test"])
        x = A.get(k)
        if x is None:
            x = A[k] = [0, 0, 0, 0.0]
        x[0] += 1
        if r["filled"]:
            x[1] += 1; x[2] += 1 if r["win"] else 0; x[3] += r["R"]
        q = EX.get(r["cara"])
        if q is None:
            q = EX[r["cara"]] = deque(maxlen=EX_KEEP)
        q.append(r)
        evs.add((r["t"], r["d"]))
    EX = {c_: [[r.get(f_) for f_ in EXF] for r in sorted(q, key=lambda r: r["t"])] for c_, q in EX.items()}
    return A, EX, len(evs)


def merge(A, EX, a2, ex2):
    for k, v in a2.items():
        x = A.get(k)
        if x is None:
            A[k] = list(v)
        else:
            for i in range(4):
                x[i] += v[i]
    for c_, L in ex2.items():
        EX[c_] = sorted(EX.get(c_, []) + L, key=lambda r: r[1])[-EX_KEEP:]


# ================================================================== analisa (dari agregat)
def _index(A):
    I = {}
    for (c_, prof, te), x in A.items():
        I.setdefault(c_, []).append((prof, te, x))
    return I


def _st(A, cara, pred=None, test=None):
    sig = fill = win = 0
    sr = 0.0
    for prof, te, x in A.get(cara, ()):                     # A = indeks per cara (lihat _index)
        if (test is not None and te != test) or (pred is not None and not pred(prof)):
            continue
        sig += x[0]; fill += x[1]; win += x[2]; sr += x[3]
    if not fill:
        return {"n": 0, "sig": sig, "wr": None, "exp": None, "fill": None, "exp_sig": None}
    ex = sr / fill
    fp = 100 * fill / sig if sig else None
    return {"n": fill, "sig": sig, "wr": 100 * win / fill, "exp": ex, "fill": fp, "exp_sig": ex * (fp or 0) / 100}


def _split(A, cara, pred=None):
    return _st(A, cara, pred), _st(A, cara, pred, False), _st(A, cara, pred, True)


def _filters():
    L = LV_KEYS
    return [("t4", "Tren 4H", [("searah", "searah", lambda p: p[0] > 0), ("melawan", "melawan", lambda p: p[0] < 0), ("netral", "sideway", lambda p: p[0] == 0)]),
            ("t1", "Tren 1D", [("searah", "searah", lambda p: p[1] > 0), ("melawan", "melawan", lambda p: p[1] < 0), ("netral", "sideway", lambda p: p[1] == 0)]),
            ("t41", "Tren 4H & 1D", [("searah2", "dua-duanya searah", lambda p: p[0] > 0 and p[1] > 0)]),
            ("sess", "Sesi", [(k, lab, (lambda p, k=k: p[2] == k)) for k, lab, _, _ in SESSIONS]),
            ("volx", "Volume candle sweep", [("ya", "≥ 1.5× rata-rata", lambda p: p[3]), ("tidak", "< 1.5× rata-rata", lambda p: not p[3])]),
            ("depth", "Kedalaman ekor", [(k, lab, (lambda p, k=k: p[4] == k)) for k, lab, _, _ in DEPTHS]),
            ("lvl", "Jenis level yang disapu", [(k, lab, (lambda p, i=i: bool(p[5] >> i & 1))) for i, (k, lab) in enumerate(LEVELS.items())]),
            ("reg", "Kondisi market (TF sinyal)", [(k, lab, (lambda p, k=k: p[6] == k)) for k, lab in REGS]),
            ("dur", "Lama kondisi market", [(k, lab, (lambda p, k=k: p[7] == k)) for k, lab, _, _ in DURS])]


def _ex_match(x, preds):
    p = tuple(x[EXF.index("p")])
    return all(fn(p) for fn in preds)


def analyse(A, EX):
    """Cara terbaik (konfirmasi x entry x TP), lalu efek tiap penyaring & kombinasi terbaik pada cara itu."""
    A = _index(A)
    caras = []
    for key in sorted(A):
        al, fi, te = _split(A, key)
        cf, en, tp, slm = key.split("|")
        caras.append({"key": key, "conf": cf, "entry": en, "tp": tp, "sl": slm, "txt": f"{CONFS[cf]} · {ENTRIES[en]} · TP {TPS[tp]} · {SLS[slm]}",
                      "all": al, "fit": fi, "test": te, "ok": bool(al["n"] >= MIN_N and (al["exp"] or 0) > 0)})
    caras.sort(key=lambda x: (x["ok"], x["all"]["exp_sig"] if x["all"]["exp_sig"] is not None else -9), reverse=True)
    if not caras:
        return {"caras": [], "best": None}
    best = caras[0]
    bk = best["key"]
    base = _split(A, bk)
    filt, fns, labs = [], {}, {}
    for fk, flab, vals in _filters():
        for vk, vlab, fn in vals:
            al, fi, te = _split(A, bk, fn)
            up = None if fi["exp"] is None or base[1]["exp"] is None else fi["exp"] - base[1]["exp"]
            up_t = None if te["exp"] is None or base[2]["exp"] is None else te["exp"] - base[2]["exp"]
            kk = f"{fk}:{vk}"
            fns[kk], labs[kk] = fn, f"{flab}: {vlab}"
            filt.append({"group": flab, "gk": fk, "key": kk, "val": vlab, "all": al, "fit": fi, "test": te, "up_fit": up, "up_test": up_t,
                         "helps": bool(fi["n"] >= MIN_N and te["n"] >= 10 and (up or 0) >= 0.05 and (up_t or 0) > 0)})
    conf_cmp = [c_ for c_ in caras if c_["entry"] == best["entry"] and c_["tp"] == best["tp"] and c_["sl"] == best["sl"]]
    sl_tab = []                                          # SL terbaik untuk TF ini: tiap pilihan SL -> cara terbaiknya + cara juara dengan SL itu
    for slm, lab in SLS.items():
        cs = [c_ for c_ in caras if c_["sl"] == slm]
        same = f"{best['conf']}|{best['entry']}|{best['tp']}|{slm}"
        sa = _split(A, same) if same in A else None
        sl_tab.append({"sl": slm, "txt": lab, "best": cs[0] if cs else None, "is_best": slm == best["sl"],
                       "same": None if sa is None else {"key": same, "all": sa[0], "fit": sa[1], "test": sa[2]}})
    chosen, preds, steps, used = [], [], [], set()
    for _ in range(3):
        cand = None
        c0 = (_split(A, bk, (lambda p: all(f(p) for f in preds)) if preds else None)[1]["exp"]) or 0
        for kk, fn in fns.items():
            if kk.split(":")[0] in used:
                continue
            P = preds + [fn]
            al, fi, te = _split(A, bk, lambda p, P=P: all(f(p) for f in P))
            if fi["n"] < MIN_N or te["n"] < 10:
                continue
            if fi["exp"] - c0 >= 0.05 and (cand is None or fi["exp"] > cand[1]["exp"]):
                cand = (kk, fi, te, al)
        if cand is None:
            break
        kk, fi, te, al = cand
        chosen.append(kk); preds.append(fns[kk]); used.add(kk.split(":")[0])
        steps.append({"add": labs[kk], "all": al, "fit": fi, "test": te})
    exs = [_ex_dict(x) for x in EX.get(bk, []) if _ex_match(x, preds)][-N_EXAMPLES:]
    return {"caras": caras[:30], "sl_table": sl_tab, "n_caras": len(caras), "best": best, "base": {"all": base[0], "fit": base[1], "test": base[2]}, "filters": filt,
            "conf": conf_cmp, "combo": {"keys": chosen, "labels": [labs[x] for x in chosen], "steps": steps,
                                       "proven": bool(steps and (steps[-1]["test"]["exp"] or 0) > 0 and (steps[-1]["test"]["exp"] or 0) > (base[2]["exp"] or 0))},
            "examples": exs}


def _disk(tf):
    from .results_store import BASE
    return os.path.join(BASE, "sweeplab_cache", f"res_{tf}.json")          # bukan folder hasil tersimpan


# ================================================================== per koin (bisa paralel di proses terpisah)
_W = {}


def _init_worker(data_dir):
    from .data import DataStore
    _W["store"] = DataStore(data_dir, cache_size=4)


def coin_job(sym, tf, store=None):
    """1 koin -> (agregat, contoh, jumlah sweep, jumlah candle) atau pesan galat."""
    from .tapro import map_closed, trend_of
    st = store or _W["store"]
    try:
        b = st.get(sym, tf)
        if len(b.c) < 500:
            return f"data terlalu sedikit ({len(b.c)} candle)"
        t = np.asarray(b.t, np.int64)
        o, h, l, c = (np.asarray(z, float) for z in (b.o, b.h, b.l, b.c))
        v = np.asarray(getattr(b, "v", np.ones(len(c))), float)
        tr = {}
        for big in ("4h", "1d"):
            if big in st.timeframes(sym) and TF_MS[big] > TF_MS[tf]:
                bb = st.get(sym, big)
                tc, trb, _ = trend_of(np.asarray(bb.t, np.int64), np.asarray(bb.c, float), big)
                tr[big] = map_closed(t, tf, tc, trb)
        A, EX, nev = aggregate(iter_rows(sym, t, o, h, l, c, v, tf, tr.get("4h"), tr.get("1d")))
        return A, EX, nev, len(c)
    except (ValueError, KeyError, IndexError, OSError) as ex:
        return f"{type(ex).__name__}: {ex}"


def run(store, tf, syms, progress=None, push=None, workers=None):
    """Backtest semua koin (paralel kalau bisa). push(partial) = hasil sementara tiap koin selesai."""
    key = (VERSION, tf, tuple(syms), tuple(int(store.get(s_, tf).t[-1]) for s_ in syms), window_bars(tf), AG._cfg_sig(AG.whale_cfg.get()))
    kstr = json.dumps([list(x) if isinstance(x, tuple) else x for x in key], default=str)
    if kstr in _CACHE:
        return _CACHE[kstr]
    try:
        with open(_disk(tf), encoding="utf-8") as f_:
            D = json.load(f_)
        if D.get("key") == kstr:
            D["res"]["from_file"] = True
            _CACHE[kstr] = D["res"]
            return D["res"]
    except (OSError, ValueError, KeyError):
        pass
    t0 = time.time()
    A, EX, used, skipped, n_ev, n_c = {}, {}, [], [], 0, 0
    per_coin = []

    def take(i, s_, res):
        nonlocal n_ev, n_c
        if isinstance(res, str):
            skipped.append(f"{s_}: {res}")
        else:
            a2, ex2, ne, nc = res
            merge(A, EX, a2, ex2)
            used.append(s_); n_ev += ne; n_c += nc
            per_coin.append({"sym": s_, "sweeps": ne})
        if progress:
            progress(i + 1, len(syms), s_, isinstance(res, str))
        if push and (i < 5 or (i + 1) % 5 == 0 or i + 1 == len(syms)):        # ringkasan sementara (agregat murah)
            part = analyse(A, EX) if A else {}
            part.update(partial=True, phase="riwayat", tf=tf, coins=list(used), done=i + 1, total=len(syms), n_events=n_ev, candles=n_c,
                        per_coin=per_coin[-12:], skipped=skipped[-5:], elapsed=round(time.time() - t0, 1))
            part.pop("examples", None)
            push(part)
    workers = workers if workers is not None else max(1, min(8, (os.cpu_count() or 2) - 1))
    done = False
    if workers > 1 and len(syms) > 2:
        try:
            from concurrent.futures import ProcessPoolExecutor, as_completed
            with ProcessPoolExecutor(max_workers=workers, initializer=_init_worker, initargs=(store.data_dir,)) as ex_:
                futs = {ex_.submit(coin_job, s_, tf): s_ for s_ in syms}
                for i, fu in enumerate(as_completed(futs)):
                    try:
                        res = fu.result()
                    except Exception as e:                                     # noqa: BLE001 - 1 koin gagal: lanjut
                        res = f"{type(e).__name__}: {e}"
                    take(i, futs[fu], res)
            done = True
        except (OSError, RuntimeError, ImportError):
            A, EX, used, skipped, n_ev, n_c, per_coin = {}, {}, [], [], 0, 0, []
    if not done:
        for i, s_ in enumerate(syms):
            take(i, s_, coin_job(s_, tf, store))
    if push:
        push({"partial": True, "phase": "analisa", "done": len(syms), "total": len(syms), "tf": tf, "coins": used, "n_events": n_ev})
    res = analyse(A, EX)
    res.update(tf=tf, coins=used, skipped=skipped[:20], n_skipped=len(skipped), n_events=n_ev, candles=n_c, window=window_bars(tf),
               n_trades=sum(v[0] for v in A.values()), elapsed=round(time.time() - t0, 1), v=VERSION, workers=workers)
    if len(_CACHE) > 6:
        _CACHE.clear()
    _CACHE[kstr] = res
    try:
        os.makedirs(os.path.dirname(_disk(tf)), exist_ok=True)
        with open(_disk(tf) + ".tmp", "w", encoding="utf-8") as f_:
            json.dump({"key": kstr, "res": res}, f_, default=float)
        os.replace(_disk(tf) + ".tmp", _disk(tf))
    except (OSError, TypeError, ValueError):
        pass
    return res


def history_symbols(store, tf, n=30):
    syms = [s_ for s_ in store.symbols() if tf in store.timeframes(s_)] if hasattr(store, "symbols") else []
    syms.sort(key=lambda s_: -len(store.get(s_, tf).c))
    return syms[:n]


def candles_around(store, sym, tf, t_ms, before=60, after=None):
    """Candle di sekitar 1 contoh trade (untuk gambar visual contoh)."""
    b = store.get(sym, tf)
    t = np.asarray(b.t, np.int64)
    i = int(np.searchsorted(t, int(t_ms)))
    after = after if after is not None else min(150, window_bars(tf) + 30)
    a0, a1 = max(0, i - before), min(len(t), i + after)
    return [[int(t[k]), float(b.o[k]), float(b.h[k]), float(b.l[k]), float(b.c[k])] for k in range(a0, a1)], i - a0
