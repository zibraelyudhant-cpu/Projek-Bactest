"""Info CPU & RAM untuk menentukan jumlah proses paralel yang aman (tanpa library tambahan)."""
import ctypes
import os
import sys

GB = 1024 ** 3
PER_WORKER_GB = 0.5     # perkiraan memori per proses paralel (data koin + numpy), dengan cadangan
MAX_DEFAULT = 8         # default tidak lebih dari ini; pengguna tetap bisa mengisi angka lebih besar


def memory():
    """(total, tersedia) dalam byte, atau (None, None) kalau tidak bisa dibaca."""
    try:
        if sys.platform == "win32":
            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
                # di Windows yang membatasi adalah "commit" (RAM + pagefile) yang masih tersedia
                return m.ullTotalPhys, min(m.ullAvailPhys + m.ullAvailPageFile // 4, m.ullAvailPageFile)
            return None, None
        if os.path.exists("/proc/meminfo"):
            info = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    k, v = line.split(":", 1)
                    info[k] = int(v.split()[0]) * 1024
            return info.get("MemTotal"), info.get("MemAvailable", info.get("MemFree"))
        if hasattr(os, "sysconf"):
            pages, size = os.sysconf("SC_PHYS_PAGES"), os.sysconf("SC_PAGE_SIZE")
            return pages * size, None
    except (OSError, ValueError, AttributeError):
        pass
    return None, None


def recommended_workers():
    cpus = os.cpu_count() or 2
    n = min(max(1, cpus - 1), MAX_DEFAULT)
    _, avail = memory()
    if avail:
        n = min(n, max(1, int(avail / GB / PER_WORKER_GB)))
    return n


def info():
    total, avail = memory()
    return {"cpus": os.cpu_count() or 1, "ram_total_gb": round(total / GB, 1) if total else None,
            "ram_free_gb": round(avail / GB, 1) if avail else None, "recommended": recommended_workers()}
