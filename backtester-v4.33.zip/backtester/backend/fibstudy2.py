"""Studi Fibonacci v2: mesin yang sama persis dengan fibstudy.py (kode dimuat ulang di modul ini), hanya beda set
angka fibo dan TF default (fibo M5, kondisi pasar & tren H1).

Set angka: -0.618, -0.414, -0.272, -0.13, 0, 0.295, 0.382, 0.441, 0.5, 0.559, 0.618, 0.705, 1, 1.13, 1.272, 1.414, 1.618
"""
import os

_SRC = os.path.join(os.path.dirname(__file__), "fibstudy.py")
with open(_SRC, encoding="utf-8") as _f:
    exec(compile(_f.read(), _SRC, "exec"), globals())   # noqa: S102  fungsi & kelas fibstudy, memakai konstanta di bawah

VERSION = 2
LEVELS = [-0.618, -0.414, -0.272, -0.13, 0.0, 0.295, 0.382, 0.441, 0.5, 0.559, 0.618, 0.705, 1.0, 1.13, 1.272, 1.414, 1.618]
RET = [0.295, 0.382, 0.441, 0.5, 0.559, 0.618, 0.705, 1.0]                  # level limit entry (koreksi)
BRK = [0.295, 0.382, 0.441, 0.5, 0.559, 0.618, 0.705]                       # level "tembus" (close) -> BOS?
EXT = [1.13, 1.272, 1.414, 1.618]                                          # sejauh apa setelah BOS (struktur patah)
TGT = [0.0, -0.272, -0.618]
TGT_NAME = ["0", "-0.272", "-0.618"]
BINS = [0.0, 0.295, 0.382, 0.441, 0.5, 0.559, 0.618, 0.705, 1.0]
BOK = [0.0, -0.13, -0.272]                                                 # level tembus breakout sideways
SLC = [0.705, 1.0, 1.13, 1.272, 1.414, 1.618]                              # kandidat SL
TP_CAND = [0.618, 0.559, 0.5, 0.441, 0.382, 0.295, 0.0, -0.13, -0.272, -0.414, -0.618]
ZONES = ((0.295, 0.382), (0.382, 0.5), (0.5, 0.618), (0.618, 0.705), (0.705, 1.0))
TLV = [0.295, 0.382, 0.441, 0.5, 0.559, 0.618, 0.705]                      # studi BOS / CHoCH
TEXT = [0.13, 0.272, 0.414, 0.618]
RT_LV = [0.295, 0.382, 0.441, 0.5, 0.559, 0.618, 0.705]
DEFAULTS = {**DEFAULTS, "tf": "5m", "regime_tf": "1h", "trend_tf": "1h", "scan": True}   # noqa: F821  scan = cari angka rahasia
KNOWN = sorted(set(KNOWN + LEVELS))   # noqa: F821  angka umum + set v2 (bukan rahasia)
JOB_KIND = "fib2"
