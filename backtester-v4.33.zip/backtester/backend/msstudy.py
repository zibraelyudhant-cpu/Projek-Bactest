"""📐 Analisa Market Structure: statistik kebiasaan struktur pasar di TF yang dipilih (deskriptif, bukan sinyal).

Definisi (tetap):
- Swing = fractal k (kecil 3 / sedang 5 / besar 10), baru DIKETAHUI k candle sesudahnya.
- Label swing (dibanding swing sejenis sebelumnya, urutan selang-seling high/low): HH / LH / EH (sama), HL / LL / EL.
- Tren naik: BOS = close menembus PUNCAK tren (swing high tertinggi yang sudah terkonfirmasi sejak BOS terakhir).
  CHoCH turun = close menembus LOW YANG DILINDUNGI (swing low terakhir sebelum BOS terakhir; sebelum BOS pertama =
  titik terendah yang memicu CHoCH). Tren turun kebalikannya.
- Tren = dari CHoCH sampai CHoCH berikutnya. CHoCH VALID kalau tren barunya berhasil membuat >= 1 BOS, PALSU kalau tidak.
- Koreksi = dari puncak (high tertinggi sebelum BOS berikutnya) sampai puncak itu ditembus (BOS) atau sampai CHoCH.
"""
import time

import numpy as np

from .data import TF_MS
from .indicators import atr as _atr, pivots

SWINGS = {"kecil": 3, "sedang": 5, "besar": 10}
EQ_TOL = 0.1           # ATR: dua swing dianggap sama tinggi
KMAX = 8               # tabel peluang sampai BOS / HH ke-8
DEFAULTS = {"tf": "15m", "n": 5000, "swing": "kecil", "top_seq": 8}


def _params(p):
    q = dict(DEFAULTS, **{k: v for k, v in (p or {}).items() if k in DEFAULTS})
    if q["tf"] not in TF_MS:
        raise ValueError("TF tidak dikenal")
    q["n"] = int(min(max(int(q["n"]), 500), 200_000))
    if q["swing"] not in SWINGS:
        q["swing"] = "kecil"
    return q


# ---------------------------------------------------------------------------- swing berlabel (urutan akhir)
def swing_seq(h, l, a, k):
    """Urutan swing selang-seling [(idx, harga, 'H'/'L', label)] (label None untuk swing pertama tiap jenis)."""
    hi, lo = pivots(h, l, k)
    ev = sorted([(int(i), "H") for i in hi] + [(int(i), "L") for i in lo])
    seq = []
    for p, typ in ev:
        price = float(h[p] if typ == "H" else l[p])
        if seq and seq[-1][2] == typ:
            if (typ == "H" and price <= seq[-1][1]) or (typ == "L" and price >= seq[-1][1]):
                continue
            seq.pop()
        prev = next((x for x in reversed(seq) if x[2] == typ), None)
        lab = None
        if prev is not None:
            tol = EQ_TOL * (a[p] if a[p] == a[p] else 0.0)
            if abs(price - prev[1]) <= tol:
                lab = "EH" if typ == "H" else "EL"
            elif typ == "H":
                lab = "HH" if price > prev[1] else "LH"
            else:
                lab = "LL" if price < prev[1] else "HL"
        seq.append((p, price, typ, lab))
    # label ulang setelah penggabungan (swing yang diganti mengubah pembanding)
    out, last = [], {}
    for p, price, typ, _ in seq:
        prev = last.get(typ)
        lab = None
        if prev is not None:
            tol = EQ_TOL * (a[p] if a[p] == a[p] else 0.0)
            if abs(price - prev) <= tol:
                lab = "EH" if typ == "H" else "EL"
            elif typ == "H":
                lab = "HH" if price > prev else "LH"
            else:
                lab = "LL" if price < prev else "HL"
        out.append((p, price, typ, lab))
        last[typ] = price
    return out


def label_runs(seq):
    """Panjang deret HH berturut-turut (di urutan swing HIGH) sebelum muncul bukan-HH (LH / EH = koreksi), dan deret LL
    berturut-turut (di swing LOW) sebelum muncul bukan-LL. Deret yang belum selesai di akhir data dibuang."""
    out = {}
    for typ, want in (("H", "HH"), ("L", "LL")):
        labs = [x[3] for x in seq if x[2] == typ and x[3] is not None]
        runs, cur = [], 0
        for lb in labs:
            if lb == want:
                cur += 1
            else:
                if cur:
                    runs.append(cur)
                cur = 0
        out[want] = runs
    return out


# ---------------------------------------------------------------------------- tren BOS / CHoCH (kausal)
def trends(h, l, c, k):
    """Tren dari candle ke candle (swing dipakai setelah terkonfirmasi). Hasil: list tren lengkap
    {dir, start, end, bos: [indeks candle BOS], segs: [koreksi], valid} + tren terakhir yang belum selesai dibuang."""
    n = len(c)
    hi, lo = pivots(h, l, k)
    conf = {}
    for i in hi:
        conf.setdefault(int(i) + k, []).append((int(i), "H"))
    for i in lo:
        conf.setdefault(int(i) + k, []).append((int(i), "L"))
    trend, start = 0, 0
    last_sh = last_sl = None          # swing terakhir yang sudah terkonfirmasi (idx, harga)
    peak = None                       # puncak tren naik / dasar tren turun sejak BOS terakhir (idx, harga) dari swing terkonfirmasi
    prot = None                       # level dilindungi (harga)
    bos, out = [], []
    seg_from = None                   # indeks BOS terakhir (awal segmen)

    origin = 0                        # indeks titik ekstrem awal tren (low terendah sebelum CHoCH naik / high tertinggi sebelum CHoCH turun)

    def close_trend(i):
        out.append({"dir": trend, "start": start, "end": i, "bos": list(bos), "origin": origin})

    for i in range(n):
        for p, typ in conf.get(i, []):
            if typ == "H":
                last_sh = (p, float(h[p]))
                if trend == 1 and (peak is None or h[p] > peak[1]):
                    peak = (p, float(h[p]))
            else:
                last_sl = (p, float(l[p]))
                if trend == -1 and (peak is None or l[p] < peak[1]):
                    peak = (p, float(l[p]))
        ci = c[i]
        if trend == 1:
            if peak is not None and ci > peak[1]:                     # BOS naik (dicatat bersama swing puncak yang ditembus)
                bos.append((i, peak[0]))
                prot = last_sl[1] if last_sl is not None and last_sl[0] < i else prot
                peak = None
            elif prot is not None and ci < prot:                      # CHoCH turun
                close_trend(i)
                low_from = bos[-1][0] if bos else start
                trend, start, bos = -1, i, []
                origin = low_from + int(np.argmax(h[low_from:i + 1]))
                prot = float(h[origin])                               # titik tertinggi yang memicu CHoCH
                peak = None
        elif trend == -1:
            if peak is not None and ci < peak[1]:
                bos.append((i, peak[0]))
                prot = last_sh[1] if last_sh is not None and last_sh[0] < i else prot
                peak = None
            elif prot is not None and ci > prot:
                close_trend(i)
                hi_from = bos[-1][0] if bos else start
                trend, start, bos = 1, i, []
                origin = hi_from + int(np.argmin(l[hi_from:i + 1]))
                prot = float(l[origin])
                peak = None
        else:                                                         # belum ada tren: tunggu tembus swing pertama
            if last_sh is not None and ci > last_sh[1]:
                trend, start, prot = 1, i, (last_sl[1] if last_sl else float(l[max(0, i - 50):i + 1].min()))
            elif last_sl is not None and ci < last_sl[1]:
                trend, start, prot = -1, i, (last_sh[1] if last_sh else float(h[max(0, i - 50):i + 1].max()))
    return out[1:] if len(out) > 1 else []                            # tren pertama mulai dari "belum ada tren": dibuang


def _segments(tr, h, l, a):
    """Koreksi di dalam tren. Yang berakhir BOS: dari swing PUNCAK yang ditembus BOS itu sampai candle BOS.
    Yang berakhir CHoCH: dari titik ekstrem sejak BOS terakhir sampai candle CHoCH (koreksi yang jadi pembalikan)."""
    d = tr["dir"]
    segs = []
    prev = tr["start"]
    org_i = tr["origin"]                                              # impuls pertama mulai dari titik ekstrem awal tren
    items = [(i, pk, True) for i, pk in tr["bos"]]
    if tr["end"] - prev >= 2:
        a0 = tr["bos"][-1][0] if tr["bos"] else tr["start"]
        rng = slice(a0, tr["end"])
        pk_end = a0 + int(np.argmax(h[rng]) if d == 1 else np.argmin(l[rng]))
        items.append((tr["end"], pk_end, False))
    for b0, pk, is_bos in items:
        a0 = prev
        prev = b0
        if not (a0 <= pk < b0):
            continue
        pv = h[pk] if d == 1 else l[pk]
        tv = l[pk:b0 + 1].min() if d == 1 else h[pk:b0 + 1].max()
        lo_i = min(org_i, pk)
        org = l[lo_i:pk + 1].min() if d == 1 else h[lo_i:pk + 1].max()   # awal impuls = titik balik terakhir sebelum puncak
        imp = abs(pv - org)
        A = a[pk] if a[pk] == a[pk] and a[pk] > 0 else np.nan
        segs.append({"peak": int(pk), "end": int(b0), "ends_bos": bool(is_bos),
                     "corr_bars": int(b0 - pk), "imp_bars": int(pk - lo_i),
                     "depth_fib": float(abs(pv - tv) / imp) if imp > 0 else np.nan,
                     "depth_atr": float(abs(pv - tv) / A), "depth_pct": float(abs(pv - tv) / pv * 100),
                     "imp_atr": float(imp / A), "imp_pct": float(imp / (org if org else pv) * 100)})
        # impuls berikutnya mulai dari titik terdalam koreksi ini
        org_i = pk + int(np.argmin(l[pk:b0 + 1]) if d == 1 else np.argmax(h[pk:b0 + 1]))
    return segs


def study_coin(store, sym, q):
    b = store.get(sym, q["tf"])
    t, o, h, l, c = (np.asarray(x, float) for x in (b.t, b.o, b.h, b.l, b.c))
    n = min(len(c), q["n"])
    if n < 300:
        return f"data terlalu sedikit ({len(c)} candle)"
    t, h, l, c = t[-n:], h[-n:], l[-n:], c[-n:]
    a = _atr(h, l, c, 14)
    k = SWINGS[q["swing"]]
    seq = swing_seq(h, l, a, k)
    runs = label_runs(seq)
    TR = trends(h, l, c, k)
    half = n // 2
    trs, segs = [], []
    for tr in TR:
        tr["valid"] = len(tr["bos"]) >= 1
        tr["dur"] = tr["end"] - tr["start"]
        tr["half"] = int(tr["start"] >= half)
        inside = [x for x in seq if tr["start"] <= x[0] < tr["end"] and x[3] is not None]
        tr["labels"] = {lb: sum(1 for x in inside if x[3] == lb) for lb in ("HH", "LH", "EH", "HL", "LL", "EL")}
        before = [x[3] for x in seq if x[0] + k <= tr["end"] and x[3] is not None][-4:]
        tr["seq_before_end"] = ">".join(before)
        tr["to_bos"] = (tr["bos"][0][0] - tr["start"]) if tr["bos"] else None
        for s_ in _segments(tr, h, l, a):
            s_["dir"], s_["half"] = tr["dir"], tr["half"]
            segs.append(s_)
        trs.append({k_: tr[k_] for k_ in ("dir", "start", "end", "valid", "dur", "half", "labels", "seq_before_end", "to_bos")}
                   | {"n_bos": len(tr["bos"]), "t0": int(t[tr["start"]]), "t1": int(t[tr["end"]]),
                      "swings": [{"time": int(t[x[0]]), "price": x[1], "label": x[3]} for x in seq
                                 if tr["start"] - 40 <= x[0] <= tr["end"] and x[3] is not None][-30:]})
    return {"symbol": sym, "n": n, "trends": trs, "segs": segs, "runs": runs}


# ---------------------------------------------------------------------------- ringkasan
def _q(x):
    x = np.asarray([v for v in x if v is not None and v == v], float)
    if not len(x):
        return None
    return {"n": int(len(x)), "p25": float(np.percentile(x, 25)), "med": float(np.median(x)), "p75": float(np.percentile(x, 75)),
            "mean": float(x.mean())}


def _hazard(counts):
    """counts = jumlah per kejadian (mis. BOS per tren). Tabel: dari yang mencapai >= k, berapa % berhenti di k."""
    counts = np.asarray(counts, int)
    rows = []
    for kk in range(0, KMAX + 1):
        reach = int((counts >= kk).sum())
        if reach < 5:
            break
        stop = int((counts == kk).sum())
        rows.append({"k": kk, "reach": reach, "stop": stop, "pct_stop": 100 * stop / reach, "pct_go": 100 * (reach - stop) / reach})
    return rows


def summarize(parts, q, used, skipped, t0):
    TF_H = TF_MS[q["tf"]] / 3_600_000
    trs = [x for p in parts for x in p["trends"]]
    segs = [x for p in parts for x in p["segs"]]
    res = {"params": q, "symbols": used, "skipped": skipped[:20], "n_skipped": len(skipped), "tf_hours": TF_H,
           "n_trends": len(trs), "n_segs": len(segs), "candles": int(sum(p["n"] for p in parts)), "elapsed": round(time.time() - t0, 1)}
    by = {}
    for d, name in ((1, "naik"), (-1, "turun")):
        T = [x for x in trs if x["dir"] == d]
        S = [x for x in segs if x["dir"] == d]
        S_b = [x for x in S if x["ends_bos"]]
        S_r = [x for x in S if not x["ends_bos"]]
        lab_keys = ("HH", "LH", "HL", "LL", "EH", "EL")
        hz = _hazard([x["n_bos"] for x in T])
        g = {"n": len(T), "dur": _q([x["dur"] for x in T]), "n_bos": _q([x["n_bos"] for x in T]), "hazard": hz,
             "valid_pct": 100 * sum(x["valid"] for x in T) / len(T) if T else None,
             "to_bos": _q([x["to_bos"] for x in T if x["valid"]]),
             "labels": {lb: _q([x["labels"][lb] for x in T]) for lb in lab_keys},
             "corr": {"bars": _q([x["corr_bars"] for x in S_b]), "fib": _q([x["depth_fib"] for x in S_b]),
                      "atr": _q([x["depth_atr"] for x in S_b]), "pct": _q([x["depth_pct"] for x in S_b])},
             "rev": {"bars": _q([x["corr_bars"] for x in S_r]), "fib": _q([x["depth_fib"] for x in S_r]), "n": len(S_r)},
             "imp": {"bars": _q([x["imp_bars"] for x in S]), "atr": _q([x["imp_atr"] for x in S]), "pct": _q([x["imp_pct"] for x in S])},
             "corr_end_bos_pct": 100 * len(S_b) / len(S) if S else None,
             "halves": [{"dur": _q([x["dur"] for x in T if x["half"] == hf]), "n_bos": _q([x["n_bos"] for x in T if x["half"] == hf]),
                         "corr": _q([x["corr_bars"] for x in S_b if x["half"] == hf]),
                         "valid_pct": (100 * sum(x["valid"] for x in T if x["half"] == hf) / max(1, sum(1 for x in T if x["half"] == hf)))
                         if any(x["half"] == hf for x in T) else None} for hf in (0, 1)]}
        # urutan swing yang paling sering tepat sebelum tren ini BERAKHIR (CHoCH berlawanan)
        cnt = {}
        for x in T:
            if x["seq_before_end"].count(">") >= 2:
                cnt[x["seq_before_end"]] = cnt.get(x["seq_before_end"], 0) + 1
        tot = sum(cnt.values())
        g["seq_end"] = [{"seq": s_, "n": n_, "pct": 100 * n_ / tot} for s_, n_ in sorted(cnt.items(), key=lambda z: -z[1])[:q["top_seq"]]] if tot else []
        by[name] = g
    res["by"] = by
    res["runs"] = {lab: {"stats": _q(sum((p["runs"][lab] for p in parts), [])), "hazard": [r for r in _hazard(sum((p["runs"][lab] for p in parts), [])) if r["k"] >= 1]}
                   for lab in ("HH", "LL")}
    ex = []
    for p in parts:
        for x in p["trends"][-40:]:
            ex.append({"symbol": p["symbol"], "dir": x["dir"], "t0": x["t0"], "t1": x["t1"], "n_bos": x["n_bos"], "valid": x["valid"],
                       "dur": x["dur"], "swings": x["swings"], "seq": x["seq_before_end"]})
    res["examples"] = sorted(ex, key=lambda e: -e["t1"])[:300]
    return res


# ---------------------------------------------------------------------------- job API (StudyJobs)
_WS = {}


def _init_worker(data_dir):
    from .data import DataStore
    _WS["store"] = DataStore(data_dir, cache_size=4)


def _one(sym, q, store=None):
    try:
        return study_coin(store or _WS["store"], sym, q)
    except Exception as ex:                                  # noqa: BLE001
        return f"{type(ex).__name__}: {ex}"


def job_total(q, symbols):
    return len(symbols)


def job_state(q, symbols):
    return {"parts": [], "used": [], "skipped": [], "t0": time.time()}


def job_call(state, q, symbols, i):
    return _one, (symbols[i], q)


def job_merge(state, q, symbols, i, res):
    if isinstance(res, str):
        state["skipped"].append(f"{symbols[i]}: {res}")
        return
    state["parts"].append(res)
    state["used"].append(symbols[i])


def job_finalize(state, q, symbols, partial=False):
    return summarize(state["parts"], q, state["used"], state["skipped"], state["t0"]) | {"partial": partial}


def run(store, symbols, p, progress=None):
    q = _params(p)
    state = job_state(q, symbols)
    for i, sym in enumerate(symbols):
        job_merge(state, q, symbols, i, _one(sym, q, store))
    return job_finalize(state, q, symbols)
