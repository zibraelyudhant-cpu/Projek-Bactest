"""API strategi untuk mode auto backtest.

Strategi hanya berinteraksi lewat `ctx`, yang hanya memberi bar yang sudah close.
Sinyal dihitung di close bar, order dieksekusi paling cepat di bar berikutnya.
"""
from types import SimpleNamespace

from .data import TF_MS


ENTRY_MODES = ["market", "limit_close", "limit_pct", "limit_atr", "limit_level", "limit_mid"]
LEGACY_ENTRY = {"retest": "limit_level", "close": "market", "edge": "limit_level", "mid": "limit_mid"}

COMMON_HELP = {
    "entry": "market = langsung | limit_close = limit di close candle sinyal | limit_pct = limit lebih bagus "
             "limit_offset_pct % | limit_atr = limit lebih bagus limit_atr x ATR | limit_level / limit_mid = "
             "limit di level kunci / tengah zona strategi (lihat deskripsi)",
    "limit_offset_pct": "Untuk entry limit_pct: jarak limit dari close sinyal (%)",
    "limit_atr": "Untuk entry limit_atr: jarak limit dari close sinyal (x ATR 14)",
    "tf": "Timeframe entry (on_bar dipanggil tiap candle TF ini close)",
    "htf": "Timeframe besar untuk arah/bias",
    "rr": "Take profit = rr x jarak SL (RR 1:rr)",
    "risk_usdt": "Rugi per trade kalau kena SL, dalam USDT (sudah termasuk fee). 0 = pakai risk_pct",
    "risk_pct": "Rugi per trade dalam % equity (dipakai kalau risk_usdt = 0)",
    "long": "Izinkan posisi long", "short": "Izinkan posisi short",
    "adx_len": "Periode ADX", "atr_len": "Periode ATR", "sl_atr": "SL = N x ATR dari harga entry",
    "vol_ma": "Periode rata-rata volume", "vol_mult": "Volume candle breakout minimal N x rata-rata (0 = mati)",
    "expire_bars": "Limit order batal kalau tidak tersentuh dalam N candle",
    "swing": "Ukuran swing/fractal: N candle kiri & kanan",
    "sl_buffer_pct": "Jarak tambahan SL (%)",
}


# Filter tambahan yang berlaku untuk SEMUA strategi (dicek di ctx.trade sebelum order dipasang).
# Default mati, jadi hasil strategi tidak berubah kalau tidak diisi.
FILTERS = {"ms_filter_tf": "", "ms_confirm_tf": "", "ms_swing": 3, "adx_filter_tf": "", "adx_filter_min": 20,
           "rules": "", "sl_mult": 1.0, "tp_rr": 0.0, "entry_shift_r": 0.0}
FILTER_HELP = {
    "ms_filter_tf": "Filter struktur TF besar: hanya entry searah Break of Structure terakhir di TF ini "
                    "(long kalau BOS terakhir ke atas, short kalau ke bawah). Kosong = mati",
    "ms_confirm_tf": "Filter struktur TF eksekusi: entry hanya kalau BOS terakhir di TF ini juga sudah searah "
                     "(sudah CHoCH/BOS). Kosong = mati",
    "ms_swing": "Ukuran swing untuk filter struktur (fractal N candle kiri & kanan)",
    "adx_filter_tf": "Filter tren: entry hanya kalau ADX 14 di TF ini > adx_filter_min. Kosong = mati",
    "adx_filter_min": "Batas ADX untuk adx_filter_tf",
    "rules": "Filter indikator bebas, pisahkan dengan ; . Contoh: rsi@1h >= 55; adx@4h >= 20; sl_atr <= 1.5 . "
             "Fitur: e50 e200 slope stack bos rsi adx di macd fi atrp atrx vol rpos bbw candle stoch (pakai @TF), "
             "sl_atr rr depth side asia london ny late (tanpa TF). Nilai 'searah' arah trade. Kosong = mati",
    "sl_mult": "Kali jarak SL dari strategi (1 = tetap, 1.5 = SL 50% lebih jauh)",
    "tp_rr": "TP = N x jarak SL (menimpa TP strategi). 0 = pakai TP strategi",
    "entry_shift_r": "Geser entry N x jarak SL ke arah SL (entry limit lebih dalam). 0 = mati",
}


class Strategy:
    timeframe = "1h"   # on_bar dipanggil setiap bar TF ini close
    params = {}
    param_help = {}   # penjelasan parameter yang tampil di formulir backtest
    param_choices = {"entry": ENTRY_MODES, "tp_mode": ["range", "rr"]}   # pilihan dropdown di formulir
    atr_tf = {}   # parameter -> daftar parameter TF (pertama yang terisi) tempat ATR-nya dihitung; default = TF entry

    def __init__(self, **params):
        self.p = SimpleNamespace(**{**FILTERS, **self.params, **params})
        if getattr(self.p, "tf", None):   # parameter "tf" = TF on_bar (bisa diganti dari UI)
            self.timeframe = self.p.tf

    def on_start(self, ctx):
        pass

    def on_bar(self, ctx):
        raise NotImplementedError

    def on_fill(self, ctx, fill):
        pass


class Context:
    def __init__(self, engine, timeframe):
        self._e = engine
        self._tf = timeframe
        self._tf_ms = TF_MS[timeframe]
        self.p = None   # parameter strategi (diisi runner) untuk filter umum

    @property
    def now(self):
        return self._e.now

    def closed(self, tf, n=500):
        """Bar `tf` yang sudah close (copy). bars.c[-1] = close bar terakhir."""
        return self._e.view.closed(tf, n)

    def closed_symbol(self, symbol, tf, n=500):
        """Bar `tf` koin LAIN (mis. BTCUSDT) yang sudah close di waktu replay yang sama. None kalau datanya tidak ada."""
        from .data import DataView
        symbol = symbol.upper()
        if symbol == self._e.symbol:
            return self.closed(tf, n)
        views = self.__dict__.setdefault("_views", {})
        if symbol not in views:
            views[symbol] = DataView(self._e.store, symbol, lambda: self._e.now) if symbol in self._e.store.catalog else None
        return views[symbol].closed(tf, n) if views[symbol] else None

    @property
    def position(self):
        e = self._e
        return SimpleNamespace(qty=e.pos, entry=e.entry, flat=abs(e.pos) < 1e-12,
                               long=e.pos > 0, short=e.pos < 0, liq=e.liq_price())

    @property
    def equity(self):
        return self._e.equity()

    def _order(self, side, qty, type, price, tp, sl, expire_bars, reduce_only, tag):
        exp = None if not expire_bars else self.now + expire_bars * self._tf_ms
        return self._e.place(side, type, qty, price, tp, sl, reduce_only, exp, tag)

    def buy(self, qty, type="market", price=None, tp=None, sl=None, expire_bars=None, reduce_only=False, tag=""):
        return self._order("buy", qty, type, price, tp, sl, expire_bars, reduce_only, tag)

    def sell(self, qty, type="market", price=None, tp=None, sl=None, expire_bars=None, reduce_only=False, tag=""):
        return self._order("sell", qty, type, price, tp, sl, expire_bars, reduce_only, tag)

    def close(self):
        return self._e.close_position()

    def cancel(self, order_id):
        self._e.cancel(order_id)

    def cancel_all(self):
        self._e.cancel_all()

    def open_orders(self):
        return self._e.open_orders()

    def qty_for_loss(self, entry, sl, usdt, entry_type="market"):
        """Qty supaya rugi saat SL kena = usdt, sudah termasuk fee masuk/keluar dan slippage stop."""
        c = self._e.cfg
        fee_in = c.maker_fee if entry_type == "limit" else c.taker_fee
        unit = abs(entry - sl) + entry * fee_in + sl * (c.taker_fee + c.slippage_bps / 10_000)
        return usdt / unit if unit > 0 else 0.0

    def trade(self, side, entry, sl, tp, risk_usdt=0.0, risk_pct=1.0, type="market", expire_bars=None, tag=""):
        """Pasang order dengan qty dari risiko: rugi di SL = risk_usdt (kalau > 0) atau risk_pct% equity.
        type "market": entry di open candle berikutnya; "limit"/"stop": order di harga `entry`.
        Return None kalau SL/TP tidak masuk akal (mis. SL di sisi yang salah)."""
        ok = sl < entry < tp if side == "buy" else tp < entry < sl
        d = 1 if side == "buy" else -1
        if ok and not self._filters_ok(d, entry, sl, tp):
            return None
        if ok and self.p is not None:   # penyesuaian umum SL / entry / TP (dari analisa evaluasi)
            R = abs(entry - sl)
            k = float(getattr(self.p, "sl_mult", 1.0) or 1.0)
            if k != 1.0:
                sl = entry - d * k * R
            shift = float(getattr(self.p, "entry_shift_r", 0.0) or 0.0)
            if shift > 0 and d * (entry - d * shift * R - sl) > 0:
                entry = entry - d * shift * R
                if type == "market":
                    type, expire_bars = "limit", getattr(self.p, "expire_bars", 12)
            rr = float(getattr(self.p, "tp_rr", 0.0) or 0.0)
            if rr > 0:
                tp = entry + d * rr * abs(entry - sl)
        usdt = risk_usdt if risk_usdt and risk_usdt > 0 else self.equity * risk_pct / 100
        qty = self.qty_for_loss(entry, sl, usdt, type) if ok else 0.0
        if qty <= 0:
            return None
        return self._order(side, qty, type, None if type == "market" else entry, tp, sl, expire_bars, False, tag)

    def _filters_ok(self, d, entry=None, sl=None, tp=None):
        p = self.p
        if p is None:
            return True
        text = getattr(p, "rules", "")
        if text and entry is not None:
            from .mining import parse_rules, rules_ok
            if getattr(self, "_rules_src", None) != text:
                self._rules_src, self._rules = text, parse_rules(text)
            exec_tf = getattr(p, "tf", "") or getattr(p, "confirm_tf", "") or self._tf
            if not rules_ok(self._rules, self.closed, d, entry, sl, tp, self._e.last_price, self.now, exec_tf):
                return False
        from .indicators import adx, bos_bias
        n = int(getattr(p, "ms_swing", 3) or 3)
        for tf in (getattr(p, "ms_filter_tf", ""), getattr(p, "ms_confirm_tf", "")):
            if tf:
                b = self.closed(tf, 300)
                if len(b) <= 4 * n or bos_bias(b.h, b.l, b.c, n) != d:
                    return False
        tf = getattr(p, "adx_filter_tf", "")
        if tf:
            b = self.closed(tf, 150)
            a = adx(b.h, b.l, b.c, 14)[-1] if len(b) >= 45 else float("nan")
            if not a > getattr(p, "adx_filter_min", 20):
                return False
        return True

    def limit_price(self, side, signal, p, level=None, mid=None, sl=None):
        """Harga & jenis entry sesuai p.entry: (harga, "limit"/"market"). Kalau harga sudah melewati level
        limit (atau level limit melewati SL), entry jatuh ke market di harga sinyal."""
        d = 1 if side == "buy" else -1
        mode = LEGACY_ENTRY.get(getattr(p, "entry", "market"), getattr(p, "entry", "market"))
        px = None
        if mode == "limit_close":
            px = signal
        elif mode == "limit_pct":
            px = signal * (1 - d * getattr(p, "limit_offset_pct", 0.2) / 100)
        elif mode == "limit_atr":
            from .indicators import atr
            b = self.closed(self._tf, 60)
            a = atr(b.h, b.l, b.c, 14)[-1] if len(b) > 15 else float("nan")
            px = signal - d * getattr(p, "limit_atr", 0.5) * a if a == a else None
        elif mode == "limit_level":
            px = level if level is not None else signal
        elif mode == "limit_mid":
            px = mid if mid is not None else (level if level is not None else signal)
        if px is not None and d * (signal - px) >= 0 and (sl is None or d * (px - sl) > 0):
            return px, "limit"
        return signal, "market"

    def enter(self, side, signal, sl, p, rr=None, tp=None, level=None, mid=None, tag=""):
        """Entry sesuai p.entry dengan SL tetap (struktural). TP = tp, atau rr x jarak SL dari harga entry."""
        d = 1 if side == "buy" else -1
        entry, kind = self.limit_price(side, signal, p, level, mid, sl)
        if tp is None:
            tp = entry + d * rr * abs(entry - sl)
        return self.trade(side, entry, sl, tp, getattr(p, "risk_usdt", 0.0), getattr(p, "risk_pct", 1.0), kind,
                          getattr(p, "expire_bars", 6) if kind == "limit" else None, tag)

    def size_by_risk(self, entry, sl, risk_pct):
        """Qty supaya kerugian saat SL kena = risk_pct% dari equity."""
        dist = abs(entry - sl)
        return 0.0 if dist <= 0 else self.equity * risk_pct / 100 / dist
