"""Runner auto backtest + metrik."""
import importlib.util
import inspect
import math
import os
import sys

import numpy as np

from .data import TF_MS
from .engine import AccountConfig, Engine
from .strategy import Context, Strategy


def load_strategies(folder):
    root = os.path.dirname(os.path.abspath(folder))
    if root not in sys.path:
        sys.path.insert(0, root)
    out = {}
    for path in sorted(os.listdir(folder)):
        if not path.endswith(".py") or path.startswith("_"):
            continue
        spec = importlib.util.spec_from_file_location(f"strategies.{path[:-3]}", os.path.join(folder, path))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        for name, obj in inspect.getmembers(mod, inspect.isclass):
            if issubclass(obj, Strategy) and obj is not Strategy and obj.__module__ == mod.__name__:
                out[name] = obj
    return out


def run_backtest(store, symbol, strategy_cls, params=None, start_ms=None, end_ms=None, cfg=None):
    cfg = cfg or AccountConfig()
    base = store.get(symbol, store.base_tf(symbol))
    start_ms = int(base.t[0]) if start_ms is None else start_ms
    eng = Engine(store, symbol, start_ms, end_ms, cfg)
    strat = strategy_cls(**(params or {}))
    ctx = Context(eng, strat.timeframe)
    ctx.p = strat.p
    tf_ms = TF_MS[strat.timeframe]
    strat.on_start(ctx)

    equity, peak, mdd = [], cfg.balance, 0.0
    while eng.step():
        for ev in eng.drain_events():
            if ev["type"] in ("fill", "liquidation"):
                strat.on_fill(ctx, ev)
        eq = eng.equity()
        peak = max(peak, eq)
        mdd = max(mdd, (peak - eq) / peak if peak > 0 else 0)
        if eng.now % 3_600_000 == 0:
            equity.append({"time": eng.now // 1000, "value": eq})
        if eng.now % tf_ms == 0:
            strat.on_bar(ctx)

    if abs(eng.pos) > 1e-12:  # tutup posisi sisa di harga terakhir supaya metrik lengkap
        eng._apply(-1 if eng.pos > 0 else 1, abs(eng.pos), eng.last_price, cfg.taker_fee, eng.now)
        eng.trades[-1]["exit_reason"] = "end_of_test"
    equity.append({"time": eng.now // 1000, "value": eng.equity()})

    return {"symbol": symbol, "strategy": strategy_cls.__name__, "params": vars(strat.p),
            "start": start_ms, "end": eng.now, "config": vars(cfg),
            "metrics": compute_metrics(eng.trades, equity, cfg.balance, eng.equity(), eng.fees_paid, mdd),
            "trades": eng.trades, "fills": eng.fills, "equity": equity, "missed": eng.missed,
            "setups": getattr(strat, "setups", None)}


def compute_metrics(trades, equity, initial, final, fees, mdd):
    pnl = np.array([t["pnl"] for t in trades]) if trades else np.zeros(0)
    wins, losses = pnl[pnl > 0], pnl[pnl <= 0]
    gross_win, gross_loss = wins.sum(), -losses.sum()
    daily = {}
    for p in equity:
        daily[p["time"] // 86400] = p["value"]
    d = np.array(list(daily.values()))
    rets = np.diff(d) / d[:-1] if len(d) > 2 else np.zeros(0)
    sharpe = float(rets.mean() / rets.std() * math.sqrt(365)) if len(rets) > 1 and rets.std() > 0 else 0.0
    return {
        "trades": len(trades),
        "net_pnl": final - initial,
        "return_pct": 100 * (final - initial) / initial,
        "win_rate": 100 * len(wins) / len(pnl) if len(pnl) else 0.0,
        "profit_factor": float(gross_win / gross_loss) if gross_loss > 0 else (float("inf") if gross_win > 0 else 0.0),
        "avg_win": float(wins.mean()) if len(wins) else 0.0,
        "avg_loss": float(losses.mean()) if len(losses) else 0.0,
        "expectancy": float(pnl.mean()) if len(pnl) else 0.0,
        "max_drawdown_pct": 100 * mdd,
        "sharpe_daily": sharpe,
        "fees": fees,
        "final_equity": final,
    }
