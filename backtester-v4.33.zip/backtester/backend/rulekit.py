"""🧱 Penyusun aturan -> strategi Python (tanpa AI, pasti / deterministik).

Spesifikasi (JSON) dari formulir:
{"name": "EMA RSI pullback", "tf": "15m", "dir": "both" | "long" | "short", "mirror": true,
 "long": [kondisi, ...], "short": [kondisi, ...],                # short dipakai kalau mirror = false
 "entry": "market" | "limit_atr" | "limit_pct" | "limit_close", "limit_atr": 0.5, "limit_pct": 0.2, "expire_bars": 6,
 "sl_mode": "atr" | "pct" | "swing", "sl_atr": 1.5, "sl_pct": 1.0, "sl_swing": 10, "sl_buf_atr": 0.1, "rr": 2.0}
kondisi = {"a": operand, "op": ">", "b": operand, "k": 3}
operand = {"ind": "ema", "p": {"n": 50}, "tf": "" (= TF strategi), "shift": 0}  atau  {"num": 30}
op: ">" "<" ">=" "<=" "cross_up" "cross_dn" (a memotong b ke atas / bawah) "rising" "falling" (a naik / turun k candle)

Kode yang dibuat memakai bar yang SUDAH close saja (ctx.closed), termasuk TF lain -> tanpa intip masa depan.
"""
import json
import keyword
import os
import re

import numpy as np

from . import indicators as I
from .data import TF_MS

# ---------------------------------------------------------------- katalog indikator
# key: (nama, [(param, label, default, min, max, langkah)], jenis cermin, penjelasan)
# jenis cermin (untuk SHORT = cermin LONG): price = tukar operator; osc100 = 100 - x; zero = -x; wr = -100 - x;
# unit1 = 1 - x; none = tidak dicerminkan (kekuatan / volatilitas / volume); swap:<key> = ganti indikator pasangannya.
N = ("n", "Periode", 14, 1, 1000, 1)
CAT = {
    "close": ("Harga close", [], "price", "Close candle"),
    "open": ("Harga open", [], "price", ""),
    "high": ("Harga high", [], "swap:low", ""),
    "low": ("Harga low", [], "swap:high", ""),
    "ema": ("EMA", [("n", "Periode", 50, 1, 3000, 1)], "price", "Exponential moving average"),
    "sma": ("SMA", [("n", "Periode", 50, 1, 3000, 1)], "price", "Simple moving average"),
    "wma": ("WMA", [("n", "Periode", 20, 1, 1000, 1)], "price", "Weighted moving average"),
    "vwma": ("VWMA", [("n", "Periode", 20, 1, 1000, 1)], "price", "Moving average berbobot volume"),
    "rsi": ("RSI", [N], "osc100", "0–100, > 70 jenuh beli, < 30 jenuh jual"),
    "stoch_k": ("Stochastic %K", [N, ("smooth", "Smoothing %K", 3, 1, 50, 1), ("d", "%D", 3, 1, 50, 1)], "osc100", "0–100"),
    "stoch_d": ("Stochastic %D", [N, ("smooth", "Smoothing %K", 3, 1, 50, 1), ("d", "%D", 3, 1, 50, 1)], "osc100", "0–100"),
    "macd": ("MACD line", [("fast", "Fast", 12, 1, 500, 1), ("slow", "Slow", 26, 2, 1000, 1), ("signal", "Signal", 9, 1, 200, 1)], "zero", ""),
    "macd_signal": ("MACD signal", [("fast", "Fast", 12, 1, 500, 1), ("slow", "Slow", 26, 2, 1000, 1), ("signal", "Signal", 9, 1, 200, 1)], "zero", ""),
    "macd_hist": ("MACD histogram", [("fast", "Fast", 12, 1, 500, 1), ("slow", "Slow", 26, 2, 1000, 1), ("signal", "Signal", 9, 1, 200, 1)], "zero", "> 0 = momentum naik"),
    "adx": ("ADX", [N], "none", "Kekuatan tren (bukan arah), > 25 = tren kuat"),
    "plus_di": ("+DI", [N], "swap:minus_di", "Tekanan naik"),
    "minus_di": ("−DI", [N], "swap:plus_di", "Tekanan turun"),
    "atr": ("ATR", [N], "none", "Rata-rata panjang candle (harga)"),
    "atr_pct": ("ATR %", [N], "none", "ATR dibagi harga × 100"),
    "bb_upper": ("Bollinger atas", [("n", "Periode", 20, 2, 1000, 1), ("k", "Deviasi", 2.0, 0.1, 10, 0.1)], "swap:bb_lower", ""),
    "bb_mid": ("Bollinger tengah", [("n", "Periode", 20, 2, 1000, 1), ("k", "Deviasi", 2.0, 0.1, 10, 0.1)], "price", ""),
    "bb_lower": ("Bollinger bawah", [("n", "Periode", 20, 2, 1000, 1), ("k", "Deviasi", 2.0, 0.1, 10, 0.1)], "swap:bb_upper", ""),
    "bb_pctb": ("Bollinger %B", [("n", "Periode", 20, 2, 1000, 1), ("k", "Deviasi", 2.0, 0.1, 10, 0.1)], "unit1", "0 = di pita bawah, 1 = di pita atas"),
    "bb_width": ("Bollinger lebar %", [("n", "Periode", 20, 2, 1000, 1), ("k", "Deviasi", 2.0, 0.1, 10, 0.1)], "none", "Lebar pita / tengah × 100"),
    "cci": ("CCI", [("n", "Periode", 20, 2, 1000, 1)], "zero", "> 100 kuat naik, < −100 kuat turun"),
    "willr": ("Williams %R", [N], "wr", "−100…0, > −20 jenuh beli, < −80 jenuh jual"),
    "roc": ("ROC %", [("n", "Periode", 10, 1, 1000, 1)], "zero", "Perubahan harga n candle (%)"),
    "mfi": ("MFI", [N], "osc100", "RSI berbobot volume, 0–100"),
    "force": ("Force Index", [("n", "Periode EMA", 13, 1, 500, 1)], "zero", "> 0 tekanan beli"),
    "supertrend": ("Supertrend arah", [("n", "Periode ATR", 10, 1, 500, 1), ("mult", "Pengali", 3.0, 0.1, 20, 0.1)], "zero", "+1 naik, −1 turun"),
    "donch_high": ("Donchian atas (high tertinggi n candle sebelumnya)", [("n", "Periode", 20, 1, 1000, 1)], "swap:donch_low", "Breakout = close > ini"),
    "donch_low": ("Donchian bawah (low terendah n candle sebelumnya)", [("n", "Periode", 20, 1, 1000, 1)], "swap:donch_high", ""),
    "volume": ("Volume", [], "none", ""),
    "vol_ma": ("Volume rata-rata", [("n", "Periode", 20, 1, 1000, 1)], "none", ""),
    "vol_ratio": ("Volume ÷ rata-rata", [("n", "Periode", 20, 1, 1000, 1)], "none", "2 = volume 2× rata-rata"),
    "body_pct": ("Badan candle % dari panjang", [], "none", "0–100"),
    "candle_dir": ("Warna candle", [], "zero", "+1 hijau, −1 merah"),
    "change_pct": ("Perubahan close %", [], "zero", "close vs close sebelumnya"),
}
OPS = {">": "lebih besar dari", "<": "lebih kecil dari", ">=": "≥", "<=": "≤", "cross_up": "memotong ke atas",
       "cross_dn": "memotong ke bawah", "rising": "naik selama k candle", "falling": "turun selama k candle"}
MIRROR_OP = {">": "<", "<": ">", ">=": "<=", "<=": ">=", "cross_up": "cross_dn", "cross_dn": "cross_up", "rising": "falling", "falling": "rising"}
TFS = ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"]
ENTRIES = ["market", "limit_atr", "limit_pct", "limit_close"]
SL_MODES = ["atr", "pct", "swing"]


# ---------------------------------------------------------------- perhitungan (dipakai kode yang dibuat)
def _wma(x, n):
    w = np.arange(1, n + 1, dtype=float)
    return I.rolling(x, n, lambda a, axis: (a * w).sum(axis=axis) / w.sum())


def ind(key, b, **p):
    """Deret indikator `key` dari bar `b` (o h l c v). Panjang sama dengan b.c."""
    o, h, l, c = (np.asarray(x, float) for x in (b.o, b.h, b.l, b.c))
    v = np.asarray(b.v, float)
    n = int(p.get("n", 14))
    if key in ("close", "open", "high", "low"):
        return {"close": c, "open": o, "high": h, "low": l}[key]
    if key == "ema":
        return I.ema(c, n)
    if key == "sma":
        return I.sma(c, n)
    if key == "wma":
        return _wma(c, n)
    if key == "vwma":
        with np.errstate(invalid="ignore", divide="ignore"):
            return I.rolling(c * v, n, np.sum) / I.rolling(v, n, np.sum)
    if key == "rsi":
        return I.rsi(c, n)
    if key in ("stoch_k", "stoch_d"):
        k, d = I.stoch(h, l, c, n, int(p.get("smooth", 3)), int(p.get("d", 3)))
        return k if key == "stoch_k" else d
    if key in ("macd", "macd_signal", "macd_hist"):
        line, sig, hist = I.macd(c, int(p.get("fast", 12)), int(p.get("slow", 26)), int(p.get("signal", 9)))
        return {"macd": line, "macd_signal": sig, "macd_hist": hist}[key]
    if key in ("adx", "plus_di", "minus_di"):
        pdi, ndi, a = I.dmi(h, l, c, n)
        return {"adx": a, "plus_di": pdi, "minus_di": ndi}[key]
    if key == "atr":
        return I.atr(h, l, c, n)
    if key == "atr_pct":
        return 100 * I.atr(h, l, c, n) / c
    if key.startswith("bb_"):
        lo, mid, up = I.bollinger(c, n, float(p.get("k", 2.0)))
        with np.errstate(invalid="ignore", divide="ignore"):
            return {"bb_upper": up, "bb_mid": mid, "bb_lower": lo, "bb_pctb": (c - lo) / (up - lo),
                    "bb_width": 100 * (up - lo) / mid}[key]
    if key == "cci":
        return I.cci(h, l, c, n)
    if key == "willr":
        return I.willr(h, l, c, n)
    if key == "roc":
        return I.roc(c, n)
    if key == "mfi":
        return I.mfi(h, l, c, v, n)
    if key == "force":
        return I.force_index(c, v, n)
    if key == "supertrend":
        return I.supertrend(h, l, c, n, float(p.get("mult", 3.0)))
    if key in ("donch_high", "donch_low"):
        r = I.rolling(h if key == "donch_high" else l, n, np.max if key == "donch_high" else np.min)
        return np.r_[np.nan, r[:-1]]                                # n candle SEBELUMNYA (tanpa candle sekarang)
    if key == "volume":
        return v
    if key == "vol_ma":
        return I.sma(v, n)
    if key == "vol_ratio":
        with np.errstate(invalid="ignore", divide="ignore"):
            return v / I.sma(v, n)
    if key == "body_pct":
        with np.errstate(invalid="ignore", divide="ignore"):
            return 100 * np.abs(c - o) / (h - l)
    if key == "candle_dir":
        return np.sign(c - o)
    if key == "change_pct":
        return np.r_[np.nan, 100 * (c[1:] / c[:-1] - 1)]
    raise ValueError(f"indikator tidak dikenal: {key}")


def at(x, shift=0):
    """Nilai `shift` candle lalu (0 = candle terakhir yang close)."""
    i = len(x) - 1 - int(shift)
    return float(x[i]) if i >= 0 else float("nan")


def ok(*vals):
    return all(v == v for v in vals)                               # semua bukan NaN


# ---------------------------------------------------------------- validasi & cermin
def _num(x, lo, hi, name):
    try:
        v = float(x)
    except (TypeError, ValueError):
        raise ValueError(f"{name} harus angka")
    if not (lo <= v <= hi):
        raise ValueError(f"{name} harus di antara {lo:g} dan {hi:g}")
    return v


def _operand(o, tf, where):
    if o is None:
        raise ValueError(f"{where}: operand kosong")
    if "num" in o:
        return {"num": _num(o["num"], -1e12, 1e12, f"{where}: angka")}
    key = o.get("ind")
    if key not in CAT:
        raise ValueError(f"{where}: indikator tidak dikenal ({key})")
    p = {}
    for name, label, dflt, lo, hi, step in CAT[key][1]:
        v = _num((o.get("p") or {}).get(name, dflt), lo, hi, f"{where}: {CAT[key][0]} {label}")
        p[name] = int(v) if float(step).is_integer() and float(dflt).is_integer() else v
    t = o.get("tf") or ""
    if t and t not in TFS:
        raise ValueError(f"{where}: TF tidak dikenal ({t})")
    if t and TF_MS[t] < TF_MS[tf]:
        raise ValueError(f"{where}: TF indikator ({t}) tidak boleh lebih kecil dari TF strategi ({tf})")
    return {"ind": key, "p": p, "tf": t, "shift": int(_num(o.get("shift", 0), 0, 500, f"{where}: candle lalu"))}


def _cond(cd, tf, where):
    op = cd.get("op")
    if op not in OPS:
        raise ValueError(f"{where}: operator tidak dikenal")
    a = _operand(cd.get("a"), tf, where)
    if "num" in a:
        raise ValueError(f"{where}: sisi kiri harus indikator")
    out = {"a": a, "op": op}
    if op in ("rising", "falling"):
        out["k"] = int(_num(cd.get("k", 3), 1, 200, f"{where}: k candle"))
    else:
        out["b"] = _operand(cd.get("b"), tf, where)
    return out


def _mirror_operand(o):
    if "num" in o:
        return o
    kind = CAT[o["ind"]][2]
    if kind.startswith("swap:"):
        return {**o, "ind": kind.split(":")[1]}
    return o


def _mirror_num(v, kind):
    return {"osc100": 100 - v, "zero": -v, "wr": -100 - v, "unit1": 1 - v}.get(kind, v)


def mirror(cd):
    """Kondisi LONG -> SHORT (cermin)."""
    a = cd["a"]
    ka = CAT[a["ind"]][2]
    if cd["op"] in ("rising", "falling"):
        if ka == "none":
            return dict(cd)
        return {"a": _mirror_operand(a), "op": MIRROR_OP[cd["op"]], "k": cd["k"]}
    b = cd["b"]
    if ka == "none" and ("num" in b or CAT[b["ind"]][2] == "none"):
        return dict(cd)                                            # kekuatan / volatilitas / volume: tetap
    nb = {"num": _mirror_num(b["num"], ka)} if "num" in b else _mirror_operand(b)
    return {"a": _mirror_operand(a), "op": MIRROR_OP[cd["op"]], "b": nb}


def validate(spec):
    s = spec or {}
    name = str(s.get("name") or "").strip()
    if not name or len(name) > 60:
        raise ValueError("isi nama strategi (maks 60 huruf)")
    tf = s.get("tf") or "15m"
    if tf not in TFS:
        raise ValueError("TF strategi tidak dikenal")
    dir_ = s.get("dir") or "both"
    if dir_ not in ("both", "long", "short"):
        raise ValueError("arah harus both / long / short")
    longs = [_cond(c, tf, f"LONG baris {i + 1}") for i, c in enumerate(s.get("long") or [])]
    mir = bool(s.get("mirror", True))
    shorts = [mirror(c) for c in longs] if mir else [_cond(c, tf, f"SHORT baris {i + 1}") for i, c in enumerate(s.get("short") or [])]
    if dir_ in ("both", "long") and not longs:
        raise ValueError("isi minimal 1 kondisi LONG")
    if dir_ in ("both", "short") and not shorts:
        raise ValueError("isi minimal 1 kondisi SHORT (atau centang cermin LONG)")
    if len(longs) > 12 or len(shorts) > 12:
        raise ValueError("maksimal 12 kondisi per arah")
    entry = s.get("entry") or "market"
    if entry not in ENTRIES:
        raise ValueError("jenis entry tidak dikenal")
    sl_mode = s.get("sl_mode") or "atr"
    if sl_mode not in SL_MODES:
        raise ValueError("jenis SL tidak dikenal")
    return {"name": name, "tf": tf, "dir": dir_, "mirror": mir, "long": longs, "short": shorts, "entry": entry,
            "limit_atr": _num(s.get("limit_atr", 0.5), 0.01, 20, "Limit (× ATR)"),
            "limit_pct": _num(s.get("limit_pct", 0.2), 0.01, 20, "Limit (%)"),
            "expire_bars": int(_num(s.get("expire_bars", 6), 1, 500, "Limit berlaku (candle)")),
            "sl_mode": sl_mode, "sl_atr": _num(s.get("sl_atr", 1.5), 0.1, 20, "SL (× ATR)"),
            "sl_pct": _num(s.get("sl_pct", 1.0), 0.05, 50, "SL (%)"),
            "sl_swing": int(_num(s.get("sl_swing", 10), 2, 500, "SL swing (candle)")),
            "sl_buf_atr": _num(s.get("sl_buf_atr", 0.1), 0, 5, "Buffer SL swing (× ATR)"),
            "rr": _num(s.get("rr", 2.0), 0.2, 20, "RR")}


# ---------------------------------------------------------------- pembuat kode
def slug(name):
    s = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")[:40] or "aturan"
    return "rb_" + s


def class_name(name):
    parts = re.findall(r"[A-Za-z0-9]+", name)
    c = "RB_" + "".join(p[:1].upper() + p[1:] for p in parts)[:50]
    return c if c.isidentifier() and not keyword.iskeyword(c) else "RB_Aturan"


def describe_operand(o, tf):
    if "num" in o:
        return f"{o['num']:g}"
    nm = CAT[o["ind"]][0]
    ps = ", ".join(f"{v:g}" for v in o["p"].values())
    s = f"{nm}({ps})" if ps else nm
    if o["tf"] and o["tf"] != tf:
        s += f" [{o['tf'].upper()}]"
    if o["shift"]:
        s += f" {o['shift']} candle lalu"
    return s


def describe(cd, tf):
    a = describe_operand(cd["a"], tf)
    if cd["op"] in ("rising", "falling"):
        return f"{a} {'naik' if cd['op'] == 'rising' else 'turun'} {cd['k']} candle berturut-turut"
    return f"{a} {OPS[cd['op']]} {describe_operand(cd['b'], tf)}"


def _var(o, tf):
    t = o["tf"] or tf
    ps = "_".join(f"{v:g}".replace(".", "p").replace("-", "m") for v in o["p"].values())
    return re.sub(r"[^a-z0-9_]", "_", f"{o['ind']}{('_' + ps) if ps else ''}_{t}").lower()


def _expr(cd, tf, vars_):
    a = cd["a"]
    va = _var(a, tf)
    vars_[va] = a
    sa = a["shift"]
    if cd["op"] in ("rising", "falling"):
        sign = ">" if cd["op"] == "rising" else "<"
        parts = [f"at({va}, {sa + i}) {sign} at({va}, {sa + i + 1})" for i in range(cd["k"])]
        return " and ".join(parts), [f"at({va}, {sa + i})" for i in range(cd["k"] + 1)]
    b = cd["b"]
    if "num" in b:
        vb_now, vb_prev = repr(float(b["num"])), repr(float(b["num"]))
        vals = [f"at({va}, {sa})"]
    else:
        vb = _var(b, tf)
        vars_[vb] = b
        vb_now, vb_prev = f"at({vb}, {b['shift']})", f"at({vb}, {b['shift'] + 1})"
        vals = [f"at({va}, {sa})", vb_now]
    if cd["op"] == "cross_up":
        vals += [f"at({va}, {sa + 1})"] + ([vb_prev] if "num" not in b else [])
        return f"at({va}, {sa + 1}) <= {vb_prev} and at({va}, {sa}) > {vb_now}", vals
    if cd["op"] == "cross_dn":
        vals += [f"at({va}, {sa + 1})"] + ([vb_prev] if "num" not in b else [])
        return f"at({va}, {sa + 1}) >= {vb_prev} and at({va}, {sa}) < {vb_now}", vals
    return f"at({va}, {sa}) {cd['op']} {vb_now}", vals


def _lookback(o):
    p = o.get("p", {})
    m = max([int(v) for k, v in p.items() if k in ("n", "slow", "fast")] + [1])
    if o["ind"].startswith("macd"):
        m = max(m, int(p.get("slow", 26)) + int(p.get("signal", 9)))
    return m


def generate(spec):
    """Spesifikasi (sudah divalidasi) -> (nama kelas, kode Python)."""
    s = spec
    tf = s["tf"]
    cls = class_name(s["name"])
    vars_ = {}
    blocks = []
    for side in ("long", "short"):
        if (s["dir"] == "long" and side == "short") or (s["dir"] == "short" and side == "long"):
            continue
        exprs, vals, docs = [], [], []
        for cd in s[side]:
            e, v = _expr(cd, tf, vars_)
            exprs.append(f"({e})")
            vals += v
            docs.append(describe(cd, tf))
        blocks.append((side, exprs, list(dict.fromkeys(vals)), docs))
    tfs = sorted({(o["tf"] or tf) for o in vars_.values()} | {tf}, key=lambda t: TF_MS[t])
    look = max([_lookback(o) + o["shift"] for o in vars_.values()] + [s["sl_swing"], 14])
    nbar = int(min(5000, max(300, look * 4 + 50)))
    L = []
    L.append('"""Dibuat otomatis oleh 🧱 Penyusun aturan — JANGAN diedit manual (edit lewat Penyusun aturan, lalu simpan ulang).')
    L.append("")
    L.append(f"Nama: {s['name']} · TF {tf} · arah: {s['dir']}{' (SHORT = cermin LONG)' if s['mirror'] else ''}")
    for side, _, _, docs in blocks:
        L.append(f"{side.upper()} kalau SEMUA benar (dicek di candle yang sudah close):")
        L += [f"  - {d}" for d in docs]
    sl_txt = {"atr": f"{s['sl_atr']:g} × ATR(14) dari entry", "pct": f"{s['sl_pct']:g}% dari entry",
              "swing": f"di balik low/high terendah/tertinggi {s['sl_swing']} candle + {s['sl_buf_atr']:g} ATR"}[s["sl_mode"]]
    ent_txt = {"market": "market di candle berikutnya", "limit_atr": f"limit {s['limit_atr']:g} × ATR lebih bagus dari close",
               "limit_pct": f"limit {s['limit_pct']:g}% lebih bagus dari close", "limit_close": "limit di close candle sinyal"}[s["entry"]]
    L.append(f"Entry: {ent_txt}. SL: {sl_txt}. TP: {s['rr']:g} × jarak SL. Satu posisi sekali jalan.")
    L.append('"""')
    L.append("from backend.indicators import atr")
    L.append("from backend.rulekit import at, ind, ok")
    L.append("from backend.strategy import Strategy")
    L.append("")
    L.append("")
    L.append(f"class {cls}(Strategy):")
    L.append(f'    """{s["name"]} (Penyusun aturan)."""')
    L.append("")
    L.append(f'    timeframe = "{tf}"')
    L.append("    params = {")
    L.append(f'        "tf": "{tf}", "entry": "{s["entry"]}", "limit_atr": {s["limit_atr"]!r}, "limit_offset_pct": {s["limit_pct"]!r},')
    L.append(f'        "expire_bars": {s["expire_bars"]}, "sl_mode": "{s["sl_mode"]}", "sl_atr": {s["sl_atr"]!r}, "sl_pct": {s["sl_pct"]!r},')
    L.append(f'        "sl_swing": {s["sl_swing"]}, "sl_buf_atr": {s["sl_buf_atr"]!r}, "rr": {s["rr"]!r},')
    L.append(f'        "long": {s["dir"] in ("both", "long")}, "short": {s["dir"] in ("both", "short")},')
    L.append('        "risk_usdt": 0.5, "risk_pct": 1.0,')
    L.append("    }")
    L.append("")
    L.append("    def on_bar(self, ctx):")
    L.append("        p = self.p")
    L.append("        if not ctx.position.flat or ctx.open_orders():")
    L.append("            return")
    for t in tfs:
        L.append(f'        b_{t} = ctx.closed("{t}", {nbar})              # hanya candle yang SUDAH close')
    L.append(f"        if len(b_{tf}) < {min(nbar, look + 5)}:")
    L.append("            return")
    for vname, o in vars_.items():
        args = "".join(f", {k}={v!r}" for k, v in o["p"].items())
        L.append(f'        {vname} = ind("{o["ind"]}", b_{o["tf"] or tf}{args})')
    L.append("")
    for side, exprs, vals, docs in blocks:
        L.append(f"        # {side.upper()}: " + " DAN ".join(docs))
        L.append(f"        {side}_ok = p.{side} and ok({', '.join(vals)}) and (")
        for j, e in enumerate(exprs):
            L.append(f"            {e}{' and' if j < len(exprs) - 1 else ''}")
        L.append("        )")
    L.append("        side = " + ('"buy" if long_ok else ' if any(b[0] == "long" for b in blocks) else "")
             + ('"sell" if short_ok else ' if any(b[0] == "short" for b in blocks) else "") + "None")
    L.append("        if side is None:")
    L.append("            return")
    L.append("        d = 1 if side == \"buy\" else -1")
    L.append(f"        c = float(b_{tf}.c[-1])")
    L.append(f"        a = float(atr(b_{tf}.h, b_{tf}.l, b_{tf}.c, 14)[-1])")
    L.append("        if not (a == a and a > 0):")
    L.append("            return")
    L.append("        entry, kind = ctx.limit_price(side, c, p)")
    L.append('        if p.sl_mode == "atr":')
    L.append("            sl = entry - d * p.sl_atr * a")
    L.append('        elif p.sl_mode == "pct":')
    L.append("            sl = entry * (1 - d * p.sl_pct / 100)")
    L.append("        else:                                               # swing")
    L.append(f"            lo, hi = float(b_{tf}.l[-p.sl_swing:].min()), float(b_{tf}.h[-p.sl_swing:].max())")
    L.append("            sl = (lo - p.sl_buf_atr * a) if d == 1 else (hi + p.sl_buf_atr * a)")
    L.append("        risk = d * (entry - sl)")
    L.append("        if risk <= 0:")
    L.append("            return")
    L.append("        ctx.trade(side, entry, sl, entry + d * p.rr * risk, p.risk_usdt, p.risk_pct, kind,")
    L.append('                  p.expire_bars if kind == "limit" else None, tag="aturan")')
    return cls, "\n".join(L) + "\n"


# ---------------------------------------------------------------- simpan / daftar
def save(folder, spec):
    s = validate(spec)
    cls, code = generate(s)
    compile(code, "<penyusun_aturan>", "exec")                        # pasti bisa dijalankan
    base = slug(s["name"])
    with open(os.path.join(folder, base + ".py"), "w", encoding="utf-8") as f:
        f.write(code)
    with open(os.path.join(folder, base + ".rules.json"), "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=1)
    return {"slug": base, "class": cls, "code": code, "spec": s}


def list_saved(folder):
    out = []
    for fn in sorted(os.listdir(folder)):
        if fn.startswith("rb_") and fn.endswith(".rules.json"):
            try:
                with open(os.path.join(folder, fn), encoding="utf-8") as f:
                    s = json.load(f)
                out.append({"slug": fn[:-11], "class": class_name(s["name"]), "spec": s,
                            "summary": {side: [describe(c, s["tf"]) for c in s.get(side, [])] for side in ("long", "short")}})
            except (OSError, ValueError, KeyError):
                continue
    return out


def delete(folder, slug_):
    if not re.fullmatch(r"rb_[a-z0-9_]{1,40}", slug_ or ""):
        raise ValueError("nama tidak valid")
    n = 0
    for ext in (".py", ".rules.json"):
        p = os.path.join(folder, slug_ + ext)
        if os.path.exists(p):
            os.remove(p)
            n += 1
    return n


def catalog():
    return {"indicators": {k: {"name": v[0], "params": [{"key": a, "label": b, "default": c, "min": d, "max": e, "step": f} for a, b, c, d, e, f in v[1]],
                               "mirror": v[2], "help": v[3]} for k, v in CAT.items()},
            "ops": OPS, "tfs": TFS, "entries": ENTRIES, "sl_modes": SL_MODES}
