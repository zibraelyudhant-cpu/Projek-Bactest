"""Pengaturan threshold modul Whale / Cari setup terbaik. Semua angka di sini bisa diubah dari tampilan
(tab Whale -> ⚙️ Threshold) dan disimpan di saved/whale_config.json. Nilai default = perilaku asli."""
import json
import os
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PATH = os.environ.get("WHALE_CFG_FILE", os.path.join(ROOT, "saved", "whale_config.json"))
_lock = threading.Lock()
_cache = {"mtime": None, "values": None}

# (kunci, label, default, min, max, step, penjelasan)   — pilihan teks: step = list pilihan
SECTIONS = [
    ("Tembok whale (order book)", [
        ("walls.depth", "Kedalaman order book saat scan (level)", 500, None, None, [100, 500, 1000], "Level order book yang dibaca per koin saat scan banyak koin. Lebih dalam = lebih berat (weight Binance)."),
        ("walls.top", "Jumlah tembok yang dipakai", 10, 3, 30, 1, "Tembok dengan dampak terbesar yang dipakai untuk entry & SL."),
        ("walls.max_dist_pct", "Jarak maks tembok untuk entry / SL (%)", 3.0, 0.5, 10, 0.5, "Tembok lebih jauh dari ini diabaikan."),
        ("walls.real_seen", "Tembok asli = terlihat minimal (scan)", 2, 1, 10, 1, "Tembok yang bertahan sekian scan berturut-turut dianggap asli (lebih dipercaya)."),
        ("walls.tol_pct", "Toleransi posisi tembok yang sama (%)", 0.05, 0.01, 0.5, 0.01, "Tembok di scan berikutnya dianggap sama kalau harganya bergeser maksimal sekian."),
        ("walls.keep_pct", "Tembok dianggap masih ada kalau nilainya ≥ (%)", 50, 10, 100, 5, "Dibanding nilai di scan sebelumnya."),
        ("walls.spoof_left_pct", "Tembok palsu kalau sisanya < (%)", 30, 5, 90, 5, "Tembok yang hilang / tinggal segini saat harga mendekat = curiga palsu."),
    ]),
    ("Swing & gocekan", [
        ("swing.fractal", "Swing: candle kiri & kanan", 3, 2, 10, 1, "Swing high/low = puncak/lembah tertinggi/terendah di antara sekian candle kiri & kanan (15M)."),
        ("swing.lookback", "Swing terdekat dicari di (candle 15M)", 200, 50, 900, 10, "Hanya swing dalam sekian candle terakhir."),
        ("swing.atr", "Periode ATR", 14, 5, 50, 1, "ATR 15M untuk semua jarak buffer."),
        ("gocek.lookahead", "Cari sapuan swing dalam (candle 15M)", 96, 12, 400, 4, "96 = 1 hari."),
        ("gocek.reclaim_bars", "Gocekan = close balik dalam ≤ (candle)", 4, 1, 20, 1, "Swing ditembus ekor candle lalu close kembali dalam sekian candle = gocekan; kalau tidak = tembus beneran."),
        ("gocek.depth_pct", "Kedalaman gocekan yang dihindari (persentil)", 90, 50, 99, 1, "90 = SL ditaruh lebih dalam dari 90% gocekan di koin itu."),
        ("round.max_dist_pct", "Angka bulat dihitung kalau jaraknya ≤ (%)", 2.0, 0.5, 5, 0.5, ""),
        ("thin.pct", "Zona tipis = antrean < (% median)", 25, 5, 60, 5, "Rentang yang order-nya sedikit; harga bisa loncat."),
    ]),
    ("SL anti-gocekan", [
        ("sl.swing_buf_atr", "Buffer di luar swing (+ ATR15m)", 0.1, 0, 2, 0.05, "SL = swing ± (kedalaman gocekan + buffer) × ATR15m."),
        ("sl.wall_buf_atr1h", "Buffer di balik tembok (× ATR H1)", 0.25, 0, 2, 0.05, ""),
        ("sl.fallback_atr1h", "SL cadangan kalau tak ada swing/tembok (× ATR H1)", 1.5, 0.5, 5, 0.1, ""),
        ("sl.round_buf", "Buffer melewati angka bulat (+ ATR15m)", 0.1, 0, 2, 0.05, ""),
        ("sl.max_pct", "Jarak SL maksimal (%)", 4.0, 0.5, 20, 0.5, "Kalau SL anti-gocekan lebih jauh dari ini lihat aturan di bawah."),
        ("sl.cap_mode", "Kalau SL lebih jauh dari batas", "tolak", None, None, ["potong", "tolak"],
         "potong = SL dipindah ke batas (bisa masuk zona gocekan). tolak = setup tidak dipakai di Cari setup."),
    ]),
    ("Kandidat entry", [
        ("entry.wall_buf_atr", "Entry di depan tembok (+ ATR15m)", 0.1, 0, 2, 0.05, ""),
        ("entry.swing_buf_atr", "Entry di depan swing (+ ATR15m)", 0.15, 0, 2, 0.05, ""),
        ("entry.use_market", "Coba entry harga sekarang (market)", "ya", None, None, ["ya", "tidak"], ""),
        ("entry.use_wall", "Coba entry di depan tembok whale", "ya", None, None, ["ya", "tidak"], ""),
        ("entry.use_swing", "Coba entry di depan swing", "ya", None, None, ["ya", "tidak"], ""),
    ]),
    ("Backtest WR", [
        ("bt.sl_tf_switch_pct", "Pakai data 1H kalau SL ≥ (%)", 1.5, 0.3, 10, 0.1, "SL lebih kecil pakai candle 15M."),
        ("bt.candles", "Jumlah candle backtest", 1500, 300, 1500, 100, "Maks 1500 per permintaan Binance (15M ≈ 15 hari, 1H ≈ 62 hari)."),
        ("bt.max_bars_15m", "Batas waktu per trade, data 15M (candle)", 192, 16, 1000, 8, "192 = 2 hari. Belum kena TP sampai batas = tidak menang."),
        ("bt.max_bars_1h", "Batas waktu per trade, data 1H (candle)", 120, 12, 500, 6, "120 = 5 hari."),
        ("bt.trend_filter", "Hanya kondisi tren seperti sekarang (EMA20 vs EMA50)", "ya", None, None, ["ya", "tidak"], ""),
        ("bt.min_trades", "Sampel minimal (trade)", 30, 5, 300, 5, "Kalau filter tren menyisakan lebih sedikit, pakai semua candle."),
        ("bt.suspicious_wr", "Tanda ⚠️ curiga kalau WR > (%)", 85, 50, 100, 1, ""),
        ("fill.window", "Peluang entry tersentuh dalam (candle 15M)", 96, 4, 400, 4, "96 = 24 jam."),
        ("fill.market_tol_pct", "Entry sejauh ≤ ini dianggap market (%)", 0.02, 0, 0.5, 0.01, ""),
    ]),
    ("Syarat setup layak (v4.33)", [
        ("setup.require_test", "Layak juga harus untung di data cari (70% awal) & data uji (30% terakhir)", "ya", None, None, ["ya", "tidak"],
         "tidak = cukup rata-rata untung di semua data (perilaku lama, rawan kebetulan)."),
        ("setup.min_test", "Trade minimal di data uji", 10, 3, 100, 1, "Kurang dari ini = belum bisa dinilai = tidak layak."),
        ("setup.min_moves", "Pergerakan berbeda minimal", 15, 1, 100, 1,
         "Trade yang TIDAK tumpang tindih (1 posisi sekali jalan). Backtest entry tiap candle menghitung pergerakan yang sama berkali-kali."),
        ("setup.reject_too_good", "WR di atas batas ⚠️ curiga = tidak layak", "ya", None, None, ["ya", "tidak"], "Batas = 'Tanda ⚠️ curiga kalau WR >'."),
        ("bt.limit_fill", "Backtest entry limit hanya dari candle yang menyentuh harga limit", "ya", None, None, ["ya", "tidak"],
         "ya = trade limit dimulai saat harga benar-benar turun / naik ke entry (dalam batas peluang tersentuh). tidak = entry di close tiap candle (lama)."),
    ]),
    ("Kekuatan pasar (regime)", [
        ("regime.w_trend", "Bobot tren EMA H1", 0.45, 0, 1, 0.05, "Bobot dinormalkan otomatis jadi total 1."),
        ("regime.w_trades", "Bobot transaksi whale", 0.30, 0, 1, 0.05, ""),
        ("regime.w_book", "Bobot order book ±2%", 0.25, 0, 1, 0.05, ""),
        ("regime.adx_full", "ADX tren penuh", 40, 10, 80, 1, "ADX segini = porsi sideways minimum."),
        ("regime.side_min", "Porsi sideways minimum (%)", 10, 0, 50, 1, ""),
        ("regime.side_max", "Porsi sideways maksimum (%)", 85, 50, 100, 1, ""),
    ]),
    ("Alarm lonjakan (1 menit)", [
        ("alarm.warn_vol", "WASPADA: volume 5 menit ≥ (× normal)", 3.0, 1, 20, 0.5, ""),
        ("alarm.warn_move_atr", "WASPADA: gerak ≥ (× ATR 1m)", 2.0, 0.5, 10, 0.5, ""),
        ("alarm.danger_peak", "BAHAYA: puncak volume ≥ (× normal)", 5.0, 1, 30, 0.5, ""),
        ("alarm.danger_move_atr", "BAHAYA: gerak ≥ (× ATR 1m)", 3.0, 0.5, 15, 0.5, ""),
    ]),
    ("Cek entry & saran", [
        ("check.adj_factor", "Pengaruh cek whale ke peluang (× poin)", 0.6, 0, 2, 0.1, ""),
        ("check.adj_cap", "Penyesuaian whale maksimal (± poin)", 12, 0, 30, 1, "Peluang backtest hanya digeser maksimal sekian poin oleh data whale."),
        ("check.min_better_r", "Saran harus lebih baik minimal (R)", 0.02, 0, 1, 0.01, "Selain peluang TP ≥ punyamu."),
    ]),
]

DEFAULTS = {k: d for _, fields in SECTIONS for k, _, d, *_ in fields}
_META = {k: (mn, mx, st) for _, fields in SECTIONS for k, _, _, mn, mx, st, _ in fields}


def clean(values):
    """Validasi & batasi ke rentang yang aman. Kunci tak dikenal dibuang."""
    out = dict(DEFAULTS)
    for k, v in (values or {}).items():
        if k not in DEFAULTS:
            continue
        mn, mx, st = _META[k]
        if isinstance(st, list):
            hit = next((ch for ch in st if str(ch) == str(v)), None)
            if hit is not None:
                out[k] = hit
            continue
        try:
            x = float(v)
        except (TypeError, ValueError):
            continue
        if x != x:
            continue
        x = min(max(x, mn), mx)
        out[k] = int(round(x)) if isinstance(DEFAULTS[k], int) else x
    return out


def get():
    """Nilai aktif (dibaca ulang hanya kalau file berubah)."""
    try:
        mt = os.path.getmtime(PATH)
    except OSError:
        return dict(DEFAULTS)
    with _lock:
        if _cache["mtime"] != mt:
            try:
                with open(PATH, encoding="utf-8") as f:
                    _cache["values"] = clean(json.load(f))
            except (OSError, ValueError):
                _cache["values"] = dict(DEFAULTS)
            _cache["mtime"] = mt
        return dict(_cache["values"])


def save(values):
    v = clean(values)
    changed = {k: x for k, x in v.items() if x != DEFAULTS[k]}
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    with _lock:
        tmp = PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(changed, f, indent=1)
        os.replace(tmp, PATH)
        _cache["mtime"] = None
    return get()


def reset():
    with _lock:
        try:
            os.remove(PATH)
        except OSError:
            pass
        _cache["mtime"] = None
    return dict(DEFAULTS)


def schema():
    return [{"title": t, "fields": [{"key": k, "label": lb, "default": d, "min": mn, "max": mx,
                                     "step": None if isinstance(st, list) else st, "choices": st if isinstance(st, list) else None,
                                     "help": hp} for k, lb, d, mn, mx, st, hp in fields]} for t, fields in SECTIONS]
