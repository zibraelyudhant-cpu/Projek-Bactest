"""Seberapa berat dijalani: kalah beruntun terpanjang & drawdown terdalam (dalam R), dari hasil trade URUT WAKTU."""


def risk_seq(rs):
    """rs = hasil tiap trade (R) urut waktu. Kalah = R < 0 (termasuk waktu habis yang rugi).
    Hasil: max_loss_streak (kali), max_dd (R, angka positif = turun dari puncak), n."""
    streak = best = 0
    eq = peak = dd = 0.0
    n = 0
    for r in rs:
        if r is None:
            continue
        n += 1
        r = float(r)
        streak = streak + 1 if r < 0 else 0
        best = max(best, streak)
        eq += r
        peak = max(peak, eq)
        dd = max(dd, peak - eq)
    return {"max_loss_streak": int(best), "max_dd": float(dd), "n_seq": n}
