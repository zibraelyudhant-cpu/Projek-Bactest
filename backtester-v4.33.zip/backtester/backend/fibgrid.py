"""'Cari angka fibo terbaik' untuk strategi yang mencatat setup fibo (mis. BreakoutFibo).

Strategi dijalankan biasa, tapi setiap setup (A = titik awal swing, B = ujung swing, waktu fibo digambar, ATR, harga
konfluensi) dicatat. Lalu SETIAP setup disimulasikan untuk semua kombinasi angka fibo entry x TP dengan SL yang sama
(sl_atr x ATR). Setup-nya sama persis untuk semua kombinasi, jadi perbandingannya adil. Hasil dibagi per bulan:
70% awal untuk memilih, 30% terakhir untuk menguji.
"""
import os
import time
import uuid

import numpy as np

from .pausable import PausableJobs

ENTRY_G = [0.236, 0.382, 0.5, 0.618, 0.705, 0.786, "conf"]
TP_G = [("rr", 2.0), ("fib", 0.0), ("fib", -0.13), ("fib", -0.272), ("fib", -0.414), ("fib", -0.618)]
TP_NAME = ["RR 1:2", "0", "-0.13", "-0.272", "-0.414", "-0.618"]
SIDES = ("all", "bull", "bear")
SIDE_LABEL = {"bull": "Bullish · koreksi turun → BUY", "bear": "Bearish · koreksi naik → SELL"}


def _first(mask):
    if not len(mask):
        return None
    i = int(np.argmax(mask))
    return i if mask[i] else None


def simulate(bars, setups, p):
    """Hitungan per bulan: {bulan: {n, fill[E], cnt[E,T], win[E,T], sumr[E,T]}}."""
    h, l, c, t = bars.h, bars.l, bars.c, bars.t
    n = len(c)
    exp, mb, k_sl = int(p.get("expire_bars", 48)), int(p.get("grid_bars", 600)), float(p.get("sl_atr", 2.0))
    E, T = len(ENTRY_G), len(TP_G)
    out = {}
    for s in setups or []:
        d, A, B, a = s["d"], s["A"], s["B"], s["atr"]
        rng = abs(B - A)
        k0 = int(np.searchsorted(t, s["t"]))                # candle pertama setelah fibo digambar
        if rng <= 0 or a <= 0 or k0 >= n - 1 or k0 < 1:
            continue
        mo = int(np.datetime64(int(s["t"]), "ms").astype("datetime64[M]").astype(np.int64))
        mm = out.setdefault(mo, {sd_: {"n": 0, "fill": np.zeros(E, np.int64), "cnt": np.zeros((E, T), np.int64),
                                       "win": np.zeros((E, T), np.int64), "sumr": np.zeros((E, T))} for sd_ in SIDES})
        ms = (mm["all"], mm["bull" if d > 0 else "bear"])
        for m in ms:
            m["n"] += 1
        lv = lambda x: B - d * x * rng                     # noqa: E731
        for ei, ex in enumerate(ENTRY_G):
            pe = s.get("conf") if ex == "conf" else lv(ex)
            if pe is None or d * (c[k0 - 1] - pe) <= 0:
                continue                                   # harga sudah lewat: bukan limit retest
            fl = l[k0:k0 + exp] if d > 0 else h[k0:k0 + exp]
            f = _first(fl <= pe) if d > 0 else _first(fl >= pe)
            if f is None:
                continue
            f += k0
            for m in ms:
                m["fill"][ei] += 1
            sd = k_sl * a
            sl = pe - d * sd
            e2 = min(n, f + 1 + mb)
            adv = l[f:e2] if d > 0 else h[f:e2]
            isl = _first(adv <= sl) if d > 0 else _first(adv >= sl)
            fav = h[f + 1:e2] if d > 0 else l[f + 1:e2]
            for ti, (kind, val) in enumerate(TP_G):
                tp = pe + d * val * sd if kind == "rr" else lv(val)
                if d * (tp - pe) <= 0:
                    continue                               # TP di sisi yang salah untuk entry ini
                it = _first(fav >= tp) if d > 0 else _first(fav <= tp)
                if it is not None and (isl is None or it + 1 < isl):
                    r, w = d * (tp - pe) / sd, 1
                elif isl is not None:
                    r, w = -1.0, 0
                else:                                      # belum selesai: nilai pasar di akhir jendela
                    r, w = max(-1.0, min(d * (c[e2 - 1] - pe) / sd, d * (tp - pe) / sd)), 0
                for m in ms:
                    m["cnt"][ei, ti] += 1
                    m["win"][ei, ti] += w
                    m["sumr"][ei, ti] += r
    return out


def merge(a, b):
    for mo, v in (b or {}).items():
        if mo not in a:
            a[mo] = v
        else:
            for sd_, vv in v.items():
                for k in vv:
                    a[mo][sd_][k] = a[mo][sd_][k] + vv[k]
    return a


def _sum(agg, months):
    s = {"n": 0, "fill": 0, "cnt": 0, "win": 0, "sumr": 0}
    for mo in months:
        for k in s:
            s[k] = s[k] + agg[mo][k]
    return s


def _table(s):
    n = int(s["n"])
    rows = []
    for ei, ex in enumerate(ENTRY_G):
        for ti, tn in enumerate(TP_NAME):
            cnt = int(np.asarray(s["cnt"])[ei, ti]) if n else 0
            if not cnt:
                continue
            rows.append({"entry": ex, "tp": tn, "fill_pct": 100 * float(np.asarray(s["fill"])[ei]) / n, "trades": cnt,
                         "win_rate": 100 * float(np.asarray(s["win"])[ei, ti]) / cnt,
                         "r_trade": float(np.asarray(s["sumr"])[ei, ti]) / cnt, "r_setup": float(np.asarray(s["sumr"])[ei, ti]) / n})
    return rows


def summarize(agg, p):
    """Ringkasan gabungan + per sisi (Bullish BUY / Bearish SELL) + kesimpulan per sisi."""
    out = _summarize_one({mo: v["all"] for mo, v in agg.items()}, p)
    out["sides"] = {}
    for sd_ in ("bull", "bear"):
        one = _summarize_one({mo: v[sd_] for mo, v in agg.items()}, p)
        one["label"] = SIDE_LABEL[sd_]
        one["conclusion"] = _conclude(one)
        out["sides"][sd_] = one
    return out


def _conclude(one):
    """Entry presisi terbaik (dibandingkan adil di kolom RR 1:2 = jarak TP sama untuk semua entry) dan TP fibo yang
    paling sering tercapai dari entry itu."""
    rows = one.get("rows") or []
    rr = [r for r in rows if r["tp"] == "RR 1:2" and r["fill_pct"] >= 20 and r["trades"] >= 30 and r.get("fit_win_rate") is not None]
    if not rr:
        return None
    ok = [r for r in rr if r["valid"]] or rr               # utamakan yang konsisten di data uji
    best = max(ok, key=lambda r: r["win_rate"])
    fib = [r for r in rows if str(r["entry"]) == str(best["entry"]) and r["tp"] != "RR 1:2"]
    order = ["0", "-0.13", "-0.272", "-0.414", "-0.618"]
    fib.sort(key=lambda r: order.index(r["tp"]))
    most = next((r for r in reversed(fib) if r["win_rate"] >= 50), None) or (max(fib, key=lambda r: r["win_rate"]) if fib else None)
    often = next((r for r in reversed(fib) if r["win_rate"] >= 35 and most is not None and order.index(r["tp"]) > order.index(most["tp"])), None)
    top = max(fib, key=lambda r: r["win_rate"]) if fib else None
    return {"entry": best["entry"], "fill_pct": best["fill_pct"], "wr_rr": best["win_rate"], "test_wr_rr": best.get("test_win_rate"),
            "valid": best["valid"], "tp_most": most, "tp_often": often, "tp_top": top,
            "tps": [{"tp": r["tp"], "win_rate": r["win_rate"]} for r in fib]}


def _summarize_one(agg, p):
    months = sorted(agg)
    if not months:
        return {"n": 0, "rows": []}
    cnt = np.array([agg[m]["n"] for m in months], float)
    k = int(np.searchsorted(np.cumsum(cnt) / max(1, cnt.sum()), 0.7)) + 1
    k = min(max(1, k), len(months) - 1) if len(months) > 1 else 1
    fit, test = _sum(agg, months[:k]), _sum(agg, months[k:])
    allr, fitr, testr = _table(_sum(agg, months)), _table(fit), _table(test)
    key = lambda r: (r["entry"], r["tp"])                  # noqa: E731
    tmap, fmap = {key(r): r for r in testr}, {key(r): r for r in fitr}
    for r in allr:
        f, tt = fmap.get(key(r)), tmap.get(key(r))
        r["fit_r_setup"] = f["r_setup"] if f else None
        r["test_r_setup"] = tt["r_setup"] if tt else None
        r["test_win_rate"] = tt["win_rate"] if tt and tt["trades"] >= 10 else None
        r["valid"] = bool(f and tt and tt["trades"] >= 10 and f["r_setup"] > 0 and tt["r_setup"] > 0)
    # teknikal saja: per target TP, entry dengan WR terbaik di data latih; lolos uji = WR di data uji tidak turun > 5 poin
    tmw = {key(r): r for r in testr}
    fw = {key(r): r for r in fitr}
    for r in allr:
        f, tt = fw.get(key(r)), tmw.get(key(r))
        r["fit_win_rate"] = f["win_rate"] if f and f["trades"] >= 20 else None
        r["valid"] = bool(f and tt and f["trades"] >= 20 and tt["trades"] >= 10 and tt["win_rate"] >= f["win_rate"] - 5)
    per_tp = []
    for tn in TP_NAME:
        cs = [r for r in allr if r["tp"] == tn and r["fit_win_rate"] is not None and r["fill_pct"] >= 20]
        if cs:
            per_tp.append(max(cs, key=lambda r: r["fit_win_rate"]))
    best = None
    best_wr = None
    split = int(np.datetime64(int(months[k]), "M").astype("datetime64[ms]").astype(np.int64)) if k < len(months) else None
    return {"n": int(cnt.sum()), "rows": allr, "best": best, "best_wr": best_wr, "per_tp": per_tp, "split": split, "params": p,
            "entries": [str(e) for e in ENTRY_G], "tps": TP_NAME}


# ------------------------------------------------------------------ job paralel
_WG = {}


def _init(data_dir, strategy_dir):
    from .backtest import load_strategies
    from .data import DataStore
    _WG["store"] = DataStore(data_dir, cache_size=4)
    _WG["strategies"] = load_strategies(strategy_dir)


def _one(sym, strategy, params, start, end, cfg):
    from .backtest import run_backtest
    from .engine import AccountConfig
    try:
        t0 = time.time()
        cls = _WG["strategies"][strategy]
        r = run_backtest(_WG["store"], sym, cls, params, start, end, AccountConfig.from_dict(cfg))
        bars = _WG["store"].get(sym, r["params"].get("tf") or cls.timeframe)
        agg = simulate(bars, r.get("setups"), r["params"])
        return {"symbol": sym, "setups": len(r.get("setups") or []), "agg": agg, "seconds": round(time.time() - t0, 1)}
    except Exception as ex:
        return {"symbol": sym, "error": f"{type(ex).__name__}: {ex}"}


class GridJobs(PausableJobs):
    """'Cari angka fibo terbaik' di banyak koin, paralel, bisa dijeda & dilanjutkan (lihat pausable.py)."""
    KIND = "grid"

    def __init__(self, data_dir, strategy_dir, paused_dir=None):
        self.data_dir, self.strategy_dir = data_dir, strategy_dir
        super().__init__(paused_dir)

    def start(self, symbols, strategy, params, start=None, end=None, cfg=None, workers=None):
        from .sysinfo import recommended_workers
        workers = max(1, min(int(workers or recommended_workers()), 32))
        job = self._new(uuid.uuid4().hex[:10], len(symbols), workers, symbols=list(symbols), setups=0, errors=[], agg={},
                        result=None, params=params, strategy=strategy, targs=(strategy, params, start, end, cfg or {}))
        self._launch(job)
        return job["id"]

    def pool_init(self):
        return _init, (self.data_dir, self.strategy_dir)

    def task_call(self, job, i):
        return _one, (job["symbols"][i], *job["targs"])

    def on_error(self, job, i, ex):
        return {"symbol": job["symbols"][i], "error": str(ex)}

    def on_result(self, job, i, row):
        if row.get("agg") is not None:
            merge(job["agg"], row["agg"])
            job["setups"] += row["setups"]
        if row.get("error"):
            job["errors"].append(f"{row['symbol']}: {row['error']}")

    def finish(self, job):
        job["result"] = summarize(job["agg"], job["params"])

    def get(self, jid):
        job = self.jobs.get(jid)
        if not job:
            return None
        return {"id": jid, "status": job["status"], "done": job["done"], "total": job["total"], "setups": job["setups"],
                "workers": job["workers"], "elapsed": round(self.elapsed(job), 1), "errors": job["errors"][:20],
                "inflight": job.get("inflight", 0), "error": job.get("error"),
                "result": job["result"] if job["status"] in ("done", "cancelled", "error") else None}
