import json
import math
import os
import socket
import threading
import time
import uuid
import traceback

import numpy as np
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from .backtest import load_strategies, run_backtest
from .multi import Jobs
from .data import TF_MS, DataStore
from .engine import AccountConfig
from .evaluate import advise, diagnose, tfs_of
from .mining import mine
from .fibstudy import DEFAULTS as FIB_DEFAULTS, FibJobs
from .fibgrid import GridJobs
from .fibstudy2 import DEFAULTS as FIB2_DEFAULTS, FibJobs as FibJobs2
from .replay import ReplaySession
from .strategy import COMMON_HELP, FILTER_HELP, FILTERS
from .screener import FIELDS, INTERVAL_MS, BinanceError, Screener
from .whales import Whales
from . import antigocek as AG

VERSION = "4.33"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.environ.get("DATA_DIR", r"D:\Data Candle Binance\all")
STRATEGY_DIR = os.path.join(ROOT, "strategies")

store = DataStore(DATA_DIR)
app = FastAPI(title="Binance Futures Replay")
app.mount("/static", StaticFiles(directory=os.path.join(ROOT, "frontend")), name="static")


def _clean(x):
    """numpy scalar -> python, inf/nan -> null supaya JSON valid."""
    if isinstance(x, np.generic):
        x = x.item()
    if isinstance(x, float) and not math.isfinite(x):
        return None
    if isinstance(x, dict):
        return {k: _clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_clean(v) for v in x]
    return x


ACCESS_PIN = os.environ.get("ACCESS_PIN", "").strip()
LOCAL = ("127.0.0.1", "::1", "localhost")

PIN_PAGE = """<!doctype html><html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Futures Replay</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0f1218;color:#d5dae3;
font:15px system-ui,sans-serif}form{background:#161a22;border:1px solid #262c38;border-radius:10px;padding:24px;
width:min(320px,90vw)}input,button{width:100%;box-sizing:border-box;font:inherit;padding:10px;border-radius:6px;
margin-top:10px}input{background:#1c212b;color:#d5dae3;border:1px solid #262c38}button{background:#3b82f6;color:#fff;
border:0}p{color:#ef5350;margin:8px 0 0}</style></head><body><form method="get" action="/">
<b>Futures Replay</b><input name="pin" type="password" inputmode="numeric" placeholder="PIN" autofocus>
<button>Masuk</button>{MSG}</form></body></html>"""


def _pin_ok(host, cookies, query):
    return not ACCESS_PIN or host in LOCAL or cookies.get("pin") == ACCESS_PIN or query.get("pin") == ACCESS_PIN


@app.middleware("http")
async def pin_guard(request, call_next):
    """Kalau ACCESS_PIN diisi, perangkat lain (HP, dsb.) harus memasukkan PIN. PC sendiri bebas."""
    host = request.client.host if request.client else ""
    if not _pin_ok(host, request.cookies, request.query_params):
        if request.url.path == "/":
            wrong = "<p>PIN salah</p>" if "pin" in request.query_params else ""
            return HTMLResponse(PIN_PAGE.replace("{MSG}", wrong), status_code=401)
        return JSONResponse({"detail": "Butuh PIN"}, status_code=401)
    resp = await call_next(request)
    if ACCESS_PIN and request.query_params.get("pin") == ACCESS_PIN:
        resp = RedirectResponse("/")
        resp.set_cookie("pin", ACCESS_PIN, max_age=30 * 86400, httponly=True, samesite="lax")
    return resp


def lan_addresses():
    """Alamat IP PC ini yang bisa dibuka dari HP (Wi-Fi/LAN dan Tailscale 100.x)."""
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))   # tidak mengirim data; hanya untuk tahu IP jaringan utama
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith(("127.", "169.254.")))


@app.get("/api/lan")
def lan(request: Request):
    port = request.url.port or 8000
    return {"lan_mode": os.environ.get("LAN_MODE") == "1", "pin": bool(ACCESS_PIN),
            "urls": [{"url": f"http://{ip}:{port}", "kind": "Tailscale" if ip.startswith("100.") else "Wi-Fi / LAN"}
                     for ip in lan_addresses()]}


@app.middleware("http")
async def no_cache(request, call_next):
    resp = await call_next(request)
    if request.url.path.startswith("/static"):
        resp.headers["Cache-Control"] = "no-cache"  # browser selalu cek file terbaru
    return resp


@app.get("/")
def index():
    with open(os.path.join(ROOT, "frontend", "index.html"), encoding="utf-8") as f:
        html = f.read().replace("__VERSION__", VERSION)
    return HTMLResponse(html, headers={"Cache-Control": "no-store"})


@app.get("/api/version")
def version():
    return {"version": VERSION, "root": ROOT, "data_dir": DATA_DIR}


@app.get("/api/symbols")
def symbols():
    return {"data_dir": DATA_DIR, "symbols": store.symbols()}


@app.get("/api/symbols/{symbol}")
def symbol_info(symbol: str):
    if symbol.upper() not in store.catalog:
        raise HTTPException(404, "simbol tidak ditemukan")
    return store.info(symbol.upper())


@app.get("/api/strategies")
def strategies():
    tf = lambda c: c.params.get("tf") or c.params.get("confirm_tf") or c.params.get("htf") or c.timeframe  # noqa: E731
    def atr_map(c):
        """Parameter yang memakai ATR -> parameter TF tempat ATR dihitung (dipakai formulir untuk label 'ATR14 · 1H')."""
        entry_tf = ["tf"] if "tf" in c.params else ["confirm_tf", "htf"] if "htf" in c.params else []
        out = {k: entry_tf for k in c.params if "atr" in k and entry_tf}
        out.update(c.atr_tf)
        return out
    return [{"name": n, "timeframe": tf(c), "params": {**c.params, **FILTERS}, "doc": (c.__doc__ or "").strip(),
             "atr_tf": atr_map(c), "default_tf": c.timeframe, "fib_grid": bool(getattr(c, "fib_grid", False)),
             "help": {**{k: c.param_help.get(k) or COMMON_HELP.get(k, "") for k in c.params}, **FILTER_HELP},
             "choices": {k: v for k, v in c.param_choices.items() if k in c.params}}
            for n, c in load_strategies(STRATEGY_DIR).items()]


@app.post("/api/backtest")
def backtest(req: dict):
    strats = load_strategies(STRATEGY_DIR)  # dimuat ulang tiap run, jadi edit strategi tanpa restart
    if req.get("strategy") not in strats:
        raise HTTPException(400, "strategi tidak ditemukan")
    sym = req["symbol"].upper()
    if sym not in store.catalog:
        raise HTTPException(400, "simbol tidak ditemukan")
    cls = strats[req["strategy"]]
    try:
        res = run_backtest(store, sym, cls, req.get("params") or {},
                           req.get("start"), req.get("end"), AccountConfig.from_dict(req.get("config")))
    except Exception as ex:
        traceback.print_exc()
        raise HTTPException(400, f"{type(ex).__name__}: {ex}")
    try:   # evaluasi gagal tidak boleh menggagalkan hasil backtest
        raw, labels = diagnose(store, sym, res, cls.timeframe)
        exec_tf, htf, _ = tfs_of(res["params"], cls.timeframe)
        raw["mine"] = mine(store, sym, res, exec_tf, htf)
        for tr, lb in zip(res["trades"], labels):
            tr["diag"] = lb
        res["evaluation"] = advise(raw, res["params"])
    except Exception:
        traceback.print_exc()
        res["evaluation"] = None
    return JSONResponse(_clean(res))


screener = Screener()
# proses yang dijeda disimpan di sini supaya tetap bisa dilanjutkan setelah aplikasi ditutup
PAUSED_DIR = os.path.join(os.path.dirname(os.environ.get("SAVED_FILE", os.path.join(ROOT, "saved", "thresholds.json"))), "paused")
jobs = Jobs(DATA_DIR, STRATEGY_DIR, PAUSED_DIR)


@app.post("/api/backtest_all")
def backtest_all(req: dict):
    """Jalankan strategi di semua koin (atau daftar `symbols`) secara paralel. Hasil diambil lewat GET."""
    _guard()
    strats = load_strategies(STRATEGY_DIR)
    if req.get("strategy") not in strats:
        raise HTTPException(400, "strategi tidak ditemukan")
    params = {**FILTERS, **strats[req["strategy"]].params, **(req.get("params") or {})}
    syms = [x.upper() for x in (req.get("symbols") or []) if x.upper() in store.catalog] or store.symbols()
    variants = req.get("variants")
    if variants:   # baris pertama = parameter sekarang sebagai pembanding (kecuali baseline: false)
        variants = [v for v in variants if v.get("params")][:20]
        if req.get("baseline", True):
            variants = [{"label": "Sekarang", "params": {}}] + variants[:8]
    jid = jobs.start(syms, req["strategy"], params, req.get("start"), req.get("end"),
                     req.get("config") or {}, req.get("workers"), float(req.get("min_days", 0)), variants)
    jobs.jobs[jid]["req"] = {k: req.get(k) for k in ("strategy", "params", "symbols", "start", "end", "config")}
    return {"id": jid, "total": len(syms)}


@app.get("/api/backtest_all/{jid}")
def backtest_all_status(jid: str, since: int = 0):
    res = jobs.get(jid, since)
    if res is None:
        raise HTTPException(404, "job tidak ditemukan")
    return JSONResponse(_clean(res))


@app.post("/api/backtest_all/{jid}/cancel")
def backtest_all_cancel(jid: str):
    jobs.cancel(jid)
    return {"ok": True}


SAVED_FILE = os.environ.get("SAVED_FILE", os.path.join(ROOT, "saved", "thresholds.json"))
_saved_lock = threading.Lock()


def _read_saved():
    try:
        with open(SAVED_FILE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _write_saved(items):
    os.makedirs(os.path.dirname(SAVED_FILE), exist_ok=True)
    tmp = SAVED_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=1)
    os.replace(tmp, SAVED_FILE)   # tulis atomik: file lama tidak rusak kalau PC mati di tengah jalan


@app.get("/api/thresholds")
def thresholds():
    """Threshold (parameter strategi) yang disimpan beserta hasil backtest-nya. File: saved/thresholds.json."""
    return _read_saved()


@app.post("/api/thresholds")
def threshold_save(req: dict):
    if not req.get("strategy") or not isinstance(req.get("params"), dict):
        raise HTTPException(400, "butuh strategy dan params")
    item = {"id": uuid.uuid4().hex[:8], "created": int(time.time() * 1000),
            **{k: req.get(k) for k in ("name", "strategy", "params", "symbols", "start", "end", "metrics", "note", "config")}}
    item["name"] = (item["name"] or item["strategy"]).strip()[:80]
    detail = req.get("detail")
    if isinstance(detail, dict):   # hasil lengkap (tabel per koin, trade, evaluasi) disimpan di file terpisah
        os.makedirs(_detail_dir(), exist_ok=True)
        path = os.path.join(_detail_dir(), item["id"] + ".json")
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(_clean(detail), f, ensure_ascii=False)
        os.replace(path + ".tmp", path)
        item["has_detail"] = True
    with _saved_lock:
        items = _read_saved()
        items.append(_clean(item))
        _write_saved(items)
    return item


def _detail_dir():
    return os.path.join(os.path.dirname(SAVED_FILE), "results")


@app.get("/api/thresholds/{tid}/detail")
def threshold_detail(tid: str):
    if not tid.isalnum():
        raise HTTPException(400, "id tidak valid")
    try:
        with open(os.path.join(_detail_dir(), tid + ".json"), encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        raise HTTPException(404, "hasil lengkap tidak ada (disimpan sebelum v3.18)")


@app.patch("/api/thresholds/{tid}")
def threshold_update(tid: str, req: dict):
    with _saved_lock:
        items = _read_saved()
        for it in items:
            if it["id"] == tid:
                it.update({k: req[k] for k in ("name", "note") if k in req})
                _write_saved(items)
                return it
    raise HTTPException(404, "tidak ditemukan")


@app.delete("/api/thresholds/{tid}")
def threshold_delete(tid: str):
    with _saved_lock:
        items = _read_saved()
        _write_saved([it for it in items if it["id"] != tid])
    if tid.isalnum():
        try:
            os.remove(os.path.join(_detail_dir(), tid + ".json"))
        except OSError:
            pass
    return {"ok": True}


fibjobs = FibJobs(DATA_DIR, PAUSED_DIR)
fibjobs2 = FibJobs2(DATA_DIR, PAUSED_DIR)   # Studi Fibonacci v2 (set angka fibo lain, default M5 / H1)
gridjobs = GridJobs(DATA_DIR, STRATEGY_DIR, PAUSED_DIR)
from . import indtester as _IT, msstudy as _MSA, snrtest as _SNR, stratlab as _SLAB   # noqa: E402
from .studyjobs import StudyJobs   # noqa: E402
# menu studi: paralel di semua inti CPU, bisa dijeda & dilanjutkan, hasil otomatis disimpan
snrjobs = StudyJobs("snrtest", _SNR, DATA_DIR, PAUSED_DIR)
slabjobs = StudyJobs("stratlab", _SLAB, DATA_DIR, PAUSED_DIR, partial_every=2.0)
itjobs = StudyJobs("indtester", _IT, DATA_DIR, PAUSED_DIR)
msajobs = StudyJobs("msa", _MSA, DATA_DIR, PAUSED_DIR, partial_every=3.0)
STUDY = {"snrtest": (snrjobs, "📍 Tes SNR"), "stratlab": (slabjobs, "🧠 Penemu Strategi"), "indtester": (itjobs, "🧪 Indikator Tester"),
         "msa": (msajobs, "📐 Analisa Market Structure")}


@app.post("/api/fibgrid")
def fibgrid_start(req: dict):
    """'Cari angka fibo terbaik': semua kombinasi angka fibo entry x TP untuk setup strategi (mis. BreakoutFibo)."""
    _guard()
    strats = load_strategies(STRATEGY_DIR)
    name = req.get("strategy") or "BreakoutFibo"
    if name not in strats:
        raise HTTPException(400, "strategi tidak ditemukan")
    params = {**FILTERS, **strats[name].params, **(req.get("params") or {})}
    syms = [x.upper() for x in (req.get("symbols") or []) if x.upper() in store.catalog] or store.symbols()
    jid = gridjobs.start(syms, name, params, req.get("start"), req.get("end"), req.get("config"), req.get("workers"))
    return {"id": jid, "total": len(syms)}


@app.get("/api/fibgrid/{jid}")
def fibgrid_status(jid: str):
    res = gridjobs.get(jid)
    if res is None:
        raise HTTPException(404, "job tidak ditemukan")
    return JSONResponse(_clean(res))


@app.post("/api/fibgrid/{jid}/cancel")
def fibgrid_cancel(jid: str):
    gridjobs.cancel(jid)
    return {"ok": True}


def _fib_dir():
    return os.path.join(os.path.dirname(SAVED_FILE), "fibstudy")


def _fib_path(fid):
    if not fid.isalnum():
        raise HTTPException(400, "id tidak valid")
    return os.path.join(_fib_dir(), fid + ".json")


@app.get("/api/fibsaved")
def fibsaved_list():
    """Hasil Studi Fibonacci yang disimpan (tanpa isi lengkap). File: saved/fibstudy/<id>.json"""
    out = []
    d = _fib_dir()
    for fn in sorted(os.listdir(d)) if os.path.isdir(d) else []:
        try:
            with open(os.path.join(d, fn), encoding="utf-8") as f:
                it = json.load(f)
            out.append({k: it.get(k) for k in ("id", "name", "created", "params", "symbols", "start", "end", "n", "coins")})
        except (OSError, ValueError):
            continue
    return sorted(out, key=lambda x: -(x["created"] or 0))


@app.get("/api/fibsaved/{fid}")
def fibsaved_get(fid: str):
    try:
        with open(_fib_path(fid), encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        raise HTTPException(404, "tidak ditemukan")


@app.post("/api/fibsaved")
def fibsaved_save(req: dict):
    res = req.get("result")
    if not isinstance(res, dict) or not res.get("groups"):
        raise HTTPException(400, "butuh hasil studi")
    item = {"id": uuid.uuid4().hex[:8], "created": int(time.time() * 1000), "name": (req.get("name") or "Studi Fibonacci").strip()[:80],
            "params": res.get("params"), "symbols": req.get("symbols"), "start": req.get("start"), "end": req.get("end"),
            "coins": req.get("coins"), "n": res.get("n"), "result": res}
    os.makedirs(_fib_dir(), exist_ok=True)
    path = _fib_path(item["id"])
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(_clean(item), f, ensure_ascii=False)
    os.replace(path + ".tmp", path)
    return {k: v for k, v in item.items() if k != "result"}


@app.patch("/api/fibsaved/{fid}")
def fibsaved_rename(fid: str, req: dict):
    item = fibsaved_get(fid)
    item["name"] = (req.get("name") or item["name"]).strip()[:80]
    with open(_fib_path(fid), "w", encoding="utf-8") as f:
        json.dump(item, f, ensure_ascii=False)
    return {"ok": True}


@app.delete("/api/fibsaved/{fid}")
def fibsaved_delete(fid: str):
    try:
        os.remove(_fib_path(fid))
    except OSError:
        pass
    return {"ok": True}


@app.get("/api/fibstudy/defaults")
def fibstudy_defaults():
    return FIB_DEFAULTS


@app.post("/api/fibstudy")
def fibstudy_start(req: dict):
    """Studi Fibonacci di koin terpilih / semua koin (paralel). Hasil diambil lewat GET."""
    _guard()
    p = {**FIB_DEFAULTS, **{k: v for k, v in (req.get("params") or {}).items() if k in FIB_DEFAULTS}}
    for k in ("tf", "regime_tf", "trend_tf"):
        if p[k] not in TF_MS:
            raise HTTPException(400, f"timeframe tidak dikenal: {p[k]}")
    syms = [x.upper() for x in (req.get("symbols") or []) if x.upper() in store.catalog] or store.symbols()
    return {"id": fibjobs.start(syms, p, req.get("start"), req.get("end"), req.get("workers")), "total": len(syms)}


@app.get("/api/fibstudy/{jid}")
def fibstudy_status(jid: str):
    res = fibjobs.get(jid)
    if res is None:
        raise HTTPException(404, "job tidak ditemukan")
    return JSONResponse(_clean(res))


@app.post("/api/fibstudy/{jid}/cancel")
def fibstudy_cancel(jid: str):
    fibjobs.cancel(jid)
    return {"ok": True}


# ------------------------------------------------------------------ Studi Fibonacci v2 (endpoint sama, awalan beda)
def _fib2_dir():
    return os.path.join(os.path.dirname(SAVED_FILE), "fibstudy2")


def _fib2_path(fid):
    if not fid.isalnum():
        raise HTTPException(400, "id tidak valid")
    return os.path.join(_fib2_dir(), fid + ".json")


@app.get("/api/fibsaved2")
def fibsaved2_list():
    out = []
    d = _fib2_dir()
    for fn in sorted(os.listdir(d)) if os.path.isdir(d) else []:
        try:
            with open(os.path.join(d, fn), encoding="utf-8") as f:
                it = json.load(f)
            out.append({k: it.get(k) for k in ("id", "name", "created", "params", "symbols", "start", "end", "n", "coins")})
        except (OSError, ValueError):
            continue
    return sorted(out, key=lambda x: -(x["created"] or 0))


@app.get("/api/fibsaved2/{fid}")
def fibsaved2_get(fid: str):
    try:
        with open(_fib2_path(fid), encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        raise HTTPException(404, "tidak ditemukan")


@app.post("/api/fibsaved2")
def fibsaved2_save(req: dict):
    res = req.get("result")
    if not isinstance(res, dict) or not res.get("groups"):
        raise HTTPException(400, "butuh hasil studi")
    item = {"id": uuid.uuid4().hex[:8], "created": int(time.time() * 1000), "name": (req.get("name") or "Studi Fibonacci v2").strip()[:80],
            "params": res.get("params"), "symbols": req.get("symbols"), "start": req.get("start"), "end": req.get("end"),
            "coins": req.get("coins"), "n": res.get("n"), "result": res}
    os.makedirs(_fib2_dir(), exist_ok=True)
    path = _fib2_path(item["id"])
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(_clean(item), f, ensure_ascii=False)
    os.replace(path + ".tmp", path)
    return {k: v for k, v in item.items() if k != "result"}


@app.patch("/api/fibsaved2/{fid}")
def fibsaved2_rename(fid: str, req: dict):
    item = fibsaved2_get(fid)
    item["name"] = (req.get("name") or item["name"]).strip()[:80]
    with open(_fib2_path(fid), "w", encoding="utf-8") as f:
        json.dump(item, f, ensure_ascii=False)
    return {"ok": True}


@app.delete("/api/fibsaved2/{fid}")
def fibsaved2_delete(fid: str):
    try:
        os.remove(_fib2_path(fid))
    except OSError:
        pass
    return {"ok": True}


@app.get("/api/fibstudy2/defaults")
def fibstudy2_defaults():
    return FIB2_DEFAULTS


@app.post("/api/fibstudy2")
def fibstudy2_start(req: dict):
    _guard()
    p = {**FIB2_DEFAULTS, **{k: v for k, v in (req.get("params") or {}).items() if k in FIB2_DEFAULTS}}
    try:
        p["ema_fast"], p["ema_slow"] = int(p["ema_fast"]), int(p["ema_slow"])
    except (TypeError, ValueError):
        raise HTTPException(400, "EMA harus angka")
    if not 1 <= p["ema_fast"] < p["ema_slow"] <= 1000:
        raise HTTPException(400, "EMA cepat harus lebih kecil dari EMA lambat (1 .. 1000)")
    for k in ("tf", "regime_tf", "trend_tf"):
        if p[k] not in TF_MS:
            raise HTTPException(400, f"timeframe tidak dikenal: {p[k]}")
    syms = [x.upper() for x in (req.get("symbols") or []) if x.upper() in store.catalog] or store.symbols()
    return {"id": fibjobs2.start(syms, p, req.get("start"), req.get("end"), req.get("workers")), "total": len(syms)}


@app.get("/api/fibstudy2/{jid}")
def fibstudy2_status(jid: str):
    res = fibjobs2.get(jid)
    if res is None:
        raise HTTPException(404, "job tidak ditemukan")
    return JSONResponse(_clean(res))


@app.post("/api/fibstudy2/{jid}/cancel")
def fibstudy2_cancel(jid: str):
    fibjobs2.cancel(jid)
    return {"ok": True}


@app.get("/api/cpu")
def cpu():
    from .sysinfo import info
    return info()


def _busy():
    """Proses berat (semua koin / uji saran / studi fibonacci) yang sedang berjalan, atau None.
    Hanya satu boleh jalan sekaligus supaya RAM tidak habis."""
    j = gridjobs.running()
    if j:
        return {"kind": "grid", "id": j["id"], "done": j["done"], "total": j["total"],
                "label": f"Cari angka fibo terbaik ({j['strategy']})"}
    j = fibjobs.running()
    if j:
        return {"kind": "fib", "id": j["id"], "done": j["done"], "total": j["total"], "label": "Studi Fibonacci", "params": j["params"]}
    j = fibjobs2.running()
    if j:
        return {"kind": "fib2", "id": j["id"], "done": j["done"], "total": j["total"], "label": "Studi Fibonacci v2", "params": j["params"]}
    for kind, (m, label) in STUDY.items():
        j = m.running()
        if j:
            return {"kind": kind, "id": j["id"], "done": j["done"], "total": j["total"], "label": label}
    j = jobs.running()
    if j:
        return {"kind": "variants" if j["variants"] else "backtest", "id": j["id"], "done": j["done"], "total": j["total"],
                "label": ("Uji saran / bandingkan" if j["variants"] else "Backtest semua koin") + f" ({j['strategy']})",
                "strategy": j["strategy"], "req": j.get("req")}
    return None


def _guard():
    b = _busy()
    if b:
        raise HTTPException(409, {"msg": f"Masih ada proses berjalan: {b['label']} {b['done']}/{b['total']}. "
                                         "Tunggu selesai atau batalkan dulu.", "busy": b})


# ------------------------------------------------------------------ jeda / lanjutkan proses berat
def _kinds():
    return {"backtest": jobs, "variants": jobs, "fib": fibjobs, "fib2": fibjobs2, "grid": gridjobs,
            **{k: m for k, (m, _) in STUDY.items()}}


def _job_label(kind, j):
    if kind == "backtest":
        return ("Uji saran / bandingkan" if j.get("variants") else "Backtest semua koin") + f" ({j.get('strategy')})"
    if kind == "grid":
        return f"Cari angka fibo terbaik ({j.get('strategy')})"
    if kind in STUDY:
        return STUDY[kind][1]
    return {"fib": "Studi Fibonacci", "fib2": "Studi Fibonacci v2"}.get(kind, kind)


def _jobs_of(kind):
    m = _kinds().get(kind)
    if m is None:
        raise HTTPException(404, "jenis proses tidak dikenal")
    return m


@app.post("/api/job/{kind}/{jid}/pause")
def job_pause(kind: str, jid: str):
    """Jeda: koin yang sedang dihitung diselesaikan dulu, lalu berhenti. Hasil yang sudah ada tetap disimpan."""
    return {"ok": _jobs_of(kind).pause(jid)}


@app.post("/api/job/{kind}/{jid}/resume")
def job_resume(kind: str, jid: str):
    """Lanjutkan dari koin yang belum selesai (tidak mengulang dari awal)."""
    m = _jobs_of(kind)
    j = m.jobs.get(jid)
    if not j:
        raise HTTPException(404, "proses tidak ditemukan")
    if not j.get("thread_alive"):
        _guard()                       # proses lain sedang berjalan: tunggu / batalkan dulu
    return {"ok": m.resume(jid)}


@app.post("/api/job/{kind}/{jid}/cancel")
def job_cancel(kind: str, jid: str):
    _jobs_of(kind).cancel(jid)
    return {"ok": True}


@app.get("/api/paused")
def paused_list():
    out = []
    for kind, m in (("backtest", jobs), ("fib", fibjobs), ("fib2", fibjobs2), ("grid", gridjobs),
                    *((k, m_) for k, (m_, _) in STUDY.items())):
        for j in m.paused():
            out.append({"kind": "variants" if kind == "backtest" and j.get("variants") else kind, "id": j["id"],
                        "label": _job_label(kind, j), "done": j["done"], "total": j["total"],
                        "draining": bool(j.get("thread_alive")), "inflight": j.get("inflight", 0),
                        "paused_at": int(1000 * j.get("paused_at", 0)), "strategy": j.get("strategy"), "req": j.get("req"),
                        "params": j.get("params") if kind in ("fib", "fib2") else None})
    return sorted(out, key=lambda x: -x["paused_at"])


@app.get("/api/running")
def running():
    return {"busy": _busy()}


@app.post("/api/running/cancel")
def running_cancel():
    b = _busy()
    if b:
        _kinds().get(b["kind"], jobs).cancel(b["id"])
    return {"ok": True}


@app.get("/api/screener/fields")
def screener_fields():
    return {"fields": [{"key": k, "label": lbl, "group": g, "len": n} for k, lbl, g, n in FIELDS],
            "intervals": list(INTERVAL_MS)}


@app.post("/api/screener")
def screener_scan(req: dict):
    try:
        res = screener.scan(req.get("tf", "1h"), req.get("filters") or [], req.get("columns") or [],
                            bool(req.get("closed_only")), req.get("structure"), req.get("limit"))
    except BinanceError as ex:
        raise HTTPException(502, str(ex))
    except (ValueError, KeyError, TypeError) as ex:
        raise HTTPException(400, f"Filter tidak valid: {ex}")
    return JSONResponse(_clean(res))


# ---- scan di latar belakang + progres (supaya tampilan menunggu tidak polos)
_scan_jobs = {}


_SCAN = __import__("threading").local()


def _bg_scan(work):
    """Jalankan work(progress) di latar belakang; status & progres lewat GET /api/screener/job/{id}."""
    import threading as _th
    jid = uuid.uuid4().hex[:10]
    job = {"id": jid, "status": "running", "done": 0, "total": 0, "recent": [], "started": time.time(), "result": None,
           "error": None, "times": [], "partial": None}
    for old in [k for k, v in _scan_jobs.items() if v["status"] != "running"][:-3]:
        del _scan_jobs[old]
    _scan_jobs[jid] = job

    def prog(k, n, sym, err):
        job["done"], job["total"] = k, n
        job["times"].append(time.time())
        job["recent"] = ([{"symbol": sym, "error": bool(err)}] + job["recent"])[:8]
    prog.partial = lambda data: job.__setitem__("partial", data)   # hasil sementara (opsional, mis. scan setup)

    def run():
        _SCAN.start = int(job["started"] * 1000)                   # 📒 jurnal: waktu MULAI scan (tombol ditekan) ikut dicatat
        try:
            job["result"] = _clean(work(prog))
            job["status"] = "done"
        except BinanceError as ex:
            job["status"], job["error"] = "error", str(ex)
        except (ValueError, KeyError, TypeError) as ex:
            job["status"], job["error"] = "error", f"Input tidak valid: {ex}"
        except Exception as ex:   # noqa: BLE001
            job["status"], job["error"] = "error", f"{type(ex).__name__}: {ex}"
    _th.Thread(target=run, daemon=True).start()
    return {"id": jid}


whales = Whales(screener.c)


def _live_ev(sym):
    """Data live tambahan untuk bukti (kelas A/B/C): candle BTC TF sama (dicache 5 menit) & candle harian koin."""
    def get(tf):
        out = {"btc": None, "d1": None}
        try:
            from .whales import _btc_series
            out["btc"] = _btc_series(whales.c, tf)
            kd = whales.c.get("/fapi/v1/klines", symbol=sym, interval="1d", limit=120)
            out["d1"] = (np.array([int(r[0]) for r in kd], np.int64), np.array([float(r[4]) for r in kd]))
        except Exception:                                          # noqa: BLE001 - tanpa internet: bukti pakai data lokal
            pass
        return out
    return get


def _obrec_autostart():
    """Perekam order book menyala lagi otomatis kalau terakhir dinyalakan (rekaman tidak bolong setelah restart)."""
    try:
        from . import obrec as OB
        if OB.get_cfg()["on"]:
            OB.start(whales.c)
    except Exception:                                              # noqa: BLE001 - perekam tidak boleh menghentikan app
        pass


_obrec_autostart()


def _journal_autostart():
    """📒 pemantau jurnal sinyal jalan di latar belakang (tiap 5 menit, hanya kalau ada sinyal terbuka)."""
    if os.environ.get("JOURNAL_NO_THREAD"):
        return
    try:
        from . import journal as J
        J.start(whales.c)
    except Exception:                                              # noqa: BLE001
        pass


_journal_autostart()


@app.get("/api/orderbook/rec")
def orderbook_rec_status():
    """📼 Status perekam order book (rekaman tembok tiap beberapa menit)."""
    from . import obrec as OB
    return _clean(OB.status())


@app.post("/api/orderbook/rec")
def orderbook_rec_set(req: dict):
    """Nyalakan / matikan perekam & atur koin (jumlah volume terbesar atau daftar), interval, min USDT tembok."""
    from . import obrec as OB
    try:
        cfg = OB.set_cfg(req)
    except (TypeError, ValueError) as ex:
        raise HTTPException(400, f"pengaturan perekam tidak valid: {ex}")
    if cfg["on"]:
        OB.start(whales.c)
    else:
        OB.stop()
    return _clean(OB.status())


@app.get("/api/rules/catalog")
def rules_catalog():
    """🧱 Penyusun aturan: daftar indikator (setting & batas), operator, TF, jenis entry & SL."""
    from . import rulekit as RK
    return RK.catalog()


@app.get("/api/rules")
def rules_list():
    from . import rulekit as RK
    return {"saved": RK.list_saved(STRATEGY_DIR)}


@app.post("/api/rules/preview")
def rules_preview(req: dict):
    """Aturan -> Python (belum disimpan) + kalimat aturan (termasuk SHORT hasil cermin)."""
    from . import rulekit as RK
    try:
        s = RK.validate(req.get("spec") or {})
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    cls, code = RK.generate(s)
    return {"class": cls, "code": code, "spec": s,
            "describe": {side: [RK.describe(c, s["tf"]) for c in s[side]] for side in ("long", "short")}}


@app.post("/api/rules/save")
def rules_save(req: dict):
    """Simpan aturan jadi strategi Python di folder strategies/ (langsung muncul di daftar Auto Backtest)."""
    from . import rulekit as RK
    try:
        r = RK.save(STRATEGY_DIR, req.get("spec") or {})
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    return r


@app.post("/api/rules/delete")
def rules_delete(req: dict):
    from . import rulekit as RK
    try:
        return {"deleted": RK.delete(STRATEGY_DIR, str(req.get("slug") or ""))}
    except ValueError as ex:
        raise HTTPException(400, str(ex))


@app.post("/api/orderbook/test")
def orderbook_test(req: dict):
    """Uji tembok dari rekaman: % mantul tembok bertahan / spoof vs level pembanding tanpa tembok."""
    from . import obrec as OB
    syms = [str(x).upper() for x in (req.get("symbols") or []) if str(x).strip()] or None
    return _bg_scan(lambda prog: OB.wall_test(whales.c, syms, req.get("min_usdt")))


@app.post("/api/whales/flow")
def whales_flow(req: dict):
    """🧭 Flow whale: Open Interest, taker buy/sell, long/short top trader & funding (riwayat ±30 hari Binance)
    -> arah 2 ATR duluan vs normal, dinilai di 70% awal & 30% terakhir. coins = koin pembanding (0 = koin ini saja)."""
    from . import flowstudy as FS
    sym = str(req.get("symbol") or "").upper().strip()
    if sym and not sym.endswith("USDT"):
        sym += "USDT"
    if not sym:
        raise HTTPException(400, "isi koin dulu")
    tf = str(req.get("tf") or "1h")
    if tf not in FS.PERIODS:
        raise HTTPException(400, "TF flow harus 15m, 1h atau 4h")
    try:
        n = max(0, min(int(req.get("coins") or 0), 50))
    except (TypeError, ValueError):
        raise HTTPException(400, "jumlah koin pembanding harus angka")

    def work(prog):
        others = []
        if n:
            tick = whales.c.get("/fapi/v1/ticker/24hr")
            info = whales.c.get("/fapi/v1/exchangeInfo")
            perp = {s_["symbol"] for s_ in info["symbols"] if s_.get("contractType") == "PERPETUAL"
                    and s_.get("quoteAsset") == "USDT" and s_.get("status") == "TRADING"}
            vol = sorted(((t["symbol"], float(t["quoteVolume"])) for t in tick if t["symbol"] in perp), key=lambda x: -x[1])
            others = [s_ for s_, _ in vol if s_ != sym][:n]
        return FS.study(whales.c, sym, tf, others, progress=prog)
    return _bg_scan(work)


@app.post("/api/whales/start")
def whales_start(req: dict):
    """Lacak whale: tembok order besar & transaksi besar di N koin volume terbesar; tampilkan `top` teratas."""
    n = max(1, min(int(req.get("coins") or 20), 300))
    top = max(1, min(int(req.get("top") or 10), 100))
    min_usdt = max(1000.0, float(req.get("min_usdt") or 100_000))
    min_impact = max(0.0, float(req.get("min_impact") or 0.0))
    return _bg_scan(lambda prog: whales.scan(n, top, min_usdt, min_impact, progress=prog))


@app.post("/api/whales/coin")
def whales_coin(req: dict):
    """Analisa whale detail untuk 1 koin."""
    from .whales import analyse_coin
    sym = str(req.get("symbol") or "").upper().strip()
    if not sym:
        raise HTTPException(400, "isi simbol koin")
    if not sym.endswith("USDT"):
        sym += "USDT"
    top = max(1, min(int(req.get("top") or 10), 100))
    min_usdt = max(1000.0, float(req.get("min_usdt") or 50_000))
    min_impact = max(0.0, float(req.get("min_impact") or 0.0))
    return _bg_scan(lambda prog: analyse_coin(whales.c, sym, top, min_usdt, min_impact, prog))


@app.get("/api/study/{kind}/{jid}")
def study_status(kind: str, jid: str):
    """Progres & hasil menu studi (Tes SNR / Penemu Strategi / Indikator Tester)."""
    if kind not in STUDY:
        raise HTTPException(404, "menu tidak dikenal")
    st = STUDY[kind][0].status(jid)
    if st is None:
        raise HTTPException(404, "proses tidak ditemukan")
    return JSONResponse(_clean(st))


@app.get("/api/results/{kind}")
def results_list(kind: str):
    """Hasil tersimpan sebuah menu (terbaru dulu)."""
    from . import results_store as RS
    try:
        return RS.listing(kind)
    except ValueError as ex:
        raise HTTPException(404, str(ex))


@app.get("/api/results/{kind}/{rid}")
def results_get(kind: str, rid: str):
    from . import results_store as RS
    try:
        return JSONResponse(_clean(RS.get(kind, rid)))
    except (OSError, ValueError):
        raise HTTPException(404, "hasil tidak ditemukan")


@app.patch("/api/results/{kind}/{rid}")
def results_rename(kind: str, rid: str, req: dict):
    from . import results_store as RS
    try:
        RS.rename(kind, rid, req.get("label") or "")
    except (OSError, ValueError):
        raise HTTPException(404, "hasil tidak ditemukan")
    return {"ok": True}


@app.delete("/api/results/{kind}/{rid}")
def results_delete(kind: str, rid: str):
    from . import results_store as RS
    try:
        RS.delete(kind, rid)
    except ValueError as ex:
        raise HTTPException(404, str(ex))
    return {"ok": True}


@app.get("/api/dorongan/defaults")
def dorongan_defaults():
    """Penghalusan Dorongan % terbaik per TF (hasil Tes SNR yang lolos uji). Dipakai indikator chart & Tes SNR."""
    from . import snrtest as T
    return T.load_defaults()


@app.get("/api/snrtest/defaults")
def snrtest_defaults():
    from . import snrtest as T
    return {"defaults": T.DEFAULTS, "bands": [b for b, _ in T.BANDS], "smooths": T.SMOOTHS, "min_auc": T.MIN_AUC}


@app.post("/api/snrtest")
def snrtest_start(req: dict):
    """📍 Tes SNR + Dorongan %: dibaca SEBELUM harga sampai SNR, lalu dinilai: breakout atau respect."""
    from . import snrtest as T
    try:
        q = T._params(req.get("params") or {})
    except (TypeError, ValueError) as ex:
        raise HTTPException(400, str(ex))
    syms = [x.upper() for x in (req.get("symbols") or []) if x.upper() in store.catalog] or store.symbols()
    syms = [x for x in syms if q["tf"] in store.timeframes(x) and q["snr_tf"] in store.timeframes(x)]
    if not syms:
        raise HTTPException(400, f"tidak ada koin dengan data TF {q['tf']} & {q['snr_tf']}")
    _guard()
    return {"id": snrjobs.start(syms, q, req.get("workers")), "kind": "snrtest"}


@app.post("/api/msa/screen")
def msa_screen(req: dict):
    """🔎 Screener Market Structure 1 koin: struktur sekarang (live Binance, cadangan data lokal) -> pola sama di riwayat
    lokal -> arah selanjutnya + entry / SL / TP (RR >= 1:3). Proses di latar belakang (GET /api/screener/job/{id})."""
    from . import msscreen as MS
    sym = str(req.get("symbol") or "").upper().strip()
    if sym and not sym.endswith("USDT"):
        sym += "USDT"
    tf = str(req.get("tf") or "15m")
    if tf not in TF_MS:
        raise HTTPException(400, "TF tidak dikenal")
    if not sym:
        raise HTTPException(400, "isi koin dulu")
    swing = req.get("swing") if req.get("swing") in MS.SWINGS else "kecil"
    try:
        scope = MS.parse_scope(req.get("scope"))
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if scope == "coin" and (sym not in store.catalog or tf not in store.timeframes(sym)):
        raise HTTPException(400, f"data lokal {sym} {tf} tidak ada — pakai riwayat semua koin, atau unduh datanya dulu")
    if isinstance(scope, list):
        miss = [x for x in scope if x not in store.catalog or tf not in store.timeframes(x)]
        if len(miss) == len(scope):
            raise HTTPException(400, f"tidak ada data lokal {tf} untuk koin riwayat: {', '.join(miss[:10])}")
    htf = str(req.get("htf") or "auto")
    if htf not in ("auto", "off") and htf not in TF_MS:
        raise HTTPException(400, "TF besar tidak dikenal")

    def work(prog):
        live, note, live_htf = None, None, None
        try:
            k = whales.c.get("/fapi/v1/klines", symbol=sym, interval=tf, limit=1000)
            now = time.time() * 1000
            k = [r for r in k if float(r[6]) < now]                    # hanya candle yang sudah close
            if len(k) >= 100:
                live = tuple(np.array([float(r[i]) for r in k]) for i in (0, 1, 2, 3, 4))
            H = MS.resolve_htf(tf, htf)
            if live is not None and H:
                kh = [r for r in whales.c.get("/fapi/v1/klines", symbol=sym, interval=H, limit=500) if float(r[6]) < now]
                if len(kh) >= 30:
                    live_htf = tuple(np.array([float(r[i]) for r in kh]) for i in (0, 1, 2, 3, 4))
        except Exception as ex:                                        # noqa: BLE001 - tanpa internet: pakai data lokal
            note = f"Binance tidak bisa diakses ({type(ex).__name__}), struktur dibaca dari data lokal terakhir."
        if live is None and (sym not in store.catalog or tf not in store.timeframes(sym)):
            raise ValueError(f"tidak bisa ambil data {sym} dari Binance dan data lokalnya tidak ada")
        walls = AG.live_walls(whales.c, sym) if live is not None else None     # SL anti-gocekan live: ikut tembok order book
        r = MS.screen(store, sym, tf, swing, scope, live=live, progress=prog, htf=htf, live_htf=live_htf,
                      live_ev=_live_ev(sym)(tf) if live is not None else None, walls=walls)
        r["note"] = note
        _journal_add(lambda J: J.from_msa(r))
        return r
    return _bg_scan(work)


def _journal_add(make):
    """📒 catat sinyal layak ke jurnal (kalau pencatatan otomatis menyala). Gagal mencatat tidak mengganggu hasil."""
    try:
        from . import journal as J
        sig = make(J)
        if sig:
            sig.setdefault("app_version", VERSION)                 # versi aplikasi yang membuat sinyal (jurnal per versi)
            if getattr(_SCAN, "start", None):
                sig.setdefault("scan_start", _SCAN.start)          # v4.31: waktu mulai scan (evaluasi jam & hari scan)
            J.add(sig)
    except Exception:                                              # noqa: BLE001
        traceback.print_exc()


@app.get("/api/journal")
def journal_get(version: str = ""):
    """version: "" = semua, "lama" = sinyal tanpa catatan versi (sebelum v4.11), atau mis. "4.11"."""
    from . import journal as J
    return _clean(J.summary(version or None))


@app.post("/api/journal/update")
def journal_update(req: dict):
    """Perbarui sinyal terbuka sekarang (ambil candle Binance)."""
    from . import journal as J
    def work(prog):
        n = J.update(whales.c)
        e = J.enrich(whales.c, prog)                            # jalur harga trade selesai (analisa SL di 🔍 Evaluasi)
        return {"updated": n, "enriched": e}
    return _bg_scan(work)


@app.get("/api/journal/eval")
def journal_eval(source: str = "all", version: str = "", tf: str = "", min_n: int = 20, exact: int = 0):
    """🔍 Evaluasi trade selesai 1 sumber: pecahan hasil, analisa SL, koin, waktu & hari MULAI scan (WIB), saran."""
    from . import journal as J
    return _clean(J.evaluate(source, version or None, tf or None, max(3, min(int(min_n), 200)), bool(exact)))


@app.post("/api/journal/auto")
def journal_auto(req: dict):
    from . import journal as J
    return {"auto": J.set_auto(bool(req.get("on")))}


@app.post("/api/journal/delete")
def journal_delete(req: dict):
    from . import journal as J
    return {"deleted": J.delete(req.get("ids") or [], bool(req.get("all")))}


@app.post("/api/journal/manual")
def journal_manual(req: dict):
    """Pantau entry kamu (hasil 🧪 Cek entry posisi) di jurnal."""
    from . import journal as J
    r = req.get("result") or {}
    try:
        sig = J.from_manual(r)
        sig.setdefault("app_version", VERSION)
    except (KeyError, TypeError, ValueError) as ex:
        raise HTTPException(400, f"hasil cek entry tidak lengkap: {ex}")
    return {"added": J.add(sig)}


TAPRO_WORKERS = 6                    # 🧠 TA Pro: koin yang dibaca live sekaligus


@app.post("/api/tapro/scan")
def tapro_scan(req: dict):
    """🧠 Teknikal Analisis Pro Advance: riwayat banyak koin (data lokal) -> statistik setup A–D + model peluang; lalu koin yang
    di-scan dibaca LIVE dari Binance (data lokal kalau Binance tidak bisa diakses) -> rencana entry / SL / TP1 / TP2 + pemeriksa."""
    from . import tapro as TP
    style = req.get("style") if req.get("style") in TP.STYLES else "intraday"
    try:
        hist_n = max(3, min(int(req.get("hist") or 30), 150))
    except (TypeError, ValueError):
        hist_n = 30
    raw = req.get("coins")
    one = str(req.get("symbol") or "").upper().strip()
    if one and not one.endswith("USDT"):
        one += "USDT"
    want = None
    if req.get("mode") == "one":
        if not one:
            raise HTTPException(400, "isi koin")
        want = [one]
    elif isinstance(raw, list) or (isinstance(raw, str) and raw.strip() and not raw.strip().isdigit()):
        L = raw if isinstance(raw, list) else str(raw).replace(";", ",").replace(" ", ",").split(",")
        want = [x.upper() if x.upper().endswith("USDT") else x.upper() + "USDT" for x in (str(y).strip() for y in L) if x]
    n_req = max(1, min(int(raw or 30), 300)) if want is None else len(want)

    def work(prog):
        note = []
        syms_h = TP.history_symbols(store, style, hist_n, include=one or None)
        if len(syms_h) < 3:
            raise ValueError(f"data lokal TF {TP.STYLES[style]['tf']} terlalu sedikit untuk backtest (butuh minimal 3 koin)")
        push = getattr(prog, "partial", None)
        n_live = n_req
        L = TP.learn(store, style, syms_h, progress=lambda i, n, s_, e: (prog(i, n + n_live, "riwayat " + s_, e),
                                                                         push and push({"phase": "riwayat", "rows": [], "full": {}, "partial": True,
                                                                                         "hist_done": i, "hist_total": n, "style_name": TP.STYLES[style]["name"]})))
        ST = L["stats"]
        learn_info = {"n_rows": L["n_rows"], "coins": syms_h, "fng": L["fng"], "btc": L["btc"], "from_file": bool(L.get("from_file")),
                      "setups": sorted([{k: v for k, v in s_.items() if k not in ("model", "examples")} | {"model_proven": bool(s_.get("model") and s_["model"]["proven"]),
                                        "weights": (s_.get("model") or {}).get("weights")} for s_ in ST.values()],
                                       key=lambda x: (x["ok"], x["exp_sig"]), reverse=True)}
        if not L["fng"]:
            note.append("Fear & Greed tidak bisa diambil (alternative.me) — faktor itu tidak dipakai di model")
        syms = want
        if syms is None:
            try:
                tick = whales.c.get("/fapi/v1/ticker/24hr")
                info = whales.c.get("/fapi/v1/exchangeInfo")
                perp = {x["symbol"] for x in info["symbols"] if x.get("contractType") == "PERPETUAL" and x.get("quoteAsset") == "USDT" and x.get("status") == "TRADING"}
                syms = [t["symbol"] for t in sorted((t for t in tick if t["symbol"] in perp), key=lambda t: -float(t["quoteVolume"]))][:n_req]
            except Exception as ex:                                    # noqa: BLE001
                note.append(f"Binance tidak bisa diakses ({type(ex).__name__}) — koin & candle dari data lokal")
                syms = TP.history_symbols(store, style, n_req)
        btc = TP._btc_trend(store, style)
        fng = TP.fear_greed()
        rows, full, errs = [], {}, []

        def one_coin(sym):                                             # 1 koin: candle live -> analisa (dipanggil paralel)
            try:
                S = TP.live_series(whales.c, sym, style, btc, fng)
                src = "binance"
            except Exception:                                          # noqa: BLE001 - tanpa internet: data lokal
                if sym not in store.catalog:
                    raise
                S = TP._series_from_store(store, sym, style, btc, fng)
                src = "lokal"
            r = TP.analyse(whales.c, store, sym, style, syms_h, ST, btc, fng, live=S)
            r["source"] = src
            return r
        from concurrent.futures import ThreadPoolExecutor, as_completed
        with ThreadPoolExecutor(max_workers=TAPRO_WORKERS) as ex_:     # beberapa koin sekaligus (tetap di bawah batas Binance)
            futs = {ex_.submit(one_coin, sym): sym for sym in syms}
            for i, fu in enumerate(as_completed(futs)):
                sym = futs[fu]
                prog(len(syms_h) + i + 1, len(syms_h) + len(syms), sym, None)
                try:
                    r = fu.result()
                except Exception as ex:                                # noqa: BLE001
                    errs.append(f"{sym}: {type(ex).__name__}: {ex}")
                    continue
                src = r["source"]
                B = r["best"]
                rows.append({"symbol": sym, "source": src, "price": r["price"], "trend": r["trend"], "n_plans": len(r["plans"]),
                             **({k: B[k] for k in ("code", "setup", "side", "dir", "entry_kind", "entry_name", "price_entry", "price_sl", "price_tp1",
                                                   "price_tp2", "rr2", "prob", "prob_src", "score", "class", "decision", "why", "n_warn", "age")} if B else {}),
                             **({"wr": B["stats"]["wr"], "fill_pct": B["stats"]["fill_pct"], "clean_pct": B["stats"]["clean_pct"], "main_pct": B["stats"]["main_pct"],
                                 "exp_r": B["stats"]["exp_r"], "n": B["stats"]["n"], "n_test": B["stats"]["n_test"], "ok": B["stats"]["ok"]} if B else {})})
                if B:
                    full[sym] = r
                    for p_ in r["plans"]:
                        if p_["decision"] == "ENTRY":
                            _journal_add(lambda J, sym=sym, p_=p_, r=r: J.from_tapro(sym, p_, style, int(r["time"]), r.get("trend")))
                if push:                                               # hasil sementara: tabel + kartu langsung bisa dibuka
                    push({"phase": "scan", "rows": rows[:], "full": dict(full), "partial": True, "done": i + 1, "total": len(syms),
                          "hist_done": len(syms_h), "hist_total": len(syms_h), "learn": learn_info, "style_name": TP.STYLES[style]["name"],
                          "note": note, "errors": errs[-5:]})
        rows.sort(key=lambda x: ({"ENTRY": 3, "TUNGGU": 2, "JANGAN": 1}.get(x.get("decision"), 0), x.get("score") or 0), reverse=True)
        return {"style": style, "style_name": TP.STYLES[style]["name"], "rows": rows, "full": full, "errors": errs[:20], "note": note,
                "learn": learn_info, "time": int(time.time() * 1000)}
    return _bg_scan(work)


@app.post("/api/cpat/scan")
def cpat_scan(req: dict):
    """🧩 Chart Pattern Screener / 🔄 Find Reversal (menu Screener): riwayat koin lokal -> backtest tiap pola x entry x TP;
    lalu koin yang di-scan dibaca LIVE dari Binance -> pola VALID (baru break) & MENUNGGU (belum break, entry* dihitung)."""
    from . import antigocek as AG_
    from . import chartpat as CP
    from .data import TF_MS as _TFMS
    tf = str(req.get("tf") or "1h")
    if tf not in _TFMS:
        raise HTTPException(400, "TF tidak dikenal")
    mode = "reversal" if req.get("mode") == "reversal" else "pattern"
    codes = ["rv"] if mode == "reversal" else [c_ for c_ in {k[0] for k in CP.NAMES} if c_ != "rv"]
    try:
        hist_n = max(3, min(int(req.get("hist") or 30), 150))
        fresh = max(1, min(int(req.get("fresh") or CP.FRESH_DEF), 200))
        k = 5 if str(req.get("swing")) == "5" else 3
    except (TypeError, ValueError):
        raise HTTPException(400, "angka tidak valid")
    show_wait = req.get("wait", True) is not False
    raw = req.get("coins")
    want = None
    if isinstance(raw, list) or (isinstance(raw, str) and raw.strip() and not raw.strip().isdigit()):
        L = raw if isinstance(raw, list) else str(raw).replace(";", ",").replace(" ", ",").split(",")
        want = [x.upper() if x.upper().endswith("USDT") else x.upper() + "USDT" for x in (str(y).strip() for y in L) if x]
    try:
        n_req = max(1, min(int(raw or 50), 500)) if want is None else len(want)
    except (TypeError, ValueError):
        raise HTTPException(400, "jumlah koin tidak valid")

    def work(prog):
        note = []
        syms_h = CP.history_symbols(store, tf, hist_n)
        if len(syms_h) < 3:
            raise ValueError(f"data lokal TF {tf} terlalu sedikit untuk backtest (butuh minimal 3 koin) — unduh data candle dulu")
        push = getattr(prog, "partial", None)
        L = CP.learn(store, tf, syms_h, k, progress=lambda i, n, s_, e: (prog(i, n + n_req, "riwayat " + s_, e),
                     push and push({"phase": "riwayat", "rows": [], "candles": {}, "partial": True, "hist_done": i, "hist_total": n})))
        ST = {k_: v for k_, v in L["stats"].items() if k_[0] in codes}
        learn_info = {"n_rows": L["n_rows"], "coins": syms_h, "from_file": bool(L.get("from_file")), "window": CP.window_bars(tf),
                      "combos": sorted([{k_: v for k_, v in s_.items() if k_ != "examples"} for s_ in ST.values()],
                                       key=lambda x: (x["ok"], x["exp_sig"]), reverse=True)}
        syms = want
        if syms is None:
            try:
                tick = whales.c.get("/fapi/v1/ticker/24hr")
                info = whales.c.get("/fapi/v1/exchangeInfo")
                perp = {x["symbol"] for x in info["symbols"] if x.get("contractType") == "PERPETUAL" and x.get("quoteAsset") == "USDT" and x.get("status") == "TRADING"}
                syms = [t_["symbol"] for t_ in sorted((t_ for t_ in tick if t_["symbol"] in perp), key=lambda t_: -float(t_["quoteVolume"]))][:n_req]
            except Exception as ex:                                    # noqa: BLE001
                note.append(f"Binance tidak bisa diakses ({type(ex).__name__}) — koin & candle dari data lokal")
                syms = CP.history_symbols(store, tf, n_req)
        rows, candles, errs = [], {}, []

        def one_coin(sym):
            src = "binance"
            try:
                now = time.time() * 1000
                kk = [r for r in whales.c.get("/fapi/v1/klines", symbol=sym, interval=tf, limit=1000) if float(r[6]) < now]
                if len(kk) < 200:
                    raise ValueError("candle terlalu sedikit")
                t_, o_, h_, l_, c_ = (np.array([float(r[j]) for r in kk]) for j in range(5))
            except Exception:                                          # noqa: BLE001 - tanpa internet: data lokal
                if sym not in store.catalog or tf not in store.timeframes(sym):
                    raise
                b = store.get(sym, tf)
                t_, o_, h_, l_, c_ = (np.asarray(z, float)[-1000:] for z in (b.t, b.o, b.h, b.l, b.c))
                src = "lokal"
            t_ = t_.astype(np.int64)
            R = CP.current(sym, t_, o_, h_, l_, c_, tf, ST, k, fresh, None, codes)
            if R and src == "binance":                                 # ada sinyal: SL live ikut tembok order book (seperti Whale)
                walls = AG_.live_walls(whales.c, sym)
                if walls is not None:
                    R = CP.current(sym, t_, o_, h_, l_, c_, tf, ST, k, fresh, walls, codes)
            if not show_wait:
                R = [r for r in R if r["status"] == "valid"]
            out = []
            for r in R[:6]:
                cd = CP.card_data(t_, o_, h_, l_, c_, r)
                r["proj"], r["source"] = cd["proj"], src
                out.append(r)
            cand = CP.card_data(t_, o_, h_, l_, c_, {"stats": None, "price_entry": 0, "price_sl": 0, "price_tp": 0, "dir": 1,
                                                     "entry_kind": "market", "symbol": sym})["candles"] if out else None
            return out, cand
        from concurrent.futures import ThreadPoolExecutor, as_completed
        with ThreadPoolExecutor(max_workers=TAPRO_WORKERS) as ex_:
            futs = {ex_.submit(one_coin, sym): sym for sym in syms}
            for i, fu in enumerate(as_completed(futs)):
                sym = futs[fu]
                prog(len(syms_h) + i + 1, len(syms_h) + len(syms), sym, None)
                try:
                    R, cand = fu.result()
                except Exception as ex:                                # noqa: BLE001
                    errs.append(f"{sym}: {type(ex).__name__}: {ex}")
                    continue
                if R:
                    candles[sym] = cand
                    rows += R
                    for r in R:
                        if r["status"] == "valid" and r["stats"] and r["stats"]["ok"]:
                            _journal_add(lambda J, r=r: J.from_cpat(r, tf))
                if push:
                    push({"phase": "scan", "rows": rows[:], "candles": dict(candles), "partial": True, "done": i + 1, "total": len(syms),
                          "hist_done": len(syms_h), "hist_total": len(syms_h), "learn": learn_info, "note": note, "errors": errs[-5:], "tf": tf, "mode": mode})
        rows.sort(key=lambda r: (r["status"] == "valid", bool(r["stats"] and r["stats"]["ok"]), (r["stats"] or {}).get("exp_sig") or -9), reverse=True)
        return {"tf": tf, "mode": mode, "rows": rows, "candles": candles, "errors": errs[:20], "note": note, "learn": learn_info,
                "scanned": len(syms), "time": int(time.time() * 1000)}
    return _bg_scan(work)


@app.post("/api/sweep/run")
def sweep_run(req: dict):
    """🧠 TA Pro › 💧 Liquidity Sweep backtest: semua sweep di data lokal banyak koin -> cara terbaik + efek tiap penyaring."""
    from . import sweeplab as SW
    from .data import TF_MS as _TFMS
    tf = str(req.get("tf") or "15m")
    if tf not in _TFMS:
        raise HTTPException(400, "TF tidak dikenal")
    try:
        n = max(3, min(int(req.get("hist") or 30), 150))
    except (TypeError, ValueError):
        raise HTTPException(400, "jumlah koin tidak valid")

    def work(prog):
        from . import results_store as RS
        syms = SW.history_symbols(store, tf, n)
        if len(syms) < 3:
            raise ValueError(f"data lokal TF {tf} terlalu sedikit (butuh minimal 3 koin) — unduh data candle dulu")
        r = SW.run(store, tf, syms, progress=prog, push=getattr(prog, "partial", None))
        try:                                                          # simpan ke 📂 Hasil tersimpan (bisa dibuka lagi)
            r["saved_id"] = RS.save("sweeplab", _clean(r), {"tf": tf, "hist": n}, symbols=r.get("coins"))
        except (OSError, ValueError, TypeError):
            pass
        return r
    return _bg_scan(work)


@app.get("/api/sweep/candles")
def sweep_candles(sym: str, tf: str, t: int):
    """Candle data lokal di sekitar 1 contoh trade sweep (gambar visual contoh)."""
    from . import sweeplab as SW
    if sym not in store.catalog or tf not in store.timeframes(sym):
        raise HTTPException(404, f"data lokal {sym} {tf} tidak ada")
    c, i = SW.candles_around(store, sym, tf, t)
    return {"candles": c, "i": i}


@app.post("/api/slbt/run")
def slbt_run(req: dict):
    """🛡️ SL Backtest: sinyal riwayat strategi pilihan (data lokal banyak koin) -> SL ATR 1..6 mana yang paling sering menang."""
    from . import slbt as SB
    from .data import TF_MS as _TFMS
    tf = str(req.get("tf") or "15m")
    strat = str(req.get("strat") or "whale")
    if tf not in _TFMS:
        raise HTTPException(400, "TF tidak dikenal")
    if strat not in SB.STRATS:
        raise HTTPException(400, "strategi tidak dikenal")
    try:
        n = max(3, min(int(req.get("hist") or 30), 150))
    except (TypeError, ValueError):
        raise HTTPException(400, "jumlah koin tidak valid")

    def work(prog):
        from . import results_store as RS
        syms = SB.history_symbols(store, tf, n)
        if len(syms) < 3:
            raise ValueError(f"data lokal TF {tf} terlalu sedikit (butuh minimal 3 koin) — unduh data candle dulu")
        r = SB.run(store, tf, strat, syms, progress=prog, push=getattr(prog, "partial", None))
        try:                                                          # simpan ke 📂 Hasil tersimpan
            r["saved_id"] = RS.save("slbt", _clean(r), {"tf": tf, "strat": strat, "hist": n}, symbols=r.get("coins"))
        except (OSError, ValueError, TypeError):
            pass
        return r
    return _bg_scan(work)


@app.get("/api/slbt/candles")
def slbt_candles(sym: str, tf: str, t: int, after: int = 200):
    """Candle data lokal di sekitar 1 contoh trade SL Backtest (gambar visual)."""
    from . import slbt as SB
    if sym not in store.catalog or tf not in store.timeframes(sym):
        raise HTTPException(404, f"data lokal {sym} {tf} tidak ada")
    c, i = SB.candles_around(store, sym, tf, t, after=after)
    return {"candles": c, "i": i}


@app.post("/api/maa/run")
def maa_run(req: dict):
    """📈 Moving Average Analisis: setelan indikator yang paling cocok dengan 1 MA (sentuh MA + OB/OS -> respect >= 2 ATR)."""
    from . import maa as MA_
    from .data import TF_MS as _TFMS
    tf = str(req.get("tf") or "15m")
    ma_type = str(req.get("ma_type") or "ema").lower()
    ind = str(req.get("ind") or "rsi").lower()
    mode = "auto" if req.get("mode") == "auto" else "list"
    if tf not in _TFMS:
        raise HTTPException(400, "TF tidak dikenal")
    if ma_type not in MA_.MA_TYPES or ind not in MA_.INDS:
        raise HTTPException(400, "tipe MA / indikator tidak dikenal")
    ma_auto = bool(req.get("ma_auto")) or str(req.get("ma_len")).lower() == "auto"
    try:
        ma_len = 0 if ma_auto else int(req.get("ma_len") or 200)
        n = max(3, min(int(req.get("hist") or 30), 150))
    except (TypeError, ValueError):
        raise HTTPException(400, "angka tidak valid")
    if not ma_auto and not 2 <= ma_len <= 1000:
        raise HTTPException(400, "periode MA harus 2–1000")

    def work(prog):
        from . import results_store as RS
        syms = MA_.history_symbols(store, tf, n)
        if len(syms) < 3:
            raise ValueError(f"data lokal TF {tf} terlalu sedikit (butuh minimal 3 koin) — unduh data candle dulu")
        r = MA_.run(store, tf, ma_type, ma_len, ind, mode, syms, progress=prog, push=getattr(prog, "partial", None))
        try:
            r["saved_id"] = RS.save("maa", _clean(r), {"tf": tf, "ma": f"{ma_type.upper()} {'otomatis → ' + str(r.get('ma_len')) if ma_auto else ma_len}", "ind": ind, "mode": mode, "hist": n},
                                    symbols=r.get("coins"))
        except (OSError, ValueError, TypeError):
            pass
        return r
    return _bg_scan(work)


@app.get("/api/maa/visual")
def maa_visual(sym: str, tf: str, t: int, ma_type: str, ma_len: int, ind: str, p: int, after: int = 150):
    """Candle asli + MA + seri indikator di sekitar 1 contoh sinyal (gambar visual + animasi)."""
    from . import maa as MA_
    if sym not in store.catalog or tf not in store.timeframes(sym):
        raise HTTPException(404, f"data lokal {sym} {tf} tidak ada")
    if ma_type not in MA_.MA_TYPES or ind not in MA_.INDS:
        raise HTTPException(400, "tipe MA / indikator tidak dikenal")
    return _clean(MA_.visual(store, sym, tf, t, ma_type, ma_len, ind, p, after=after))


@app.post("/api/arb/run")
def arb_run(req: dict):
    """🧭 Penentu Arah: semua sinyal strategi tetap, model hanya membalik arah kalau yakin (belajar 70% awal, uji 30% terakhir)."""
    from . import arbiter as AR
    from .data import TF_MS as _TFMS
    tf = str(req.get("tf") or "15m")
    strat = str(req.get("strat") or "whale")
    if tf not in _TFMS:
        raise HTTPException(400, "TF tidak dikenal")
    if strat not in AR.STRATS:
        raise HTTPException(400, "strategi tidak dikenal")
    groups = [g for g in (req.get("groups") or list(AR.GROUPS)) if g in AR.GROUPS]
    if not groups:
        raise HTTPException(400, "pilih minimal 1 faktor model")
    try:
        n = max(3, min(int(req.get("hist") or 30), 150))
    except (TypeError, ValueError):
        raise HTTPException(400, "jumlah koin tidak valid")

    def work(prog):
        from . import results_store as RS
        syms = AR.history_symbols(store, tf, n)
        if len(syms) < 3:
            raise ValueError(f"data lokal TF {tf} terlalu sedikit (butuh minimal 3 koin) — unduh data candle dulu")
        r = AR.run(store, tf, strat, syms, client=whales.c, use_flow="flow" in groups, groups=groups,
                   progress=prog, push=getattr(prog, "partial", None))
        try:
            r["saved_id"] = RS.save("arb", _clean(r), {"tf": tf, "strat": strat, "hist": n, "faktor": len(groups)}, symbols=r.get("coins"))
        except (OSError, ValueError, TypeError):
            pass
        return r
    return _bg_scan(work)


@app.get("/api/arb/candles")
def arb_candles(sym: str, tf: str, t: int, after: int = 200):
    """Candle data lokal di sekitar 1 contoh sinyal Penentu Arah (gambar visual + animasi)."""
    from . import slbt as SB
    if sym not in store.catalog or tf not in store.timeframes(sym):
        raise HTTPException(404, f"data lokal {sym} {tf} tidak ada")
    c, i = SB.candles_around(store, sym, tf, t, before=80, after=after)
    return {"candles": c, "i": i}


@app.post("/api/msa/scan")
def msa_scan(req: dict):
    """🔎 Screener Market Structure BANYAK koin: tiap koin dibaca live dari Binance (struktur + TF besar), pola dicari di
    riwayat lokal, hanya setup yang LAYAK (berlaku, terisi >= 70%, untung & terbukti) ditandai. coins = jumlah (volume
    Binance terbesar) atau daftar koin."""
    from . import msscreen as MS
    tf = str(req.get("tf") or "15m")
    if tf not in TF_MS:
        raise HTTPException(400, "TF tidak dikenal")
    swing = req.get("swing") if req.get("swing") in MS.SWINGS else "kecil"
    try:
        scope = MS.parse_scope(req.get("scope"))
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    try:                                                                # swing minimal (x ATR), hanya scan banyak koin
        min_leg = float(req.get("min_leg", MS.MULTI_MIN_LEG))
    except (TypeError, ValueError):
        min_leg = MS.MULTI_MIN_LEG
    if min_leg not in MS.MIN_LEG_CHOICES:
        min_leg = MS.MULTI_MIN_LEG
    htf = str(req.get("htf") or "auto")
    if htf not in ("auto", "off") and htf not in TF_MS:
        raise HTTPException(400, "TF besar tidak dikenal")
    raw = req.get("coins") or 50
    want = None
    if isinstance(raw, list) or (isinstance(raw, str) and not raw.strip().isdigit()):
        L = raw if isinstance(raw, list) else str(raw).replace(";", ",").replace(" ", ",").split(",")
        want = [x.upper() if x.upper().endswith("USDT") else x.upper() + "USDT" for x in (str(y).strip() for y in L) if x]
        if not want:
            raise HTTPException(400, "isi jumlah koin atau daftar koin")
    else:
        n_req = max(1, min(int(raw), 300))

    def work(prog):
        note = None
        H = MS.resolve_htf(tf, htf)
        if want is None:
            try:
                tick = whales.c.get("/fapi/v1/ticker/24hr")
                info = whales.c.get("/fapi/v1/exchangeInfo")
                perp = {x["symbol"] for x in info["symbols"] if x.get("contractType") == "PERPETUAL"
                        and x.get("quoteAsset") == "USDT" and x.get("status") == "TRADING"}
                syms = [t["symbol"] for t in sorted((t for t in tick if t["symbol"] in perp), key=lambda t: -float(t["quoteVolume"]))][:n_req]
            except Exception as ex:                                    # noqa: BLE001 - tanpa internet: koin data lokal
                note = f"Binance tidak bisa diakses ({type(ex).__name__}), koin & struktur dari data lokal."
                syms = MS.history_symbols(store, "", tf, n_req)
        else:
            syms = want
        rows, full, errs = [], {}, []
        for i, sym in enumerate(syms):
            prog(i, len(syms), sym, None)
            live = live_htf = None
            try:
                now = time.time() * 1000
                k = [r for r in whales.c.get("/fapi/v1/klines", symbol=sym, interval=tf, limit=1000) if float(r[6]) < now]
                if len(k) >= 100:
                    live = tuple(np.array([float(r[j]) for r in k]) for j in (0, 1, 2, 3, 4))
                if live is not None and H:
                    kh = [r for r in whales.c.get("/fapi/v1/klines", symbol=sym, interval=H, limit=500) if float(r[6]) < now]
                    if len(kh) >= 30:
                        live_htf = tuple(np.array([float(r[j]) for r in kh]) for j in (0, 1, 2, 3, 4))
            except Exception:                                          # noqa: BLE001 - pakai data lokal
                live = live_htf = None
            if live is None and (sym not in store.catalog or tf not in store.timeframes(sym)):
                errs.append(f"{sym}: tidak ada data")
                continue
            try:
                r = MS.screen(store, sym, tf, swing, scope, live=live, htf=htf, live_htf=live_htf,
                              live_ev=_live_ev(sym)(tf) if live is not None else None,
                              rrs=MS.MULTI_RRS, min_wr=MS.MULTI_MIN_WR,         # scan banyak koin: RR >= 1:2 & WR >= 50%
                              min_leg=min_leg, bounce=True,                      # & swing kecil diabaikan & utamakan entry yg sering mantul
                              walls=AG.live_walls(whales.c, sym) if live is not None else None)   # SL anti-gocekan + tembok live
            except (ValueError, KeyError, IndexError) as ex:
                errs.append(f"{sym}: {ex}")
                continue
            sm = MS.summary(r)
            rows.append(sm)
            if sm["usable"]:
                _journal_add(lambda J, r=r: J.from_msa(r))
            if sm["usable"] and len(full) < 40:
                full[sym] = _clean(r)
            push = getattr(prog, "partial", None)
            if push:
                push({"rows": sorted(rows, key=_msa_rank), "full": {}, "partial": True, "done": i + 1, "total": len(syms)})
        prog(len(syms), len(syms), "", None)
        rows.sort(key=_msa_rank)
        return {"rows": rows, "full": full, "n_usable": sum(1 for x in rows if x["usable"]), "n": len(rows), "errors": errs[:20],
                "n_errors": len(errs), "tf": tf, "swing": swing, "htf": htf, "min_leg": min_leg, "note": note, "time": int(time.time() * 1000)}
    return _bg_scan(work)


def _msa_rank(x):
    """Layak dipasang dulu (R per sinyal terbesar), lalu yang lain menurut keunggulan arah pola."""
    return (not x["usable"], -(x["exp_sig"] or 0) if x["usable"] else -(x["edge"] or -99))


@app.post("/api/msa/check")
def msa_check(req: dict):
    """🧪 Cek entry posisi: entry / SL / TP kamu diuji di kejadian pola market structure yang sama di riwayat
    -> peluang & lama limit terisi, WR, saran entry / SL / TP (belum terisi) atau saran TP (sudah masuk)."""
    from . import poscheck as PC
    from . import msscreen as MS
    sym = str(req.get("symbol") or "").upper().strip()
    if sym and not sym.endswith("USDT"):
        sym += "USDT"
    tf = str(req.get("tf") or "15m")
    if tf not in TF_MS:
        raise HTTPException(400, "TF tidak dikenal")
    if not sym:
        raise HTTPException(400, "isi koin dulu")
    try:
        e, s_, t_ = float(req.get("entry")), float(req.get("sl")), float(req.get("tp"))
    except (TypeError, ValueError):
        raise HTTPException(400, "isi entry, SL dan TP dengan angka")
    if not ((t_ > e > s_) or (t_ < e < s_)):
        raise HTTPException(400, "susunan harga salah: LONG = SL < entry < TP, SHORT = TP < entry < SL")
    swing = req.get("swing") if req.get("swing") in MS.SWINGS else "kecil"
    try:
        scope = MS.parse_scope(req.get("scope"))
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if scope == "coin" and (sym not in store.catalog or tf not in store.timeframes(sym)):
        raise HTTPException(400, f"data lokal {sym} {tf} tidak ada — pakai riwayat semua koin, atau unduh datanya dulu")
    if isinstance(scope, list):
        miss = [x for x in scope if x not in store.catalog or tf not in store.timeframes(x)]
        if len(miss) == len(scope):
            raise HTTPException(400, f"tidak ada data lokal {tf} untuk koin riwayat: {', '.join(miss[:10])}")
    htf = str(req.get("htf") or "auto")
    if htf not in ("auto", "off") and htf not in TF_MS:
        raise HTTPException(400, "TF besar tidak dikenal")
    filled = bool(req.get("filled"))

    def work(prog):
        live, note, live_htf = None, None, None
        try:
            k = whales.c.get("/fapi/v1/klines", symbol=sym, interval=tf, limit=1000)
            now = time.time() * 1000
            k = [r for r in k if float(r[6]) < now]
            if len(k) >= 100:
                live = tuple(np.array([float(r[i]) for r in k]) for i in (0, 1, 2, 3, 4))
            H = MS.resolve_htf(tf, htf)
            if live is not None and H:
                kh = [r for r in whales.c.get("/fapi/v1/klines", symbol=sym, interval=H, limit=500) if float(r[6]) < now]
                if len(kh) >= 30:
                    live_htf = tuple(np.array([float(r[i]) for r in kh]) for i in (0, 1, 2, 3, 4))
        except Exception as ex:                                        # noqa: BLE001
            note = f"Binance tidak bisa diakses ({type(ex).__name__}), struktur dibaca dari data lokal terakhir."
        if live is None and (sym not in store.catalog or tf not in store.timeframes(sym)):
            raise ValueError(f"tidak bisa ambil data {sym} dari Binance dan data lokalnya tidak ada")
        r = PC.check(store, sym, tf, e, s_, t_, filled=filled, swing=swing, scope=scope, live=live, progress=prog, htf=htf, live_htf=live_htf,
                     live_ev=_live_ev(sym)(tf) if live is not None else None,
                     walls=AG.live_walls(whales.c, sym) if live is not None else None)
        r["note"] = note
        return r
    return _bg_scan(work)


@app.get("/api/msa/defaults")
def msa_defaults():
    return {"defaults": _MSA.DEFAULTS, "swings": _MSA.SWINGS}


@app.post("/api/msa")
def msa_start(req: dict):
    """📐 Analisa Market Structure: statistik koreksi, impuls, umur tren, BOS / CHoCH, HH / LL berturut-turut."""
    try:
        q = _MSA._params(req.get("params") or {})
    except (TypeError, ValueError) as ex:
        raise HTTPException(400, str(ex))
    syms = [x.upper() for x in (req.get("symbols") or []) if x.upper() in store.catalog] or store.symbols()
    syms = [x for x in syms if q["tf"] in store.timeframes(x)]
    if not syms:
        raise HTTPException(400, f"tidak ada koin dengan data TF {q['tf']}")
    _guard()
    return {"id": msajobs.start(syms, q, req.get("workers")), "kind": "msa"}


@app.get("/api/stratlab/defaults")
def stratlab_defaults():
    from . import stratlab as SL
    return {"defaults": SL.DEFAULTS, "entries": SL.ENTRY_TXT, "sl": SL.SL_TXT, "labels": SL.LBL}


@app.post("/api/stratlab")
def stratlab_start(req: dict):
    """🧠 Penemu Strategi: pola market structure (urutan swing) -> entry / SL / TP terbaik, di latar belakang."""
    from . import stratlab as SL
    p = req.get("params") or {}
    try:
        q = SL._params(p)
    except (TypeError, ValueError) as ex:
        raise HTTPException(400, str(ex))
    syms = [x.upper() for x in (req.get("symbols") or []) if x.upper() in store.catalog] or store.symbols()
    syms = [x for x in syms if q["tf"] in store.timeframes(x)]
    if not syms:
        raise HTTPException(400, f"tidak ada koin dengan data TF {q['tf']}")
    _guard()
    return {"id": slabjobs.start(syms, q, req.get("workers")), "kind": "stratlab"}


@app.post("/api/stratlab/trades")
def stratlab_trades(req: dict):
    from . import stratlab as SL
    sym = str(req.get("symbol") or "").upper()
    if sym not in store.catalog:
        raise HTTPException(404, "simbol tidak ditemukan")
    try:
        return _clean(SL.pattern_trades(store, sym, req.get("params") or {}, req.get("pattern") or {}))
    except (TypeError, ValueError, KeyError) as ex:
        raise HTTPException(400, f"tidak bisa menghitung trade: {ex}")


@app.post("/api/whales/setup_trades")
def whales_setup_trades(req: dict):
    """Contoh kejadian 🎯 Cari setup whale: daftar entry di backtest setup itu (data terbaru dari Binance)."""
    from .whales import setup_trades
    try:
        sym = str(req.get("symbol") or "").upper()
        sl_pct, tp_pct = float(req["sl_pct"]), float(req["tp_pct"])
    except (TypeError, ValueError, KeyError):
        raise HTTPException(400, "data setup tidak lengkap")
    try:
        dist = req.get("dist_pct")
        return _clean(setup_trades(whales.c, sym, req.get("side") or "BUY", sl_pct, tp_pct,
                                   dist_pct=float(dist) if dist is not None else None, down=req.get("down")))
    except Exception as ex:                                    # noqa: BLE001 - koneksi Binance dsb.
        raise HTTPException(502, f"gagal mengambil data: {ex}")


@app.post("/api/indtester/trades")
def indtester_trades(req: dict):
    """Contoh kejadian Indikator Tester: trade satu kombinasi di satu koin (dibuka di Manual Replay)."""
    from . import indtester as IT
    sym = str(req.get("symbol") or "").upper()
    if sym not in store.catalog:
        raise HTTPException(404, "simbol tidak ditemukan")
    try:
        if req.get("item"):                                # EMA Tester: kejadian pantulan / pasangan MA
            return _clean(IT.ema_events(store, sym, req.get("params") or {}, req["item"]))
        return _clean(IT.combo_trades(store, sym, req.get("params") or {}, req.get("combo") or {}))
    except (TypeError, ValueError, KeyError) as ex:
        raise HTTPException(400, f"tidak bisa menghitung trade: {ex}")


@app.get("/api/indtester/defaults")
def indtester_defaults():
    from . import indtester as IT
    return {"defaults": IT.DEFAULTS, "ma_types": IT.MA_TYPES, "max_combos": IT.MAX_COMBOS, "auto": IT.AUTO}


@app.post("/api/indtester")
def indtester_start(req: dict):
    """🧪 Indikator Tester: EMA / RSI / Stochastic / MACD / ADX / Force Index / kombinasi. Proses di latar belakang,
    progres lewat GET /api/screener/job/{id}."""
    from . import indtester as IT
    D = IT.DEFAULTS
    p = {**D, **{k: v for k, v in (req.get("params") or {}).items() if k in D}}
    try:
        if p["tester"] not in IT.TESTERS:
            raise ValueError("tester tidak dikenal")
        if p["tf"] not in TF_MS:
            raise ValueError(f"TF {p['tf']} tidak dikenal")
        p["sl_atr"] = min(max(float(p["sl_atr"]), 0.1), 20.0)
        p["rr"] = min(max(float(p["rr"]), 0.2), 20.0)
        p["max_bars"] = min(max(int(p["max_bars"]), 2), 2000)
        p["atr_len"] = min(max(int(p["atr_len"]), 2), 200)
        p["min_trades"] = min(max(int(p["min_trades"]), 1), 100000)
        p["top"] = min(max(int(p["top"]), 1), 200)
        p["body_pct"] = min(max(float(p["body_pct"]), 0.0), 100.0)
        p["vol_mult"] = min(max(float(p["vol_mult"]), 0.0), 20.0)
        p["swing"] = min(max(int(p["swing"]), 1), 20)
        p["confirm_bars"] = min(max(int(p["confirm_bars"]), 1), 1000)
        p["retest_bars"] = min(max(int(p["retest_bars"]), 1), 1000)
        p["retest_tol"] = min(max(float(p["retest_tol"]), 0.0), 5.0)
        p["bounce_away"] = min(max(float(p["bounce_away"]), 0.1), 20.0)
        p["hold_bars"] = min(max(int(p["hold_bars"]), 1), 500)
        p["start"] = int(p["start"]) if p.get("start") else None
        p["end"] = int(p["end"]) if p.get("end") else None
        p["trend_filter"] = bool(p.get("trend_filter"))
        for k in ("ma_type", "ma_type2"):
            if p[k] and str(p[k]).upper() not in IT.MA_TYPES:
                raise ValueError(f"jenis MA {p[k]} tidak dikenal")
            p[k] = str(p[k]).upper() if p[k] else ""
        p["ma_type"] = p["ma_type"] or "EMA"
        if p["tester"] in ("combo", "hyper"):
            comps = [c for c in (p.get("components") or []) if c in ("ma_pair", "rsi", "stoch", "macd", "adx", "force")]
            if p["tester"] == "combo" and len(comps) < 2:
                raise ValueError("kombinasi butuh minimal 2 indikator")
            if p["tester"] == "hyper" and not comps:
                raise ValueError("Hyperopt: pilih minimal 1 indikator")
            p["components"] = comps
        if p["tester"] == "hyper":
            IT.parse_list(str(p.get("hyper_sl") or "1, 1.5, 2"), 0.1, 20, integer=False)
            if p.get("hyper_obj") not in ("exp_r", "wr", "score"):
                p["hyper_obj"] = "exp_r"
        IT.plan(p)                                    # cek isian & jumlah kombinasi sebelum mulai (besar = bertahap)
    except (TypeError, ValueError) as ex:
        raise HTTPException(400, str(ex))
    syms = [x.upper() for x in (req.get("symbols") or []) if x.upper() in store.catalog] or store.symbols()
    syms = [x for x in syms if p["tf"] in store.timeframes(x)]
    if not syms:
        raise HTTPException(400, f"tidak ada koin dengan data TF {p['tf']}")
    _guard()
    return {"id": itjobs.start(syms, p, req.get("workers")), "kind": "indtester"}


@app.get("/api/whales/config")
def whales_config():
    """Threshold Whale / Cari setup: nilai aktif, default & penjelasan tiap angka."""
    from . import whale_cfg
    return {"values": whale_cfg.get(), "defaults": whale_cfg.DEFAULTS, "sections": whale_cfg.schema()}


@app.post("/api/whales/config")
def whales_config_save(req: dict):
    from . import whale_cfg
    if req.get("reset"):
        return {"values": whale_cfg.reset()}
    return {"values": whale_cfg.save(req.get("values") or {})}


@app.post("/api/whales/check")
def whales_check(req: dict):
    """Cek entry user (entry, SL, TP) untuk 1 koin: peluang TP dulu + posisi terhadap whale & gocekan."""
    from .whales import check_entry
    sym = str(req.get("symbol") or "").upper().strip()
    if not sym:
        raise HTTPException(400, "isi simbol koin")
    if not sym.endswith("USDT"):
        sym += "USDT"
    try:
        e, sl, tp = float(req["entry"]), float(req["sl"]), float(req["tp"])
    except (KeyError, TypeError, ValueError):
        raise HTTPException(400, "isi entry, SL, dan TP dengan angka")
    min_usdt = max(1000.0, float(req.get("min_usdt") or 50_000))
    status = req.get("status")
    try:
        min_rr = max(0.5, min(10.0, float(req.get("min_rr") or 2.0)))
    except (TypeError, ValueError):
        min_rr = 2.0
    if status not in ("running", "pending"):
        raise HTTPException(400, "pilih status posisi: sudah berjalan / belum kena entry")
    side = str(req.get("side") or "").upper()
    if side not in ("BUY", "SELL"):
        raise HTTPException(400, "pilih arah: BUY atau SELL")
    if side == "BUY" and not (sl < e < tp):
        raise HTTPException(400, "BUY: SL harus di bawah entry dan TP di atas entry")
    if side == "SELL" and not (tp < e < sl):
        raise HTTPException(400, "SELL: SL harus di atas entry dan TP di bawah entry")

    def work(prog):
        prog(1, 2, sym + " · analisa whale", None)
        r = check_entry(whales.c, sym, e, sl, tp, status, min_usdt, min_rr, side)
        prog(2, 2, sym + " · backtest entry", None)
        return r
    return _bg_scan(work)


@app.post("/api/whales/setups")
def whales_setups(req: dict):
    """Cari setup terbaik (entry, SL anti-gocekan, TP = RR user) di N koin volume terbesar, diurutkan dari
    rata-rata hasil per trade hasil backtest."""
    from .whales import scan_setups
    try:
        raw = req.get("rr") or 2.0
        raw = raw if isinstance(raw, list) else [x for x in str(raw).replace(";", ",").split(",") if x.strip()]
        rr = sorted({max(0.5, min(10.0, float(x))) for x in raw})[:6] or [2.0]
        n = max(1, min(int(req.get("coins") or 20), 2000))   # 2000 = praktis semua koin USDT perpetual
        top = max(1, min(int(req.get("top") or 10), 50))
        min_wr = max(0.0, min(100.0, float(req.get("min_wr") or 0)))
    except (TypeError, ValueError):
        raise HTTPException(400, "angka tidak valid (RR mis. 1, 1.5, 2, 3)")
    side = str(req.get("side") or "BOTH").upper()
    sides = ("BUY",) if side == "BUY" else ("SELL",) if side == "SELL" else ("BUY", "SELL")
    min_usdt = max(1000.0, float(req.get("min_usdt") or 50_000))
    syms = [str(x).upper() for x in (req.get("symbols") or []) if str(x).strip()]
    def work(prog):
        from . import results_store as RS
        r = scan_setups(whales.c, n, rr, sides, top, min_usdt, prog, syms or None, min_wr, only_aligned=bool(req.get("only_aligned")))
        from . import whale_cfg as WC
        cfg = WC.get()
        for s_ in r.get("setups", []):
            if s_.get("usable"):
                mb = int(cfg["bt.max_bars_1h"] if s_.get("bt_tf") == "1h" else cfg["bt.max_bars_15m"])
                _journal_add(lambda J, s_=s_, mb=mb: J.from_whale(s_, int(cfg["fill.window"]), mb))
        try:                                                    # hasil scan disimpan supaya bisa dibuka lagi
            r["saved_id"] = RS.save("whsetups", _clean(r), {"rr": rr, "side": side, "coins": n, "symbols": syms, "min_usdt": min_usdt,
                                                            "min_wr": min_wr, "top": top, "only_aligned": bool(req.get("only_aligned"))}, symbols=syms or n)
        except Exception:                                       # noqa: BLE001
            pass
        return r
    return _bg_scan(work)


@app.post("/api/screener/start")
def screener_start(req: dict):
    import threading as _th
    jid = uuid.uuid4().hex[:10]
    job = {"id": jid, "status": "running", "done": 0, "total": 0, "recent": [], "started": time.time(), "result": None,
           "error": None, "times": []}
    for old in [k for k, v in _scan_jobs.items() if v["status"] != "running"][:-3]:
        del _scan_jobs[old]
    _scan_jobs[jid] = job

    def prog(k, n, sym, err):
        job["done"], job["total"] = k, n
        job["times"].append(time.time())
        job["recent"] = ([{"symbol": sym, "error": bool(err)}] + job["recent"])[:8]

    def run():
        try:
            job["result"] = _clean(screener.scan(req.get("tf", "1h"), req.get("filters") or [], req.get("columns") or [],
                                                 bool(req.get("closed_only")), req.get("structure"), req.get("limit"), prog))
            job["status"] = "done"
        except BinanceError as ex:
            job["status"], job["error"] = "error", str(ex)
        except (ValueError, KeyError, TypeError) as ex:
            job["status"], job["error"] = "error", f"Filter tidak valid: {ex}"
        except Exception as ex:   # noqa: BLE001
            job["status"], job["error"] = "error", f"{type(ex).__name__}: {ex}"
    _th.Thread(target=run, daemon=True).start()
    return {"id": jid}


@app.get("/api/screener/job/{jid}")
def screener_job(jid: str):
    job = _scan_jobs.get(jid)
    if not job:
        raise HTTPException(404, "scan tidak ditemukan")
    t, left = job["times"], job["total"] - job["done"]
    eta = None
    if len(t) >= 5 and left > 0:
        k = min(len(t) - 1, 30)
        eta = left * (t[-1] - t[-1 - k]) / k
    return JSONResponse({"id": jid, "status": job["status"], "done": job["done"], "total": job["total"],
                         "recent": job["recent"], "elapsed": round(time.time() - job["started"], 1), "eta": eta,
                         "error": job["error"], "result": job["result"] if job["status"] == "done" else None,
                         "partial": _clean(job.get("partial")) if job["status"] == "running" else None,
                         "binance": screener.c.status() if job["status"] == "running" else None,     # menunggu batas / diblokir / koneksi
                         "running_jobs": sum(1 for v in _scan_jobs.values() if v["status"] == "running")})


@app.websocket("/ws/replay")
async def ws_replay(ws: WebSocket):
    if not _pin_ok(ws.client.host if ws.client else "", ws.cookies, ws.query_params):
        await ws.close(code=4401)
        return
    await ws.accept()
    session = ReplaySession(store)
    try:
        while True:
            msg = json.loads(await ws.receive_text())
            try:
                out = session.handle(msg)
            except Exception as ex:
                out = {"type": "error", "msg": f"{type(ex).__name__}: {ex}"}
            out["req_id"] = msg.get("req_id")
            await ws.send_text(json.dumps(_clean(out)))
    except WebSocketDisconnect:
        pass
