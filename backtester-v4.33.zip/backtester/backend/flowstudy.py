"""🧭 Flow whale: data "uang besar" yang riwayatnya disediakan Binance (±30 hari) diuji seperti Market Structure.

Sinyal (dihitung di candle yang sudah close, hanya dari data yang SUDAH ada saat itu):
  1. Open Interest + harga (W candle terakhir): harga naik + OI naik = posisi long baru, harga naik + OI turun = short
     tutup posisi, harga turun + OI naik = posisi short baru, harga turun + OI turun = long tutup posisi.
  2. Taker buy / sell (dari candle Binance): rata-rata porsi beli agresif W candle terakhir > 50% = pembeli dominan.
  3. Rasio long / short TOP TRADER (posisi): naik / turun dalam W candle terakhir = top trader menambah long / short.
  4. Funding rate terakhir: positif = yang long membayar (pasar ramai long), negatif / nol = yang short membayar.
Hasil yang diukur = sama seperti Market Structure: harga bergerak +2 ATR atau -2 ATR duluan (dalam HORIZON candle).
Pembanding = semua sampel (arah normal). Keunggulan dihitung terpisah di 70% waktu awal & 30% waktu terakhir;
"terbukti" = keunggulan searah dan positif di KEDUA bagian.
"""
import time

import numpy as np

from .indicators import atr as _atr

PERIODS = {"15m": 900_000, "1h": 3_600_000, "4h": 14_400_000}
DAYS = 30                 # Binance hanya menyimpan ±30 hari data futures/data
W = 4                     # jendela perubahan (candle); sampel diambil tiap W candle supaya tidak tumpang tindih
MOVE_ATR = 2.0
HORIZON = 48              # candle maksimal menunggu +-2 ATR
MIN_N = 30                # sampel minimal supaya baris dinilai
MIN_TEST = 10             # sampel minimal di 30% terakhir


def _hist(c, path, sym, period, t_from, t_to, ts_key="timestamp"):
    """Ambil data futures/data (maks 500 per permintaan) mundur dari t_to sampai t_from."""
    out, end = [], t_to
    for _ in range(20):
        rows = c.get(path, symbol=sym, period=period, limit=500, endTime=int(end))
        if not rows:
            break
        rows = [r for r in rows if int(r[ts_key]) <= end]
        if not rows:
            break
        out = rows + out
        first = int(rows[0][ts_key])
        if first <= t_from or len(rows) < 500:
            break
        end = first - 1
    seen, uniq = set(), []
    for r in out:
        k = int(r[ts_key])
        if k not in seen and k >= t_from:
            seen.add(k)
            uniq.append(r)
    return sorted(uniq, key=lambda r: int(r[ts_key]))


def _asof(ts, vals, t):
    """Nilai terakhir yang SUDAH diketahui pada waktu t (array t) -> nan kalau belum ada."""
    if not len(ts):
        return np.full(len(t), np.nan)
    i = np.searchsorted(ts, t, side="right") - 1
    out = np.where(i >= 0, vals[np.clip(i, 0, None)], np.nan)
    return out.astype(float)


def coin_flow(c, sym, period="1h"):
    """Data & sinyal 1 koin. Hasil dict array per candle (sudah close) + nilai sekarang."""
    ms = PERIODS[period]
    k = c.get("/fapi/v1/klines", symbol=sym, interval=period, limit=1000)
    now = time.time() * 1000
    k = [r for r in k if int(r[6]) < now]                         # hanya candle yang sudah close
    if len(k) < 100:
        raise ValueError(f"{sym}: candle {period} terlalu sedikit")
    t = np.array([int(r[0]) for r in k], np.int64)
    o, h, l, cl, v = (np.array([float(r[i]) for r in k]) for i in (1, 2, 3, 4, 5))
    tb = np.array([float(r[9]) for r in k])
    close_t = t + ms                                              # data dianggap diketahui saat candle close
    t_to, t_from = int(close_t[-1]), int(close_t[-1] - DAYS * 86_400_000)
    oi = _hist(c, "/futures/data/openInterestHist", sym, period, t_from, t_to)
    ls = _hist(c, "/futures/data/topLongShortPositionRatio", sym, period, t_from, t_to)
    fr = c.get("/fapi/v1/fundingRate", symbol=sym, startTime=t_from - 86_400_000, endTime=t_to, limit=1000) or []
    oi_v = _asof(np.array([int(r["timestamp"]) for r in oi], np.int64), np.array([float(r["sumOpenInterest"]) for r in oi]), close_t)
    ls_v = _asof(np.array([int(r["timestamp"]) for r in ls], np.int64), np.array([float(r["longShortRatio"]) for r in ls]), close_t)
    fr_v = _asof(np.array([int(r["fundingTime"]) for r in fr], np.int64), np.array([float(r["fundingRate"]) for r in fr]), close_t)
    with np.errstate(invalid="ignore", divide="ignore"):
        taker = np.where(v > 0, tb / v, np.nan)
    a = _atr(h, l, cl, 14)
    return {"symbol": sym, "t": t, "o": o, "h": h, "l": l, "c": cl, "a": a, "oi": oi_v, "ls": ls_v, "fr": fr_v, "taker": taker,
            "n_oi": len(oi), "n_ls": len(ls), "n_fr": len(fr)}


def _states(D, i):
    """Keadaan 4 sinyal di candle i (pakai W candle terakhir). None kalau datanya belum ada."""
    if i < W:
        return None
    c, oi, ls, fr, tk = D["c"], D["oi"], D["ls"], D["fr"], D["taker"]
    st = {}
    dp = c[i] / c[i - W] - 1
    if oi[i] == oi[i] and oi[i - W] == oi[i - W] and oi[i - W] > 0:
        doi = oi[i] / oi[i - W] - 1
        st["oi"] = ("harga naik + OI naik (long baru masuk)" if dp > 0 and doi > 0 else
                    "harga naik + OI turun (short tutup posisi)" if dp > 0 else
                    "harga turun + OI naik (short baru masuk)" if doi > 0 else
                    "harga turun + OI turun (long tutup posisi)")
    tw = tk[i - W + 1:i + 1]
    if np.isfinite(tw).all():
        st["taker"] = "pembeli agresif dominan" if tw.mean() > 0.5 else "penjual agresif dominan"
    if ls[i] == ls[i] and ls[i - W] == ls[i - W]:
        st["ls"] = "top trader menambah long" if ls[i] > ls[i - W] else "top trader menambah short"
    if fr[i] == fr[i]:
        st["fr"] = "funding positif (ramai long)" if fr[i] > 0 else "funding negatif/nol (ramai short)"
    return st


def _first_move(D, i):
    a = D["a"][i]
    if not (a == a) or a <= 0:
        return 0
    c0, h, l = D["c"][i], D["h"], D["l"]
    e = min(len(h), i + 1 + HORIZON)
    if i + 1 + HORIZON > len(h):
        return None                                               # masa depan belum cukup
    up = np.flatnonzero(h[i + 1:e] >= c0 + MOVE_ATR * a)
    dn = np.flatnonzero(l[i + 1:e] <= c0 - MOVE_ATR * a)
    iu, idn = (int(up[0]) if len(up) else None), (int(dn[0]) if len(dn) else None)
    if iu is None and idn is None:
        return 0
    if idn is None or (iu is not None and iu < idn):
        return 1
    if iu is None or idn < iu:
        return -1
    return 0


NAMES = {"oi": "Open Interest + harga", "taker": "Taker buy / sell", "ls": "Long/short top trader", "fr": "Funding rate"}


def study(c, symbol, period="1h", symbols=None, progress=None):
    """symbols = koin pembanding (riwayat digabung). Sinyal sekarang dibaca dari `symbol`."""
    if period not in PERIODS:
        raise ValueError("TF tidak dikenal (pilih 15m, 1h atau 4h)")
    t0 = time.time()
    pool = list(dict.fromkeys([symbol] + list(symbols or [])))
    data, errors = {}, []
    for j, s in enumerate(pool):
        if progress:
            progress(j, len(pool), s, None)
        try:
            data[s] = coin_flow(c, s, period)
        except Exception as ex:                                    # noqa: BLE001 - koin gagal dilewati, dilaporkan
            if s == symbol:
                raise
            errors.append(f"{s}: {ex}")
    if progress:
        progress(len(pool), len(pool), symbol, None)
    return _analyze(data, symbol, period, errors, t0)


def _samples(data):
    """Sampel riwayat: tiap W candle (tidak tumpang tindih), hanya yang hasilnya sudah diketahui."""
    S = []
    for s, D in data.items():
        for i in range(W, len(D["c"]), W):
            fm = _first_move(D, i)
            if fm is None:
                continue
            st = _states(D, i)
            if st:
                S.append((int(D["t"][i]), fm, st))
    return S


def _pct(rows):
    m = [x[1] for x in rows if x[1]]
    up = sum(1 for x in m if x == 1)
    return (100 * up / len(m), 100 * (len(m) - up) / len(m), len(m)) if m else (None, None, 0)


def _analyze(data, symbol, period, errors, t0):
    D0 = data[symbol]
    now = _states(D0, len(D0["c"]) - 1) or {}
    S = _samples(data)
    if not S:
        raise ValueError("data flow belum cukup untuk diuji")
    times = np.array([x[0] for x in S], float)
    t_split = float(np.quantile(times, 0.7))

    pct = _pct
    fit_all = [x for x in S if x[0] < t_split]
    tst_all = [x for x in S if x[0] >= t_split]
    bu, bd, bn = pct(S)
    bfu, _, _ = pct(fit_all)
    btu, _, _ = pct(tst_all)
    rows = []
    combos = [(k,) for k in ("oi", "taker", "ls", "fr")] + [("oi", "taker"), ("oi", "taker", "ls", "fr")]
    for keys in combos:
        if not all(k in now for k in keys):
            continue
        sub = [x for x in S if all(x[2].get(k) == now[k] for k in keys)]
        up, dn, n = pct(sub)
        if not n:
            continue
        maj_up = up >= 50
        edge = (up - bu) if maj_up else (dn - bd)
        p0 = bu / 100
        z = abs(up / 100 - p0) / max(1e-9, (p0 * (1 - p0) / n) ** 0.5)
        fu, _, nf = pct([x for x in sub if x[0] < t_split])
        tu, _, nt = pct([x for x in sub if x[0] >= t_split])
        ef = None if fu is None or bfu is None else ((fu - bfu) if maj_up else (bfu - fu))
        et = None if tu is None or btu is None else ((tu - btu) if maj_up else (btu - tu))
        proven = bool(n >= MIN_N and nt >= MIN_TEST and ef is not None and et is not None and ef > 0 and et > 0)
        rows.append({"keys": list(keys), "name": " + ".join(NAMES[k] for k in keys) if len(keys) < 4 else "Semua sinyal sama",
                     "state": " · ".join(now[k] for k in keys), "n": n, "pct_up": up, "pct_down": dn, "dir": 1 if maj_up else -1,
                     "edge": edge, "z": float(z), "edge_fit": ef, "edge_test": et, "n_test": nt, "proven": proven,
                     "edge_txt": "meyakinkan" if z >= 2 and edge > 0 else "lemah" if z >= 1 and edge > 0 else "bisa kebetulan"})
    good = [r for r in rows if r["proven"] and r["edge"] > 0]
    conflict = len({r["dir"] for r in good}) > 1                     # sinyal terbukti tapi arahnya berlawanan
    best = None if conflict or not good else max(good, key=lambda r: (r["edge_test"], r["edge"]))
    cur = {}
    i = len(D0["c"]) - 1
    if D0["oi"][i] == D0["oi"][i] and D0["oi"][i - W] == D0["oi"][i - W] and D0["oi"][i - W] > 0:
        cur["oi_chg"] = float(100 * (D0["oi"][i] / D0["oi"][i - W] - 1))
    cur["price_chg"] = float(100 * (D0["c"][i] / D0["c"][i - W] - 1))
    tw = D0["taker"][i - W + 1:i + 1]
    if np.isfinite(tw).all():
        cur["taker_buy"] = float(100 * tw.mean())
    if D0["ls"][i] == D0["ls"][i]:
        cur["ls"] = float(D0["ls"][i])
        if D0["ls"][i - W] == D0["ls"][i - W]:
            cur["ls_prev"] = float(D0["ls"][i - W])
    if D0["fr"][i] == D0["fr"][i]:
        cur["funding"] = float(100 * D0["fr"][i])
    n0 = len(D0["c"])
    candles = [[int(D0["t"][j]), float(D0["o"][j]), float(D0["h"][j]), float(D0["l"][j]), float(D0["c"][j])]
               for j in range(max(0, n0 - 150), n0)]
    return {"symbol": symbol, "tf": period, "window": W, "horizon": HORIZON, "move_atr": MOVE_ATR, "days": DAYS,
            "coins": list(data), "n_coins": len(data), "errors": errors[:10], "n_samples": len(S),
            "base": {"pct_up": bu, "pct_down": bd, "n": bn}, "now": now, "current": cur, "rows": rows, "best": best,
            "conflict": conflict,
            "now_time": int(D0["t"][-1] + PERIODS[period]), "now_price": float(D0["c"][-1]), "candles": candles,
            "elapsed": round(time.time() - t0, 1)}


# ---------------------------------------------------------------- gabung ke 🎯 Cari setup: info + uji searah / melawan
FEATS = ("oi", "taker", "ls", "fr")
MIN_GAP = 5.0             # WR searah harus >= WR melawan + 5 poin (di data uji DAN data cari) supaya "terbukti membantu"


def _vote_table(S, t_split):
    """Cara membaca flow dipelajari dari 70% WAKTU AWAL saja: tiap (sinyal, keadaan) -> arah mayoritas kalau unggul
    dari normal (>= MIN_N sampel)."""
    fit = [x for x in S if x[0] < t_split]
    bu, bd, _ = _pct(fit)
    if bu is None:
        return {}
    table = {}
    for k in FEATS:
        for v in {x[2][k] for x in fit if k in x[2]}:
            up, dn, n = _pct([x for x in fit if x[2].get(k) == v])
            if n < MIN_N:
                continue
            maj = 1 if up >= 50 else -1
            if ((up - bu) if maj > 0 else (dn - bd)) > 0:
                table[(k, v)] = maj
    return table


def _lean(table, st):
    """Arah condong flow = jumlah suara sinyal yang unggul (+1 naik / -1 turun). 0 = netral."""
    v = sum(table.get((k, x), 0) for k, x in (st or {}).items())
    return (1 if v > 0 else -1 if v < 0 else 0), v


def enrich(c, setups, rows, pool_n=10, progress=None):
    """A) tiap setup diberi info flow sekarang (searah / melawan / netral) + kesimpulan flow koin itu.
    B) uji: trade backtest setup yang waktunya punya data flow dibagi searah / melawan / netral; WR dibandingkan
       di 30% waktu terakhir (data uji) dan 70% awal (data cari). rows = semua hasil coin_setups (punya `_det`)."""
    det = {(r["symbol"], r["side"], r["rr"], r["how"]): r.get("_det") or [] for r in rows}
    groups = {}
    for s_ in setups:
        groups.setdefault(s_.get("bt_tf") if s_.get("bt_tf") in PERIODS else "1h", []).append(s_)
    top = []
    if pool_n:
        try:
            tick = c.get("/fapi/v1/ticker/24hr")
            top = [t["symbol"] for t in sorted(tick, key=lambda t: -float(t.get("quoteVolume") or 0)) if t["symbol"].endswith("USDT")]
        except Exception:                                          # noqa: BLE001 - tanpa pembanding tetap jalan
            top = []
    acc = {p: {k: [0, 0] for k in ("agree", "against", "neutral")} for p in ("fit", "test")}
    n_done, n_all = 0, sum(len(v) for v in groups.values())
    for period, lst in groups.items():
        syms = list(dict.fromkeys(x["symbol"] for x in lst))
        pool = syms + [x for x in top if x not in syms][:pool_n]
        data = {}
        for s_ in pool:
            try:
                data[s_] = coin_flow(c, s_, period)
            except Exception:                                      # noqa: BLE001 - koin gagal dilewati
                continue
        S = _samples(data)
        if not S:
            for x in lst:
                x["flow"] = None
            continue
        t_split = float(np.quantile([x[0] for x in S], 0.7))
        table = _vote_table(S, t_split)
        verdicts = {}
        for x in lst:
            n_done += 1
            if progress:
                progress(n_done, n_all, x["symbol"], None)
            D = data.get(x["symbol"])
            if D is None:
                x["flow"] = None
                continue
            side = 1 if x["side"] == "BUY" else -1
            lean, votes = _lean(table, _states(D, len(D["c"]) - 1))
            if x["symbol"] not in verdicts:
                try:
                    a = _analyze(data, x["symbol"], period, [], time.time())
                    verdicts[x["symbol"]] = {"best": a["best"] and {k: a["best"][k] for k in ("name", "dir", "edge", "edge_txt", "pct_up", "pct_down")},
                                             "conflict": a["conflict"], "now": a["now"], "current": a["current"]}
                except ValueError:
                    verdicts[x["symbol"]] = None
            v = verdicts[x["symbol"]]
            st = {"lean": lean, "votes": votes, "agree": "agree" if lean == side else "against" if lean == -side else "neutral",
                  "tf": period, "verdict": v}
            # uji per setup: trade backtest pada waktu yang punya data flow
            per = {p: {k: [0, 0] for k in ("agree", "against", "neutral")} for p in ("fit", "test")}
            ts = D["t"]
            for t_, res in det.get((x["symbol"], x["side"], x["rr"], x["how"]), []):
                i = int(np.searchsorted(ts, t_))
                if i >= len(ts) or ts[i] != t_ or i < W:
                    continue
                s2 = _states(D, i)
                if not s2:
                    continue
                l2, _ = _lean(table, s2)
                cls = "agree" if l2 == side else "against" if l2 == -side else "neutral"
                part = "test" if t_ >= t_split else "fit"
                for box in (per, acc):
                    box[part][cls][0] += 1
                    box[part][cls][1] += res == 1
            st["test"] = _wr(per)
            x["flow"] = st
    return {"overall": _wr(acc), "pool": pool_n}


def _wr(acc):
    """{fit|test: {agree|against|neutral: {n, wr}}} + kesimpulan: terbukti membantu kalau WR searah >= melawan + 5
    poin di data cari DAN data uji (masing-masing >= 30 trade)."""
    out = {p: {k: {"n": v[0], "wr": (100 * v[1] / v[0]) if v[0] else None} for k, v in acc[p].items()} for p in acc}

    def gap(p):
        a, b = out[p]["agree"], out[p]["against"]
        if a["n"] < 30 or b["n"] < 30:
            return None
        return a["wr"] - b["wr"]
    gf, gt = gap("fit"), gap("test")
    out["gap_fit"], out["gap_test"] = gf, gt
    out["helps"] = bool(gf is not None and gt is not None and gf >= MIN_GAP and gt >= MIN_GAP)
    out["verdict"] = ("terbukti membantu" if out["helps"] else "belum cukup data" if gf is None or gt is None
                      else "tidak terbukti membantu")
    return out
