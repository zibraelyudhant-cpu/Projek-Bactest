"""Paket backend Futures Replay.

Numpy (OpenBLAS / MKL) secara default membuat thread sebanyak jumlah core di SETIAP proses dan memesan memori
untuk tiap thread. Backtest & studi semua koin menjalankan banyak proses sekaligus, jadi di PC dengan banyak core
memori bisa habis ("OpenBLAS error: Memory allocation still failed"). Hitungan di aplikasi ini tidak butuh BLAS
multi-thread, jadi dibatasi 1 thread per proses. Harus diset SEBELUM numpy di-import (proses anak ikut mewarisi).
"""
import os

for _k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ.setdefault(_k, "1")
