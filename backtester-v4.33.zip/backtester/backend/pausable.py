"""Mesin proses berat yang bisa DIJEDA dan DILANJUTKAN (dipakai backtest semua koin, Studi Fibonacci v1/v2, dan
'cari angka fibo terbaik').

Cara kerja:
- Tugas (biasanya satu koin) dikirim ke proses paralel sedikit demi sedikit (maks. 2 x jumlah proses), bukan sekaligus.
- Jeda: tidak ada tugas baru yang dikirim; koin yang sedang dihitung diselesaikan dulu (tidak ada hasil yang hilang),
  lalu proses paralel ditutup (CPU & RAM dilepas) dan keadaan job disimpan ke disk.
- Lanjutkan: hanya tugas yang BELUM selesai yang dikerjakan; hasil yang sudah ada dipakai lagi. Karena disimpan ke disk,
  job yang dijeda tetap bisa dilanjutkan walaupun aplikasi ditutup lalu dibuka lagi.
"""
import multiprocessing
import os
import pickle
import threading
import time
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait

_SKIP = {"pool", "thread_alive"}           # tidak disimpan ke disk


class PausableJobs:
    KIND = "job"

    def __init__(self, paused_dir=None):
        self.jobs = {}
        self.lock = threading.Lock()
        self.paused_dir = paused_dir
        self._load_paused()

    # ---- diisi kelas turunan
    def pool_init(self):
        """(initializer, initargs) untuk proses paralel."""
        raise NotImplementedError

    def task_call(self, job, i):
        """(fungsi, argumen) untuk tugas ke-i (fungsi harus bisa di-pickle: fungsi tingkat modul)."""
        raise NotImplementedError

    def on_result(self, job, i, res):
        """Gabungkan hasil tugas ke-i ke job (dipanggil dengan self.lock terkunci)."""
        raise NotImplementedError

    def on_error(self, job, i, ex):
        return None

    def ready(self, job, i):
        """Boleh mengirim tugas ke-i sekarang? (mis. tahap 2 menunggu semua tahap 1 selesai)."""
        return True

    def finish(self, job):
        """Ringkasan akhir setelah semua tugas selesai."""

    # ---- umum
    def _new(self, jid, total, workers, **extra):
        now = time.time()
        job = {"id": jid, "kind": self.KIND, "status": "running", "total": total, "done": 0, "workers": workers,
               "pending": list(range(total)), "inflight": 0, "started": now, "run_since": now, "active": 0.0,
               "pool": None, "thread_alive": False, **extra}
        with self.lock:
            for old in [k for k, v in self.jobs.items() if v["status"] in ("done", "cancelled", "error")][:-4]:
                del self.jobs[old]
            self.jobs[jid] = job
        return job

    def _launch(self, job):
        job["thread_alive"] = True
        threading.Thread(target=self._thread, args=(job,), daemon=True).start()

    def elapsed(self, job):
        return job["active"] + (time.time() - job["run_since"] if job["status"] == "running" else 0.0)

    def _thread(self, job):
        try:
            outcome = self._run_tasks(job)
            if outcome == "paused":
                return
            if outcome == "done":
                self.finish(job)
                if job["status"] in ("running", "paused"):   # dijeda tepat saat koin terakhir: tetap selesai
                    if job["status"] == "running":
                        job["active"] = self.elapsed(job)
                    job["status"] = "done"
        except Exception as ex:   # noqa: BLE001
            from .multi import friendly_error
            job["status"], job["error"] = "error", friendly_error(ex)
        finally:
            job["pool"] = None
            if job["status"] != "paused":
                job["finished"] = time.time()
                job["thread_alive"] = False
                self._drop_file(job)

    def _run_tasks(self, job):
        init, initargs = self.pool_init()
        queue = list(job["pending"])
        inflight = {}
        with ProcessPoolExecutor(job["workers"], mp_context=multiprocessing.get_context("spawn"),
                                 initializer=init, initargs=initargs) as pool:
            job["pool"] = pool
            while True:
                if job["status"] == "cancelled":
                    pool.shutdown(wait=False, cancel_futures=True)
                    return "cancelled"
                while job["status"] == "running" and queue and len(inflight) < 2 * job["workers"] and self.ready(job, queue[0]):
                    i = queue.pop(0)
                    fn, args = self.task_call(job, i)
                    inflight[pool.submit(fn, *args)] = i
                job["inflight"] = len(inflight)
                if not inflight:
                    with self.lock:
                        if not job["pending"]:
                            return "done"
                        if job["status"] == "paused":       # semua koin yang sedang jalan sudah selesai
                            job["thread_alive"] = False
                            job["pool"] = None
                            self._save(job)
                            return "paused"
                        if job["status"] == "running" and not queue:   # dilanjutkan saat sedang menjeda
                            queue = list(job["pending"])
                    continue
                done, _ = wait(list(inflight), timeout=0.5, return_when=FIRST_COMPLETED)
                for f in done:
                    i = inflight.pop(f)
                    try:
                        res = f.result()
                    except Exception as ex:   # noqa: BLE001
                        res = self.on_error(job, i, ex)
                    with self.lock:
                        if res is not None:
                            self.on_result(job, i, res)
                        if i in job["pending"]:
                            job["pending"].remove(i)
                        job["done"] = job["total"] - len(job["pending"])
                job["inflight"] = len(inflight)

    def pause(self, jid):
        job = self.jobs.get(jid)
        with self.lock:
            if job and job["status"] == "running":
                job["status"] = "paused"
                job["active"] += time.time() - job["run_since"]
                job["paused_at"] = time.time()
                return True
        return False

    def resume(self, jid):
        job = self.jobs.get(jid)
        with self.lock:
            if not job or job["status"] != "paused":
                return False
            job["status"] = "running"
            job["run_since"] = time.time()
            job["times"] = []                                   # kecepatan dihitung ulang setelah jeda
            alive = job["thread_alive"]
        if not alive:
            self._launch(job)
        return True

    def cancel(self, jid):
        job = self.jobs.get(jid)
        if not job or job["status"] not in ("running", "paused"):
            return
        was_alive = job["thread_alive"]
        job["status"] = "cancelled"
        if job.get("pool"):
            job["pool"].shutdown(wait=False, cancel_futures=True)
        if not was_alive:                                       # dijeda (tidak ada thread): langsung buang
            self._drop_file(job)

    def running(self):
        """Job yang sedang memakai CPU (berjalan, atau sedang menyelesaikan koin terakhir sebelum jeda)."""
        return next((j for j in self.jobs.values() if j["status"] == "running" or
                     (j["status"] == "paused" and j["thread_alive"])), None)

    def paused(self):
        return [j for j in self.jobs.values() if j["status"] == "paused"]

    # ---- simpan / muat jeda
    def _path(self, job):
        return os.path.join(self.paused_dir, f"{self.KIND}_{job['id']}.pkl") if self.paused_dir else None

    def _save(self, job):
        p = self._path(job)
        if not p:
            return
        os.makedirs(self.paused_dir, exist_ok=True)
        with open(p + ".tmp", "wb") as f:
            pickle.dump({k: v for k, v in job.items() if k not in _SKIP}, f)
        os.replace(p + ".tmp", p)

    def _drop_file(self, job):
        p = self._path(job)
        if p and os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass

    def _load_paused(self):
        if not self.paused_dir or not os.path.isdir(self.paused_dir):
            return
        for fn in sorted(os.listdir(self.paused_dir)):
            if not (fn.startswith(self.KIND + "_") and fn.endswith(".pkl")):
                continue
            try:
                with open(os.path.join(self.paused_dir, fn), "rb") as f:
                    job = pickle.load(f)
            except Exception:   # noqa: BLE001  file rusak: abaikan
                continue
            job.update({"status": "paused", "pool": None, "thread_alive": False, "inflight": 0})
            self.jobs[job["id"]] = job
