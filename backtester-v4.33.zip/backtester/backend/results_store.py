"""Simpan hasil semua menu (Tes SNR, Penemu Strategi, Indikator Tester, Cari setup Whale, ...) supaya bisa dibuka lagi
tanpa menghitung ulang. File: saved/results/<menu>/<id>.json (atau RESULTS_DIR)."""
import json
import os
import threading
import time
import uuid

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = os.environ.get("RESULTS_DIR", os.path.join(ROOT, "saved", "results"))
KINDS = {"snrtest": "📍 Tes SNR", "stratlab": "🧠 Penemu Strategi", "indtester": "🧪 Indikator Tester", "whsetups": "🎯 Cari setup Whale",
         "msa": "📐 Analisa Market Structure", "sweeplab": "💧 Liquidity Sweep (TA Pro)",
         "slbt": "🛡️ SL Backtest", "maa": "📈 Moving Average Analisis", "arb": "🧭 Penentu Arah"}
_lock = threading.Lock()


def _dir(kind):
    if kind not in KINDS:
        raise ValueError("menu tidak dikenal")
    return os.path.join(BASE, kind)


def save(kind, result, params=None, label=None, symbols=None):
    d = _dir(kind)
    os.makedirs(d, exist_ok=True)
    rid = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    item = {"id": rid, "kind": kind, "time": int(time.time() * 1000), "label": label or "", "params": params or {},
            "symbols": len(symbols) if isinstance(symbols, (list, tuple)) else symbols, "result": result}
    with _lock:
        tmp = os.path.join(d, rid + ".json.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(item, f, default=lambda o: o.item() if hasattr(o, "item") else str(o))
        os.replace(tmp, os.path.join(d, rid + ".json"))
    return rid


def listing(kind):
    d = _dir(kind)
    out = []
    if not os.path.isdir(d):
        return out
    for fn in sorted(os.listdir(d), reverse=True):
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(d, fn), encoding="utf-8") as f:
                it = json.load(f)
        except (OSError, ValueError):
            continue
        out.append({k: it.get(k) for k in ("id", "kind", "time", "label", "params", "symbols")})
    return out


def get(kind, rid):
    p = os.path.join(_dir(kind), os.path.basename(rid) + ".json")
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def rename(kind, rid, label):
    with _lock:
        it = get(kind, rid)
        it["label"] = str(label)[:120]
        p = os.path.join(_dir(kind), os.path.basename(rid) + ".json")
        with open(p + ".tmp", "w", encoding="utf-8") as f:
            json.dump(it, f)
        os.replace(p + ".tmp", p)
    return it


def delete(kind, rid):
    p = os.path.join(_dir(kind), os.path.basename(rid) + ".json")
    if os.path.exists(p):
        os.remove(p)
