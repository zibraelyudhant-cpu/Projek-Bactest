"""🛡️ SL anti-gocekan (logika menu 🐋 Whale) untuk menu 📐 Market Structure dan 🧠 TA Pro Advance.

Sama dengan whales.anti_gocek, tapi bisa dihitung di SETIAP candle riwayat tanpa intip masa depan:
- gocekan = swing (fractal swing.fractal) yang ditembus ekor candle lalu close balik dalam gocek.reclaim_bars candle.
  Kedalaman tembus (ATR) baru dipakai setelah gocekannya selesai; persentil gocek.depth_pct dari gocekan dalam
  1000 candle terakhir (sama seperti Whale: 1000 candle) = "pen". Belum ada gocekan = 1.0 ATR (sama dengan Whale).
- SL = swing terdekat (sudah terkonfirmasi, dalam swing.lookback candle) di balik ENTRY ∓ (pen + sl.swing_buf_atr) x ATR.
- (live saja) di balik tembok order book terkuat (asli kalau terlihat >= walls.real_seen scan) ∓ sl.wall_buf_atr1h x ATR H1.
- tidak ada swing / tembok: sl.fallback_atr1h x ATR H1. ATR H1 ≈ 2 x ATR (rumus Whale: akar 4 candle).
- dipilih kandidat TERJAUH; kalau jatuh di zona angka bulat -> digeser melewatinya (0.5 x pen + sl.round_buf ATR).
- maksimal sl.max_pct dari entry: sl.cap_mode "potong" = dipotong, "tolak" = setup dilewati (None).
Semua angka dari pengaturan Whale (⚙️ Threshold), jadi mengubahnya di Whale ikut mengubah SL menu ini.
Bedanya dengan Whale: Whale selalu memakai candle 15M; di sini memakai TF menu itu (jumlah candle sama).
"""
import math

import numpy as np

from . import whale_cfg
from .indicators import atr as _atr, pivots

PEN_WINDOW = 1000          # candle: gocekan yang dihitung (Whale membaca 1000 candle terakhir)
TXT = "anti-gocekan (logika Whale): di luar swing terdekat + kedalaman 90% gocekan, lewati angka bulat, maks 4%"


def _cfg_sig(C):
    keys = ("swing.fractal", "swing.lookback", "swing.atr", "gocek.lookahead", "gocek.reclaim_bars", "gocek.depth_pct",
            "round.max_dist_pct", "sl.swing_buf_atr", "sl.wall_buf_atr1h", "sl.fallback_atr1h", "sl.round_buf", "sl.max_pct",
            "sl.cap_mode", "walls.max_dist_pct", "walls.real_seen")
    return tuple(C[k] for k in keys)


def txt():
    C = whale_cfg.get()
    return (f"anti-gocekan (logika Whale): di luar swing terdekat + kedalaman {C['gocek.depth_pct']:.0f}% gocekan "
            f"+ {C['sl.swing_buf_atr']:g} ATR, lewati angka bulat, maks {C['sl.max_pct']:g}%")


def round_step(price):
    return 5 * 10 ** (math.floor(math.log10(price)) - 2)


class Ctx:
    """Data 1 koin (h, l, c) -> semua bahan SL anti-gocekan, dihitung sekali."""

    def __init__(self, h, l, c):
        C = whale_cfg.get()
        self.C, self.sig = C, _cfg_sig(C)
        self.h, self.l, self.c = (np.asarray(x, float) for x in (h, l, c))
        n = len(self.c)
        self.n = n
        self.k = int(C["swing.fractal"])
        self.a = _atr(self.h, self.l, self.c, int(C["swing.atr"]))
        hi, lo = pivots(self.h, self.l, self.k)
        self.hi, self.lo = np.asarray(hi, int), np.asarray(lo, int)
        # gocekan: (candle diketahui selesai, kedalaman ATR)
        look, rec = int(C["gocek.lookahead"]), int(C["gocek.reclaim_bars"])
        known, pen = [], []
        h_, l_, c_, a_ = self.h, self.l, self.c, self.a
        for idx, is_low in [(int(i), True) for i in self.lo] + [(int(i), False) for i in self.hi]:
            start = idx + self.k + 1
            if start >= n:
                continue
            lvl = l_[idx] if is_low else h_[idx]
            end = min(n, start + look)
            seg = l_[start:end] if is_low else h_[start:end]
            hit = np.flatnonzero(seg < lvl) if is_low else np.flatnonzero(seg > lvl)
            if not len(hit):
                continue
            j = start + int(hit[0])
            w_end = min(n, j + rec)
            win = slice(j, w_end)
            cw = c_[win]
            back = np.flatnonzero(cw > lvl) if is_low else np.flatnonzero(cw < lvl)
            if not len(back) or not (np.isfinite(a_[j]) and a_[j] > 0):
                continue
            jb = j + int(back[0])                              # close balik = gocekan diketahui di candle ini
            deep = (lvl - l_[j:jb + 1].min()) if is_low else (h_[j:jb + 1].max() - lvl)
            known.append(jb)
            pen.append(deep / a_[j])
        o = np.argsort(known, kind="stable")
        self.known = np.asarray(known, int)[o]
        self.pens = np.asarray(pen, float)[o]
        self._pc = {}

    def pen_at(self, s):
        """Kedalaman gocekan (ATR, persentil) dari gocekan yang SUDAH selesai sampai candle s (1000 candle terakhir)."""
        b = s >> 4                                            # disimpan per 16 candle (berubah pelan) supaya cepat
        if b in self._pc:
            return self._pc[b]
        s2 = (b << 4)
        i0 = int(np.searchsorted(self.known, s2 - PEN_WINDOW, "left"))
        i1 = int(np.searchsorted(self.known, s2, "right"))
        seg = self.pens[i0:i1]
        v = float(np.percentile(seg, self.C["gocek.depth_pct"])) if len(seg) else 1.0
        self._pc[b] = v
        return v

    def swing(self, s, long, ref):
        """Swing terdekat di balik ref yang sudah terkonfirmasi pada candle s (dalam swing.lookback candle)."""
        arr = self.lo if long else self.hi
        i0 = int(np.searchsorted(arr, s - int(self.C["swing.lookback"]), "left"))
        i1 = int(np.searchsorted(arr, s - self.k, "right"))
        if i1 <= i0:
            return None
        v = self.l[arr[i0:i1]] if long else self.h[arr[i0:i1]]
        v = v[v < ref] if long else v[v > ref]
        if not len(v):
            return None
        return float(v.max() if long else v.min())


def get_ctx(holder, h, l, c):
    """Ctx yang disimpan di dict / objek data koin (dibuat ulang kalau pengaturan Whale berubah)."""
    C = whale_cfg.get()
    g = holder.get("_ag") if isinstance(holder, dict) else getattr(holder, "_ag", None)
    if g is None or g.sig != _cfg_sig(C) or g.n != len(c):
        g = Ctx(h, l, c)
        if isinstance(holder, dict):
            holder["_ag"] = g
        else:
            holder._ag = g
    return g


def sl_at(g, s, long, ref, walls=None, detail=False):
    """SL anti-gocekan untuk entry `ref` yang diketahui di candle s. walls = tembok order book live (opsional).
    Hasil: harga SL (atau dict kalau detail), None kalau tidak bisa / ditolak (sl.cap_mode = tolak)."""
    C = g.C
    a = g.a[s] if 0 <= s < g.n else np.nan
    if not (np.isfinite(a) and a > 0 and ref > 0):
        return None
    a = float(a)
    a1h = 2 * a
    pen = g.pen_at(s)
    reasons, cands = [], []
    sw = g.swing(s, long, ref)
    if sw is not None:
        b = pen + C["sl.swing_buf_atr"]
        cands.append(sw - b * a if long else sw + b * a)
        if detail:
            reasons.append(f"di luar swing {'low' if long else 'high'} {sw:.6g} + {pen:.2f} ATR ({C['gocek.depth_pct']:.0f}% gocekan tidak sedalam ini)")
    if walls:
        side = [w for w in walls if w["side"] == ("BUY" if long else "SELL") and ((w["price"] < ref) if long else (w["price"] > ref))
                and abs(w["price"] / ref - 1) <= C["walls.max_dist_pct"] / 100]
        real = [w for w in side if w.get("seen", 1) >= C["walls.real_seen"]] or side
        if real:
            w = max(real, key=lambda w: w["usdt"])
            wb = C["sl.wall_buf_atr1h"] * a1h
            cands.append(w["price"] - wb if long else w["price"] + wb)
            if detail:
                asli = w.get("seen", 1) >= C["walls.real_seen"]
                reasons.append(f"di balik tembok {'BELI' if long else 'JUAL'} {w['price']:.6g} "
                               f"({'asli, terlihat ' + str(w.get('seen', 1)) + 'x' if asli else 'belum terbukti asli'})")
    if not cands:
        fb = C["sl.fallback_atr1h"]
        cands.append(ref - fb * a1h if long else ref + fb * a1h)
        if detail:
            reasons.append(f"{fb:g} ATR H1 (≈ {2 * fb:g} ATR; tidak ada swing{' / tembok' if walls is not None else ''} dekat)")
    sl = min(cands) if long else max(cands)
    step = round_step(ref)
    rn = math.floor(ref / step) * step if long else math.ceil(ref / step) * step
    if abs(rn / ref - 1) <= C["round.max_dist_pct"] / 100 and rn != ref and (
            (long and rn - 0.5 * pen * a <= sl <= rn) or (not long and rn <= sl <= rn + 0.5 * pen * a)):
        rb = 0.5 * pen + C["sl.round_buf"]
        sl = rn - rb * a if long else rn + rb * a
        if detail:
            reasons.append(f"digeser melewati angka bulat {rn:.6g}")
    mx = C["sl.max_pct"]
    lim = ref * (1 - mx / 100 if long else 1 + mx / 100)
    capped = (long and sl < lim) or (not long and sl > lim)
    raw = float(sl)
    if capped:
        if C["sl.cap_mode"] == "tolak":
            return None
        sl = lim
        if detail:
            reasons.append(f"dibatasi maksimal {mx:g}% dari entry")
    sl = float(sl)
    if (long and sl >= ref) or (not long and sl <= ref):
        return None
    if detail:
        return {"sl": sl, "raw": raw, "pct": (sl / ref - 1) * 100, "reasons": reasons, "capped": bool(capped), "pen_atr": pen,
                "walls": walls is not None}
    return sl


def live_walls(c, sym, min_usdt=50_000):
    """Tembok order book live (seperti Whale; seen dari scan sebelumnya). [] kalau gagal."""
    from . import whales as W
    try:
        d = c.get("/fapi/v1/depth", symbol=sym, limit=int(whale_cfg.get()["walls.depth"]))
        bids = [(float(p), float(q)) for p, q in d["bids"]]
        asks = [(float(p), float(q)) for p, q in d["asks"]]
        if not bids or not asks:
            return []
        walls = W.analyse_book(sym, bids, asks, min_usdt)
        W.track_walls(sym, (bids[0][0] + asks[0][0]) / 2, walls)
        return walls
    except Exception:                                          # noqa: BLE001 - tanpa order book: SL tanpa tembok
        return None
