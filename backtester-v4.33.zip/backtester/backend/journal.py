"""📒 Jurnal sinyal (forward test): setiap sinyal LAYAK dicatat otomatis lalu dipantau dengan candle Binance sungguhan
sampai terisi / batal, lalu kena TP / SL / waktu habis — aturan sama dengan backtest-nya. Hasil live dibandingkan
dengan janji backtest (WR & R per sinyal).

Aturan pantau (sama dengan backtest):
- market: terisi di candle pertama sesudah sinyal; limit: terisi kalau harga menyentuh entry dalam batas tunggu, BATAL
  kalau tidak tersentuh atau (Market Structure) harga lebih dulu menembus ujung leg (`cancel_at`).
- sesudah terisi: candle terisi ikut dicek SL (limit); TP mulai candle berikutnya; TP & SL di candle sama = SL.
- lewat batas lama trade = ditutup di close (R dibatasi -1 .. RR).
"""
import json
import os
import threading
import time
import uuid

import numpy as np

from .data import TF_MS

PATH = os.environ.get("JOURNAL_FILE") or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "saved", "journal.json")
_LOCK = threading.Lock()
_ST = {"thread": None, "last_update": None, "errors": []}
SOURCES = {"msa": "📐 Market Structure", "whale": "🐋 Whale · Cari setup", "tapro": "🧠 TA Pro Advance", "cpat": "🧩 Chart Pattern / Reversal", "manual": "🧪 Entry kamu (Cek entry)"}
OPEN = ("menunggu", "terisi")


def _load():
    try:
        with open(PATH) as f:
            d = json.load(f)
        return {"auto": d.get("auto", True), "signals": d.get("signals", [])}
    except (OSError, ValueError):
        return {"auto": True, "signals": []}


def _save(d):
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    tmp = PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(d, f)
    os.replace(tmp, PATH)


def set_auto(on):
    with _LOCK:
        d = _load()
        d["auto"] = bool(on)
        _save(d)
    return d["auto"]


def add(sig):
    """Tambah sinyal (dobel = sumber, koin, TF, arah, entry & waktu sinyal sama -> diabaikan). Hasil: True kalau baru."""
    key = (sig["source"], sig["symbol"], sig["tf"], sig["dir"], round(float(sig["entry"]), 10), int(sig["created"]))
    with _LOCK:
        d = _load()
        if sig["source"] != "manual" and not d["auto"]:
            return False
        for x in d["signals"]:
            if (x["source"], x["symbol"], x["tf"], x["dir"], round(float(x["entry"]), 10), int(x["created"])) == key:
                return False
        sig = {"id": uuid.uuid4().hex[:10], "status": "menunggu", "fill_time": None, "exit_time": None, "result_r": None,
               "open_r": None, "last_price": None, **sig}
        d["signals"].append(sig)
        _save(d)
    return True


def delete(ids=None, all_=False):
    with _LOCK:
        d = _load()
        n0 = len(d["signals"])
        d["signals"] = [] if all_ else [x for x in d["signals"] if x["id"] not in set(ids or [])]
        _save(d)
    return n0 - len(d["signals"])


# ---------------------------------------------------------------- dari hasil menu lain
def _trend_htf(r):
    """Tren TF besar yang dipakai Market Structure (struktur swing HH/HL vs LH/LL), untuk info jurnal."""
    F = r.get("filters") or {}
    if not F.get("htf"):
        return None
    now = F.get("htf_now")
    return {"tf": F["htf"], "dir": {"naik": 1, "turun": -1}.get(now, 0), "txt": f"struktur swing {now or 'belum jelas'}"}


def from_msa(r, source="msa"):
    """Sinyal dari Screener Market Structure (hanya rencana LAYAK)."""
    B = r.get("best")
    if not B or not B.get("usable"):
        return None
    tf = r["tf"]
    step = TF_MS[tf]
    created = int(r["now_time"]) + step                         # sinyal diketahui saat candle terakhir close
    mk = B["entry"] == "market"
    from . import stratlab as SL
    return {"source": source, "symbol": r["symbol"], "tf": tf, "dir": int(B["dir"]), "kind": "market" if mk else "limit",
            "entry": float(B["price_entry"]), "sl": float(B["price_sl"]), "tp": float(B["price_tp"]), "rr": float(B["rr"]),
            "created": created, "ref_price": float(r.get("now_price") or B["price_entry"]),
            "wait_until": None if mk else int(B.get("expires") or created + SL.FILL_WAIT * step),
            "hold_ms": int(SL.HOLD * step), "cancel_at": None if mk else B.get("ext"),
            "bt": {"wr": B.get("wr"), "exp_r": B.get("exp_r"), "exp_sig": B.get("exp_sig"), "fill_pct": B.get("fill_pct"),
                   "proven": B.get("proven")},
            "note": f"{B.get('entry_txt', '')} · SL {B.get('sl_txt', '')} · pola {' › '.join(r.get('pattern') or [])}", "trend": _trend_htf(r)}


def from_whale(s, fill_window=96, max_bars=None):
    """Sinyal dari 🎯 Cari setup Whale (hanya setup LAYAK)."""
    if not s.get("usable"):
        return None
    mk = str(s.get("how", "")).startswith("market")
    tf = s.get("bt_tf") or "15m"
    created = int(time.time() * 1000)
    if s.get("t_scan"):
        created = int(s["t_scan"])                              # v4.33 (F): saat harga koin dibaca waktu scan (harga entry market)
    elif s.get("candles"):
        created = int(s["candles"][-1][0]) + TF_MS["15m"]
    hold_bars = max_bars or (120 if tf == "1h" else 192)
    return {"source": "whale", "symbol": s["symbol"], "tf": tf, "dir": 0 if s["side"] == "BUY" else 1, "kind": "market" if mk else "limit",
            "entry": float(s["entry"]), "sl": float(s["sl"]), "tp": float(s["tp"]), "rr": float(s["rr"]), "created": created,
            "ref_price": float(s.get("price") or s["entry"]),
            "wait_until": None if mk else created + int(fill_window) * TF_MS["15m"], "hold_ms": int(hold_bars * TF_MS[tf]),
            "cancel_at": None,
            "bt": {"wr": s.get("wr"), "exp_r": s.get("exp_r"), "exp_sig": (s.get("exp_r") or 0) * (s.get("fill_pct") or 0) / 100,
                   "fill_pct": s.get("fill_pct"), "proven": s.get("proven")},
            "note": f"{s.get('how', '')} · flow " + {"agree": "searah", "against": "melawan", "neutral": "netral"}.get((s.get("flow") or {}).get("agree"), "-"),
            "trend": None if s.get("trend_up") is None else {"tf": s.get("trend_tf") or tf, "dir": 1 if s["trend_up"] else -1,
                                                             "txt": "EMA20 > EMA50" if s["trend_up"] else "EMA20 < EMA50"}}


def from_tapro(sym, p, style, now_ms, trend=None):
    """Sinyal 🧠 TA Pro Advance (keputusan ENTRY). Jurnal memantau TP1 (target pertama); TP2 dicatat di catatan."""
    from .tapro import STYLES
    st = STYLES[style]
    tf = st["tf"]
    created = int(now_ms) + TF_MS[tf]
    mk = p["entry_kind"] == "market"
    S_ = p["stats"]
    return {"source": "tapro", "symbol": sym, "tf": tf, "dir": 0 if p["dir"] == 1 else 1, "kind": "market" if mk else "limit",
            "entry": float(p["price_entry"]), "sl": float(p["price_sl"]), "tp": float(p["price_tp1"]), "rr": 2.0, "created": created,
            "ref_price": float(p["price_entry"]), "wait_until": None if mk else created + st["fill_wait"] * TF_MS[tf],
            "hold_ms": int(st["hold"] * TF_MS[tf]), "cancel_at": None,
            "bt": {"wr": S_.get("wr"), "exp_r": 2 * (S_.get("wr") or 0) / 100 - (1 - (S_.get("wr") or 0) / 100), "exp_sig": None,
                   "fill_pct": S_.get("fill_pct"), "proven": S_.get("ok")},
            "note": f"{p['setup']} · {p['entry_name']} · TP2 {p['price_tp2']:.6g} (1:{p['rr2']:g}) · peluang {p['prob']:.0f}% · kelas {p['class']}",
            "trend": None if trend is None else {"tf": "+".join(x for x in (st["htf"], st["d1"]) if x), "dir": int(trend),
                                                 "txt": "close > EMA50 > EMA200, EMA50 naik" if trend == 1 else "close < EMA50 < EMA200, EMA50 turun" if trend == -1
                                                 else "TF besar tidak searah / belum jelas"}}


def from_cpat(p, tf):
    """Sinyal 🧩 Chart Pattern / 🔄 Reversal yang VALID & layak (seperti Whale). Batas waktu = 24 jam (TF < 1H) / 2 hari."""
    from .chartpat import window_bars
    mk = p["entry_kind"] == "market"
    created = int(p["break_time"]) + TF_MS[tf]
    w = window_bars(tf) * TF_MS[tf]
    S_ = p.get("stats") or {}
    return {"source": "cpat", "symbol": p["symbol"], "tf": tf, "dir": 0 if p["dir"] == 1 else 1, "kind": "market" if mk else "limit",
            "entry": float(p["price_entry"]), "sl": float(p["price_sl"]), "tp": float(p["price_tp"]), "rr": float(p["rr"] or 0), "created": created,
            "ref_price": float(p["price_entry"]), "wait_until": None if mk else created + w, "hold_ms": int(w), "cancel_at": None,
            "bt": {"wr": S_.get("wr"), "exp_r": S_.get("exp_r"), "exp_sig": S_.get("exp_sig"), "fill_pct": S_.get("fill_pct"), "proven": S_.get("proven")},
            "note": f"{p['name']} · {p['entry_txt']} · TP {p['tp_txt']}", "trend": p.get("trend")}


def from_manual(r):
    """Entry kamu dari 🧪 Cek entry posisi."""
    from . import stratlab as SL
    tf = r["tf"]
    step = TF_MS[tf]
    created = int(r.get("now_time") or time.time() * 1000) + step
    S = r.get("stats") or {}
    filled = bool(r.get("filled"))
    return {"source": "manual", "symbol": r["symbol"], "tf": tf, "dir": int(r["dir"]), "kind": "market" if filled else "limit",
            "entry": float(r["entry"]), "sl": float(r["sl"]), "tp": float(r["tp"]), "rr": float(r["rr"]), "created": created,
            "ref_price": float(r.get("now_price") or r["entry"]),
            "wait_until": None if filled else created + 96 * step, "hold_ms": int(150 * step), "cancel_at": None,
            "bt": {"wr": S.get("wr"), "exp_r": S.get("exp_r"), "exp_sig": S.get("exp_sig"), "fill_pct": S.get("fill_pct"),
                   "proven": None},
            "note": "posisi sudah masuk" if filled else "limit kamu", "trend": _trend_htf(r)}


# ---------------------------------------------------------------- pantau
def simulate(sig, t, h, l, c, now_ms):
    """Status sinyal dari candle (t = open time, urut) sesudah sinyal. Hasil dict pembaruan."""
    long = sig["dir"] == 0
    e, sl, tp, rr = sig["entry"], sig["sl"], sig["tp"], sig["rr"]
    risk = abs(e - sl) or 1e-12
    step = TF_MS.get(sig["tf"], 900_000) if sig["source"] != "whale" else TF_MS["15m"]
    idx = np.flatnonzero(t + step > sig["created"])          # v4.33 (F): mulai dari candle yang SEDANG berjalan saat sinyal
    upd = {}
    if not len(idx):
        return upd
    i0 = int(idx[0])
    mid = sig["created"] > t[i0]                              # sinyal di tengah candle (Whale: saat scan)
    # 1) terisi?
    if sig["kind"] == "market":
        # entry market di tengah candle: candle itu ikut dicek SL & TP (urutan di dalam candle tidak diketahui:
        # TP & SL di candle sama = SL). Sinyal di close candle (menu lain): mulai candle berikutnya seperti dulu.
        f, first = i0, (i0 if mid else i0 + 1)
    else:
        below = e <= sig["ref_price"]
        f = None
        for i in range(i0, len(t)):
            if sig.get("wait_until") and t[i] >= sig["wait_until"]:
                break
            ca = sig.get("cancel_at")
            touch = (l[i] <= e) if below else (h[i] >= e)
            run = ca is not None and ((h[i] > ca) if long else (l[i] < ca))
            if run and not touch:                                  # harga lari melewati ujung leg duluan -> batal
                return {"status": "batal (harga lari, limit tidak terisi)", "exit_time": int(t[i])}
            if touch:
                f = i
                break
        if f is None:
            if sig.get("wait_until") and (now_ms >= sig["wait_until"]):
                return {"status": "batal (tidak terisi)", "exit_time": int(sig["wait_until"])}
            return {"status": "menunggu", "last_price": float(c[-1])}
        first = f
    upd.update(status="terisi", fill_time=int(t[f]))
    end_t = int(t[f]) + sig["hold_ms"]
    for j in range(first, len(t)):
        if t[j] >= end_t:
            r_ = ((c[j - 1] - e) if long else (e - c[j - 1])) / risk
            upd.update(status="waktu habis", exit_time=int(t[j]), result_r=float(max(-1.0, min(rr, r_))))
            return upd
        slh = (l[j] <= sl) if long else (h[j] >= sl)
        tph = (j > f or (mid and sig["kind"] == "market")) and ((h[j] >= tp) if long else (l[j] <= tp))
        if slh:
            upd.update(status="SL", exit_time=int(t[j]), result_r=-1.0)
            return upd
        if tph:
            upd.update(status="TP", exit_time=int(t[j]), result_r=float(rr))
            return upd
    upd["last_price"] = float(c[-1])
    upd["open_r"] = float((((c[-1] - e) if long else (e - c[-1])) / risk))
    return upd


def _klines(c, sym, tf, start):
    out, st = [], int(start) - TF_MS[tf]
    for _ in range(30):
        part = c.get("/fapi/v1/klines", symbol=sym, interval=tf, startTime=st, limit=1500)
        if not part:
            break
        out += part
        st = int(part[-1][0]) + TF_MS[tf]
        if len(part) < 1500:
            break
    now = time.time() * 1000
    out = [r for r in out if float(r[6]) < now]                      # hanya candle yang sudah close
    return out


def update(c):
    """Perbarui semua sinyal terbuka (sekali ambil candle per koin & TF pantau)."""
    with _LOCK:
        d = _load()
    sigs = [x for x in d["signals"] if x["status"] in OPEN]
    now = time.time() * 1000
    errs, groups = [], {}
    for x in sigs:
        tf = "15m" if x["source"] == "whale" else x["tf"]
        groups.setdefault((x["symbol"], tf), []).append(x)
    res = {}
    for (sym, tf), lst in groups.items():
        try:
            k = _klines(c, sym, tf, min(x["created"] for x in lst))
        except Exception as ex:                                    # noqa: BLE001
            errs.append(f"{sym}: {ex}")
            continue
        if not k:
            continue
        t = np.array([int(r[0]) for r in k], np.int64)
        h, l, cl = (np.array([float(r[j]) for r in k]) for j in (2, 3, 4))
        for x in lst:
            res[x["id"]] = simulate(x, t, h, l, cl, now)
    with _LOCK:
        d = _load()
        for x in d["signals"]:
            if x["id"] in res and x["status"] in OPEN:
                x.update(res[x["id"]])
        _save(d)
    _ST.update(last_update=int(now), errors=errs[-10:])
    return len(res)


def _loop(c):
    while True:
        try:
            if any(x["status"] in OPEN for x in _load()["signals"]):
                update(c)
            enrich(c)                                              # jalur harga trade selesai (🔍 Evaluasi)
        except Exception as ex:                                    # noqa: BLE001
            _ST["errors"] = (_ST["errors"] + [f"{type(ex).__name__}: {ex}"])[-10:]
        time.sleep(300)


def start(c):
    if _ST["thread"] and _ST["thread"].is_alive():
        return
    th = threading.Thread(target=_loop, args=(c,), daemon=True)
    _ST["thread"] = th
    th.start()


# ---------------------------------------------------------------- ringkasan
OLD_VER = "lama"                 # sinyal yang dicatat sebelum jurnal menyimpan versi aplikasi (sebelum v4.11)


_REL = {"mtime": None, "list": []}


def _releases():
    """[(waktu rilis ms UTC, versi)] dari data 🕘 History Update (waktu zip versi itu pertama kali dikirim)."""
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend", "history_data.json")
    try:
        mt = os.path.getmtime(p)
        if _REL["mtime"] != mt:
            from datetime import datetime
            H = json.load(open(p, encoding="utf-8"))
            _REL["list"] = sorted((int(datetime.fromisoformat(x["ts"].replace("Z", "+00:00")).timestamp() * 1000), x["v"])
                                  for x in H.get("versions", []) if x.get("ts"))
            _REL["mtime"] = mt
    except (OSError, ValueError, KeyError):
        pass
    return _REL["list"]


def est_version(sig):
    """Sinyal lama (tanpa catatan versi): versi PALING BARU yang mungkin dipakai = versi terakhir yang sudah dirilis saat
    sinyal itu dicatat (candle sinyal close). Bisa saja versi yang dipakai lebih lama -> ditampilkan '≤ vX (perkiraan)'."""
    from .data import TF_MS
    t = int(sig.get("created") or 0) + int(TF_MS.get(sig.get("tf"), 0))
    best = None
    for ms, v in _releases():
        if ms <= t:
            best = v
    return best


def vkey(sig):
    """Kelompok versi sinyal: '4.11' (tercatat) / 'lama:4.06' (lama, perkiraan ≤ v4.06) / 'lama' (tidak bisa diperkirakan)."""
    if sig.get("app_version"):
        return sig["app_version"]
    e = est_version(sig)
    return f"{OLD_VER}:{e}" if e else OLD_VER


def versions(sigs):
    """Daftar kelompok versi di jurnal (terbaru dulu) + jumlah sinyalnya."""
    cnt = {}
    for x in sigs:
        v = vkey(x)
        cnt[v] = cnt.get(v, 0) + 1

    def key(v):
        if v.startswith(OLD_VER):
            e = v.split(":")[1] if ":" in v else "0.0"
            return (0,) + tuple(int(a) for a in e.split("."))
        return (1,) + tuple(int(a) for a in v.split("."))
    return [{"v": v, "n": cnt[v]} for v in sorted(cnt, key=key, reverse=True)]


def summary(version=None):
    """version: None = semua sinyal; "lama" = tanpa catatan versi; "4.11" = hanya sinyal dari versi itu."""
    from .riskstats import risk_seq
    d = _load()
    sigs = sorted(d["signals"], key=lambda x: x["created"])
    vers = versions(sigs)
    if version == OLD_VER:                                       # semua sinyal lama (perkiraan apa pun)
        sigs = [x for x in sigs if not x.get("app_version")]
    elif version:
        sigs = [x for x in sigs if vkey(x) == version]
    out = {}
    for src in list(SOURCES) + ["all"]:
        L = [x for x in sigs if src == "all" or x["source"] == src]
        if not L:
            continue
        done = [x for x in L if x["result_r"] is not None]
        filled = [x for x in L if x["fill_time"] is not None]
        decided = [x for x in L if x["status"] not in OPEN]
        batal = [x for x in L if x["status"].startswith("batal")]
        rs = [x["result_r"] for x in sorted(done, key=lambda x: x["exit_time"] or 0)]
        bt = [x["bt"] for x in L if x.get("bt")]
        avg = lambda k: (float(np.mean([b[k] for b in bt if b.get(k) is not None])) if any(b.get(k) is not None for b in bt) else None)  # noqa: E731
        out[src] = {"name": SOURCES.get(src, "Semua"), "n": len(L), "open": sum(1 for x in L if x["status"] in OPEN),
                    "filled": len(filled), "batal": len(batal),
                    "fill_pct": (100 * len(filled) / (len(filled) + len(batal))) if (filled or batal) else None,
                    "done": len(done), "wins": sum(1 for x in done if x["status"] == "TP"),
                    "losses": sum(1 for x in done if x["status"] == "SL"), "timeouts": sum(1 for x in done if x["status"] == "waktu habis"),
                    "wr": (100 * sum(1 for x in done if x["status"] == "TP") / len(done)) if done else None,
                    "avg_r": float(np.mean(rs)) if rs else None, "sum_r": float(np.sum(rs)) if rs else 0.0,
                    "r_per_signal": (float(np.sum(rs)) / len(decided)) if decided else None,      # batal = 0R
                    "bt_wr": avg("wr"), "bt_exp_r": avg("exp_r"), "bt_exp_sig": avg("exp_sig"), "bt_fill": avg("fill_pct"),
                    **risk_seq(rs)}
    for x in sigs:                                               # perkiraan versi untuk sinyal lama (tidak disimpan ke file)
        if not x.get("app_version"):
            x["app_version_est"] = est_version(x)
    return {"auto": d["auto"], "version": version, "versions": vers, "summary": out, "signals": sigs[::-1][:500], "last_update": _ST["last_update"], "errors": _ST["errors"]}


# ================================================================== 🔍 evaluasi (v4.31)
WIB = 7 * 3_600_000                                               # jam & hari scan ditampilkan dalam WIB (UTC+7)
BLOCKS = [("07–11", "sesi Asia"), ("11–15", "Asia akhir"), ("15–19", "London buka"), ("19–23", "London + New York"),
          ("23–03", "New York akhir"), ("03–07", "sepi")]
DAYS = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
CLUSTER_MS = 30 * 60_000
MIN_SCANS = 5                                                     # jam / hari scan baru dinilai kalau dari >= 5 scan berbeda                                          # sinyal lama: tercatat berdekatan (≤ 30 menit) = 1 scan


def scan_times(sigs):
    """{id: (waktu mulai scan ms, pasti?)}. Sinyal baru menyimpan `scan_start` (waktu tombol scan ditekan). Sinyal lama:
    dikelompokkan per sumber (tercatat berdekatan = 1 scan), perkiraan = waktu sinyal paling awal di kelompok itu."""
    out = {}
    old = {}
    for x in sigs:
        if x.get("scan_start"):
            out[x["id"]] = (int(x["scan_start"]), True)
        else:
            old.setdefault(x["source"], []).append(x)
    for L in old.values():
        L = sorted(L, key=lambda x: int(x["created"]))
        grp = []
        for x in L + [None]:
            if x is None or (grp and int(x["created"]) - int(grp[-1]["created"]) > CLUSTER_MS):
                if grp:
                    t0 = min(int(g["created"]) for g in grp)
                    for g in grp:
                        out[g["id"]] = (t0, False)
                grp = []
            if x is not None:
                grp.append(x)
    return out


def wib_block(ms):
    h = int(((ms + WIB) // 3_600_000) % 24)
    return ((h - 7) % 24) // 4


def wib_day(ms):
    return int((((ms + WIB) // 86_400_000) + 3) % 7)                # 1970-01-01 = Kamis -> 0 = Senin


def path_stats(sig, t, h, l, c, now_ms):
    """Jalur harga trade yang sudah selesai (candle TF pantau): seberapa jauh sempat ke arah TP sebelum keluar, kena SL lalu
    harga sampai TP dalam batas waktu, langsung kena SL, dan hasil kalau SL dipindah ke entry setelah +1R."""
    if sig.get("fill_time") is None or sig.get("exit_time") is None or sig.get("result_r") is None:
        return None
    long = sig["dir"] == 0
    e, sl, tp, rr = float(sig["entry"]), float(sig["sl"]), float(sig["tp"]), float(sig["rr"])
    risk = abs(e - sl) or 1e-12
    fi = np.flatnonzero(t == int(sig["fill_time"]))
    xi = np.flatnonzero(t == int(sig["exit_time"]))
    if not len(fi) or not len(xi):
        return None
    f, x = int(fi[0]), int(xi[0])
    fav = ((h - e) if long else (e - l)) / risk
    adv = ((e - l) if long else (h - e)) / risk
    mfe = float(fav[f + 1:x].max()) if x > f + 1 else 0.0
    end_t = int(sig["fill_time"]) + int(sig["hold_ms"])
    final = now_ms >= end_t and t[-1] >= end_t - (t[1] - t[0] if len(t) > 1 else 0)
    after = (t > t[x]) & (t < end_t)
    tp_after = bool(sig["status"] == "SL" and np.any(fav[after] >= rr))
    # SL dipindah ke entry setelah harga sempat +1R (berlaku mulai candle berikutnya); aturan lain sama dengan pantau
    first = f + 1 if sig["kind"] == "market" else f
    armed, be = False, None
    for j in range(first, len(t)):
        if t[j] >= end_t:
            be = float(max(-1.0, min(rr, ((c[j - 1] - e) if long else (e - c[j - 1])) / risk)))
            break
        if adv[j] >= (0.0 if armed else 1.0):
            be = 0.0 if armed else -1.0
            break
        if j > f and fav[j] >= rr:
            be = rr
            break
        if not armed and fav[j] >= 1.0:
            armed = True
    return {"mfe": round(mfe, 3), "bars": int(x - f), "tp_after": tp_after, "be_r": be, "final": bool(final)}


def enrich(c, progress=None):
    """Tambahkan jalur harga ke trade selesai yang belum punya (ambil candle Binance sekali per koin & TF)."""
    with _LOCK:
        d = _load()
    now = time.time() * 1000
    need = [x for x in d["signals"] if x.get("result_r") is not None and x.get("fill_time") is not None
            and (not x.get("path") or (not x["path"].get("final") and now >= int(x["fill_time"]) + int(x["hold_ms"])))]   # hemat permintaan Binance
    groups = {}
    for x in need:
        groups.setdefault((x["symbol"], "15m" if x["source"] == "whale" else x["tf"]), []).append(x)
    res, errs = {}, []
    for k_, ((sym, tf), lst) in enumerate(groups.items()):
        try:
            k = _klines(c, sym, tf, min(int(x["fill_time"]) for x in lst))
        except Exception as ex:                                    # noqa: BLE001
            errs.append(f"{sym}: {ex}")
            k = []
        if k:
            t = np.array([int(r[0]) for r in k], np.int64)
            h, l, cl = (np.array([float(r[j]) for r in k]) for j in (2, 3, 4))
            for x in lst:
                p = path_stats(x, t, h, l, cl, now)
                if p:
                    res[x["id"]] = p
        if progress:
            progress(k_ + 1, len(groups), sym, None)
    with _LOCK:
        d = _load()
        for x in d["signals"]:
            if x["id"] in res:
                x["path"] = res[x["id"]]
        _save(d)
    return {"done": len(res), "need": len(need), "errors": errs[-5:]}


def _badge(r, bt_r):
    if r is None:
        return None
    if r > 0 and (bt_r is None or r >= 0.5 * bt_r):
        return "ok"
    return "mid" if r > 0 else "bad"


def _grp(rows, label, sub=None):
    rs = [float(x["result_r"]) for x in rows]
    if not rs:
        return {"label": label, "sub": sub, "n": 0}
    bt = [x["bt"] for x in rows if x.get("bt")]
    bwr = [b["wr"] for b in bt if b.get("wr") is not None]
    ber = [b["exp_r"] for b in bt if b.get("exp_r") is not None]
    r = float(np.mean(rs))
    bt_r = float(np.mean(ber)) if ber else None
    return {"label": label, "sub": sub, "n": len(rs), "wr": 100 * sum(1 for x in rows if x["status"] == "TP") / len(rs), "r": r, "sum": float(np.sum(rs)),
            "bt_wr": float(np.mean(bwr)) if bwr else None, "bt_r": bt_r, "badge": _badge(r, bt_r)}


def _fmt_r(v):
    return f"{'+' if v >= 0 else '−'}{abs(v):.2f}R".replace(".", ",")


def evaluate(source="all", version=None, tf=None, min_n=20, exact_only=False):
    """Evaluasi trade selesai 1 sumber: pecahan hasil, analisa SL, koin, waktu & hari MULAI scan (WIB), saran."""
    d = _load()
    sigs = d["signals"]
    ST = scan_times(sigs)
    if version == OLD_VER:
        sigs = [x for x in sigs if not x.get("app_version")]
    elif version:
        sigs = [x for x in sigs if vkey(x) == version]
    if source and source != "all":
        sigs = [x for x in sigs if x["source"] == source]
    tfs = sorted({x["tf"] for x in sigs})
    if tf:
        sigs = [x for x in sigs if x["tf"] == tf]
    done = [x for x in sigs if x.get("result_r") is not None]
    n_exact = sum(1 for x in done if ST.get(x["id"], (0, False))[1])
    out = {"source": source, "name": SOURCES.get(source, "Semua"), "n_done": len(done), "n_exact": n_exact, "n_est": len(done) - n_exact,
           "tfs": tfs, "min_n": min_n, "exact_only": exact_only}
    if not done:
        return out
    G = []

    def section(title, key_fn, order=None, labels=None):
        b = {}
        for x in done:
            k = key_fn(x)
            if k is not None:
                b.setdefault(k, []).append(x)
        keys = order if order is not None else sorted(b, key=lambda k: -len(b[k]))
        rows = [_grp(b[k], (labels or {}).get(k, k)) for k in keys if k in b]
        G.append({"title": title, "rows": rows})

    section("Arah", lambda x: "BUY" if x["dir"] == 0 else "SELL", ["BUY", "SELL"], {"BUY": "▲ BUY", "SELL": "▼ SELL"})

    def tr(x):
        T = x.get("trend")
        if not T or T.get("dir") is None:
            return "tanpa data tren"
        if T["dir"] == 0:
            return "tren belum jelas / sideway"
        return "searah tren" if (T["dir"] > 0) == (x["dir"] == 0) else "melawan tren"
    section("Tren saat sinyal", tr, ["searah tren", "melawan tren", "tren belum jelas / sideway", "tanpa data tren"])
    section("RR", lambda x: f"1:{round(float(x['rr']) * 2) / 2:g}")     # dibulatkan ke 0,5 (Chart Pattern punya RR pecahan)
    section("TF", lambda x: x["tf"].upper())
    section("Entry", lambda x: x["kind"], ["market", "limit"])
    section("Versi aplikasi", lambda x: ("v" + x["app_version"]) if x.get("app_version") else "lama (sebelum v4.11)")
    out["groups"] = G
    # ---- analisa SL
    P = [x for x in done if x.get("path")]
    sls = [x for x in P if x["status"] == "SL"]
    out["n_path"], out["n_need_path"] = len(P), len(done) - len(P)
    if sls:
        mf = np.array([x["path"]["mfe"] for x in sls])
        bars = [x["path"]["bars"] for x in sls]
        step = {x["tf"]: TF_MS.get("15m" if x["source"] == "whale" else x["tf"], 900_000) for x in sls}
        hrs = [x["path"]["bars"] * step[x["tf"]] / 3.6e6 for x in sls]
        bes = [x for x in P if x["path"].get("be_r") is not None]
        out["sl"] = {"n": len(sls), "mfe1": 100 * float(np.mean(mf >= 1)), "tp_after": 100 * float(np.mean([x["path"]["tp_after"] for x in sls])),
                     "quick": 100 * float(np.mean([(x["path"]["bars"] <= 4 and x["path"]["mfe"] < 0.5) for x in sls])),
                     "median_h": float(np.median(hrs)), "median_bars": float(np.median(bars)),
                     "hist": [{"label": lab, "n": int(np.sum((mf >= a) & (mf < b)))} for lab, a, b in
                              (("< +0,5R", -1e9, 0.5), ("+0,5R – +1R", 0.5, 1), ("+1R – +2R", 1, 2), ("≥ +2R (hampir TP)", 2, 1e9))],
                     "be": {"n": len(bes), "r_now": float(np.mean([x["result_r"] for x in bes])) if bes else None,
                            "r_be": float(np.mean([x["path"]["be_r"] for x in bes])) if bes else None,
                            "changed": sum(1 for x in bes if x["status"] == "SL" and x["path"]["be_r"] == 0.0)}}
    # ---- koin
    bc = {}
    for x in done:
        bc.setdefault(x["symbol"], []).append(float(x["result_r"]))
    coins = [{"sym": s, "n": len(v), "sum": float(np.sum(v))} for s, v in bc.items() if len(v) >= 5]
    out["coins"] = {"worst": sorted([c_ for c_ in coins if c_["sum"] < 0], key=lambda c_: c_["sum"])[:5],
                    "best": sorted([c_ for c_ in coins if c_["sum"] > 0], key=lambda c_: -c_["sum"])[:5]}
    # ---- waktu & hari MULAI scan (WIB)
    D = [x for x in done if x["id"] in ST and (ST[x["id"]][1] or not exact_only)]
    blk, day, heat = {}, {}, {}
    for x in D:
        s0 = ST[x["id"]][0]
        bi, di = wib_block(s0), wib_day(s0)
        blk.setdefault(bi, []).append(x)
        day.setdefault(di, []).append(x)
        heat.setdefault((di, bi), []).append(float(x["result_r"]))
    nscan = lambda L: len({(x["source"], ST[x["id"]][0]) for x in L})          # noqa: E731 - v4.32: berapa scan berbeda
    hs = {}
    for x in D:
        s0 = ST[x["id"]][0]
        hs.setdefault((wib_day(s0), wib_block(s0)), set()).add((x["source"], s0))
    out["scan"] = {"n": len(D), "n_scans": nscan(D),
                   "blocks": [{**_grp(blk[i], BLOCKS[i][0], BLOCKS[i][1]), "i": i, "scans": nscan(blk[i])} for i in range(6) if i in blk],
                   "days": [{**_grp(day[i], DAYS[i]), "i": i, "scans": nscan(day[i])} for i in range(7) if i in day],
                   "heat": [[{"n": len(heat.get((di, bi), [])), "r": float(np.mean(heat[(di, bi)])) if heat.get((di, bi)) else None,
                              "scans": len(hs.get((di, bi), ()))} for bi in range(6)] for di in range(7)],
                   "block_names": [b[0] for b in BLOCKS], "day_names": DAYS}
    F = [x for x in D if x.get("fill_time") is not None]
    if F:
        dl = np.array([(int(x["fill_time"]) - ST[x["id"]][0]) / 3.6e6 for x in F])
        stale = [x for x, v in zip(F, dl) if v > 12]
        out["scan"]["delay_median_h"] = float(np.median(dl))
        out["scan"]["stale"] = _grp(stale, "terisi > 12 jam setelah scan") if stale else None
    bs = {}
    for x in D:
        bs.setdefault((x["source"], ST[x["id"]][0]), []).append(x)
    big = [x for L in bs.values() if len(L) >= 5 for x in L]
    small = [x for L in bs.values() if len(L) < 5 for x in L]
    out["scan"]["batch_big"] = _grp(big, "scan menghasilkan ≥ 5 sinyal sekaligus") if big else None
    out["scan"]["batch_small"] = _grp(small, "scan menghasilkan < 5 sinyal") if small else None
    out["tips"], out["summary"] = _tips(out, min_n)
    return out


def _tips(E, min_n):
    T = []
    allrows = [(g["title"], r) for g in E["groups"] for r in g["rows"] if r["n"] >= min_n]
    find = lambda title, lab: next((r for t_, r in allrows if t_ == title and r["label"] == lab), None)  # noqa: E731
    w, s_ = find("Tren saat sinyal", "melawan tren"), find("Tren saat sinyal", "searah tren")
    if w and w["r"] < 0:
        T.append(f"Sinyal <b>melawan tren</b> rugi {_fmt_r(w['r'])}/trade ({w['n']} trade)" + (f", searah tren {_fmt_r(s_['r'])}" if s_ else "")
                 + " → pertimbangkan hanya ambil sinyal searah tren.")
    sl = E.get("sl")
    if sl and sl["n"] >= min_n and sl["mfe1"] >= 40 and sl["be"]["r_be"] is not None and sl["be"]["r_be"] > (sl["be"]["r_now"] or 0):
        T.append(f"{sl['mfe1']:.0f}% trade yang kena SL sempat jalan ≥ +1R → coba <b>geser SL ke entry setelah +1R</b> "
                 f"(perkiraan {_fmt_r(sl['be']['r_be'])}/trade vs sekarang {_fmt_r(sl['be']['r_now'])}).")
    if sl and sl["n"] >= min_n and sl["tp_after"] >= 30:
        T.append(f"{sl['tp_after']:.0f}% trade kena SL lalu harga tetap sampai TP → SL kemungkinan terlalu sempit.")
    rrs = [r for t_, r in allrows if t_ == "RR"]
    if len(rrs) >= 2:
        b, w2 = max(rrs, key=lambda r: r["r"]), min(rrs, key=lambda r: r["r"])
        if b["r"] - w2["r"] >= 0.15:
            T.append(f"RR <b>{b['label']}</b> paling bagus ({_fmt_r(b['r'])}/trade) dibanding {w2['label']} ({_fmt_r(w2['r'])}).")
    mk, li = find("Entry", "market"), find("Entry", "limit")
    if mk and li and abs(mk["r"] - li["r"]) >= 0.15:
        b = li if li["r"] > mk["r"] else mk
        T.append(f"Entry <b>{b['label']}</b> lebih bagus (limit {_fmt_r(li['r'])} vs market {_fmt_r(mk['r'])}) → utamakan {b['label']}.")
    S = E.get("scan") or {}
    for key, what in (("blocks", "jam"), ("days", "hari")):
        rows = [r for r in S.get(key, []) if r["n"] >= max(5, min_n // 2) and r.get("scans", 0) >= MIN_SCANS]
        if len(rows) >= 2:
            b, w2 = max(rows, key=lambda r: r["r"]), min(rows, key=lambda r: r["r"])
            if b["r"] - w2["r"] >= 0.2:
                lb = f"{b['label']} WIB" if key == "blocks" else b["label"]
                lw = f"{w2['label']} WIB" if key == "blocks" else w2["label"]
                T.append(f"Mulai scan {what} <b>{lb}</b> paling bagus ({_fmt_r(b['r'])}/trade, {b['n']} trade); {what} <b>{lw}</b> paling jelek "
                         f"({_fmt_r(w2['r'])}, {w2['n']} trade).")
    st = S.get("stale")
    if st and st["n"] >= max(5, min_n // 2) and st["r"] < 0:
        T.append(f"Limit yang baru terisi lebih dari 12 jam setelah scan rugi ({_fmt_r(st['r'])}/trade, {st['n']} trade) → batalkan limit yang belum terisi setelah 12 jam.")
    bb = S.get("batch_big")
    if bb and bb["n"] >= min_n and bb["r"] < 0 and (S.get("batch_small") or {}).get("r", -9) > bb["r"]:
        T.append(f"Scan yang menghasilkan banyak sinyal sekaligus (≥ 5) rugi {_fmt_r(bb['r'])}/trade → sinyal searah bersamaan sering kalah bareng; ambil sebagian saja.")
    # ringkasan 1 kalimat: kelompok terburuk & terbaik (selain versi)
    cand = [(t_, r) for t_, r in allrows if t_ != "Versi aplikasi"]
    summ = None
    if cand:
        wt, wr_ = min(cand, key=lambda z: z[1]["r"])
        bt_, br_ = max(cand, key=lambda z: z[1]["r"])
        summ = (f"{'Kerugian terbesar' if wr_['r'] < 0 else 'Hasil paling kecil'} dari <b>{wr_['label']}</b> ({wt.lower()}: {_fmt_r(wr_['r'])}/trade, {wr_['n']} trade); "
                + (f"paling bagus <b>{br_['label']}</b> ({bt_.lower()}: {_fmt_r(br_['r'])}/trade, {br_['n']} trade)." if br_["r"] > 0 else
                   f"<b>tidak ada kelompok yang untung</b> — yang paling ringan ruginya <b>{br_['label']}</b> ({bt_.lower()}: {_fmt_r(br_['r'])}/trade)."))
    return T, summ
