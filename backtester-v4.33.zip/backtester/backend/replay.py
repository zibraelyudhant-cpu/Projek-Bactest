"""Mode manual replay: satu session per koneksi WebSocket."""
from . import candlestruct as CS
from .data import TF_MS
from .engine import AccountConfig, Engine

HISTORY_BARS = 1500
ACTIONS = ("order", "modify", "cancel", "cancel_all", "close")


class ReplaySession:
    def __init__(self, store):
        self.store = store
        self.engine = None
        self.tf = "1h"
        self.last_sent = None
        self.start_msg = None
        self.actions = []   # [(engine.now, msg)] untuk memutar ulang saat mundur

    def handle(self, msg):
        cmd = msg.get("cmd")
        if cmd == "start":
            return self._start(msg)
        if self.engine is None:
            raise ValueError("session belum dimulai")
        e = self.engine
        if cmd == "set_tf":
            return self._set_tf(msg["tf"])
        if cmd == "history":  # candle lama untuk scroll ke kiri (selalu sebelum `now`)
            tf = msg.get("tf", self.tf)
            bars = e.view.closed_before(tf, int(msg["before"]), max(1, min(int(msg.get("n", HISTORY_BARS)), 5000)))
            return {"type": "history", "tf": tf, "bars": bars.to_list()}
        if cmd == "struct":   # isi candle TF besar di TF kecil (hanya data sampai waktu replay)
            low = msg.get("low", "")
            if low not in self.store.timeframes(e.symbol):
                raise ValueError(f"TF {low} tidak tersedia untuk {e.symbol}")
            return {"type": "struct", "low": low, "items": CS.structure(e.view, low, msg.get("ranges") or [], e.now)}
        if cmd == "step":
            n = max(1, min(int(msg.get("n", 1)), 5000))
            dur = TF_MS[self.tf]
            e.run_until((e.now // dur + n) * dur)
        elif cmd == "step_base":
            for _ in range(max(1, min(int(msg.get("n", 1)), 100_000))):
                if not e.step():
                    break
        elif cmd == "step_back":
            return self._step_back(msg)
        elif cmd in ACTIONS:
            _apply(e, msg)
            self.actions.append((e.now, msg))
        else:
            raise ValueError(f"perintah tidak dikenal: {cmd}")
        return self._update()

    def _start(self, msg):
        sym = msg["symbol"].upper()
        if sym not in self.store.catalog:
            raise ValueError(f"simbol {sym} tidak ada")
        self.engine = Engine(self.store, sym, int(msg["start"]), cfg=AccountConfig.from_dict(msg.get("config")))
        self.start_msg = {**msg, "symbol": sym}
        self.actions = []
        tfs = self.store.timeframes(sym)
        tf = msg.get("tf", self.tf)
        return self._set_tf(tf if tf in tfs else tfs[0])

    def _step_back(self, msg):
        """Mundur n bar (TF aktif, atau base TF kalau base=True). Engine dibangun ulang dari tanggal
        mulai dan aksi user sebelum titik tujuan diputar ulang; aksi di/sesudah titik itu dibatalkan."""
        e = self.engine
        n = max(1, min(int(msg.get("n", 1)), 5000))
        dur = e.base_ms if msg.get("base") else TF_MS[self.tf]
        target = max(((e.now - 1) // dur - (n - 1)) * dur, int(e.base.t[0]))
        begin = min(int(self.start_msg["start"]), target)  # boleh mundur sampai sebelum tanggal mulai
        keep = [(t, m) for t, m in self.actions if t < target]
        eng = Engine(self.store, e.symbol, begin, cfg=e.cfg)
        for t, m in keep:
            eng.run_until(t)
            try:
                _apply(eng, m)
            except Exception:
                pass
        eng.run_until(target)
        eng.drain_events()
        self.engine, self.actions = eng, keep
        self.start_msg["start"] = begin
        return self._set_tf(self.tf)

    def _set_tf(self, tf):
        if tf not in self.store.timeframes(self.engine.symbol):
            raise ValueError(f"TF {tf} tidak tersedia")
        self.tf = tf
        bars = self.engine.view.closed(tf, HISTORY_BARS)
        self.last_sent = int(bars.t[-1]) if len(bars) else None
        return {"type": "init", "tf": tf, "bars": bars.to_list(), "forming": self.engine.view.forming(tf),
                "fills": self.engine.fills, "trades": self.engine.trades, **self._state()}

    def _update(self):
        bars = self.engine.view.closed_after(self.tf, self.last_sent)
        if len(bars):
            self.last_sent = int(bars.t[-1])
        return {"type": "update", "bars": bars.to_list(), "forming": self.engine.view.forming(self.tf),
                "events": self.engine.drain_events(), "trades": self.engine.trades, **self._state()}

    def _state(self):
        return {"state": self.engine.snapshot(), "base_tf": self.engine.base_tf}


def _apply(e, msg):
    cmd = msg["cmd"]
    if cmd == "order":
        e.place(msg["side"], msg["type"], float(msg["qty"]), _num(msg.get("price")),
                _num(msg.get("tp")), _num(msg.get("sl")), bool(msg.get("reduce_only")), tag="manual")
    elif cmd == "modify":
        e.modify(int(msg["id"]), _num(msg.get("price")), _num(msg.get("tp")), _num(msg.get("sl")))
    elif cmd == "cancel":
        e.cancel(int(msg["id"]))
    elif cmd == "cancel_all":
        e.cancel_all()
    elif cmd == "close":
        e.close_position()


def _num(x):
    return None if x in (None, "", 0, "0") else float(x)
