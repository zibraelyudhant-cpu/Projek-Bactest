"""🧪 Indikator Tester: cari angka indikator yang cocok untuk TF tertentu, dari backtest candle (tanpa intip masa depan).

Semua tester memakai mesin yang sama:
- Setiap candle i punya hasil trade yang sudah dihitung SEKALI per koin: entry di close i, SL = k x ATR, TP = RR x SL,
  batas waktu N candle. TP & SL di candle yang sama = kalah. Belum kena TP sampai batas waktu = tidak menang
  (R dihitung dari harga close di batas waktu).
- Indikator memberi sinyal (event) LONG / SHORT. Trade tidak boleh tumpang tindih: sinyal saat trade sebelumnya masih
  jalan dilewati.
- WR dasar = WR kalau entry di SEMUA candle dengan SL & TP yang sama (searah sinyal). Edge = WR sinyal - WR dasar.
- 70% data awal (waktu) = data cari, 30% terakhir = data uji. Angka yang cuma bagus di data cari = curiga kebetulan.

Peran indikator:
- MA pasangan (EMA Tester): harga di atas MA utama & MA kedua = hanya LONG, di bawah keduanya = hanya SHORT,
  di antara keduanya = sideways (tidak trade). Juga diukur seberapa akurat MA kedua memberi tanda struktur berubah.
- RSI / Stochastic / MACD: pemicu entry (validasi LONG / SHORT).
- ADX / Force Index: kekuatan tren (filter / pemicu saat tren mulai kuat).
"""
import itertools
import math
import time

import numpy as np

from .data import TF_MS
from .indicators import _wilder, atr as _atr, dmi, ema, force_index, macd, pivots, rsi, sma, stoch

MA_TYPES = ["EMA", "SMA", "WMA", "RMA", "HMA", "DEMA", "TEMA"]
TESTERS = ["ema", "rsi", "stoch", "macd", "adx", "force", "combo", "hyper"]
MAX_COMBOS = 3000
MAX_LIST = 60
MAX_MA = 5000              # panjang MA maksimal (butuh data minimal ±3x panjangnya)


# ---------------------------------------------------------------------------- moving average
def wma(x, n):
    x = np.asarray(x, float)
    out = np.full(len(x), np.nan)
    if n < 1 or len(x) < n:
        return out
    w = np.arange(1, n + 1, dtype=float)
    out[n - 1:] = np.convolve(x, w[::-1], "valid") / w.sum()
    return out


def rma(x, n):
    a = 1.0 / n
    out = np.empty(len(x))
    if not len(x):
        return out
    out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = a * x[i] + (1 - a) * out[i - 1]
    return out


def ma(x, n, kind="EMA"):
    """Moving average jenis apa saja. Nilai awal (warm-up) sebelum cukup data = NaN."""
    n = int(n)
    kind = (kind or "EMA").upper()
    if kind == "SMA":
        return sma(x, n)
    if kind == "WMA":
        return wma(x, n)
    if kind == "HMA":
        h = max(1, n // 2)
        return wma(2 * np.nan_to_num(wma(x, h)) - np.nan_to_num(wma(x, n)), max(1, int(math.sqrt(n))))
    if kind == "RMA":
        out = rma(x, n)
    elif kind == "DEMA":
        e = ema(x, n)
        out = 2 * e - ema(e, n)
    elif kind == "TEMA":
        e = ema(x, n)
        e2 = ema(e, n)
        out = 3 * e - 3 * e2 + ema(e2, n)
    else:
        out = ema(x, n)
    out = np.asarray(out, float)
    out[:max(0, n - 1)] = np.nan                       # sama seperti SMA: belum valid sebelum n candle
    return out


def parse_list(txt, lo=1, hi=1000, integer=True):
    """'20, 50, 100' atau '10-100:10' (dari-sampai:langkah) atau gabungan. Maks MAX_LIST angka."""
    if isinstance(txt, (int, float)):
        txt = str(txt)
    if isinstance(txt, (list, tuple)):
        txt = ",".join(str(x) for x in txt)
    vals = []
    for part in str(txt or "").replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part[1:]:
            rng, _, step = part.partition(":")
            a, b = rng.split("-", 1) if not rng.startswith("-") else ("-" + rng[1:].split("-", 1)[0], rng[1:].split("-", 1)[1])
            a, b = float(a), float(b)
            st = float(step) if step else (1 if integer else 0.5)
            if st <= 0:
                raise ValueError(f"langkah harus > 0: {part}")
            k = 0
            while a + k * st <= b + 1e-9 and len(vals) < 10 * MAX_LIST:
                vals.append(a + k * st)
                k += 1
        else:
            vals.append(float(part))
    out = []
    bad = [v for v in vals if v < lo or v > hi]
    if bad:
        raise ValueError(f"angka {bad[0]:g} di luar batas ({lo:g}–{hi:g})")
    for v in vals:
        v = int(round(v)) if integer else round(v, 4)
        if v not in out:
            out.append(v)
    if len(out) > MAX_LIST:
        raise ValueError(f"terlalu banyak angka ({len(out)}), maksimal {MAX_LIST} per kolom")
    return out


# ---------------------------------------------------------------------------- hasil trade per candle
def trade_outcomes(h, l, c, a, sl_atr, rr, max_bars):
    """Untuk setiap candle i & arah: hasil entry di close i (SL = sl_atr x ATR, TP = rr x SL).
    Hasil: res[d] = (win bool, R float, exit index int, valid bool) dengan d = 0 LONG, 1 SHORT."""
    n = len(c)
    out = {}
    for d, sgn in ((0, 1), (1, -1)):
        win = np.zeros(n, bool)
        R = np.full(n, np.nan)
        ex = np.full(n, -1, np.int64)
        ok = np.zeros(n, bool)
        for i in range(n - 1):
            risk = sl_atr * a[i]
            if not (risk > 0) or i + max_bars >= n:
                continue
            e = c[i]
            tp, sl = e + sgn * rr * risk, e - sgn * risk
            hh, ll = h[i + 1:i + 1 + max_bars], l[i + 1:i + 1 + max_bars]
            if sgn > 0:
                it, isl = np.flatnonzero(hh >= tp), np.flatnonzero(ll <= sl)
            else:
                it, isl = np.flatnonzero(ll <= tp), np.flatnonzero(hh >= sl)
            t = it[0] if len(it) else None
            s = isl[0] if len(isl) else None
            ok[i] = True
            if s is not None and (t is None or s <= t):
                R[i], ex[i] = -1.0, i + 1 + s
            elif t is not None:
                win[i], R[i], ex[i] = True, rr, i + 1 + t
            else:                                           # waktu habis: tidak menang, R dari close terakhir
                R[i], ex[i] = sgn * (c[i + max_bars] - e) / risk, i + max_bars
        out[d] = (win, R, ex, ok)
    return out


def _stats(out, idx_l, idx_s):
    """Ringkasan trade dari daftar index sinyal (sudah tanpa tumpang tindih)."""
    wl, Rl = out[0][0][idx_l], out[0][1][idx_l]
    ws, Rs = out[1][0][idx_s], out[1][1][idx_s]
    n = len(idx_l) + len(idx_s)
    if not n:
        return {"n": 0, "wins": 0, "wr": None, "exp_r": None, "n_long": 0, "n_short": 0, "r_sum": 0.0}
    wins = int(wl.sum() + ws.sum())
    rs = float(np.nansum(Rl) + np.nansum(Rs))
    return {"n": n, "wins": wins, "wr": 100 * wins / n, "exp_r": rs / n, "n_long": len(idx_l), "n_short": len(idx_s), "r_sum": rs}


def _merge(a, b):
    n = a["n"] + b["n"]
    wins = a["wins"] + b["wins"]
    rs = a["r_sum"] + b["r_sum"]
    return {"n": n, "wins": wins, "wr": 100 * wins / n if n else None, "exp_r": rs / n if n else None,
            "n_long": a["n_long"] + b["n_long"], "n_short": a["n_short"] + b["n_short"], "r_sum": rs}


def _no_overlap(sig, out, lo, hi):
    """Sinyal (array -1/0/+1) di rentang [lo, hi) -> index LONG & SHORT yang benar-benar diambil (tidak tumpang tindih)."""
    il, is_ = [], []
    busy = -1
    for i in np.flatnonzero(sig[lo:hi]) + lo:
        if i <= busy:
            continue
        d = 0 if sig[i] > 0 else 1
        if not out[d][3][i]:
            continue
        (il if d == 0 else is_).append(i)
        busy = out[d][2][i]
    return np.array(il, np.int64), np.array(is_, np.int64)


# ---------------------------------------------------------------------------- data per koin (cache indikator)
class Coin:
    def __init__(self, b, p):
        self.t, self.o, self.h, self.l, self.c, self.v = (np.asarray(x, float) for x in (b.t, b.o, b.h, b.l, b.c, b.v))
        self.n = len(self.c)
        self.a = _atr(self.h, self.l, self.c, int(p["atr_len"]))
        self._p = p
        self.split = int(self.n * 0.7)
        self._c = {}

    @property
    def out(self):                                          # hasil trade tiap candle, dihitung saat pertama dibutuhkan
        p = self._p
        return self.get("out", lambda: trade_outcomes(self.h, self.l, self.c, self.a, p["sl_atr"], p["rr"], int(p["max_bars"])))

    def get(self, key, fn):
        if key not in self._c:
            self._c[key] = fn()
        return self._c[key]

    def ma(self, kind, n):
        return self.get(("ma", kind, n), lambda: ma(self.c, n, kind))

    def baseline(self, lo, hi):
        """WR & R rata-rata kalau entry di semua candle (dasar pembanding)."""
        def f():
            r = {}
            for d in (0, 1):
                ok = self.out[d][3][lo:hi]
                w, R = self.out[d][0][lo:hi][ok], self.out[d][1][lo:hi][ok]
                r[d] = (int(ok.sum()), int(w.sum()), float(np.nansum(R)))
            return r
        return self.get(("base", lo, hi), f)

    def swings(self, n):
        """Swing low / high terakhir yang SUDAH terkonfirmasi di tiap candle (tanpa intip masa depan)."""
        def f():
            hi_i, lo_i = pivots(self.h, self.l, n)
            last_lo, last_hi = np.full(self.n, np.nan), np.full(self.n, np.nan)
            for idx, arr, src in ((lo_i, last_lo, self.l), (hi_i, last_hi, self.h)):
                for k in idx:
                    j = k + n                               # baru diketahui n candle setelahnya
                    if j < self.n:
                        arr[j] = src[k]
            fill = lambda x: np.array([*itertools.accumulate(x, lambda p_, q: q if q == q else p_)])  # noqa: E731
            return fill(last_lo), fill(last_hi)
        return self.get(("sw", n), f)


# ---------------------------------------------------------------------------- komponen indikator
# Tiap komponen menghasilkan ("state", s) = arah yang diizinkan per candle (-1/0/+1)
# atau ("trig", s) = sinyal di candle itu saja (-1/0/+1).
def comp_ma_pair(C, main, second, kind_main, kind_second):
    m, s = C.ma(kind_main, main), C.ma(kind_second, second)
    up = (C.c > np.fmax(m, s))
    dn = (C.c < np.fmin(m, s))
    st = np.where(up, 1, np.where(dn, -1, 0)).astype(np.int8)
    st[np.isnan(m) | np.isnan(s)] = 0
    return "state", st


def comp_ma_filter(C, n, kind):
    m = C.ma(kind, n)
    st = np.where(C.c > m, 1, np.where(C.c < m, -1, 0)).astype(np.int8)
    st[np.isnan(m)] = 0
    return "state", st


def comp_rsi(C, n, ob, mode):
    r = C.get(("rsi", n), lambda: rsi(C.c, n))
    os_ = 100 - ob
    p = np.r_[np.nan, r[:-1]]
    if mode == "masuk":                                  # langsung saat masuk zona (kontra)
        short = (p < ob) & (r >= ob)
        long = (p > os_) & (r <= os_)
    else:                                                 # balik keluar dari zona
        short = (p >= ob) & (r < ob)
        long = (p <= os_) & (r > os_)
    return "trig", np.where(long, 1, np.where(short, -1, 0)).astype(np.int8)


def comp_stoch(C, k, smooth, d, ob):
    K, D = C.get(("st", k, smooth, d), lambda: stoch(C.h, C.l, C.c, k, smooth, d))
    pk, pd_ = np.r_[np.nan, K[:-1]], np.r_[np.nan, D[:-1]]
    up = (pk <= pd_) & (K > D)
    dn = (pk >= pd_) & (K < D)
    long = up & (np.fmin(pk, K) <= 100 - ob)
    short = dn & (np.fmax(pk, K) >= ob)
    return "trig", np.where(long, 1, np.where(short, -1, 0)).astype(np.int8)


def comp_macd(C, fast, slow, signal, mode):
    if fast >= slow:
        return None
    line, sig, _ = C.get(("macd", fast, slow, signal), lambda: macd(C.c, fast, slow, signal))
    pl, ps = np.r_[np.nan, line[:-1]], np.r_[np.nan, sig[:-1]]
    up = (pl <= ps) & (line > sig)
    dn = (pl >= ps) & (line < sig)
    if mode == "nol":                                     # klasik: cross naik di bawah 0, cross turun di atas 0
        up &= line < 0
        dn &= line > 0
    t = np.where(up, 1, np.where(dn, -1, 0)).astype(np.int8)
    t[: slow + signal] = 0
    return "trig", t


def comp_adx(C, n, th):
    pdi, ndi, ad = C.get(("dmi", n), lambda: dmi(C.h, C.l, C.c, n))
    strong = ad > th
    st = np.where(strong & (pdi > ndi), 1, np.where(strong & (ndi > pdi), -1, 0)).astype(np.int8)
    return "state", st


def comp_force(C, n, k):
    def f():
        fi = force_index(C.c, C.v, n)
        ref = sma(np.abs(fi), 100)
        return fi, ref
    fi, ref = C.get(("fi", n), f)
    with np.errstate(invalid="ignore"):
        st = np.where(fi > k * ref, 1, np.where(fi < -k * ref, -1, 0)).astype(np.int8)
    st[np.isnan(ref)] = 0
    return "state", st


def comp_retest(C, swing, window, tol):
    """Entry pullback / retest market structure (tanpa intip masa depan).
    LONG: close menembus swing high terakhir yang sudah terkonfirmasi (BOS) -> level = swing high itu. Dalam `window`
    candle sesudahnya, harga turun menyentuh level (low <= level + tol x ATR) dan close tetap DI ATAS level -> sinyal
    LONG di candle itu (entry di close). Batal kalau close < level - tol x ATR (retest gagal) atau waktu habis.
    SHORT kebalikannya (BOS ke bawah swing low, retest naik ke level, close tetap di bawah)."""
    def f():
        lo_sw, hi_sw = C.swings(int(swing))
        c, h, l, a = C.c, C.h, C.l, C.a
        sig = np.zeros(C.n, np.int8)
        up = dn = None                                  # (level, index BOS)
        for i in range(1, C.n):
            t = tol * a[i] if a[i] == a[i] else 0.0
            if up is not None:
                lvl, b = up
                if i - b > window or c[i] < lvl - t:
                    up = None
                elif l[i] <= lvl + t and c[i] > lvl:
                    sig[i] = 1
                    up = None
            if dn is not None:
                lvl, b = dn
                if i - b > window or c[i] > lvl + t:
                    dn = None
                elif h[i] >= lvl - t and c[i] < lvl:
                    sig[i] = -1
                    dn = None
            H, L = hi_sw[i - 1], lo_sw[i - 1]           # swing yang SUDAH diketahui sebelum candle i
            if H == H and c[i] > H >= c[i - 1]:
                up = (H, i)                             # BOS naik: tunggu retest mulai candle berikutnya
            if L == L and c[i] < L <= c[i - 1]:
                dn = (L, i)
        return sig
    return "trig", C.get(("retest", int(swing), int(window), round(float(tol), 4)), f)


def combine(parts, confirm_window=3):
    """Gabungkan komponen jadi sinyal entry. Ada pemicu: pemicu menyala & semua state searah (kalau pemicu > 1,
    semuanya harus menyala searah dalam `confirm_window` candle terakhir). Tanpa pemicu: entry saat semua state
    baru saja menjadi searah (candle sebelumnya belum)."""
    states = [s for k, s in parts if k == "state"]
    trigs = [s for k, s in parts if k == "trig"]
    if states:
        S = states[0].copy()
        for s in states[1:]:
            S = np.where(S == s, S, 0).astype(np.int8)
    if trigs:
        sig = trigs[0].copy()
        for t in trigs[1:]:
            recent_up = np.convolve((t == 1).astype(int), np.ones(confirm_window, int))[:len(t)] > 0
            recent_dn = np.convolve((t == -1).astype(int), np.ones(confirm_window, int))[:len(t)] > 0
            sig = np.where((sig == 1) & recent_up, 1, np.where((sig == -1) & recent_dn, -1, 0)).astype(np.int8)
        if states:
            sig = np.where(sig == S, sig, 0).astype(np.int8)
        return sig, (S if states else None)
    prev = np.r_[0, S[:-1]]
    return np.where((S != 0) & (S != prev), S, 0).astype(np.int8), S


# ---------------------------------------------------------------------------- akurasi MA kedua (struktur berubah)
def structure_events(C, sig_state, main_line, second_line, p):
    """Event peringatan: harga sedang di atas kedua MA (LONG) lalu candle CLOSE menembus MA kedua ke bawah dengan body
    valid (>= body_pct dari panjang candle, warna searah tembusan) & volume >= vol_mult x rata-rata 20 candle.
    Valid (berhasil) kalau dalam N candle: market structure berubah (CHoCH: close menembus swing low terakhir yang
    sudah terkonfirmasi) DAN close menembus MA utama, sebelum harga close kembali ke atas kedua MA.
    Kebalikannya untuk SHORT. Hasil per event: (index, arah lama, berhasil?, candle sampai valid)."""
    o, h, l, c, v = C.o, C.h, C.l, C.c, C.v
    body_ok = np.abs(c - o) >= p["body_pct"] / 100 * np.maximum(h - l, 1e-12)
    vavg = C.get("vavg", lambda: np.r_[np.nan, sma(v, 20)[:-1]])
    vol_ok = v >= p["vol_mult"] * vavg
    lo_sw, hi_sw = C.swings(int(p["swing"]))
    N = int(p["confirm_bars"])
    prev = np.r_[0, sig_state[:-1]]
    ev = []
    for i in np.flatnonzero((prev != 0) & body_ok & vol_ok):
        d = prev[i]
        if np.isnan(second_line[i]) or np.isnan(main_line[i]):
            continue
        if d > 0 and not (c[i] < second_line[i] and c[i] < o[i]):
            continue
        if d < 0 and not (c[i] > second_line[i] and c[i] > o[i]):
            continue
        ref_sw = lo_sw[i] if d > 0 else hi_sw[i]
        ok_ms = ok_main = False
        bars = None
        for j in range(i, min(C.n, i + N + 1)):
            if j > i and ((d > 0 and c[j] > max(main_line[j], second_line[j])) or (d < 0 and c[j] < min(main_line[j], second_line[j]))):
                break                                       # balik lagi ke tren lama = peringatan palsu
            sw = lo_sw[j] if d > 0 else hi_sw[j]
            sw = sw if sw == sw else ref_sw
            if sw == sw and ((d > 0 and c[j] < sw) or (d < 0 and c[j] > sw)):
                ok_ms = True
            if (d > 0 and c[j] < main_line[j]) or (d < 0 and c[j] > main_line[j]):
                ok_main = True
            if ok_ms and ok_main:
                bars = j - i
                break
        if i + N >= C.n and bars is None:
            continue                                        # masa depan belum cukup: belum diketahui
        ev.append((i, int(d), bars is not None, bars))
    return ev


def _struct_sum(ev, lo, hi):
    e = [x for x in ev if lo <= x[0] < hi]
    ok = [x for x in e if x[2]]
    return {"n": len(e), "ok": len(ok), "wr": 100 * len(ok) / len(e) if e else None,
            "bars_med": float(np.median([x[3] for x in ok])) if ok else None}


# ---------------------------------------------------------------------------- grid & evaluasi
# kolom dikosongkan = dicari otomatis dari daftar ini
AUTO = {
    "ema_main": "30, 34, 50, 55, 60, 89, 100, 120, 144, 150, 200, 233, 250, 300",
    "ema_second": "5, 8, 9, 10, 12, 13, 15, 20, 21, 25, 26, 30, 34, 40, 50, 55, 60, 75, 89, 100",
    "filter_len": "50, 100, 150, 200",
    "bounce_list": "8, 9, 10, 13, 20, 21, 25, 30, 34, 50, 55, 60, 89, 100, 144, 150, 200, 233",
    "rsi_len": "5, 7, 9, 11, 14, 21, 28", "rsi_ob": "60, 65, 70, 75, 80, 85",
    "st_k": "5, 8, 9, 14, 21", "st_smooth": "1, 3", "st_d": "3, 5", "st_ob": "70, 75, 80, 85, 90",
    "macd_fast": "5, 8, 12, 15", "macd_slow": "17, 21, 26, 34", "macd_signal": "5, 7, 9",
    "adx_len": "7, 10, 14, 20, 28", "adx_th": "15, 20, 25, 30, 35, 40",
    "fi_len": "2, 5, 8, 13, 21, 34", "fi_k": "0, 0.5, 1, 1.5, 2",
}
AUTO_NAMES = {"bounce_list": "daftar EMA pantulan", "ema_main": "MA utama", "ema_second": "MA kedua", "filter_len": "MA filter tren", "rsi_len": "panjang RSI",
              "rsi_ob": "overbought RSI", "st_k": "%K", "st_smooth": "%K smoothing", "st_d": "%D", "st_ob": "overbought Stoch",
              "macd_fast": "MACD fast", "macd_slow": "MACD slow", "macd_signal": "MACD signal", "adx_len": "panjang ADX",
              "adx_th": "batas ADX", "fi_len": "panjang Force Index", "fi_k": "batas Force Index"}


def _vals(p, key, lo, hi, integer=True):
    """Isi kolom; kosong = otomatis (daftar AUTO). Dicatat di p['_auto'] supaya hasil bisa menyebutnya."""
    txt = str(p.get(key) if p.get(key) is not None else "").strip()
    if not txt:
        p.setdefault("_auto", [])
        if key not in p["_auto"]:
            p["_auto"].append(key)
        txt = AUTO[key]
    return parse_list(txt, lo, hi, integer)


def _dims(p):
    """Pilihan angka per komponen: {komponen: [dict angka, ...]}."""
    t = p["tester"]
    comps = p.get("components") or []
    if t not in ("combo", "hyper"):
        comps = {"ema": ["ma_pair"], "rsi": ["rsi"], "stoch": ["stoch"], "macd": ["macd"], "adx": ["adx"], "force": ["force"]}[t]
        if t in ("rsi", "stoch", "macd") and p.get("trend_filter"):
            comps = comps + ["ma_filter"]
    G = {}
    if "ma_pair" in comps:
        mode = p.get("ema_mode", "both")
        if mode == "test" and not (str(p.get("ema_main") or "").strip() and str(p.get("ema_second") or "").strip()):
            raise ValueError("mode Test pasangan sendiri: isi MA utama DAN MA kedua (mis. 200 dan 50)")
        if mode == "find_second" and not str(p.get("ema_main") or "").strip():
            raise ValueError("mode Cari MA kedua: isi MA utama kamu (mis. 200); MA kedua boleh dikosongkan = dicari otomatis")
        if mode == "find_main" and not str(p.get("ema_second") or "").strip():
            raise ValueError("mode Cari MA utama: isi MA kedua kamu (mis. 50); MA utama boleh dikosongkan = dicari otomatis")
        mains = _vals(p, "ema_main", 2, MAX_MA)
        seconds = _vals(p, "ema_second", 2, MAX_MA)
        if mode == "test":
            mains, seconds = mains[:1], seconds[:1]
        # aturan: MA utama (tren) = angka LEBIH BESAR, MA kedua (peringatan struktur) = angka lebih kecil.
        # Saat bullish MA kedua ada di atas MA utama: harga tembus MA kedua dulu (peringatan), lalu MA utama (konfirmasi).
        G["ma_pair"] = [{"main": a, "second": b} for a in mains for b in seconds if a > b]
    if "ma_filter" in comps:
        G["ma_filter"] = [{"n": x} for x in _vals(p, "filter_len", 2, MAX_MA)]
    if "rsi" in comps:
        G["rsi"] = [{"n": a, "ob": b} for a in _vals(p, "rsi_len", 2, 200) for b in _vals(p, "rsi_ob", 51, 99)]
    if "stoch" in comps:
        G["stoch"] = [{"k": a, "smooth": s, "d": d, "ob": ob} for a in _vals(p, "st_k", 2, 200)
                      for s in _vals(p, "st_smooth", 1, 20) for d in _vals(p, "st_d", 1, 20) for ob in _vals(p, "st_ob", 51, 99)]
    if "macd" in comps:
        G["macd"] = [{"fast": a, "slow": b, "signal": s} for a in _vals(p, "macd_fast", 2, 200)
                     for b in _vals(p, "macd_slow", 3, 400) for s in _vals(p, "macd_signal", 2, 100) if a < b]
    if "adx" in comps:
        G["adx"] = [{"n": a, "th": b} for a in _vals(p, "adx_len", 2, 100) for b in _vals(p, "adx_th", 5, 80)]
    if "force" in comps:
        G["force"] = [{"n": a, "k": b} for a in _vals(p, "fi_len", 1, 200) for b in _vals(p, "fi_k", 0, 5, integer=False)]
    for k, why in (("ma_pair", "MA utama (tren) harus angka LEBIH BESAR dari MA kedua, mis. utama 200 & kedua 50"),
                   ("macd", "MACD fast harus lebih kecil dari slow")):
        if k in G and not G[k]:
            raise ValueError(why)
    G = {k: v for k, v in G.items() if v}
    if not G:
        raise ValueError("tidak ada kombinasi angka yang valid")
    return G


def _total(G):
    t = 1
    for v in G.values():
        t *= len(v)
    return t


def plan(p):
    """Cek isian sebelum mulai. Hasil: (jumlah kombinasi penuh, bertahap?). Kombinasi > MAX_COMBOS dengan >= 2
    indikator dicari BERTAHAP: tiap indikator dicari sendiri dulu, lalu angka terbaiknya digabung."""
    if p.get("tester") == "ema":
        st = ema_state(dict(p))
        return len(st["bl"]) + len(st["pairs"]), False
    if p.get("tester") == "hyper":
        st = hyper_state(dict(p))
        return len(st["grid"]), False
    G = _dims(dict(p))
    total = _total(G)
    if total <= MAX_COMBOS:
        return total, False
    if len(G) < 2 or max(len(v) for v in G.values()) > MAX_COMBOS:
        raise ValueError(f"kombinasi terlalu banyak ({total:,}), maksimal {MAX_COMBOS:,}. Persempit daftar angka.")
    return total, True


def _grid(p):
    """Semua kombinasi (dipakai kalau tidak bertahap)."""
    G = _dims(p)
    if _total(G) > MAX_COMBOS:
        raise ValueError(f"kombinasi terlalu banyak ({_total(G):,}), maksimal {MAX_COMBOS:,}. Persempit daftar angka.")
    return [dict(zip(G, vals)) for vals in itertools.product(*G.values())]


def _parts(C, combo, p):
    parts = []
    for k, v in combo.items():
        if k == "ma_pair":
            parts.append(comp_ma_pair(C, v["main"], v["second"], p["ma_type"], p.get("ma_type2") or p["ma_type"]))
        elif k == "ma_filter":
            parts.append(comp_ma_filter(C, v["n"], p["ma_type"]))
        elif k == "rsi":
            parts.append(comp_rsi(C, v["n"], v["ob"], p.get("rsi_mode", "balik")))
        elif k == "stoch":
            parts.append(comp_stoch(C, v["k"], v["smooth"], v["d"], v["ob"]))
        elif k == "macd":
            r = comp_macd(C, v["fast"], v["slow"], v["signal"], p.get("macd_mode", "nol"))
            if r is None:
                return None
            parts.append(r)
        elif k == "adx":
            parts.append(comp_adx(C, v["n"], v["th"]))
        elif k == "force":
            parts.append(comp_force(C, v["n"], v["k"]))
    # MA pasangan hanya penentu ARAH tren. Kalau tidak ada pemicu lain (RSI / Stoch / MACD), entry = pullback / retest
    # market structure searah tren.
    if "ma_pair" in combo and not any(kind == "trig" for kind, _ in parts):
        parts.append(comp_retest(C, p["swing"], int(p["retest_bars"]), float(p["retest_tol"])))
    return parts


def _label(combo, p):
    out = []
    for k, v in combo.items():
        if k == "ma_pair":
            t1, t2 = p["ma_type"], (p.get("ma_type2") or p["ma_type"])
            out.append(f"{t1} {v['main']} (utama) + {t2} {v['second']} (kedua)")
        elif k == "ma_filter":
            out.append(f"filter tren {p['ma_type']} {v['n']}")
        elif k == "rsi":
            out.append(f"RSI {v['n']} ({100 - v['ob']}/{v['ob']})")
        elif k == "stoch":
            out.append(f"Stoch {v['k']},{v['smooth']},{v['d']} ({100 - v['ob']}/{v['ob']})")
        elif k == "macd":
            out.append(f"MACD {v['fast']},{v['slow']},{v['signal']}")
        elif k == "adx":
            out.append(f"ADX {v['n']} > {v['th']}")
        elif k == "force":
            out.append(f"Force Index {v['n']} (> {v['k']:g}× rata-rata)")
    return " + ".join(out)


def _warmup(grid):
    w = 50
    for combo in grid:
        for k, v in combo.items():
            for key in ("main", "second", "n", "slow", "k"):
                if key in v and isinstance(v[key], (int, float)):
                    w = max(w, int(v[key]) * (3 if k in ("ma_pair", "ma_filter", "macd") else 2))
    return w


def _coin_acc(C, grid, p, warm):
    """Satu koin: tabungan hasil tiap kombinasi angka (digabung antar koin dengan _merge_acc)."""
    dirs = p.get("direction", "both")
    acc = {}
    lo, sp, hi = warm, max(warm + 1, C.split), C.n
    base_tr, base_te = C.baseline(lo, sp), C.baseline(sp, hi)
    for combo in grid:
        parts = _parts(C, combo, p)
        if parts is None:
            continue
        sig, state = combine(parts)
        if dirs == "long":
            sig = np.where(sig > 0, sig, 0)
        elif dirs == "short":
            sig = np.where(sig < 0, sig, 0)
        key = _label(combo, p)
        A = acc.setdefault(key, {"combo": combo, "label": key, "tr": None, "te": None, "base_tr": [0, 0, 0.0, 0, 0, 0.0],
                                  "base_te": [0, 0, 0.0, 0, 0, 0.0], "side": [0, 0], "st_tr": [], "st_te": []})
        for part, (a_, b_), base, bk in (("tr", (lo, sp), base_tr, "base_tr"), ("te", (sp, hi), base_te, "base_te")):
            il, is_ = _no_overlap(sig, C.out, a_, b_)
            s = _stats(C.out, il, is_)
            A[part] = s if A[part] is None else _merge(A[part], s)
            # WR dasar ditimbang sesuai jumlah LONG / SHORT sinyal
            for d, cnt in ((0, len(il)), (1, len(is_))):
                nb, wb, rb = base[d]
                if nb and cnt:
                    A[bk][d * 3] += cnt
                    A[bk][d * 3 + 1] += cnt * wb / nb
                    A[bk][d * 3 + 2] += cnt * rb / nb
        if state is not None:
            seg = state[lo:hi]
            A["side"][0] += int((seg == 0).sum())
            A["side"][1] += len(seg)
        if "ma_pair" in combo:
            v = combo["ma_pair"]
            m_line = C.ma(p["ma_type"], v["main"])
            s_line = C.ma(p.get("ma_type2") or p["ma_type"], v["second"])
            st_pair = comp_ma_pair(C, v["main"], v["second"], p["ma_type"], p.get("ma_type2") or p["ma_type"])[1]
            ev = structure_events(C, st_pair, m_line, s_line, p)
            A["st_tr"].append(_struct_sum(ev, lo, sp))
            A["st_te"].append(_struct_sum(ev, sp, hi))
    return acc


def _merge_acc(acc, coin):
    """Tambahkan tabungan satu koin ke tabungan total (urut per koin -> hasil sama dengan dihitung satu per satu)."""
    for key, B in coin.items():
        A = acc.get(key)
        if A is None:
            acc[key] = {"combo": B["combo"], "label": B["label"], "tr": B["tr"], "te": B["te"], "base_tr": list(B["base_tr"]),
                        "base_te": list(B["base_te"]), "side": list(B["side"]), "st_tr": list(B["st_tr"]), "st_te": list(B["st_te"])}
            continue
        for part in ("tr", "te"):
            A[part] = B[part] if A[part] is None else _merge(A[part], B[part])
        for bk in ("base_tr", "base_te"):
            A[bk] = [x + y for x, y in zip(A[bk], B[bk])]
        A["side"] = [A["side"][0] + B["side"][0], A["side"][1] + B["side"][1]]
        A["st_tr"] += B["st_tr"]
        A["st_te"] += B["st_te"]


def _rows(acc, p):
    rows = []
    for A in acc.values():
        tr, te = A["tr"], A["te"]
        if not tr:
            continue
        def base_wr(bk, n):
            B = A[bk]
            nn = B[0] + B[3]
            return (100 * (B[1] + B[4]) / nn, (B[2] + B[5]) / nn) if nn else (None, None)
        bw, br = base_wr("base_tr", tr["n"])
        bw2, _ = base_wr("base_te", te["n"])
        def st_sum(lst):
            n = sum(x["n"] for x in lst)
            ok = sum(x["ok"] for x in lst)
            meds = [x["bars_med"] for x in lst if x["bars_med"] is not None]
            return {"n": n, "ok": ok, "wr": 100 * ok / n if n else None, "bars_med": float(np.median(meds)) if meds else None}
        row = {"label": A["label"], "combo": A["combo"],
               "n": tr["n"], "wr": tr["wr"], "exp_r": tr["exp_r"], "n_long": tr["n_long"], "n_short": tr["n_short"],
               "base_wr": bw, "base_r": br, "edge": (tr["wr"] - bw) if tr["wr"] is not None and bw is not None else None,
               "n_test": te["n"], "wr_test": te["wr"], "exp_test": te["exp_r"], "base_wr_test": bw2,
               "sideways_pct": 100 * A["side"][0] / A["side"][1] if A["side"][1] else None}
        if A["st_tr"]:
            row["struct"], row["struct_test"] = st_sum(A["st_tr"]), st_sum(A["st_te"])
        row["consistent"] = bool(row["exp_test"] is not None and row["exp_r"] is not None and te["n"] >= max(5, p["min_trades"] // 3)
                                 and row["exp_test"] > 0 and row["exp_r"] > 0 and abs((row["wr_test"] or 0) - (row["wr"] or 0)) <= 12)
        rows.append(row)
    return rows


def _load_coin(store, sym, p):
    try:
        b = _slice(store.get(sym, p["tf"]), p.get("start"), p.get("end"))
        n = len(b.t)
        if n == 0:
            return "tidak ada data di periode ini (koin baru listing / data belum diunduh)"
        if n < 50:
            return f"data terlalu sedikit di periode ini ({n} candle)"
        return Coin(b, p)
    except Exception as ex:                                 # noqa: BLE001 - satu koin bermasalah tidak boleh menghentikan semua
        return f"{type(ex).__name__}: {ex}"


_WS = {}


def _init_worker(data_dir):
    from .data import DataStore
    _WS["store"] = DataStore(data_dir, cache_size=4)


def coin_task(sym, p, grid, warm, store=None, C=None):
    """Satu koin x semua kombinasi di grid -> (tabungan, candle) atau pesan kenapa dilewati."""
    C = C if C is not None else _load_coin(store or _WS["store"], sym, p)
    if isinstance(C, str):
        return C
    if C.n < warm + 200:
        return f"data terlalu pendek ({C.n} candle, butuh ≥ {warm + 200})"
    return _coin_acc(C, grid, p, warm), C.n - warm


def job_total(q, symbols):
    if q.get("tester") == "hyper":
        return len(symbols)
    if q.get("tester") == "ema":
        return len(symbols)
    G = _dims(dict(q))
    return len(symbols) * (2 if _total(G) > MAX_COMBOS else 1)


def job_state(q, symbols):
    if q.get("tester") == "hyper":
        return hyper_state(q)
    if q.get("tester") == "ema":
        return ema_state(q)
    G = _dims(q)                                           # (q diisi '_auto' = kolom yang dicari otomatis)
    full = _total(G)
    staged = full > MAX_COMBOS
    if staged and (len(G) < 2 or max(len(v) for v in G.values()) > MAX_COMBOS):
        raise ValueError(f"kombinasi terlalu banyak ({full:,}), maksimal {MAX_COMBOS:,}. Persempit daftar angka.")
    grid1 = [{k: v} for k, vals in G.items() for v in vals] if staged else \
        [dict(zip(G, vals)) for vals in itertools.product(*G.values())]
    return {"G": G, "full": full, "staged": staged, "grid1": grid1, "grid2": None, "picked": None, "keep": None,
            "warm": _warmup([{k: v} for k, vals in G.items() for v in vals]), "acc1": {}, "acc": {}, "used": [],
            "skipped": [], "candles": 0, "merged": 0, "t0": time.time()}


def job_ready(state, q, symbols, i):
    if state.get("ema") or state.get("hyper"):
        return True
    return i < len(symbols) or state["grid2"] is not None     # tahap 2 menunggu semua koin tahap 1 selesai


def job_call(state, q, symbols, i):
    if state.get("hyper"):
        return hyper_coin_task, (symbols[i], q, state["grid"], state["sls"], state["warm"])
    if state.get("ema"):
        return ema_coin_task, (symbols[i], q, state["bl"], state["pairs"], state["warm"])
    n = len(symbols)
    grid = state["grid1"] if i < n else state["grid2"]
    return coin_task, (symbols[i % n], q, grid, state["warm"])


def _pick(state, q):
    """Tahap 1 selesai: ambil angka terbaik tiap indikator (diuji sendiri-sendiri)."""
    G = state["G"]
    keep = min(max(2, int(MAX_COMBOS ** (1 / len(G)))), 6)
    mid = {k: v[len(v) // 2] for k, v in G.items()}
    rows = _rows(state["acc1"], q)
    min_n = max(5, int(q["min_trades"]) // 2)
    picked = {}
    for k in G:
        r1 = [r for r in rows if list(r["combo"]) == [k]]
        ok = sorted([r for r in r1 if r["n"] >= min_n and r["exp_r"] is not None], key=lambda r: -r["exp_r"])
        ok += sorted([r for r in r1 if 3 <= r["n"] < min_n and r["exp_r"] is not None], key=lambda r: -r["exp_r"])
        best = []
        for r in ok:
            if r["combo"][k] not in best:
                best.append(r["combo"][k])
            if len(best) >= keep:
                break
        picked[k] = best or [mid[k]]
    state["picked"], state["keep"] = picked, keep
    state["grid2"] = [dict(zip(picked, vals)) for vals in itertools.product(*picked.values())]


def job_merge(state, q, symbols, i, res):
    if state.get("hyper"):
        return hyper_merge(state, symbols[i], res)
    if state.get("ema"):
        return ema_merge(state, symbols[i], res)
    n = len(symbols)
    final_phase = (i >= n) or not state["staged"]
    state["merged"] += 1
    if isinstance(res, str):
        if final_phase:
            state["skipped"].append(f"{symbols[i % n]}: {res}")
    else:
        coin, cnd = res
        _merge_acc(state["acc"] if final_phase else state["acc1"], coin)
        if final_phase:
            state["used"].append(symbols[i % n])
            state["candles"] += cnd
    if state["staged"] and state["merged"] == n:
        _pick(state, q)


def job_finalize(state, q, symbols, partial=False):
    if state.get("hyper"):
        return hyper_finalize(state, q)
    if state.get("ema"):
        return ema_finalize(state, q)
    p = q
    rows = _rows(state["acc"], p)
    staged = None
    if state["staged"]:
        staged = {"full": state["full"], "stage1": len(state["grid1"]), "stage2": len(state["grid2"] or []), "keep": state["keep"],
                  "picked": {k: [_label({k: v}, p) for v in vals] for k, vals in (state["picked"] or {}).items()}}
    used, skipped, candles, full = state["used"], state["skipped"], state["candles"], state["full"]
    t0 = state["t0"]
    min_n = int(p["min_trades"])
    good = [r for r in rows if r["n"] >= min_n]
    _rank(good, p)
    best_per = []
    mode = p.get("ema_mode")
    if p["tester"] == "ema" and mode in ("find_second", "find_main"):
        fixed = "main" if mode == "find_second" else "second"
        seen = set()
        for r in good:                                     # good sudah urut dari yang terbaik
            k = r["combo"]["ma_pair"][fixed]
            if k not in seen:
                seen.add(k)
                best_per.append(r)
        best_per.sort(key=lambda r: r["combo"]["ma_pair"][fixed])
    return {"rows": good[:int(p.get("top", 30))], "best_per": best_per, "n_combos": full if staged is None else staged["stage1"] + staged["stage2"],
            "staged": staged, "n_rows": len(rows), "n_ok": len(good),
            "too_few": len(rows) - len(good), "symbols": used, "skipped": skipped[:20], "n_skipped": len(skipped), "candles": candles,
            "params": {k: p[k] for k in p if k != "components"} | {"components": p.get("components")},
            "breakeven": 100 / (1 + p["rr"]), "elapsed": round(time.time() - t0, 1),
            "auto": [AUTO_NAMES[k] for k in p.get("_auto", [])]}




def combo_trades(store, sym, p, combo, limit=300):
    """Contoh kejadian: daftar trade satu kombinasi di satu koin, PERSIS seperti yang dihitung tester
    (rentang latih & uji dihitung terpisah, tanpa tumpang tindih), untuk dibuka di Manual Replay."""
    q = {**DEFAULTS, **dict(p)}
    q["components"] = p.get("components") or DEFAULTS["components"]
    C = _load_coin(store, sym, q)
    if isinstance(C, str):
        raise ValueError(C)
    warm = _warmup([{k: v} for k, vals in _dims(dict(q)).items() for v in vals])
    if C.n < warm + 200:
        raise ValueError(f"data terlalu pendek ({C.n} candle, butuh ≥ {warm + 200})")
    parts = _parts(C, combo, q)
    if parts is None:
        return {"symbol": sym, "tf": q["tf"], "trades": [], "n": 0}
    sig, _ = combine(parts)
    if q.get("direction") == "long":
        sig = np.where(sig > 0, sig, 0)
    elif q.get("direction") == "short":
        sig = np.where(sig < 0, sig, 0)
    lo, sp = warm, max(warm + 1, C.split)
    segs = ((lo, sp, False), (sp, C.n, True))
    if q.get("tester") == "hyper":                                    # hyperopt: dihitung per fold waktu, uji = fold terakhir
        bnd = [warm + (C.n - warm) * j // H_FOLDS for j in range(H_FOLDS + 1)]
        segs = tuple((bnd[j], bnd[j + 1], j == H_FOLDS - 1) for j in range(H_FOLDS))
    out = []
    for a_, b_, test in segs:
        il, is_ = _no_overlap(sig, C.out, a_, b_)
        for d, idx in ((0, il), (1, is_)):
            sgn = 1 if d == 0 else -1
            for i in idx:
                risk = q["sl_atr"] * C.a[i]
                win, R, ex = C.out[d][0][i], C.out[d][1][i], C.out[d][2][i]
                out.append({"time": int(C.t[i]), "side": "long" if d == 0 else "short", "entry": float(C.c[i]),
                            "sl": float(C.c[i] - sgn * risk), "tp": float(C.c[i] + sgn * q["rr"] * risk),
                            "win": bool(win), "r": float(R), "sl_hit": bool(not win and R == -1.0),
                            "exit_time": int(C.t[min(ex, C.n - 1)]), "test": test})
    out.sort(key=lambda x: x["time"])
    return {"symbol": sym, "tf": q["tf"], "trades": out[-limit:], "n": len(out)}


def run(store, symbols, p, progress=None):
    """Versi langsung (tanpa jeda) — dipakai tes. Menu memakai StudyJobs (paralel, bisa dijeda, hasil disimpan)."""
    q = dict(p)
    state = job_state(q, symbols)
    total = job_total(q, symbols)
    if state.get("ema") or state.get("hyper"):
        for i, sym in enumerate(symbols):
            if progress:
                progress(i, total, f"{sym}|menguji||", None)
            fn, args = job_call(state, q, symbols, i)
            job_merge(state, q, symbols, i, fn(*args, store=store))
        return job_finalize(state, q, symbols)
    cache = {}
    for i in range(total):
        sym = symbols[i % len(symbols)]
        if progress:
            progress(i, total, f"{sym}|{'[Tahap 2 · gabungan] ' if i >= len(symbols) else ''}menguji||", None)
        if sym not in cache:
            cache[sym] = _load_coin(store, sym, q)
        fn, args = job_call(state, q, symbols, i)
        job_merge(state, q, symbols, i, fn(*args, C=cache[sym]))
        if len(symbols) > 20 and i >= len(symbols):
            cache.pop(sym, None)
    if progress:
        progress(total, total, "selesai||", None)
    return job_finalize(state, q, symbols)


def _rank(rows, p):
    sort = p.get("sort", "auto")
    if sort == "auto":
        sort = "gabungan" if p["tester"] == "ema" else "exp_r"
    if sort == "gabungan" and any("struct" in r for r in rows):
        def rk(key):
            vals = sorted(rows, key=lambda r: -(key(r) if key(r) is not None else -1e9))
            return {id(r): i for i, r in enumerate(vals)}
        a = rk(lambda r: r["exp_r"])
        b = rk(lambda r: (r.get("struct") or {}).get("wr"))
        for r in rows:
            r["rank_score"] = (a[id(r)] + b[id(r)]) / 2
        rows.sort(key=lambda r: r["rank_score"])
        return
    keyf = {"wr": lambda r: r["wr"], "edge": lambda r: r["edge"], "struct": lambda r: (r.get("struct") or {}).get("wr"),
            "test": lambda r: r["exp_test"]}.get(sort, lambda r: r["exp_r"])
    rows.sort(key=lambda r: -(keyf(r) if keyf(r) is not None else -1e9))


def _slice(b, start, end):
    if not start and not end:
        return b
    t = np.asarray(b.t)
    lo = np.searchsorted(t, int(start)) if start else 0
    hi = np.searchsorted(t, int(end), side="right") if end else len(t)
    return type(b)(*(np.asarray(x)[lo:hi] for x in (b.t, b.o, b.h, b.l, b.c, b.v)))


DEFAULTS = {
    "tester": "ema", "tf": "1h", "start": None, "end": None, "direction": "both",
    "sl_atr": 1.5, "rr": 2.0, "max_bars": 100, "atr_len": 14, "min_trades": 30, "sort": "auto", "top": 30,
    "ma_type": "EMA", "ma_type2": "", "ema_mode": "find_both",
    "ema_main": "50, 89, 100, 144, 150, 200, 233", "ema_second": "8, 13, 20, 21, 30, 34, 50, 55",
    "body_pct": 50, "vol_mult": 1.2, "swing": 3, "confirm_bars": 30, "retest_bars": 20, "retest_tol": 0.2,
    "trend_filter": False, "filter_len": "200",
    "rsi_len": "7, 9, 14, 21", "rsi_ob": "65, 70, 75, 80", "rsi_mode": "balik",
    "st_k": "5, 9, 14, 21", "st_smooth": "1, 3", "st_d": "3", "st_ob": "75, 80, 85",
    "macd_fast": "8, 12", "macd_slow": "21, 26", "macd_signal": "5, 9", "macd_mode": "nol",
    "adx_len": "7, 10, 14, 20", "adx_th": "20, 25, 30",
    "fi_len": "2, 13, 21", "fi_k": "0, 0.5, 1",
    "components": ["ma_pair", "force"],
    "bounce_list": "", "bounce_away": 1.0, "hold_bars": 3,
    "hyper_sl": "1, 1.5, 2", "hyper_obj": "exp_r",
}


# ============================================================================ 📈 EMA Tester (v3.76, simpel)
# Yang diatur user cuma TF & angka EMA. Aturan lain TETAP (tidak ada pengaturan):
# Tes 1 — EMA PANTULAN: saat tren (harga sudah >= 1 ATR di atas / bawah EMA), harga MENYENTUH EMA (ekor candle sampai EMA).
#         R = 1 ATR saat menyentuh, diukur dari harga EMA saat disentuh. Mana yang lebih dulu:
#         MANTUL 2R = close >= 2R searah tren; TEMBUS & TREN BERUBAH = close >= 2R di seberang EMA. Tanpa batas waktu.
# Tes 2 — PASANGAN EMA (EMA pertama minimal 30 lebih besar dari EMA kedua): saat harga di atas (bullish) / di bawah
#         (bearish) kedua EMA, candle close menembus EMA KEDUA tapi masih tertahan EMA pertama = peringatan.
#         BALIK (tren berlanjut) = harga close kembali melewati EMA kedua ke sisi tren lama.
#         VALID (tren berubah) = harga lanjut close menembus EMA PERTAMA dan tidak close balik selama 200 candle.
#         TEMBUS LALU BALIK = sempat tembus EMA pertama tapi close balik sebelum 200 candle.
EMA_AWAY = 1.0          # ATR: sudah ada tren (harga menjauh dari EMA) sebelum sentuhan dihitung
EMA_R = 1.0             # 1R = sekian ATR saat menyentuh
EMA_TP = 2.0            # mantul / tren berubah = gerak 2R
EMA_HOLD = 200          # candle: tembus EMA pertama sah kalau tidak balik selama ini (Tes 2)
EMA_GAP = 30            # EMA pertama minimal sekian lebih besar dari EMA kedua
EMA_MIN_N = 30          # kejadian minimal supaya ditampilkan
EMA_MAXWAIT = 20000     # pengaman: kejadian yang belum selesai sampai sekian candle dibuang


def _held(c, m, j, sg, n, hold=EMA_HOLD):
    """Close di candle j sudah di sisi -sg dari EMA. True = tidak close kembali ke sisi sg selama `hold` candle,
    False = kembali, None = data belum cukup."""
    if j + 1 + hold > n:
        return None
    seg = c[j + 1:j + 1 + hold] - m[j + 1:j + 1 + hold]
    return not bool((sg * seg > 0).any())


def _bounce_outcome(c, m, a, i, sg):
    """Dari candle sentuh i (E = EMA saat disentuh, R = ATR saat itu): (1, j) mantul 2R, (0, j) tembus & tren berubah
    (2R di seberang EMA), (None, j) belum selesai sampai data habis."""
    n = len(c)
    E, R = m[i], EMA_R * a[i]
    j = i
    for j in range(i, min(n, i + EMA_MAXWAIT)):
        if sg * (c[j] - E) >= EMA_TP * R:
            return 1, j
        if sg * (E - c[j]) >= EMA_TP * R:
            return 0, j
    return None, j


def bounce_events(C, m, p=None):
    """Tes 1 satu EMA -> list (i sentuh, arah tren +1/-1, hasil 1 mantul 2R / 0 tembus & tren berubah, i hasil).
    Sentuhan berikutnya baru dihitung setelah kejadian sebelumnya selesai (tidak tumpang tindih)."""
    c, h, l, a = C.c, C.h, C.l, C.a
    ev = []
    arm = [False, False]
    nxt = 1
    for i in range(1, C.n):
        mi, ai = m[i], a[i]
        if i < nxt or not (mi == mi) or not (ai == ai) or ai <= 0:
            continue
        for d, sg in ((0, 1), (1, -1)):
            if not arm[d]:
                if sg * (c[i] - mi) >= EMA_AWAY * ai:
                    arm[d] = True
                continue
            if not ((l[i] <= mi) if sg > 0 else (h[i] >= mi)):
                continue
            res, k = _bounce_outcome(c, m, a, i, sg)
            arm = [False, False]
            if res is None:
                nxt = C.n
                break
            ev.append((i, sg, res, k))
            nxt = k + 1
            break
    return ev


def pair_events(C, main_line, second_line, p=None):
    """Tes 2 satu pasangan -> list (i peringatan, arah tren lama +1/-1, kode 0 valid / 1 balik (tren berlanjut) /
    2 tembus EMA pertama lalu balik, candle sampai tembus EMA pertama, i hasil)."""
    c = C.c
    m1, m2 = main_line, second_line
    st = np.where(c > np.fmax(m1, m2), 1, np.where(c < np.fmin(m1, m2), -1, 0)).astype(np.int8)
    st[np.isnan(m1) | np.isnan(m2)] = 0
    prev = np.r_[0, st[:-1]]
    ev = []
    n = C.n
    # peringatan = candle close menembus EMA kedua tapi BELUM menembus EMA pertama (kalau langsung jebol keduanya,
    # tidak ada "peringatan dulu" — tidak dihitung)
    for i in np.flatnonzero(((prev > 0) & (c < m2) & (c >= m1)) | ((prev < 0) & (c > m2) & (c <= m1))):
        d = int(prev[i])
        code, bars, k = None, None, i
        for j in range(i + 1, min(n, i + EMA_MAXWAIT)):
            k = j
            if (d > 0 and c[j] > m2[j]) or (d < 0 and c[j] < m2[j]):
                code = 1                                    # balik melewati EMA kedua = tren lama berlanjut
                break
            if (d > 0 and c[j] < m1[j]) or (d < 0 and c[j] > m1[j]):
                h_ = _held(c, m1, j, d, n)
                if h_ is not None:
                    code, bars = (0, j - i) if h_ else (2, j - i)
                    if h_:
                        k = j + EMA_HOLD
                break
        if code is not None:
            ev.append((int(i), d, code, bars, int(k)))
    return ev


def _ema_lists(q):
    bl = _vals(q, "bounce_list", 2, MAX_MA)
    mains, seconds = _vals(q, "ema_main", 2, MAX_MA), _vals(q, "ema_second", 2, MAX_MA)
    pairs = [(a, b) for a in mains for b in seconds if a - b >= EMA_GAP]
    if not pairs:
        raise ValueError(f"EMA pertama harus minimal {EMA_GAP} lebih besar dari EMA kedua (mis. 200 & 50, atau 1120 & 640)")
    if len(pairs) > MAX_COMBOS or len(bl) > MAX_LIST * 5:
        raise ValueError("daftar EMA terlalu banyak, persempit")
    return bl, pairs


def ema_state(q):
    q["ma_type"], q["ma_type2"], q["atr_len"] = "EMA", "", 14         # EMA Tester: aturan tetap
    bl, pairs = _ema_lists(q)
    warm = min([_ema_warm(x) for x in bl] + [_ema_warm(a) for a, b in pairs])   # yang terpendek; tiap EMA punya pemanasan sendiri
    return {"ema": True, "bl": bl, "pairs": pairs, "warm": warm, "B": {}, "P": {}, "used": [], "skipped": [],
            "candles": [0, 0], "t0": time.time()}


BARS_MAX = 500


def _ema_warm(n):
    """Pemanasan PER EMA: nilai EMA baru dipakai setelah 3x panjangnya (EMA 3000 -> 9000 candle). EMA pendek tidak ikut
    menunggu EMA panjang."""
    return max(50, 3 * int(n))


def ema_coin(C, q, bl, pairs, warm=None):
    """Satu koin: hitungan Tes 1 (per EMA) & Tes 2 (per pasangan), dipisah data cari (70%) & uji (30%).
    EMA yang datanya belum cukup panjang di koin ini dilewati (dicatat di "short")."""
    B, P, short = {}, {}, []
    for n_ in bl:
        w = _ema_warm(n_)
        if C.n < w + 200:
            short.append(f"EMA {n_}")
            continue
        sp = max(w + 1, C.split)
        A = B[n_] = {"tr": [0, 0], "te": [0, 0], "bars": np.zeros(BARS_MAX + 1, np.int64), "cand": sp - w}   # [berubah, mantul]
        for i, sg, res, k in bounce_events(C, C.ma("EMA", n_)):
            if i < w:
                continue
            A["tr" if i < sp else "te"][res] += 1
            if res == 1 and i < sp:
                A["bars"][min(k - i, BARS_MAX)] += 1
    for a_, b_ in pairs:
        w = _ema_warm(a_)
        if C.n < w + 200:
            short.append(f"EMA {a_}/{b_}")
            continue
        sp = max(w + 1, C.split)
        A = P[(a_, b_)] = {"tr": [0, 0, 0], "te": [0, 0, 0], "bars": np.zeros(BARS_MAX + 1, np.int64), "cand": sp - w}  # [valid, balik, tembus lalu balik]
        for i, d, code, bars, k in pair_events(C, C.ma("EMA", a_), C.ma("EMA", b_)):
            if i < w:
                continue
            A["tr" if i < sp else "te"][code] += 1
            if code == 0 and i < sp:
                A["bars"][min(bars, BARS_MAX)] += 1
    w0 = min([_ema_warm(x) for x in bl] + [_ema_warm(x) for x, _ in pairs])
    sp0 = max(w0 + 1, C.split)
    return {"B": B, "P": P, "cand": [sp0 - w0, C.n - sp0], "short": short}


def ema_coin_task(sym, q, bl, pairs, warm, store=None, C=None):
    q = dict(q, ma_type="EMA", ma_type2="", atr_len=14)
    C = C if C is not None else _load_coin(store or _WS["store"], sym, q)
    if isinstance(C, str):
        return C
    if C.n < warm + 200:
        return f"data terlalu pendek ({C.n} candle, butuh ≥ {warm + 200})"
    return ema_coin(C, q, bl, pairs)


def ema_merge(state, sym, res):
    if isinstance(res, str):
        state["skipped"].append(f"{sym}: {res}")
        return
    state["used"].append(sym)
    state["candles"][0] += res["cand"][0]
    state["candles"][1] += res["cand"][1]
    if res.get("short"):
        state.setdefault("short", {})
        for x in res["short"]:
            state["short"][x] = state["short"].get(x, 0) + 1
    for key, src in (("B", res["B"]), ("P", res["P"])):
        for k, X in src.items():
            A = state[key].get(k)
            if A is None:
                state[key][k] = {"tr": list(X["tr"]), "te": list(X["te"]), "bars": X["bars"].copy(), "cand": X.get("cand", 0)}
                continue
            for kk in ("tr", "te"):
                A[kk] = [x + y for x, y in zip(A[kk], X[kk])]
            A["bars"] += X["bars"]
            A["cand"] = A.get("cand", 0) + X.get("cand", 0)


def _hmed(hist, step=1.0):
    n = int(hist.sum())
    if not n:
        return None
    return float(np.searchsorted(np.cumsum(hist), (n + 1) / 2) * step)


def ema_finalize(state, q):
    cand_tr, cand_te = state["candles"]
    brows = []
    for n_, A in state["B"].items():
        tr, te = A["tr"], A["te"]
        nt, ne = sum(tr), sum(te)
        brows.append({"n": n_, "label": f"EMA {n_}", "touch": nt, "ok": tr[1], "fail": tr[0],
                      "pct": 100 * tr[1] / nt if nt else None, "pct_fail": 100 * tr[0] / nt if nt else None,
                      "per1000": 1000 * nt / A["cand"] if A.get("cand") else None,
                      "bars_med": _hmed(A["bars"]), "n_test": ne, "pct_test": 100 * te[1] / ne if ne else None})
    ok_b = [r for r in brows if r["touch"] >= EMA_MIN_N and r["pct"] is not None]
    avg = float(np.mean([r["pct"] for r in ok_b])) if ok_b else None
    for r in brows:
        r["edge"] = r["pct"] - avg if avg is not None and r["pct"] is not None else None
        r["consistent"] = bool(r["pct"] is not None and r["pct_test"] is not None and r["n_test"] >= 10
                               and abs(r["pct_test"] - r["pct"]) <= 10 and r["pct"] > 50 and r["pct_test"] > 50)
    ok_b.sort(key=lambda r: -r["pct"])
    prows = []
    for (a_, b_), A in state["P"].items():
        tr, te = A["tr"], A["te"]
        nt, ne = sum(tr), sum(te)
        prows.append({"main": a_, "second": b_, "label": f"EMA {a_} (pertama) + EMA {b_} (kedua)", "warn": nt,
                      "valid": tr[0], "balik": tr[1], "tembus_balik": tr[2], "pct": 100 * tr[0] / nt if nt else None,
                      "bars_med": _hmed(A["bars"]), "n_test": ne, "pct_test": 100 * te[0] / ne if ne else None})
    for r in prows:
        r["consistent"] = bool(r["pct"] is not None and r["pct_test"] is not None and r["n_test"] >= 10
                               and abs(r["pct_test"] - r["pct"]) <= 10)
    ok_p = sorted([r for r in prows if r["warn"] >= EMA_MIN_N and r["pct"] is not None], key=lambda r: -r["pct"])
    top = int(q.get("top", 30))
    return {"ema2": True, "bounce": ok_b[:top], "bounce_avg": avg, "pairs": ok_p[:top],
            "n_bounce": len(brows), "n_pairs": len(prows), "too_few_b": len(brows) - len(ok_b), "too_few_p": len(prows) - len(ok_p),
            "short": state.get("short", {}),
            "rules": {"away": EMA_AWAY, "r": EMA_R, "tp": EMA_TP, "hold": EMA_HOLD, "gap": EMA_GAP, "min_n": EMA_MIN_N},
            "symbols": state["used"], "skipped": state["skipped"][:20], "n_skipped": len(state["skipped"]),
            "candles": cand_tr + cand_te, "params": {k: v for k, v in q.items() if k != "components"},
            "elapsed": round(time.time() - state["t0"], 1), "auto": [AUTO_NAMES[k] for k in q.get("_auto", []) if k in AUTO_NAMES],
            "rows": [], "n_combos": len(brows) + len(prows)}


def ema_events(store, sym, p, item, limit=300):
    """Contoh kejadian EMA Tester: item = {"kind": "bounce", "n": 50} atau {"kind": "pair", "main": 200, "second": 50}."""
    q = {**DEFAULTS, **dict(p), "ma_type": "EMA", "ma_type2": "", "atr_len": 14}
    C = _load_coin(store, sym, q)
    if isinstance(C, str):
        raise ValueError(C)
    out = []
    if item.get("kind") == "bounce":
        n_ = int(item["n"])
        warm = _ema_warm(n_)
        sp = max(warm + 1, C.split)
        m = C.ma("EMA", n_)
        for i, sg, res, k in bounce_events(C, m):
            if i >= warm:
                out.append({"time": int(C.t[i]), "dir": sg, "result": ["berubah", "mantul"][res], "ma": float(m[i]),
                            "r": float(EMA_R * C.a[i]),
                            "price": float(C.c[i]), "end_time": int(C.t[k]), "test": bool(i >= sp)})
        lines = {"main": n_}
    else:
        a_, b_ = int(item["main"]), int(item["second"])
        warm = _ema_warm(a_)
        sp = max(warm + 1, C.split)
        m1, m2 = C.ma("EMA", a_), C.ma("EMA", b_)
        for i, d, code, bars, k in pair_events(C, m1, m2):
            if i >= warm:
                out.append({"time": int(C.t[i]), "dir": d, "result": ["valid", "balik", "tembus_balik"][code],
                            "main": float(m1[i]), "second": float(m2[i]), "price": float(C.c[i]), "end_time": int(C.t[k]),
                            "bars": bars, "test": bool(i >= sp)})
        lines = {"main": a_, "second": b_}
    return {"symbol": sym, "tf": q["tf"], "kind": item.get("kind"), "ma_type": "EMA", "ma_type2": "EMA",
            "lines": lines, "events": out[-limit:], "n": len(out)}


# ============================================================================ 🎛️ Hyperopt Tester
# Seperti hyperopt Freqtrade: banyak kombinasi angka indikator (+ SL) dicoba otomatis, RR dari user. Bedanya, langsung
# dicek anti-overfitting:
# - data dibagi 5 bagian waktu (fold). CARI = fold 1-4 (80%), UJI = fold 5 (20%, tidak dipakai mencari);
# - WALK-FORWARD: cari di fold 1..k, pakai angka terbaiknya di fold k+1 (k = 2, 3, 4) = meniru hyperopt ulang tiap periode;
# - KESTABILAN: hasil angka "tetangga" (satu angka digeser ke nilai sebelah di daftar) dibanding angka terbaik.
H_FOLDS = 5
H_MAX = MAX_COMBOS                      # kombinasi maksimal; lebih dari ini diambil acak (seed tetap -> bisa diulang)
H_SL = [1.0, 1.5, 2.0]                  # SL (x ATR) yang dicari otomatis
H_HOLD_H = [4, 12, 24]                  # lama trade maksimal (jam) yang dicari otomatis
H_MIN_N = 30                            # trade minimal di data cari
H_KEYS = {"ma_pair": ("ema_main", "ema_second"), "rsi": ("rsi_len", "rsi_ob"), "stoch": ("st_k", "st_smooth", "st_d", "st_ob"),
          "macd": ("macd_fast", "macd_slow", "macd_signal"), "adx": ("adx_len", "adx_th"), "force": ("fi_len", "fi_k")}


def _h_holds(tf):
    return sorted({max(4, int(round(hh * 3_600_000 / TF_MS[tf]))) for hh in H_HOLD_H}) if tf in TF_MS else [24, 48, 96]


def hyper_state(q):
    comps = [c for c in (q.get("components") or []) if c in ("ma_pair", "rsi", "stoch", "macd", "adx", "force")]
    if not comps:
        raise ValueError("Hyperopt: pilih minimal 1 indikator")
    q["components"] = comps
    # aturan tetap: semua angka indikator dari daftar otomatis, EMA, cari dua-duanya; SL & lama trade ikut dicari
    q.update(ma_type="EMA", ma_type2="", ema_mode="find_both", hyper_obj="exp_r", min_trades=H_MIN_N, direction="both", trend_filter=False)
    for c in comps:
        for k in H_KEYS[c]:
            q[k] = ""
    q.pop("_auto", None)
    G = _dims(q)
    G["_sl"] = list(H_SL)
    G["_mb"] = _h_holds(q["tf"])
    full = _total(G)
    keys = list(G)
    if full <= H_MAX:
        grid = [dict(zip(keys, vals)) for vals in itertools.product(*G.values())]
    else:                                              # terlalu banyak: ambil acak (seperti hyperopt), seed tetap
        rng = np.random.default_rng(0)
        seen, grid = set(), []
        while len(grid) < H_MAX:
            pick = tuple(int(rng.integers(len(G[k]))) for k in keys)
            if pick not in seen:
                seen.add(pick)
                grid.append({k: G[k][i] for k, i in zip(keys, pick)})
    return {"hyper": True, "grid": grid, "G": {k: v for k, v in G.items()}, "full": full, "sampled": full > H_MAX, "sls": [0],
            "warm": _warmup([{k: v for k, v in g.items() if not k.startswith("_")} for g in grid]), "acc": {}, "used": [], "skipped": [],
            "candles": 0, "t0": time.time()}


def hyper_coin(C, q, grid, sls, warm):
    """Satu koin: untuk tiap kombinasi (angka indikator + SL + lama trade) hitungan trade per fold waktu:
    [n, menang, jumlah R]."""
    n = C.n
    bnd = [warm + (n - warm) * j // H_FOLDS for j in range(H_FOLDS + 1)]
    outs, sigs, acc = {}, {}, {}
    for gi, g in enumerate(grid):
        combo = {k: v for k, v in g.items() if not k.startswith("_")}
        key = repr(combo)
        if key not in sigs:
            parts = _parts(C, combo, q)
            sigs[key] = None if parts is None else combine(parts)[0]
        sig = sigs[key]
        if sig is None:
            continue
        om = (g["_sl"], g["_mb"])
        if om not in outs:
            outs[om] = trade_outcomes(C.h, C.l, C.c, C.a, om[0], q["rr"], int(om[1]))
        out = outs[om]
        F = np.zeros((H_FOLDS, 3))
        for j in range(H_FOLDS):
            il, is_ = _no_overlap(sig, out, bnd[j], bnd[j + 1])
            st = _stats(out, il, is_)
            F[j] = (st["n"], st["wins"], st["r_sum"])
        acc[(gi, 0)] = F
    return acc, n - warm


def hyper_coin_task(sym, q, grid, sls, warm, store=None, C=None):
    C = C if C is not None else _load_coin(store or _WS["store"], sym, q)
    if isinstance(C, str):
        return C
    if C.n < warm + 200:
        return f"data terlalu pendek ({C.n} candle, butuh ≥ {warm + 200})"
    return hyper_coin(C, q, grid, sls, warm)


def hyper_merge(state, sym, res):
    if isinstance(res, str):
        state["skipped"].append(f"{sym}: {res}")
        return
    acc, cnd = res
    state["used"].append(sym)
    state["candles"] += cnd
    A = state["acc"]
    for k, F in acc.items():
        if k in A:
            A[k] += F
        else:
            A[k] = F.copy()


def _hstat(F):
    n, w, r = float(F[0]), float(F[1]), float(F[2])
    return {"n": int(n), "wr": 100 * w / n if n else None, "exp_r": r / n if n else None}


def hyper_finalize(state, q):
    A, grid, sls, G = state["acc"], state["grid"], state["sls"], state["G"]
    min_n = int(q["min_trades"])
    obj = q.get("hyper_obj") or "exp_r"
    keys = list(G)
    idx_of = {k: {repr(v): i for i, v in enumerate(G[k])} for k in keys}

    def score(F):                                       # nilai yang dioptimasi
        n = F[0]
        if n < 1:
            return -1e9
        ex, wr = F[2] / n, F[1] / n
        return ex if obj == "exp_r" else wr if obj == "wr" else ex * np.sqrt(n)

    tf_m = TF_MS[q["tf"]] / 60_000

    def label(gi, si):
        g = grid[gi]
        mb = g["_mb"] * tf_m
        hold = f"{mb / 60:g} jam" if mb < 1440 else f"{mb / 1440:g} hari"
        return f"{_label({k: v for k, v in g.items() if not k.startswith('_')}, q)} · SL {g['_sl']:g}×ATR · tahan maks {hold}"

    tr_sum = {k: F[:H_FOLDS - 1].sum(0) for k, F in A.items()}
    ok = [k for k, F in tr_sum.items() if F[0] >= min_n]
    ok.sort(key=lambda k: -score(tr_sum[k]))
    pos = {}
    for k in A:
        gi, si = k
        pos[tuple(idx_of[kk][repr(grid[gi][kk])] for kk in keys)] = k

    def neighbors(k):
        gi, si = k
        base = [idx_of[kk][repr(grid[gi][kk])] for kk in keys]
        out = []
        for d in range(len(base)):
            lim = len(G[keys[d]])
            for step in (-1, 1):
                nb = list(base)
                nb[d] += step
                if 0 <= nb[d] < lim and tuple(nb) in pos:
                    out.append(pos[tuple(nb)])
        return out

    rows = []
    for k in ok[:int(q.get("top", 30))]:
        F = A[k]
        tr, te = _hstat(tr_sum[k]), _hstat(F[H_FOLDS - 1])
        nb = [x for x in neighbors(k) if tr_sum[x][0] >= max(5, min_n // 2)]
        nb_ex = [tr_sum[x][2] / tr_sum[x][0] for x in nb]
        nb_mean = float(np.mean(nb_ex)) if nb_ex else None
        robust = bool(nb_mean is not None and tr["exp_r"] and tr["exp_r"] > 0 and nb_mean > 0 and nb_mean >= 0.5 * tr["exp_r"])
        gi, si = k
        rows.append({"label": label(gi, si), "combo": {kk: v for kk, v in grid[gi].items() if not kk.startswith("_")},
                     "sl": grid[gi]["_sl"], "mb": grid[gi]["_mb"], "n": tr["n"], "wr": tr["wr"], "exp_r": tr["exp_r"],
                     "n_test": te["n"], "wr_test": te["wr"], "exp_test": te["exp_r"],
                     "folds": [_hstat(F[j]) for j in range(H_FOLDS)], "nb_mean": nb_mean, "nb_n": len(nb), "robust": robust,
                     "passed": bool(robust and te["exp_r"] is not None and te["exp_r"] > 0 and te["n"] >= max(5, min_n // 4))})
    # walk-forward: cari di fold 1..k (anchored), pakai angka terbaik di fold k+1
    wf = []
    for kk in range(2, H_FOLDS):
        mn = max(5, int(min_n * kk / (H_FOLDS - 1)))
        cand = [k for k, F in A.items() if F[:kk].sum(0)[0] >= mn]
        if not cand:
            wf.append({"train_folds": kk, "pick": None})
            continue
        best = max(cand, key=lambda k: score(A[k][:kk].sum(0)))
        tst = _hstat(A[best][kk])
        allt = np.array([A[k][kk] for k in cand]).sum(0)
        wf.append({"train_folds": kk, "pick": label(*best), "train": _hstat(A[best][:kk].sum(0)), "test": tst, "all_test": _hstat(allt)})
    wf_tot = np.zeros(3)
    for w in wf:
        if w.get("pick"):
            wf_tot += (w["test"]["n"], (w["test"]["wr"] or 0) * w["test"]["n"] / 100, (w["test"]["exp_r"] or 0) * w["test"]["n"])
    top10 = rows[:10]
    over = None
    if top10:
        a_tr = [r["exp_r"] for r in top10 if r["exp_r"] is not None]
        a_te = [r["exp_test"] for r in top10 if r["exp_test"] is not None]
        if a_tr and a_te:
            over = {"train": float(np.mean(a_tr)), "test": float(np.mean(a_te))}
    all_te = np.array([F[H_FOLDS - 1] for F in A.values()]).sum(0) if A else np.zeros(3)
    return {"hyper": True, "rows": rows, "walk": wf, "walk_total": _hstat(wf_tot), "overfit": over, "base_test": _hstat(all_te),
            "n_combos": len(grid), "full": state["full"], "sampled": state["sampled"], "n_ok": len(ok),
            "searched": {"sl": list(H_SL), "hold_h": list(H_HOLD_H)},
            "too_few": len(A) - len(ok), "symbols": state["used"], "skipped": state["skipped"][:20], "n_skipped": len(state["skipped"]),
            "candles": state["candles"], "folds": H_FOLDS, "obj": obj,
            "params": {k: v for k, v in q.items() if k != "components"} | {"components": q.get("components")},
            "breakeven": 100 / (1 + q["rr"]), "elapsed": round(time.time() - state["t0"], 1)}
