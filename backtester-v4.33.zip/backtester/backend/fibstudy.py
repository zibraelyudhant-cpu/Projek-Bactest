"""Studi Fibonacci: di setiap gelombang (swing low -> swing high, atau sebaliknya) Fibonacci ditarik otomatis, lalu
dicatat: harga berbalik di level berapa, seberapa sering limit di tiap level menang & seberapa jauh pantulannya,
dan kalau candle CLOSE menembus suatu level, seberapa sering akhirnya jadi BOS (struktur patah).

Fibonacci baru dianggap "digambar" setelah swing ujungnya terkonfirmasi (swing candle sesudahnya), jadi
semua kejadian (sentuh, isi limit, tembus) hanya dihitung sesudah itu: sama seperti menggambar di chart live.
"""
import math
import os
import time
import uuid

import numpy as np

from .data import TF_MS
from .indicators import atr, ema, pivots
from .mining import tf_series
from .pausable import PausableJobs

RET = [0.236, 0.382, 0.5, 0.618, 0.65, 0.705, 0.786, 0.886, 1.0]      # level limit entry (koreksi)
BRK = [0.236, 0.382, 0.5, 0.618, 0.65, 0.705, 0.786, 0.886]           # level "tembus" (close) -> BOS?
EXT = [1.13, 1.272, 1.414, 1.618]                                      # sejauh apa setelah BOS
TGT = [0.0, -0.272, -0.618]                                            # target TP pantulan
TGT_NAME = ["0", "-0.272", "-0.618"]
BINS = [0.0, 0.236, 0.382, 0.5, 0.618, 0.65, 0.705, 0.786, 0.886, 1.0]
REG = {1: "Bullish", -1: "Bearish", 0: "Sideways"}

BOK = [0.0, -0.05, -0.1, -0.13, -0.2, -0.272]          # level tembus breakout (di luar ujung range = 0)
BK_MOVE = 0.382                                         # breakout "lanjut" = bergerak lagi >= 0.382 x lebar range setelah tembus
B_EXT = np.round(np.arange(-3.0, 0.0001, 0.02), 2)      # extension terjauh setelah breakout (fibo, negatif)
K_ATR = [0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0]      # SL = level -/+ k x ATR TF eksekusi (uji respek)
B_PEN = np.arange(0, 5.0001, 0.05)                      # tusukan melewati level sebelum memantul (dalam ATR)
TLV = [0.236, 0.382, 0.5, 0.618, 0.705, 0.786, 0.886]       # level tembus untuk studi BOS / CHoCH (tren EMA)
TEXT = [0.13, 0.272, 0.414, 0.618]                           # sejauh apa lewat 0 setelah BOS (tampil -0.13 .. -0.618)
B_DEP = np.round(np.arange(0, 1.0001, 0.01), 2)              # kedalaman koreksi sebelum BOS
SCAN = np.round(np.arange(0.15, 0.9501, 0.01), 2)
BKS = np.round(np.arange(0.0, -0.3001, -0.01), 2)            # pemindaian level tembus breakout (di luar range)
SLOPE_CUT = (0.5, 1.0)                                        # kemiringan impuls (ATR/candle): landai < 0.5 <= sedang < 1.0 <= curam
SLOPE_NAME = ["landai", "sedang", "curam"]
FBIN = np.round(np.arange(-3.0, 2.5001, 0.01), 2)             # histogram halus level fibo           # pemindaian "angka rahasia" (hanya kalau p["scan"])
DEFAULTS = {"tf": "15m", "regime_tf": "4h", "trend_tf": "1h", "swing": 3, "min_leg_atr": 2.0, "adx_min": 20, "conf_tol_atr": 0.25,
            "sl_buffer_atr": 0.1, "max_bars": 300, "ema_fast": 50, "ema_slow": 200}


def regime_at(S, idx, adx_min):
    """+1 bullish (BOS naik, close > EMA50, ADX >= adx_min), -1 bearish, 0 sideways, None kalau data kurang."""
    if idx < 210:
        return None
    b, c, e, a = S["bos"][idx], S["c"][idx], S["e50"][idx], S["adx"][idx]
    if not np.isfinite(a) or not np.isfinite(e):
        return None
    if b > 0 and c > e and a >= adx_min:
        return 1
    if b < 0 and c < e and a >= adx_min:
        return -1
    return 0


def find_legs(h, l, swing):
    """Gelombang: (d, i_anchor, j_ujung). d=+1 naik (low i -> high j), d=-1 turun (high i -> low j).
    j harus titik ekstrem sejak anchor (benar-benar impulse)."""
    hi, lo = pivots(h, l, swing)
    legs = []
    for d, ends, anchors in ((1, hi, lo), (-1, lo, hi)):
        for j in ends:
            k = np.searchsorted(anchors, j) - 1
            if k < 0:
                continue
            i = anchors[k]
            if d > 0 and h[j] < h[i:j + 1].max() or d < 0 and l[j] > l[i:j + 1].min():
                continue
            legs.append((d, int(i), int(j)))
    legs.sort(key=lambda x: x[2])
    return legs


def _first(mask):
    if not len(mask):
        return None
    i = int(np.argmax(mask))
    return i if mask[i] else None


def study_bars(b, S_tf, reg_bars, S_reg, p, start=None, end=None, trend=None):
    """Studi satu koin. b = candle TF gelombang, S_tf = tf_series(b), reg_bars/S_reg = TF kondisi pasar.
    trend = (waktu candle TF tren, EMA50, EMA200) untuk studi BOS / CHoCH (bullish = EMA50 > EMA200)."""
    h, l, c, t = b.h, b.l, b.c, b.t
    n = len(c)
    dur, rdur = TF_MS[p["tf"]], TF_MS[p["regime_tf"]]
    sw, mb = int(p["swing"]), int(p["max_bars"])
    atr = S_tf["atr"]
    # konfluensi S/R flip: swing high lama yang sudah ditembus close (resistance -> support), atau swing low lama
    # yang sudah ditembus ke bawah (support -> resistance). brk[p] = candle pertama yang close menembus swing p.
    piv_hi, piv_lo = pivots(h, l, sw)
    def _breaks(piv, up):
        out = np.full(len(piv), n, np.int64)
        for q, pv in enumerate(piv):
            seg = c[pv + 1:pv + 2001]
            k_ = _first(seg > h[pv]) if up else _first(seg < l[pv])
            if k_ is not None:
                out[q] = pv + 1 + k_
        return out
    brk_hi, brk_lo = _breaks(piv_hi, True), _breaks(piv_lo, False)
    rows = {k: [] for k in ("t", "reg", "dir", "depth", "end", "fill", "R", "bounce", "bpct", "reach", "slw", "sll", "elig",
                            "rk", "pen", "conf",
                            "belig", "bout", "bbars", "ext", "bko", "bke", "tr", "tch", "trc", "bx", "trt", "sel", "stc", "srs",
                            "zsl", "zcd", "zbx", "zst", "zbk", "zbrt", "zfk")}
    scan = bool(p.get("scan"))
    tdur = TF_MS[p.get("trend_tf", "1h")]
    exs = []                                           # contoh kejadian (dibuka di Manual Replay)
    for d, i, j in find_legs(h, l, sw):
        c0 = j + sw                                    # candle konfirmasi swing ujung (fibo digambar saat close)
        if c0 >= n - 2 or not np.isfinite(atr[j]):
            continue
        if start is not None and t[c0] < start or end is not None and t[c0] > end:
            continue
        top, bot = (h[j], l[i]) if d > 0 else (h[i], l[j])
        rng = top - bot
        if rng <= 0 or rng < p["min_leg_atr"] * atr[j]:
            continue
        ridx = int(np.searchsorted(reg_bars.t, t[c0] + dur - rdur, side="right")) - 1
        reg = regime_at(S_reg, ridx, p["adx_min"])
        if reg is None:
            continue
        tr = 0
        if trend is not None:
            ti = int(np.searchsorted(trend[0], t[c0] + dur - tdur, side="right")) - 1   # candle TF tren yang sudah close
            if ti >= int(p.get("ema_slow", 200)) and np.isfinite(trend[1][ti]) and np.isfinite(trend[2][ti]):
                tr = 1 if trend[1][ti] > trend[2][ti] else -1 if trend[1][ti] < trend[2][ti] else 0
        P0 = top if d > 0 else bot
        lvl = lambda x: P0 - d * x * rng        # noqa: E731  harga level fibo x
        W = min(n, c0 + 1 + 2 * mb)
        cc = c[j + 1:W]
        # akhir gelombang: close tembus 0% (lanjut) atau close tembus 100% (BOS)
        k_cont = _first(d * (cc - P0) > 0)
        k_bos = _first(d * (lvl(1.0) - cc) > 0)
        k_cont = None if k_cont is None else k_cont + j + 1
        k_bos = None if k_bos is None else k_bos + j + 1
        cands = [x for x in (k_cont, k_bos) if x is not None and x <= c0 + mb]
        endk = min(cands) if cands else min(n - 1, c0 + mb)
        etype = 0 if endk == k_cont else 1 if endk == k_bos else 2
        if endk <= c0:                                 # selesai sebelum fibo sempat digambar
            continue
        seg_l, seg_h = l[j + 1:endk + 1], h[j + 1:endk + 1]
        depth = ((top - seg_l.min()) if d > 0 else (seg_h.max() - bot)) / rng
        pre_l, pre_h, pre_c = l[j + 1:c0 + 1], h[j + 1:c0 + 1], c[j + 1:c0 + 1]
        sl = lvl(1.0) - d * p["sl_buffer_atr"] * atr[j]

        fill = np.zeros(len(RET), bool)
        elig = np.zeros(len(RET), bool)
        R = np.full((len(RET), len(TGT)), np.nan, np.float32)
        WIN = np.zeros((len(RET), len(TGT)), np.int8)      # contoh kejadian: 1 TP, -1 SL, 0 belum selesai
        bounce = np.full(len(RET), np.nan, np.float32)
        reach = np.full(len(RET), np.nan, np.float32)      # level fibo terjauh yang dicapai pantulan sebelum SL
        bpct = np.full(len(RET), np.nan, np.float32)
        # uji SL: untuk tiap (TP kandidat, SL kandidat) apakah trade menang (TP dulu) atau kalah (SL dulu)
        slw = np.zeros((len(RET), len(TP_CAND), len(SLC)), bool)
        sll = np.zeros((len(RET), len(TP_CAND), len(SLC)), bool)
        fill_end = endk                                # limit aktif sampai candle yang mengakhiri gelombang
        rk = np.zeros((len(RET), len(K_ATR)), bool)    # respek: dari sentuhan, harga kembali ke 0 sebelum tembus level -/+ k ATR
        pen = np.full(len(RET), np.nan, np.float32)    # tusukan terdalam melewati level (ATR) sebelum memantul ke 0
        conf = np.zeros(len(RET), bool)                # level fibo bertemu S/R flip
        a_ex = atr[c0] if np.isfinite(atr[c0]) else atr[j]
        piv, brk, src = (piv_hi, brk_hi, h) if d > 0 else (piv_lo, brk_lo, l)
        q0, q1 = np.searchsorted(piv, j - 300), np.searchsorted(piv, j)
        flips = np.array([src[pv] for pv, bk in zip(piv[q0:q1], brk[q0:q1]) if bk <= c0 and bot < src[pv] < top])
        for a, x in enumerate(RET):
            if len(flips):
                conf[a] = bool((np.abs(flips - lvl(x)) <= p.get("conf_tol_atr", 0.25) * a_ex).any())
        for a, x in enumerate(RET):
            px = lvl(x)
            touched_pre = (pre_l.min() <= px) if d > 0 else (pre_h.max() >= px)
            if touched_pre or d * (c[c0] - px) <= 0:
                continue
            elig[a] = True
            fl = l[c0 + 1:fill_end + 1] if d > 0 else h[c0 + 1:fill_end + 1]
            k = _first(fl <= px) if d > 0 else _first(fl >= px)
            if k is None:
                continue
            k += c0 + 1
            fill[a] = True
            risk = d * (px - sl)
            if risk <= 0:
                continue
            e2 = min(n, k + 1 + mb)
            adv = (l[k:e2] if d > 0 else h[k:e2])
            isl = _first(adv <= sl) if d > 0 else _first(adv >= sl)
            isl = len(adv) if isl is None else isl     # indeks relatif dari k (0 = candle isi)
            fav = h[k + 1:e2] if d > 0 else l[k + 1:e2]
            for b_, tg in enumerate(TGT):
                tp = lvl(tg)
                it = _first(fav >= tp) if d > 0 else _first(fav <= tp)
                if it is not None and it + 1 < isl:
                    R[a, b_] = d * (tp - px) / risk
                    WIN[a, b_] = 1
                elif isl < len(adv):
                    R[a, b_] = -1.0
                    WIN[a, b_] = -1
                else:                                  # belum selesai di akhir jendela: nilai pasar
                    R[a, b_] = max(-1.0, min(d * (c[e2 - 1] - px) / risk, d * (tp - px) / risk))
            mx = fav[:max(0, isl - 1)]
            best = (mx.max() - px) if d > 0 and len(mx) else (px - mx.min()) if len(mx) else 0.0
            bounce[a] = max(0.0, best) / risk
            bpct[a] = max(0.0, best) / px * 100
            reach[a] = x - max(0.0, best) / rng
            # koordinat fibo per candle sejak terisi: adv = sejauh apa melawan (makin besar makin dalam),
            # fv = sejauh apa searah (makin kecil makin dekat / lewat ujung koreksi)
            if d > 0:
                adv_c = np.maximum.accumulate((P0 - l[k:e2]) / rng)
                fav_c = np.minimum.accumulate((P0 - h[k + 1:e2]) / rng) if e2 > k + 1 else np.zeros(0)
            else:
                adv_c = np.maximum.accumulate((h[k:e2] - P0) / rng)
                fav_c = np.minimum.accumulate((l[k + 1:e2] - P0) / rng) if e2 > k + 1 else np.zeros(0)
            # respek ke 0 dengan SL = level -/+ k ATR, dan tusukan sebelum memantul (struktur tidak boleh patah dulu)
            it0 = int(np.searchsorted(-fav_c, 0.0, side="left")) if len(fav_c) else 0
            if it0 < len(fav_c):
                cl = ((P0 - c[k:k + it0 + 2]) / rng) if d > 0 else ((c[k:k + it0 + 2] - P0) / rng)
                if not (cl >= 1.0).any():                   # tidak close tembus 1.0 sebelum kembali ke 0
                    mae0 = adv_c[min(it0 + 1, len(adv_c) - 1)]
                    pen[a] = max(0.0, (mae0 - x) * rng / a_ex)
                    rk[a] = pen[a] < np.array(K_ATR)
            slc = np.array(SLC)
            for ti, tg in enumerate(TP_CAND):
                if tg >= x:
                    continue
                it = int(np.searchsorted(-fav_c, -tg, side="left")) if len(fav_c) else 0   # candle (dari k+1) TP tercapai
                hit = it < len(fav_c)
                mae = adv_c[min(it + 1, len(adv_c) - 1)] if hit else adv_c[-1]           # terdalam sampai candle TP
                ok = slc > x
                slw[a, ti] = ok & hit & (mae < slc)
                sll[a, ti] = ok & (mae >= slc)

        belig = np.zeros(len(BRK), bool)
        bout = np.full(len(BRK), -1, np.int8)          # 1 = jadi BOS, 0 = palsu (lanjut high baru), -1 = belum jelas
        bbars = np.full(len(BRK), np.nan, np.float32)
        for a, x in enumerate(BRK):
            px = lvl(x)
            if (d * (pre_c - px) <= 0).any() or d * (c[c0] - px) <= 0:
                continue
            belig[a] = True
            last = endk - 1 if etype == 1 else endk   # tembus di candle BOS itu sendiri = bukan tanda awal
            k = _first(d * (px - c[c0 + 1:last + 1]) > 0)
            if k is None:
                continue
            k += c0 + 1
            if k_bos is not None and (k_cont is None or k_bos < k_cont) and k_bos >= k:
                bout[a], bbars[a] = 1, k_bos - k
            elif k_cont is not None and k_cont > k:
                bout[a] = 0
            else:
                bout[a] = 2                            # tembus tapi belum ada BOS / high baru di jendela
        ext = np.nan
        if k_bos is not None and k_bos <= c0 + mb:
            e2 = min(n, k_bos + 1 + mb)
            back = _first(d * (c[k_bos + 1:e2] - lvl(1.0)) > 0)   # close balik ke dalam struktur = BOS gagal, stop
            e2 = e2 if back is None else k_bos + 1 + back + 1
            if d > 0:
                ext = (top - l[k_bos:e2].min()) / rng
            else:
                ext = (h[k_bos:e2].max() - bot) / rng
        # breakout ujung range: candle CLOSE tembus level x (di luar 0) -> lanjut sampai BK_TGT, atau palsu
        # (close balik ke dalam range, di bawah 0 untuk BUY) dulu? Dipakai untuk pasang buy stop / sell stop.
        bko = np.zeros(len(BOK), np.int8)              # 0 = tidak tembus, 1 = lanjut, 2 = palsu, 3 = belum jelas
        bke = np.full(len(BOK), np.nan, np.float32)    # extension terjauh setelah tembus, sebelum balik ke dalam range
        for a, x in enumerate(BOK):
            px = lvl(x)
            if d * (c[c0] - px) > 0:
                continue                               # sudah di luar saat fibo digambar
            k = _first(d * (c[c0 + 1:W] - px) > 0)
            if k is None:
                continue
            k += c0 + 1
            e2 = min(n, k + 1 + mb)
            back = _first(d * (c[k + 1:e2] - P0) < 0)
            fv = h[k + 1:e2] if d > 0 else l[k + 1:e2]
            tgt = lvl(x - BK_MOVE)                     # jarak yang sama untuk semua level tembus (adil dibandingkan)
            hit = _first(fv >= tgt) if d > 0 else _first(fv <= tgt)
            bko[a] = 1 if hit is not None and (back is None or hit <= back) else 2 if back is not None else 3
            seg = fv[:back + 1] if back is not None else fv
            far = max(h[k], seg.max()) if d > 0 and len(seg) else (min(l[k], seg.min()) if len(seg) else (h[k] if d > 0 else l[k]))
            bke[a] = (P0 - far) / rng if d > 0 else (far - P0) / rng
        # BOS / CHoCH searah tren EMA: gelombang searah tren, lalu koreksi.
        # tch: close tembus level x (melawan tren) -> akhirnya CHoCH (close tembus 1.0) atau BOS (close tembus 0)?
        # trc: setelah tembus x, close balik melewati x (searah tren) -> akhirnya BOS atau CHoCH?
        # pemindaian angka 0.15 .. 0.95: setelah fibo digambar, harga menyentuh level itu? kalau ya, memantul sampai 0
        # (ujung swing) sebelum ada candle CLOSE tembus level itu? = respek
        sel = stc = srs = None
        if scan:
            pxs = P0 - d * SCAN * rng
            pre_ext = pre_l.min() if d > 0 else pre_h.max()
            sel = (d * (pre_ext - pxs) > 0) & (d * (c[c0] - pxs) > 0)
            w0, w1 = c0 + 1, min(n, c0 + 1 + mb)
            if w1 > w0:
                if d > 0:
                    ext_run, cls_run = np.minimum.accumulate(l[w0:w1]), np.minimum.accumulate(c[w0:w1])
                    it = np.searchsorted(-ext_run, -pxs, side="left")          # candle pertama low <= level
                    ic = np.searchsorted(-cls_run, -pxs, side="right")         # candle pertama close < level
                    hit0 = np.flatnonzero(h[w0:w1] >= P0)
                else:
                    ext_run, cls_run = np.maximum.accumulate(h[w0:w1]), np.maximum.accumulate(c[w0:w1])
                    it = np.searchsorted(ext_run, pxs, side="left")
                    ic = np.searchsorted(cls_run, pxs, side="right")
                    hit0 = np.flatnonzero(l[w0:w1] <= P0)
                L_ = w1 - w0
                stc = sel & (it < L_) & (it <= endk - w0)                    # disentuh sebelum gelombang selesai
                if len(hit0):
                    nxt = np.searchsorted(hit0, it, side="right")            # sampai 0 sesudah candle sentuh
                    i0 = np.where(nxt < len(hit0), hit0[np.minimum(nxt, len(hit0) - 1)], L_)
                else:
                    i0 = np.full(len(SCAN), L_)
                srs = stc & (i0 < ic)
            else:
                stc = srs = np.zeros(len(SCAN), bool)
        tch = np.full(len(TLV), -1, np.int8)
        trc = np.full(len(TLV), -1, np.int8)
        trt = np.full(len(TLV), np.nan, np.float32)    # retest: level fibo terdekat ke 0 yang dicapai setelah tembus, sebelum CHoCH
        bx = np.nan
        if tr != 0 and d == tr:
            res = {0: 0, 1: 1, 2: 2}[etype]                     # 0 = BOS, 1 = CHoCH, 2 = belum jelas
            for a, x in enumerate(TLV):
                px = lvl(x)
                if (d * (pre_c - px) <= 0).any() or d * (c[c0] - px) <= 0:
                    continue
                seg = c[c0 + 1:endk]                           # candle penentu (endk) tidak dihitung
                k = _first(d * (px - seg) > 0)
                if k is None:
                    continue
                tch[a] = res
                if etype == 1:                                 # berakhir CHoCH: sebelum itu harga balik (retest) sampai mana?
                    kk = c0 + 1 + k
                    if endk > kk + 1:
                        rt = ((top - h[kk + 1:endk].max()) if d > 0 else (l[kk + 1:endk].min() - bot)) / rng
                    else:
                        rt = 1.0                               # langsung CHoCH di candle berikutnya
                    trt[a] = min(max(rt, 0.0), 0.9999)
                r_ = _first(d * (seg[k + 1:] - px) > 0)
                if r_ is not None:
                    trc[a] = res
            if etype == 0:                                     # sejauh apa setelah BOS (sampai CHoCH / max_bars)
                e2 = min(n, k_cont + 1 + mb)
                back = _first(d * (lvl(1.0) - c[k_cont + 1:e2]) > 0)
                e2 = e2 if back is None else k_cont + 1 + back
                bx = ((h[k_cont:e2].max() - top) if d > 0 else (bot - l[k_cont:e2].min())) / rng
        if scan:
            # kemiringan impuls: ATR per candle (0 landai, 1 sedang, 2 curam)
            spd = rng / atr[j] / max(1, j - i)
            zsl = 0 if spd < SLOPE_CUT[0] else 1 if spd < SLOPE_CUT[1] else 2
            # close terdalam sebelum gelombang selesai (candle penentu tidak dihitung)
            cs = c[j + 1:endk] if endk > j + 1 else c[j + 1:j + 2]
            zcd = float(((top - cs.min()) if d > 0 else (cs.max() - bot)) / rng)
            # sejauh apa setelah BOS (sampai close tembus 1 / max_bars), sebagai level fibo negatif
            zbx = zst = np.nan
            if etype == 0:
                e2 = min(n, k_cont + 1 + mb)
                back = _first(d * (lvl(1.0) - c[k_cont + 1:e2]) > 0)
                e2 = e2 if back is None else k_cont + 1 + back
                zbx = -float(((h[k_cont:e2].max() - top) if d > 0 else (bot - l[k_cont:e2].min())) / rng)
                # dorongan pertama habis: titik ekstrem sebelum harga koreksi >= 0.382 x lebar swing dari ekstrem itu
                if d > 0:
                    run_ = np.maximum.accumulate(h[k_cont:e2])
                    kk_ = _first(l[k_cont:e2] <= run_ - BK_MOVE * rng)
                    if kk_ is not None:
                        zst = -float((run_[kk_] - top) / rng)
                else:
                    run_ = np.minimum.accumulate(l[k_cont:e2])
                    kk_ = _first(h[k_cont:e2] >= run_ + BK_MOVE * rng)
                    if kk_ is not None:
                        zst = -float((bot - run_[kk_]) / rng)
            # breakout ujung range (hanya sideways): close tembus level y -> lanjut (BK_MOVE) atau palsu; dan retest
            # setelah breakout valid di 0: harga balik sampai level berapa sebelum lanjut
            zbk = np.zeros(len(BKS), np.int8)
            zbrt = zfk = np.nan
            if reg == 0:
                cw = c[c0 + 1:W]
                run = np.maximum.accumulate(cw) if d > 0 else np.minimum.accumulate(cw)
                pys = P0 - d * BKS * rng
                if d * (c[c0] - P0) <= 0:
                    first = (np.searchsorted(run, pys, side="right") if d > 0 else np.searchsorted(-run, -pys, side="right"))
                    for a, y in enumerate(BKS):
                        k = int(first[a])
                        if k >= len(cw):
                            continue
                        k += c0 + 1
                        e2 = min(n, k + 1 + mb)
                        back = _first(d * (c[k + 1:e2] - P0) < 0)
                        fv = h[k + 1:e2] if d > 0 else l[k + 1:e2]
                        tgt = lvl(y - BK_MOVE)
                        hit = _first(fv >= tgt) if d > 0 else _first(fv <= tgt)
                        ok = hit is not None and (back is None or hit <= back)
                        zbk[a] = 1 if ok else 2 if back is not None else 3
                        if a == 0 and ok:
                            seg = l[k + 1:k + 2 + hit] if d > 0 else h[k + 1:k + 2 + hit]
                            if len(seg):
                                zbrt = float(((P0 - seg.min()) if d > 0 else (seg.max() - P0)) / rng)
                        if a == 0 and not ok and back is not None:
                            # gagal breakout: close balik ke dalam range -> lari balik sampai mana sebelum coba breakout lagi
                            kb = k + 1 + back
                            e3 = min(n, kb + 1 + mb)
                            again = _first(d * (c[kb + 1:e3] - P0) > 0)      # berhenti saat close tembus 0 lagi
                            e3 = e3 if again is None else kb + 1 + again
                            zfk = float(((P0 - l[kb:e3].min()) if d > 0 else (h[kb:e3].max() - P0)) / rng)
            for key, v in (("sel", sel), ("stc", stc), ("srs", srs), ("zsl", zsl), ("zcd", zcd), ("zbx", zbx), ("zst", zst),
                           ("zbk", zbk), ("zbrt", zbrt), ("zfk", zfk)):
                rows[key].append(v)
        exs.append({"t": int(t[c0]), "t0": int(t[i]), "t_end": int(t[endk]), "dir": int(d), "reg": int(reg), "top": float(top), "bot": float(bot),
                    "depth": round(float(depth), 3), "end": int(etype), "sl": float(sl),
                    "fill": [bool(x) for x in fill], "elig": [bool(x) for x in elig], "R": [[None if not np.isfinite(v) else round(float(v), 2) for v in rr] for rr in R], "W": WIN.tolist()})
        for key, v in (("tr", tr), ("tch", tch), ("trc", trc), ("bx", bx), ("trt", trt), ("t", int(t[c0])), ("reg", reg), ("dir", d), ("depth", depth), ("end", etype),
                       ("fill", fill), ("R", R), ("bounce", bounce), ("bpct", bpct), ("reach", reach), ("slw", slw), ("sll", sll), ("rk", rk), ("pen", pen), ("conf", conf), ("elig", elig),
                       ("belig", belig), ("bout", bout), ("bbars", bbars), ("ext", ext), ("bko", bko), ("bke", bke)):
            rows[key].append(v)
    if not rows["t"]:
        return None
    out = {k: np.array(v) for k, v in rows.items()}
    out["t"] = out["t"].astype(np.int64)
    out["ex"] = exs
    return out


EX_PER_GROUP = 60          # contoh kejadian yang disimpan per kelompok (kondisi pasar x arah), yang paling baru


def pick_examples(exs, sym=None, keep=None):
    """Simpan contoh terbaru per kelompok (kondisi pasar, arah) supaya tiap kelompok punya contoh untuk dicek di chart."""
    keep = keep or EX_PER_GROUP
    by = {}
    for e in exs:
        if sym is not None:
            e = {**e, "symbol": sym}
        by.setdefault((e["reg"], e["dir"]), []).append(e)
    out = []
    for v in by.values():
        out += sorted(v, key=lambda e: -e["t"])[:keep]
    return sorted(out, key=lambda e: -e["t"])


def study_symbol(store, sym, p, start=None, end=None):
    """Data per gelombang satu koin (dipakai tes & analisa satu koin)."""
    p = {**DEFAULTS, **(p or {})}
    b = store.get(sym, p["tf"])
    rb = store.get(sym, p["regime_tf"])
    tb = store.get(sym, p["trend_tf"])
    tc = np.asarray(tb.c, float)
    trend = (np.asarray(tb.t), ema(tc, int(p.get("ema_fast", 50))), ema(tc, int(p.get("ema_slow", 200))))
    return study_bars(b, {"atr": atr(b.h, b.l, b.c, 14)}, rb, tf_series(rb), p, start, end, trend)


# ------------------------------------------------------------------ ringkas per bulan (hemat memori)
# Hasil tiap koin langsung diringkas jadi HITUNGAN per (bulan, kelompok). Ribuan koin x jutaan gelombang tetap
# kecil di memori, dan pembagian data latih / uji tetap bisa dilakukan per bulan.
GROUPS = [(1, 1), (1, -1), (-1, 1), (-1, -1), (0, 1), (0, -1)]     # (kondisi pasar, arah gelombang)
GKEY = ["bull_up", "bull_down", "bear_up", "bear_down", "side_up", "side_down"]
B_BOUNCE = np.arange(0, 10.0001, 0.1)       # pantulan dalam R
B_PCT = np.arange(0, 20.0001, 0.1)          # pantulan dalam %
SLC = [0.886, 0.94, 1.0, 1.05, 1.13, 1.2, 1.272, 1.414, 1.618, 2.0]   # kandidat SL (level fibo di luar entry)
B_REACH = np.round(np.arange(-1.0, 1.0001, 0.01), 2)   # level fibo terjauh yang dicapai pantulan (0 = ujung gelombang)
TP_CAND = [0.618, 0.5, 0.382, 0.236, 0.0, -0.272, -0.414, -0.618]   # kandidat TP (level fibo)
ZONES = ((0.236, 0.382), (0.382, 0.5), (0.5, 0.618), (0.618, 0.786), (0.786, 1.0))   # zona tempat pullback berhenti
B_BARS = np.arange(0, 302, 2)               # candle sampai BOS


def _hist(x, edges):
    x = x[np.isfinite(x)]
    return np.histogram(np.clip(x, edges[0], edges[-1] - 1e-9), bins=edges)[0]


def _empty():
    G, L, T, K, E = len(GROUPS), len(RET), len(TGT), len(BRK), len(EXT)
    z = lambda *sh: np.zeros(sh, np.int64)   # noqa: E731
    return {"n": z(G), "turn": z(G, len(BINS) - 1), "end": z(G, 3), "touch": z(G, L), "fill": z(G, L),
            "rcnt": z(G, L, T), "rwin": z(G, L, T), "rsum": np.zeros((G, L, T)),
            "bnc": z(G, L, len(B_BOUNCE) - 1), "bpct": z(G, L, len(B_PCT) - 1), "reach": z(G, L, len(B_REACH) - 1),
            "slw": z(G, L, len(TP_CAND), len(SLC)), "sll": z(G, L, len(TP_CAND), len(SLC)),
            "rk": z(G, L, len(K_ATR)), "rkc": z(G, L, len(K_ATR)), "ntc": z(G, L),
            "bkn": z(G, len(BOK)), "bkok": z(G, len(BOK)), "bkf": z(G, len(BOK)), "bke": z(G, len(BOK), len(B_EXT) - 1),
            "pen": z(G, L, len(B_PEN) - 1), "penc": z(G, L, len(B_PEN) - 1), "reachc": z(G, L, len(B_REACH) - 1),
            "belig": z(G, K), "broke": z(G, K), "bos": z(G, K), "fake": z(G, K), "bbars": z(G, K, len(B_BARS) - 1),
            "ext_n": z(G), "ext": z(G, E),
            # studi tren EMA: indeks 0 = bullish (BUY), 1 = bearish (SELL); tidak ikut _sum per kelompok
            "t_n": z(2), "t_end": z(2, 3), "t_dep": z(2, len(B_DEP) - 1), "t_cb": z(2, len(TLV)), "t_cc": z(2, len(TLV)),
            "t_cs": z(2, len(TLV)), "t_rn": z(2, len(TLV)), "t_rb": z(2, len(TLV)), "t_rc": z(2, len(TLV)),
            "t_cxn": z(2), "t_cx": z(2, E), "t_bxn": z(2), "t_bx": z(2, len(TEXT)),
            "t_rt": z(2, len(TLV), len(B_DEP) - 1),
            "s_el": z(G, len(SCAN)), "s_tc": z(G, len(SCAN)), "s_rs": z(G, len(SCAN)),
            "z_dw": z(G, 3, 3, len(FBIN) - 1), "z_dc": z(G, 3, len(FBIN) - 1), "z_bx": z(G, 3, len(FBIN) - 1), "z_st": z(G, 3, len(FBIN) - 1),
            "z_bk": z(G, 3, len(BKS)), "z_brt": z(G, 3, len(FBIN) - 1), "z_fk": z(G, 3, len(FBIN) - 1), "z_n": z(G, 3)}


def aggregate(r):
    """Gelombang satu koin -> {bulan: hitungan}. bulan = tahun*12 + bulan (UTC)."""
    if r is None or not len(r["t"]):
        return {}
    mon = (r["t"] // 1000).astype("datetime64[s]").astype("datetime64[M]").astype(np.int64)
    out = {}
    for mo in np.unique(mon):
        a = _empty()
        for si, tv in enumerate((1, -1)):
            m = (mon == mo) & (r["tr"] == tv) & (r["dir"] == tv)
            if not m.any():
                continue
            end, tch, trc = r["end"][m], r["tch"][m], r["trc"][m]
            a["t_n"][si] = m.sum()
            a["t_end"][si] = [(end == 0).sum(), (end == 1).sum(), (end == 2).sum()]
            a["t_dep"][si] = _hist(r["depth"][m][end == 0], B_DEP)
            a["t_cb"][si], a["t_cc"][si], a["t_cs"][si] = (tch >= 0).sum(0), (tch == 1).sum(0), (tch == 0).sum(0)
            a["t_rn"][si], a["t_rb"][si], a["t_rc"][si] = (trc >= 0).sum(0), (trc == 0).sum(0), (trc == 1).sum(0)
            for k_ in range(len(TLV)):
                a["t_rt"][si, k_] = _hist(r["trt"][m][:, k_], B_DEP)
            ext = r["ext"][m][end == 1]                       # hanya yang benar-benar berakhir CHoCH
            ext = ext[np.isfinite(ext)]
            a["t_cxn"][si] = len(ext)
            a["t_cx"][si] = [(ext >= x).sum() for x in EXT]
            bx = r["bx"][m]
            bx = bx[np.isfinite(bx)]
            a["t_bxn"][si] = len(bx)
            a["t_bx"][si] = [(bx >= x).sum() for x in TEXT]
        for g, (reg, d) in enumerate(GROUPS):
            m = (mon == mo) & (r["reg"] == reg) & (r["dir"] == d)
            if not m.any():
                continue
            a["n"][g] = m.sum()
            if len(r.get("sel", [])) == len(r["t"]):
                a["s_el"][g], a["s_tc"][g], a["s_rs"][g] = r["sel"][m].sum(0), r["stc"][m].sum(0), r["srs"][m].sum(0)
                zsl, dep_, end_ = r["zsl"][m], r["depth"][m], r["end"][m]
                for sv in range(3):
                    ms_ = zsl == sv
                    a["z_n"][g, sv] = ms_.sum()
                    for e_ in range(3):
                        a["z_dw"][g, sv, e_] = _hist(dep_[ms_ & (end_ == e_)], FBIN)
                    a["z_bx"][g, sv] = _hist(r["zbx"][m][ms_], FBIN)
                    a["z_st"][g, sv] = _hist(r["zst"][m][ms_], FBIN)
                    a["z_brt"][g, sv] = _hist(r["zbrt"][m][ms_], FBIN)
                    a["z_fk"][g, sv] = _hist(r["zfk"][m][ms_], FBIN)
                for e_ in range(3):
                    a["z_dc"][g, e_] = _hist(r["zcd"][m][end_ == e_], FBIN)
                bk_ = r["zbk"][m]
                a["z_bk"][g] = [(bk_ > 0).sum(0), (bk_ == 1).sum(0), (bk_ == 2).sum(0)]
            depth, end = r["depth"][m], r["end"][m]
            cont = end == 0
            a["turn"][g] = np.histogram(np.clip(depth[cont], 0, 0.9999), bins=BINS)[0]
            a["end"][g] = [cont.sum(), (end == 1).sum(), (end == 2).sum()]
            a["touch"][g] = [(depth >= x).sum() for x in RET]
            fill = r["fill"][m]
            a["fill"][g] = fill.sum(0)
            bo_ = r["bko"][m]
            a["bkn"][g] = (bo_ > 0).sum(0)
            a["bkok"][g] = (bo_ == 1).sum(0)
            a["bkf"][g] = (bo_ == 2).sum(0)
            for k_ in range(len(BOK)):
                a["bke"][g, k_] = _hist(r["bke"][m][bo_[:, k_] > 0, k_], B_EXT)
            cf = r["conf"][m] & fill                        # sentuhan yang bertemu S/R flip
            a["rk"][g] = r["rk"][m].sum(0)
            a["rkc"][g] = (r["rk"][m] & cf[:, :, None]).sum(0)
            a["ntc"][g] = cf.sum(0)
            for k_ in range(len(RET)):
                pk = r["pen"][m][:, k_]
                a["pen"][g, k_] = _hist(pk[fill[:, k_]], B_PEN)
                a["penc"][g, k_] = _hist(pk[cf[:, k_]], B_PEN)
                a["reachc"][g, k_] = _hist(r["reach"][m][:, k_][cf[:, k_]], B_REACH)
            a["slw"][g] = r["slw"][m].sum(0)
            a["sll"][g] = r["sll"][m].sum(0)
            R = r["R"][m]
            fin = np.isfinite(R) & fill[:, :, None]
            a["rcnt"][g] = fin.sum(0)
            a["rwin"][g] = (fin & (np.nan_to_num(R) > 0)).sum(0)
            a["rsum"][g] = np.where(fin, np.nan_to_num(R), 0).sum(0)
            for k in range(len(RET)):
                f = fill[:, k]
                a["bnc"][g, k] = _hist(r["bounce"][m][f, k], B_BOUNCE)
                a["bpct"][g, k] = _hist(r["bpct"][m][f, k], B_PCT)
                a["reach"][g, k] = _hist(r["reach"][m][f, k], B_REACH)
            bo = r["bout"][m]
            a["belig"][g] = r["belig"][m].sum(0)
            a["broke"][g] = ((bo == 0) | (bo == 1) | (bo == 2)).sum(0)
            a["bos"][g] = (bo == 1).sum(0)
            a["fake"][g] = (bo == 0).sum(0)
            for k in range(len(BRK)):
                a["bbars"][g, k] = _hist(r["bbars"][m][bo[:, k] == 1, k], B_BARS)
            ext = r["ext"][m]
            ext = ext[np.isfinite(ext)]
            a["ext_n"][g] = len(ext)
            a["ext"][g] = [(ext >= x).sum() for x in EXT]
        out[int(mo)] = a
    return out


def merge_agg(a, b):
    """Jumlahkan hitungan dua hasil (antar koin)."""
    for mo, v in b.items():
        if mo not in a:
            a[mo] = v
        else:
            for k in v:
                a[mo][k] = a[mo][k] + v[k]
    return a


def _sum(agg, months, groups=None):
    """Jumlahkan hitungan beberapa bulan; groups = indeks kelompok (None = semua), hasil tanpa dimensi kelompok."""
    out = None
    for mo in months:
        a = agg[mo]
        s = {k: (v.sum(0) if groups is None else v[groups].sum(0)) for k, v in a.items() if not k.startswith("t_")}
        out = s if out is None else {k: out[k] + s[k] for k in s}
    if out is None:
        out = {k: v.sum(0) * 0 for k, v in _empty().items() if not k.startswith("t_")}
    return out


def _pct(x, n):
    return float(100 * x / n) if n else 0.0


def _median_hist(h, edges):
    tot = h.sum()
    if not tot:
        return None
    i = int(np.searchsorted(np.cumsum(h), tot / 2))
    return float((edges[i] + edges[i + 1]) / 2)


def _table(s):
    """Statistik satu kelompok dari hitungan s (hasil _sum)."""
    n = int(s["n"])
    out = {"n": n}
    if not n:
        return out
    out["turn"] = [{"lo": BINS[i], "hi": BINS[i + 1], "n": int(s["turn"][i]), "pct": _pct(s["turn"][i], n)}
                   for i in range(len(BINS) - 1)]
    out["end"] = {"cont": _pct(s["end"][0], n), "bos": _pct(s["end"][1], n), "timeout": _pct(s["end"][2], n)}
    lv = []
    for a, x in enumerate(RET):
        row = {"level": x, "touch": _pct(s["touch"][a], n), "fill": _pct(s["fill"][a], n), "filled": int(s["fill"][a])}
        for b_, name in enumerate(TGT_NAME):
            c = s["rcnt"][a, b_]
            row["wr_" + name] = float(100 * s["rwin"][a, b_] / c) if c else None
            row["r_" + name] = float(s["rsum"][a, b_] / c) if c else None
            row["rl_" + name] = float(s["rsum"][a, b_] / n)
        row["bounce_r"] = _median_hist(s["bnc"][a], B_BOUNCE)
        row["bounce_pct"] = _median_hist(s["bpct"][a], B_PCT)
        if "reach" in s:   # peluang pantulan sampai tiap level fibo (sebelum kena SL)
            h = s["reach"][a]
            tot = h.sum()
            cum = np.cumsum(h)
            row["tp"] = [{"level": f, "pct": _pct(cum[max(0, int(np.searchsorted(B_REACH, f + 1e-9)) - 1)], tot)}
                         for f in TP_CAND if f < x - 1e-9] if tot else []
            row["reach_med"] = _median_hist(h, B_REACH)
        lv.append(row)
    out["levels"] = lv
    if "rk" in s:
        out["strength"] = _strength(s, n)
    if "bkn" in s:
        out["breakout"] = [{"level": x, "broke": int(s["bkn"][a]), "broke_pct": _pct(s["bkn"][a], n),
                            "ok_pct": _pct(s["bkok"][a], s["bkn"][a]), "fake_pct": _pct(s["bkf"][a], s["bkn"][a]),
                            "ext_med": _median_hist(s["bke"][a], B_EXT)} for a, x in enumerate(BOK)]
    br = []
    for a, x in enumerate(BRK):
        nb, el = int(s["broke"][a]), int(s["belig"][a])
        nbos, nfake = int(s["bos"][a]), int(s["fake"][a])
        br.append({"level": x, "eligible": el, "broke": nb, "broke_pct": _pct(nb, el), "bos_pct": _pct(nbos, nb),
                   "fake_pct": _pct(nfake, nb), "open_pct": _pct(nb - nbos - nfake, nb),
                   "bars_med": _median_hist(s["bbars"][a], B_BARS)})
    out["breaks"] = br
    en = int(s["ext_n"])
    out["after_bos"] = {"n": en, "reach": [{"level": x, "pct": _pct(s["ext"][k], en)} for k, x in enumerate(EXT)]}
    return out


def _pctl(h, edges, q):
    tot = h.sum()
    if not tot:
        return None
    i = int(np.searchsorted(np.cumsum(h), q * tot))
    return float(edges[min(i + 1, len(edges) - 1)])


def _strength(s, n):
    """Kekuatan tiap level: seberapa sering di-retest, seberapa sering respek (memantul ke 0), dengan/tanpa S/R flip,
    seberapa dalam harga menusuk level sebelum memantul (ATR), dan rata-rata pantulan."""
    out = []
    for a, x in enumerate(RET):
        if x >= 1.0:
            continue
        nt, nc = int(s["fill"][a]), int(s["ntc"][a])
        p80 = _pctl(s["pen"][a], B_PEN, 0.8)
        k_rec = next((k for k in K_ATR if p80 is not None and k >= p80), K_ATR[-1])
        ki = K_ATR.index(k_rec)
        resp = [float(100 * s["rk"][a, i] / nt) if nt else None for i in range(len(K_ATR))]
        rcs = [float(100 * s["rkc"][a, i] / nc) if nc else None for i in range(len(K_ATR))]
        rns = [float(100 * (s["rk"][a, i] - s["rkc"][a, i]) / (nt - nc)) if nt > nc else None for i in range(len(K_ATR))]
        rc, rn = rcs[ki], rns[ki]
        out.append({"level": x, "retest": _pct(nt, n), "n": nt, "conf_n": nc, "conf_share": _pct(nc, nt),
                    "respect": resp, "respect_conf_k": rcs, "respect_noconf_k": rns, "touch": _pct(s["touch"][a], n), "k_rec": k_rec, "respect_rec": resp[ki], "respect_conf": rc, "respect_noconf": rn,
                    "pen50": _pctl(s["pen"][a], B_PEN, 0.5), "pen80": p80, "pen90": _pctl(s["pen"][a], B_PEN, 0.9),
                    "reach_med": _median_hist(s["reach"][a], B_REACH) if "reach" in s else None,
                    "reach_med_conf": _median_hist(s["reachc"][a], B_REACH),
                    "score": (_pct(nt, n) * resp[ki] / 100) if resp[ki] is not None else 0.0})
    return out


def power_summary(g):
    """Ringkasan kekuatan untuk kesimpulan (tanpa RR):
    - zona tempat pullback paling sering berhenti (histogram titik balik);
    - SL oke = level -/+ k x ATR TF eksekusi, k = tusukan 80% pantulan (median dari level 0.382 .. sebelum alarm);
    - level terkuat = paling sering tersentuh x paling sering respek (pantul ke 0) pada SL k yang sama;
    - pengaruh konfluensi S/R flip, rata-rata pantulan, dan cek ulang di data uji."""
    st = g.get("strength")
    if not st or g.get("n", 0) < 30:
        return None
    alarm = ((g.get("advice") or {}).get("alarm") or {}).get("level", 1.0)
    cand = [r for r in st if 0.382 <= r["level"] < alarm and r["n"] >= 30 and r["pen80"] is not None]
    if not cand:
        return None
    k = next((x for x in K_ATR if x >= float(np.median([r["pen80"] for r in cand]))), K_ATR[-1])
    ki = K_ATR.index(k)
    for r in cand:
        r["score_k"] = r["touch"] * (r["respect"][ki] or 0) / 100
    best = max(cand, key=lambda r: r["score_k"])
    zones = []
    for lo, hi in ZONES:
        pc = sum(t["pct"] for t in g.get("turn", []) if t["lo"] >= lo - 1e-9 and t["hi"] <= hi + 1e-9)
        zones.append({"lo": lo, "hi": hi, "pct": pc})
    zone = max(zones, key=lambda z: z["pct"]) if zones else None
    tst = next((r for r in (g.get("test") or {}).get("strength", []) if r["level"] == best["level"]), None)
    rows = [{"level": r["level"], "touch": r["touch"], "respect": r["respect"][ki], "respect_conf": r["respect_conf_k"][ki],
             "respect_noconf": r["respect_noconf_k"][ki], "conf_n": r["conf_n"], "n": r["n"], "pen80": r["pen80"],
             "reach_med": r["reach_med"], "reach_med_conf": r["reach_med_conf"], "score": r["score_k"]} for r in cand]
    out = {"k": k, "best": next(x for x in rows if x["level"] == best["level"]), "rows": rows, "zone": zone, "zones": zones,
           "alarm": alarm,
           "test_respect": tst["respect"][ki] if tst and tst["n"] >= 20 else None, "test_n": tst["n"] if tst else 0}
    conf = [x for x in rows if x["conf_n"] >= 20 and x["respect_conf"] is not None]
    if conf:
        out["best_conf"] = max(conf, key=lambda x: x["respect_conf"])
    return out


def breakout_summary(g):
    """Level tembus untuk buy stop / sell stop: level terdekat dari ujung range yang setelah candle close menembusnya,
    >= 70% lanjut (bergerak lagi >= BK_MOVE x range) (kalau tidak ada: yang paling tinggi persennya). Dicek di data uji."""
    rows = [r for r in g.get("breakout") or [] if r["broke"] >= 30]
    if not rows:
        return None
    pick = next((r for r in rows if r["ok_pct"] >= 70), None) or max(rows, key=lambda r: r["ok_pct"])
    tst = next((r for r in (g.get("test") or {}).get("breakout", []) if r["level"] == pick["level"]), None)
    return {"pick": pick, "move": BK_MOVE, "rows": rows, "strong": pick["ok_pct"] >= 70,
            "test_ok_pct": tst["ok_pct"] if tst and tst["broke"] >= 20 else None}


def split_months(agg, frac=0.7):
    """Bulan untuk data latih (sampai ±70% gelombang) dan data uji (sisanya)."""
    months = sorted(agg)
    cnt = np.array([agg[m]["n"].sum() for m in months])
    if not len(months):
        return [], []
    cum = np.cumsum(cnt) / max(1, cnt.sum())
    k = int(np.searchsorted(cum, frac)) + 1
    k = min(max(1, k), len(months) - 1) if len(months) > 1 else 1
    return months[:k], months[k:]


def summarize(agg, p, light=False):
    """light = hanya kelompok 'Semua' (untuk bocoran hasil saat studi masih berjalan)."""
    if not agg:
        return {"n": 0, "groups": []}
    fit_m, test_m = split_months(agg)
    months = sorted(agg)
    total = int(sum(agg[m]["n"].sum() for m in months))
    groups = []
    spec = [("all", None, "Semua setup", "", "", 0, 0)]
    if not light:
        for g, (reg, d) in enumerate(GROUPS):
            with_trend = reg == d
            side = "BUY" if d > 0 else "SELL"
            kind = "sideways" if reg == 0 else "koreksi searah tren" if with_trend else "koreksi melawan tren"
            name = f"{REG[reg]} · {side}" if reg == 0 else f"{REG[reg]} · {kind} ({side})"
            spec.append((GKEY[g], [g], name, side, kind, reg, d))
    sums = {}
    for key, gi, name, side, note, reg, d in spec:
        allc, fit, test = _sum(agg, months, gi), _sum(agg, fit_m, gi), _sum(agg, test_m, gi)
        g = {"key": key, "name": name, "side": side, "note": note, "reg": reg, "dir": d, **_table(allc),
             "test": _table(test)}
        g["advice"] = _advice(fit, test, g)
        sums[key] = (allc, fit, test)
        if not light:
            g["power"] = power_summary(g)
            g["plan"] = plan_group(g, sums[key])
            if int(allc["s_tc"].sum()):
                g["scan"] = scan_summary(allc, fit, test)
                g["secret"] = secret_summary(allc, fit, test, key, g["scan"])
        groups.append(g)
    split = (int(np.datetime64(int(test_m[0]), "M").astype("datetime64[ms]").astype(np.int64)) if test_m else None)
    out = {"n": total, "split": split, "params": p, "groups": groups}
    if not light:
        out["conclusion"] = conclusion(groups, p, sums)
        out["trend"] = trend_summary(agg, fit_m, test_m, p)
    return out


KNOWN = [-1.618, -1.0, -0.618, -0.414, -0.272, -0.13, 0.0, 0.236, 0.382, 0.5, 0.618, 0.65, 0.705, 0.786, 0.886, 1.0,
         1.13, 1.272, 1.414, 1.618]   # angka fibo yang sudah umum


def scan_summary(allc, fit, test):
    """Cari 'angka rahasia': level yang respeknya lebih tinggi dari level-level di sekitarnya (bukan sekadar karena
    lebih dangkal/dalam). excess = respek level - rata-rata respek level tetangga (jarak 0.03 .. 0.06).
    Dipilih di data latih (puncak lokal, excess >= 2 x galat acak), lalu dicek di data uji (excess harus tetap > 0)."""
    def curve(s):
        tc, rs, el = s["s_tc"].astype(float), s["s_rs"].astype(float), s["s_el"].astype(float)
        resp = np.where(tc > 0, 100 * rs / np.maximum(tc, 1), np.nan)
        touch = np.where(el > 0, 100 * tc / np.maximum(el, 1), np.nan)
        exc = np.full(len(SCAN), np.nan)
        for i in range(len(SCAN)):
            nb = [j for j in range(len(SCAN)) if 3 <= abs(j - i) <= 6 and np.isfinite(resp[j])]
            if len(nb) >= 4 and np.isfinite(resp[i]):
                exc[i] = resp[i] - np.mean([resp[j] for j in nb])
        return resp, touch, exc, tc
    r_a, t_a, e_a, n_a = curve(allc)
    r_f, _, e_f, n_f = curve(fit)
    r_t, _, e_t, n_t = curve(test)
    rows = []
    for i, x in enumerate(SCAN):
        p_ = (r_f[i] / 100) if np.isfinite(r_f[i]) else 0.5
        se = 100 * np.sqrt(max(p_ * (1 - p_), 0.01) / max(n_f[i], 1))
        rows.append({"level": float(x), "respect": None if not np.isfinite(r_a[i]) else float(r_a[i]),
                     "touch": None if not np.isfinite(t_a[i]) else float(t_a[i]), "n": int(n_a[i]),
                     "excess": None if not np.isfinite(e_a[i]) else float(e_a[i]),
                     "fit_excess": None if not np.isfinite(e_f[i]) else float(e_f[i]), "se": float(se),
                     "test_excess": None if not np.isfinite(e_t[i]) else float(e_t[i]), "test_n": int(n_t[i]),
                     "known": any(abs(x - k) < 0.006 for k in KNOWN)})
    cand = []
    for i, r in enumerate(rows):
        fe = r["fit_excess"]
        if fe is None or n_f[i] < 100 or fe < 2 * r["se"]:
            continue
        if any(rows[j]["fit_excess"] is not None and rows[j]["fit_excess"] > fe for j in (i - 1, i + 1) if 0 <= j < len(rows)):
            continue                                       # bukan puncak lokal
        r = {**r, "valid": r["test_excess"] is not None and r["test_n"] >= 50 and r["test_excess"] > 0}
        cand.append(r)
    cand.sort(key=lambda r: (not r["valid"], -(r["fit_excess"] or 0)))
    return {"rows": rows, "secret": cand[:6], "found": [r for r in cand if r["valid"]][:6]}


# ------------------------------------------------------------------ angka rahasia: peran tiap angka + penjelasan
FC = np.round(FBIN[:-1] + 0.005, 3)          # titik tengah bin histogram halus


def _lv(x):
    return f"{x:.2f}".rstrip("0").rstrip(".") if x not in (0, -0.0) else "0"


def _mode(h, lo, hi, w=2):
    """Level paling sering (histogram dihaluskan ±w bin) di rentang lo..hi."""
    m = (FC >= lo) & (FC <= hi)
    if h[m].sum() < 30:
        return None, 0.0
    sm = np.convolve(h.astype(float), np.ones(2 * w + 1), "same")
    i = int(np.flatnonzero(m)[np.argmax(sm[m])])
    return float(round(FC[i] - 0.005, 2)), float(100 * sm[i] / max(1, h[m].sum()))


def _q(h, q):
    tot = h.sum()
    if tot < 30:
        return None
    return float(round(FC[min(len(FC) - 1, int(np.searchsorted(np.cumsum(h), q * tot)))] - 0.005, 2))


def _new(x):
    return not any(abs(x - k) < 0.006 for k in KNOWN)


def secret_summary(allc, fit, test, key, scan):
    """Peran 'angka rahasia' satu kelompok, dari pemindaian halus (tiap 0.01), dipilih di data latih dan dicek di data
    uji. Tiap peran: angka + penjelasan singkat + apakah lolos uji + apakah angka baru (bukan angka fibo umum)."""
    buy = key.endswith("_up")
    side = "BUY" if buy else "SELL"
    kor = "turun" if buy else "naik"
    roles = []

    def add(kind, icon, title, level, lines, valid, extra=None):
        roles.append({"kind": kind, "icon": icon, "title": title, "level": level, "lines": lines, "valid": bool(valid),
                      "new": level is not None and _new(level), **(extra or {})})

    # 1. entry limit pullback / retest (+ S/R kuat): puncak respek
    best = (scan.get("found") or scan.get("secret") or [None])[0]
    if best:
        add("entry", "🎯", f"Limit entry pullback / retest ({side})", best["level"], [
            f"Setelah fibo ditarik, harga {kor} ke {_lv(best['level'])} lalu memantul sampai 0 (ujung swing) "
            f"sebelum ada candle close tembus {_lv(best['level'])}: {best['respect']:.0f}% kejadian.",
            f"Itu {best['fit_excess']:+.1f} poin lebih sering dari angka-angka di sekitarnya, jadi angka ini memang istimewa, "
            f"bukan cuma karena lebih dangkal / dalam.",
            "Karena sering jadi tempat memantul, angka ini juga bekerja sebagai S/R kuat di dalam swing."],
            best.get("valid"), {"respect": best["respect"], "test_excess": best.get("test_excess")})
    else:
        add("entry", "🎯", f"Limit entry pullback / retest ({side})", None, [
            "Tidak ada angka yang respeknya menonjol dari sekitarnya. Respek turun mulus makin dalam koreksi, "
            "jadi tidak ada angka entry rahasia dari sisi respek. Untuk limit, pakai angka 🛑 (koreksi biasanya berhenti) di bawah."], False)

    # 2. koreksi biasanya berhenti (gelombang yang lanjut BOS), total & per kemiringan
    hw = allc["z_dw"][:, 0].sum(0)
    md, share = _mode(hw, 0.1, 1.0)
    tmd, _ = _mode(test["z_dw"][:, 0].sum(0), 0.1, 1.0)
    if md is not None:
        sl_lines = []
        for sv in range(3):
            m_, _ = _mode(allc["z_dw"][sv, 0], 0.1, 1.0)
            if m_ is not None and allc["z_dw"][sv, 0].sum() >= 100:
                sl_lines.append(f"Impuls {SLOPE_NAME[sv]}: koreksi paling sering berhenti di {_lv(m_)}.")
        add("stop", "🛑", "Koreksi biasanya berhenti di sini" + ("" if key.startswith("side") else " (tren masih kuat)"), md, [
            f"Di swing yang akhirnya lanjut BOS, titik balik koreksi paling sering ada di {_lv(md)} "
            f"({share:.0f}% berhenti di sekitar ±0.02 angka ini). Bagus untuk limit entry koreksi.", *sl_lines],
            tmd is not None and abs(tmd - md) <= 0.05, {"test_level": tmd})

    # 3. alarm struktur patah + SL aman
    def choch_curve(sv):
        dc = sv["z_dc"]
        tot = dc.sum(0)
        out = []
        for x in np.round(np.arange(0.3, 1.0001, 0.01), 2):
            m = FC >= x
            nb, nc = tot[m].sum(), dc[1][m].sum()
            out.append((float(x), int(nb), 100 * nc / nb if nb else None))
        return out
    cf, ct = choch_curve(fit), choch_curve(test)
    al = next((r for r in cf if r[1] >= 50 and r[2] is not None and r[2] >= 70), None)
    if al:
        tv = next((r for r in ct if r[0] == al[0]), None)
        ta = tv[2] if tv and tv[1] >= 20 else None
        add("alarm", "🚨", "Alarm: kalau close tembus angka ini, struktur biasanya patah", al[0], [
            f"Kalau candle close tembus {_lv(al[0])}, {al[2]:.0f}% akhirnya tembus 1 (CHoCH)"
            + (f" (data uji {ta:.0f}%)." if ta is not None else "."),
            "Batalkan limit yang lebih dalam dari angka ini dan jangan entry searah tren lagi."],
            ta is not None and ta >= 60, {"test_pct": ta})
    sl90, sl80 = _q(hw, 0.9), _q(hw, 0.8)
    tsl = _q(test["z_dw"][:, 0].sum(0), 0.9)
    if sl90 is not None:
        add("sl", "🛡️", "SL aman", sl90, [
            f"Koreksi yang akhirnya lanjut BOS: 80% tidak lewat {_lv(sl80)}, 90% tidak lewat {_lv(sl90)} (pakai ekor candle).",
            f"Taruh SL sedikit di luar {_lv(sl90)} (beri buffer ATR TF fibo): kena SL berarti koreksinya sudah tidak wajar."],
            tsl is not None and abs(tsl - sl90) <= 0.05, {"test_level": tsl})

    # 4. TP setelah BOS + titik tren kuat biasanya berhenti
    hb = allc["z_bx"].sum(0)
    nb = int(hb.sum())
    if nb >= 50:
        cum_far = np.cumsum(hb)                          # FC naik: dari -1.5 (jauh) ke 0
        reach = lambda y: 100 * cum_far[max(0, int(np.searchsorted(FC, y + 1e-9)) - 1)] / nb   # noqa: E731
        grid = np.round(np.arange(-0.01, -2.9001, -0.01), 2)
        tp1 = next((float(y) for y in grid[::-1] if reach(y) >= 60), None)
        tp2 = next((float(y) for y in grid[::-1] if reach(y) >= 35), None)
        hbt = test["z_bx"].sum(0)
        rt = (lambda y: 100 * np.cumsum(hbt)[max(0, int(np.searchsorted(FC, y + 1e-9)) - 1)] / hbt.sum()) if hbt.sum() >= 30 else None
        if tp1 is not None:
            lines = [f"Kalau ditahan sampai struktur patah (dalam batas Maks. candle): setelah close tembus 0 (BOS), "
                     f"{reach(tp1):.0f}% sampai {_lv(tp1)} → TP jauh."]
            if tp2 is not None and tp2 < tp1:
                lines.append(f"{reach(tp2):.0f}% sampai {_lv(tp2)} → TP lanjutan (runner).")
            lines.append("Untuk TP aman / cepat, pakai angka 🏁 (dorongan pertama habis) di bawah.")
            add("tp", "💰", "TP setelah BOS", tp1, lines, rt is not None and rt(tp1) >= 50,
                {"tp2": tp2, "test_pct": rt(tp1) if rt else None})
        hs = allc["z_st"].sum(0)
        sm_, sh_ = _mode(hs, -2.9, -0.01)
        if sm_ is not None:
            med_ = _q(hs, 0.5)
            sl_lines = []
            for sv in range(3):
                h_ = allc["z_st"][sv]
                if h_.sum() >= 100:
                    sl_lines.append(f"Impuls {SLOPE_NAME[sv]}: rata-rata habis di {_lv(_q(h_, 0.5))}.")
            tm_ = _q(test["z_st"].sum(0), 0.5)
            add("end", "🏁", "Tren kuat biasanya berhenti / mulai koreksi di sini", med_, [
                f"Setelah BOS, dorongan pertama rata-rata habis di {_lv(med_)} (paling sering di {_lv(sm_)}), "
                f"lalu harga koreksi minimal {BK_MOVE} × swing.", *sl_lines,
                "Cocok untuk ambil profit sebelum koreksi berikutnya, dan jangan kejar entry di sekitar angka ini."],
                tm_ is not None and abs(tm_ - med_) <= 0.1, {"test_level": tm_})

    # 5. breakout sideways: angka awal breakout valid + retest setelah breakout
    if key.startswith("side"):
        bk, bkt = fit["z_bk"], test["z_bk"]
        pick = None
        for a, y in enumerate(BKS):
            if bk[0, a] >= 50 and 100 * bk[1, a] / bk[0, a] >= 70:
                pick = a
                break
        if pick is not None:
            y = float(BKS[pick])
            okp = 100 * bk[1, pick] / bk[0, pick]
            tok = 100 * bkt[1, pick] / bkt[0, pick] if bkt[0, pick] >= 20 else None
            ok0 = 100 * allc["z_bk"][1, 0] / allc["z_bk"][0, 0] if allc["z_bk"][0, 0] else None
            add("breakout", "🚀", f"Awal breakout valid ({'buy stop' if buy else 'sell stop'})", y, [
                f"Range dari swing terakhir: kalau candle close tembus {_lv(y)}, {okp:.0f}% lanjut "
                f"{'naik' if buy else 'turun'} minimal {BK_MOVE} × lebar range" + (f" (data uji {tok:.0f}%)." if tok is not None else "."),
                (f"Baru close tembus 0 cuma {ok0:.0f}% lanjut, jadi tunggu {_lv(y)} supaya tidak kena breakout palsu." if ok0 is not None and pick > 0 else
                 "Close tembus 0 sudah cukup jadi tanda breakout.")],
                tok is not None and tok >= 60, {"test_pct": tok})
        hr = allc["z_brt"].sum(0)
        if hr.sum() >= 50:
            med, p70 = _q(hr, 0.5), _q(hr, 0.7)
            lines = [f"Breakout yang valid biasanya retest dulu ke {_lv(med)} sebelum lanjut; 70% tidak lebih dalam dari {_lv(p70)}."]
            for sv in range(3):
                h_ = allc["z_brt"][sv]
                if h_.sum() >= 40:
                    lines.append(f"Impuls {SLOPE_NAME[sv]}: retest ke ±{_lv(_q(h_, 0.5))}.")
            lines.append("Angka positif = harga masuk lagi ke dalam range; minus = retest di luar range.")
            tm_ = _q(test["z_brt"].sum(0), 0.5)
            add("retest", "🔁", "Retest setelah breakout valid", med, lines,
                tm_ is not None and abs(tm_ - med) <= 0.08, {"test_level": tm_})
        hf = allc["z_fk"].sum(0)
        nf = int(hf.sum())
        if nf >= 50:
            cum = np.cumsum(hf[::-1])[::-1]                   # cum[i] = jumlah yang sampai >= FC[i]
            reach = lambda x: 100 * cum[min(len(FC) - 1, int(np.searchsorted(FC, x - 1e-9)))] / nf   # noqa: E731
            grid = np.round(np.arange(0.05, 2.5001, 0.01), 2)
            r70 = next((float(x) for x in grid[::-1] if reach(x) >= 70), None)
            r50 = next((float(x) for x in grid[::-1] if reach(x) >= 50), None)
            r35 = next((float(x) for x in grid[::-1] if reach(x) >= 35), None)
            ht = test["z_fk"].sum(0)
            tr50 = None
            if ht.sum() >= 20:
                ct = np.cumsum(ht[::-1])[::-1]
                tr50 = 100 * ct[min(len(FC) - 1, int(np.searchsorted(FC, (r50 or 0) - 1e-9)))] / ht.sum()
            if r50 is not None:
                arah = "turun" if buy else "naik"
                lines = [f"Kalau candle sempat close tembus 0 lalu close balik ke dalam range (breakout {'atas' if buy else 'bawah'} gagal), "
                         f"sebelum mencoba breakout lagi harga biasanya {arah}:"]
                if r70 is not None:
                    lines.append(f"70% sampai {_lv(r70)}.")
                lines.append(f"50% sampai {_lv(r50)}" + (f" (data uji {tr50:.0f}%)." if tr50 is not None else "."))
                if r35 is not None and r35 > r50:
                    lines.append(f"35% sampai {_lv(r35)}.")
                for sv in range(3):
                    h_ = allc["z_fk"][sv]
                    if h_.sum() >= 40:
                        lines.append(f"Impuls {SLOPE_NAME[sv]}: rata-rata sampai {_lv(_q(h_, 0.5))}.")
                lines.append("Lewat 1 = tembus sisi range yang satunya. Cocok jadi target kalau entry arah sebaliknya setelah breakout gagal.")
                add("fake", "🪤", f"Gagal breakout {'atas' if buy else 'bawah'} → harga lari ke sini", r50, lines,
                    tr50 is not None and tr50 >= 40, {"r70": r70, "r35": r35, "test_pct": tr50})
    return {"roles": roles}


def _tsum(agg, months):
    out = None
    for mo in months:
        s = {k: v.copy() for k, v in agg[mo].items() if k.startswith("t_")}
        out = s if out is None else {k: out[k] + s[k] for k in s}
    return out


RT_LV = [0.236, 0.382, 0.5, 0.618, 0.705, 0.786, 0.886]


def _retest(h, x):
    """Setelah close tembus x lalu akhirnya CHoCH: sebelum CHoCH harga balik (retest) sampai level berapa.
    pct = % yang retest sampai level itu atau lebih dekat ke 0; direct = % yang tidak balik lagi ke x."""
    tot = int(h.sum())
    if not tot:
        return None
    cum = np.cumsum(h)
    upto = lambda v: int(cum[max(0, int(np.searchsorted(B_DEP, v + 1e-9)) - 1)])   # noqa: E731  level <= v
    return {"n": tot, "med": _median_hist(h, B_DEP), "direct": _pct(tot - upto(x), tot),
            "reach": [{"level": v, "pct": _pct(upto(v), tot)} for v in RT_LV if v <= x]}


def trend_summary(agg, fit_m, test_m, p):
    """Saat tren TF trend_tf (EMA50 vs EMA200) bullish / bearish, untuk gelombang searah tren:
    - CHoCH: kalau koreksi CLOSE tembus level x, berapa % akhirnya CHoCH (close tembus 1.0) vs BOS (close tembus 0);
    - BOS: kalau setelah tembus x harga close balik melewati x, berapa % akhirnya BOS;
    - kedalaman koreksi sebelum BOS, dan sejauh apa harga jalan setelah BOS / CHoCH."""
    allc = _tsum(agg, sorted(agg))
    if allc is None:
        return None
    test = _tsum(agg, test_m) if test_m else None
    ef, es = int(p.get("ema_fast", 50)), int(p.get("ema_slow", 200))
    out = {"tf": p.get("trend_tf", "1h"), "ema_fast": ef, "ema_slow": es, "sides": []}
    for si, (key, name, side) in enumerate((("bull", f"Bullish (EMA{ef} > EMA{es})", "BUY"), ("bear", f"Bearish (EMA{ef} < EMA{es})", "SELL"))):
        n = int(allc["t_n"][si])
        g = {"key": key, "name": name, "side": side, "n": n}
        if n:
            e = allc["t_end"][si]
            g["end"] = {"bos": _pct(e[0], n), "choch": _pct(e[1], n), "open": _pct(e[2], n)}
            dh = allc["t_dep"][si]
            g["depth_med"], g["depth_p80"] = _median_hist(dh, B_DEP), _pctl(dh, B_DEP, 0.8)
            rows = []
            for a, x in enumerate(TLV):
                cb, rn = int(allc["t_cb"][si, a]), int(allc["t_rn"][si, a])
                tcb = int(test["t_cb"][si, a]) if test else 0
                trn = int(test["t_rn"][si, a]) if test else 0
                rows.append({"level": x, "broke": cb, "broke_pct": _pct(cb, n), "choch_pct": _pct(allc["t_cc"][si, a], cb),
                             "bos_pct": _pct(allc["t_cs"][si, a], cb), "reclaim": rn, "rc_bos_pct": _pct(allc["t_rb"][si, a], rn),
                             "rc_choch_pct": _pct(allc["t_rc"][si, a], rn),
                             "retest": _retest(allc["t_rt"][si, a], x),
                             "test_choch_pct": _pct(test["t_cc"][si, a], tcb) if tcb >= 20 else None,
                             "test_rc_bos_pct": _pct(test["t_rb"][si, a], trn) if trn >= 20 else None})
            g["rows"] = rows
            ok = [r for r in rows if r["broke"] >= 30]
            ch = next((r for r in ok if r["choch_pct"] >= 70), None) or (max(ok, key=lambda r: r["choch_pct"]) if ok else None)
            if ch:
                g["choch"] = {**ch, "strong": ch["choch_pct"] >= 70,
                              "valid": ch["test_choch_pct"] is not None and ch["test_choch_pct"] >= 60}
            okr = [r for r in rows if r["reclaim"] >= 30]
            bs = next((r for r in reversed(okr) if r["rc_bos_pct"] >= 70), None) or (max(okr, key=lambda r: r["rc_bos_pct"]) if okr else None)
            if bs:
                g["bos"] = {**bs, "strong": bs["rc_bos_pct"] >= 70,
                            "valid": bs["test_rc_bos_pct"] is not None and bs["test_rc_bos_pct"] >= 60}
            bxn, cxn = int(allc["t_bxn"][si]), int(allc["t_cxn"][si])
            g["after_bos"] = {"n": bxn, "reach": [{"level": -x, "pct": _pct(allc["t_bx"][si, k], bxn)} for k, x in enumerate(TEXT)]}
            g["after_choch"] = {"n": cxn, "reach": [{"level": x, "pct": _pct(allc["t_cx"][si, k], cxn)} for k, x in enumerate(EXT)]}
        out["sides"].append(g)
    return out


def sl_test(sums, x, t):
    """Uji letak SL untuk entry di level x dan TP di level t: WR & hasil per trade tiap kandidat SL.
    terbaik = hasil per trade (R) tertinggi di data latih.
    aman = SL paling longgar yang hasilnya masih >= 80% dari yang terbaik (lebih tahan sweep, profit hampir sama)."""
    allc, fit, test = sums
    if "slw" not in allc or x not in RET or t not in TP_CAND:
        return None
    a, ti = RET.index(x), TP_CAND.index(t)

    def stat(s, si):
        w, lo = int(s["slw"][a, ti, si]), int(s["sll"][a, ti, si])
        if w + lo == 0:
            return None, None, 0
        wr = w / (w + lo)
        return 100 * wr, wr * (x - t) / (SLC[si] - x) - (1 - wr), w + lo
    rows = []
    for si, lv in enumerate(SLC):
        if lv <= x:
            continue
        wr, ex, n = stat(allc, si)
        if wr is None:
            continue
        twr, tex, tn = stat(test, si)
        fwr, fex, _ = stat(fit, si)
        rows.append({"level": lv, "wins": int(allc["slw"][a, ti, si]), "n": n, "win_rate": wr, "exp_r": ex,
                     "rr": (x - t) / (lv - x), "fit_exp_r": fex, "test_win_rate": twr, "test_exp_r": tex, "test_n": tn})
    if not rows:
        return None
    fits = [r for r in rows if r["fit_exp_r"] is not None]
    best = max(fits, key=lambda r: r["fit_exp_r"]) if fits else None
    if not best or best["fit_exp_r"] <= 0:
        return {"rows": rows, "safe": None, "best": None}
    safe = max((r for r in fits if r["fit_exp_r"] >= 0.8 * best["fit_exp_r"]), key=lambda r: r["level"])
    for r in rows:
        r["valid"] = r["test_exp_r"] is not None and r["test_n"] >= 10 and r["test_exp_r"] > 0
    return {"rows": rows, "safe": safe["level"], "best": best["level"]}


TP1_P, TP2_P = 60.0, 35.0   # TP1 = level terjauh yang dicapai >= 60% trade, TP2 = >= 35%


def _plan_level(row, n):
    """Untuk entry di level row: TP1, TP2, rata-rata pantulan, dan perkiraan hasil per trade di TP1."""
    x, tps = row["level"], row.get("tp") or []
    if x >= 1.0 or not tps or row["filled"] < max(20, 0.15 * n):
        return None
    tp1 = next((t for t in reversed(tps) if t["pct"] >= TP1_P), None)   # tps urut dari dekat ke jauh
    if tp1 is None:
        return None
    tp2 = next((t for t in reversed(tps) if t["pct"] >= TP2_P and t["level"] < tp1["level"]), None)
    rr1 = (x - tp1["level"]) / (1 - x)                                # perkiraan RR (SL di 1.0, tanpa buffer)
    p1 = tp1["pct"] / 100
    return {"entry": x, "fill_pct": row["fill"], "tp1": {**tp1, "rr": rr1},
            "tp2": {**tp2, "rr": (x - tp2["level"]) / (1 - x)} if tp2 else None,
            "avg": row.get("reach_med"), "exp_r": p1 * rr1 - (1 - p1)}


def plan_group(g, sums=None):
    """Rencana entry satu kelompok (teknikal, tanpa uang): entry = level terkuat (sering disentuh & respek, di atas
    level alarm), TP1 = level yang dicapai >= 60% pantulan, TP2 = >= 35%, SL = k x ATR dari entry, plus alarm & target
    setelah BOS. Lolos uji = di 30% data terakhir TP1 tetap dicapai >= 50% trade."""
    n = g.get("n", 0)
    a = g.get("advice") or {}
    alarm = a.get("alarm")
    pw = g.get("power")
    item = {"n": n, "alarm": alarm, "after_bos": a.get("target_after_bos")}
    if n < 30 or not g.get("levels") or not pw:
        return item
    row = next((r for r in g["levels"] if r["level"] == pw["best"]["level"]), None)
    pl = _plan_level(row, n) if row else None
    if not pl:
        return item
    item.update(pl)
    item["sl_k"] = pw["k"]
    trow = next((r for r in (g.get("test") or {}).get("levels", []) if r["level"] == pl["entry"]), None)
    tp_t = next((t for t in (trow or {}).get("tp", []) if t["level"] == pl["tp1"]["level"]), None)
    if tp_t and trow and trow["filled"] >= 10:
        item["test"] = {"wr_tp1": tp_t["pct"], "n": trow["filled"]}
        item["valid"] = tp_t["pct"] >= 50
    else:
        item["valid"] = None
    return item


def conclusion(groups, p, sums=None):
    """Kesimpulan per kondisi pasar dalam bahasa sederhana (hanya koreksi searah tren & sideways)."""
    by = {g["key"]: g for g in groups}
    spec = [("Bullish", "📈", [("bull_up", "BUY", "koreksi searah tren")]),
            ("Bearish", "📉", [("bear_down", "SELL", "koreksi searah tren")]),
            ("Sideways", "↔️", [("side_up", "BUY", "sideways (beli di bawah)"),
                                 ("side_down", "SELL", "sideways (jual di atas)")])]
    out = []
    for reg, icon, items in spec:
        rows = []
        for key, side, desc in items:
            g = by.get(key) or {}
            plan = g.get("plan") or plan_group(g, (sums or {}).get(key))
            rows.append({"key": key, "side": side, "desc": desc, **plan, "power": power_summary(g),
                         "breakout": breakout_summary(g)})
        out.append({"regime": reg, "icon": icon, "items": rows})
    return out


def _advice(fit, test, g):
    """Kesimpulan: level limit terbaik (dipilih di data latih, dicek di data uji), level alarm BOS, target."""
    out = {}
    nf, nt = int(fit["n"]), int(test["n"])
    if nf >= 30:
        best, bw = None, None
        for a, x in enumerate(RET):
            if x >= 1.0:   # limit tepat di titik awal gelombang: SL terlalu dekat, R membengkak, tidak dipakai sebagai saran
                continue
            for b_, tg in enumerate(TGT_NAME):
                c = fit["rcnt"][a, b_]
                if c < 20:
                    continue
                rl = float(fit["rsum"][a, b_] / nf)
                if best is None or rl > best[0]:
                    best = (rl, a, b_)
                mean, wr = fit["rsum"][a, b_] / c, 100 * fit["rwin"][a, b_] / c
                if mean > 0 and c >= 0.15 * nf and (bw is None or wr > bw[0]):   # level jarang terisi tidak praktis
                    bw = (float(wr), a, b_, float(mean))
        if best:
            rl, a, b_ = best
            c, ct = fit["rcnt"][a, b_], test["rcnt"][a, b_]
            out["limit"] = {"level": RET[a], "target": TGT_NAME[b_], "fit_r_leg": rl,
                            "fit_wr": float(100 * fit["rwin"][a, b_] / c) if c else None,
                            "test_r_leg": float(test["rsum"][a, b_] / nt) if nt else None,
                            "test_wr": float(100 * test["rwin"][a, b_] / ct) if ct else None, "test_n": int(ct)}
            out["limit"]["valid"] = bool(nt >= 15 and ct >= 10 and out["limit"]["test_r_leg"] > 0 and rl > 0)
        if bw:
            wr, a, b_, mean = bw
            ct = test["rcnt"][a, b_]
            out["high_wr"] = {"level": RET[a], "target": TGT_NAME[b_], "fit_wr": wr, "fit_r": mean,
                              "test_wr": float(100 * test["rwin"][a, b_] / ct) if ct else None,
                              "test_r": float(test["rsum"][a, b_] / ct) if ct else None, "test_n": int(ct)}
            out["high_wr"]["valid"] = bool(ct >= 10 and out["high_wr"]["test_r"] > 0)
    for row in g.get("breaks", []):
        if row["broke"] >= 30 and row["bos_pct"] >= 70:
            a = BRK.index(row["level"])
            nb = int(test["broke"][a])
            out["alarm"] = {**row, "test_bos_pct": _pct(int(test["bos"][a]), nb) if nb else None, "test_broke": nb}
            break
    ab = g.get("after_bos", {})
    if ab.get("n", 0) >= 20:
        reach = [x for x in ab["reach"] if x["pct"] >= 50]
        if reach:
            out["target_after_bos"] = reach[-1]
    return out


# ------------------------------------------------------------------ job paralel (semua koin)
_WS = {}


def _init(data_dir):
    from .data import DataStore
    _WS["store"] = DataStore(data_dir, cache_size=4)


def _one(sym, p, start, end):
    try:
        t0 = time.time()
        r = study_symbol(_WS["store"], sym, p, start, end)
        return {"symbol": sym, "legs": 0 if r is None else int(len(r["t"])), "agg": aggregate(r),
                "ex": [] if r is None else pick_examples(r["ex"], sym),
                "seconds": round(time.time() - t0, 1)}
    except Exception as ex:
        return {"symbol": sym, "error": f"{type(ex).__name__}: {ex}"}


JOB_KIND = "fib"


class FibJobs(PausableJobs):
    """Studi semua koin, paralel, bisa dijeda & dilanjutkan (lihat pausable.py)."""

    def __init__(self, data_dir, paused_dir=None):
        self.data_dir = data_dir
        super().__init__(paused_dir)

    @property
    def KIND(self):   # noqa: N802  v1 = "fib", v2 = "fib2" (dibaca dari modul masing-masing)
        return JOB_KIND

    def start(self, symbols, p, start=None, end=None, workers=None):
        p = {**DEFAULTS, **(p or {})}
        from .sysinfo import recommended_workers
        workers = max(1, min(int(workers or recommended_workers()), 32))
        job = self._new(uuid.uuid4().hex[:10], len(symbols), workers, symbols=list(symbols), legs=0, errors=[],
                        agg={}, result=None, params=p, range=(start, end), times=[], recent=[], top=[], ex=[],
                        preview=None, preview_at=0.0)
        self._launch(job)
        return job["id"]

    def pool_init(self):
        return _init, (self.data_dir,)

    def task_call(self, job, i):
        return _one, (job["symbols"][i], job["params"], *job["range"])

    def on_error(self, job, i, ex):
        return {"symbol": job["symbols"][i], "error": f"{type(ex).__name__}: {ex}"}

    def on_result(self, job, i, row):
        if row.get("ex"):
            job["ex"] = pick_examples(job.get("ex", []) + row["ex"])
        if row.get("agg"):
            merge_agg(job["agg"], row["agg"])
            job["legs"] += row["legs"]
        if row.get("error"):
            job["errors"].append(f"{row['symbol']}: {row['error']}")
        job["times"].append(time.time())
        job["recent"] = ([{"symbol": row["symbol"], "legs": row.get("legs", 0), "seconds": row.get("seconds"),
                           "error": bool(row.get("error"))}] + job["recent"])[:8]
        if row.get("legs"):
            job["top"] = sorted(job["top"] + [{"symbol": row["symbol"], "legs": row["legs"]}], key=lambda x: -x["legs"])[:5]

    def finish(self, job):
        job["result"] = summarize(job["agg"], job["params"])
        job["result"]["examples"] = job.get("ex", [])
        job["result"]["ret"], job["result"]["tgt"] = list(RET), list(TGT_NAME)

    def _eta(self, job):
        """Sisa waktu dari kecepatan selesai yang sebenarnya (bukan dari koin pertama, yang ikut menanggung waktu start)."""
        t, left = job["times"], job["total"] - job["done"]
        k = min(len(t) - 1, max(2 * job["workers"], 10))
        if left <= 0 or len(t) < min(job["total"], max(3, job["workers"])) or k < 2:
            return None
        rate = k / max(1e-6, t[-1] - t[-1 - k])          # koin per detik, dari k koin terakhir
        return left / rate

    def get(self, jid):
        job = self.jobs.get(jid)
        if not job:
            return None
        now = time.time()
        with self.lock:
            if job["status"] in ("running", "paused") and job["agg"] and now - job["preview_at"] > 3:
                job["preview"], job["preview_at"] = summarize(job["agg"], job["params"], light=True), now
            t = job["times"]
            rate = (len(t) - 1) / (t[-1] - t[0]) * 60 if len(t) >= 3 and t[-1] > t[0] else None
            out = {"id": jid, "status": job["status"], "done": job["done"], "total": job["total"], "legs": job["legs"],
                   "workers": job["workers"], "elapsed": round(self.elapsed(job), 1),
                   "eta": self._eta(job) if job["status"] == "running" else None, "inflight": job.get("inflight", 0),
                   "rate_min": rate, "recent": job["recent"], "top": job["top"],
                   "errors": job["errors"][:20], "error": job.get("error"),
                   "preview": job["preview"] if job["status"] in ("running", "paused") else None,
                   "result": job["result"] if job["status"] in ("done", "cancelled", "error") else None}
        return out
