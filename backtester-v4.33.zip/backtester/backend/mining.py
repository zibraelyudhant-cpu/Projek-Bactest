"""Analisa mendalam trade: cari pola indikator & timeframe yang membedakan trade menang vs kalah,
simulasi TP / SL / entry lain, lalu ubah jadi threshold yang bisa langsung dipasang (parameter `rules`, dll.).

Semua fitur dihitung dari candle yang SUDAH close saat sinyal (sama seperti yang bisa dilihat strategi),
jadi aturan yang ditemukan bisa dipakai sungguhan tanpa look-ahead. Yang melihat masa depan hanya
simulasi hasil (apakah TP/SL kena), dan itu memang tujuannya.
"""
import math
import re

import numpy as np

from .data import TF_MS
from .indicators import atr, bollinger, dmi, ema, force_index, macd, pivots, rolling, rsi, sma, stoch

TF_ORDER = ["5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"]

# fitur per timeframe: kunci -> (nama, penjelasan). Semua "searah": nilai besar = mendukung arah trade
TF_FEATS = {
    "e50": ("Jarak harga ke EMA50", "searah, dalam ATR (positif = harga di sisi arah trade)"),
    "e200": ("Jarak harga ke EMA200", "searah, dalam ATR"),
    "slope": ("Kemiringan EMA50", "searah, ATR per 5 candle"),
    "stack": ("Susunan EMA 20/50/200", "+1 = berurutan searah, −1 = berurutan melawan"),
    "bos": ("Struktur BOS", "+1 = BOS terakhir searah, −1 = melawan"),
    "rsi": ("RSI 14", "searah (long = RSI, short = 100 − RSI)"),
    "adx": ("ADX 14", "kekuatan tren"),
    "di": ("DI+ − DI−", "searah"),
    "macd": ("Histogram MACD", "searah, dalam ATR"),
    "fi": ("Force Index EMA2", "searah, dinormalisasi volume × ATR"),
    "atrp": ("ATR % harga", "volatilitas"),
    "atrx": ("ATR ÷ rata-rata ATR 50", "> 1 = volatilitas sedang melebar"),
    "vol": ("Volume ÷ rata-rata 20", "volume candle terakhir"),
    "rpos": ("Posisi di range 50 candle", "searah: 0 = area murah (diskon) untuk arah trade, 1 = sudah di ujung"),
    "bbw": ("Lebar Bollinger %", "kecil = squeeze"),
    "candle": ("Body candle terakhir", "searah, −1..1"),
    "stoch": ("Stochastic %K 14", "searah"),
    "ms4": ("Market structure 4 swing terakhir", "searah: +4 = HH/HL semua (struktur searah), −4 = LH/LL semua (melawan)"),
    "mslast": ("Swing terakhir (market structure)", "searah: +2 = HH, +1 = HL, −1 = LH, −2 = LL (untuk short dibalik)"),
}
MS_NAMES = ["HH", "HL", "LH", "LL"]


def ms_series(h, l, n=3):
    """Market structure per candle (kausal: swing baru dihitung setelah terkonfirmasi n candle di kanannya).
    Swing high & low dibuat selang-seling (dua high berturut-turut: yang tertinggi dipakai). Hasil per candle:
    ms4 = jumlah (+1 HH/HL, −1 LH/LL) 4 swing terakhir, mslast = +2 HH / +1 HL / −1 LH / −2 LL swing terakhir,
    ms3 = kode 3 swing terakhir (indeks MS_NAMES, a*16 + b*4 + c; −1 kalau belum ada 3)."""
    N = len(h)
    hi, lo = pivots(h, l, n)
    ev = sorted([(int(i) + n, int(i), "H", float(h[i])) for i in hi] + [(int(i) + n, int(i), "L", float(l[i])) for i in lo])
    ms4, mslast, ms3 = np.full(N, np.nan), np.full(N, np.nan), np.full(N, -1, np.int16)
    clean = []                                       # [(tipe, harga)]
    labels = []                                      # label tiap swing di clean (None untuk swing pertama tiap tipe)
    val = {"HH": 2, "HL": 1, "LH": -1, "LL": -2}
    k = 0
    cur = (np.nan, np.nan, -1)
    for t in range(N):
        while k < len(ev) and ev[k][0] <= t:
            _, _, typ, px = ev[k]
            k += 1
            if clean and clean[-1][0] == typ:
                if (typ == "H" and px > clean[-1][1]) or (typ == "L" and px < clean[-1][1]):
                    clean[-1] = (typ, px)
                    labels.pop()
                else:
                    continue
            prev = next((q for tq, q in reversed(clean[:-1] if clean and clean[-1][0] == typ else clean) if tq == typ), None)
            if clean and clean[-1][0] != typ or not clean:
                clean.append((typ, px))
            lab = None if prev is None else ("HH" if px > prev else "LH") if typ == "H" else ("HL" if px > prev else "LL")
            labels.append(lab)
            labs = [x for x in labels if x]
            if labs:
                last4 = labs[-4:]
                c3 = -1
                if len(labs) >= 3:
                    a, b, c_ = (MS_NAMES.index(x) for x in labs[-3:])
                    c3 = a * 16 + b * 4 + c_
                cur = (float(sum(1 if x in ("HH", "HL") else -1 for x in last4)), float(val[labs[-1]]), c3)
        ms4[t], mslast[t], ms3[t] = cur
    return ms4, mslast, ms3


def ms3_text(code):
    code = int(code)
    if code < 0:
        return "—"
    return "-".join(MS_NAMES[x] for x in (code // 16, (code // 4) % 4, code % 4))
GEO_FEATS = {
    "sl_atr": ("Jarak SL ÷ ATR TF eksekusi", "SL sempit < 1, lebar > 2"),
    "rr": ("RR rencana", "jarak TP ÷ jarak SL"),
    "depth": ("Kedalaman entry dari harga sinyal", "dalam R; 0 = market, besar = limit jauh"),
    "side": ("Arah", "+1 long, −1 short"),
    "asia": ("Sesi Asia 00–08 UTC", "1 = ya"), "london": ("Sesi London 08–13 UTC", "1 = ya"),
    "ny": ("Sesi New York 13–21 UTC", "1 = ya"), "late": ("Sesi malam 21–24 UTC", "1 = ya"),
}
K_SL = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
RR_GRID = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0, 4.0]
DEPTH = [0.25, 0.5, 0.75]


def tfs_for(exec_tf, htf, base_tf):
    """TF yang dianalisa: TF eksekusi, TF besar strategi, dan 15m / 1h / 4h / 1d."""
    want = {exec_tf, htf, "15m", "1h", "4h", "1d"}
    lo = TF_ORDER.index(base_tf) if base_tf in TF_ORDER else 0
    return [t for t in TF_ORDER if t in want and TF_ORDER.index(t) >= lo]


def bos_series(h, l, c, n=3):
    """Bias Break of Structure di setiap candle (+1 / −1 / 0), sama dengan indicators.bos_bias tapi per candle."""
    hi, lo = pivots(h, l, n)
    out = np.zeros(len(c))
    bias, ih, il, lh, ll = 0, 0, 0, None, None
    for i in range(len(c)):
        while ih < len(hi) and hi[ih] + n <= i:
            lh = h[hi[ih]]
            ih += 1
        while il < len(lo) and lo[il] + n <= i:
            ll = l[lo[il]]
            il += 1
        if lh is not None and c[i] > lh:
            bias, lh = 1, None
        elif ll is not None and c[i] < ll:
            bias, ll = -1, None
        out[i] = bias
    return out


def tf_series(b):
    """Semua deret indikator untuk satu TF (kausal: nilai di i hanya memakai candle <= i)."""
    o, h, l, c, v = (np.asarray(x, float) for x in (b.o, b.h, b.l, b.c, b.v))
    S = {"o": o, "h": h, "l": l, "c": c, "v": v}
    S["e20"], S["e50"], S["e200"] = ema(c, 20), ema(c, 50), ema(c, 200)
    S["atr"] = atr(h, l, c, 14)
    S["rsi"] = rsi(c, 14)
    S["pdi"], S["ndi"], S["adx"] = dmi(h, l, c, 14)
    S["hist"] = macd(c)[2]
    S["fi"] = force_index(c, v, 2)
    S["vsma"] = sma(v, 20)
    S["asma"] = sma(S["atr"], 50)
    S["hi50"], S["lo50"] = rolling(h, 50, np.max), rolling(l, 50, np.min)
    lb, mid, ub = bollinger(c, 20, 2)
    S["bbw"] = (ub - lb) / mid * 100
    S["stoch"] = stoch(h, l, c, 14)[0]
    S["bos"] = bos_series(h, l, c, 3)
    S["ms4"], S["mslast"], S["ms3"] = ms_series(h, l, 3)
    S["n"] = len(c)
    return S


def tf_values(S, i, d):
    """Nilai fitur di indeks candle i (array), arah d (+1/−1). i < 0 atau data kurang -> NaN."""
    i = np.asarray(i)
    ok = (i >= 210)   # minimal 210 candle supaya EMA200 & indikator lain stabil
    j = np.where(ok, i, 0)
    g = lambda k: np.where(ok, S[k][j], np.nan)   # noqa: E731
    c, a = g("c"), g("atr")
    with np.errstate(invalid="ignore", divide="ignore"):
        e20, e50, e200 = g("e20"), g("e50"), g("e200")
        prev = np.where(ok, S["e50"][np.maximum(j - 5, 0)], np.nan)
        stack = np.where((e20 > e50) & (e50 > e200), 1.0, np.where((e20 < e50) & (e50 < e200), -1.0, 0.0)) * d
        rng = g("hi50") - g("lo50")
        pos = (c - g("lo50")) / rng
        h_, l_, o_ = g("h"), g("l"), g("o")
        out = {
            "e50": d * (c - e50) / a, "e200": d * (c - e200) / a, "slope": d * (e50 - prev) / a,
            "stack": np.where(ok, stack, np.nan), "bos": d * g("bos"),
            "rsi": 50 + d * (g("rsi") - 50), "adx": g("adx"), "di": d * (g("pdi") - g("ndi")),
            "macd": d * g("hist") / a, "fi": d * g("fi") / (g("vsma") * a),
            "atrp": a / c * 100, "atrx": a / g("asma"), "vol": g("v") / g("vsma"),
            "rpos": np.where(d > 0, pos, 1 - pos), "bbw": g("bbw"),
            "candle": d * (c - o_) / (h_ - l_), "stoch": 50 + d * (g("stoch") - 50),
            "ms4": d * g("ms4"), "mslast": d * g("mslast"),
        }
    return {k: np.where(np.isfinite(v), v, np.nan) for k, v in out.items()}


def geo_values(d, entry, sl, tp, signal, hour, atr_exec):
    R = np.abs(entry - sl)
    with np.errstate(invalid="ignore", divide="ignore"):
        out = {"sl_atr": R / atr_exec, "rr": np.abs(tp - entry) / R, "depth": d * (signal - entry) / R,
               "side": d * 1.0, "asia": (hour < 8) * 1.0, "london": ((hour >= 8) & (hour < 13)) * 1.0,
               "ny": ((hour >= 13) & (hour < 21)) * 1.0, "late": (hour >= 21) * 1.0}
    return {k: np.where(np.isfinite(v), v, np.nan) for k, v in out.items()}


# ------------------------------------------------------------------ per koin
def mine(store, sym, res, exec_tf, htf, cap=None, seed=0):
    """Fitur + hasil simulasi untuk tiap trade. cap = maksimal trade yang disimpan (sampel acak tetap)."""
    tr = [t for t in res["trades"] if t.get("sl") and t.get("tp") and t["entry"] != t["sl"]]
    if not tr:
        return None
    if cap and len(tr) > cap:
        rng = np.random.default_rng(seed)
        tr = [tr[i] for i in sorted(rng.choice(len(tr), cap, replace=False))]
    base_tf = store.base_tf(sym)
    b = store.get(sym, base_tf)
    k = max(1, TF_MS.get(exec_tf, TF_MS[base_tf]) // TF_MS[base_tf])
    d = np.array([1.0 if t["side"] == "long" else -1.0 for t in tr])
    entry = np.array([t["entry"] for t in tr])
    sl = np.array([t["sl"] for t in tr])
    tp = np.array([t["tp"] for t in tr])
    sig_t = np.array([t.get("signal_time") or t["entry_time"] for t in tr], dtype=np.int64)
    signal = np.array([t.get("signal_price") or t["entry"] for t in tr])
    exitp = np.array([t["exit"] for t in tr])
    R = np.abs(entry - sl)
    y = d * (exitp - entry) / R

    names, cols = [], []
    atr_exec = None
    for tf in tfs_for(exec_tf, htf, base_tf):
        bars = store.get(sym, tf)
        idx = np.searchsorted(bars.t, sig_t - TF_MS[tf], side="right") - 1
        vals = tf_values(tf_series(bars), idx, d)
        if tf == exec_tf:
            atr_exec = vals["atrp"] * (signal / 100)
        for key, v in vals.items():
            names.append(f"{key}@{tf}")
            cols.append(v)
    if atr_exec is None:
        atr_exec = np.full(len(tr), np.nan)
    hour = (sig_t // 3_600_000) % 24
    for key, v in geo_values(d, entry, sl, tp, signal, hour, atr_exec).items():
        names.append(key)
        cols.append(v)

    # simulasi: SL x k, TP = rr x jarak SL baru (dari entry yang sama); entry lebih dalam (SL & TP tetap)
    N = 200 * k
    G = np.full((len(tr), len(K_SL), len(RR_GRID)), np.nan, np.float32)
    D = np.full((len(tr), len(DEPTH)), np.nan, np.float32)
    mfe_bins = np.zeros(12)
    W = 24 * k
    for n_, t in enumerate(tr):
        i0 = int(np.searchsorted(b.t, t["entry_time"]))
        s = slice(i0 + 1, min(len(b.t), i0 + 1 + N))
        hh, ll = b.h[s], b.l[s]
        if not len(hh):
            continue
        if d[n_] > 0:
            fav, adv, endv = np.maximum.accumulate(hh) - entry[n_], entry[n_] - np.minimum.accumulate(ll), b.c[s][-1] - entry[n_]
        else:
            fav, adv, endv = entry[n_] - np.minimum.accumulate(ll), np.maximum.accumulate(hh) - entry[n_], entry[n_] - b.c[s][-1]
        r = R[n_]
        for a, kk in enumerate(K_SL):
            sd = kk * r
            isl = np.searchsorted(adv, sd)
            itp = np.searchsorted(fav, np.array(RR_GRID) * sd)
            out = np.where(itp < isl, np.array(RR_GRID), -1.0)
            unresolved = (isl >= len(adv)) & (itp >= len(fav))
            out = np.where(unresolved, np.clip(endv / sd, -1, np.array(RR_GRID)), out)
            G[n_, a] = out
            if kk == 1.0:   # MFE sebelum SL asli
                m = fav[isl - 1] / r if isl > 0 else 0.0
                mfe_bins[min(int(max(m, 0) / 0.5), 11)] += 1
        tpd = abs(tp[n_] - entry[n_])
        isl = np.searchsorted(adv, r)
        itp = np.searchsorted(fav, tpd)
        for a, x in enumerate(DEPTH):
            f = np.searchsorted(adv, x * r)
            if f >= min(W, len(adv)) or itp < f:   # tidak terisi, atau harga ke TP dulu sebelum menyentuh limit
                continue
            win = itp < isl
            D[n_, a] = (tpd + x * r) / ((1 - x) * r) if win else (-1.0 if isl < len(adv) else
                                                              np.clip((endv + x * r) / ((1 - x) * r), -1, None))
    return {"X": np.column_stack(cols).astype(np.float32), "names": tuple(names), "y": y.astype(np.float32),
            "t": sig_t, "G": G, "D": D, "mfe": list(mfe_bins), "n_all": len(res["trades"])}


# ------------------------------------------------------------------ analisa gabungan
def _label(name):
    key, _, tf = name.partition("@")
    lab, desc = TF_FEATS.get(key) or GEO_FEATS.get(key) or (key, "")
    return (f"{lab} {tf.upper()}" if tf else lab), desc


def _fmt_num(x):
    if x == 0 or not np.isfinite(x):
        return "0"
    mag = abs(x)
    return f"{x:.0f}" if mag >= 100 else f"{x:.1f}" if mag >= 10 else f"{x:.2f}" if mag >= 1 else f"{x:.3f}"


def _stats(y):
    n = len(y)
    if not n:
        return {"n": 0, "win_rate": 0.0, "exp_r": 0.0}
    return {"n": int(n), "win_rate": float(100 * np.mean(y > 0)), "exp_r": float(np.mean(y))}


def _auc(a, b):
    """P(nilai menang > nilai kalah). 0.5 = tidak membedakan."""
    a, b = a[np.isfinite(a)], b[np.isfinite(b)]
    if len(a) < 10 or len(b) < 10:
        return None
    allv = np.concatenate([a, b])
    order = allv.argsort(kind="mergesort")
    ranks = np.empty(len(allv))
    ranks[order] = np.arange(1, len(allv) + 1)
    # rata-rata rank untuk nilai kembar
    _, inv, cnt = np.unique(allv, return_inverse=True, return_counts=True)
    sums = np.bincount(inv, ranks)
    ranks = (sums / cnt)[inv]
    return float((ranks[:len(a)].sum() - len(a) * (len(a) + 1) / 2) / (len(a) * len(b)))


def _rule_mask(x, op, thr):
    with np.errstate(invalid="ignore"):
        return (x >= thr) if op == ">=" else (x <= thr)


def _rules_ranked(X, y, cols, base_mask, min_keep, exclude=(), top=8):
    """Kandidat aturan tunggal (fitur, op, threshold) diurutkan dari skor terbaik di data `base_mask`.
    Skor = kenaikan expectancy × √n (lebih suka aturan yang membantu banyak trade). Satu kandidat terbaik per fitur."""
    yb = y[base_mask]
    if len(yb) < min_keep:
        return []
    mu = yb.mean()
    best = {}
    for j in cols:
        if j in exclude:
            continue
        x = X[base_mask, j]
        fin = np.isfinite(x)
        if fin.mean() < 0.8:
            continue
        qs = np.unique(np.nanquantile(x[fin], np.linspace(0.1, 0.9, 9)))
        for thr in qs:
            for op in (">=", "<="):
                m = _rule_mask(x, op, thr)
                nk = int(m.sum())
                if nk < min_keep or nk > 0.95 * len(x):
                    continue
                gain = yb[m].mean() - mu
                score = gain * math.sqrt(nk)
                if gain > 0.02 and (j not in best or score > best[j][0]):
                    best[j] = (score, j, op, float(thr), gain, nk)
    return sorted(best.values(), key=lambda b: -b[0])[:top]


def _round_thr(thr, op):
    """Bulatkan threshold ke angka yang enak dibaca, tanpa membuat aturan lebih longgar dari aslinya."""
    if thr == 0:
        return 0.0
    mag = 10 ** (math.floor(math.log10(abs(thr))) - 1)
    return (math.ceil(thr / mag) if op == ">=" else math.floor(thr / mag)) * mag


def _discrete_text(x, win, lab):
    vals = [v for v in np.unique(x[np.isfinite(x)]) if (x == v).sum() >= 10]
    names = {1.0: "searah", -1.0: "melawan", 0.0: "netral"} if set(vals) <= {-1.0, 0.0, 1.0} else {}
    parts = [f"{names.get(v, _fmt_num(v))}: WR {100 * win[x == v].mean():.0f}% ({int((x == v).sum())} trade)" for v in vals]
    return f"{lab}: " + " · ".join(parts) if parts else ""


def analyze(mine_raw, params, exec_tf, htf):
    m = mine_raw
    X, y, t, names = m["X"], m["y"].astype(float), m["t"], list(m["names"])
    ok = np.isfinite(y)
    X, y, t, G, D = X[ok], y[ok], t[ok], m["G"][ok], m["D"][ok]
    y = (y > 0).astype(float)          # teknikal saja: 1 = kena TP (menang), 0 = kena SL (kalah). Uang tidak dihitung
    n = len(y)
    if n < 60:
        return {"enough": False, "n": int(n),
                "message": f"Baru {n} trade dengan SL/TP. Analisa pola butuh minimal 60 trade (idealnya ratusan–ribuan): "
                           "jalankan di periode lebih panjang atau di semua koin."}
    win = y > 0
    # bagi menurut waktu: 50% latih (cari aturan), 20% validasi (terima/tolak), 30% uji (laporan jujur)
    q50, q70 = np.quantile(t, 0.5), np.quantile(t, 0.7)
    tr_m, va_m, te_m = t <= q50, (t > q50) & (t <= q70), t > q70
    fit_m = tr_m | va_m
    base = {"all": _stats(y), "train": _stats(y[tr_m]), "valid": _stats(y[va_m]), "test": _stats(y[te_m])}

    # ---- pola: indikator yang membedakan menang vs kalah
    feats = []
    for j, nm in enumerate(names):
        xj = X[:, j].astype(float)
        a = _auc(xj[win], xj[~win])
        if a is None:
            continue
        lab, desc = _label(nm)
        f = {"name": nm, "label": lab, "desc": desc, "auc": a,
             "win_med": float(np.nanmedian(xj[win])), "loss_med": float(np.nanmedian(xj[~win]))}
        s = abs(a - 0.5)
        f["strength"] = "kuat" if s >= 0.08 else "sedang" if s >= 0.04 else "lemah" if s >= 0.02 else "tidak ada"
        if len(np.unique(xj[np.isfinite(xj)])) <= 3:
            f["text"] = _discrete_text(xj, win, lab)
        else:
            f["text"] = (f"Trade kalah cenderung punya {lab} lebih {'rendah' if a > 0.5 else 'tinggi'} "
                         f"(median kalah {_fmt_num(f['loss_med'])} vs menang {_fmt_num(f['win_med'])}).")
        # konsisten di dua periode? (paruh awal vs paruh akhir data)
        a1, a2 = _auc(xj[win & tr_m], xj[~win & tr_m]), _auc(xj[win & ~tr_m], xj[~win & ~tr_m])
        f["stable"] = a1 is not None and a2 is not None and (a1 - 0.5) * (a2 - 0.5) > 0 and min(abs(a1 - .5), abs(a2 - .5)) >= 0.02
        feats.append(f)
    feats.sort(key=lambda f: -(abs(f["auc"] - 0.5) + (0.03 if f["stable"] else 0)))

    tf_rank = {}
    for f in feats:
        tf = f["name"].partition("@")[2] or "geometri"
        e = tf_rank.setdefault(tf, {"tf": tf, "best": f["label"], "auc": f["auc"], "power": 0.0, "n_signal": 0, "n_stable": 0})
        if abs(f["auc"] - 0.5) > e["power"]:
            e.update(best=f["label"], auc=f["auc"], power=abs(f["auc"] - 0.5))
        e["n_signal"] += abs(f["auc"] - 0.5) >= 0.04
        e["n_stable"] += bool(f["stable"])
    tf_list = sorted(tf_rank.values(), key=lambda e: -(e["power"] + 0.01 * e["n_stable"]))

    # ---- filter baru: cari di latih, terima hanya kalau validasi juga membaik, laporkan di uji
    cols = list(range(len(names)))
    rules, tried, used = [], [], set()
    cur = {"tr": tr_m.copy(), "va": va_m.copy(), "te": te_m.copy()}
    for _ in range(3):
        min_keep = max(30, int(0.25 * tr_m.sum()))
        if cur["tr"].sum() < 2 * min_keep * 0.8:
            break
        accepted = None
        for _, j, op, thr, gain, _ in _rules_ranked(X, y, cols, cur["tr"], min_keep, used):
            thr = _round_thr(thr, op)
            mk = lambda base_m: base_m & _rule_mask(X[:, j], op, thr)   # noqa: E731
            va_old, va_new = y[cur["va"]], y[mk(cur["va"])]
            ok_va = len(va_new) >= 15 and va_new.mean() >= va_old.mean() + 0.02 and \
                np.mean(va_new > 0) >= np.mean(va_old > 0) - 0.01
            lab, desc = _label(names[j])
            item = {"name": names[j], "op": op, "thr": thr, "label": lab, "desc": desc,
                    "text": f"{names[j]} {op} {_fmt_num(thr)}", "train": _stats(y[mk(cur["tr"])]),
                    "valid": _stats(va_new)}
            if ok_va:
                accepted = (j, item, mk)
                break
            tried.append(item)
        if not accepted:
            break
        j, item, mk = accepted
        cur = {k: mk(v) for k, v in cur.items()}
        item["test"] = _stats(y[cur["te"]])
        used.add(j)
        rules.append(item)
    rules_text = "; ".join(r["text"] for r in rules)
    final = {"train": _stats(y[cur["tr"]]), "valid": _stats(y[cur["va"]]), "test": _stats(y[cur["te"]])} if rules else None
    valid = bool(rules) and final["test"]["n"] >= 15 and final["test"]["exp_r"] > base["test"]["exp_r"] + 0.02 \
        and final["test"]["win_rate"] >= base["test"]["win_rate"] - 1
    keep_all = _apply(X, names, rules, np.ones(n, bool))

    # ---- simulasi TP / SL: pilih di data latih+validasi, cek di data uji
    RRa = np.array(RR_GRID)

    def cell(mask, a, r):
        g = G[mask, a, r]
        g = g[np.isfinite(g)]
        return {"n": int(len(g)), "win_rate": float(np.mean(g >= RRa[r] - 1e-9) * 100) if len(g) else 0.0,
                "exp_r": float(np.mean(g)) if len(g) else 0.0}

    def table(mask):
        g = G[mask]
        if not len(g):
            return None
        with np.errstate(invalid="ignore"):
            return {"win_rate": (np.nanmean(g >= RRa[None, None, :] - 1e-9, axis=0) * 100).round(2).tolist(),
                    "exp_r": np.nanmean(g, axis=0).round(4).tolist(), "n": int(len(g))}

    rr_now = float(np.nanmedian(X[:, names.index("rr")])) if "rr" in names else None
    a1 = K_SL.index(1.0)
    r1 = int(np.argmin([abs(r - rr_now) for r in RR_GRID])) if rr_now else RR_GRID.index(2.0)

    def choose(mask_fit, mask_test, need_wr=None):
        tb = table(mask_fit)
        if not tb:
            return None
        e, w = np.array(tb["exp_r"]), np.array(tb["win_rate"])
        cand = np.where(w >= need_wr, e, -np.inf) if need_wr else e.copy()
        a, r = np.unravel_index(np.argmax(cand), cand.shape)
        if not np.isfinite(cand[a, r]):
            return None
        out = {"sl_mult": K_SL[a], "rr": RR_GRID[r], "fit": cell(mask_fit, a, r), "test": cell(mask_test, a, r),
               "test_now": cell(mask_test, a1, r1), "fit_now": cell(mask_fit, a1, r1)}
        out["valid"] = out["test"]["n"] >= 15 and out["test"]["exp_r"] > out["test_now"]["exp_r"] + 0.02 and \
            (need_wr is None or (out["test"]["win_rate"] >= need_wr - 2 and out["test"]["exp_r"] > 0))
        return out

    best_exp = choose(fit_m, te_m)
    best_wr50 = choose(fit_m, te_m, 50)
    best_rules_wr50 = choose(fit_m & keep_all, te_m & keep_all, 50) if rules else None

    depth = []
    for a, x in enumerate(DEPTH):
        def st(mask):
            col = D[mask, a]
            filled = np.isfinite(col)
            return {"n": int(mask.sum()), "fill_pct": float(100 * filled.mean()) if len(col) else 0.0,
                    "win_rate": float(100 * np.mean(col[filled] > 0)) if filled.any() else 0.0,
                    "exp_r_signal": float(np.nansum(col) / max(1, mask.sum()))}
        f_, te = st(fit_m), st(te_m)
        depth.append({"x": x, **st(np.ones(n, bool)), "fit": f_, "test": te,
                      "valid": te["n"] >= 15 and te["exp_r_signal"] > base["test"]["exp_r"] + 0.02 and
                      f_["exp_r_signal"] > _stats(y[fit_m])["exp_r"] + 0.02})

    mfe = np.array(m["mfe"], float)
    mfe_pct = (100 * np.cumsum(mfe[::-1])[::-1] / mfe.sum()).round(1).tolist() if mfe.sum() else []
    existing = _existing(params, names, X, y, exec_tf, htf)

    return {"enough": True, "n": int(n), "n_all": int(m.get("n_all", n)), "base": base,
            "split": {"train_end": int(q50), "valid_end": int(q70)},
            "features": feats[:16], "timeframes": tf_list, "rules": rules, "rules_tried": tried[:6],
            "rules_text": rules_text, "rules_final": final, "rules_valid": valid,
            "grid": {"k": K_SL, "rr": RR_GRID, "all": table(np.ones(n, bool)), "rules": table(keep_all) if rules else None,
                     "rr_now": rr_now},
            "best_exp": best_exp, "best_wr50": best_wr50, "best_rules_wr50": best_rules_wr50,
            "depth": depth, "mfe_pct": mfe_pct, "existing": existing}


def _apply(X, names, rules, mask):
    m = mask.copy()
    for r in rules:
        m &= _rule_mask(X[:, names.index(r["name"])], r["op"], r["thr"])
    return m


def _existing(p, names, X, y, exec_tf, htf):
    """Bandingkan trade di dekat batas threshold yang sudah ada dengan sisanya."""
    trend_tf = p.get("trend_tf") or p.get("htf") or htf
    maps = [("adx_min", f"adx@{trend_tf}", "ADX minimal", lambda v: v, lambda thr: thr),
            ("vol_mult", f"vol@{exec_tf}", "Volume minimal (× rata-rata)", lambda v: v, lambda thr: thr),
            ("rsi_long", f"rsi@{exec_tf}", "RSI minimal untuk long", lambda v: v, lambda thr: thr),
            ("min_rr", "rr", "RR minimal", lambda v: v, lambda thr: thr),
            ("adx_filter_min", f"adx@{p.get('adx_filter_tf')}", "ADX filter umum", lambda v: v, lambda thr: thr)]
    out = []
    for key, feat, lab, _, _ in maps:
        v = p.get(key)
        if not v or feat not in names or (key == "adx_filter_min" and not p.get("adx_filter_tf")):
            continue
        x = X[:, names.index(feat)].astype(float)
        fin = np.isfinite(x)
        if fin.sum() < 60:
            continue
        q = float(np.nanquantile(x, 0.3))
        low, rest = fin & (x < q), fin & (x >= q)
        if low.sum() < 20 or rest.sum() < 20:
            continue
        el, er = y[low].mean(), y[rest].mean()
        item = {"param": key, "label": lab, "value": v, "feature": feat, "edge": q,
                "near": _stats(y[low]), "rest": _stats(y[rest])}
        if er - el > 0.06:
            item["action"] = "perketat"
            item["new"] = round(q, 1) if key != "min_rr" else round(q, 2)
            item["text"] = (f"{lab} = {v} masih meloloskan banyak trade yang kalah: trade dengan nilai {v}–{_fmt_num(q)} "
                            f"WR {100 * el:.0f}% vs {100 * er:.0f}% di atasnya. Naikkan ke ±{item['new']}.")
        elif el - er > -0.02:
            item["action"] = "longgarkan"
            item["new"] = round(v * 0.8, 2) if key != "rsi_long" else max(50, v - 5)
            item["text"] = (f"Trade yang nilainya mepet batas {lab} ({v}–{_fmt_num(q)}) tidak lebih buruk "
                            f"(WR {100 * el:.0f}% vs {100 * er:.0f}%). Threshold ini mungkin terlalu ketat dan membuang trade bagus: "
                            f"coba longgarkan ke {item['new']} (atau hapus), lalu bandingkan.")
        else:
            item["action"] = "pertahankan"
            item["text"] = f"{lab} = {v} sudah wajar (trade di dekat batas sedikit lebih sering kalah: WR {100 * el:.0f}% vs {100 * er:.0f}%)."
        out.append(item)
    return out


# ------------------------------------------------------------------ filter `rules` saat backtest
RULE_RE = re.compile(r"^\s*([a-z0-9_]+)(?:@([0-9]+[mhd]))?\s*(>=|<=|>|<)\s*(-?[0-9.]+)\s*$")


def parse_rules(text):
    """'rsi@1h >= 55; adx@4h >= 20; sl_atr <= 1.5' -> [(fitur, tf, op, angka)]. Error kalau formatnya salah."""
    out = []
    for part in re.split(r"[;\n]+", text or ""):
        if not part.strip():
            continue
        m = RULE_RE.match(part.strip().lower())
        if not m:
            raise ValueError(f"aturan tidak dikenali: '{part.strip()}' (contoh: rsi@1h >= 55)")
        key, tf, op, num = m.groups()
        if tf and key not in TF_FEATS or not tf and key not in GEO_FEATS:
            raise ValueError(f"fitur tidak dikenal di aturan '{part.strip()}'")
        if tf and tf not in TF_MS:
            raise ValueError(f"timeframe tidak dikenal di aturan '{part.strip()}'")
        out.append((key, tf, op, float(num)))
    return out


def rules_ok(rules, closed, d, entry, sl, tp, signal, now, exec_tf):
    """Cek aturan memakai candle yang sudah close (closed(tf, n) dari ctx)."""
    cache = {}
    for key, tf, op, num in rules:
        if tf:
            if tf not in cache:
                b = closed(tf, 600)
                cache[tf] = tf_values(tf_series(b), np.array([len(b) - 1]), d) if len(b) else None
            vals = cache[tf]
            v = float(vals[key][0]) if vals is not None else float("nan")
        else:
            if "geo" not in cache:
                b = closed(exec_tf, 60)
                a = atr(b.h, b.l, b.c, 14)[-1] if len(b) > 15 else float("nan")
                cache["geo"] = geo_values(d, np.array([entry]), np.array([sl]), np.array([tp]), np.array([signal]),
                                          np.array([(now // 3_600_000) % 24]), np.array([a]))
            v = float(cache["geo"][key][0])
        if not math.isfinite(v):
            return False
        if not (v >= num if op == ">=" else v <= num if op == "<=" else v > num if op == ">" else v < num):
            return False
    return True
