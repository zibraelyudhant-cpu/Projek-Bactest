"""🧠 Teknikal Analisis Pro Advance — logika BARU (bukan Whale, bukan Market Structure).

1. Pustaka setup price action (aturan pasti):
   A  pullback ke zona confluence (tren TF besar + Fib OTE 0.618–0.786 + minimal 1 confluence lain: EMA 50 / S-R flip)
   B  sweep likuiditas (low/high hari sebelumnya atau equal low/high disapu, close balik ke dalam)
   C  breakout–retest (range tembus dengan volume >= 1.5x rata-rata, searah tren)
   D  squeeze -> ekspansi (Bollinger paling sempit, close keluar band searah tren, ADX naik)
2. Kandidat entry SAMA dengan Whale (v4.17): MARKET (candle pemicu), LIMIT DEPAN SWING terdekat (+0.15 ATR) dan — live saja —
   LIMIT DEPAN TEMBOK whale (+0.1 ATR, dinilai dengan backtest cara Whale di candle koin itu). Dipakai yang terbaik (lolos
   syarat dulu, lalu paling sering MANTUL BERSIH, lalu R per sinyal).
   Syarat layak SAMA dengan Whale: sampel >= 30 trade & rata-rata untung (WR TP1 x 2 - kalah > 0, belum kena TP1 dalam 2 hari
   = tidak menang). Untung di 30% terakhir & tersentuh >= 70% (24 jam) = info. Trade maks 2 hari.
3. SL (v4.15) = SL ANTI-GOCEKAN logika menu Whale (antigocek.py): di luar swing terdekat + kedalaman 90% gocekan, lewati
   angka bulat, maks 4% — riwayat tanpa tembok, sinyal sekarang ikut tembok order book live. TP1 = 1:2 (ambil 50%, SL ke entry), TP2 minimal 1:3 — dinaikkan (1:4, 1:5, ...) kalau
   di riwayat itu memberi rata-rata hasil lebih baik.
4. Backtest semua kejadian setup di riwayat banyak koin (data lokal), 70% data awal untuk mencari, 30% terakhir untuk menguji.
5. Model peluang (regresi logistik) dari kondisi saat setup muncul (ADX, kemiringan tren, volume, RSI, tren BTC, Fear & Greed)
   -> peluang TP1 kena sebelum SL; bobot faktor dari data cari, dibuktikan di data uji.
6. Pemeriksa yang tidak bisa di-backtest: sentimen live (funding, OI, long/short top trader), order book live, fundamental
   (CoinGecko). Sentimen = peringatan, fundamental = veto / peringatan, order book = INFO (seperti Whale).
Semua tanpa intip masa depan: setup diketahui saat candle sinyal close; TF besar hanya candle yang sudah close.
"""
import json
import math
import os
import time
import urllib.request

import numpy as np

from . import antigocek as AG
from .data import TF_MS
from .indicators import adx as _adx, atr as _atr, ema as _ema, pivots, rsi as _rsi

STYLES = {
    # v4.17 (sama dengan Whale): trade maks 2 HARI, entry limit tersentuh dihitung dalam 24 JAM
    "intraday": {"tf": "15m", "htf": "4h", "d1": "1d", "fill_wait": 96, "hold": 192, "name": "Intraday (entry 15M · tren 4H + D1)"},
    "scalping": {"tf": "5m", "htf": "1h", "d1": None, "fill_wait": 288, "hold": 576, "name": "Scalping (entry 5M · tren 1H)"},
}
SETUPS = {"A": "Pullback ke zona confluence", "B": "Sweep likuiditas", "C": "Breakout–retest", "D": "Squeeze → ekspansi"}
TP1_R = 2.0
TP2_CHOICES = (3.0, 4.0, 5.0, 6.0, 8.0)
# v4.17: syarat layak DISAMAKAN dengan 🐋 Whale › 🎯 Cari setup (permintaan user):
#   layak = cukup RATA-RATA UNTUNG dengan rumus Whale di TP1: WR TP1 x 2 - (1 - WR TP1) > 0
#   (belum kena TP1 sampai batas 2 hari = tidak menang), sampel minimal = bt.min_trades Whale (30 trade).
#   Untung di 30% data terakhir & entry tersentuh >= 70% (24 jam) = INFO saja. Tidak ada WR minimal.
MIN_FILL = 70.0           # entry tersentuh >= 70% -> info (seperti Whale SETUP_MIN_FILL)
MIN_TEST = 10             # trade minimal di data uji supaya "terbukti" bisa dinilai (info, seperti Whale)
BOUNCE_BARS = 12          # mantul bersih: +1R dalam 12 candle tanpa close di area entry–SL (definisi user)
N_FEAT = ("adx", "slope", "vol", "rsi", "btc", "fng")
_CACHE = {}


# ================================================================== indikator & tren
def _slope(x, k, a):
    out = np.full(len(x), np.nan)
    out[k:] = (x[k:] - x[:-k]) / np.where(a[k:] > 0, a[k:], np.nan)
    return out


def _bbw(c, n=20):
    from numpy.lib.stride_tricks import sliding_window_view as sw
    w = np.full(len(c), np.nan)
    if len(c) >= n:
        W = sw(c, n)
        m = W.mean(1)
        w[n - 1:] = 4 * W.std(1) / np.where(m != 0, m, np.nan)
    return w


def _bb(c, n=20, k=2.0):
    from numpy.lib.stride_tricks import sliding_window_view as sw
    up, mid = np.full(len(c), np.nan), np.full(len(c), np.nan)
    if len(c) >= n:
        W = sw(c, n)
        mid[n - 1:] = W.mean(1)
        up[n - 1:] = mid[n - 1:] + k * W.std(1)
    return up, mid, 2 * mid - up


def trend_of(t, c, tf):
    """+1 naik / -1 turun / 0 tidak jelas per candle TF besar: close > EMA50 > EMA200 dan EMA50 menanjak (kebalikannya turun).
    Waktu = CLOSE candle (supaya dipetakan ke TF kecil tanpa intip masa depan)."""
    e50, e200 = _ema(c, 50), _ema(c, 200)
    up = (c > e50) & (e50 > e200) & (e50 > np.roll(e50, 5))
    dn = (c < e50) & (e50 < e200) & (e50 < np.roll(e50, 5))
    tr = np.where(up, 1, np.where(dn, -1, 0))
    tr[:205] = 0
    return np.asarray(t, np.int64) + TF_MS[tf], tr, _slope(e50, 5, _atr(np.asarray(c), np.asarray(c), np.asarray(c), 14) + 1e-12)


def map_closed(t_entry, tf, t_close_big, vals):
    """Nilai TF besar terakhir yang SUDAH close saat candle TF kecil close."""
    tc = np.asarray(t_entry, np.int64) + TF_MS[tf]
    j = np.searchsorted(t_close_big, tc, side="right") - 1
    out = np.where(j >= 0, np.asarray(vals)[np.clip(j, 0, None)], 0)
    return out


class Series:
    """Satu koin: candle TF entry + indikator + tren TF besar yang sudah dipetakan."""

    def __init__(self, sym, tf, t, o, h, l, c, v, big=(), btc=None, fng=None):
        self.sym, self.tf = sym, tf
        self.t, self.o, self.h, self.l, self.c, self.v = (np.asarray(x, float) for x in (t, o, h, l, c, v))
        self.t = self.t.astype(np.int64)
        self.n = len(self.c)
        self.a = _atr(self.h, self.l, self.c, 14)
        self.e50 = _ema(self.c, 50)
        self.vm = np.convolve(self.v, np.ones(20) / 20, "full")[:self.n]
        self.rsi = _rsi(self.c, 14)
        self.adx = _adx(self.h, self.l, self.c, 14)
        self.adx = self.adx[0] if isinstance(self.adx, tuple) else self.adx
        self.bbw = _bbw(self.c)
        self.bbu, self.bbm, self.bbl = _bb(self.c)
        trs, slope = [], np.zeros(self.n)
        for (tb, cb, tfb) in big:                          # semua TF besar harus searah (mis. 4H dan D1)
            tclose, trb, slb = trend_of(tb, cb, tfb)
            trs.append(map_closed(self.t, tf, tclose, trb))
            slope = slope + map_closed(self.t, tf, tclose, np.nan_to_num(slb))
        if trs:
            tr = trs[0].copy()
            for m in trs[1:]:
                tr = np.where(tr == m, tr, 0)
        self.trend = tr.astype(int) if trs else np.zeros(self.n, int)
        self.slope = slope / max(1, len(big))
        self.btc = np.zeros(self.n) if btc is None else map_closed(self.t, tf, btc[0], btc[1])
        self.fng = np.full(self.n, np.nan) if fng is None else fng_at(self.t, fng)
        # low / high hari sebelumnya (untuk setup B)
        day = self.t // 86_400_000
        self.pdl, self.pdh = np.full(self.n, np.nan), np.full(self.n, np.nan)
        ud, first = np.unique(day, return_index=True)
        lows = np.minimum.reduceat(self.l, first)
        highs = np.maximum.reduceat(self.h, first)
        k = np.searchsorted(ud, day) - 1
        okk = k >= 0
        self.pdl[okk], self.pdh[okk] = lows[k[okk]], highs[k[okk]]


# ================================================================== Fear & Greed (riwayat harian, alternative.me)
_FNG = {"t": 0, "d": None}


def fear_greed():
    """{hari_utc: nilai 0-100} atau None kalau tidak bisa diambil (tanpa internet / diblokir). Cache 6 jam."""
    if _FNG["d"] is not None and time.time() - _FNG["t"] < 6 * 3600:
        return _FNG["d"]
    try:
        with urllib.request.urlopen("https://api.alternative.me/fng/?limit=0&format=json", timeout=10) as r:
            js = json.loads(r.read().decode())
        _FNG["d"] = {int(x["timestamp"]) // 86400: float(x["value"]) for x in js.get("data", [])}
        _FNG["t"] = time.time()
    except Exception:                                                # noqa: BLE001 - fitur dibuang kalau tidak tersedia
        _FNG["d"], _FNG["t"] = {}, time.time()
    return _FNG["d"] or None


def fng_at(t_ms, fng):
    """Nilai Fear & Greed HARI SEBELUMNYA (yang sudah terbit) untuk tiap candle."""
    day = np.asarray(t_ms, np.int64) // 86_400_000 - 1
    return np.array([fng.get(int(d_), np.nan) for d_ in day], float)


# ================================================================== deteksi setup (dir +1 long / -1 short)
def detect(S, k_sw=3, start=220):
    """[(s, dir, kode, sl, {nama_entry: harga}, inv, market_s)] — s = candle sinyal (close).
    market_s = candle entry market (A: candle pemicu pertama di zona; lainnya = s)."""
    out = []
    h, l, c, o, a = S.h, S.l, S.c, S.o, S.a
    hi, lo = pivots(h, l, k_sw)
    hi_arr, lo_arr = np.sort(np.asarray(hi, int)), np.sort(np.asarray(lo, int))
    # ---------------- A: pullback ke zona confluence (impuls swing low -> swing high, lalu koreksi ke OTE)
    last_lo, last_hi = None, None
    sw = sorted([(int(x), 1) for x in hi] + [(int(x), -1) for x in lo])
    for i, typ in sw:
        conf = i + k_sw
        if conf >= S.n or conf < start:
            if typ == 1:
                last_hi = i
            else:
                last_lo = i
            continue
        for d in (1, -1):
            if typ != d:
                continue
            base = last_lo if d == 1 else last_hi
            if base is None or base >= i:
                continue
            p0, p1 = (l[base], h[i]) if d == 1 else (h[base], l[i])
            imp = abs(p1 - p0)
            A_ = a[conf]
            if not (A_ > 0 and imp >= 3 * A_ and S.trend[conf] == d):
                continue
            z_lo, z_hi = sorted((p1 - d * 0.618 * imp, p1 - d * 0.786 * imp))
            conf_n = 1
            if z_lo <= S.e50[conf] <= z_hi:
                conf_n += 1
            arr = hi_arr if d == 1 else lo_arr               # swing lama (S/R flip) 120 candle sebelum impuls
            prev = arr[np.searchsorted(arr, base - 120, "right"):np.searchsorted(arr, base, "left")]
            pv = h[prev] if d == 1 else l[prev]
            if len(prev) and np.any((pv >= z_lo - 0.2 * A_) & (pv <= z_hi + 0.2 * A_)):
                conf_n += 1
            if conf_n < 2:
                continue
            sl = p0 - d * 0.3 * A_
            near, deep = (z_hi, (z_lo + z_hi) / 2) if d == 1 else (z_lo, (z_lo + z_hi) / 2)
            ms = None                                        # candle pemicu: masuk zona lalu close balik searah
            for j in range(conf + 1, min(S.n, conf + 25)):
                if (l[j] < p0) if d == 1 else (h[j] > p0):
                    break
                touched = (l[j] <= z_hi) if d == 1 else (h[j] >= z_lo)
                if touched and ((c[j] > o[j] and c[j] > z_lo) if d == 1 else (c[j] < o[j] and c[j] < z_hi)):
                    ms = j
                    break
            out.append((conf, d, "A", sl, {"limit tepi zona (0.618)": near, "limit tengah zona (0.70)": deep}, p1, ms))
        if typ == 1:
            last_hi = i
        else:
            last_lo = i
    # (B, C, D diperiksa SEKALIGUS untuk semua candle dengan numpy; aturannya sama, lalu hanya kandidat yang dirakit)
    from numpy.lib.stride_tricks import sliding_window_view as swv
    n = S.n
    idx = np.arange(n)
    okA = np.isfinite(a) & (a > 0) & (idx >= start)

    def roll(x, w, fn, fill):                                # nilai fn(x[s-w:s]) untuk tiap s (nan kalau s < w)
        out_ = np.full(n, fill, float)
        if n > w:
            out_[w:] = fn(swv(x, w)[:-1], axis=1)
        return out_
    # ---------------- B: sweep likuiditas (low/high hari sebelumnya, atau equal low/high 2 swing terakhir)
    lo5, hi5 = roll(l, 5, np.min, np.nan), roll(h, 5, np.max, np.nan)
    for d in (1, -1):
        arr = lo_arr if d == 1 else hi_arr                    # swing yang sudah terkonfirmasi, 80 candle terakhir
        px = l if d == 1 else h
        lvl = (S.pdl if d == 1 else S.pdh).astype(float).copy()
        i_end = np.searchsorted(arr, idx - k_sw, "left")
        i_beg = np.searchsorted(arr, idx - 80, "right")
        has2 = (i_end - i_beg) >= 2
        j1 = arr[np.clip(i_end - 1, 0, max(0, len(arr) - 1))] if len(arr) else np.zeros(n, int)
        j2 = arr[np.clip(i_end - 2, 0, max(0, len(arr) - 1))] if len(arr) else np.zeros(n, int)
        pa_, pb_ = px[j1], px[j2]
        with np.errstate(invalid="ignore"):
            use_eq = has2 & (np.abs(pa_ - pb_) <= 0.2 * a)
        eqlv = np.minimum(pa_, pb_) if d == 1 else np.maximum(pa_, pb_)
        lvl = np.where(use_eq, eqlv, lvl)
        with np.errstate(invalid="ignore"):
            if d == 1:
                hit = (l < lvl - 0.05 * a) & (c > lvl) & (c > o) & (lo5 > lvl)
            else:
                hit = (h > lvl + 0.05 * a) & (c < lvl) & (c < o) & (hi5 < lvl)
        hit &= okA & (S.trend != -d) & np.isfinite(lvl) & (idx >= 5)
        for s in np.flatnonzero(hit):
            sl = (l[s] if d == 1 else h[s]) - d * 0.2 * a[s]
            mid = (c[s] + (l[s] if d == 1 else h[s])) / 2
            out.append((int(s), d, "B", sl, {"limit retest level": float(lvl[s]), "limit 50% ekor": mid}, None, int(s)))
    # ---------------- C: breakout–retest
    top, bot = roll(h, 30, np.max, np.nan), roll(l, 30, np.min, np.nan)
    cprev = np.r_[np.nan, c[:-1]]
    with np.errstate(invalid="ignore"):
        tight = (top - bot) <= 8 * a
        vol_ok = S.v >= 1.5 * S.vm
        up_b = (S.trend == 1) & (c > top) & (cprev <= top)
        dn_b = (S.trend == -1) & (c < bot) & (cprev >= bot)
    for s in np.flatnonzero(okA & tight & vol_ok & (up_b | dn_b)):
        d = int(S.trend[s])
        lvl_ = top[s] if d == 1 else bot[s]
        sl = lvl_ - d * 0.8 * a[s]
        out.append((int(s), d, "C", sl, {"limit retest level": float(lvl_), "limit level + 0.25 ATR": float(lvl_ + d * 0.25 * a[s])}, None, int(s)))
    # ---------------- D: squeeze -> ekspansi
    bw_inf = np.where(np.isfinite(S.bbw), S.bbw, np.inf)
    m119 = np.full(n, np.inf)
    if n > 120:
        m119[120:] = swv(bw_inf, 119)[:n - 120].min(axis=1)          # min bbw[s-120 : s-1]
    m6 = roll(bw_inf, 6, np.min, np.inf)
    adx3 = np.r_[np.full(3, np.nan), S.adx[:-3]]
    with np.errstate(invalid="ignore"):
        squeeze = np.isfinite(m119) & (m6 <= m119 * 1.05)
        o_up = (S.trend == 1) & (c > S.bbu)
        o_dn = (S.trend == -1) & (c < S.bbl)
        adx_up = S.adx > adx3
    for s in np.flatnonzero(okA & np.isfinite(S.bbw) & (S.trend != 0) & squeeze & (o_up | o_dn) & adx_up):
        d = int(S.trend[s])
        sl = ((l[s - 5:s + 1].min()) if d == 1 else (h[s - 5:s + 1].max())) - d * 0.3 * a[s]
        out.append((int(s), d, "D", sl, {"limit tepi band": S.bbu[s] if d == 1 else S.bbl[s], "limit garis tengah": S.bbm[s]}, None, int(s)))
    return out


# ================================================================== simulasi 1 trade
def _bounce(d, f, e, sl, h, l, c, market):
    """MANTUL BERSIH (definisi user): candle sentuh hanya EKOR (limit), +1R dalam BOUNCE_BARS candle tanpa close di area
    entry–SL. -> (mantul_bersih, main_dulu)."""
    risk = abs(e - sl)
    if risk <= 0:
        return False, False
    up = d == 1
    if not market and ((c[f] <= e) if up else (c[f] >= e)):
        return False, True
    tgt = e + risk if up else e - risk
    for j in range(f + 1, min(len(c), f + 1 + BOUNCE_BARS)):
        if (l[j] <= sl) if up else (h[j] >= sl):
            return False, True
        inside = (sl < c[j] <= e) if up else (e <= c[j] < sl)
        if (h[j] >= tgt) if up else (l[j] <= tgt):
            return (not inside), inside
        if inside:
            return False, True
    return False, False


def simulate(S, d, f, e, sl, hold, market):
    """Hasil trade dari candle terisi f: TP1 = 2R ambil 50% + SL ke entry; sisa ke TP2 (tiap pilihan).
    -> dict(hit1, R per TP2, bars, mfe) atau None kalau data belum cukup."""
    h, l, c = S.h, S.l, S.c
    end = f + hold
    if end >= S.n:
        return None
    risk = abs(e - sl)
    if risk <= 0:
        return None
    first = f + 1 if market else f
    hh, ll = h[f + 1:end + 1], l[f + 1:end + 1]
    adv = (l[first:end + 1] <= sl) if d == 1 else (h[first:end + 1] >= sl)
    isl = (first + int(np.argmax(adv))) if adv.any() else None
    fav = (hh - e) / risk if d == 1 else (e - ll) / risk
    t1 = np.flatnonzero(fav >= TP1_R)
    i1 = (f + 1 + int(t1[0])) if len(t1) else None
    if isl is not None and (i1 is None or isl <= i1):
        return {"hit1": False, "R": {k: -1.0 for k in TP2_CHOICES}, "bars": isl - f, "mfe": float(fav[:max(1, isl - f)].max(initial=0))}
    if i1 is None:                                            # waktu habis tanpa TP1 / SL
        r_ = ((c[end] - e) if d == 1 else (e - c[end])) / risk
        return {"hit1": False, "R": {k: float(max(-1.0, min(TP1_R, r_))) for k in TP2_CHOICES}, "bars": hold, "mfe": float(fav.max(initial=0)), "to": True}
    # sesudah TP1: sisa 50% ke TP2, SL pindah ke entry (break-even)
    seg_h, seg_l = h[i1 + 1:end + 1], l[i1 + 1:end + 1]
    back = (seg_l <= e) if d == 1 else (seg_h >= e)
    ib = int(np.argmax(back)) if back.any() else None
    fav2 = (seg_h - e) / risk if d == 1 else (e - seg_l) / risk
    R = {}
    for k in TP2_CHOICES:
        tk = np.flatnonzero(fav2 >= k)
        ik = int(tk[0]) if len(tk) else None
        if ik is not None and (ib is None or ik < ib):
            R[k] = 0.5 * TP1_R + 0.5 * k
        elif ib is not None:
            R[k] = 0.5 * TP1_R
        else:
            r_ = ((c[end] - e) if d == 1 else (e - c[end])) / risk
            R[k] = 0.5 * TP1_R + 0.5 * max(0.0, min(k, r_))
    return {"hit1": True, "R": R, "bars": i1 - f, "mfe": float(max(fav.max(initial=0), fav2.max(initial=0)))}


def fill_limit(S, d, s, e, sl, wait):
    """Candle limit terisi (sesudah candle sinyal s) atau None: batal kalau harga lebih dulu lari ke TP1."""
    h, l = S.h, S.l
    risk = abs(e - sl)
    t1 = e + d * TP1_R * risk
    for j in range(s + 1, min(S.n, s + 1 + wait)):
        if (l[j] <= e) if d == 1 else (h[j] >= e):
            return j
        if (h[j] >= t1) if d == 1 else (l[j] <= t1):
            return None
    return None


def features(S, s):
    return [S.adx[s] / 50, S.slope[s], (S.v[s] / S.vm[s] if S.vm[s] > 0 else 1.0) - 1, (S.rsi[s] - 50) / 50, S.btc[s],
            (S.fng[s] - 50) / 50 if np.isfinite(S.fng[s]) else np.nan]


# ================================================================== kandidat entry (sama dengan Whale)
ENTRY_SWING = "limit depan swing"
ENTRY_WALL = "limit depan tembok"


def _entries_at(S, g, s, d, ms):
    """Kandidat entry seperti 🐋 Whale (v4.17): market (candle pemicu setup) + limit di depan swing terdekat
    (+ entry.swing_buf_atr ATR). Limit depan tembok hanya live (riwayat order book tidak ada)."""
    C = AG.whale_cfg.get()
    out = {}
    if ms is not None and C["entry.use_market"] == "ya":
        out["market"] = float(S.c[ms])
    if C["entry.use_swing"] == "ya":
        sw = g.swing(s, d == 1, float(S.c[s]))
        a = g.a[s]
        if sw is not None and np.isfinite(a) and a > 0:
            e = sw + d * C["entry.swing_buf_atr"] * a
            if (d == 1 and e < S.c[s]) or (d == -1 and e > S.c[s]):
                out[ENTRY_SWING] = float(e)
    return out


def wall_entry(S, g, d, walls):
    """Limit depan tembok whale terkuat (asli kalau terlihat >= walls.real_seen scan), seperti Whale. None kalau tidak ada."""
    if not walls:
        return None
    C = AG.whale_cfg.get()
    if C["entry.use_wall"] != "ya":
        return None
    price, a = float(S.c[-1]), float(g.a[-1])
    my = "BUY" if d == 1 else "SELL"
    sw = [w for w in walls if w["side"] == my and ((w["price"] < price) if d == 1 else (w["price"] > price))
          and abs(w["price"] / price - 1) <= C["walls.max_dist_pct"] / 100]
    real = [w for w in sw if w.get("seen", 1) >= C["walls.real_seen"]] or sw
    if not real or not (a > 0):
        return None
    w = max(real, key=lambda w: w["usdt"])
    return float(w["price"] + d * C["entry.wall_buf_atr"] * a), w


def wall_stats(S, style, d, e, sl, tp2):  # sl = harga SL anti-gocekan
    """Limit depan tembok tidak bisa diuji di riwayat setup -> dinilai seperti Whale: backtest dari candle koin ini
    (setiap candle, jarak SL% & TP1% sama, kondisi tren EMA20 vs EMA50 sama seperti sekarang) + peluang tersentuh 24 jam."""
    from . import whales as W
    st = STYLES[style]
    price = float(S.c[-1])
    long = d == 1
    sl_pct, tp_pct = abs(e - sl) / e * 100, TP1_R * abs(e - sl) / e * 100
    e20, e50 = _ema(S.c, 20), _ema(S.c, 50)
    up_now = e20[-1] > e50[-1]
    mask = (e20 > e50) if up_now else (e20 <= e50)
    hold = st["hold"]
    b = W.first_touch_backtest(S.o, S.h, S.l, S.c, sl_pct, tp_pct, long, max_bars=hold, trend_mask=mask)
    if b["n"] < _min_trades():
        b = W.first_touch_backtest(S.o, S.h, S.l, S.c, sl_pct, tp_pct, long, max_bars=hold)
    if b["wr"] is None:
        return None
    fb = W.fill_backtest(S.h, S.l, S.c, abs(e / price - 1) * 100, long, max_bars=st["fill_wait"])
    fill = fb["fill_pct"] or 0.0
    w_ = b["wr"] / 100
    ex = w_ * TP1_R - (1 - w_)
    return {"code": None, "d": d, "entry": ENTRY_WALL, "n": b["n"], "n_fit": None, "n_test": None, "fill_pct": fill,
            "wr_fit": None, "wr_test": None, "wr": b["wr"], "tp2": tp2, "reach_tp2": {}, "exp_fit": None, "exp_test": None,
            "exp_r": ex, "exp_sig": ex * fill / 100, "clean_pct": 0.0, "main_pct": None, "max_loss_streak": None,
            "bars_med": b["bars_med"] or hold / 4, "model": None, "proven": None, "fill_ok": bool(fill >= MIN_FILL),
            "ok": bool(b["n"] >= _min_trades() and ex > 0), "live_bt": True}


# ================================================================== riwayat: semua kejadian + hasil per cara entry
def history_events(S, style):
    """Semua kejadian setup di 1 koin -> list baris trade per (setup, arah, cara entry)."""
    st = STYLES[style]
    rows = []
    g = AG.get_ctx(S, S.h, S.l, S.c)
    for s, d, code, _sl0, _lims, inv, ms in detect(S):
        cands = _entries_at(S, g, s, d, ms)
        for name, e in cands.items():
            mk = name == "market"
            sl = AG.sl_at(g, ms if mk else s, d == 1, e)           # SL anti-gocekan (logika Whale), diketahui saat entry dipasang
            if sl is None:
                continue
            if (d == 1 and not sl < e) or (d == -1 and not e < sl):
                continue
            if not mk and ((d == 1 and e >= S.c[s]) or (d == -1 and e <= S.c[s])):
                continue                                     # limit harus di bawah (BUY) / di atas (SELL) harga saat sinyal
            f = ms if mk else fill_limit(S, d, s, e, sl, st["fill_wait"])
            row = {"sym": S.sym, "t": int(S.t[s]), "code": code, "d": d, "entry": name, "filled": f is not None,
                   "e": float(e), "sl": float(sl)}                    # untuk 🔍 contoh trade
            if f is not None:
                r = simulate(S, d, f, e, sl, st["hold"], mk)
                if r is None:
                    continue
                b, m = _bounce(d, f, e, sl, S.h, S.l, S.c, mk)
                row.update(hit1=r["hit1"], R={str(k): v for k, v in r["R"].items()}, bars=r["bars"], clean=b, main=m,
                           fb=int(f - s), to=bool(r.get("to")),
                           x=[float(v) for v in features(S, s)])
            elif s + st["fill_wait"] >= S.n:
                continue                                     # belum tahu terisi atau tidak
            rows.append(row)
    return rows


def _logit_fit(X, y, l2=1.0, it=300):
    X = np.asarray(X, float)
    mu, sd = X.mean(0), X.std(0) + 1e-9
    Z = (X - mu) / sd
    w, b = np.zeros(Z.shape[1]), 0.0
    for _ in range(it):
        p = 1 / (1 + np.exp(-(Z @ w + b)))
        g = p - y
        w -= 0.1 * (Z.T @ g / len(y) + l2 * w / len(y))
        b -= 0.1 * g.mean()
    return {"w": w.tolist(), "b": float(b), "mu": mu.tolist(), "sd": sd.tolist()}


def _logit_p(M, x):
    z = (np.asarray(x, float) - np.asarray(M["mu"])) / np.asarray(M["sd"])
    return float(1 / (1 + math.exp(-(float(z @ np.asarray(M["w"])) + M["b"]))))


def _streak(rs):
    best = cur = 0
    for r in rs:
        cur = cur + 1 if r < 0 else 0
        best = max(best, cur)
    return best


N_EXAMPLES = 150


def _examples(G, k, t_split):
    """🔍 Contoh trade: N_EXAMPLES kejadian terbaru (semua koin) untuk setup × arah × entry ini, dengan TP2 terpilih."""
    out = []
    for r in sorted(G, key=lambda r: r["t"])[-N_EXAMPLES:]:
        if "e" not in r:
            continue
        d, e, sl = r["d"], r["e"], r["sl"]
        risk = abs(e - sl)
        x = {"sym": r["sym"], "t": r["t"], "d": d, "e": e, "sl": sl, "tp1": e + d * TP1_R * risk, "tp2": e + d * k * risk,
             "filled": r["filled"], "test": r["t"] >= t_split}
        if r["filled"]:
            R = r["R"][str(k)]
            res = ("waktu habis" if r.get("to") else "SL") if not r["hit1"] else (
                "TP1 → TP2" if R >= 0.5 * TP1_R + 0.5 * k - 1e-9 else "TP1 → BE" if abs(R - 0.5 * TP1_R) < 1e-9 else "TP1 → waktu habis")
            x.update(fb=r.get("fb"), res=res, R=round(float(R), 3), win=bool(r["hit1"]), bars=r["bars"], clean=bool(r["clean"]))
        out.append(x)
    return out


def _min_trades():
    return int(AG.whale_cfg.get()["bt.min_trades"])               # sampel minimal = pengaturan Whale (30)


def stats(rows):
    """Statistik per (setup, arah, cara entry): terisi, peluang TP1, TP2 terbaik, R per trade/sinyal (cari & uji), mantul
    bersih, model peluang."""
    if not rows:
        return {}
    t_split = float(np.quantile([r["t"] for r in rows], 0.7))
    groups = {}
    for r in rows:
        groups.setdefault((r["code"], r["d"], r["entry"]), []).append(r)
    out = {}
    for key, G in groups.items():
        fit = [r for r in G if r["t"] < t_split]
        test = [r for r in G if r["t"] >= t_split]
        Ff, Ft = [r for r in fit if r["filled"]], [r for r in test if r["filled"]]
        if len(Ff) + len(Ft) < 15:
            continue
        mk = key[2] == "market"
        fill = 100.0 if mk else 100 * len([r for r in G if r["filled"]]) / len(G)
        best_k, best_e = None, -9
        for k in TP2_CHOICES:                                 # TP2 dipilih di data CARI saja (hasil nyata TP1 50% + TP2)
            e_ = float(np.mean([r["R"][str(k)] for r in Ff])) if Ff else -9
            if e_ > best_e:
                best_k, best_e = k, e_
        wr = lambda F: (100 * float(np.mean([r["hit1"] for r in F])) if F else None)  # noqa: E731
        # rumus Whale di TP1 (1:2): WR x RR - kalah; belum kena TP1 sampai batas waktu = tidak menang
        wx = lambda F: ((w_ / 100) * TP1_R - (1 - w_ / 100) if (w_ := wr(F)) is not None else None)  # noqa: E731
        ex2 = lambda F: (float(np.mean([r["R"][str(best_k)] for r in F])) if F else None)  # noqa: E731
        allF = sorted(Ff + Ft, key=lambda r: r["t"])
        reach = {str(k): 100 * float(np.mean([r["R"][str(k)] >= 0.5 * TP1_R + 0.5 * k - 1e-9 for r in allF])) for k in TP2_CHOICES}
        S_ = {"code": key[0], "d": key[1], "entry": key[2], "n": len(allF), "n_fit": len(Ff), "n_test": len(Ft), "fill_pct": fill,
              "wr_fit": wr(Ff), "wr_test": wr(Ft), "wr": wr(allF), "tp2": best_k, "reach_tp2": reach,
              "exp_fit": wx(Ff), "exp_test": wx(Ft), "exp_r": wx(allF),
              "exp_tp2_fit": ex2(Ff), "exp_tp2_test": ex2(Ft), "exp_tp2": ex2(allF),          # info: hasil nyata TP1 50% + TP2
              "clean_pct": 100 * float(np.mean([r["clean"] for r in allF])),
              "main_pct": 100 * float(np.mean([r["main"] for r in allF])), "max_loss_streak": _streak([1.0 if r["hit1"] else -1.0 for r in allF]),
              "bars_med": float(np.median([r["bars"] for r in allF]))}
        S_["exp_sig"] = (S_["exp_r"] or 0) * fill / 100      # skor Whale: R x peluang tersentuh
        # model peluang TP1: fitur yang tersedia (Fear & Greed dibuang kalau tidak ada datanya)
        cols = [i for i in range(len(N_FEAT)) if all(np.isfinite(r["x"][i]) for r in allF)]
        S_["model"] = None
        if len(Ff) >= 30 and len(Ft) >= MIN_TEST and cols:
            X = np.array([[r["x"][i] for i in cols] for r in Ff])
            y = np.array([1.0 if r["hit1"] else 0.0 for r in Ff])
            M = _logit_fit(X, y)
            M["cols"] = cols
            pt = [_logit_p(M, [r["x"][i] for i in cols]) for r in Ft]
            sel = [r for r, p in zip(Ft, pt) if p >= 0.5]
            M["test_n_sel"] = len(sel)
            M["test_wr_sel"] = wr(sel)
            M["test_exp_sel"] = wx(sel)
            M["proven"] = bool(sel and len(sel) >= MIN_TEST and M["test_exp_sel"] > 0)
            M["weights"] = {N_FEAT[i]: round(float(w_ / s_), 4) for i, w_, s_ in zip(cols, M["w"], M["sd"])}
            S_["model"] = M
        # syarat layak = Whale: sampel >= bt.min_trades & rata-rata untung. Uji 30% & tersentuh = info
        S_["proven"] = bool(S_["n_test"] >= MIN_TEST and (S_["exp_test"] or 0) > 0)
        S_["fill_ok"] = bool(mk or fill >= MIN_FILL)
        S_["ok"] = bool(S_["n"] >= _min_trades() and (S_["exp_r"] or 0) > 0)
        S_["examples"] = _examples(G, best_k, t_split)
        out[key] = S_
    return out


def best_entry(ST, code, d):
    """Mode entry seperti Whale: market & limit; yang lolos syarat dulu, lalu paling sering MANTUL BERSIH, lalu R/sinyal."""
    cand = [v for (c_, d_, _), v in ST.items() if c_ == code and d_ == d]
    if not cand:
        return None, []
    cand.sort(key=_entry_key, reverse=True)
    return cand[0], cand


def _entry_key(v):
    return (v["ok"], round((v.get("clean_pct") or 0) / 5), v["exp_sig"])


# ================================================================== pemeriksa live (tidak bisa di-backtest)
_CG = {"t": 0, "d": {}}


def coingecko():
    """{SIMBOL: data} 1000 koin market cap terbesar (cache 1 jam). {} kalau CoinGecko tidak bisa diakses."""
    if _CG["d"] and time.time() - _CG["t"] < 3600:
        return _CG["d"]
    out = {}
    try:
        for page in (1, 2, 3, 4):
            url = f"https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page={page}"
            req = urllib.request.Request(url, headers={"User-Agent": "futures-replay"})
            with urllib.request.urlopen(req, timeout=15) as r:
                for x in json.loads(r.read().decode()):
                    k = str(x.get("symbol", "")).upper()
                    if k and k not in out:
                        out[k] = {"name": x.get("name"), "mcap": x.get("market_cap"), "fdv": x.get("fully_diluted_valuation"),
                                  "vol": x.get("total_volume"), "circ": x.get("circulating_supply"), "total": x.get("total_supply"),
                                  "rank": x.get("market_cap_rank")}
    except Exception:                                                # noqa: BLE001
        pass
    if out:
        _CG["d"], _CG["t"] = out, time.time()
    return _CG["d"]


def base_asset(sym):
    b = sym[:-4] if sym.endswith("USDT") else sym
    for p in ("1000000", "10000", "1000"):
        if b.startswith(p):
            return b[len(p):]
    return b


def check_fundamental(sym):
    cg = coingecko()
    if not cg:
        return {"ok": None, "items": [], "note": "CoinGecko tidak bisa diakses — pilar fundamental tidak dihitung"}
    x = cg.get(base_asset(sym))
    if not x:
        return {"ok": None, "items": [], "note": "koin tidak ada di 1000 market cap terbesar CoinGecko"}
    items, veto = [], False
    mc, fdv, vol = x.get("mcap") or 0, x.get("fdv") or 0, x.get("vol") or 0
    items.append(["Market cap", f"${mc / 1e6:,.0f} jt (peringkat #{x.get('rank')})", "warn" if mc < 30e6 else "ok"])
    if mc < 15e6:
        veto = True
        items[-1][2] = "veto"
    if mc and fdv:
        r = fdv / mc
        items.append(["FDV ÷ market cap", f"{r:.1f}×" + (" (banyak token belum beredar → rawan unlock)" if r > 3 else ""), "warn" if r > 3 else "ok"])
    if mc and vol:
        r = vol / mc
        items.append(["Volume 24j ÷ market cap", f"{r:.2f}" + (" (sangat spekulatif)" if r > 1.5 else ""), "warn" if r > 1.5 else "ok"])
    return {"ok": not veto, "veto": veto, "items": items, "name": x.get("name")}


def check_sentiment(c, sym, d):
    """Funding, Open Interest 24 jam, long/short top trader, Fear & Greed sekarang (live, tidak di-backtest)."""
    items = []
    try:
        pi = c.get("/fapi/v1/premiumIndex", symbol=sym)
        fr = float(pi.get("lastFundingRate", 0)) * 100
        crowded = (fr > 0.05 and d == 1) or (fr < -0.05 and d == -1)
        items.append(["Funding", f"{fr:+.4f}%" + (" (posisi searah sudah ramai)" if crowded else ""), "warn" if crowded else "ok"])
    except Exception:                                                # noqa: BLE001
        pass
    try:
        oi = c.get("/futures/data/openInterestHist", symbol=sym, period="1h", limit=25)
        o0, o1 = float(oi[0]["sumOpenInterestValue"]), float(oi[-1]["sumOpenInterestValue"])
        ch = (o1 / o0 - 1) * 100 if o0 else 0
        items.append(["Open Interest 24j", f"{ch:+.1f}%", "ok"])
    except Exception:                                                # noqa: BLE001
        pass
    try:
        ls = c.get("/futures/data/topLongShortPositionRatio", symbol=sym, period="1h", limit=1)
        r = float(ls[-1]["longShortRatio"])
        against = (r < 0.8 and d == 1) or (r > 1.25 and d == -1)
        items.append(["Long/short top trader", f"{r:.2f}" + (" (top trader condong berlawanan)" if against else ""), "warn" if against else "ok"])
    except Exception:                                                # noqa: BLE001
        pass
    fg = fear_greed()
    if fg:
        v = fg[max(fg)]
        ext = (v >= 80 and d == 1) or (v <= 20 and d == -1)
        items.append(["Fear & Greed", f"{v:.0f}" + (" (ekstrem searah posisi)" if ext else ""), "warn" if ext else "ok"])
    return {"items": items}


def check_orderbook(c, sym, d, e, sl, tp1):
    """Tembok order book yang menghalangi TP1 atau zona tipis di dekat SL (live)."""
    try:
        ob = c.get("/fapi/v1/depth", symbol=sym, limit=500)
    except Exception:                                                # noqa: BLE001
        return {"items": [], "note": "order book tidak bisa diambil"}
    bids = [(float(p), float(q) * float(p)) for p, q in ob.get("bids", [])]
    asks = [(float(p), float(q) * float(p)) for p, q in ob.get("asks", [])]
    lv = bids + asks
    if not lv:
        return {"items": []}
    med = float(np.median([u for _, u in lv]))
    lo_, hi_ = sorted((e, tp1))
    opp = asks if d == 1 else bids
    block = [(p, u) for p, u in opp if lo_ < p < hi_ and u >= 20 * med]
    items = []
    if block:
        p, u = max(block, key=lambda x: x[1])
        items.append(["Tembok di jalur TP1", f"{p:.6g} · {u / 1e3:,.0f} rb USDT (info, seperti Whale)", "info"])
    else:
        items.append(["Jalur ke TP1", "tidak ada tembok besar", "ok"])
    same = bids if d == 1 else asks
    lo2, hi2 = sorted((sl, e))
    sup = sum(u for p, u in same if lo2 <= p <= hi2)
    items.append(["Antrean pelindung entry–SL", f"{sup / 1e3:,.0f} rb USDT" + (" (tipis — info)" if sup < 5 * med else ""), "info" if sup < 5 * med else "ok"])
    return {"items": items}


# ================================================================== pengolahan riwayat (data lokal, banyak koin)
def _series_from_store(store, sym, style, btc=None, fng=None):
    st = STYLES[style]
    b = store.get(sym, st["tf"])
    big = []
    for tfb in (st["htf"], st["d1"]):
        if tfb and tfb in store.timeframes(sym):
            bb = store.get(sym, tfb)
            big.append((np.asarray(bb.t, np.int64), np.asarray(bb.c, float), tfb))
    v = np.asarray(getattr(b, "v", np.ones(len(b.c))), float)
    return Series(sym, st["tf"], b.t, b.o, b.h, b.l, b.c, v, big, btc, fng)


def _btc_trend(store, style):
    st = STYLES[style]
    for s_ in ("BTCUSDT",):
        if s_ in store.catalog and st["htf"] in store.timeframes(s_):
            bb = store.get(s_, st["htf"])
            tclose, tr, _ = trend_of(np.asarray(bb.t, np.int64), np.asarray(bb.c, float), st["htf"])
            return tclose, tr
    return None


def history_symbols(store, style, n=30, include=None):
    tf = STYLES[style]["tf"]
    syms = [s_ for s_ in store.symbols() if tf in store.timeframes(s_)] if hasattr(store, "symbols") else []
    syms.sort(key=lambda s_: -len(store.get(s_, store.base_tf(s_)).c))
    out = ([include] if include and include in syms else []) + [s_ for s_ in syms if s_ != include]
    return out[:n]


def _disk(style):
    from .results_store import BASE
    return os.path.join(BASE, "tapro", f"learn_{style}.json")


def learn(store, style, syms, progress=None):
    """Statistik + model dari riwayat banyak koin (data lokal). Disimpan di memori DAN file (saved/results/tapro): scan
    berikutnya (juga sesudah aplikasi dibuka ulang) langsung memakai hasil ini, kecuali data candle / koin / gaya berubah."""
    fng = fear_greed()
    key = (style, tuple(syms), tuple(int(store.get(s_, store.base_tf(s_)).t[-1]) for s_ in syms), bool(fng),
           ("sl-anti-gocek", "syarat-whale", "contoh-trade", MIN_FILL, _min_trades(), STYLES[style]["fill_wait"], STYLES[style]["hold"])
           + AG._cfg_sig(AG.whale_cfg.get())
           + tuple(AG.whale_cfg.get()[k] for k in ("entry.use_market", "entry.use_swing", "entry.swing_buf_atr")))       # SL anti-gocekan / pengaturan Whale berubah = hitung ulang
    if key in _CACHE:
        return _CACHE[key]
    kstr = json.dumps([key[0], list(key[1]), list(key[2]), key[3], list(key[4])])
    try:
        with open(_disk(style), encoding="utf-8") as f:
            D = json.load(f)
        if D.get("key") == kstr:
            R = D["res"]
            R["stats"] = {tuple(k): v for k, v in R["stats"]}
            R["from_file"] = True
            _CACHE[key] = R
            return R
    except (OSError, ValueError, KeyError, TypeError):
        pass
    btc = _btc_trend(store, style)
    rows = []
    for i, s_ in enumerate(syms):
        if progress:
            progress(i, len(syms), s_, None)
        try:
            S = _series_from_store(store, s_, style, btc, fng)
            if S.n > 600:
                rows += history_events(S, style)
        except (ValueError, KeyError, IndexError):
            continue
    res = {"stats": stats(rows), "n_rows": len(rows), "n_coins": len(syms), "fng": bool(fng), "btc": btc is not None}
    if len(_CACHE) > 8:
        _CACHE.clear()
    _CACHE[key] = res
    try:                                                     # simpan ke file (atomik)
        os.makedirs(os.path.dirname(_disk(style)), exist_ok=True)
        tmp = _disk(style) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"key": kstr, "saved": int(time.time() * 1000),
                       "res": {**res, "stats": [[list(k), v] for k, v in res["stats"].items()]}}, f, default=float)
        os.replace(tmp, _disk(style))
    except (OSError, TypeError, ValueError):
        pass
    return res


# ================================================================== sinyal sekarang
def live_series(c, sym, style, btc=None, fng=None):
    st = STYLES[style]
    now = time.time() * 1000

    def kl(tf, n):
        k = [r for r in c.get("/fapi/v1/klines", symbol=sym, interval=tf, limit=n) if float(r[6]) < now]
        return [np.array([float(r[j]) for r in k]) for j in (0, 1, 2, 3, 4, 5)]
    t, o, h, l, cl, v = kl(st["tf"], 1000)
    big = []
    for tfb in (st["htf"], st["d1"]):
        if tfb:
            tb, _, _, _, cb, _ = kl(tfb, 500)
            big.append((tb.astype(np.int64), cb, tfb))
    return Series(sym, st["tf"], t, o, h, l, cl, v, big, btc, fng)


def current_signals(S, style, ST):
    """Setup yang masih berlaku di candle terakhir -> rencana (entry terbaik, SL, TP1, TP2) + statistik riwayat."""
    st = STYLES[style]
    plans = []
    last = S.n - 1
    g = AG.get_ctx(S, S.h, S.l, S.c)
    walls = getattr(S, "walls", None)                        # tembok order book live (SL anti-gocekan seperti Whale)
    for s, d, code, _sl0, _lims, inv, ms in detect(S, start=max(220, S.n - st["fill_wait"] - 40)):
        if last - s > st["fill_wait"]:
            continue
        best0, cands = best_entry(ST, code, d)
        if best0 is None:
            continue
        ents = _entries_at(S, g, s, d, ms)
        we = wall_entry(S, g, d, walls)                      # limit depan tembok (live saja, dinilai cara Whale)
        if we is not None:
            inf_w = AG.sl_at(g, last, d == 1, we[0], walls)
            ws = wall_stats(S, style, d, we[0], inf_w, best0["tp2"]) if inf_w is not None else None
            if ws is not None:
                ws["code"], ws["wall"] = code, {"price": we[1]["price"], "usdt": we[1]["usdt"], "seen": we[1].get("seen", 1)}
                ents[ENTRY_WALL] = we[0]
                cands = sorted(cands + [ws], key=_entry_key, reverse=True)
        best = e = sl = sl_info = None
        for cand in cands:                                   # urutan terbaik dulu; yang sudah tidak berlaku dilewati
            name = cand["entry"]
            if name == "market":
                if ms is None or ms != last:
                    continue                                 # entry market hanya di candle sinyal terbaru
                e_ = float(S.c[ms])
            else:
                e_ = float(ents.get(name, np.nan))
                if not np.isfinite(e_) or (d == 1 and e_ >= S.c[last]) or (d == -1 and e_ <= S.c[last]):
                    continue
            inf = AG.sl_at(g, last, d == 1, e_, walls, detail=True)   # SL sekarang: anti-gocekan + tembok live
            if inf is None:
                continue
            sl_ = inf["sl"]
            if name == ENTRY_SWING:
                if fill_limit(S, d, s, e_, sl_, last - s + 1) is not None:
                    continue                                 # limit sudah tersentuh: jangan dikejar
            if (d == 1 and not sl_ < e_) or (d == -1 and not e_ < sl_):
                continue
            t1 = e_ + d * TP1_R * abs(e_ - sl_)
            if (d == 1 and S.h[s + 1:].max(initial=-np.inf) >= t1) or (d == -1 and S.l[s + 1:].min(initial=np.inf) <= t1):
                continue                                     # harga sudah lari ke TP1 tanpa kita
            best, e, sl, sl_info = cand, e_, sl_, inf
            break
        if best is None:
            continue
        name = best["entry"]
        risk = abs(e - sl)
        tp1 = e + d * TP1_R * risk
        tp2 = e + d * best["tp2"] * risk
        M = best.get("model")
        x = features(S, s)
        p = None
        if M and M.get("proven"):
            xs = [x[i] for i in M["cols"]]
            if all(np.isfinite(xs)):
                p = _logit_p(M, xs)
        prob = 100 * p if p is not None else best["wr"]
        plans.append({"code": code, "setup": SETUPS[code], "dir": d, "side": "BUY" if d == 1 else "SELL", "entry_kind": "market" if name == "market" else "limit",
                      "entry_name": name, "price_entry": e, "price_sl": float(sl), "price_tp1": float(tp1), "price_tp2": float(tp2),
                      "rr2": best["tp2"], "risk_pct": 100 * risk / e, "sl_reasons": sl_info["reasons"], "sl_walls": walls is not None, "signal_time": int(S.t[s]), "age": int(last - s),
                      "prob": float(prob), "prob_src": "model" if p is not None else "rata-rata setup", "stats": best,
                      "alts": [{k: v for k, v in c_.items() if k not in ("model", "examples")} for c_ in cands if c_ is not best][:4], "features": dict(zip(N_FEAT, [None if not np.isfinite(v) else round(float(v), 3) for v in x]))})
    plans.sort(key=lambda p: (p["stats"]["ok"], p["prob"]), reverse=True)
    return plans


def decide(plan, checks):
    """Rapat pilar -> skor, kelas & keputusan. Fundamental = veto / peringatan, sentimen = peringatan, order book = INFO
    (v4.17, seperti Whale: tidak dihitung ke TUNGGU)."""
    st = plan["stats"]
    warns = [it for k in ("sentiment", "orderbook", "fundamental") for it in (checks.get(k) or {}).get("items", []) if it[2] == "warn"]
    veto = bool((checks.get("fundamental") or {}).get("veto"))
    score = plan["prob"] - 8 * len(warns)
    cls = "A" if score >= 65 else "B" if score >= 55 else "C"
    if not st["ok"]:
        dec, why = "JANGAN", (f"sampel backtest < {_min_trades()} trade" if st["n"] < _min_trades()
                              else "rata-rata rugi di backtest (WR TP1 × 2 − kalah ≤ 0, rumus Whale)")
    elif veto:
        dec, why = "JANGAN", "fundamental: market cap terlalu kecil"
    elif len(warns) >= 2:
        dec, why = "TUNGGU", f"{len(warns)} peringatan dari sentimen / order book / fundamental"
    else:
        dec, why = "ENTRY", "rata-rata untung di backtest (rumus Whale)" + (", 1 peringatan" if warns else ", tanpa peringatan")
    return {"score": round(score, 1), "class": cls, "decision": dec, "why": why, "n_warn": len(warns)}


def card_data(S, plan, nbar=120):
    """Data kartu visual (candle, kotak angka, garis TP2) + animasi prediksi price action."""
    from . import papath as PA
    k0 = max(0, S.n - nbar)
    candles = [[int(S.t[i]), float(S.o[i]), float(S.h[i]), float(S.l[i]), float(S.c[i])] for i in range(k0, S.n)]
    st = plan["stats"]
    A = float(S.a[-1])
    price = float(S.c[-1])
    long = plan["dir"] == 1
    outcome = "tp" if plan["prob"] >= 50 else "sl"
    pa = None
    try:
        lv = PA.minor_levels(S.h, S.l)
        retr = PA.median_retrace(S.h, S.l, S.c)
        pa = PA.build(price, plan["price_entry"], plan["price_sl"], plan["price_tp1"], long, outcome,
                      int(min(200, max(3, st["bars_med"]))), A, levels=lv, retr=retr, seed=sum(map(ord, S.sym)))
    except Exception:                                                # noqa: BLE001
        pa = None
    proj = None
    if pa:
        lbl = f"{'✅ TP1 duluan' if outcome == 'tp' else '❌ SL duluan'} paling sering (peluang TP1 {plan['prob']:.0f}%)"
        proj = {"atr": A, "path": {"pa": pa, "close": pa["close"], "p25": pa["close"], "p75": pa["close"], "n": st["n"], "n_all": st["n"],
                                   "dir": 1 if pa["close"][-1] >= 0 else -1, "label": lbl, "target_r": pa["close"][-1]}}
    return {"candles": candles, "now_price": price, "now_time": int(S.t[-1]), "proj": proj, "atr": A}


def analyse(c, store, sym, style, hist_syms, ST, btc=None, fng=None, live=None):
    """1 koin: candle live -> setup yang berlaku -> rencana + pemeriksa + keputusan + data kartu."""
    S = live or live_series(c, sym, style, btc, fng)
    if c is not None and getattr(S, "walls", None) is None:
        S.walls = AG.live_walls(c, sym)                      # SL anti-gocekan live ikut tembok order book (seperti Whale)
    plans = current_signals(S, style, ST)
    out = []
    for p in plans[:3]:
        if p["stats"]["ok"]:
            checks = {"sentiment": check_sentiment(c, sym, p["dir"]), "orderbook": check_orderbook(c, sym, p["dir"], p["price_entry"], p["price_sl"], p["price_tp1"]),
                      "fundamental": check_fundamental(sym)}
        else:                                               # backtest tidak lolos -> keputusan pasti JANGAN, hemat permintaan
            skip = {"items": [], "note": "tidak diperiksa: setup ini tidak lolos backtest"}
            checks = {"sentiment": skip, "orderbook": skip, "fundamental": skip}
        p.update(checks=checks, **decide(p, checks))
        p["card"] = card_data(S, p)
        out.append(p)
    out.sort(key=lambda p: ({"ENTRY": 2, "TUNGGU": 1}.get(p["decision"], 0), p["score"]), reverse=True)
    return {"symbol": sym, "style": style, "tf": STYLES[style]["tf"], "price": float(S.c[-1]), "plans": out, "best": out[0] if out else None,
            "trend": int(S.trend[-1]), "time": int(S.t[-1])}
