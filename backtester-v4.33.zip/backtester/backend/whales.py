"""Pelacak whale Binance USDT-M Futures (data publik, tanpa API key).

Binance tidak membuka identitas / dompet pemilik order. Yang dilacak adalah JEJAK uang besar:
1. Tembok order (limit) besar di order book: di harga berapa, sisi BUY (bid) atau SELL (ask), berapa USDT.
2. Transaksi market besar terbaru (aggTrades): BUY (pembeli agresif) atau SELL (penjual agresif).

"Mampu menggerakkan harga" diukur dengan:
- dampak (%): kalau order sebesar itu dieksekusi market sekarang, harga bergerak berapa persen menyapu order book lawan;
- kekuatan tembok (%): porsi tembok itu dari semua order di sisi yang sama dalam +-2% dari harga;
- x volume/menit: nilai transaksi dibanding rata-rata volume per menit (volume 24 jam / 1440).
"""
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from . import whale_cfg

from .riskstats import risk_seq
from .screener import BinanceError, Client

WORKERS = 6


def walk_impact(levels, notional):
    """Persen pergerakan harga kalau order market senilai `notional` USDT menyapu `levels` [(harga, qty), ...]
    (urut dari harga terbaik). Kalau order book habis, dihitung sampai level terakhir (dampak minimal)."""
    if not levels or notional <= 0:
        return 0.0
    p0, left, last = levels[0][0], notional, levels[0][0]
    for px, qty in levels:
        val = px * qty
        last = px
        if val >= left:
            break
        left -= val
    return abs(last / p0 - 1) * 100


def analyse_book(sym, bids, asks, min_usdt, band=0.02):
    """Tembok order besar dari order book: level dengan nilai >= min_usdt."""
    if not bids or not asks:
        return []
    mid = (bids[0][0] + asks[0][0]) / 2
    side_tot = {
        "BUY": sum(p * q for p, q in bids if p >= mid * (1 - band)) or 1.0,
        "SELL": sum(p * q for p, q in asks if p <= mid * (1 + band)) or 1.0,
    }
    out = []
    for side, book, opp in (("BUY", bids, asks), ("SELL", asks, bids)):
        for px, qty in book:
            val = px * qty
            if val < min_usdt:
                continue
            out.append({"symbol": sym, "kind": "wall", "side": side, "price": px, "qty": qty, "usdt": val,
                        "dist_pct": (px / mid - 1) * 100,
                        "power_pct": 100 * val / side_tot[side] if abs(px / mid - 1) <= band else None,
                        "impact_pct": walk_impact(opp, val)})
    return out


def analyse_trades(sym, trades, bids, asks, min_usdt, vol_min):
    """Transaksi market besar: m = True -> pembeli adalah maker -> penjual agresif (SELL)."""
    out = []
    for t in trades:
        px, qty = float(t["p"]), float(t["q"])
        val = px * qty
        if val < min_usdt:
            continue
        side = "SELL" if t.get("m") else "BUY"
        out.append({"symbol": sym, "kind": "trade", "side": side, "price": px, "qty": qty, "usdt": val, "time": int(t["T"]),
                    "x_vol_min": val / vol_min if vol_min > 0 else None,
                    "impact_pct": walk_impact(asks if side == "BUY" else bids, val)})
    return out


class Whales:
    def __init__(self, client=None):
        self.c = client or Client()

    def scan(self, n_coins=20, top=10, min_usdt=100_000, min_impact=0.0, depth=500, progress=None, symbols=None):
        t0 = time.time()
        info = self.c.get("/fapi/v1/exchangeInfo")
        perp = {s["symbol"] for s in info["symbols"] if s.get("contractType") == "PERPETUAL"
                and s.get("quoteAsset") == "USDT" and s.get("status") == "TRADING"}
        tick = {t["symbol"]: t for t in self.c.get("/fapi/v1/ticker/24hr") if t["symbol"] in perp}
        if symbols:
            syms = [s for s in symbols if s in tick]
        else:
            syms = sorted(tick, key=lambda s: -float(tick[s]["quoteVolume"]))[:max(1, int(n_coins))]

        def load(sym):
            try:
                d = self.c.get("/fapi/v1/depth", symbol=sym, limit=depth)
                tr = self.c.get("/fapi/v1/aggTrades", symbol=sym, limit=1000)
                return sym, d, tr, None
            except BinanceError as e:
                return sym, None, None, str(e)

        walls, trades, errors = [], [], []
        with ThreadPoolExecutor(WORKERS) as pool:
            futs = [pool.submit(load, s) for s in syms]
            for k, f in enumerate(futs, 1):
                sym, d, tr, err = f.result()
                if err:
                    errors.append(f"{sym}: {err}")
                else:
                    bids = [(float(p), float(q)) for p, q in d["bids"]]
                    asks = [(float(p), float(q)) for p, q in d["asks"]]
                    vol_min = float(tick[sym]["quoteVolume"]) / 1440
                    walls += analyse_book(sym, bids, asks, min_usdt)
                    trades += analyse_trades(sym, tr, bids, asks, min_usdt, vol_min)
                if progress:
                    progress(k, len(syms), sym, err)
        if errors and len(errors) == len(syms):
            raise BinanceError(errors[0].split(": ", 1)[1])
        walls = [w for w in walls if w["impact_pct"] >= min_impact]
        trades = [t for t in trades if t["impact_pct"] >= min_impact]
        walls.sort(key=lambda w: (-w["impact_pct"], -w["usdt"]))
        trades.sort(key=lambda t: (-t["impact_pct"], -t["usdt"]))
        # ringkasan per koin: total tembok BUY vs SELL & transaksi BUY vs SELL (arah tekanan whale)
        coins = {}
        for x in walls + trades:
            c = coins.setdefault(x["symbol"], {"symbol": x["symbol"], "wall_buy": 0.0, "wall_sell": 0.0, "trade_buy": 0.0,
                                               "trade_sell": 0.0, "max_impact": 0.0,
                                               "price": float(tick[x["symbol"]]["lastPrice"]),
                                               "chg_24h": float(tick[x["symbol"]]["priceChangePercent"])})
            c[("wall_" if x["kind"] == "wall" else "trade_") + ("buy" if x["side"] == "BUY" else "sell")] += x["usdt"]
            c["max_impact"] = max(c["max_impact"], x["impact_pct"])
        for c in coins.values():
            tot = c["wall_buy"] + c["wall_sell"] + c["trade_buy"] + c["trade_sell"]
            c["bias"] = 100 * (c["wall_buy"] + c["trade_buy"] - c["wall_sell"] - c["trade_sell"]) / tot if tot else 0.0
        top = max(1, int(top))
        return {"walls": walls[:top], "trades": trades[:top],
                "coins": sorted(coins.values(), key=lambda c: -c["max_impact"])[:top],
                "scanned": len(syms) - len(errors), "errors": len(errors), "min_usdt": min_usdt, "min_impact": min_impact,
                "time": int(time.time() * 1000), "elapsed": round(time.time() - t0, 2), "weight": self.c.weight}


def usdt_to_move(levels, mid, pct):
    """USDT market order yang dibutuhkan untuk menyapu order book sampai harga bergerak `pct` persen."""
    lim = mid * (1 + pct / 100) if levels and levels[0][0] >= mid else mid * (1 - pct / 100)
    up = levels and levels[0][0] >= mid
    tot = 0.0
    for px, qty in levels:
        if (up and px > lim) or (not up and px < lim):
            return tot
        tot += px * qty
    return None                                     # order book yang dibaca tidak sampai sejauh itu


def analyse_coin(c, sym, top=10, min_usdt=50_000, min_impact=0.0, progress=None, light=False):
    """Analisa whale detail untuk 1 koin: tembok, transaksi besar, peta likuiditas, support/resistance whale,
    USDT yang dibutuhkan untuk menggerakkan harga, dan kesimpulan singkat."""
    t0 = time.time()
    sym = sym.upper()
    tick = c.get("/fapi/v1/ticker/24hr", symbol=sym)
    if isinstance(tick, list):
        tick = next((t for t in tick if t.get("symbol") == sym), None)
        if tick is None:
            raise ValueError(f"koin {sym} tidak ditemukan di Binance Futures")
    if progress:
        progress(1, 4, sym + " · harga", None)
    d = c.get("/fapi/v1/depth", symbol=sym, limit=int(whale_cfg.get()["walls.depth"]) if light else 1000)   # light: hemat weight saat scan banyak koin
    bids = [(float(p), float(q)) for p, q in d["bids"]]
    asks = [(float(p), float(q)) for p, q in d["asks"]]
    if not bids or not asks:
        raise ValueError(f"order book {sym} kosong")
    if progress:
        progress(2, 4, sym + " · order book", None)
    trades = c.get("/fapi/v1/aggTrades", symbol=sym, limit=1000)
    for _ in range(0 if light else 2):              # 2 halaman lagi ke belakang (total +-3000 transaksi)
        if not trades:
            break
        first = int(trades[0]["a"])
        if first <= 0:
            break
        older = c.get("/fapi/v1/aggTrades", symbol=sym, fromId=max(0, first - 1000), limit=1000)
        older = [t for t in older if int(t["a"]) < first]
        if not older:
            break
        trades = older + trades
    if progress:
        progress(3, 4, sym + " · transaksi", None)
    mid = (bids[0][0] + asks[0][0]) / 2
    vol_min = float(tick["quoteVolume"]) / 1440
    walls = [w for w in analyse_book(sym, bids, asks, min_usdt) if w["impact_pct"] >= min_impact]
    big = [t for t in analyse_trades(sym, trades, bids, asks, min_usdt, vol_min) if t["impact_pct"] >= min_impact]
    # peta likuiditas: +-5% dari harga, per 0.25%
    step, span = 0.25, 5.0
    nb = int(span / step)
    heat = []
    for k in range(-nb, nb):
        lo, hi = mid * (1 + k * step / 100), mid * (1 + (k + 1) * step / 100)
        heat.append({"from_pct": k * step, "to_pct": (k + 1) * step, "lo": lo, "hi": hi,
                     "bid": sum(p * q for p, q in bids if lo <= p < hi), "ask": sum(p * q for p, q in asks if lo <= p < hi)})
    sup = sorted([w for w in walls if w["side"] == "BUY"], key=lambda w: -w["usdt"])
    res = sorted([w for w in walls if w["side"] == "SELL"], key=lambda w: -w["usdt"])
    near_sup = max((w for w in walls if w["side"] == "BUY"), key=lambda w: w["price"], default=None)
    near_res = min((w for w in walls if w["side"] == "SELL"), key=lambda w: w["price"], default=None)
    move = {str(p): {"up": usdt_to_move(asks, mid, p), "down": usdt_to_move(bids, mid, p)} for p in (0.5, 1, 2, 5)}
    buy_t = sum(t["usdt"] for t in big if t["side"] == "BUY")
    sell_t = sum(t["usdt"] for t in big if t["side"] == "SELL")
    bid2 = sum(p * q for p, q in bids if p >= mid * 0.98)
    ask2 = sum(p * q for p, q in asks if p <= mid * 1.02)
    # kesimpulan sederhana
    lines = []
    if buy_t + sell_t > 0:
        r = buy_t / (buy_t + sell_t) * 100
        lines.append(f"Transaksi whale: {r:.0f}% BELI vs {100 - r:.0f}% JUAL → whale condong "
                     f"{'BELI (tekanan naik)' if r >= 60 else 'JUAL (tekanan turun)' if r <= 40 else 'seimbang'}.")
    else:
        lines.append(f"Belum ada transaksi market >= {min_usdt:,.0f} USDT di {len(trades)} transaksi terakhir.")
    if bid2 + ask2 > 0:
        r2 = bid2 / (bid2 + ask2) * 100
        lines.append(f"Order book ±2%: {r2:.0f}% antre BELI vs {100 - r2:.0f}% antre JUAL → "
                     f"{'bawah lebih tebal (support kuat)' if r2 >= 60 else 'atas lebih tebal (resistance kuat)' if r2 <= 40 else 'seimbang'}.")
    if near_sup:
        lines.append(f"Support whale terdekat {near_sup['price']:.6g} ({near_sup['dist_pct']:+.2f}%), nilai {near_sup['usdt']:,.0f} USDT.")
    if near_res:
        lines.append(f"Resistance whale terdekat {near_res['price']:.6g} ({near_res['dist_pct']:+.2f}%), nilai {near_res['usdt']:,.0f} USDT.")
    m1 = move["1"]
    if m1["up"] is not None and m1["down"] is not None:
        lines.append(f"Untuk mendorong harga NAIK 1% butuh ±{m1['up']:,.0f} USDT market buy; TURUN 1% butuh ±{m1['down']:,.0f} USDT market sell "
                     f"→ lebih mudah {'naik' if m1['up'] < m1['down'] else 'turun'}.")
    try:
        anti = anti_gocek(c, sym, float(tick["lastPrice"]), walls, heat)
    except (BinanceError, ValueError, KeyError, IndexError):
        anti = None
    try:
        plan = whale_plan(c, sym, float(tick["lastPrice"]), walls, buy_t, sell_t, bid2, ask2, anti)
    except (BinanceError, ValueError, KeyError, IndexError):
        plan = None
    if anti and anti.get("alarm") and anti["alarm"]["level"] != "NORMAL":
        al = anti["alarm"]
        lines.insert(0, f"🚨 {al['level']}: 5 menit terakhir volume {al['vol_ratio']:.1f}x normal, harga {al['move5_pct']:+.2f}% "
                        f"({al['dir']}) → kemungkinan gocekan sedang berjalan, jangan kejar harga.")
    if anti and anti["spoof"]["vanished"]:
        v = anti["spoof"]["vanished"][0]
        lines.append(f"👻 Tembok {'BELI' if v['side'] == 'BUY' else 'JUAL'} {v['price']:.6g} ({v['usdt']:,.0f} USDT) hilang saat harga mendekat → curiga palsu.")
    if progress:
        progress(4, 4, sym + " · selesai", None)
    top = max(1, int(top))
    return {"symbol": sym, "price": float(tick["lastPrice"]), "mid": mid, "chg_24h": float(tick["priceChangePercent"]),
            "vol_24h": float(tick["quoteVolume"]), "n_trades": len(trades), "min_usdt": min_usdt,
            "walls": sorted(walls, key=lambda w: (-w["impact_pct"], -w["usdt"]))[:top],
            "supports": sup[:top], "resistances": res[:top], "trades": sorted(big, key=lambda t: -t["time"])[:top],
            "biggest_trades": sorted(big, key=lambda t: -t["usdt"])[:top],
            "heat": heat, "move": move, "near_support": near_sup, "near_resist": near_res,
            "trade_buy": buy_t, "trade_sell": sell_t, "book_bid2": bid2, "book_ask2": ask2, "lines": lines, "plan": plan, "anti": anti,
            "time": int(time.time() * 1000), "elapsed": round(time.time() - t0, 2)}


# ---------------------------------------------------------------------------- rencana: kekuatan tren, perkiraan, SL/TP
def _ema(x, n):
    from .indicators import ema
    return ema(x, n)


def whale_plan(c, sym, price, walls, buy_t, sell_t, bid2, ask2, anti=None):
    """Perkiraan (bukan kepastian) dari data whale + harga:
    - kekuatan Bullish / Bearish / Sideways (tren EMA 20/50/200 H1, ADX H1, tekanan transaksi whale, order book +-2%);
    - perkiraan gerak dari volatilitas (ATR H1 & harian) dalam 4 jam / 1 hari;
    - SL & TP dari tembok whale (+ buffer ATR);
    - "kalau harga menyentuh tembok ini, perkiraan memantul berapa persen"."""
    import numpy as np

    from .indicators import atr, dmi
    k1 = c.get("/fapi/v1/klines", symbol=sym, interval="1h", limit=300)
    kd = c.get("/fapi/v1/klines", symbol=sym, interval="1d", limit=30)
    h, l, cl = (np.array([float(r[i]) for r in k1]) for i in (2, 3, 4))
    hd, ld, cd = (np.array([float(r[i]) for r in kd]) for i in (2, 3, 4))
    if len(cl) < 60:
        return None
    a1 = float(atr(h, l, cl, 14)[-1])
    ad = float(atr(hd, ld, cd, 14)[-1]) if len(cd) >= 15 else a1 * 5
    a1p, adp = 100 * a1 / price, 100 * ad / price
    e20, e50, e200 = (float(_ema(cl, n)[-1]) for n in (20, 50, 200))
    adx = float(dmi(h, l, cl, 14)[2][-1])
    # skor -100..+100 per faktor
    trend = (np.sign(price - e20) + np.sign(e20 - e50) + np.sign(e50 - e200)) / 3 * 100 if len(cl) >= 200 else \
        (np.sign(price - e20) + np.sign(e20 - e50)) / 2 * 100
    tw = 100 * (buy_t - sell_t) / (buy_t + sell_t) if buy_t + sell_t else 0.0
    bk = 100 * (bid2 - ask2) / (bid2 + ask2) if bid2 + ask2 else 0.0
    C = whale_cfg.get()
    wsum = (C["regime.w_trend"] + C["regime.w_trades"] + C["regime.w_book"]) or 1.0
    score = (C["regime.w_trend"] * trend + C["regime.w_trades"] * tw + C["regime.w_book"] * bk) / wsum
    side = float(np.clip(100 * (1 - adx / C["regime.adx_full"]), C["regime.side_min"], C["regime.side_max"])) if np.isfinite(adx) else 40.0
    bull = (100 - side) * (0.5 + score / 200)
    bear = 100 - side - bull
    regime = "BULLISH" if bull >= max(bear, side) else "BEARISH" if bear >= max(bull, side) else "SIDEWAYS"
    # perkiraan gerak (kisaran normal dari volatilitas) & arah
    dirn = 1 if bull > bear else -1
    m4, m24 = a1p * 2 * 0.8, adp * 0.8
    sup = sorted([w for w in walls if w["side"] == "BUY" and w["price"] < price], key=lambda w: -w["price"])
    res = sorted([w for w in walls if w["side"] == "SELL" and w["price"] > price], key=lambda w: w["price"])
    strong_sup = max((w for w in sup if (price - w["price"]) / price <= 0.03), key=lambda w: w["usdt"], default=None)
    strong_res = max((w for w in res if (w["price"] - price) / price <= 0.03), key=lambda w: w["usdt"], default=None)
    pred = {"atr1h_pct": a1p, "atrd_pct": adp, "move_4h": m4, "move_1d": m24, "dir": dirn,
            "to_resist_h": ((res[0]["price"] - price) / price * 100) / a1p if res and a1p else None,
            "to_support_h": ((price - sup[0]["price"]) / price * 100) / a1p if sup and a1p else None}
    # SL / TP
    def plan(long):
        if long:
            sl = (strong_sup["price"] - 0.25 * a1) if strong_sup else price - 1.5 * a1
            t1 = (res[0]["price"] - 0.1 * a1) if res else price + 2 * a1
            far = [w for w in res if w["price"] > t1 + 0.5 * a1]
            t2 = (max(far, key=lambda w: w["usdt"])["price"] - 0.1 * a1) if far else price + 3.5 * a1
            if t1 <= price:
                t1 = price + 1.5 * a1
        else:
            sl = (strong_res["price"] + 0.25 * a1) if strong_res else price + 1.5 * a1
            t1 = (sup[0]["price"] + 0.1 * a1) if sup else price - 2 * a1
            far = [w for w in sup if w["price"] < t1 - 0.5 * a1]
            t2 = (max(far, key=lambda w: w["usdt"])["price"] + 0.1 * a1) if far else price - 3.5 * a1
            if t1 >= price:
                t1 = price - 1.5 * a1
        t2 = max(t2, t1) if long else min(t2, t1)
        sl_from = None
        if anti:
            sl = anti["sl_long" if long else "sl_short"]["sl"]
            sl_from = "anti-gocekan: " + "; ".join(anti["sl_long" if long else "sl_short"]["reasons"])
        risk = abs(price - sl)
        return {"side": "LONG" if long else "SHORT", "entry": price, "sl": sl, "tp1": t1, "tp2": t2,
                "sl_pct": (sl / price - 1) * 100, "tp1_pct": (t1 / price - 1) * 100, "tp2_pct": (t2 / price - 1) * 100,
                "rr1": abs(t1 - price) / risk if risk else None, "rr2": abs(t2 - price) / risk if risk else None,
                "sl_from": sl_from or ("tembok BELI whale" if long and strong_sup else "tembok JUAL whale" if not long and strong_res else "ATR"),
                "tp_from": "tembok whale" if (res if long else sup) else "ATR"}
    plans = {"long": plan(True), "short": plan(False)}
    # pantulan kalau tembok tersentuh: dari kekuatan tembok & ATR, dibatasi tembok lawan berikutnya
    def bounce(w):
        pw = (w["power_pct"] or 5.0) / 100
        k = 0.8 + 2.2 * min(1.0, pw * 2)                    # tembok makin dominan -> pantulan makin jauh (0.8..3 ATR)
        base = k * a1
        if w["side"] == "BUY":
            nxt = [x for x in walls if x["side"] == "SELL" and x["price"] > w["price"]]
            cap = min((x["price"] for x in nxt), default=None)
            tgt = w["price"] + base if cap is None else min(w["price"] + base, cap)
        else:
            nxt = [x for x in walls if x["side"] == "BUY" and x["price"] < w["price"]]
            cap = max((x["price"] for x in nxt), default=None)
            tgt = w["price"] - base if cap is None else max(w["price"] - base, cap)
        hours = abs(tgt - w["price"]) / a1 if a1 else None
        return {"side": w["side"], "price": w["price"], "usdt": w["usdt"], "dist_pct": w["dist_pct"], "power_pct": w["power_pct"],
                "target": tgt, "move_pct": (tgt / w["price"] - 1) * 100, "hours": hours, "capped": cap is not None and tgt == cap}
    touch = [bounce(w) for w in sorted(sup, key=lambda w: -w["usdt"])[:3]] + [bounce(w) for w in sorted(res, key=lambda w: -w["usdt"])[:3]]
    return {"bull": bull, "bear": bear, "side": side, "regime": regime, "score": score, "adx": adx,
            "factors": {"trend": trend, "whale_trades": tw, "order_book": bk},
            "ema": {"e20": e20, "e50": e50, "e200": e200}, "pred": pred, "plans": plans, "touch": touch,
            "strong_support": strong_sup, "strong_resist": strong_res}


# ---------------------------------------------------------------------------- anti gocekan (stop hunt)
_WALL_HIST = {}            # simbol -> list snapshot tembok [(waktu, mid, [(harga, usdt, sisi)])], untuk deteksi tembok palsu
WICK_LOOKAHEAD = 96        # candle 15m (1 hari) untuk mencari sapuan swing
RECLAIM_BARS = 4           # sapuan dianggap gocekan kalau close balik ke dalam dalam <= 4 candle


def wick_backtest(h, l, c, a, swing=3, lookahead=None, reclaim=None, depth_pct=90):
    """Backtest dari candle: setiap swing high/low (fractal) yang kemudian DITEMBUS ekor candle, apakah harga balik
    (close kembali ke dalam dalam RECLAIM_BARS candle = gocekan) atau tembus beneran. Untuk gocekan: kedalaman tembus
    (dalam ATR). Hasil: jumlah sapuan, % gocekan, p50 / p80 / p90 kedalaman (ATR)."""
    import numpy as np

    from .indicators import pivots
    hi, lo = pivots(h, l, swing)
    pen, fake, real = [], 0, 0
    n = len(c)
    for idx, is_low in [(i, True) for i in lo] + [(i, False) for i in hi]:
        start = idx + swing + 1                                  # baru diketahui setelah terkonfirmasi
        lvl = l[idx] if is_low else h[idx]
        end = min(n, start + (lookahead or WICK_LOOKAHEAD))
        seg = l[start:end] if is_low else h[start:end]
        hit = np.flatnonzero(seg < lvl) if is_low else np.flatnonzero(seg > lvl)
        if not len(hit):
            continue
        j = start + int(hit[0])
        win = slice(j, min(n, j + (reclaim or RECLAIM_BARS)))
        back = (c[win] > lvl).any() if is_low else (c[win] < lvl).any()
        if back:
            fake += 1
            deep = (lvl - l[win].min()) if is_low else (h[win].max() - lvl)
            if np.isfinite(a[j]) and a[j] > 0:
                pen.append(deep / a[j])
        else:
            real += 1
    q = (lambda p: float(np.percentile(pen, p)) if pen else None)
    tot = fake + real
    return {"sweeps": tot, "fake": fake, "real": real, "fake_pct": 100 * fake / tot if tot else None,
            "p50": q(50), "p80": q(80), "p90": q(90), "pdepth": q(depth_pct), "depth_pct": depth_pct}


def _round_step(price):
    import math
    return 5 * 10 ** (math.floor(math.log10(price)) - 2)


def track_walls(sym, mid, walls, now=None):
    """Simpan snapshot tembok & bandingkan dengan scan sebelumnya:
    - tiap tembok sekarang diberi seen (berapa scan berturut-turut ada) & age_s (sejak kapan terlihat);
    - tembok yang di scan sebelumnya ada tapi sekarang HILANG padahal harga mendekatinya -> curiga palsu (spoofing)."""
    now = now or time.time()
    hist = [s for s in _WALL_HIST.get(sym, []) if now - s[0] <= 1800][-10:]
    C = whale_cfg.get()
    tol, keep, left = C["walls.tol_pct"] / 100, C["walls.keep_pct"] / 100, C["walls.spoof_left_pct"] / 100
    for w in walls:
        seen, first = 1, now
        for t, _, snap in reversed(hist):
            if any(sd == w["side"] and abs(p / w["price"] - 1) <= tol and u >= keep * w["usdt"] for p, u, sd in snap):
                seen += 1
                first = t
            else:
                break
        w["seen"], w["age_s"] = seen, now - first
    vanished = []
    if hist:
        t_prev, mid_prev, snap = hist[-1]
        for p, u, sd in snap:
            still = any(w["side"] == sd and abs(w["price"] / p - 1) <= tol and w["usdt"] >= left * u for w in walls)
            if still:
                continue
            d_prev, d_now = abs(p / mid_prev - 1), abs(p / mid - 1)
            if d_now < d_prev or d_now <= 0.005:                 # harga mendekat / sudah dekat lalu tembok hilang
                vanished.append({"side": sd, "price": p, "usdt": u, "dist_pct": (p / mid - 1) * 100, "ago_s": now - t_prev})
    hist.append((now, mid, [(w["price"], w["usdt"], w["side"]) for w in walls]))
    _WALL_HIST[sym] = hist
    return {"vanished": sorted(vanished, key=lambda v: -v["usdt"])[:10], "snapshots": len(hist)}


def spike_alarm(c, sym):
    """Alarm lonjakan dari candle 1 menit: volume 5 menit terakhir vs rata-rata 1 jam, dan gerak harga vs ATR 1m."""
    import numpy as np

    from .indicators import atr
    k = c.get("/fapi/v1/klines", symbol=sym, interval="1m", limit=61)
    if len(k) < 20:
        return None
    o, h, l, cl = (np.array([float(r[i]) for r in k]) for i in (1, 2, 3, 4))
    qv = np.array([float(r[7]) for r in k])
    tb = np.array([float(r[10]) for r in k])
    base = float(np.median(qv[:-5])) or 1.0
    ratio = float(qv[-5:].mean() / base)
    peak = float(qv[-5:].max() / base)
    move = (cl[-1] / o[-5] - 1) * 100
    a1 = float(atr(h, l, cl, 14)[-1]) / cl[-1] * 100
    buy_share = float(tb[-5:].sum() / qv[-5:].sum() * 100) if qv[-5:].sum() else 50.0
    C = whale_cfg.get()
    lvl = "BAHAYA" if (peak >= C["alarm.danger_peak"] and abs(move) >= C["alarm.danger_move_atr"] * a1) else \
        "WASPADA" if (ratio >= C["alarm.warn_vol"] or abs(move) >= C["alarm.warn_move_atr"] * a1) else "NORMAL"
    return {"level": lvl, "vol_ratio": ratio, "peak_ratio": peak, "move5_pct": float(move), "atr1m_pct": float(a1), "buy_share": buy_share,
            "dir": "NAIK" if move > 0 else "TURUN"}


def anti_gocek(c, sym, price, walls, heat, a1h=None):
    """Zona gocekan, zona tipis, tembok palsu, alarm lonjakan, dan SL anti-gocekan."""
    import numpy as np

    from .indicators import atr, pivots
    k = c.get("/fapi/v1/klines", symbol=sym, interval="15m", limit=1000)
    h, l, cl = (np.array([float(r[i]) for r in k]) for i in (2, 3, 4))
    C = whale_cfg.get()
    a15 = atr(h, l, cl, int(C["swing.atr"]))
    a = float(a15[-1]) if np.isfinite(a15[-1]) else price * 0.003
    a1h = a1h or 2 * a                                      # ATR H1 ~ 2 x ATR 15m (akar 4 candle)
    bt = wick_backtest(h, l, cl, a15, int(C["swing.fractal"]), int(C["gocek.lookahead"]), int(C["gocek.reclaim_bars"]), C["gocek.depth_pct"])
    pen = bt["pdepth"] if bt["pdepth"] is not None else 1.0
    # swing terdekat yang sudah terkonfirmasi
    hi, lo = pivots(h, l, int(C["swing.fractal"]))
    rec = len(cl) - int(C["swing.lookback"])
    lows = sorted({float(l[i]) for i in lo if i >= rec and l[i] < price}, reverse=True)[:3]
    highs = sorted({float(h[i]) for i in hi if i >= rec and h[i] > price})[:3]
    step = _round_step(price)
    rb, ra = np.floor(price / step) * step, np.ceil(price / step) * step
    zones = [{"side": "BAWAH", "kind": "swing low", "level": x, "from": x - pen * a, "to": x,
              "note": "SL long yang ditaruh tepat di bawah swing ini rawan disapu"} for x in lows]
    zones += [{"side": "ATAS", "kind": "swing high", "level": x, "from": x, "to": x + pen * a,
               "note": "SL short yang ditaruh tepat di atas swing ini rawan disapu"} for x in highs]
    for x, sd in ((float(rb), "BAWAH"), (float(ra), "ATAS")):
        if abs(x / price - 1) <= C["round.max_dist_pct"] / 100 and x != price:
            zones.append({"side": sd, "kind": "angka bulat", "level": x,
                          "from": x - 0.5 * pen * a if sd == "BAWAH" else x, "to": x if sd == "BAWAH" else x + 0.5 * pen * a,
                          "note": "banyak order & SL menumpuk di angka bulat"})
    for z in zones:
        z["dist_pct"] = (z["level"] / price - 1) * 100
    zones.sort(key=lambda z: abs(z["dist_pct"]))
    # zona tipis: rentang peta likuiditas yang hampir kosong
    tot = np.array([x["bid"] + x["ask"] for x in heat])
    med = float(np.median(tot[tot > 0])) if (tot > 0).any() else 0.0
    thin, cur = [], None
    for x, t in zip(heat, tot):
        is_thin = med > 0 and t < C["thin.pct"] / 100 * med and not (x["from_pct"] <= 0 < x["to_pct"])
        if is_thin:
            if cur and abs(cur["to_pct"] - x["from_pct"]) < 1e-9:
                cur.update(to_pct=x["to_pct"], hi=x["hi"])
            else:
                cur = {"from_pct": x["from_pct"], "to_pct": x["to_pct"], "lo": x["lo"], "hi": x["hi"]}
                thin.append(cur)
        else:
            cur = None
    spoof = track_walls(sym, price, walls)
    try:
        alarm = spike_alarm(c, sym)
    except (BinanceError, ValueError, KeyError, IndexError, ZeroDivisionError):
        alarm = None

    # SL anti-gocekan: di luar swing + kedalaman tembus 90% gocekan, di balik tembok ASLI (terlihat >= 2 scan
    # kalau ada), dan di luar angka bulat; jaga maksimal sl.max_pct dari harga (pengaturan)
    def sl_for(long):
        reasons, cands = [], []
        sw = lows[0] if long and lows else highs[0] if (not long and highs) else None
        if sw is not None:
            b = pen + C["sl.swing_buf_atr"]
            cands.append(sw - b * a if long else sw + b * a)
            reasons.append(f"di luar swing {'low' if long else 'high'} {sw:.6g} + {pen:.2f} ATR15m ({C['gocek.depth_pct']:.0f}% gocekan tidak sedalam ini)")
        side_walls = [w for w in walls if w["side"] == ("BUY" if long else "SELL") and
                      ((w["price"] < price) if long else (w["price"] > price)) and abs(w["price"] / price - 1) <= C["walls.max_dist_pct"] / 100]
        real = [w for w in side_walls if w.get("seen", 1) >= C["walls.real_seen"]] or side_walls
        if real:
            w = max(real, key=lambda w: w["usdt"])
            wb = C["sl.wall_buf_atr1h"] * a1h
            cands.append(w["price"] - wb if long else w["price"] + wb)
            reasons.append(f"di balik tembok {'BELI' if long else 'JUAL'} {w['price']:.6g} ({'asli, terlihat ' + str(w.get('seen', 1)) + 'x' if w.get('seen', 1) >= C['walls.real_seen'] else 'belum terbukti asli'})")
        if not cands:
            fb = C["sl.fallback_atr1h"]
            cands.append(price - fb * a1h if long else price + fb * a1h)
            reasons.append(f"{fb:g} ATR H1 (tidak ada swing / tembok dekat)")
        sl = min(cands) if long else max(cands)
        rn = rb if long else ra
        if (long and rn - 0.5 * pen * a <= sl <= rn) or (not long and rn <= sl <= rn + 0.5 * pen * a):
            rbuf = 0.5 * pen + C["sl.round_buf"]
            sl = rn - rbuf * a if long else rn + rbuf * a
            reasons.append(f"digeser melewati angka bulat {rn:.6g}")
        raw = float(sl)                                  # tanpa batas 4% (selalu di luar swing / tembok)
        mx = C["sl.max_pct"]
        lim = price * (1 - mx / 100 if long else 1 + mx / 100)
        capped = (long and sl < lim) or (not long and sl > lim)
        if capped:
            sl = lim
            reasons.append(f"dibatasi maksimal {mx:g}% dari harga")
        return {"sl": float(sl), "raw": raw, "pct": (sl / price - 1) * 100, "reasons": reasons, "capped": bool(capped)}
    return {"backtest": bt, "atr15": a, "pen_atr": pen, "zones": zones[:8], "thin": thin[:8], "spoof": spoof, "alarm": alarm,
            "sl_long": sl_for(True), "sl_short": sl_for(False)}


# ---------------------------------------------------------------------------- cek entry user
def first_touch_backtest(o, h, l, c, sl_pct, tp_pct, long, max_bars=192, trend_mask=None, detail=False):
    """Backtest dari candle: untuk SETIAP candle sebagai entry (di harga close) dengan jarak SL% & TP% yang sama,
    mana yang tersentuh duluan dalam max_bars candle. TP & SL di candle yang sama = dihitung kalah (konservatif).
    Yang TIDAK kena TP maupun SL dalam max_bars candle dihitung "tidak menang" (open), BUKAN dibuang — kalau dibuang,
    hanya trade yang kebetulan ikut tren kuat yang tersisa dan WR jadi terlalu bagus. Candle yang masa depannya kurang
    dari max_bars tidak dipakai (hasilnya belum diketahui).
    trend_mask: hanya candle yang kondisinya sama dengan sekarang. Hasil: n, menang, kalah, open, WR, median candle sampai TP."""
    import numpy as np
    n = len(c)
    wins = losses = opens = 0
    bars_win = []
    last = n - 1 - max_bars
    trades = []
    idx = range(max(0, last)) if trend_mask is None else [i for i in range(max(0, last)) if trend_mask[i]]
    for i in idx:
        e = c[i]
        tp = e * (1 + tp_pct / 100) if long else e * (1 - tp_pct / 100)
        sl = e * (1 - sl_pct / 100) if long else e * (1 + sl_pct / 100)
        hh, ll = h[i + 1:i + 1 + max_bars], l[i + 1:i + 1 + max_bars]
        hit_tp = np.flatnonzero(hh >= tp) if long else np.flatnonzero(ll <= tp)
        hit_sl = np.flatnonzero(ll <= sl) if long else np.flatnonzero(hh >= sl)
        t = hit_tp[0] if len(hit_tp) else None
        s = hit_sl[0] if len(hit_sl) else None
        if t is None and s is None:
            opens += 1                                  # tidak kena TP dalam batas waktu = tidak menang
            res, ex = 0, i + max_bars
        elif s is not None and (t is None or s <= t):
            losses += 1
            res, ex = -1, i + 1 + int(s)
        else:
            wins += 1
            bars_win.append(int(t) + 1)
            res, ex = 1, i + 1 + int(t)
        if detail:
            trades.append((i, res, ex, e, sl, tp))
    tot = wins + losses + opens
    out = {"n": tot, "wins": wins, "losses": losses, "open": opens, "wr": 100 * wins / tot if tot else None,
           "bars_med": float(np.median(bars_win)) if bars_win else None}
    if detail:
        out["detail"] = trades
    return out


def limit_backtest(o, h, l, c, dist_pct, down, sl_pct, tp_pct, long, max_bars=192, fill_bars=96, trend_mask=None, detail=False):
    """v4.33 (D): backtest entry LIMIT. Dari setiap candle sinyal i (kondisi tren seperti sekarang), harga limit = close i
    ∓ dist_pct. Trade baru dimulai kalau harga MENYENTUH limit dalam fill_bars candle (tidak tersentuh = tidak ada trade;
    peluang tersentuh dihitung terpisah). SL / TP diukur dari harga limit. Candle terisi ikut dicek SL (bisa saja SL kena
    di candle yang sama), TP mulai candle berikutnya; TP & SL di candle sama = kalah. Belum kena keduanya dalam max_bars
    = tidak menang. Hasil sama dengan first_touch_backtest (+ n_signal & filled)."""
    import numpy as np
    n = len(c)
    wins = losses = opens = 0
    bars_win, trades = [], []
    last = n - 1 - max_bars - fill_bars
    idx = range(max(0, last)) if trend_mask is None else [i for i in range(max(0, last)) if trend_mask[i]]
    n_sig = 0
    for i in idx:
        n_sig += 1
        e = c[i] * (1 - dist_pct / 100) if down else c[i] * (1 + dist_pct / 100)
        hh, ll = h[i + 1:i + 1 + fill_bars], l[i + 1:i + 1 + fill_bars]
        hit = np.flatnonzero(ll <= e) if down else np.flatnonzero(hh >= e)
        if not len(hit):
            continue
        j = i + 1 + int(hit[0])                                     # candle terisi
        tp = e * (1 + tp_pct / 100) if long else e * (1 - tp_pct / 100)
        sl = e * (1 - sl_pct / 100) if long else e * (1 + sl_pct / 100)
        hs_, ls_ = h[j:j + max_bars], l[j:j + max_bars]
        hit_sl = np.flatnonzero(ls_ <= sl) if long else np.flatnonzero(hs_ >= sl)
        hit_tp = np.flatnonzero(hs_[1:] >= tp) + 1 if long else np.flatnonzero(ls_[1:] <= tp) + 1
        t = int(hit_tp[0]) if len(hit_tp) else None
        s_ = int(hit_sl[0]) if len(hit_sl) else None
        if t is None and s_ is None:
            opens += 1
            res, ex = 0, j + max_bars - 1
        elif s_ is not None and (t is None or s_ <= t):
            losses += 1
            res, ex = -1, j + s_
        else:
            wins += 1
            bars_win.append(j - i + t)
            res, ex = 1, j + t
        if detail:
            trades.append((i, res, ex, e, sl, tp))
    tot = wins + losses + opens
    out = {"n": tot, "wins": wins, "losses": losses, "open": opens, "wr": 100 * wins / tot if tot else None,
           "bars_med": float(np.median(bars_win)) if bars_win else None, "n_signal": n_sig, "filled": tot}
    if detail:
        out["detail"] = trades
    return out


def fill_backtest(h, l, c, dist_pct, down, miss_pct=None, max_bars=None):
    """Backtest dari candle: dari setiap candle, apakah harga menyentuh level sejauh dist_pct (ke bawah kalau down)
    dalam max_bars candle (limit terisi), dan apakah harga lebih dulu 'kabur' sejauh miss_pct ke arah sebaliknya."""
    import numpy as np
    max_bars = int(max_bars or whale_cfg.get()["fill.window"])
    n = len(c)
    fill = miss = tot = 0
    bars = []
    for i in range(n - 1):
        e = c[i] * (1 - dist_pct / 100) if down else c[i] * (1 + dist_pct / 100)
        hh, ll = h[i + 1:i + 1 + max_bars], l[i + 1:i + 1 + max_bars]
        if len(hh) < max_bars:
            break
        tot += 1
        hit = np.flatnonzero(ll <= e) if down else np.flatnonzero(hh >= e)
        f = int(hit[0]) if len(hit) else None
        if miss_pct:
            away = c[i] * (1 + miss_pct / 100) if down else c[i] * (1 - miss_pct / 100)
            mh = np.flatnonzero(hh >= away) if down else np.flatnonzero(ll <= away)
            m = int(mh[0]) if len(mh) else None
            if m is not None and (f is None or m < f):
                miss += 1
                continue
        if f is not None:
            fill += 1
            bars.append(f + 1)
    return {"n": tot, "fill_pct": 100 * fill / tot if tot else None, "miss_pct": 100 * miss / tot if tot and miss_pct else None,
            "bars_med": float(np.median(bars)) if bars else None}


def check_entry(c, sym, entry, sl, tp, status="pending", min_usdt=50_000, min_rr=2.0, side=None):
    """Analisa entry user. status: 'running' (posisi sudah terbuka: peluang dihitung dari harga sekarang) atau
    'pending' (limit belum tersentuh: + peluang terisi / kabur, + saran entry/SL/TP yang lebih baik).
    Peluang TP duluan dari backtest candle koin ini + cek posisi SL/TP terhadap whale & gocekan."""
    import numpy as np

    from .indicators import ema
    sym = sym.upper().strip()
    if not sym.endswith("USDT"):
        sym += "USDT"
    if status not in ("running", "pending"):
        raise ValueError("pilih status posisi: sudah berjalan / belum kena entry")
    entry, sl, tp = float(entry), float(sl), float(tp)
    side = (side or "").upper()
    if side in ("BUY", "LONG"):
        if not sl < entry:
            raise ValueError(f"BUY: SL ({sl:g}) harus DI BAWAH entry ({entry:g})")
        if not tp > entry:
            raise ValueError(f"BUY: TP ({tp:g}) harus DI ATAS entry ({entry:g})")
        long = True
    elif side in ("SELL", "SHORT"):
        if not sl > entry:
            raise ValueError(f"SELL: SL ({sl:g}) harus DI ATAS entry ({entry:g})")
        if not tp < entry:
            raise ValueError(f"SELL: TP ({tp:g}) harus DI BAWAH entry ({entry:g})")
        long = False
    elif tp > entry > sl:
        long = True
    elif tp < entry < sl:
        long = False
    else:
        raise ValueError("posisi tidak valid: BUY = SL < entry < TP, SELL = TP < entry < SL")
    coin = analyse_coin(c, sym, top=10, min_usdt=min_usdt)
    price = coin["price"]
    anti, plan, walls = coin.get("anti"), coin.get("plan"), coin["walls"]
    k = c.get("/fapi/v1/klines", symbol=sym, interval="15m", limit=1000)
    o, h, l, cl = (np.array([float(r[i]) for r in k]) for i in (1, 2, 3, 4))
    e20, e50 = ema(cl, 20), ema(cl, 50)
    up_now = e20[-1] > e50[-1]
    mask = (e20 > e50) == up_now
    sgn = 1 if long else -1
    # status posisi
    state, done = {"status": status}, None
    ref = entry
    if status == "running":
        if (long and price <= sl) or (not long and price >= sl):
            done = "SL"
        elif (long and price >= tp) or (not long and price <= tp):
            done = "TP"
        state.update(pnl_pct=sgn * (price / entry - 1) * 100, progress_pct=100 * (price - entry) / (tp - entry), done=done)
        ref = price
    else:
        dist = abs(entry / price - 1) * 100
        down = entry < price
        order = ("limit" if (down == long) else "stop") if dist > 0.02 else "market"
        miss = abs(tp / price - 1) * 100 if order == "limit" else None
        fb = fill_backtest(h, l, cl, dist, down, miss) if dist > whale_cfg.get()["fill.market_tol_pct"] else {"fill_pct": 100.0, "miss_pct": None, "bars_med": 0, "n": 0}
        state.update(dist_pct=(entry / price - 1) * 100, order=order, fill=fb)
    sl_pct, tp_pct = abs(ref - sl) / ref * 100, abs(tp - ref) / ref * 100
    if done:
        sl_pct = tp_pct = max(sl_pct, 1e-6)
    bo, bh, bl, bc, bmask, bmb, btf = bt_data(c, sym, sl_pct)
    base = first_touch_backtest(bo, bh, bl, bc, sl_pct, tp_pct, long, max_bars=bmb)
    trend = first_touch_backtest(bo, bh, bl, bc, sl_pct, tp_pct, long, max_bars=bmb, trend_mask=bmask)
    evidence = ev_model = None
    try:                                                   # kelas A/B/C + Elliott (info, tidak mengubah peluang di atas)
        from . import evidence as EV
        V = ev_votes(c, coin["symbol"], btf, bo, bh, bl, bc)
        if V is not None:
            det = first_touch_backtest(bo, bh, bl, bc, sl_pct, tp_pct, long, max_bars=bmb, detail=True)["detail"]
            m = EV.learn_np(EV.pack(V, [d_[0] for d_ in det], sgn, [d_[1] == 1 for d_ in det], int((len(bc) - 1 - bmb) * 0.7)))
            evidence = EV.describe(m, V, len(bc) - 1, sgn, btf)
            ev_model = {k: m.get(k) for k in ("w", "stats", "grades", "proven", "note", "n_fit", "n_test")}
    except Exception:                                      # noqa: BLE001 - bukti gagal: cek entry tetap jalan
        evidence = None
    checks = []

    def add(st, pts, txt):
        checks.append({"status": st, "points": pts, "text": txt})
    rr0 = abs(tp - entry) / abs(entry - sl)
    rr = tp_pct / sl_pct if sl_pct else None
    breakeven = 100 / (1 + rr) if rr else None
    add("ok" if rr0 >= 1.5 else "warn" if rr0 >= 1 else "bad", 0, f"RR rencana 1:{rr0:.2f}" +
        (f"; dari harga sekarang sisa jarak TP {tp_pct:.2f}% vs SL {sl_pct:.2f}% (RR 1:{rr:.2f})." if status == "running" and not done else "."))
    if plan:
        side_ok = {"BULLISH": long, "BEARISH": not long}.get(plan["regime"])
        if side_ok is True:
            add("ok", 8, f"Searah kekuatan pasar ({plan['regime']}, Bullish {plan['bull']:.0f}% / Bearish {plan['bear']:.0f}%).")
        elif side_ok is False:
            add("bad", -10, f"MELAWAN kekuatan pasar ({plan['regime']}, Bullish {plan['bull']:.0f}% / Bearish {plan['bear']:.0f}%).")
        else:
            add("warn", -3, f"Pasar SIDEWAYS ({plan['side']:.0f}%): TP jauh lebih sulit tercapai.")
    if anti:
        zs = [z for z in anti["zones"] if min(z["from"], z["to"]) <= sl <= max(z["from"], z["to"])]
        if zs:
            add("bad", -15, f"SL {sl:.6g} ada DI DALAM zona gocekan ({zs[0]['kind']} {zs[0]['level']:.6g}, rentang "
                            f"{min(zs[0]['from'], zs[0]['to']):.6g}–{max(zs[0]['from'], zs[0]['to']):.6g}) → rawan disapu lalu harga balik.")
        safe = anti["sl_long" if long else "sl_short"]["sl"]
        if (long and sl > safe) or (not long and sl < safe):
            add("warn", -6, f"SL lebih dekat dari SL anti-gocekan ({safe:.6g}). 90% gocekan koin ini menembus sampai {anti['pen_atr']:.2f} ATR15m.")
        else:
            add("ok", 6, f"SL di luar jarak gocekan (SL anti-gocekan {safe:.6g}).")
        if any(min(t["lo"], t["hi"]) <= sl <= max(t["lo"], t["hi"]) for t in anti["thin"]):
            add("warn", -4, "SL di zona tipis: kalau tersentuh, harga bisa loncat (slippage).")
        if any(min(t["lo"], t["hi"]) <= tp <= max(t["lo"], t["hi"]) for t in anti["thin"]):
            add("ok", 3, "TP di zona tipis: kalau harga sampai sana, geraknya cenderung cepat.")
        al = anti.get("alarm")
        if al and al["level"] != "NORMAL":
            add("bad" if al["level"] == "BAHAYA" else "warn", -8 if al["level"] == "BAHAYA" else -4,
                f"Alarm {al['level']}: lonjakan {al['dir']} {al['move5_pct']:+.2f}% dalam 5 menit, volume {al['vol_ratio']:.1f}x normal.")
    my, opp = ("BUY", "SELL") if long else ("SELL", "BUY")
    lo_, hi_ = min(sl, ref), max(sl, ref)
    guard = [w for w in walls if w["side"] == my and lo_ < w["price"] < hi_]
    if guard:
        g = max(guard, key=lambda w: w["usdt"])
        add("ok", 6 if g.get("seen", 1) >= 2 else 3, f"Ada tembok {'BELI' if long else 'JUAL'} {g['price']:.6g} ({g['usdt']:,.0f} USDT"
            f"{', asli ' + str(g['seen']) + 'x' if g.get('seen', 1) >= 2 else ', belum terbukti asli'}) di antara entry & SL → melindungi SL.")
    lo_, hi_ = min(ref, tp), max(ref, tp)
    block = [w for w in walls if w["side"] == opp and lo_ < w["price"] < hi_]
    if block:
        b = max(block, key=lambda w: w["usdt"])
        add("warn", -8, f"TP terhalang tembok {'JUAL' if long else 'BELI'} {b['price']:.6g} ({b['usdt']:,.0f} USDT) sebelum TP → "
                        f"pertimbangkan TP sedikit {'di bawah' if long else 'di atas'} {b['price']:.6g}.")
    else:
        add("ok", 4, f"Tidak ada tembok {'JUAL' if long else 'BELI'} whale besar di jalur menuju TP.")
    if status == "pending":
        f = state["fill"]
        if state["order"] == "stop":
            add("warn", 0, f"Entry {entry:.6g} ada di {'atas' if long else 'bawah'} harga ({state['dist_pct']:+.2f}%): ini order STOP (breakout), bukan limit.")
        if f.get("fill_pct") is not None and state["order"] != "market":
            add("ok" if f["fill_pct"] >= 50 else "warn", 0, f"Peluang entry tersentuh dalam 24 jam: {f['fill_pct']:.0f}%"
                + (f"; {f['miss_pct']:.0f}% harga keburu kabur ke arah TP tanpa mengisi entry." if f.get("miss_pct") is not None else "."))
    src = trend if trend["n"] >= whale_cfg.get()["bt.min_trades"] else base
    C = whale_cfg.get()
    adj = float(np.clip(C["check.adj_factor"] * sum(x["points"] for x in checks), -C["check.adj_cap"], C["check.adj_cap"]))
    prob = None if src["wr"] is None else float(np.clip(src["wr"] + adj, 3, 97))
    if done:
        prob = 100.0 if done == "TP" else 0.0
    verdict = None if prob is None else "PROFIT" if prob >= 55 else "LOSE" if prob <= 45 else "50:50"
    edge = prob - breakeven if prob is not None and breakeven is not None and not done else None
    hours = src["bars_med"] * (1.0 if btf == "1h" else 0.25) if src.get("bars_med") else None
    # saran entry / SL / TP (hanya kalau belum kena entry). Saran HARUS lebih baik dari punyamu di dua hal sekaligus:
    # peluang TP duluan TIDAK lebih rendah & rata-rata hasil per trade (R) LEBIH tinggi — keduanya dari backtest mentah
    # yang sama. RR saran selalu >= min_rr. Kandidat: entry (depan tembok whale, entry kamu, di atas/bawah swing) x
    # SL (anti-gocekan tanpa batas 4% = selalu di luar swing, SL kamu) x TP (TP kamu, entry + min_rr x risiko).
    sug = None
    if status == "pending" and anti:
        a15 = anti["atr15"]
        A = anti["sl_long" if long else "sl_short"]
        u_wr = src["wr"] if src["wr"] is not None else 0.0
        u_exp = u_wr / 100 * rr0 - (1 - u_wr / 100)
        ents = [(entry, "entry kamu")]
        side_w = [w for w in walls if w["side"] == my and ((w["price"] < price) if long else (w["price"] > price))
                  and abs(w["price"] / price - 1) <= 0.03]
        real = [w for w in side_w if w.get("seen", 1) >= 2] or side_w
        if real:
            w = max(real, key=lambda w: w["usdt"])
            ents.append((w["price"] + 0.1 * a15 if long else w["price"] - 0.1 * a15,
                         f"entry di depan tembok {'BELI' if long else 'JUAL'} {w['price']:.6g} ({w['usdt']:,.0f} USDT)"))
        zs = [z for z in anti["zones"] if z["side"] == ("BAWAH" if long else "ATAS") and z["kind"] == ("swing low" if long else "swing high")]
        if zs:
            z = zs[0]
            ents.append((z["level"] + 0.15 * a15 if long else z["level"] - 0.15 * a15,
                         f"entry {'di atas swing low' if long else 'di bawah swing high'} {z['level']:.6g}"))
        sls = [(A.get("raw", A["sl"]), "SL anti-gocekan: " + "; ".join(r_ for r_ in A["reasons"] if not r_.startswith("dibatasi maksimal"))), (sl, "SL kamu")]
        cache = {}

        def bt(s_sl, s_tp):
            tf = "1h" if s_sl >= 1.5 else "15m"
            if tf not in cache:
                cache[tf] = bt_data(c, sym, s_sl)
            so, sh_, sl_, sc_, smask, smb, _ = cache[tf]
            r_ = first_touch_backtest(so, sh_, sl_, sc_, s_sl, s_tp, long, max_bars=smb, trend_mask=smask)
            return r_ if r_["n"] >= whale_cfg.get()["bt.min_trades"] else first_touch_backtest(so, sh_, sl_, sc_, s_sl, s_tp, long, max_bars=smb)
        fills = {}
        best, tried = None, 0
        for se, ewhy in ents:
            for ss, swhy in sls:
                if (long and not ss < se) or (not long and not ss > se):
                    continue
                if (long and se > price * 1.003 and abs(se - entry) > 1e-12) or (not long and se < price * 0.997 and abs(se - entry) > 1e-12):
                    continue                               # entry saran tidak boleh jadi order STOP (kecuali entry kamu)
                risk = abs(se - ss)
                if risk <= 0:
                    continue
                need = se + sgn * min_rr * risk
                for st_, twhy in ((tp, "TP kamu"), (need, f"TP = RR 1:{min_rr:g}")):
                    if (long and st_ < need - 1e-12) or (not long and st_ > need + 1e-12):
                        continue                           # RR saran selalu >= min_rr
                    tried += 1
                    s_sl, s_tp = risk / se * 100, abs(st_ - se) / se * 100
                    sb = bt(s_sl, s_tp)
                    if sb["wr"] is None:
                        continue
                    sd = abs(se / price - 1) * 100
                    key = round(se, 12)
                    if key not in fills:
                        fills[key] = fill_backtest(h, l, cl, sd, se < price)["fill_pct"] if sd > C["fill.market_tol_pct"] else 100.0
                    rr_ = s_tp / s_sl
                    wr = sb["wr"] / 100
                    exp_r = wr * rr_ - (1 - wr)
                    if sb["wr"] < u_wr - 1e-9 or exp_r <= u_exp + C["check.min_better_r"]:
                        continue                           # tidak lebih baik dari punyamu: buang
                    score = exp_r * (fills[key] or 0) / 100
                    pass_w = [x for x in walls if x["side"] == opp and min(se, st_) < x["price"] < max(se, st_)]
                    warn = None
                    if pass_w:
                        x = max(pass_w, key=lambda x: x["usdt"])
                        warn = f"TP melewati tembok {'JUAL' if long else 'BELI'} {x['price']:.6g} ({x['usdt']:,.0f} USDT): harga bisa tertahan di sana"
                    item = {"entry": se, "sl": ss, "tp": st_, "rr": rr_, "wr": sb["wr"], "n": sb["n"], "fill_pct": fills[key],
                            "exp_r": exp_r, "score": score, "why": [ewhy, swhy, twhy] + ([warn] if warn else [])}
                    if best is None or score > best["score"]:
                        best = item
        if best:
            best["same"] = abs(best["entry"] - entry) < 1e-12 and abs(best["sl"] - sl) < 1e-12 and abs(best["tp"] - tp) < 1e-12
            best["min_rr"], best["user_wr"], best["user_exp"] = min_rr, u_wr, u_exp
            sug = best
        else:
            sug = {"none": True, "min_rr": min_rr, "tried": tried, "user_wr": u_wr, "user_exp": u_exp}
    return {"symbol": coin["symbol"], "side": "LONG" if long else "SHORT", "entry": entry, "sl": sl, "tp": tp, "price": price,
            "sl_pct": sl_pct, "tp_pct": tp_pct, "rr": rr, "rr_plan": rr0, "breakeven": breakeven, "backtest_all": base,
            "backtest_trend": trend, "trend_now": "naik (EMA20 > EMA50 di 15M)" if up_now else "turun (EMA20 < EMA50 di 15M)",
            "checks": checks, "adj": adj, "prob": prob, "verdict": verdict, "edge": edge, "hours_to_tp": hours,
            "bt_tf": btf, "bt_days": len(bc) * (1 / 24 if btf == "1h" else 1 / 96), "bt_limit_h": bmb * (1 if btf == "1h" else 0.25),
            "state": state, "suggest": sug, "coin": coin, "evidence": evidence, "ev_model": ev_model}


# ---------------------------------------------------------------------------- cari setup terbaik (banyak koin)
def coin_setups(c, sym, rr=2.0, min_usdt=50_000, sides=("BUY", "SELL")):
    """Setup terbaik 1 koin untuk tiap RR (rr bisa angka atau list): kandidat entry (harga sekarang, depan tembok whale,
    di atas/bawah swing), SL anti-gocekan, TP = entry + rr x risiko. Tiap kandidat di-backtest (kondisi tren sama seperti
    sekarang) -> WR, rata-rata hasil per trade (R) & peluang entry tersentuh 24 jam. Hasil: 1 setup terbaik per (arah, RR)."""
    import numpy as np
    rrs = [float(x) for x in (rr if isinstance(rr, (list, tuple)) else [rr])]
    C = whale_cfg.get()
    t_scan = int(time.time() * 1000)                     # (F) waktu harga koin dibaca = waktu sinyal di jurnal
    coin = analyse_coin(c, sym, top=int(C["walls.top"]), min_usdt=min_usdt, light=True)
    anti, plan, walls, price = coin.get("anti"), coin.get("plan"), coin["walls"], coin["price"]
    if not anti:
        return []
    k = c.get("/fapi/v1/klines", symbol=coin["symbol"], interval="15m", limit=1000)
    h, l, cl = (np.array([float(r[i]) for r in k]) for i in (2, 3, 4))
    a15 = anti["atr15"]
    # untuk kartu visual entry: 96 candle 15M terakhir + tembok order terbesar
    vis = [[int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4])] for r in k[-96:]]
    wv = sorted(walls, key=lambda w: -w["usdt"])[:6]
    walls_vis = [{"price": float(w["price"]), "side": w["side"], "usdt": float(w["usdt"])} for w in wv]
    alarm = (anti.get("alarm") or {}).get("level", "NORMAL")
    cache = {}

    def data(sl_pct):                                    # data backtest per TF di-cache (hemat permintaan ke Binance)
        tf = "1h" if sl_pct >= C["bt.sl_tf_switch_pct"] else "15m"
        if tf not in cache:
            cache[tf] = bt_data(c, coin["symbol"], sl_pct)
        return cache[tf]
    fills = {}
    out = []
    evc = {}

    def votes(stf):                                      # suara bukti per TF backtest (sekali per koin)
        if stf not in evc:
            so, sh_, sl_, sc_ = cache[stf][:4]
            try:
                evc[stf] = ev_votes(c, coin["symbol"], stf, so, sh_, sl_, sc_)
            except Exception:                              # noqa: BLE001 - bukti gagal: setup tetap jalan tanpa kelas
                evc[stf] = None
        return evc[stf]
    for side in sides:
        long = side == "BUY"
        sgn, my, opp = (1, "BUY", "SELL") if long else (-1, "SELL", "BUY")
        A = anti["sl_long" if long else "sl_short"]
        if A.get("capped") and C["sl.cap_mode"] == "tolak":
            continue                                     # SL anti-gocekan lebih jauh dari batas: jangan dipotong, lewati
        ss = A["sl"]
        cands = [(price, "market (harga sekarang)")] if C["entry.use_market"] == "ya" else []
        sw = [w for w in walls if w["side"] == my and ((w["price"] < price) if long else (w["price"] > price))
              and abs(w["price"] / price - 1) <= C["walls.max_dist_pct"] / 100]
        real = [w for w in sw if w.get("seen", 1) >= C["walls.real_seen"]] or sw
        if real and C["entry.use_wall"] == "ya":
            w = max(real, key=lambda w: w["usdt"])
            eb = C["entry.wall_buf_atr"] * a15
            cands.append((w["price"] + eb if long else w["price"] - eb, f"limit di depan tembok {'BELI' if long else 'JUAL'} {w['price']:.6g}"))
        zs = [z for z in anti["zones"] if z["side"] == ("BAWAH" if long else "ATAS") and z["kind"] == ("swing low" if long else "swing high")]
        if zs and C["entry.use_swing"] == "ya":
            z = zs[0]
            zb = C["entry.swing_buf_atr"] * a15
            cands.append((z["level"] + zb if long else z["level"] - zb, f"limit di {'atas swing low' if long else 'bawah swing high'} {z['level']:.6g}"))
        for rr_ in rrs:
            best = None
            for se, why in cands:
                if (long and not ss < se <= price * 1.0001) or (not long and not price * 0.9999 <= se < ss):
                    continue
                risk = abs(se - ss)
                if risk <= 0:
                    continue
                tp = se + sgn * rr_ * risk
                s_sl, s_tp = risk / se * 100, rr_ * risk / se * 100
                so, sh_, sl_, sc_, smask, smb, stf = data(s_sl)
                from .indicators import ema as _ema_
                t_up = bool(_ema_(sc_, 20)[-1] > _ema_(sc_, 50)[-1])            # tren yang dipakai filter backtest (info jurnal)
                sd = abs(se / price - 1) * 100
                is_limit = sd > C["fill.market_tol_pct"] and C["bt.limit_fill"] == "ya"
                fbars = max(1, int(round(C["fill.window"] / (4 if stf == "1h" else 1))))   # batas tersentuh dalam candle TF backtest

                def run_bt(mask):
                    if is_limit:
                        return limit_backtest(so, sh_, sl_, sc_, sd, se < price, s_sl, s_tp, long, max_bars=smb, fill_bars=fbars,
                                              trend_mask=mask, detail=True)
                    return first_touch_backtest(so, sh_, sl_, sc_, s_sl, s_tp, long, max_bars=smb, trend_mask=mask, detail=True)
                sb = run_bt(smask)
                trend_mixed = False
                if sb["n"] < C["bt.min_trades"]:
                    sb = run_bt(None)                            # (E) filter tren dimatikan karena sampel kurang -> ditandai
                    trend_mixed = True
                if sb["wr"] is None:
                    continue
                det = sb.pop("detail")
                T_ = _BT_T.get((coin["symbol"], stf))
                split = _split_test(det, len(sc_) - 1 - smb, rr_, int(C["setup.min_test"]))
                seq = _one_at_a_time(det, rr_)
                split.update(risk_seq(seq))
                split["n_moves"] = len(seq)                      # (B) pergerakan berbeda (trade tidak tumpang tindih)
                if sd <= C["fill.market_tol_pct"]:
                    fill = 100.0
                else:
                    key = (round(se, 12), long)
                    if key not in fills:
                        fills[key] = fill_backtest(h, l, cl, sd, se < price)
                    fill = fills[key]["fill_pct"]
                wr = sb["wr"] / 100
                exp_r = wr * rr_ - (1 - wr)
                score = exp_r * (fill or 0) / 100
                blk = [x for x in walls if x["side"] == opp and min(se, tp) < x["price"] < max(se, tp)]
                item = {"symbol": coin["symbol"], "side": side, "entry": se, "sl": ss, "tp": tp, "rr": rr_, "wr": sb["wr"], "n": sb["n"],
                        "fill_pct": fill, "exp_r": exp_r, "score": score, "how": why, "sl_pct": s_sl, "tp_pct": s_tp, "trend_tf": stf, "trend_up": t_up,
                        "price": price, "regime": plan["regime"] if plan else None,
                        "aligned": bool(plan and {"BULLISH": long, "BEARISH": not long}.get(plan["regime"], False)),
                        "blocked": (f"{max(blk, key=lambda x: x['usdt'])['price']:.6g}" if blk else None), "alarm": alarm,
                        "hours": sb["bars_med"] * (1.0 if stf == "1h" else 0.25) if sb.get("bars_med") else None,
                        "bt_tf": stf, "open": sb.get("open", 0), "too_good": sb["wr"] > C["bt.suspicious_wr"], **split,
                        "_det": [(int(T_[d_[0]]), int(d_[1])) for d_ in det] if T_ is not None else [],
                        "candles": vis, "walls_vis": walls_vis}
                item["fill_ok"] = bool(fill is not None and fill >= SETUP_MIN_FILL)
                item.update(trend_mixed=trend_mixed, bt_kind="limit" if is_limit else "market", t_scan=t_scan)
                # v4.33 syarat layak (A, B, C): rata-rata untung + untung di data cari & data uji + cukup pergerakan berbeda
                # + WR tidak mencurigakan. Peluang tersentuh tetap info (dipakai di urutan / skor).
                why = []
                if exp_r <= 0:
                    why.append("rata-rata rugi")
                if C["setup.require_test"] == "ya":
                    if split["exp_fit"] is None or split["exp_fit"] <= 0:
                        why.append("rugi di data cari (70% awal)")
                    if split["n_test"] < int(C["setup.min_test"]):
                        why.append(f"data uji kurang ({split['n_test']} < {int(C['setup.min_test'])} trade)")
                    elif split["exp_test"] is None or split["exp_test"] <= 0:
                        why.append("rugi di data uji (30% terakhir)")
                if split["n_moves"] < int(C["setup.min_moves"]):
                    why.append(f"pergerakan berbeda kurang ({split['n_moves']} < {int(C['setup.min_moves'])})")
                if C["setup.reject_too_good"] == "ya" and item["too_good"]:
                    why.append(f"WR {sb['wr']:.0f}% terlalu bagus (curiga kebetulan)")
                item["usable"] = not why
                item["why_not"] = "; ".join(why) or None
                V = votes(stf)
                if V is not None and det:
                    from . import evidence as EV
                    item["_evs"] = EV.pack(V, [d_[0] for d_ in det], sgn, [d_[1] == 1 for d_ in det], int((len(sc_) - 1 - smb) * 0.7))
                    item["_evsnap"] = EV.snapshot(V, -1)
                item["_pp"] = (det, stf, sc_, sd, fills.get((round(se, 12), long)))
                if best is None or (item["usable"], score) > (best["usable"], best["score"]):
                    best = item
            if best:
                try:
                    best["proj"] = _whale_proj(best, k, walls, price, a15)
                except Exception:                            # noqa: BLE001 - animasi gagal: setup tetap tampil
                    best["proj"] = None
            for x in [best] if best else []:
                x.pop("_pp", None)
            if best:
                out.append(best)
    return out


def _whale_proj(it, k15, walls, price, a15):
    """Animasi kartu: jalur PRICE ACTION (mantul di SNR minor & tembok whale) sampai hasil yang paling sering di backtest
    (kena TP kalau WR >= 50%, selain itu kena SL), lama dari median backtest + pita 25-75% gerak harga semua trade."""
    import numpy as np

    from . import papath as PA
    det, stf, sc_, sd, fb = it["_pp"]
    if not det or not (a15 and a15 > 0):
        return None
    mul = 4 if stf == "1h" else 1                                   # candle backtest -> candle 15M kartu
    long = it["side"] == "BUY"
    outcome = "tp" if it["wr"] >= 50 else "sl"
    wins = [ex - i for i, res, ex, *_ in det if res == 1]
    loss = [ex - i for i, res, ex, *_ in det if res == -1]
    med = np.median(wins if outcome == "tp" else loss) if (wins if outcome == "tp" else loss) else None
    if not med:
        return None
    bars = int(min(240, max(2, round(med * mul))))
    h = np.array([float(r[2]) for r in k15])
    l = np.array([float(r[3]) for r in k15])
    c = np.array([float(r[4]) for r in k15])
    lv = PA.minor_levels(h, l) + [float(w["price"]) for w in walls]
    retr = PA.median_retrace(h, l, c)
    fill_bars = (fb or {}).get("bars_med") if sd > whale_cfg.get()["fill.market_tol_pct"] else None
    pa = PA.build(price, it["entry"], it["sl"], it["tp"], long, outcome, bars, a15, levels=lv, retr=retr,
                  fill_bars=fill_bars, seed=sum(map(ord, it["symbol"])))
    if pa is None:
        return None
    # pita 25-75% & median: gerak harga semua trade backtest setup ini (dalam ATR 15M harga sekarang)
    N = len(pa["close"])
    idx = np.array([d_[0] for d_ in det])
    steps = (np.arange(1, N + 1) + mul - 1) // mul                   # candle 15M ke-j -> candle backtest ke-(j/mul)
    ok = idx + steps[-1] < len(sc_)
    if ok.sum() >= 10:
        M = (sc_[idx[ok, None] + steps[None, :]] / sc_[idx[ok, None]] - 1) * price / a15
        off = (it["entry"] - price) / a15
        p25, p50, p75 = (np.percentile(M, q, 0) + off for q in (25, 50, 75))
    else:
        p25 = p50 = p75 = np.array(pa["close"])
    rn = lambda a: [round(float(x), 3) for x in a]                   # noqa: E731
    lbl = (f"{'✅ kena TP' if outcome == 'tp' else '❌ kena SL'} paling sering di backtest "
           f"({it['wr']:.0f}% TP duluan)")
    return {"atr": float(a15), "path": {"pa": pa, "close": rn(p50), "p25": rn(p25), "p75": rn(p75), "n": int(ok.sum()), "n_all": len(det),
            "dir": 1 if (pa["close"][-1] >= 0) else -1, "label": lbl, "target_r": pa["close"][-1]}}


SETUP_MIN_FILL = 70.0       # entry limit wajib tersentuh >= 70% (24 jam) supaya dijadikan sinyal
SETUP_MIN_TEST = 10         # trade minimal di 30% data terakhir supaya bisa dinilai "terbukti"


def _split_test(detail, n_valid, rr, min_test=SETUP_MIN_TEST):
    """Pisah hasil backtest per waktu: 70% candle awal = data cari, 30% terakhir = data uji.
    Rata-rata R = WR x RR - (kalah + belum kena) (sama dengan exp_r utama). Terbukti = untung di data uji."""
    cut = int(max(0, n_valid) * 0.7)

    def stat(rows):
        if not rows:
            return None, None, 0
        w = sum(1 for r in rows if r[1] == 1)
        wr = w / len(rows)
        return 100 * wr, wr * rr - (1 - wr), len(rows)
    wr_f, ex_f, n_f = stat([d for d in detail if d[0] < cut])
    wr_t, ex_t, n_t = stat([d for d in detail if d[0] >= cut])
    return {"wr_fit": wr_f, "exp_fit": ex_f, "n_fit": n_f, "wr_test": wr_t, "exp_test": ex_t, "n_test": n_t,
            "proven": bool(ex_t is not None and ex_t > 0 and n_t >= min_test)}


def scan_setups(c, n_coins=20, rr=2.0, sides=("BUY", "SELL"), top=10, min_usdt=50_000, progress=None, symbols=None, min_wr=0.0,
                flow=True, only_aligned=False):
    """Cari setup terbaik di N koin volume terbesar (atau `symbols`). rr = angka atau list (dibandingkan sekaligus).
    min_wr: hanya tampilkan setup dengan WR backtest >= ini. Hasil: setups (urut rata-rata x peluang tersentuh),
    compare = per koin & arah: WR / rata-rata R tiap RR + RR terbaik."""
    t0 = time.time()
    rrs = sorted({float(x) for x in (rr if isinstance(rr, (list, tuple)) else [rr])})
    tick = c.get("/fapi/v1/ticker/24hr")
    info = c.get("/fapi/v1/exchangeInfo")
    perp = {s["symbol"] for s in info["symbols"] if s.get("contractType") == "PERPETUAL" and s.get("quoteAsset") == "USDT"
            and s.get("status") == "TRADING"}
    vol = {t["symbol"]: float(t["quoteVolume"]) for t in tick if t["symbol"] in perp}
    rows, errors = [], []
    if symbols:
        want = list(dict.fromkeys(s.upper() for s in symbols))
        errors += [f"{s}: tidak ada di Binance Futures (USDT perpetual)" for s in want if s not in vol]
        queue = [s for s in want if s in vol]
        target = len(queue)
    else:
        # semua koin urut volume; target = N koin yang BERHASIL di-scan. Koin yang gagal (mis. koin baru, data
        # belum cukup) diganti koin berikutnya, jadi minta 500 = 500 koin (kecuali koin futures memang kurang)
        queue = sorted(vol, key=lambda s: -vol[s])
        target = min(max(1, int(n_coins)), len(queue))
    ok, done, pos, skipped, n_against = 0, 0, 0, [], 0
    with ThreadPoolExecutor(3) as pool:
        running = {}
        while True:
            while pos < len(queue) and ok + len(running) < target:
                running[pool.submit(coin_setups, c, queue[pos], rrs, min_usdt, sides)] = queue[pos]
                pos += 1
            if not running:
                break
            f = next(iter(as_completed(running)))
            s = running.pop(f)
            done += 1
            try:
                got = f.result()
                if only_aligned:                                   # v4.32: hanya setup searah kondisi pasar (Tren hijau)
                    n_against += sum(1 for r in got if not r.get("aligned"))
                    got = [r for r in got if r.get("aligned")]
                rows += got
                ok += 1
                err = None
            except (BinanceError, ValueError, KeyError, IndexError, ZeroDivisionError) as e:
                err = str(e)
                (errors if symbols else skipped).append(f"{s}: {e}")
            if progress:
                progress(min(ok, target), target, s, err)
                push = getattr(progress, "partial", None)     # hasil sementara: setup yang sudah ketemu langsung tampil
                if push and err is None:
                    part = _setups_result(list(rows), rrs, min_wr, top, ok, target, vol, skipped, errors, t0, partial=True)
                    part.update(only_aligned=only_aligned, n_against=n_against)
                    push(part)
    ev_model = grade_rows(rows)
    out = _setups_result(rows, rrs, min_wr, top, ok, target, vol, skipped, errors, t0)
    out.update(only_aligned=only_aligned, n_against=n_against)
    out["ev_model"] = ev_model
    if flow and out["setups"]:
        # 🧭 flow whale untuk setup yang tampil (info) + uji gabungan (searah vs melawan) dari trade backtest-nya
        from . import flowstudy as FS
        keep = {(r["symbol"], r["side"], r["rr"], r["how"]) for r in out["setups"]}
        try:
            out["flow_test"] = FS.enrich(c, out["setups"], [r for r in rows if (r["symbol"], r["side"], r["rr"], r["how"]) in keep],
                                         progress=getattr(progress, "flow", None))
        except Exception as ex:                                    # noqa: BLE001 - flow gagal: setup tetap tampil
            out["flow_test"] = {"error": f"{type(ex).__name__}: {ex}"}
    return out


def _setups_result(rows, rrs, min_wr, top, ok, target, vol, skipped, errors, t0, partial=False):
    """Susun hasil scan setup (dipakai juga untuk hasil sementara saat scan masih berjalan)."""
    comp = {}
    for r in rows:                                   # perbandingan RR per koin & arah
        key = (r["symbol"], r["side"])
        g = comp.setdefault(key, {"symbol": r["symbol"], "side": r["side"], "aligned": r["aligned"], "regime": r["regime"], "rr": {}})
        g["rr"][f"{r['rr']:g}"] = {"wr": r["wr"], "exp_r": r["exp_r"], "score": r["score"], "fill_pct": r["fill_pct"]}
    compare = []
    for g in comp.values():
        best = max(g["rr"].items(), key=lambda kv: kv[1]["score"])
        g["best_rr"], g["best_score"] = best[0], best[1]["score"]
        compare.append(g)
    compare.sort(key=lambda g: -g["best_score"])
    shown = [r for r in rows if r["wr"] >= float(min_wr or 0)]
    shown.sort(key=lambda r: (not r.get("usable", False), -r["score"]))      # yang layak dipasang selalu di atas
    good = [r for r in shown if r["exp_r"] > 0]
    usable = [r for r in shown if r.get("usable")]
    shown = [{k: v for k, v in r.items() if not k.startswith("_")} for r in shown]   # data internal tidak dikirim
    return {"setups": shown[:max(1, int(top))], "n_good": len(good), "n_usable": len(usable),
            "min_fill": SETUP_MIN_FILL, "min_test": SETUP_MIN_TEST, "n_all": len(rows), "n_shown": len(shown),
            "scanned": ok, "target": target, "available": len(vol), "skipped": len(skipped), "skipped_list": skipped[:20],
            "errors": errors[:10], "n_errors": len(errors), "rrs": rrs, "rr": rrs[0] if len(rrs) == 1 else None,
            "min_wr": float(min_wr or 0), "breakeven": {f"{x:g}": 100 / (1 + x) for x in rrs},
            "compare": compare[:max(1, int(top)) * 2], "time": int(time.time() * 1000), "elapsed": round(time.time() - t0, 2),
            "partial": partial}


def grade_rows(rows):
    """Kelas A / B / C tiap setup: bobot bukti dipelajari dari 70% trade awal SEMUA setup yang di-scan (banyak koin
    digabung, supaya tidak pas-pasan dengan 1 koin), dinilai di 30% trade terakhir. Tidak membuang setup apa pun."""
    from . import evidence as EV
    model = EV.learn_np(EV.concat([r.get("_evs") for r in rows]))
    for r in rows:
        snap = r.get("_evsnap")
        if snap is not None:
            r["evidence"] = EV.describe(model, snap, 0, 1 if r["side"] == "BUY" else -1, r.get("bt_tf") or "15m")
    return {k: model.get(k) for k in ("w", "stats", "grades", "proven", "note", "n_fit", "n_test", "sess")}


def setup_trades(c, sym, side, sl_pct, tp_pct, limit=300, dist_pct=None, down=None):
    """Contoh kejadian 🎯 Cari setup: tiap entry di backtest (data candle TERBARU dari Binance, aturan sama persis
    dengan saat scan: TF & batas waktu sesuai SL, filter tren seperti sekarang, kalau trade kurang -> tanpa filter)."""
    import numpy as np

    from .indicators import ema
    C = whale_cfg.get()
    long = str(side).upper() == "BUY"
    tf, mb = ("1h", int(C["bt.max_bars_1h"])) if sl_pct >= C["bt.sl_tf_switch_pct"] else ("15m", int(C["bt.max_bars_15m"]))
    k = c.get("/fapi/v1/klines", symbol=sym, interval=tf, limit=int(C["bt.candles"]))
    t = np.array([int(r[0]) for r in k], np.int64)
    o, h, l, cl = (np.array([float(r[i]) for r in k]) for i in (1, 2, 3, 4))
    e20, e50 = ema(cl, 20), ema(cl, 50)
    mask = (e20 > e50) == (e20[-1] > e50[-1]) if C["bt.trend_filter"] == "ya" else np.ones(len(cl), bool)
    is_limit = dist_pct is not None and down is not None and float(dist_pct) > C["fill.market_tol_pct"] and C["bt.limit_fill"] == "ya"
    fbars = max(1, int(round(C["fill.window"] / (4 if tf == "1h" else 1))))

    def run_bt(m):                                           # sama dengan saat scan (v4.33: limit dari candle yang menyentuh limit)
        if is_limit:
            return limit_backtest(o, h, l, cl, float(dist_pct), bool(down), sl_pct, tp_pct, long, max_bars=mb, fill_bars=fbars,
                                  trend_mask=m, detail=True)
        return first_touch_backtest(o, h, l, cl, sl_pct, tp_pct, long, max_bars=mb, trend_mask=m, detail=True)
    r = run_bt(mask)
    filt = True
    if r["n"] < C["bt.min_trades"]:
        r, filt = run_bt(None), False
    dur = {"1h": 3_600_000, "15m": 900_000}[tf]
    out = [{"time": int(t[i]), "entry": float(e), "sl": float(sl), "tp": float(tp), "result": int(res),
            "exit_time": int(t[ex]) if ex < len(t) else int(t[-1] + (ex - len(t) + 1) * dur)} for i, res, ex, e, sl, tp in r.pop("detail")]
    return {"symbol": sym, "side": "BUY" if long else "SELL", "tf": tf, "max_bars": mb, "trend_filter": filt, "stats": r,
            "trades": out[-limit:], "n": len(out)}


def bt_data(c, sym, sl_pct):
    """Data candle untuk backtest entry: SL lebar (>= 1.5%) pakai 1500 candle 1H (+-62 hari, batas 5 hari per trade),
    SL sempit pakai 1500 candle 15M (+-15 hari, batas 2 hari). Hasil: o, h, l, c, mask tren (EMA20 vs EMA50 sama
    seperti sekarang), max_bars, label TF."""
    import numpy as np

    from .indicators import ema
    C = whale_cfg.get()
    tf, mb = ("1h", int(C["bt.max_bars_1h"])) if sl_pct >= C["bt.sl_tf_switch_pct"] else ("15m", int(C["bt.max_bars_15m"]))
    k = c.get("/fapi/v1/klines", symbol=sym, interval=tf, limit=int(C["bt.candles"]))
    o, h, l, cl = (np.array([float(r[i]) for r in k]) for i in (1, 2, 3, 4))
    if len(_BT_T) > 500:
        _BT_T.clear()
    _BT_T[(sym, tf)] = np.array([int(r[0]) for r in k], np.int64)       # waktu candle (untuk uji gabungan flow)
    e20, e50 = ema(cl, 20), ema(cl, 50)
    mask = (e20 > e50) == (e20[-1] > e50[-1]) if C["bt.trend_filter"] == "ya" else np.ones(len(cl), bool)
    return o, h, l, cl, mask, mb, tf


_BT_T = {}
_BTC = {}          # tf -> (waktu ambil, t, c) candle BTC untuk bukti "arah BTC" (diperbarui tiap 5 menit)


def _btc_series(c, tf):
    x = _BTC.get(tf)
    if x and time.time() - x[0] < 300:
        return x[1], x[2]
    import numpy as np
    try:
        k = c.get("/fapi/v1/klines", symbol="BTCUSDT", interval=tf, limit=1500)
    except Exception:                                      # noqa: BLE001 - tanpa BTC: bukti BTC = 0
        return None
    if not k:
        return None
    v = (np.array([int(r[0]) for r in k], np.int64), np.array([float(r[4]) for r in k]))
    _BTC[tf] = (time.time(), v[0], v[1])
    return v


def ev_votes(c, sym, tf, o, h, l, cl):
    """Suara bukti (Elliott, D1, BTC, kekuatan relatif, sapuan likuiditas, sesi) di tiap candle data backtest koin ini."""
    import numpy as np

    from . import evidence as EV
    t = _BT_T.get((sym, tf))
    if t is None or len(t) != len(cl):
        return None
    try:
        kd = c.get("/fapi/v1/klines", symbol=sym, interval="1d", limit=120)
        d1 = (np.array([int(r[0]) for r in kd], np.int64), np.array([float(r[4]) for r in kd]))
    except Exception:                                      # noqa: BLE001
        d1 = None
    return EV.coin_votes(t, o, h, l, cl, tf, btc=_btc_series(c, tf), d1=d1, symbol=sym)


def _one_at_a_time(det, rr):
    """Hasil trade (R) seperti dijalani sungguhan: SATU posisi sekali jalan — trade berikutnya baru dihitung sesudah
    trade sebelumnya selesai (backtest entry tiap candle tumpang tindih, jadi kalah beruntunnya terlihat berlebihan)."""
    out, free = [], -1
    for i, res, ex, *_ in det:
        if i <= free:
            continue
        out.append(rr if res == 1 else -1.0)                           # menang = +RR, kalah / belum kena = -1R
        free = ex
    return out
