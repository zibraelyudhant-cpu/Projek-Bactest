"""Jalur animasi PRICE ACTION untuk kartu visual (Whale, Screener Market Structure, Cek entry posisi).

Harga jarang bergerak lurus ke TP / SL. Jalur ini dibuat bertahap:
  harga sekarang -> (limit: ke entry dulu) -> SNR minor pertama di jalur -> mantul -> SNR minor berikutnya -> ... -> TP / SL.
  - SNR minor = swing high / low terakhir (fractal 3) + tembok order whale (kalau ada), yang ada DI ANTARA entry dan target.
  - Dalam mantul = median balikan leg koin itu sendiri (swing kecil 1 ATR, 300 candle terakhir), dibatasi 30-75%.
  - Hasil akhir (kena TP atau SL) & lama sampai selesai diambil dari backtest / riwayat (bukan dikarang).
  - Mantul tidak pernah menyentuh SL (kalau hasilnya TP) / TP (kalau hasilnya SL) sebelum waktunya.
Ini ILUSTRASI bentuk gerak; yang diuji tetap arah, TP / SL, WR dan waktunya.
"""
import numpy as np

from .indicators import atr as _atr
from .indicators import pivots as _pivots

RETR_MIN, RETR_MAX, RETR_DEF = 0.3, 0.75, 0.5
MAX_STOPS = 3
GAP = 3.0             # ATR maksimal tanpa koreksi


def minor_levels(h, l, n=3, look=300):
    """Swing high & low terakhir (sudah terkonfirmasi) sebagai SNR minor."""
    h, l = np.asarray(h, float)[-look:], np.asarray(l, float)[-look:]
    hi, lo = _pivots(h, l, n)
    return [float(h[i]) for i in hi] + [float(l[i]) for i in lo]


def median_retrace(h, l, c, look=300):
    """Median balikan leg swing kecil (1 ATR) koin ini: leg berikutnya / leg sebelumnya."""
    from .evidence import zigzag
    h, l, c = (np.asarray(x, float)[-look:] for x in (h, l, c))
    if len(c) < 40:
        return RETR_DEF
    a = _atr(h, l, c, 14)
    piv, _ = zigzag(h, l, a, 1.0)
    p = [x[1] for x in piv]
    r = [abs(p[i + 1] - p[i]) / abs(p[i] - p[i - 1]) for i in range(1, len(p) - 1) if abs(p[i] - p[i - 1]) > 0]
    r = [x for x in r if x < 1.0]                                   # balikan (bukan tembus)
    return float(np.clip(np.median(r), RETR_MIN, RETR_MAX)) if r else RETR_DEF


def build(p0, entry, sl, tp, long, outcome, bars, atr, levels=(), retr=RETR_DEF, fill_bars=None, seed=0, fmt=None):
    """Jalur candle per candle (dalam ATR dari harga sekarang p0) + titik mantul.
    outcome: "tp" / "sl". bars = lama entry -> selesai (candle, median riwayat). fill_bars = lama sampai limit terisi."""
    A = float(atr)
    if not (A > 0 and bars and bars > 0):
        return None
    rng = np.random.default_rng(seed)
    m_tp = 1 if long else -1
    tgt, opp = (tp, sl) if outcome == "tp" else (sl, tp)
    m = 1 if tgt > entry else -1                                   # arah gerak ke target
    fmt = fmt or (lambda x: f"{x:.6g}")
    # titik-titik jalur: (harga, label)
    way = [(p0, None)]
    mk = []
    near = abs(entry - p0) <= 0.05 * A
    if not near:
        way.append((entry, "entry terisi"))
    # SNR minor di antara entry & target, berjarak dari entry/target/sesamanya
    lv = sorted({round(x, 12) for x in levels if (x - entry) * m > 0.5 * A and (tgt - x) * m > 0.5 * A}, key=lambda x: (x - entry) * m)
    stops = []
    for x in lv:
        if all(abs(x - y) >= 0.8 * A for y in stops):
            stops.append(x)
        if len(stops) >= MAX_STOPS:
            break
    synthetic = not stops and abs(tgt - entry) > 1.6 * A
    # jarak tanpa SNR yang terlalu panjang (> GAP ATR): harga tetap butuh koreksi -> koreksi normal tiap ±GAP ATR
    pts = [entry] + stops + [tgt]
    kinds = {x: "snr" for x in stops}
    for a_, b_ in zip(pts[:-1], pts[1:]):
        span = abs(b_ - a_)
        n_add = int(span // (GAP * A)) if span > 1.6 * A else 0
        if a_ == entry and b_ == tgt and n_add == 0 and synthetic:
            n_add = 1
        for j in range(1, n_add + 1):
            x = a_ + m * span * j / (n_add + 1)
            kinds[x] = "normal"
    stops = sorted(kinds, key=lambda x: (x - entry) * m)[:MAX_STOPS + 2]
    start = entry
    for x in stops:
        way.append((x, ("koreksi normal" if kinds[x] == "normal" else f"mantul di SNR minor {fmt(x)}")))
        pb = x - m * retr * abs(x - start)
        # mantul tidak boleh menyentuh level lawan (SL kalau menuju TP, TP kalau menuju SL)
        lim = opp - (-m) * 0.25 * A                                # sisi lawan ada di arah -m
        pb = max(pb, lim) if m > 0 else min(pb, lim)
        way.append((pb, None))
        start = pb
    way.append((tgt, "kena TP" if outcome == "tp" else "kena SL"))
    # waktu: limit -> fill_bars, sisanya dibagi rata menurut jarak
    seg = list(zip(way[:-1], way[1:]))
    if not near:
        fb = max(1, int(round(fill_bars or 4)))
        rest = seg[1:]
    else:
        fb, rest = 0, seg
    dist = [abs(b[0] - a[0]) for a, b in rest]
    tot = sum(dist) or 1.0
    nb = [max(1, int(round(bars * d / tot))) for d in dist]
    plan = ([fb] if not near else []) + nb
    close, high, low = [], [], []
    k = 0
    prev = p0
    for (a, b), n in zip(seg, plan):
        for j in range(1, n + 1):
            cl = a[0] + (b[0] - a[0]) * j / n
            if j < n:
                cl += rng.normal(0, 0.18) * A                       # goyangan kecil di dalam leg
            hi_ = max(prev, cl) + abs(rng.normal(0, 0.18)) * A
            lo_ = min(prev, cl) - abs(rng.normal(0, 0.18)) * A
            last = (b is way[-1]) and j == n
            # sebelum candle terakhir: jangan menyentuh TP / SL; entry baru boleh tersentuh di akhir leg ke entry
            for lvl in (tp, sl):
                if last and lvl == tgt:
                    continue
                if hi_ >= lvl > prev and not last:
                    hi_ = lvl - 0.05 * A
                if lo_ <= lvl < prev and not last:
                    lo_ = lvl + 0.05 * A
            if not near and b[0] == entry and j == n:
                if entry < p0:
                    lo_ = min(lo_, entry)
                else:
                    hi_ = max(hi_, entry)
            elif not near and k < fb:                              # belum waktunya terisi
                if entry < p0:
                    lo_ = max(lo_, entry + 0.05 * A)
                    cl = max(cl, entry + 0.05 * A)
                else:
                    hi_ = min(hi_, entry - 0.05 * A)
                    cl = min(cl, entry - 0.05 * A)
            if last:
                cl = tgt
                if tgt > prev:
                    hi_ = max(hi_, tgt)
                else:
                    lo_ = min(lo_, tgt)
            cl = min(max(cl, lo_), hi_)
            close.append(cl)
            high.append(hi_)
            low.append(lo_)
            prev = cl
            k += 1
        if b[1]:
            mk.append({"k": k - 1, "r": round((b[0] - p0) / A, 3), "text": b[1]})
    rel = lambda arr: [round((x - p0) / A, 3) for x in arr]          # noqa: E731
    return {"close": rel(close), "high": rel(high), "low": rel(low), "marks": mk, "outcome": outcome,
            "stops": [round(x, 12) for x in stops], "synthetic": synthetic, "retr": round(float(retr), 3), "m_tp": m_tp}
