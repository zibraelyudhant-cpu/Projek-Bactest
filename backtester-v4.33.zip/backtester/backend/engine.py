"""Engine simulasi Binance USDT-M Futures (one-way mode, margin isolated).

Clock maju per base bar (M5). Order yang dibuat pada waktu `now` baru aktif mulai
bar berikutnya. Urutan harga di dalam bar diasumsikan mengikuti jalur O->L->H->C
(bar bullish) atau O->H->L->C (bar bearish), sehingga entry, TP, SL dan likuidasi
di bar yang sama diproses sesuai urutan kejadian.
"""
from dataclasses import asdict, dataclass

import numpy as np

from .data import TF_MS, DataView

EPS = 1e-12


@dataclass
class AccountConfig:
    balance: float = 1000.0
    use_margin: bool = False      # False: tanpa margin/leverage/likuidasi (order sederhana)
    leverage: float = 10.0
    maker_fee: float = 0.0002     # 0.02%
    taker_fee: float = 0.0005     # 0.05%
    slippage_bps: float = 1.0     # untuk market & stop (1 bps = 0.01%)
    mmr: float = 0.005            # maintenance margin rate (aproksimasi)
    limit_fill: str = "through"   # "through": harga harus menembus limit | "touch"
    intrabar: str = "ohlc"        # "ohlc": heuristik arah candle | "pessimistic"

    @classmethod
    def from_dict(cls, d):
        d = d or {}
        return cls(**{k: type(getattr(cls, k))(v) for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class Order:
    id: int
    side: int                 # +1 buy, -1 sell
    type: str                 # market | limit | stop
    qty: float
    price: float = None
    tp: float = None
    sl: float = None
    reduce_only: bool = False
    oco: int = None
    tag: str = ""
    created: int = 0          # ms (= engine.now saat order dibuat)
    active_bar: int = 0       # open time bar pertama tempat order boleh dieksekusi
    active_pos: float = 0.0   # posisi jalur intrabar mulai aktif (untuk bracket)
    expire: int = None
    status: str = "open"      # open | filled | canceled | rejected
    fill_price: float = None
    fill_time: int = None
    fee: float = 0.0
    note: str = ""
    ref: float = None         # harga terakhir saat order dibuat (harga sinyal)

    def to_dict(self):
        d = asdict(self)
        d["side"] = "buy" if self.side > 0 else "sell"
        return d


def bar_path(o, h, l, c, bias=0):
    """bias +1: paksa O->L->H->C, -1: paksa O->H->L->C, 0: ikut arah candle."""
    if bias > 0 or (bias == 0 and c >= o):
        return [o, l, h, c]
    return [o, h, l, c]


def price_at(path, pos):
    i = min(int(pos), len(path) - 2)
    return path[i] + (path[i + 1] - path[i]) * (pos - i)


def trigger_pos(path, start, level, direction, strict=False):
    """Posisi pertama (>= start) di jalur saat kondisi terpenuhi.
    direction -1: harga <= level (turun ke level), +1: harga >= level."""
    if direction < 0:
        ok = (lambda p: p < level) if strict else (lambda p: p <= level)
    else:
        ok = (lambda p: p > level) if strict else (lambda p: p >= level)
    n = len(path) - 1
    i = int(start)
    while i < n:
        s = max(start, i)
        a, b = path[i], path[i + 1]
        if ok(a + (b - a) * (s - i)):
            return s
        if ok(b):
            return max(s, i + (level - a) / (b - a))
        i += 1
    return None


class Engine:
    def __init__(self, store, symbol, start_ms, end_ms=None, cfg=None):
        self.store, self.symbol = store, symbol
        self.cfg = cfg or AccountConfig()
        self.base_tf = store.base_tf(symbol)
        self.base_ms = TF_MS[self.base_tf]
        self.base = store.get(symbol, self.base_tf)
        self.i = int(np.searchsorted(self.base.t, start_ms))
        self.end_i = len(self.base) if end_ms is None else int(np.searchsorted(self.base.t, end_ms))
        self.now = int(self.base.t[self.i]) if self.i < len(self.base) else int(start_ms)
        self.view = DataView(store, symbol, lambda: self.now)

        self.balance = self.cfg.balance
        self.pos = 0.0
        self.entry = 0.0
        self.last_price = float(self.base.c[self.i - 1]) if self.i > 0 else float(self.base.o[self.i])
        self.orders = {}
        self.fills = []
        self.trades = []
        self.events = []
        self.fees_paid = 0.0
        self.missed = []          # order entry limit yang kadaluarsa tanpa terisi
        self._trade = None
        self._oid = 0
        self._oco = 0

    # ------------------------------------------------------------------ clock
    @property
    def done(self):
        return self.i >= self.end_i or self.equity() <= 0

    def next_bar_time(self):
        return int(self.base.t[self.i]) if self.i < len(self.base) else self.now

    def step(self):
        if self.done:
            return False
        i = self.i
        t = int(self.base.t[i])
        o, h, l, c = (float(x[i]) for x in (self.base.o, self.base.h, self.base.l, self.base.c))
        for od in self.open_orders():
            if od.expire is not None and t >= od.expire:
                self._cancel(od, "expired")
        self._process_bar(t, o, h, l, c)
        self.last_price = c
        self.i += 1
        self.now = t + self.base_ms
        return True

    def run_until(self, target_ms, max_steps=10_000_000):
        n = 0
        while self.now < target_ms and n < max_steps and self.step():
            n += 1
        return n

    # ---------------------------------------------------------------- orders
    def place(self, side, type, qty, price=None, tp=None, sl=None,
              reduce_only=False, expire_ms=None, tag=""):
        side = {"buy": 1, "sell": -1, 1: 1, -1: -1}[side]
        if type not in ("market", "limit", "stop"):
            raise ValueError(f"tipe order tidak dikenal: {type}")
        if not qty or qty <= 0:
            raise ValueError("qty harus > 0")
        if type != "market" and (price is None or price <= 0):
            raise ValueError("limit/stop butuh price > 0")
        self._oid += 1
        od = Order(self._oid, side, type, float(qty), None if price is None else float(price),
                   tp=tp or None, sl=sl or None, reduce_only=bool(reduce_only), tag=tag,
                   created=self.now, active_bar=self.next_bar_time(), expire=expire_ms, ref=self.last_price)
        self.orders[od.id] = od
        return od

    def modify(self, oid, price=None, tp=None, sl=None):
        od = self.orders[oid]
        if od.status != "open":
            raise ValueError("order sudah tidak aktif")
        if price is not None:
            od.price = float(price)
        if tp is not None:
            od.tp = tp or None
        if sl is not None:
            od.sl = sl or None
        od.active_bar, od.active_pos = self.next_bar_time(), 0.0  # berlaku mulai bar berikutnya
        return od

    def cancel(self, oid):
        od = self.orders.get(oid)
        if od and od.status == "open":
            self._cancel(od, "user")

    def cancel_all(self):
        for od in self.open_orders():
            self._cancel(od, "user")

    def close_position(self):
        if abs(self.pos) > EPS:
            return self.place(-1 if self.pos > 0 else 1, "market", abs(self.pos), reduce_only=True, tag="close")

    def open_orders(self):
        return [od for od in self.orders.values() if od.status == "open"]

    # --------------------------------------------------------------- account
    def equity(self, price=None):
        p = self.last_price if price is None else price
        return self.balance + self.pos * (p - self.entry)

    def liq_price(self):
        if not self.cfg.use_margin:
            return None
        if abs(self.pos) < EPS:
            return None
        lev, mmr = self.cfg.leverage, self.cfg.mmr
        if self.pos > 0:
            return self.entry * (1 - 1 / lev + mmr)
        return self.entry * (1 + 1 / lev - mmr)

    def snapshot(self):
        return {
            "now": self.now, "symbol": self.symbol, "done": self.done,
            "balance": self.balance, "equity": self.equity(), "position": self.pos,
            "entry": self.entry if abs(self.pos) > EPS else None,
            "upnl": self.pos * (self.last_price - self.entry), "liq": self.liq_price(),
            "last_price": self.last_price, "fees": self.fees_paid,
            "orders": [od.to_dict() for od in self.open_orders()],
        }

    def drain_events(self):
        ev, self.events = self.events, []
        return ev

    # -------------------------------------------------------------- matching
    def _path_bias(self, t):
        if self.cfg.intrabar != "pessimistic":
            return 0
        if abs(self.pos) > EPS:
            return 1 if self.pos > 0 else -1  # long: low dulu (SL dulu), short: high dulu
        for od in self.open_orders():
            if not od.reduce_only and od.active_bar <= t:
                return od.side
        return 0

    def _trigger(self, od, path, start):
        if od.type == "market":
            return start
        if od.type == "limit":
            return trigger_pos(path, start, od.price, -od.side, self.cfg.limit_fill == "through")
        return trigger_pos(path, start, od.price, od.side)  # stop

    def _process_bar(self, t, o, h, l, c):
        if not self.orders and abs(self.pos) < EPS:
            return
        path = bar_path(o, h, l, c, self._path_bias(t))
        pos = 0.0
        for _ in range(100):
            best = None
            for od in self.open_orders():
                if od.active_bar > t:
                    continue
                act = od.active_pos if od.active_bar == t else 0.0
                p = self._trigger(od, path, max(pos, act))
                if p is not None and (best is None or p < best[0]):
                    best = (p, od, p == act and od.active_bar == t)
            liq = self.liq_price()
            if liq is not None:
                p = trigger_pos(path, pos, liq, -1 if self.pos > 0 else 1)
                if p is not None and (best is None or p < best[0]):
                    self._liquidate(t, liq)
                    pos = p
                    continue
            if best is None:
                break
            pos, od, immediate = best
            self._fill(od, path, pos, t, immediate)
        self.orders = {k: v for k, v in self.orders.items() if v.status == "open"}

    def _fill(self, od, path, p, t, immediate):
        px = price_at(path, p)
        slip = self.cfg.slippage_bps / 10_000
        if od.type == "limit" and not immediate:
            price, fee_rate, liq = od.price, self.cfg.maker_fee, "maker"   # resting -> harga limit
        elif od.type == "limit":
            price, fee_rate, liq = px, self.cfg.taker_fee, "taker"         # marketable -> harga pasar
        else:
            price, fee_rate, liq = px * (1 + od.side * slip), self.cfg.taker_fee, "taker"  # market/stop

        qty = od.qty
        if od.reduce_only:
            if abs(self.pos) < EPS or np.sign(self.pos) == od.side:
                self._cancel(od, "reduce-only tanpa posisi")
                return
            qty = min(qty, abs(self.pos))
        else:
            new_pos = self.pos + od.side * qty
            if self.cfg.use_margin and abs(new_pos) > abs(self.pos) + EPS:
                need = abs(new_pos) * price / self.cfg.leverage
                if need > self.equity(price) + EPS:
                    od.status, od.note = "rejected", "margin tidak cukup"
                    self.events.append({"type": "rejected", "order": od.to_dict(), "time": t})
                    return

        n_closed = len(self.trades)
        fee = self._apply(od.side, qty, price, fee_rate, t)
        if not od.reduce_only and self._trade is not None and "sl" not in self._trade:
            # rencana trade: dipakai evaluasi strategi (SL/TP awal, harga & waktu sinyal)
            self._trade.update(sl=od.sl, tp=od.tp, tag=od.tag, order_type=od.type,
                               signal_time=od.created, signal_price=od.ref)
        if len(self.trades) > n_closed:
            self.trades[-1]["exit_reason"] = od.tag if od.tag in ("tp", "sl") else od.type
        od.status, od.fill_price, od.fill_time, od.fee = "filled", price, t, fee
        fill = {"type": "fill", "time": t, "order_id": od.id, "side": "buy" if od.side > 0 else "sell",
                "qty": qty, "price": price, "fee": fee, "liquidity": liq, "tag": od.tag or od.type}
        self.fills.append(fill)
        self.events.append(fill)

        if od.oco is not None:
            for o2 in self.open_orders():
                if o2.oco == od.oco:
                    self._cancel(o2, "oco")
        if (od.tp or od.sl) and not od.reduce_only:
            self._oco += 1
            for kind, lvl in (("tp", od.tp), ("sl", od.sl)):
                if lvl:
                    self._oid += 1
                    self.orders[self._oid] = Order(
                        self._oid, -od.side, "limit" if kind == "tp" else "stop", qty, float(lvl),
                        reduce_only=True, oco=self._oco, tag=kind, created=t, active_bar=t, active_pos=p)
        if abs(self.pos) < EPS:
            for o2 in self.open_orders():
                if o2.reduce_only:
                    self._cancel(o2, "posisi tutup")

    def _liquidate(self, t, price):
        side = -1 if self.pos > 0 else 1
        qty = abs(self.pos)
        fee = self._apply(side, qty, price, self.cfg.taker_fee, t)
        clearance = qty * price * self.cfg.mmr
        self.balance -= clearance
        if self._trade is None and self.trades:
            self.trades[-1]["pnl"] -= clearance
            self.trades[-1]["exit_reason"] = "liquidation"
        ev = {"type": "liquidation", "time": t, "price": price, "qty": qty, "fee": fee + clearance,
              "side": "buy" if side > 0 else "sell", "tag": "liq"}
        self.fills.append(ev)
        self.events.append(ev)
        for od in self.open_orders():
            if od.reduce_only:
                self._cancel(od, "likuidasi")

    def _cancel(self, od, reason):
        od.status, od.note = "canceled", reason
        if reason == "expired" and not od.reduce_only and od.type == "limit":
            self.missed.append({"side": "long" if od.side > 0 else "short", "price": od.price, "sl": od.sl,
                                "tp": od.tp, "created": od.created, "expired": self.now, "tag": od.tag})
        self.events.append({"type": "canceled", "order_id": od.id, "reason": reason})

    def _apply(self, side, qty, price, fee_rate, t):
        """Update posisi + saldo. Return fee."""
        fee = qty * price * fee_rate
        self.balance -= fee
        self.fees_paid += fee
        if abs(self.pos) < EPS or np.sign(self.pos) == side:
            if abs(self.pos) < EPS:
                self._trade = {"side": "long" if side > 0 else "short", "entry_time": t,
                               "equity_at_entry": self.balance + fee, "qty": 0.0,
                               "exit_qty": 0.0, "exit_value": 0.0, "pnl": 0.0, "fees": 0.0}
            new = self.pos + side * qty
            self.entry = (self.entry * abs(self.pos) + price * qty) / abs(new)
            self.pos = new
            self._trade["qty"] += qty
            self._trade["entry"] = self.entry
            self._trade["pnl"] -= fee
            self._trade["fees"] += fee
            return fee

        close_qty = min(qty, abs(self.pos))
        realized = close_qty * (price - self.entry) * np.sign(self.pos)
        self.balance += realized
        part = fee * close_qty / qty
        tr = self._trade
        tr["exit_qty"] += close_qty
        tr["exit_value"] += close_qty * price
        tr["pnl"] += realized - part
        tr["fees"] += part
        self.pos += side * close_qty
        rem = qty - close_qty
        if abs(self.pos) < EPS:
            self.pos = 0.0
            tr.update(exit_time=t, exit=tr["exit_value"] / tr["exit_qty"],
                      return_pct=100 * tr["pnl"] / tr["equity_at_entry"])
            for k in ("exit_qty", "exit_value"):
                tr.pop(k)
            self.trades.append(tr)
            self._trade = None
            self.entry = 0.0
        if rem > EPS:  # reversal
            self._trade = {"side": "long" if side > 0 else "short", "entry_time": t,
                           "equity_at_entry": self.balance, "qty": rem, "entry": price,
                           "exit_qty": 0.0, "exit_value": 0.0, "pnl": -(fee - part), "fees": fee - part}
            self.pos, self.entry = side * rem, price
        return fee
