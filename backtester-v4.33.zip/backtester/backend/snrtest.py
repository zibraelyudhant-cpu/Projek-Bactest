"""📍 Tes SNR + Dorongan %: saat harga mendekati support / resistance, berapa Dorongan % dan jaraknya ke SNR,
lalu apa yang terjadi: BREAKOUT (close tembus) atau RESPECT (cuma nyentuh / wick lalu balik).

- SNR = swing high (resistance) / swing low (support) di TF SNR (fractal n), baru dipakai SETELAH terkonfirmasi.
  Level yang berdekatan (< 0.3 ATR) dengan level aktif digabung. Level berlaku sampai tembus atau `life` candle.
- Tiap kali harga mendekat (dari > 2 ATR menjadi <= 2 ATR) = satu "pendekatan". Dicatat Dorongan % dan arah
  dorongannya di candle pertama saat jarak <= 2, 1, 0.5 ATR dan saat MENYENTUH (wick <= tol ATR dari SNR).
- Hasil pendekatan: BREAKOUT = ada close melewati SNR dan bertahan `hold_h` jam (kalau balik = FAKEOUT, dihitung
  SNR bertahan); RESPECT = sudah menyentuh lalu close menjauh >= `away` ATR dan `hold_h` jam berikutnya tidak ada
  close tembus (kalau ada, pantulan itu belum dihitung & pendekatan lanjut sampai hasil yang sah); TIDAK SAMPAI = balik menjauh > 2 ATR sebelum menyentuh. Tanpa hasil sampai level habis = dibuang.
- Semua nilai dari candle yang SUDAH close (tanpa intip masa depan). 70% data awal untuk mencari batas, 30% untuk menguji.
Dorongan % dihitung PERSIS sama dengan indikator "Dorongan %" di chart (frontend/app.js doronganCalc).
"""
import json
import os
import threading
import time

import numpy as np

from .data import TF_MS
from .indicators import atr as _atr, dmi as _dmi, ema as _ema, force_index as _fi, pivots

BANDS = [("2", 2.0), ("1.5", 1.5), ("1", 1.0), ("0.5", 0.5), ("sentuh", None)]   # dibaca SEBELUM sampai SNR (2 / 1 / 0.5 ATR) + saat menyentuh
BUCKETS = list(range(0, 100, 10))                     # 0-10, 10-20, ... 90-100
SMOOTHS = [3, 5, 10, 15, 20]                          # penghalusan yang dibandingkan (mode otomatis)
ADX_LENS = [7, 10, 14, 20, 28]                        # panjang ADX yang dibandingkan (indikator ADX / ADX + Force Index)
INDS = ("dorongan", "adx", "adxfi")                   # indikator yang dites: Dorongan % / ADX / ADX + arah Force Index
MIN_AUC = 55.0                                        # di bawah ini Dorongan % belum cukup bisa dipercaya
DEF_FILE = os.environ.get("DORONGAN_DEF_FILE",
                          os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "saved", "dorongan_default.json"))
_def_lock = threading.Lock()
DEFAULTS = {"tf": "15m", "snr_tf": "1h", "swing": 3, "life": 2000, "touch": 0.1, "away": 1.0, "target": 60,
            "min_n": 30, "hold_h": 1.0, "hold": None, "ind": "dorongan", "read_band": "1.5", "adx_len": 14, "fi_len": 13, "vol_len": 20, "smooth": 10, "auto_smooth": True, "toward": True, "start": None, "end": None}


def dorongan_raw(h, l, c, v, n_adx=14, n_fi=13, n_vol=20):
    """Skor Dorongan SEBELUM penghalusan (0-100, NaN sebelum cukup data) & arah (+1 beli / -1 jual)."""
    n = len(c)
    P = np.full(n, np.nan)
    D = np.zeros(n, np.int8)
    tr = pdm = ndm = 0.0
    adx = None
    dxs = []
    fi = None
    fi_abs, vols = [], []
    a_fi = 2 / (n_fi + 1)
    wil = lambda prev, x, k: (prev * (k - 1) + x) / k  # noqa: E731
    for i in range(1, n):
        up, dn = h[i] - h[i - 1], l[i - 1] - l[i]
        t = max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
        p1 = up if (up > dn and up > 0) else 0.0
        n1 = dn if (dn > up and dn > 0) else 0.0
        if i <= n_adx:
            tr += t; pdm += p1; ndm += n1  # noqa: E702
        else:
            tr, pdm, ndm = wil(tr, t, n_adx), wil(pdm, p1, n_adx), wil(ndm, n1, n_adx)
        pdi = ndi = None
        if i >= n_adx and tr > 0:
            pdi, ndi = 100 * pdm / tr, 100 * ndm / tr
            dx = 100 * abs(pdi - ndi) / (pdi + ndi) if pdi + ndi > 0 else 0.0
            if adx is None:
                dxs.append(dx)
                if len(dxs) == n_adx:
                    adx = sum(dxs) / n_adx
            else:
                adx = wil(adx, dx, n_adx)
        raw = (c[i] - c[i - 1]) * (v[i] or 0.0)
        fi = raw if fi is None else a_fi * raw + (1 - a_fi) * fi
        fi_abs.append(abs(fi))
        if len(fi_abs) > 100:
            fi_abs.pop(0)
        v_avg = sum(vols) / len(vols) if vols else None
        vols.append(v[i] or 0.0)
        if len(vols) > n_vol:
            vols.pop(0)
        if adx is None or v_avg is None or len(fi_abs) < 20:
            continue
        fi_avg = sum(fi_abs) / len(fi_abs)
        cl = lambda x: max(0.0, min(1.0, x))  # noqa: E731
        s_a = cl(adx / 50)
        s_f = cl(abs(fi) / (2 * fi_avg)) if fi_avg > 0 else 0.0
        s_v = cl((v[i] or 0.0) / v_avg / 3) if v_avg > 0 else 0.0
        score = 100 * (0.4 * s_a + 0.35 * s_f + 0.25 * s_v)
        P[i] = score
        D[i] = 1 if fi > 0 else -1 if fi < 0 else (1 if (pdi or 0) >= (ndi or 0) else -1)
    return P, D


def smooth_score(S, n_smooth=10):
    """Penghalusan (EMA) skor Dorongan, dibulatkan 1 desimal seperti di chart (EMA tetap pakai nilai belum dibulatkan)."""
    out = np.full(len(S), np.nan)
    a_s = 2 / (max(1, int(n_smooth)) + 1)
    e = None
    for i, x in enumerate(S.tolist()):
        if x != x:
            continue
        e = x if e is None else a_s * x + (1 - a_s) * e
        out[i] = round(e, 1)
    return out


def dorongan(h, l, c, v, n_adx=14, n_fi=13, n_vol=20, n_smooth=10):
    """Dorongan % (0-100) & arah (+1 beli / -1 jual) per candle; NaN sebelum cukup data. Sama persis dengan versi chart."""
    S, D = dorongan_raw(h, l, c, v, n_adx, n_fi, n_vol)
    return smooth_score(S, n_smooth), D


def _slice(b, start, end):
    t = np.asarray(b.t)
    lo = np.searchsorted(t, int(start)) if start else 0
    hi = np.searchsorted(t, int(end), side="right") if end else len(t)
    return [np.asarray(x, float)[lo:hi] for x in (b.t, b.o, b.h, b.l, b.c, b.v)]


def _levels(sb, q, t_entry, a_entry):
    """Level SNR dari swing TF SNR: (harga, sisi +1 resistance / -1 support, index entry mulai berlaku)."""
    st, sh, sl = sb[0], sb[2], sb[3]
    n = int(q["swing"])
    ms = TF_MS[q["snr_tf"]]
    hi_i, lo_i = pivots(sh, sl, n)
    out = []
    for idx, side, src in ((hi_i, 1, sh), (lo_i, -1, sl)):
        for k in idx:
            if k + n >= len(st):
                continue
            avail = st[k + n] + ms                       # swing baru diketahui setelah candle konfirmasi close
            s = int(np.searchsorted(t_entry, avail))
            if s < len(t_entry):
                out.append((float(src[k]), side, s))
    out.sort(key=lambda x: x[2])
    return out


def _holds(c, j, L, side, n_hold):
    """Breakout VALID kalau setelah close tembus di j, tidak ada close balik ke dalam SNR selama n_hold candle.
    False = fakeout (close tembus lalu balik = SNR sebenarnya bertahan)."""
    seg = c[j + 1:j + 1 + n_hold]
    back = (seg < L) if side > 0 else (seg > L)
    return not bool(back.any())


def _follow(h, l, c, j, L, side, atr_j, life):
    """Lanjutan breakout dari close tembus di candle j: 1 = harga lanjut >= 1 ATR searah tembusan SEBELUM ada close balik
    ke dalam SNR; 0 = fakeout (close balik dulu; kalau di candle yang sama dua-duanya terjadi = fakeout); -1 = belum jelas."""
    tgt = c[j] + atr_j if side > 0 else c[j] - atr_j
    for m in range(j + 1, min(len(c), j + life)):
        if (side > 0 and c[m] < L) or (side < 0 and c[m] > L):
            return 0
        if (side > 0 and h[m] >= tgt) or (side < 0 and l[m] <= tgt):
            return 1
    return -1


def study_coin(store, sym, q, smooths=None):
    b = store.get(sym, q["tf"])
    t, o, h, l, c, v = _slice(b, q.get("start"), q.get("end"))
    n = len(c)
    if n < 500:
        return f"data terlalu sedikit di periode ini ({n} candle)"
    sb = _slice(store.get(sym, q["snr_tf"]), None, t[-1])
    a = _atr(h, l, c, 14)
    ind = q.get("ind", "dorongan")
    if ind == "dorongan":
        smooths = smooths or [int(q["smooth"])]
        S, D = dorongan_raw(h, l, c, v, int(q["adx_len"]), int(q["fi_len"]), int(q["vol_len"]))   # sekali per koin
        PS = {sm: smooth_score(S, sm) for sm in smooths}       # yang beda cuma penghalusan di akhir
    else:
        # ADX: nilai 0-100 (dibulatkan 1 desimal seperti di chart); "smooths" = panjang ADX yang dibandingkan.
        # Arah: ADX saja -> +DI vs -DI; ADX + Force Index -> tanda Force Index (positif = tekanan beli).
        smooths = smooths or [int(q["adx_len"])]
        PS, D = {}, None
        for k_, ln in enumerate(smooths):
            pdi, ndi, adx = _dmi(h, l, c, int(ln))
            PS[ln] = np.round(adx, 1)
            if k_ == 0:
                D = np.where(pdi >= ndi, 1, -1).astype(np.int8)
        if ind == "adxfi":
            fi = _fi(c, v, int(q["fi_len"]))
            D = np.where(fi > 0, 1, np.where(fi < 0, -1, D)).astype(np.int8)
    P = PS[smooths[0]]
    split = int(n * 0.7)
    # tren TF besar: EMA 50 vs 200 di TF SNR, candle TF SNR yang SUDAH close saat candle entry close
    st_, sc_ = sb[0], sb[4]
    htf_up = np.zeros(n, np.int8)                         # +1 naik, -1 turun, 0 belum cukup data
    if len(sc_) > 210:
        e50, e200 = _ema(sc_, 50), _ema(sc_, 200)
        jj = np.searchsorted(st_ + TF_MS[q["snr_tf"]], t + TF_MS[q["tf"]], side="right") - 1
        okj = jj >= 200
        jc = np.clip(jj, 0, len(sc_) - 1)
        htf_up = np.where(okj, np.where(e50[jc] > e200[jc], 1, -1), 0).astype(np.int8)
    c10 = np.r_[np.full(10, np.nan), c[:-10]]             # close 10 candle sebelumnya (kecepatan datang)
    tf_h = TF_MS[q["tf"]] / 3_600_000
    life, tol, away = int(q["life"]), float(q["touch"]), float(q["away"])
    n_hold = int(q["hold"])
    active = []                                          # (harga, sisi, mulai, habis) untuk menggabung level berdekatan
    BI = {name: i for i, (name, _) in enumerate(BANDS)}
    OI = {"breakout": 0, "respect": 1, "tidak sampai": 2}
    rb, rk, rto, ro, rd, rs, rl = [], [], [], [], [], [], []
    rtw, rtc, rage, rspd, rfol, rfk = [], [], [], [], [], []       # faktor: tren TF besar, sentuhan sebelumnya, umur, kecepatan, lanjutan breakout
    for L, side, s in _levels(sb, q, t, a):
        if not (a[s] == a[s]) or a[s] <= 0:
            continue
        active = [x for x in active if x[3] > s]           # buang level yang sudah habis (supaya tidak makin lambat)
        if any(sd == side and abs(L - lv) < 0.3 * a[s] for lv, sd, st_, en in active):
            continue
        e = min(n, s + life)
        seg_c = c[s:e]
        brk_rel = np.flatnonzero(seg_c > L) if side > 0 else np.flatnonzero(seg_c < L)
        brk = s + int(brk_rel[0]) if len(brk_rel) else e
        active.append((L, side, s, brk))
        if brk == s:
            continue
        # jarak (dalam ATR) harga close ke SNR sebelum tembus; wick untuk "menyentuh"
        i = s
        far = False
        touches = 0                                        # berapa kali level ini sudah disentuh & di-respect sebelumnya
        while i < min(brk + 1, e):
            ai = a[i]
            if not (ai == ai) or ai <= 0:
                i += 1
                continue
            d = (L - c[i]) / ai if side > 0 else (c[i] - L) / ai
            if d > 2:
                far = True
                i += 1
                continue
            if not far:                                   # harus datang dari jauh (> 2 ATR) supaya jadi satu pendekatan
                i += 1
                continue
            # mulai pendekatan
            snaps = {}
            touched = False
            outcome = None
            j = i
            while j < e:
                aj = a[j]
                if not (aj == aj) or aj <= 0:
                    j += 1
                    continue
                dj = (L - c[j]) / aj if side > 0 else (c[j] - L) / aj
                if (side > 0 and c[j] > L) or (side < 0 and c[j] < L):
                    outcome = "breakout"                  # candle tembus TIDAK dicatat (nilainya sudah berisi gerakan tembus)
                    break
                wick = (L - h[j]) / aj if side > 0 else (l[j] - L) / aj
                for name, lim in BANDS:
                    if lim is not None and dj <= lim:
                        snaps.setdefault(name, j)
                if wick <= tol:
                    touched = True
                    snaps.setdefault("sentuh", j)
                if touched and dj >= away and _holds(c, j, L, -side, n_hold):
                    outcome = "respect"                   # respect sah: N candle berikutnya tidak ada close tembus SNR
                    break
                if not touched and dj > 2:
                    outcome = "tidak sampai"
                    break
                j += 1
            if outcome is None:
                break                                     # level habis tanpa hasil: dibuang
            follow = _follow(h, l, c, j, L, side, a[j], life) if outcome == "breakout" else -1
            fake = 1 if outcome == "breakout" and not _holds(c, j, L, side, int(q["hold"])) else 0
            for name, k in snaps.items():
                if k < len(P) and P[k] == P[k]:
                    rb.append(BI[name]); rk.append(k); ro.append(OI[outcome])  # noqa: E702
                    rto.append(D[k] == side)              # resistance: dorongan beli (FI positif) = menuju SNR
                    rd.append((L - c[k]) / a[k] if side > 0 else (c[k] - L) / a[k]); rs.append(side); rl.append(L)  # noqa: E702
                    rtw.append(0 if htf_up[k] == 0 else (1 if htf_up[k] == side else -1))   # 1 tren searah dorongan menuju SNR
                    rtc.append(touches)
                    rage.append((k - s) * tf_h)
                    rspd.append(((c[k] - c10[k]) if side > 0 else (c10[k] - c[k])) / a[k] if c10[k] == c10[k] else np.nan)
                    rfol.append(follow)
                    rfk.append(fake)
            if outcome == "breakout":
                break
            if touched:
                touches += 1
            far = outcome == "tidak sampai"
            i = j + 1
    k = np.asarray(rk, np.int64)
    return {"band": np.asarray(rb, np.int8), "k": k, "toward": np.asarray(rto, bool), "out": np.asarray(ro, np.int8),
            "test": k >= split, "dist": np.asarray(rd, np.float32), "side": np.asarray(rs, np.int8), "lvl": np.asarray(rl, float),
            "pv": np.stack([PS[sm][k] for sm in smooths], 1).astype(np.float32) if len(k) else np.zeros((0, len(smooths)), np.float32),
            "time": t[k].astype(np.int64) if len(k) else np.zeros(0, np.int64), "price": c[k] if len(k) else np.zeros(0),
            "trend": np.asarray(rtw, np.int8), "touches": np.asarray(rtc, np.int16), "age_h": np.asarray(rage, np.float32),
            "speed": np.asarray(rspd, np.float32), "follow": np.asarray(rfol, np.int8), "fake": np.asarray(rfk, np.int8),
            "n": n}


def _rate_from(b, r, ns, f=0):
    """b breakout valid, r respect, ns tidak sampai, f fakeout. 'Respect' (SNR bertahan) = respect + fakeout."""
    reach = b + r + f
    n = reach + ns
    return {"n": int(n), "breakout": int(b), "respect": int(r + f), "respect_murni": int(r), "fakeout": int(f), "tidak_sampai": int(ns),
            "pct_breakout": 100 * b / reach if reach else None, "pct_respect": 100 * (r + f) / reach if reach else None,
            "pct_fakeout": 100 * f / reach if reach else None, "pct_reach": 100 * reach / n if n else None}


def _rate(xs):
    xs = list(xs)
    return _rate_from(sum(x == "breakout" for x in xs), sum(x == "respect" for x in xs), sum(x == "tidak sampai" for x in xs),
                      sum(x == "fakeout" for x in xs))


def _counts(bucket, out, mask):
    """Jumlah breakout / respect / tidak sampai / fakeout per ember Dorongan (0, 10, ... 90) -> array (10, 4)."""
    idx = (bucket[mask] // 10).astype(int) * 4 + out[mask].astype(int)
    return np.bincount(idx, minlength=40).reshape(10, 4)


def _recommend(band_mask, bucket, out, test, target, min_n):
    """Batas Dorongan % dari data cari (70%), dicek di data uji (30%).
    Limit (pullback / retest): Dorongan < X -> respect >= target. Breakout: Dorongan >= Z -> breakout >= target."""
    tr = _counts(bucket, out, band_mask & ~test)
    te = _counts(bucket, out, band_mask & test)
    out_ = {"base": _rate_from(*tr.sum(0))}                # tanpa filter Dorongan (pembanding)
    best = None
    for X in range(10, 101, 10):                          # makin besar X makin banyak sampel; cari X terbesar yang masih >= target
        s = _rate_from(*tr[: X // 10].sum(0))
        if s["breakout"] + s["respect"] >= min_n and s["pct_respect"] is not None and s["pct_respect"] >= target:
            best = (X, s)
    if best:
        X, s = best
        out_["limit"] = {"max": X, "train": s, "test": _rate_from(*te[: X // 10].sum(0))}
    best = None
    for Z in range(90, -1, -10):                           # makin kecil Z makin banyak sampel; cari Z terkecil yang masih >= target
        s = _rate_from(*tr[Z // 10:].sum(0))
        if s["breakout"] + s["respect"] >= min_n and s["pct_breakout"] is not None and s["pct_breakout"] >= target:
            best = (Z, s)
    if best:
        Z, s = best
        out_["breakout"] = {"min": Z, "train": s, "test": _rate_from(*te[Z // 10:].sum(0))}
    return out_


def _params(p):
    q = dict(DEFAULTS, **{k: v for k, v in (p or {}).items() if k in DEFAULTS})
    if q["tf"] not in TF_MS or q["snr_tf"] not in TF_MS:
        raise ValueError("TF tidak dikenal")
    if TF_MS[q["snr_tf"]] < TF_MS[q["tf"]]:
        raise ValueError("TF SNR tidak boleh lebih kecil dari TF entry")
    q["swing"] = int(min(max(int(q["swing"]), 1), 20))
    q["life"] = int(min(max(int(q["life"]), 50), 20000))
    q["touch"] = float(min(max(float(q["touch"]), 0.0), 2.0))
    q["away"] = float(min(max(float(q["away"]), 0.2), 10.0))
    q["target"] = float(min(max(float(q["target"]), 50.0), 95.0))
    q["min_n"] = int(min(max(int(q["min_n"]), 5), 100000))
    # bertahan dalam JAM (sama untuk semua TF) -> jumlah candle TF entry; "hold" (candle) hanya untuk cara lama
    if (p or {}).get("hold") not in (None, "") and (p or {}).get("hold_h") in (None, ""):
        q["hold"] = int(min(max(int(float(p["hold"])), 1), 500))
        q["hold_h"] = round(q["hold"] * TF_MS[q["tf"]] / 3_600_000, 3)
    else:
        q["hold_h"] = float(min(max(float(q["hold_h"] if q["hold_h"] not in (None, "") else 1.0), 0.05), 168.0))
        q["hold"] = int(min(max(round(q["hold_h"] * 3_600_000 / TF_MS[q["tf"]]), 1), 5000))
    for k, lo, hi in (("adx_len", 2, 100), ("fi_len", 1, 200), ("vol_len", 2, 500), ("smooth", 1, 200)):
        q[k] = int(min(max(int(q[k]), lo), hi))
    q["toward"] = bool(q["toward"])
    q["auto_smooth"] = bool(q["auto_smooth"])
    q["ind"] = q.get("ind") if q.get("ind") in INDS else "dorongan"
    if q["ind"] != "dorongan":
        q["toward"] = False                                # ADX tanpa arah; ADX + FI dipisah menurut arah FI (dua-duanya)
    q["read_band"] = str(q.get("read_band") or "1.5")
    if q["read_band"] not in [b for b, _ in BANDS if b != "sentuh"]:
        q["read_band"] = "1.5"
    return q


def _auc(scores, labels):
    """Seberapa baik Dorongan % membedakan breakout (1) dari respect (0): 50 = tebak koin, 100 = sempurna (dalam %)."""
    x = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    n1, n0 = int(y.sum()), int((~y).sum())
    if not n1 or not n0:
        return None
    u, inv, cnt = np.unique(x, return_inverse=True, return_counts=True)
    first = np.concatenate([[0], np.cumsum(cnt)[:-1]])
    rank = (first + (cnt - 1) / 2 + 1)[inv]                # peringkat rata-rata untuk nilai yang sama
    return float(100 * (rank[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def _midline(values, is_breakout, is_test):
    """Garis tengah: batas Dorongan % yang paling memisahkan breakout (di atas) dari respect (di bawah), dicari di data
    CARI lalu dicek di data UJI. Pemisahan = % breakout yang di atas garis − % respect yang di atas garis."""
    v, b, te = (np.asarray(x) for x in (values, is_breakout, is_test))
    v, b, te = v.astype(float), b.astype(bool), te.astype(bool)

    def sep(sel, t):
        bb, rr = v[sel & b], v[sel & ~b]
        if not len(bb) or not len(rr):
            return None
        return float(100 * ((bb >= t).mean() - (rr >= t).mean()))
    best = None
    for t in range(10, 95, 5):
        s_ = sep(~te, t)
        if s_ is not None and (best is None or s_ > best[1]):
            best = (t, s_)
    if best is None:
        return None
    t, s_ = best
    hi, lo = te & (v >= t), te & (v < t)
    st = sep(te, t)
    return {"line": t, "sep_train": round(s_, 1), "sep_test": None if st is None else round(st, 1),
            "test_breakout_above": round(100 * float(b[hi].mean()), 1) if hi.any() else None,
            "test_respect_below": round(100 * float((~b[lo]).mean()), 1) if lo.any() else None,
            "n_above": int(hi.sum()), "n_below": int(lo.sum())}


FACTORS = {
    "trend": ("Tren TF besar (EMA 50/200 TF SNR)", [("searah", "searah dorongan menuju SNR"), ("lawan", "berlawanan"), ("na", "belum cukup data")]),
    "touches": ("Sentuhan sebelumnya", [("0", "level baru (0×)"), ("1", "sudah 1×"), ("2+", "2× atau lebih")]),
    "age": ("Umur level", [("<1h", "< 1 hari"), ("1-3h", "1–3 hari"), ("3-7h", "3–7 hari"), (">7h", "> 7 hari")]),
    "speed": ("Kecepatan datang (10 candle)", [("pelan", "pelan (< 1 ATR)"), ("sedang", "sedang (1–3 ATR)"), ("cepat", "cepat (≥ 3 ATR)")]),
}


def _cats(A):
    """Kategori faktor tiap kejadian -> dict nama faktor: array kode kategori (index ke FACTORS[...][1])."""
    tr = np.where(A["trend"] == 1, 0, np.where(A["trend"] == -1, 1, 2))
    tc = np.minimum(A["touches"].astype(int), 2)
    ag = A["age_h"].astype(float)
    age = np.where(ag < 24, 0, np.where(ag < 72, 1, np.where(ag < 168, 2, 3)))
    sp = np.nan_to_num(A["speed"].astype(float), nan=0.0)
    spd = np.where(sp < 1, 0, np.where(sp < 3, 1, 2))
    return {"trend": tr, "touches": tc, "age": age, "speed": spd}


def _fstats(sel, out, follow, test):
    """Ringkasan sekelompok kejadian: respect / breakout (dari yang sampai SNR) & breakout yang lanjut vs fakeout."""
    def one(m):
        b = int((m & (out == 0)).sum())
        r = int((m & ((out == 1) | (out == 3))).sum())
        fl = int((m & ((out == 0) | (out == 3)) & (follow == 1)).sum())
        fk = int((m & ((out == 0) | (out == 3)) & (follow == 0)).sum())
        fo = int((m & (out == 3)).sum())
        return {"n": b + r, "respect": r, "breakout": b, "fakeout": fo, "pct_respect": 100 * r / (b + r) if b + r else None,
                "pct_breakout": 100 * b / (b + r) if b + r else None, "pct_fakeout": 100 * fo / (b + r) if b + r else None,
                "lanjut": fl, "gagal": fk,
                "pct_lanjut": 100 * fl / (fl + fk) if fl + fk else None}
    return {"train": one(sel & ~test), "test": one(sel & test)}


def _factors(A, q):
    """Faktor yang mempengaruhi SNR, dibaca di 1 ATR sebelum SNR (satu pembacaan per pendekatan)."""
    if not len(A["band"]):
        return None
    base = (A["band"] == BANDS.index(("1", 1.0))) & (A["out"] != 2)
    out, fol, te = A["out"], A["follow"], A["test"]
    cats = _cats(A)
    res = {"overall": _fstats(base, out, fol, te), "factors": [], "best_limit": [], "best_breakout": []}
    for key, (title, labels) in FACTORS.items():
        rows = []
        for ci, (code, lab) in enumerate(labels):
            st = _fstats(base & (cats[key] == ci), out, fol, te)
            if st["train"]["n"] + st["test"]["n"]:
                rows.append({"code": code, "label": lab, **st})
        res["factors"].append({"key": key, "title": title, "rows": rows})
    # kombinasi 2 faktor: dipilih dari data CARI (min. kejadian), dibuktikan di data UJI
    keys = list(FACTORS)
    cand = []
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            ki, kj = keys[i], keys[j]
            for ci, (code_i, li) in enumerate(FACTORS[ki][1]):
                for cj, (code_j, lj) in enumerate(FACTORS[kj][1]):
                    if "na" in (code_i, code_j):         # "belum cukup data" bukan kondisi pasar
                        continue
                    st = _fstats(base & (cats[ki] == ci) & (cats[kj] == cj), out, fol, te)
                    if st["train"]["n"] >= q["min_n"]:
                        cand.append({"label": f"{FACTORS[ki][0]}: {li} + {FACTORS[kj][0]}: {lj}", **st})
    lim = [c for c in cand if c["train"]["pct_respect"] is not None]
    res["best_limit"] = sorted(lim, key=lambda c: -c["train"]["pct_respect"])[:5]
    brk = [c for c in cand if c["train"]["pct_lanjut"] is not None and c["train"]["lanjut"] + c["train"]["gagal"] >= q["min_n"]]
    # breakout yang benar-benar menguntungkan = tembus DAN lanjut: peluang = % breakout x % lanjut
    for c in brk:
        for part in ("train", "test"):
            x = c[part]
            x["pct_breakout_lanjut"] = (x["pct_breakout"] or 0) * (x["pct_lanjut"] or 0) / 100 if x["pct_lanjut"] is not None else None
    res["best_breakout"] = sorted(brk, key=lambda c: -c["train"]["pct_breakout_lanjut"])[:5]
    return res


def _summary(A, bucket, q):
    rb = str(q.get("read_band") or "1")
    names = [b for b, _ in BANDS]
    """Ringkasan simpel (dibaca 1 ATR sebelum SNR): rentang Dorongan % untuk entry limit (respect di atas rata-rata) dan
    untuk entry breakout (breakout di atas rata-rata). Rentang dicari di data CARI, dicek di data UJI."""
    m0 = (A["band"] == names.index(rb if rb in names else "1")) & (A["out"] != 2)
    if not m0.any():
        return None
    out, fol, te = A["out"], A["follow"], A["test"]

    def rate(m):
        b, r = int((m & (out == 0)).sum()), int((m & ((out == 1) | (out == 3))).sum())
        fl, fk = int((m & ((out == 0) | (out == 3)) & (fol == 1)).sum()), int((m & ((out == 0) | (out == 3)) & (fol == 0)).sum())
        return {"n": b + r, "pct_respect": 100 * r / (b + r) if b + r else None, "pct_breakout": 100 * b / (b + r) if b + r else None,
                "pct_lanjut": 100 * fl / (fl + fk) if fl + fk else None}
    base = rate(m0 & ~te)
    per = [rate(m0 & ~te & (bucket == bk)) for bk in BUCKETS]

    def zone(key):
        good = [i for i, x in enumerate(per) if x["n"] >= max(10, q["min_n"] // 5) and x[key] is not None and x[key] >= base[key] + 3]
        if not good:
            return None
        runs, cur = [], [good[0]]                          # rentang bersambung dengan kejadian terbanyak
        for i in good[1:]:
            if i == cur[-1] + 1:
                cur.append(i)
            else:
                runs.append(cur)
                cur = [i]
        runs.append(cur)
        best = max(runs, key=lambda r: sum(per[i]["n"] for i in r))
        lo, hi = BUCKETS[best[0]], BUCKETS[best[-1]] + 10
        mz = m0 & (bucket >= lo) & (bucket < hi)
        return {"from": lo, "to": hi, "train": rate(mz & ~te), "test": rate(mz & te)}
    return {"base": base, "base_test": rate(m0 & te), "limit": zone("pct_respect"), "breakout": zone("pct_breakout"), "band": rb}


def load_defaults():
    try:
        with open(DEF_FILE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_default(tf, info):
    with _def_lock:
        d = load_defaults()
        d[tf] = info
        os.makedirs(os.path.dirname(DEF_FILE), exist_ok=True)
        tmp = DEF_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=1)
        os.replace(tmp, DEF_FILE)


_WS = {}


def _init_worker(data_dir):
    from .data import DataStore
    _WS["store"] = DataStore(data_dir, cache_size=4)


FIELDS = ("band", "out", "test", "dist", "side", "lvl", "pv", "time", "price", "trend", "touches", "age_h", "speed", "follow", "fake", "tw")


def _one(sym, q, smooths, store=None):
    """Satu koin -> potongan hasil (sudah difilter arah dorongan) atau pesan kenapa dilewati."""
    try:
        r = study_coin(store or _WS["store"], sym, q, smooths)
    except Exception as ex:                                     # noqa: BLE001 - koin bermasalah dilewati
        return f"{type(ex).__name__}: {ex}"
    if isinstance(r, str):
        return r
    r["tw"] = r["toward"]
    m = r["toward"] if q["toward"] else np.ones(len(r["k"]), bool)
    return {k_: r[k_][m] for k_ in FIELDS}


def job_total(q, symbols):
    return len(symbols)


def job_state(q, symbols):
    if q.get("ind", "dorongan") != "dorongan":
        sm = list(ADX_LENS) if q["auto_smooth"] else [int(q["adx_len"])]
    else:
        sm = list(SMOOTHS) if q["auto_smooth"] else [int(q["smooth"])]
    return {"parts": [], "used": [], "skipped": [], "smooths": sm, "t0": time.time()}


def job_call(state, q, symbols, i):
    return _one, (symbols[i], q, state["smooths"])


def job_merge(state, q, symbols, i, res):
    sym = symbols[i]
    if isinstance(res, str):
        state["skipped"].append(f"{sym}: {res}")
        return
    state["used"].append(sym)
    if len(res["band"]):
        state["parts"].append(res | {"sym": np.full(len(res["band"]), len(state["used"]) - 1, np.int32)})


def run(store, symbols, p, progress=None):
    """Versi langsung (tanpa jeda) — dipakai tes. Menu memakai StudyJobs (paralel, bisa dijeda, hasil disimpan)."""
    q = _params(p)
    state = job_state(q, symbols)
    workers = int(p.get("workers") or max(1, min((os.cpu_count() or 2) - 1, 8)))
    results = {}
    if workers > 1 and len(symbols) > 1 and getattr(store, "data_dir", None):
        from concurrent.futures import ProcessPoolExecutor, as_completed
        try:
            with ProcessPoolExecutor(workers, initializer=_init_worker, initargs=(store.data_dir,)) as pool:
                futs = {pool.submit(_one, sym, q, state["smooths"]): i for i, sym in enumerate(symbols)}
                for f in as_completed(futs):
                    results[futs[f]] = f.result()
                    if progress:
                        progress(len(results), len(symbols), f"{symbols[futs[f]]}|selesai", None)
        except Exception:                                       # noqa: BLE001 - proses paralel gagal: lanjut satu per satu
            results = {}
    for i, sym in enumerate(symbols):
        if i not in results:
            results[i] = _one(sym, q, state["smooths"], store)
            if progress:
                progress(i + 1, len(symbols), f"{sym}|selesai", None)
    for i in range(len(symbols)):                               # digabung URUT -> hasil sama dengan satu per satu
        job_merge(state, q, symbols, i, results[i])
    return job_finalize(state, q, symbols)


def job_finalize(state, q, symbols, partial=False):
    """Susun hasil dari semua koin (tabel, batas Dorongan %, penghalusan terbaik, garis tengah)."""
    t0 = state.get("t0", time.time())
    smooths, parts, used, skipped = state["smooths"], state["parts"], state["used"], state["skipped"]
    keys = FIELDS + ("sym",)
    A = {k_: np.concatenate([x[k_] for x in parts]) for k_ in keys} if parts else \
        {"band": np.zeros(0, np.int8), "out": np.zeros(0, np.int8), "test": np.zeros(0, bool), "dist": np.zeros(0),
         "side": np.zeros(0, np.int8), "lvl": np.zeros(0), "pv": np.zeros((0, len(smooths))), "time": np.zeros(0, np.int64),
         "price": np.zeros(0), "sym": np.zeros(0, np.int32), "trend": np.zeros(0, np.int8), "touches": np.zeros(0, np.int16),
         "age_h": np.zeros(0, np.float32), "speed": np.zeros(0, np.float32), "follow": np.zeros(0, np.int8), "fake": np.zeros(0, np.int8), "tw": np.zeros(0, bool)}
    # hasil: 0 breakout VALID (bertahan di luar SNR), 1 respect, 2 tidak sampai, 3 fakeout (tembus lalu balik = SNR bertahan)
    A["out"] = np.where((A["out"] == 0) & (A["fake"] == 1), 3, A["out"]).astype(np.int8)
    if q.get("ind") == "adxfi":
        # ADX + Force Index: dihitung terpisah — FI MENUJU SNR (mis. FI positif mendekati resistance) vs FI MELAWAN
        parts_ = {}
        for key, m in (("menuju", A["tw"]), ("melawan", ~A["tw"])):
            parts_[key] = _build({k_: v_[m] for k_, v_ in A.items()}, q, smooths, used, skipped, t0, save=False)
        out = dict(parts_["menuju"])
        out.update({"fi_split": True, "split": parts_, "n_events": int(len(A["band"]))})
        return out
    return _build(A, q, smooths, used, skipped, t0, save=q.get("ind", "dorongan") == "dorongan")


def _build(A, q, smooths, used, skipped, t0, save=True):
    n_ev = len(A["band"])
    pre = A["band"] != BANDS.index(("sentuh", None))           # dibaca sebelum menyentuh
    reach = A["out"] != 2
    compare = []
    for j, sm in enumerate(smooths):
        v = A["pv"][:, j]
        sel_tr, sel_te = pre & reach & ~A["test"], pre & reach & A["test"]
        compare.append({"smooth": sm, "auc_train": _auc(v[sel_tr], A["out"][sel_tr] == 0), "n_train": int(sel_tr.sum()),
                        "auc_test": _auc(v[sel_te], A["out"][sel_te] == 0), "n_test": int(sel_te.sum())})
    # DIPILIH dari data cari (70% awal), lalu DIBUKTIKAN di data uji (30% terakhir) — memilih dari data uji = curang
    ok = [x for x in compare if x["auc_train"] is not None and x["n_train"] >= q["min_n"]]
    best = max(ok, key=lambda x: (round(x["auc_train"], 1), -abs(x["smooth"] - 10))) if ok else compare[0]
    sm = best["smooth"]
    j = smooths.index(sm)
    v = A["pv"][:, j].astype(float)
    bucket = np.minimum(np.floor(np.nan_to_num(v) / 10) * 10, 90).astype(int)
    saved = None
    if q["auto_smooth"] and save:
        if best["auc_test"] is not None and best["auc_test"] >= MIN_AUC and best["n_test"] >= q["min_n"]:
            saved = {"smooth": sm, "auc_test": round(float(best["auc_test"]), 1), "n_test": best["n_test"], "snr_tf": q["snr_tf"],
                     "symbols": len(used), "time": int(time.time() * 1000)}
            save_default(q["tf"], saved)
    sel = pre & reach
    mid = _midline(v[sel], A["out"][sel] == 0, A["test"][sel]) if sel.any() else None
    if save and saved is not None and mid is not None and (mid["sep_test"] or 0) > 0:
        saved["line"] = mid["line"]                      # garis tengah ikut jadi default kalau di data uji tetap memisahkan
        save_default(q["tf"], saved)
    table, rec = {}, {}
    for bi, (name, _) in enumerate(BANDS):
        bm = A["band"] == bi
        cnt = _counts(bucket, A["out"], bm)
        table[name] = [dict(_rate_from(*cnt[i]), bucket=i * 10) for i in range(10)]
        rec[name] = _recommend(bm, bucket, A["out"], A["test"], q["target"], q["min_n"])
    sel_ex = np.flatnonzero(A["band"] == BANDS.index(("sentuh", None)))[-300:]
    oname = {0: "breakout", 1: "respect", 2: "tidak sampai", 3: "fakeout"}
    examples = [{"symbol": used[int(A["sym"][i])], "time": int(A["time"][i]), "price": float(A["price"][i]), "snr": float(A["lvl"][i]),
                 "side": "resistance" if A["side"][i] > 0 else "support", "dorongan": int(bucket[i]), "outcome": oname[int(A["out"][i])],
                 "dist_atr": round(float(A["dist"][i]), 2)} for i in sel_ex]
    return {"table": table, "rec": rec, "bands": [b for b, _ in BANDS], "n_events": n_ev, "smooth": sm, "midline": mid,
            "factors": _factors(A, q), "summary": _summary(A, bucket, q),
            "compare": compare, "saved_default": saved, "min_auc": MIN_AUC,
            "symbols": used, "skipped": skipped[:20], "n_skipped": len(skipped), "examples": examples,
            "params": q, "elapsed": round(time.time() - t0, 1)}
