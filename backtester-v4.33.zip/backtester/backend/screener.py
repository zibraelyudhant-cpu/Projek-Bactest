"""Screener live Binance USDT-M Futures (data dari API publik Binance, tanpa API key).

Scan pertama mengambil ~500 candle per koin; scan berikutnya hanya candle terbaru (cache di memori).
"""
import json
import math
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from . import indicators as ind

BASE_URL = os.environ.get("BINANCE_FAPI_URL", "https://fapi.binance.com")
INTERVAL_MS = {"1m": 60_000, "3m": 180_000, "5m": 300_000, "15m": 900_000, "30m": 1_800_000, "1h": 3_600_000,
               "2h": 7_200_000, "4h": 14_400_000, "6h": 21_600_000, "8h": 28_800_000, "12h": 43_200_000,
               "1d": 86_400_000, "3d": 259_200_000, "1w": 604_800_000}
BARS = 499          # candle per koin untuk scan pertama (cukup untuk EMA 200). <500 = weight 2 di Binance
WORKERS = 8


VPN_HINT = "Binance sering memblokir IP / provider tertentu: nyalakan VPN (atau ganti DNS ke 1.1.1.1), lalu coba lagi."


class BinanceError(RuntimeError):
    pass


LONG_BAN_S = 120     # blokir Binance lebih lama dari ini: jangan ditunggu diam-diam, langsung lapor (menunggu memperpanjang blokir)


def _log(msg):
    print(time.strftime("%H:%M:%S"), "[Binance]", msg, flush=True)        # tampil di jendela server (run.bat)


class Client:
    def __init__(self, base=BASE_URL):
        self.base = base.rstrip("/")
        self.weight = 0
        self.lock = threading.Lock()
        # status untuk ditampilkan di aplikasi: ok / menunggu batas / diblokir / koneksi gagal
        self.state = {"code": "ok", "text": "", "until": 0.0, "since": 0.0, "calls": 0, "errors": 0, "last_ok": 0.0}
        self.pause_until = 0.0                     # semua thread berhenti sampai waktu ini (setelah 429/418)
        self.ban_until = 0.0                       # blokir panjang: permintaan langsung ditolak tanpa ke Binance

    def _set(self, code, text, until=0.0):
        with self.lock:
            self.state.update(code=code, text=text, until=until, since=time.time())

    def status(self):
        with self.lock:
            st = dict(self.state)
        st["weight"] = self.weight
        st["wait_s"] = max(0.0, st["until"] - time.time()) if st["until"] else 0.0
        if st["code"] != "ok" and st["until"] and st["wait_s"] <= 0 and st["code"] != "koneksi":
            st["code"], st["text"] = "ok", ""
        return st

    def _sleep_until(self, t, code, text):
        left = t - time.time()
        if left > 0:
            self._set(code, text, t)
            time.sleep(left)

    def get(self, path, **params):
        now = time.time()
        if self.ban_until > now:
            raise BinanceError(f"Binance memblokir IP kamu sementara (HTTP 418) karena terlalu banyak permintaan — coba lagi sekitar "
                               f"{time.strftime('%H:%M', time.localtime(self.ban_until))} (±{(self.ban_until - now) / 60:.0f} menit lagi). "
                               "Jangan jalankan banyak scan besar bersamaan.")
        if self.pause_until > now:                               # thread lain baru kena batas: ikut menunggu, jangan menambah permintaan
            self._sleep_until(self.pause_until, "batas", "menunggu batas permintaan Binance")
        url = f"{self.base}{path}" + ("?" + urllib.parse.urlencode(params) if params else "")
        for attempt in range(4):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "futures-replay-screener"})
                with urllib.request.urlopen(req, timeout=20) as r:
                    w = r.headers.get("X-MBX-USED-WEIGHT-1M")
                    with self.lock:
                        self.state["calls"] += 1
                        self.state["last_ok"] = time.time()
                        if self.state["code"] == "koneksi":
                            self.state.update(code="ok", text="", until=0.0)
                    if w and w.isdigit():
                        with self.lock:
                            self.weight = int(w)
                        if int(w) > 2000:            # batas Binance 2400/menit: tunggu menit berikutnya
                            t = time.time() + (61 - time.gmtime().tm_sec)
                            self.pause_until = max(self.pause_until, t)
                            _log(f"jatah permintaan per menit hampir habis ({w}/2400) — menunggu {t - time.time():.0f} dtk")
                            self._sleep_until(t, "batas", f"jatah permintaan Binance per menit hampir habis ({w}/2400)")
                    return json.loads(r.read())
            except urllib.error.HTTPError as e:
                if e.code in (418, 429):              # 429 = kena batas, 418 = IP diblokir sementara
                    ra = int(e.headers.get("Retry-After") or ("120" if e.code == 418 else "10"))
                    with self.lock:
                        self.state["errors"] += 1
                    if e.code == 418 or ra > LONG_BAN_S:
                        self.ban_until = time.time() + ra
                        _log(f"HTTP {e.code}: IP diblokir Binance {ra} dtk (sampai {time.strftime('%H:%M', time.localtime(self.ban_until))}) — scan dihentikan, coba lagi nanti")
                        self._set("blokir", f"IP diblokir Binance sementara (HTTP {e.code}) sampai {time.strftime('%H:%M', time.localtime(self.ban_until))}", self.ban_until)
                        raise BinanceError(f"Binance memblokir IP kamu sementara (HTTP {e.code}) selama ±{ra / 60:.0f} menit karena terlalu banyak "
                                           f"permintaan. Coba lagi sekitar {time.strftime('%H:%M', time.localtime(self.ban_until))}; jangan jalankan banyak scan "
                                           "besar bersamaan.") from e
                    self.pause_until = max(self.pause_until, time.time() + ra)
                    _log(f"HTTP 429: kena batas permintaan — semua scan menunggu {ra} dtk")
                    self._sleep_until(self.pause_until, "batas", f"kena batas permintaan Binance (HTTP 429), menunggu {ra} dtk")
                    continue
                if e.code in (451, 403):
                    raise BinanceError(f"Binance menolak akses dari jaringan ini (HTTP {e.code}). {VPN_HINT}") from e
                raise BinanceError(f"HTTP {e.code} dari Binance untuk {path}") from e
            except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
                with self.lock:
                    self.state["errors"] += 1
                _log(f"koneksi ke Binance gagal ({getattr(e, 'reason', e)}) — percobaan {attempt + 1}/4")
                self._set("koneksi", f"koneksi ke Binance gagal / lambat ({getattr(e, 'reason', e)}), mencoba ulang {attempt + 1}/4")
                if attempt == 3:
                    raise BinanceError(f"Tidak bisa terhubung ke {self.base} ({getattr(e, 'reason', e)}). {VPN_HINT}") from e
                time.sleep(1 + attempt)
        raise BinanceError(f"Gagal mengambil {path}")


class Screener:
    def __init__(self, client=None):
        self.c = client or Client()
        self.cache = {}            # (symbol, interval) -> array [open_time, o, h, l, c, v, close_time]
        self.lock = threading.Lock()
        self._symbols = (0.0, [])

    # ---------------------------------------------------------------- data
    def symbols(self):
        ts, syms = self._symbols
        if time.time() - ts > 600 or not syms:
            info = self.c.get("/fapi/v1/exchangeInfo")
            syms = sorted(s["symbol"] for s in info["symbols"] if s.get("contractType") == "PERPETUAL"
                          and s.get("quoteAsset") == "USDT" and s.get("status") == "TRADING")
            self._symbols = (time.time(), syms)
        return syms

    def tickers(self):
        out = {}
        for t in self.c.get("/fapi/v1/ticker/24hr"):
            out[t["symbol"]] = {"chg_24h": float(t["priceChangePercent"]), "vol_24h": float(t["quoteVolume"]),
                                "last": float(t["lastPrice"])}
        return out

    def klines(self, sym, interval, now_ms, bars=BARS):
        key = (sym, interval)
        with self.lock:
            old = self.cache.get(key)
        if old is not None and len(old):
            missing = int((now_ms - old[-1, 0]) // INTERVAL_MS[interval]) + 2
            limit = min(max(missing, 2), 1500)
        else:
            limit = bars
        rows = self.c.get("/fapi/v1/klines", symbol=sym, interval=interval, limit=limit)
        new = np.array([[float(r[0]), *map(float, r[1:6]), float(r[6])] for r in rows]) if rows else np.zeros((0, 7))
        if old is not None and len(old) and len(new):
            a = np.concatenate([old[old[:, 0] < new[0, 0]], new])[-bars - 50:]   # candle terakhir diganti versi terbaru
        else:
            a = new
        with self.lock:
            self.cache[key] = a
        return a

    # ---------------------------------------------------------------- scan
    def scan(self, interval, filters, columns=(), closed_only=False, structure=None, limit=None, progress=None):
        """structure = {"codes": ["HH", "HL", ...] (3-6, lama -> baru), "bars": 200, "swing": 3} -> hanya koin yang
        urutan swing terakhirnya (di `bars` candle terakhir) sama dengan codes."""
        if interval not in INTERVAL_MS:
            raise ValueError(f"TF {interval} tidak didukung")
        ms = None
        if structure and structure.get("codes"):
            codes = [str(c).upper() for c in structure["codes"]]
            if not 3 <= len(codes) <= 6 or any(c not in MS_CODES for c in codes):
                raise ValueError("kode market structure harus 3-6 baris berisi HH / HL / LH / LL / ANY")
            ms = {"codes": codes, "bars": max(20, min(int(structure.get("bars") or 200), 1500)),
                  "swing": max(1, min(int(structure.get("swing") or 3), 20)),
                  "min_atr": max(0.0, min(float(structure.get("min_atr") or 0.0), 20.0)),
                  "live": bool(structure.get("live", True))}
        nbars = max(BARS, ms["bars"] + 2) if ms else BARS
        t0 = time.time()
        syms = self.symbols()
        tick = self.tickers()
        if limit:                                   # hanya N koin dengan volume 24 jam terbesar (lebih cepat)
            syms = sorted(syms, key=lambda s_: -tick.get(s_, {}).get("vol_24h", 0.0))[:max(1, int(limit))]
        now = int(time.time() * 1000)
        specs = [f["a"] for f in filters] + [f["b"] for f in filters if "f" in f.get("b", {})] + list(columns)
        need_daily = any(s["f"] in ("chg_7d", "chg_30d") for s in specs) and interval != "1d"

        def load(sym):
            try:
                a = self.klines(sym, interval, now, nbars)
                d = self.klines(sym, "1d", now, 60) if need_daily else None
                return sym, a, d, None
            except BinanceError as e:
                return sym, None, None, str(e)

        loaded = []
        with ThreadPoolExecutor(WORKERS) as pool:
            futs = [pool.submit(load, s_) for s_ in syms]
            for k, f in enumerate(futs, 1):
                loaded.append(f.result())
                if progress:
                    progress(k, len(syms), loaded[-1][0], loaded[-1][3])
        errors = [e for _, a, _, e in loaded if e]
        if errors and len(errors) == len(syms):
            raise BinanceError(errors[0])

        rows = []
        for sym, a, d, err in loaded:
            if err or a is None or len(a) < 3:
                continue
            if closed_only:
                a = a[a[:, 6] < now]
                d = d[d[:, 6] < now] if d is not None else None
            extra = {}
            if ms:
                seg = a[-ms["bars"]:]
                labs = ms_labels(seg[:, 2], seg[:, 3], ms["swing"], seg[:, 4], ms["min_atr"], ms["live"])
                if not ms_match(labs, ms["codes"]):
                    continue
                n_ = len(ms["codes"])
                extra = {"structure": "-".join(x[2] + ("*" if x[4] else "") for x in labs[-n_:]),
                         "ms_age": float(len(seg) - 1 - labs[-1][0])}
            ctx = Row(sym, a, d if d is not None else (a if interval == "1d" else None), tick.get(sym, {}))
            if all(ctx.check(f) for f in filters):
                vals = {spec_key(s): ctx.value(s) for s in specs}
                row = {"symbol": sym, "values": {k: (None if v is None or not math.isfinite(v) else v)
                                                 for k, v in vals.items()}}
                if extra:
                    row["structure"] = extra["structure"]
                    row["values"]["ms_age"] = extra["ms_age"]
                rows.append(row)
        return {"rows": rows, "scanned": len(syms) - len(errors), "errors": len(errors), "interval": interval,
                "closed_only": closed_only, "time": now, "structure": ms, "elapsed": round(time.time() - t0, 2),
                "weight": self.c.weight, "columns": list(dict.fromkeys(spec_key(s) for s in specs))}


# ---------------------------------------------------------------------------- market structure
MS_CODES = ("HH", "HL", "LH", "LL", "ANY")   # ANY = bebas (apa saja)


def ms_labels(h, l, swing=3, c=None, min_atr=0.0, live=False):
    """Urutan swing (lama -> baru): tiap swing high diberi HH (lebih tinggi dari swing high sebelumnya) / LH, tiap
    swing low HL (lebih tinggi dari swing low sebelumnya) / LL.
    - Swing = pivot fractal (swing candle kiri & kanan) yang SUDAH terkonfirmasi.
    - Swing high & low dibuat selang-seling (dua high berturut-turut: dipakai yang tertinggi; low: yang terendah).
    - min_atr > 0: swing yang jaraknya dari swing sebelumnya < min_atr x ATR14 diabaikan (buang struktur mikro).
    - live = True: gerakan yang sedang berjalan (belum ada `swing` candle di kanannya) ikut dihitung sebagai swing
      sementara (label diberi '*'), supaya struktur yang sudah patah langsung terlihat.
    Hasil: list (indeks candle, 'H'/'L', label, harga, sementara?)."""
    h, l = np.asarray(h, float), np.asarray(l, float)
    n, sw = len(h), int(swing)
    hi, lo = ind.pivots(h, l, sw)
    ev = [(int(i), "H", float(h[i]), False) for i in hi] + [(int(i), "L", float(l[i]), False) for i in lo]
    if live and n > sw:
        for i in range(max(sw, n - sw), n):                  # pivot sementara: kanan belum lengkap
            if h[i] >= h[i - sw:n].max():
                ev.append((i, "H", float(h[i]), True))
            if l[i] <= l[i - sw:n].min():
                ev.append((i, "L", float(l[i]), True))
    ev.sort(key=lambda e: (e[0], e[1]))
    a_ = ind.atr(h, l, np.asarray(c, float) if c is not None else (h + l) / 2, 14) if min_atr > 0 else None
    clean = []
    for e in ev:
        if clean and clean[-1][1] == e[1]:
            if (e[1] == "H" and e[2] > clean[-1][2]) or (e[1] == "L" and e[2] < clean[-1][2]):
                clean[-1] = e
            continue
        if clean and a_ is not None:
            thr = min_atr * (a_[e[0]] if np.isfinite(a_[e[0]]) else 0.0)
            if abs(e[2] - clean[-1][2]) < thr:
                continue                                      # swing terlalu kecil
        clean.append(e)
    out, last = [], {"H": None, "L": None}
    for i, t, px, tmp in clean:
        prev = last[t]
        if prev is not None:
            lab = ("HH" if px > prev else "LH") if t == "H" else ("HL" if px > prev else "LL")
            out.append((i, t, lab, px, tmp))
        last[t] = px
    return out


def ms_match(labels, codes):
    """codes = urutan kode (lama -> baru), 'ANY' = bebas. Cocok kalau swing-swing TERAKHIR sama persis urutannya."""
    n = len(codes)
    if n == 0 or len(labels) < n:
        return False
    tail = [x[2] for x in labels[-n:]]
    return all(c == "ANY" or c == t for c, t in zip(codes, tail))


# ---------------------------------------------------------------------------- indikator
def _pct(a, b):
    return 100 * (a / b - 1)


def _series(f, n, o, h, l, c, v):
    """Seri indikator `f` dengan periode `n` (array sepanjang data)."""
    if f == "close":
        return c
    if f == "chg":
        return np.r_[np.nan, _pct(c[1:], c[:-1])]
    if f == "vol":
        return v * c                                   # volume candle dalam USDT
    if f == "ema":
        return ind.ema(c, n)
    if f == "sma":
        return ind.sma(c, n)
    if f == "dist_ema":
        return _pct(c, ind.ema(c, n))
    if f in ("adx", "pdi", "ndi"):
        p, m, a = ind.dmi(h, l, c, n)
        return {"adx": a, "pdi": p, "ndi": m}[f]
    if f in ("macd", "macd_signal", "macd_hist"):
        return dict(zip(("macd", "macd_signal", "macd_hist"), ind.macd(c)))[f]
    if f == "rsi":
        return ind.rsi(c, n)
    if f == "force_index":
        return ind.force_index(c, v, n)
    if f in ("stoch_k", "stoch_d"):
        k, d = ind.stoch(h, l, c, n)
        return k if f == "stoch_k" else d
    if f == "cci":
        return ind.cci(h, l, c, n)
    if f == "willr":
        return ind.willr(h, l, c, n)
    if f == "roc":
        return ind.roc(c, n)
    if f == "mfi":
        return ind.mfi(h, l, c, v, n)
    if f == "atr_pct":
        return 100 * ind.atr(h, l, c, n) / c
    if f in ("bb_pctb", "bb_width"):
        lo, mid, up = ind.bollinger(c, n)
        with np.errstate(invalid="ignore", divide="ignore"):
            return (c - lo) / (up - lo) if f == "bb_pctb" else 100 * (up - lo) / mid
    if f == "vol_ratio":
        vv = v * c
        return np.r_[np.nan, vv[1:] / ind.sma(vv, n)[:-1]]   # volume candle / rata-rata n candle sebelumnya
    if f == "supertrend":
        return ind.supertrend(h, l, c, n, 3.0)
    if f == "high_break":
        prev = np.r_[np.nan, ind.rolling(h, n, np.max)[:-1]]
        return np.where(np.isnan(prev), np.nan, (c > prev).astype(float))
    if f == "low_break":
        prev = np.r_[np.nan, ind.rolling(l, n, np.min)[:-1]]
        return np.where(np.isnan(prev), np.nan, (c < prev).astype(float))
    if f == "structure":
        out = np.full(len(c), np.nan)
        out[-1] = ind.bos_bias(h, l, c, n)
        return out
    raise ValueError(f"indikator tidak dikenal: {f}")


FIELDS = [
    # key, label, grup, periode default (None = tanpa periode)
    ("close", "Harga", "Harga", None), ("chg", "Perubahan candle %", "Harga", None),
    ("chg_24h", "Perubahan 24 jam %", "Harga", None), ("chg_7d", "Perubahan 7 hari %", "Harga", None),
    ("chg_30d", "Perubahan 30 hari %", "Harga", None), ("vol_24h", "Volume 24 jam (USDT)", "Volume", None),
    ("vol", "Volume candle (USDT)", "Volume", None), ("vol_ratio", "Volume / rata-rata", "Volume", 20),
    ("ema", "EMA", "Tren", 50), ("sma", "SMA", "Tren", 50), ("dist_ema", "Jarak harga ke EMA %", "Tren", 50),
    ("adx", "ADX", "Tren", 14), ("pdi", "+DI", "Tren", 14), ("ndi", "-DI", "Tren", 14),
    ("macd", "MACD (12,26,9)", "Tren", None), ("macd_signal", "MACD signal", "Tren", None),
    ("macd_hist", "MACD histogram", "Tren", None), ("supertrend", "Supertrend arah (+1/-1)", "Tren", 10),
    ("structure", "Market structure (+1/-1)", "Tren", 3),
    ("high_break", "Breakout high N candle (1/0)", "Tren", 20), ("low_break", "Breakdown low N candle (1/0)", "Tren", 20),
    ("rsi", "RSI", "Momentum", 14), ("force_index", "Force Index", "Momentum", 2), ("stoch_k", "Stochastic %K", "Momentum", 14), ("stoch_d", "Stochastic %D", "Momentum", 14),
    ("cci", "CCI", "Momentum", 20), ("willr", "Williams %R", "Momentum", 14), ("roc", "ROC %", "Momentum", 10),
    ("mfi", "MFI", "Momentum", 14), ("atr_pct", "ATR % harga", "Volatilitas", 14),
    ("bb_pctb", "Bollinger %B", "Volatilitas", 20), ("bb_width", "Bollinger width %", "Volatilitas", 20),
]
FIELD_LEN = {k: n for k, _, _, n in FIELDS}
NO_SERIES = {"chg_24h", "vol_24h", "chg_7d", "chg_30d", "structure"}   # tidak bisa dipakai untuk "crossing"


def spec_key(s):
    n = s.get("len") if FIELD_LEN.get(s["f"]) is not None else None
    return f"{s['f']}({int(n)})" if n else s["f"]


class Row:
    def __init__(self, sym, a, daily, tick):
        self.sym, self.tick = sym, tick
        self.o, self.h, self.l, self.c, self.v = (a[:, i] for i in range(1, 6))
        self.daily = daily
        self.memo = {}

    def series(self, s):
        f = s["f"]
        if f not in FIELD_LEN:
            raise ValueError(f"indikator tidak dikenal: {f}")
        key = spec_key(s)
        if key not in self.memo:
            if f in ("chg_24h", "vol_24h"):
                val = self.tick.get(f, np.nan)
                self.memo[key] = np.array([np.nan, val])
            elif f in ("chg_7d", "chg_30d"):
                k = 7 if f == "chg_7d" else 30
                dc = self.daily[:, 4] if self.daily is not None else np.zeros(0)
                self.memo[key] = np.array([np.nan, _pct(dc[-1], dc[-1 - k]) if len(dc) > k else np.nan])
            else:
                n = int(s.get("len") or FIELD_LEN[f] or 0)
                self.memo[key] = _series(f, n, self.o, self.h, self.l, self.c, self.v)
        return self.memo[key]

    def value(self, s, back=0):
        x = self.series(s)
        return float(x[-1 - back]) if len(x) > back else np.nan

    def check(self, flt):
        op, a, b = flt["op"], flt["a"], flt.get("b", {})
        rhs = (lambda back=0: self.value(b, back)) if "f" in b else (lambda back=0: float(b.get("v", np.nan)))
        x = self.value(a)
        if op in ("xup", "xdn"):
            if a["f"] in NO_SERIES or b.get("f") in NO_SERIES:
                raise ValueError(f"{a['f']} tidak bisa dipakai untuk crossing")
            px, y, py = self.value(a, 1), rhs(), rhs(1)
            return bool(px <= py and x > y) if op == "xup" else bool(px >= py and x < y)
        y = rhs()
        if op == "gt":
            return bool(x > y)
        if op == "gte":
            return bool(x >= y)
        if op == "lt":
            return bool(x < y)
        if op == "lte":
            return bool(x <= y)
        if op == "eq":
            return bool(abs(x - y) < 1e-9)
        if op == "between":
            return bool(y <= x <= float(flt.get("b2", {}).get("v", np.nan)))
        raise ValueError(f"operator tidak dikenal: {op}")
