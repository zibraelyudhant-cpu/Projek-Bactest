"""🛡️ SL Backtest: mencari SL (kelipatan ATR) yang paling sering MENANG di TF yang dipilih, memakai sinyal riwayat dari
logika menu lain (data candle lokal banyak koin).

Sumber sinyal (pilih satu):
  whale  — 🐋 Whale › 🎯 Cari setup, logika candle: tiap swing low (BUY, tren EMA20 > EMA50) / swing high (SELL, tren
           EMA20 < EMA50) yang baru terkonfirmasi -> entry market (close) & limit di depan swing (+ entry.swing_buf_atr ATR).
           Tembok order book / flow tidak punya riwayat -> tidak dipakai.
  ms     — 📐 Market Structure › Scan banyak koin: struktur lanjutan tren (HH lalu HL = BUY, LL lalu LH = SELL) ->
           entry Penemu Strategi (market / fib / retest / limit X ATR), pengisian limit sama dengan MS.
  tapro  — 🧠 TA Pro Advance: setup A–D (detect) -> entry market & limit depan swing, pengisian limit sama dengan TA Pro.
  cpat   — 📊 Screener › 🧩 Chart Pattern: pola valid (break terkonfirmasi) -> entry market / retest / QML.
  rev    — 📊 Screener › 🔄 Find Reversal (fresh & terkonfirmasi) -> entry konfirmasi / retest.
SL default = SL strategi itu sendiri (anti-gocekan Whale). TP selalu RR 1:2.

Cara hitung (disetujui user):
  1. Uji SL default strategi (TP = 2 x jarak SL).
  2. Uji SL = entry -+ k x ATR(14) TF sinyal (diukur dari entry), k = 1, 1.5, ... 6; TP = entry +- 2k x ATR.
  3. Trade dimasukkan ke "kotak ATR" = k terkecil yang SL-nya TIDAK tersentuh (harga turun lewat ATR 3 tapi belum ATR 4
     -> kotak ATR 4). ATR yang lebih lebar tidak dihitung untuk trade itu. Harga lewat ATR 6 -> benar-benar LOSE.
  4. Batas 5 hari sejak entry tersentuh: sampai TP (RR 1:2) = WIN +2R. Kalau waktu habis: pernah sampai RR 1:1 = TP1 +1R;
     di atas entry (di area entry–TP) = +0.5R; masih di area SL = LOSE -1R.
  5. SL terbaik = ATR yang paling sering WIN. Ditampilkan 2 cara: (a) kalau SL ATR k dipakai ke SEMUA trade (tiap trade
     diuji dengan SL itu) dan (b) kotak ATR per trade (cara 3). Cara (b) selalu condong ke ATR kecil karena trade yang
     langsung jalan selalu masuk kotak ATR 1, jadi (a) yang dipakai sebagai ⭐ SL terbaik; (b) = sebaran kedalaman SL.
"""
import json
import os
import time

import numpy as np

from . import antigocek as AG
from .chartpat import window_bars
from .data import TF_MS
from .indicators import atr as _atr, ema as _ema, pivots

VERSION = 1
KS = (1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6)
KEYS = [f"{k:g}" for k in KS]
RR = 2.0
HOLD_DAYS = 5
STRATS = {"whale": "🐋 Whale · 🎯 Cari setup (logika candle)", "ms": "📐 Market Structure · Scan banyak koin",
          "tapro": "🧠 TA Pro Advance (setup A–D)", "cpat": "🧩 Chart Pattern Screener", "rev": "🔄 Find Reversal (fresh & terkonfirmasi)"}
CODES = ("win", "tp1", "half", "sl", "lose")         # sl = kena SL; lose = waktu habis di area SL
R_OF = {"win": RR, "tp1": 1.0, "half": 0.5, "sl": -1.0, "lose": -1.0}
EX_KEEP = 200
_CACHE = {}


def hold_bars(tf):
    return max(2, int(HOLD_DAYS * 86_400_000 // TF_MS[tf]))


# ================================================================== sumber sinyal: list dict(s, d, en, e, sl0, mk, f)
def _limit_fill(h, l, d, s, e, sl, wait):
    """Limit terisi sesudah candle s (dalam wait candle); batal kalau harga lebih dulu sampai TP RR 1:2 (seperti TA Pro)."""
    tp = e + d * RR * abs(e - sl)
    for j in range(s + 1, min(len(h), s + 1 + wait)):
        if (l[j] <= e) if d == 1 else (h[j] >= e):
            return j
        if (h[j] >= tp) if d == 1 else (l[j] <= tp):
            return None
    return None


def sig_whale(D, tf):
    h, l, c = D["h"], D["l"], D["c"]
    a = D["a"]
    g = AG.get_ctx({}, h, l, c)
    C = AG.whale_cfg.get()
    up = _ema(c, 20) > _ema(c, 50)
    wait = window_bars(tf)
    hi, lo = pivots(h, l, 3)
    out = []
    for idx, d in ((lo, 1), (hi, -1)):
        for i in np.asarray(idx, int):
            s = int(i) + 3
            if s >= len(c) or not (a[s] > 0) or up[s] != (d == 1):
                continue
            E = {"market": float(c[s])}
            sw = g.swing(s, d == 1, float(c[s]))
            if sw is not None:
                e = sw + d * C["entry.swing_buf_atr"] * a[s]
                if (d == 1 and e < c[s]) or (d == -1 and e > c[s]):
                    E["limit depan swing"] = float(e)
            for en, e in E.items():
                sl = AG.sl_at(g, s, d == 1, e)
                if sl is None or (sl - e) * d >= 0:
                    continue
                mk = en == "market"
                out.append({"s": s, "d": d, "en": en, "e": e, "sl0": float(sl), "mk": mk,
                            "f": s if mk else _limit_fill(h, l, d, s, e, sl, wait), "wait": wait})
    return out


def sig_ms(D, tf):
    from . import msscreen as MS
    from . import stratlab as SL
    h, l, c, a = D["h"], D["l"], D["c"], D["a"]
    g = AG.get_ctx({}, h, l, c)
    out = []
    for s, seq in MS.events(h, l, c, a, 3):
        if len(seq) < 2 or not (a[s] > 0):
            continue
        last, prev = seq[-1], seq[-2]
        if last[3] == "HL" and prev[3] == "HH":
            dm = 0
        elif last[3] == "LH" and prev[3] == "LL":
            dm = 1
        else:
            continue
        r = MS._entries(dm, seq, s, h, l, c, a)
        if r is None:
            continue
        E, _base, ext = r
        d = 1 if dm == 0 else -1
        for en, e in E.items():
            st = MS._stops(g, s, dm, e)
            if "anti" not in st:
                continue
            sl = st["anti"]
            risk = (e - sl) * d
            if not (SL.MIN_RISK * a[s] <= risk <= SL.MAX_RISK * a[s]):
                continue
            mk = en == "market"
            out.append({"s": s, "d": d, "en": en, "e": float(e), "sl0": float(sl), "mk": mk, "f": SL._fill(dm, s, e, ext, h, l, en),
                        "wait": SL.FILL_WAIT})
    return out


def sig_tapro(D, tf, store=None, sym=None):
    from . import msscreen as MS
    from . import tapro as TP
    big = []
    if store is not None:
        for tfb in (MS.HTF_AUTO.get(tf), "1d"):
            if tfb and tfb != tf and tfb in store.timeframes(sym) and TF_MS[tfb] > TF_MS[tf] and tfb not in [x[2] for x in big]:
                bb = store.get(sym, tfb)
                big.append((np.asarray(bb.t, np.int64), np.asarray(bb.c, float), tfb))
    S = TP.Series(sym or "?", tf, D["t"], D["o"], D["h"], D["l"], D["c"], D["v"], big)
    g = AG.get_ctx(S, S.h, S.l, S.c)
    wait = window_bars(tf)
    out = []
    for s, d, code, _sl0, _lims, _inv, ms in TP.detect(S):
        for en, e in TP._entries_at(S, g, s, d, ms).items():
            mk = en == "market"
            sb = ms if mk else s
            sl = AG.sl_at(g, sb, d == 1, e)
            if sl is None or (sl - e) * d >= 0:
                continue
            if not mk and ((d == 1 and e >= S.c[s]) or (d == -1 and e <= S.c[s])):
                continue
            out.append({"s": int(sb), "d": int(d), "en": f"{code}·{en}", "e": float(e), "sl0": float(sl), "mk": mk,
                        "f": int(ms) if mk else _limit_fill(S.h, S.l, d, s, e, sl, wait), "wait": wait})
    return out


def _sig_cp(D, tf, rev):
    from . import chartpat as CP
    h, l, c, a = D["h"], D["l"], D["c"], D["a"]
    g = AG.get_ctx({}, h, l, c)
    wait = window_bars(tf)
    out = []
    for x in CP.formations(h, l, c, a, 3):
        if (x["code"] == "rv") != rev:
            continue
        b, _st = CP.find_break(x, h, l, c)
        if b is None:
            continue
        d = x["dir"]
        for en, e in CP.plan_levels(x, b, c, d).items():
            sl = AG.sl_at(g, b, d == 1, e)
            if sl is None or (sl - e) * d >= 0:
                continue
            mk = en in ("market", "conf")
            tp = e + d * RR * abs(e - sl)
            out.append({"s": int(b), "d": d, "en": f"{CP.NAMES.get(x['code'], x['code']) if hasattr(CP, 'NAMES') else x['code']}·{en}",
                        "e": float(e), "sl0": float(sl), "mk": mk, "f": b if mk else CP._fill(h, l, d, b, e, tp, wait), "wait": wait})
    return out


def signals(strat, D, tf, store=None, sym=None):
    if strat == "whale":
        return sig_whale(D, tf)
    if strat == "ms":
        return sig_ms(D, tf)
    if strat == "tapro":
        return sig_tapro(D, tf, store, sym)
    if strat in ("cpat", "rev"):
        return _sig_cp(D, tf, strat == "rev")
    raise ValueError(f"strategi tidak dikenal: {strat}")


# ================================================================== hasil 1 trade
def _outcome(H, L, C, f, end, mk, e, sl, tp, risk):
    """Sisi beli (harga sisi jual sudah dicermin). -> (kode, candle keluar, MAE dalam harga sampai keluar)."""
    first = f + 1 if mk else f
    lw = L[first:end + 1]
    hg = H[f + 1:end + 1]
    ii = np.flatnonzero(lw <= sl)
    sj = first + int(ii[0]) if len(ii) else None
    ii = np.flatnonzero(hg >= tp)
    tj = f + 1 + int(ii[0]) if len(ii) else None
    if sj is not None and (tj is None or sj <= tj):
        return "sl", sj
    if tj is not None:
        return "win", tj
    if len(hg) and hg.max() >= e + risk:
        return "tp1", end                                        # waktu habis, pernah sampai RR 1:1
    if C[end] > e:
        return "half", end                                       # waktu habis di area entry–TP
    return "lose", end                                           # waktu habis masih di area SL


def eval_signal(D, x, hold):
    """Satu sinyal -> dict hasil SL default + tiap ATR + kotak ATR. None kalau belum terisi / data kurang."""
    f = x["f"]
    if f is None:
        return None
    n = len(D["c"])
    end = f + hold
    if end >= n:
        return None
    d = x["d"]
    H, L, C = (D["h"], D["l"], D["c"]) if d == 1 else (-D["l"], -D["h"], -D["c"])
    e, sl0 = x["e"] * d, x["sl0"] * d
    A = float(D["a"][x["s"]])
    if not (A > 0):
        return None
    r0 = e - sl0
    if r0 <= 0:
        return None
    dc, dx = _outcome(H, L, C, f, end, x["mk"], e, sl0, e + RR * r0, r0)
    per = {}
    box = None
    for k, kk in zip(KS, KEYS):
        risk = k * A
        code, ex = _outcome(H, L, C, f, end, x["mk"], e, e - risk, e + RR * risk, risk)
        per[kk] = (code, ex)
        if box is None and code != "sl":
            box = kk
    first = f + 1 if x["mk"] else f
    xb = per[box][1] if box else end
    mae = float((e - L[first:xb + 1].min()) / A) if xb >= first else 0.0
    return {"def": (dc, dx), "per": per, "box": box, "mae": max(0.0, mae), "A": A}


# ================================================================== per koin (agregat kecil + contoh)
def _blank():
    return {c_: 0 for c_ in CODES}


def coin_eval(sym, D, tf, strat, store=None):
    sig = signals(strat, D, tf, store, sym)
    hold = hold_bars(tf)
    t = D["t"]
    n = len(t)
    split_t = int(t[int(n * 0.7)]) if n else 0
    G = {"n_sig": len(sig), "n": 0, "n_test": 0, "def": _blank(), "def_test": _blank(), "per": {k: _blank() for k in KEYS}, "per_test": {k: _blank() for k in KEYS},
         "box": {k: _blank() for k in KEYS}, "box_test": {k: _blank() for k in KEYS}, "lose": 0, "lose_test": 0, "by_en": {}, "mae": []}
    EX = []
    for x in sig:
        r = eval_signal(D, x, hold)
        if r is None:
            continue
        te = int(t[x["s"]]) >= split_t
        G["n"] += 1
        G["n_test"] += te
        G["def"][r["def"][0]] += 1
        if te:
            G["def_test"][r["def"][0]] += 1
        for kk, (code, _) in r["per"].items():
            G["per"][kk][code] += 1
            if te:
                G["per_test"][kk][code] += 1
        bx = r["box"]
        if bx is None:
            G["lose"] += 1
            G["lose_test"] += te
        else:
            bc = r["per"][bx][0]
            G["box"][bx][bc] += 1
            if te:
                G["box_test"][bx][bc] += 1
        B = G["by_en"].setdefault(x["en"], {"n": 0, "def_win": 0, "box_win": {}, "lose": 0})
        B["n"] += 1
        B["def_win"] += r["def"][0] == "win"
        if bx is None:
            B["lose"] += 1
        elif r["per"][bx][0] == "win":
            B["box_win"][bx] = B["box_win"].get(bx, 0) + 1
        if len(G["mae"]) < 5000:
            G["mae"].append(round(r["mae"], 2))
        s, f = x["s"], x["f"]
        bx_code, bx_x = r["per"][bx] if bx else ("lose", f + hold)
        k = float(bx) if bx else KS[-1]
        EX.append({"sym": sym, "t": int(t[s]), "d": x["d"], "en": x["en"], "e": x["e"], "sl0": x["sl0"], "tp0": x["e"] + x["d"] * RR * abs(x["e"] - x["sl0"]),
                   "A": r["A"], "fb": int(f - s), "def": r["def"][0], "def_xo": int(r["def"][1] - s), "box": bx, "res": bx_code,
                   "xo": int(bx_x - s), "sl": x["e"] - x["d"] * k * r["A"], "tp": x["e"] + x["d"] * RR * k * r["A"], "mae": round(r["mae"], 2),
                   "R": R_OF[bx_code] if bx else -1.0, "test": te})
        if len(EX) > 3 * EX_KEEP:
            EX = EX[-EX_KEEP:]
    return G, EX[-EX_KEEP:]


def merge(G, g2):
    if not G:
        G.update(json.loads(json.dumps(g2)))
        return
    for k in ("n_sig", "n", "n_test", "lose", "lose_test"):
        G[k] += g2[k]
    for k in ("def", "def_test"):
        for c_ in CODES:
            G[k][c_] += g2[k][c_]
    for k in ("per", "per_test", "box", "box_test"):
        for kk in KEYS:
            for c_ in CODES:
                G[k][kk][c_] += g2[k][kk][c_]
    for en, B in g2["by_en"].items():
        X = G["by_en"].setdefault(en, {"n": 0, "def_win": 0, "box_win": {}, "lose": 0})
        X["n"] += B["n"]; X["def_win"] += B["def_win"]; X["lose"] += B["lose"]
        for kk, v in B["box_win"].items():
            X["box_win"][kk] = X["box_win"].get(kk, 0) + v
    G["mae"] = (G["mae"] + g2["mae"])[-20000:]


# ================================================================== analisa
def _st(cnt):
    n = sum(cnt.values())
    if not n:
        return {"n": 0, "wr": None, "exp": None, **cnt}
    return {"n": n, "wr": 100 * cnt["win"] / n, "exp": sum(R_OF[c_] * v for c_, v in cnt.items()) / n, **cnt}


def analyse(G):
    if not G or not G.get("n"):
        return {"n": 0, "best": None}
    N = G["n"]
    rows = []
    for kk in KEYS:
        bx = G["box"][kk]
        nb = sum(bx.values())
        rows.append({"k": kk, "box_n": nb, "box_win": bx["win"], "box_tp1": bx["tp1"], "box_half": bx["half"], "box_lose": bx["lose"],
                     "box_pct": 100 * nb / N, "win_pct": 100 * bx["win"] / N, "box_win_test": G["box_test"][kk]["win"],
                     "all": _st(G["per"][kk])})
    best_box = max(rows, key=lambda r: (r["box_win"], r["all"]["exp"] or -9))      # kotak ATR yang paling sering WIN (cara per trade)
    best = max(rows, key=lambda r: (r["all"]["win"], r["all"]["exp"] or -9))        # SL ATR yang paling sering WIN kalau dipakai ke semua trade
    for r in rows:
        r["all_test"] = _st(G["per_test"][r["k"]])
    cum, cw = 0, 0
    for r in rows:                                     # kumulatif: kalau pakai SL ATR k, trade yang kotaknya <= k selamat
        cum += r["box_n"]; cw += r["box_win"]
        r["saved_pct"] = 100 * cum / N
    mae = np.array(G["mae"]) if G["mae"] else np.zeros(1)
    en = []
    for name, B in G["by_en"].items():
        bk = max(B["box_win"].items(), key=lambda kv: kv[1]) if B["box_win"] else (None, 0)
        en.append({"en": name, "n": B["n"], "def_wr": 100 * B["def_win"] / B["n"] if B["n"] else None, "best_k": bk[0],
                   "best_win": bk[1], "best_pct": 100 * bk[1] / B["n"] if B["n"] else None, "lose_pct": 100 * B["lose"] / B["n"] if B["n"] else None})
    en.sort(key=lambda x: -x["n"])
    nt = G["n_test"]
    return {"n": N, "n_sig": G["n_sig"], "n_test": nt, "default": _st(G["def"]), "default_test": _st(G["def_test"]), "rows": rows,
            "best": best, "best_box": {**best_box, "win_pct_test": 100 * best_box["box_win_test"] / nt if nt else None},
            "lose": G["lose"], "lose_pct": 100 * G["lose"] / N, "lose_test_pct": 100 * G["lose_test"] / nt if nt else None,
            "mae_p": {str(p): float(np.percentile(mae, p)) for p in (25, 50, 75, 90)}, "by_entry": en[:40]}


# ================================================================== jalankan (paralel, progres, cache, simpan)
_W = {}


def _init_worker(data_dir):
    from .data import DataStore
    _W["store"] = DataStore(data_dir, cache_size=4)


def load(store, sym, tf):
    b = store.get(sym, tf)
    D = {"t": np.asarray(b.t, np.int64)}
    for k in ("o", "h", "l", "c"):
        D[k] = np.asarray(getattr(b, k), float)
    D["v"] = np.asarray(getattr(b, "v", np.ones(len(D["c"]))), float)
    D["a"] = _atr(D["h"], D["l"], D["c"], 14)
    return D


def coin_job(sym, tf, strat, store=None):
    st = store or _W["store"]
    try:
        D = load(st, sym, tf)
        if len(D["c"]) < 500:
            return f"data terlalu sedikit ({len(D['c'])} candle)"
        G, EX = coin_eval(sym, D, tf, strat, st)
        return G, EX, len(D["c"])
    except (ValueError, KeyError, IndexError, OSError, ZeroDivisionError) as ex:
        return f"{type(ex).__name__}: {ex}"


def _disk(tf, strat):
    from .results_store import BASE
    return os.path.join(BASE, "slbt_cache", f"res_{strat}_{tf}.json")


def run(store, tf, strat, syms, progress=None, push=None, workers=None):
    if strat not in STRATS:
        raise ValueError(f"strategi tidak dikenal: {strat}")
    key = json.dumps([VERSION, tf, strat, list(syms), [int(store.get(s_, tf).t[-1]) for s_ in syms], AG._cfg_sig(AG.whale_cfg.get())], default=str)
    if key in _CACHE:
        return _CACHE[key]
    try:
        with open(_disk(tf, strat), encoding="utf-8") as f_:
            Dk = json.load(f_)
        if Dk.get("key") == key:
            Dk["res"]["from_file"] = True
            _CACHE[key] = Dk["res"]
            return Dk["res"]
    except (OSError, ValueError, KeyError):
        pass
    t0 = time.time()
    G, EX, used, skipped, n_c, per_coin = {}, [], [], [], 0, []

    def take(i, s_, res):
        nonlocal n_c, EX
        if isinstance(res, str):
            skipped.append(f"{s_}: {res}")
        else:
            g2, ex2, nc = res
            merge(G, g2)
            EX = sorted(EX + ex2, key=lambda r: r["t"])[-EX_KEEP:]
            used.append(s_); n_c += nc
            per_coin.append({"sym": s_, "n": g2["n"]})
        if progress:
            progress(i + 1, len(syms), s_, isinstance(res, str))
        if push and (i < 5 or (i + 1) % 3 == 0 or i + 1 == len(syms)):
            part = analyse(G)
            part.update(partial=True, phase="riwayat", tf=tf, strat=strat, coins=list(used), done=i + 1, total=len(syms), candles=n_c,
                        per_coin=per_coin[-12:], skipped=skipped[-5:], elapsed=round(time.time() - t0, 1))
            part.pop("by_entry", None)
            push(part)
    workers = workers if workers is not None else max(1, min(8, (os.cpu_count() or 2) - 1))
    done = False
    if workers > 1 and len(syms) > 2:
        try:
            from concurrent.futures import ProcessPoolExecutor, as_completed
            with ProcessPoolExecutor(max_workers=workers, initializer=_init_worker, initargs=(store.data_dir,)) as ex_:
                futs = {ex_.submit(coin_job, s_, tf, strat): s_ for s_ in syms}
                for i, fu in enumerate(as_completed(futs)):
                    try:
                        res = fu.result()
                    except Exception as e:                                     # noqa: BLE001 - 1 koin gagal: lanjut
                        res = f"{type(e).__name__}: {e}"
                    take(i, futs[fu], res)
            done = True
        except (OSError, RuntimeError, ImportError):
            G, EX, used, skipped, n_c, per_coin = {}, [], [], [], 0, []
    if not done:
        for i, s_ in enumerate(syms):
            take(i, s_, coin_job(s_, tf, strat, store))
    if push:
        push({"partial": True, "phase": "analisa", "done": len(syms), "total": len(syms), "tf": tf, "strat": strat, "coins": used})
    res = analyse(G)
    res.update(tf=tf, strat=strat, strat_txt=STRATS[strat], coins=used, skipped=skipped[:20], n_skipped=len(skipped), candles=n_c,
               hold_bars=hold_bars(tf), ks=KEYS, examples=EX, elapsed=round(time.time() - t0, 1), v=VERSION, workers=workers)
    if len(_CACHE) > 6:
        _CACHE.clear()
    _CACHE[key] = res
    try:
        os.makedirs(os.path.dirname(_disk(tf, strat)), exist_ok=True)
        with open(_disk(tf, strat) + ".tmp", "w", encoding="utf-8") as f_:
            json.dump({"key": key, "res": res}, f_, default=float)
        os.replace(_disk(tf, strat) + ".tmp", _disk(tf, strat))
    except (OSError, TypeError, ValueError):
        pass
    return res


def history_symbols(store, tf, n=30):
    syms = [s_ for s_ in store.symbols() if tf in store.timeframes(s_)] if hasattr(store, "symbols") else []
    syms.sort(key=lambda s_: -len(store.get(s_, tf).c))
    return syms[:n]


def candles_around(store, sym, tf, t_ms, before=60, after=200):
    b = store.get(sym, tf)
    t = np.asarray(b.t, np.int64)
    i = int(np.searchsorted(t, int(t_ms)))
    a0, a1 = max(0, i - before), min(len(t), i + max(10, min(int(after), 800)))
    return [[int(t[k]), float(b.o[k]), float(b.h[k]), float(b.l[k]), float(b.c[k])] for k in range(a0, a1)], i - a0
