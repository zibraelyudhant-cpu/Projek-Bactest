"""🔎 Screener Market Structure: struktur SEKARANG 1 koin (live Binance, cadangan data lokal) -> cari pola swing yang
sama di riwayat (data lokal, semua koin / koin ini) -> biasanya lanjut ke mana + entry / SL / TP terbaik (RR >= 1:3)
diterapkan ke harga sekarang.

- Swing fractal k (kecil 3 / sedang 5 / besar 10), diketahui k candle sesudahnya; urutan selang-seling high/low.
- Label dasar: HH / LH (high sama tinggi dihitung LH), HL / LL (low sama dihitung HL).
- Pola = L swing terakhir saat swing terbaru terkonfirmasi. L otomatis: 6 -> 5 -> 4 -> 3 sampai kejadian di riwayat >= MIN_OCC.
- Entry / SL / hasil memakai aturan yang SAMA dengan Penemu Strategi (stratlab): entry market / fib 0.382-0.786 / retest BOS,
  limit berlaku FILL_WAIT candle, lama trade maks HOLD candle.
- SL (v4.15) = SL anti-gocekan logika menu Whale (antigocek.py); sinyal sekarang ikut memakai tembok order book live.
"""
import time

import numpy as np

from . import antigocek as AG
from . import evidence as EV
from . import papath as PA
from . import stratlab as SL
from .data import TF_MS
from .indicators import atr as _atr, pivots
from .riskstats import risk_seq

SWINGS = {"kecil": 3, "sedang": 5, "besar": 10}
EQ_TOL = 0.1
LENS = (6, 5, 4, 3)
MIN_OCC = 30
MIN_FILL = 15
MIN_FILL_PCT = 70.0              # sinyal hanya dari entry yang di riwayat TERISI >= 70% (market = 100%)
RRS = [3.0, 4.0, 5.0]            # RR minimal 1:3
# khusus 🔎 Scan banyak koin: RR minimal 1:2 & layak hanya kalau LEBIH SERING MENANG (WR >= 50% di data cari & data uji)
MULTI_RRS = [2.0, 3.0, 4.0, 5.0]
MULTI_MIN_WR = 50.0
MULTI_MIN_LEG = 1.0              # scan banyak koin: swing baru dihitung kalau jaraknya dari swing sebelumnya >= 1 ATR
MIN_LEG_CHOICES = (0.0, 0.5, 1.0, 1.5, 2.0)
# scan banyak koin: "MANTUL BERSIH" (definisi disetujui user) =
#   (1) candle yang menyentuh entry hanya kena EKOR, close-nya kembali di sisi untung (entry market: syarat ini tidak berlaku),
#   (2) sebelum harga bergerak +1R tidak ada SATU candle pun yang close di area antara entry dan SL ("main dulu" = jelek),
#   (3) +1R tercapai dalam BOUNCE_BARS candle.
BOUNCE_BARS = 12
EVAL_FRACS = (-0.2, -0.1, 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6)   # entry dievaluasi: geser entry sinyal x risiko (+ = menuju SL)
MOVE_ATR = 2.0                   # "arah selanjutnya" = mana duluan: +2 ATR atau -2 ATR dari close
N_PATH = 40                      # jalur harga sesudah pola (candle) untuk animasi prediksi
_CACHE = {}                      # (sym, tf, k, n, last_t) -> kejadian per koin


def _eval_entry(p, events, D_of, now, min_wr):
    """🔬 Entry dievaluasi: entry sinyal digeser EVAL_FRACS x risiko di SEMUA kejadian aturan ini (SL tetap, TP = RR yang sama),
    lalu dipilih yang paling sering MANTUL BERSIH, dengan syarat terisi >= 70%, untung, untung di data uji & WR >= min_wr."""
    d, rr, mk0 = p["dir"], p["rr"], p["entry"] == "market"
    sg = 1 if d == 0 else -1
    e0, sl0 = p["price_entry"], p["price_sl"]
    r0 = abs(e0 - sl0)
    out = []
    for fr in EVAL_FRACS:
        if mk0 and fr < 0:
            continue                                            # entry market tidak bisa digeser menjauhi SL
        e_now = e0 - sg * fr * r0
        if fr != 0 and ((d == 0 and e_now >= now) or (d == 1 and e_now <= now)):
            continue                                            # limit harus di bawah harga (BUY) / di atas harga (SELL)
        mk = mk0 and fr == 0
        n = nf = w = cl = mn = 0
        R, Rt = [], []
        for sym, s_, e, slp, ext, te in events:
            D = D_of[sym]
            h, l, c = D["h"], D["l"], D["c"]
            rk = abs(e - slp)
            e2 = e - sg * fr * rk
            if not mk and ((d == 0 and e2 >= c[s_]) or (d == 1 and e2 <= c[s_])):
                continue
            n += 1
            f = SL._fill(d, s_, e2, ext, h, l, "market" if mk else "limit")
            if f is None:
                continue
            res = SL._outcome(d, f, e2, slp, [rr], h, l, c, mk)
            if res is None:
                n -= 1
                continue
            nf += 1
            r_, code, _ = res[0]
            w += code == 1
            (Rt if te else R).append(r_)
            b, m = _bounce(d, f, e2, slp, h, l, c, mk)
            cl += b
            mn += m
        if not nf:
            continue
        allR = R + Rt
        fill = 100.0 if mk else 100 * nf / max(1, n)
        exp_r = float(np.mean(allR))
        st = {"frac": fr, "price_entry": float(e_now), "price_sl": float(sl0), "price_tp": float(e_now + sg * rr * abs(e_now - sl0)),
              "entry": "market" if mk else "limit", "n": nf, "fill_pct": fill, "wr": 100 * w / nf, "exp_r": exp_r, "exp_sig": exp_r * fill / 100,
              "n_test": len(Rt), "exp_test": float(np.mean(Rt)) if Rt else None, "clean_pct": 100 * cl / nf, "main_pct": 100 * mn / nf}
        st["ok"] = bool((mk or fill >= MIN_FILL_PCT) and st["exp_sig"] > 0 and st["exp_test"] is not None and st["exp_test"] > 0
                        and st["n_test"] >= 5 and (min_wr is None or st["wr"] >= min_wr))
        out.append(st)
    sig = next((x for x in out if x["frac"] == 0), None) or {"frac": 0, "clean_pct": None, "main_pct": None}
    ok = [x for x in out if x["ok"]]
    best = max(ok, key=lambda x: (round(x["clean_pct"]), x["exp_sig"])) if ok else None
    return {"signal": sig, "best": best, "cands": out, "same": bool(best is None or best["frac"] == 0)}


def _bounce(d, f, e, sl, h, l, c, market):
    """-> (mantul_bersih, main_dulu). main_dulu = ada close di area entry–SL sebelum +1R (atau candle sentuh close di sana)."""
    risk = abs(e - sl)
    if risk <= 0:
        return False, False
    up = d == 0
    if not market and ((c[f] <= e) if up else (c[f] >= e)):
        return False, True                              # candle sentuh close di dalam area entry–SL: bukan cuma ekor
    tgt = e + risk if up else e - risk
    for j in range(f + 1, min(len(c), f + 1 + BOUNCE_BARS)):
        if (l[j] <= sl) if up else (h[j] >= sl):
            return False, True
        if (h[j] >= tgt) if up else (l[j] <= tgt):
            if (sl < c[j] <= e) if up else (e <= c[j] < sl):
                return False, True
            return True, False
        if (sl < c[j] <= e) if up else (e <= c[j] < sl):
            return False, True                          # main dulu di area entry–SL
    return False, False


def events(h, l, c, a, k, min_leg=0.0):
    """[(s, seq)] — seq = 8 swing terakhir [(idx, harga, 'H'/'L', label)] yang DIKETAHUI saat candle s close.
    min_leg > 0 (hanya 🔎 Scan banyak koin): swing yang jaraknya dari swing sebelumnya < min_leg x ATR = goyangan kecil,
    diabaikan (tidak dihitung sebagai swing)."""
    hi_i, lo_i = pivots(h, l, k)
    ev = sorted([(int(i) + k, int(i), "H") for i in hi_i] + [(int(i) + k, int(i), "L") for i in lo_i])
    seq, out = [], []
    for s, p, typ in ev:
        if s >= len(c):
            continue
        price = float(h[p] if typ == "H" else l[p])
        if seq and seq[-1][2] == typ:
            if (typ == "H" and price <= seq[-1][1]) or (typ == "L" and price >= seq[-1][1]):
                continue
            seq.pop()
        elif seq and min_leg and abs(price - seq[-1][1]) < min_leg * (a[p] if a[p] == a[p] else 0):
            continue                                      # terlalu kecil untuk disebut swing
        prev = next((x for x in reversed(seq) if x[2] == typ), None)
        lab = None
        if prev is not None:
            if typ == "H":
                lab = "HH" if price > prev[1] + EQ_TOL * (a[p] if a[p] == a[p] else 0) else "LH"
            else:
                lab = "LL" if price < prev[1] - EQ_TOL * (a[p] if a[p] == a[p] else 0) else "HL"
        seq.append((p, price, typ, lab))
        seq = seq[-8:]
        out.append((s, list(seq)))
    return out


_LCODE = {"HH": 0, "LH": 1, "HL": 2, "LL": 3}


def _med(x):
    return float(np.median(x)) if x else None


def _code(seq, L):
    """Label L swing terakhir sebagai satu angka (basis 4) -> pencarian pola cepat. -1 = belum lengkap."""
    if len(seq) < L:
        return -1
    v = 0
    for x in seq[-L:]:
        d = _LCODE.get(x[3])
        if d is None:
            return -1
        v = v * 4 + d
    return v


def _labels(seq, L):
    labs = [x[3] for x in seq[-L:]]
    return None if len(labs) < L or any(x is None for x in labs) else tuple(labs)


def _first_move(h, l, c, a, s, horizon=200):
    """+1 kalau harga naik MOVE_ATR x ATR duluan dari close s, -1 kalau turun duluan, 0 belum / tidak jelas."""
    A = a[s]
    if not (A == A) or A <= 0:
        return 0, None
    up, dn = c[s] + MOVE_ATR * A, c[s] - MOVE_ATR * A
    e = min(len(c), s + 1 + horizon)
    hu = np.flatnonzero(h[s + 1:e] >= up)
    hd = np.flatnonzero(l[s + 1:e] <= dn)
    iu = int(hu[0]) if len(hu) else None
    idn = int(hd[0]) if len(hd) else None
    if iu is None and idn is None:
        return 0, None
    if idn is None or (iu is not None and iu < idn):
        return 1, iu + 1
    if iu is None or idn < iu:
        return -1, idn + 1
    return 0, None                                            # di candle yang sama: tidak jelas


def coin_events(store, sym, tf, k, n_max=200_000, min_leg=0.0):
    b = store.get(sym, tf)
    t = np.asarray(b.t)
    key = (sym, tf, k, len(t), int(t[-1]) if len(t) else 0, float(min_leg))
    if key in _CACHE:
        return _CACHE[key]
    h, l, c = (np.asarray(x, float)[-n_max:] for x in (b.h, b.l, b.c))
    t = t[-n_max:]
    a = _atr(h, l, c, 14)
    ev = events(h, l, c, a, k, min_leg)
    out = {"t": t, "h": h, "l": l, "c": c, "a": a, "ev": ev, "ev_s": np.array([x[0] for x in ev], np.int64),
           "codes": {L: np.array([_code(seq, L) for _, seq in ev], np.int64) for L in LENS}}
    if len(_CACHE) > 600:
        _CACHE.clear()
    _CACHE[key] = out
    return out


_EVMEMO = {}                     # (sym, tf, n, last_t) -> zigzag Elliott yang sudah dihitung (riwayat panjang)


def _store_tc(store, sym, tf):
    try:
        if sym in store.catalog and tf in store.timeframes(sym):
            b = store.get(sym, tf)
            return np.asarray(b.t, np.int64), np.asarray(b.c, float)
    except (ValueError, KeyError, OSError):
        pass
    return None


def hist_votes(store, sym, tf, idxs, n_max=200_000):
    """Suara bukti di candle `idxs` (indeks sama dengan coin_events) untuk 1 koin riwayat (data lokal)."""
    b = store.get(sym, tf)
    t = np.asarray(b.t, np.int64)[-n_max:]
    o, h, l, c = (np.asarray(x, float)[-n_max:] for x in (b.o, b.h, b.l, b.c))
    key = (sym, tf, len(t), int(t[-1]) if len(t) else 0)
    if len(_EVMEMO) > 300:
        _EVMEMO.clear()
    memo = _EVMEMO.setdefault(key, {})
    return EV.coin_votes(t, o, h, l, c, tf, btc=_store_tc(store, "BTCUSDT", tf), d1=_store_tc(store, sym, "1d"),
                         symbol=sym, at=idxs, memo=memo)


def now_votes(store, symbol, tf, lt, lo, lh, ll, lc, live_ev=None):
    """Suara bukti di candle sekarang (data live dari Binance kalau ada: BTC & D1 ikut live)."""
    live_ev = live_ev or {}
    btc = live_ev.get("btc") or _store_tc(store, "BTCUSDT", tf)
    d1 = live_ev.get("d1") or _store_tc(store, symbol, "1d")
    return EV.coin_votes(np.asarray(lt, np.int64), lo, lh, ll, lc, tf, btc=btc, d1=d1, symbol=symbol, at=[len(lc) - 1])


def grade_trades(store, tf, samples, d, V_now):
    """samples = [(sym, s, menang, data_uji)] -> kelas A/B/C untuk setup arah d (0 LONG / 1 SHORT) sekarang.
    Bobot bukti dari 70% kejadian awal (semua koin riwayat digabung), WR per kelas di 30% terakhir."""
    sg = 1 if d == 0 else -1
    by = {}
    for sym, s, w, te in samples:
        by.setdefault(sym, []).append((s, w, te))
    packs = []
    for sym, L in by.items():
        try:
            V = hist_votes(store, sym, tf, [x[0] for x in L])
        except (ValueError, KeyError, OSError, IndexError):
            continue
        packs.append(EV.pack(V, [x[0] for x in L], sg, [x[1] for x in L], test=[x[2] for x in L]))
    model = EV.learn_np(EV.concat(packs))
    ev = EV.describe(model, V_now, len(V_now["ew"]) - 1, sg, tf)
    ev["model"] = {k: model.get(k) for k in ("w", "stats", "n_fit", "n_test")}
    return ev


DIPS = (0.5, 1.0, 1.5)           # entry limit X ATR di bawah (LONG) / di atas (SHORT) close saat pola terkonfirmasi


def _entry_txt(en, d):
    if en.startswith("atr"):
        return f"limit {en[3:]} ATR {'di bawah' if d == 0 else 'di atas'} harga saat pola terkonfirmasi"
    return SL.ENTRY_TXT[en]


def _entries(d, seq, s, h, l, c, a):
    """Entry Penemu Strategi (market / fib / retest) + limit X ATR dari close."""
    r = SL._entries(d, seq, s, h, l, c, a)
    if r is None:
        return None
    E, base, ext = r
    A = a[s]
    for x in DIPS:
        lv = c[s] - x * A if d == 0 else c[s] + x * A
        if (d == 0 and lv > base) or (d == 1 and lv < base):
            E[f"atr{x:g}"] = float(lv)
    return E, base, ext


def _stops(g, s, d, e, walls=None):
    """SL = anti-gocekan (logika menu Whale, lihat antigocek.py) untuk entry e yang diketahui di candle s.
    walls = tembok order book live (hanya sinyal sekarang). {} kalau SL ditolak (lebih jauh dari batas & mode tolak)."""
    sl = AG.sl_at(g, s, d == 0, e, walls)
    return {} if sl is None else {"anti": sl}


HTF_AUTO = {"1m": "15m", "3m": "15m", "5m": "1h", "15m": "4h", "30m": "4h", "1h": "1d", "2h": "1d", "4h": "1d",
            "6h": "1d", "8h": "1d", "12h": "1d", "1d": None}
BASE_PER_COIN = 400        # kejadian swing per koin untuk pembanding (diambil merata, di-cache)
SIM_KEEP = 0.5             # "leg mirip" = separuh kejadian yang ukuran leg-nya paling mirip (minimal MIN_OCC)
MIN_TEST = 10              # kejadian data uji minimal supaya filter bisa dinilai


def resolve_htf(tf, htf):
    """TF besar yang dipakai: "auto" -> HTF_AUTO, "off" -> None, atau TF pilihan (harus lebih besar dari tf)."""
    H = HTF_AUTO.get(tf) if htf in (None, "", "auto") else (None if htf == "off" else htf)
    return H if H and H in TF_MS and tf in TF_MS and TF_MS[H] > TF_MS[tf] else None


def _trend(seq):
    """Tren dari struktur: naik = high terakhir HH & low terakhir HL; turun = LH & LL; lainnya campur."""
    hh = next((x[3] for x in reversed(seq) if x[2] == "H" and x[3]), None)
    lw = next((x[3] for x in reversed(seq) if x[2] == "L" and x[3]), None)
    if hh == "HH" and lw == "HL":
        return "naik"
    if hh == "LH" and lw == "LL":
        return "turun"
    return "campur" if hh and lw else None


def _htf_trend_at(D, close_ms):
    """Tren TF besar yang sudah DIKETAHUI pada waktu close_ms (event HTF dipakai setelah candle konfirmasinya close)."""
    ev, t = D["ev"], D["t"]
    if not ev:
        return None
    if "_evt" not in D:
        step = int(t[1] - t[0]) if len(t) > 1 else 0
        D["_evt"] = np.array([t[s] + step for s, _ in ev])          # waktu close candle konfirmasi
    i = int(np.searchsorted(D["_evt"], close_ms, side="right")) - 1
    return _trend(ev[i][1]) if i >= 0 else None


def _legs(seq, L, a_ref):
    """Ukuran leg antar swing pola (dalam ATR), bertanda: + naik, - turun."""
    pts = seq[-L:]
    return np.array([(pts[i + 1][1] - pts[i][1]) / a_ref for i in range(len(pts) - 1)]) if a_ref and a_ref == a_ref else None


def _baseline(store, sym, tf, k, min_leg=0.0):
    """Pembanding: arah gerak 2 ATR duluan setelah swing APA PUN (bukan hanya pola ini) di koin & TF yang sama."""
    D = coin_events(store, sym, tf, k, min_leg=min_leg)
    if "_base" in D:
        return D["_base"]
    n = len(D["c"])
    idx = [s for s, _ in D["ev"] if s + 200 < n]
    if len(idx) > BASE_PER_COIN:
        idx = [idx[int(i)] for i in np.linspace(0, len(idx) - 1, BASE_PER_COIN)]
    up = dn = 0
    for s in idx:
        d_, _ = _first_move(D["h"], D["l"], D["c"], D["a"], s)
        up += d_ == 1
        dn += d_ == -1
    D["_base"] = (up, dn)
    return D["_base"]


def parse_scope(raw):
    """Isian "Riwayat": "semua" / "all" -> "all"; "koin ini" / "coin" -> "coin"; angka N -> N koin volume terbesar
    (data lokal); daftar koin "btc, eth" -> ["BTCUSDT", "ETHUSDT"]. Hasil: "all" | "coin" | int | list."""
    if isinstance(raw, int):
        return max(1, raw)
    if isinstance(raw, (list, tuple)):
        L = [str(x).upper().strip() for x in raw if str(x).strip()]
        return [x if x.endswith("USDT") else x + "USDT" for x in L] or "all"
    t = str(raw or "").strip().lower()
    if t in ("", "all", "semua", "semua koin"):
        return "all"
    if t in ("coin", "koin ini", "koin ini saja", "ini"):
        return "coin"
    if t.isdigit():
        if int(t) < 1:
            raise ValueError("jumlah koin riwayat minimal 1")
        return int(t)
    parts = [x for x in t.replace(";", ",").replace(" ", ",").split(",") if x]
    return [x.upper() if x.upper().endswith("USDT") else x.upper() + "USDT" for x in parts]


_RANK = {}


def history_symbols(store, symbol, tf, scope):
    """Koin riwayat. Angka N = N koin dengan volume (USDT) terbesar 30 hari terakhir di DATA LOKAL; koin yang dipilih
    selalu ikut (kalau datanya ada)."""
    have = [x for x in store.symbols() if tf in store.timeframes(x)]
    if scope == "coin":
        return [symbol]
    if isinstance(scope, list):
        return [x for x in dict.fromkeys(scope) if x in have]
    if isinstance(scope, int):
        key = (tf, len(have))
        if key not in _RANK:
            n30 = max(1, int(30 * 86_400_000 / TF_MS[tf]))
            vol = {}
            for x in have:
                try:
                    b = store.get(x, tf)
                    vol[x] = float((np.asarray(b.v[-n30:], float) * np.asarray(b.c[-n30:], float)).sum())
                except (ValueError, KeyError, OSError):
                    continue
            _RANK[key] = sorted(vol, key=lambda s: -vol[s])
        top = _RANK[key][:scope]
        return ([symbol] if symbol in have and symbol not in top else []) + top
    return have


def _prep(store, symbol, tf, swing, scope, live, progress, htf="auto", live_htf=None, min_leg=0.0):
    """Struktur sekarang + kejadian pola yang sama di riwayat (dipakai Screener & Cek entry posisi).
    Lalu: pembanding (arah normal), tren TF besar & kemiripan ukuran leg -> kombinasi yang paling tepat di 30% data
    terakhir dipakai untuk semua angka sesudahnya."""
    if tf not in TF_MS:
        raise ValueError("TF tidak dikenal")
    k = SWINGS.get(swing, 3)
    src = "binance"
    if live is None:
        src = "lokal"
        b = store.get(symbol, tf)
        lt, lh, ll, lc = (np.asarray(x, float)[-1500:] for x in (b.t, b.h, b.l, b.c))
        lo_ = np.asarray(b.o, float)[-1500:]
    else:
        lt, lo_, lh, ll, lc = (np.asarray(x, float) for x in live)
    la = _atr(lh, ll, lc, 14)
    lev = events(lh, ll, lc, la, k, min_leg)
    if not lev:
        raise ValueError("struktur belum terbentuk (data terlalu sedikit)")
    s_now, seq_now = lev[-1]
    # riwayat
    syms = history_symbols(store, symbol, tf, scope)
    hist = []
    for i, sym in enumerate(syms):
        if progress:
            progress(i, len(syms), sym, None)
        try:
            hist.append((sym, coin_events(store, sym, tf, k, min_leg=min_leg)))
        except (ValueError, KeyError, OSError):
            continue
    # panjang pola otomatis
    pick, occ = None, []
    for L in LENS:
        want = _labels(seq_now, L)
        if want is None:
            continue
        found = []
        wc = _code(seq_now, L)
        for sym, D in hist:                                          # pencarian cepat: kode label (sama persis dengan _labels)
            n = len(D["c"])
            idx = np.flatnonzero((D["codes"][L] == wc) & (D["ev_s"] + SL.HOLD + SL.FILL_WAIT < n))
            ev = D["ev"]
            found.extend((sym, ev[j][0], ev[j][1]) for j in idx)
        if len(found) >= MIN_OCC or L == LENS[-1]:
            pick, occ = L, found
            break
        if pick is None:
            pick, occ = L, found
    want = _labels(seq_now, pick)
    flt = _filters(store, symbol, tf, k, hist, occ, pick, lt, lh, ll, lc, la, s_now, seq_now, htf, live_htf, min_leg)
    occ = flt.pop("_occ")
    return {"k": k, "src": src, "lt": lt, "lo": lo_, "lh": lh, "ll": ll, "lc": lc, "la": la, "s_now": s_now, "seq_now": seq_now,
            "hist": hist, "pick": pick, "occ": occ, "want": want, "filters": flt}


def _filters(store, symbol, tf, k, hist, occ, pick, lt, lh, ll, lc, la, s_now, seq_now, htf, live_htf, min_leg=0.0):
    """1) pembanding, 2) tren TF besar, 3) leg mirip. Tiap kombinasi dinilai di 30% kejadian terakhir:
    arah mayoritas dari 70% awal dipakai menebak 30% terakhir -> % tebakan benar. Yang terbaik dipakai."""
    D_of = dict(hist)
    step = TF_MS[tf]
    # pembanding (koin-koin riwayat yang sama)
    bu = bd = 0
    for sym in {o[0] for o in occ} or {symbol}:
        try:
            u, d_ = _baseline(store, sym, tf, k, min_leg)
        except (ValueError, KeyError, OSError):
            continue
        bu, bd = bu + u, bd + d_
    base = {"up": bu, "down": bd, "pct_up": 100 * bu / max(1, bu + bd), "pct_down": 100 * bd / max(1, bu + bd)}
    out = {"base": base, "htf": None, "htf_now": None, "legs_now": None, "mode": "pola", "modes": []}
    if not occ:
        out["_occ"] = occ
        return out
    # arah duluan tiap kejadian + waktu
    info = []
    for sym, s, seq in occ:
        D = D_of[sym]
        d_, _ = _first_move(D["h"], D["l"], D["c"], D["a"], s)
        info.append((d_, D["t"][s]))
    times = np.array([x[1] for x in info], float)
    t_split = float(np.quantile(times, 0.7))
    # 2) tren TF besar
    H = resolve_htf(tf, htf)
    htf_now, tr_of = None, None
    if H:
        try:
            if live_htf is not None:
                ht, hh_, hl_, hc_ = (np.asarray(x, float) for x in (live_htf[0], live_htf[2], live_htf[3], live_htf[4]))
                ha = _atr(hh_, hl_, hc_, 14)
                ev = events(hh_, hl_, hc_, ha, 3)
                htf_now = _trend(ev[-1][1]) if ev else None
            else:
                Dn = coin_events(store, symbol, H, 3)
                htf_now = _htf_trend_at(Dn, float(lt[-1]) + step)
        except (ValueError, KeyError, OSError, IndexError):
            htf_now = None
        tr_of = []
        cache = {}
        for sym, s, _ in occ:
            if sym not in cache:
                try:
                    cache[sym] = coin_events(store, sym, H, 3)
                except (ValueError, KeyError, OSError):
                    cache[sym] = None
            Dh = cache[sym]
            tr_of.append(_htf_trend_at(Dh, float(D_of[sym]["t"][s]) + step) if Dh is not None else None)
    out["htf"], out["htf_now"] = H, htf_now
    # 3) ukuran leg (ATR) -> jarak ke sekarang
    legs_now = _legs(seq_now, pick, la[s_now])
    dist = None
    if legs_now is not None and len(legs_now):
        dist = []
        for sym, s, seq in occ:
            lg = _legs(seq, pick, D_of[sym]["a"][s])
            dist.append(float(np.abs(lg - legs_now).mean()) if lg is not None and len(lg) == len(legs_now) else np.inf)
        dist = np.array(dist)
        out["legs_now"] = [round(float(x), 2) for x in legs_now]

    def score(mask):
        idx = np.flatnonzero(mask)
        fit = [info[i][0] for i in idx if times[i] < t_split and info[i][0]]
        tst = [info[i][0] for i in idx if times[i] >= t_split and info[i][0]]
        allm = [info[i][0] for i in idx if info[i][0]]
        up = sum(1 for x in allm if x == 1)
        res = {"n": int(len(idx)), "pct_up": 100 * up / max(1, len(allm)), "pct_down": 100 * (len(allm) - up) / max(1, len(allm)),
               "n_test": len(tst), "test_hit": None}
        if fit and tst:
            maj = 1 if sum(1 for x in fit if x == 1) >= len(fit) / 2 else -1
            res["test_hit"] = 100 * sum(1 for x in tst if x == maj) / len(tst)
        return res
    allmask = np.ones(len(occ), bool)
    cands = [("pola", allmask)]
    if tr_of is not None and htf_now:
        hm = np.array([t == htf_now for t in tr_of])
        cands.append(("pola + tren " + H.upper(), hm))
    if dist is not None and np.isfinite(dist).any():
        kkeep = max(MIN_OCC, int(np.ceil(SIM_KEEP * np.isfinite(dist).sum())))
        thr = np.sort(dist[np.isfinite(dist)])[min(kkeep, int(np.isfinite(dist).sum())) - 1]
        sm = dist <= thr
        cands.append(("pola + leg mirip", sm))
        if tr_of is not None and htf_now:
            cands.append(("pola + tren " + H.upper() + " + leg mirip", sm & np.array([t == htf_now for t in tr_of])))
    best_name, best_sc = "pola", None
    for name, m in cands:
        sc = score(m)
        sc["name"] = name
        ok = sc["n"] >= MIN_OCC and sc["n_test"] >= MIN_TEST and sc["test_hit"] is not None
        sc["eligible"] = bool(ok)
        out["modes"].append(sc)
        if name == "pola":
            best_sc = sc
            continue
        # filter dipakai hanya kalau tebakan di data uji LEBIH tepat (minimal +2%) dan sampel cukup
        if ok and best_sc and best_sc.get("test_hit") is not None and sc["test_hit"] >= best_sc["test_hit"] + 2:
            best_name, best_sc = name, sc
    out["mode"] = best_name
    mask = dict(cands)[best_name]
    out["_occ"] = [o for o, m in zip(occ, mask) if m]
    out["n_all"] = len(occ)
    return out


def screen(store, symbol, tf, swing="kecil", scope="all", live=None, progress=None, htf="auto", live_htf=None, live_ev=None,
           rrs=None, min_wr=None, min_leg=0.0, bounce=False, walls=None):
    """live = (t, o, h, l, c) candle TERTUTUP terbaru dari Binance (atau None -> data lokal koin itu).
    htf = TF besar untuk filter tren ("auto", "off", atau TF mis. "4h"); live_htf = candle TF besar dari Binance."""
    t0 = time.time()
    RRS_ = list(rrs or RRS)              # rrs / min_wr hanya dipakai 🔎 Scan banyak koin (screen 1 koin tetap seperti biasa)
    P_ = _prep(store, symbol, tf, swing, scope, live, progress, htf, live_htf, min_leg)
    src, lt, lo_, lh, ll, lc, la = P_["src"], P_["lt"], P_["lo"], P_["lh"], P_["ll"], P_["lc"], P_["la"]
    s_now, seq_now, hist, pick, occ, want = P_["s_now"], P_["seq_now"], P_["hist"], P_["pick"], P_["occ"], P_["want"]
    if not occ:
        return {"symbol": symbol, "tf": tf, "swing": swing, "source": src, "pattern": list(want or []), "len": pick, "n_occ": 0,
                "filters": P_["filters"],
                "elapsed": round(time.time() - t0, 1), **_visual(lt, lo_, lh, ll, lc, la, seq_now, s_now, None, None)}
    times = np.array([dict(hist)[sym]["t"][s] for sym, s, _ in occ])
    t_split = float(np.quantile(times, 0.7))
    nxt, fm, fm_bars = {}, [], {1: [], -1: []}
    paths = []                                                   # (arah duluan, close/high/low relatif dalam ATR, N_PATH candle)
    acc = {}
    evq = {}                                                     # kejadian per aturan (evaluasi entry, scan banyak koin)
    D_of = dict(hist)
    examples = []
    for sym, s, seq in occ:
        D = D_of[sym]
        h, l, c, a, t = D["h"], D["l"], D["c"], D["a"], D["t"]
        A = a[s]
        # swing berikutnya
        evs = D["ev"]
        j = next((ii for ii, (ss, _) in enumerate(evs) if ss == s), None)
        if j is not None and j + 1 < len(evs):
            ns, nseq = evs[j + 1]
            last = nseq[-1]
            lab = last[3] or "?"
            nxt[lab] = nxt.get(lab, 0) + 1
        d_, b_ = _first_move(h, l, c, a, s)
        fm.append(d_)
        if d_:
            fm_bars[d_].append(b_)
        if A == A and A > 0 and s + N_PATH < len(c):
            seg = slice(s + 1, s + 1 + N_PATH)
            paths.append((d_, (c[seg] - c[s]) / A, (h[seg] - c[s]) / A, (l[seg] - c[s]) / A, sym, int(t[s]), s))
        te = t[s] >= t_split
        for d in (0, 1):
            r = _entries(d, seq, s, h, l, c, a)
            if r is None:
                continue
            E, base, ext = r
            g = AG.get_ctx(D, h, l, c)
            for en, e in E.items():
                f = SL._fill(d, s, e, ext, h, l, en)
                for sk, slp in _stops(g, s, d, e).items():
                    risk = (e - slp) if d == 0 else (slp - e)
                    if not (SL.MIN_RISK * A <= risk <= SL.MAX_RISK * A):
                        continue
                    res = None if f is None else SL._outcome(d, f, e, slp, RRS_, h, l, c, en == "market")
                    bn = bool(bounce and res is not None and _bounce(d, f, e, slp, h, l, c, en == "market")[0])
                    if bounce:                                   # disimpan untuk evaluasi entry (geser entry di kejadian yang sama)
                        evq.setdefault((d, en, sk), []).append((sym, s, e, slp, ext, bool(te)))
                    for ri, rr in enumerate(RRS_):
                        X = acc.setdefault((d, en, sk, rr), {"sig": 0, "fill": 0, "w": 0, "r": 0.0, "fillt": 0, "wt": 0, "rt": 0.0})
                        X["sig"] += 1
                        if res is not None:
                            R_, code, ix = res[ri]
                            X.setdefault("seq", []).append((int(t[s]), float(R_)))
                            # lama (candle): sampai terisi, lalu dari terisi sampai kena TP / SL
                            X.setdefault("fb", []).append(f - s)
                            if code == 1:
                                X.setdefault("tpb", []).append(ix - f)
                            elif code == -1:
                                X.setdefault("slb", []).append(ix - f)
                            X.setdefault("occ", []).append((sym, s, code == 1, bool(te)))   # untuk kelas A/B/C
                            X["fillt" if te else "fill"] += 1
                            X["wt" if te else "w"] += code == 1
                            X["rt" if te else "r"] += R_
                            X["bn"] = X.get("bn", 0) + bn
        if len(examples) < 400:
            examples.append({"symbol": sym, "time": int(t[s]), "first_move": d_,
                             "swings": [{"time": int(t[x[0]]), "price": x[1], "label": x[3]} for x in seq[-pick:]]})
    rules = []
    for (d, en, sk, rr), X in acc.items():
        nf = X["fill"] + X["fillt"]
        if X["fill"] < MIN_FILL:
            continue
        ex, wr = X["r"] / X["fill"], 100 * X["w"] / X["fill"]
        ext = X["rt"] / X["fillt"] if X["fillt"] else None
        wrt = 100 * X["wt"] / X["fillt"] if X["fillt"] else None
        fp = 100 * nf / X["sig"] if X["sig"] else 0.0
        rk = risk_seq([r for _, r in sorted(X.get("seq", []))])          # urut waktu (semua koin digabung)
        rules.append({"dir": d, "entry": en, "sl": sk, "rr": rr, "n": X["fill"], "wr": wr, "exp_r": ex, "n_test": X["fillt"], "wr_test": wrt,
                      "exp_test": ext, "fill_pct": fp,
                      # R per SINYAL = R per trade x peluang terisi: limit yang jarang tersentuh tidak boleh menang hanya karena
                      # hasilnya bagus di sedikit kejadian yang terisi (sisanya harga pergi tanpa kita)
                      "exp_sig": ex * fp / 100, "bounce_pct": (100 * X.get("bn", 0) / nf) if bounce and nf else None, "max_loss_streak": rk["max_loss_streak"], "max_dd": rk["max_dd"],
                      "fill_bars": _med(X.get("fb")), "tp_bars": _med(X.get("tpb")), "sl_bars": _med(X.get("slb")),
                      "entry_txt": _entry_txt(en, d), "sl_txt": AG.txt(),
                      "proven": bool(ex > 0 and ext is not None and ext > 0 and X["fillt"] >= 5)})
    rules.sort(key=lambda r: (not r["proven"], -r["exp_sig"]))
    fm = np.array(fm)
    up, dn = int((fm == 1).sum()), int((fm == -1).sum())
    pred = {"up": up, "down": dn, "unclear": int((fm == 0).sum()), "pct_up": 100 * up / max(1, up + dn), "pct_down": 100 * dn / max(1, up + dn),
            "next": sorted([{"label": k_, "n": v, "pct": 100 * v / sum(nxt.values())} for k_, v in nxt.items()], key=lambda x: -x["n"]) if nxt else [],
            "move_atr": MOVE_ATR,
            "bars_up": float(np.median(fm_bars[1])) if fm_bars[1] else None,
            "bars_down": float(np.median(fm_bars[-1])) if fm_bars[-1] else None}
    # 1) pembanding: arah normal setelah swing apa pun -> keunggulan pola & apakah meyakinkan (uji binomial kasar)
    B0 = P_["filters"]["base"]
    if B0["up"] + B0["down"] and up + dn:
        p0 = B0["pct_up"] / 100
        maj_up = pred["pct_up"] >= 50
        edge = (pred["pct_up"] - B0["pct_up"]) if maj_up else (pred["pct_down"] - B0["pct_down"])
        z = abs(pred["pct_up"] / 100 - p0) / max(1e-9, (p0 * (1 - p0) / (up + dn)) ** 0.5)
        pred.update(base_up=B0["pct_up"], base_down=B0["pct_down"], edge=edge, z=float(z),
                    edge_txt="meyakinkan" if z >= 2 and edge > 0 else "lemah" if z >= 1 and edge > 0 else "bisa kebetulan")
    # jalur prediksi dari riwayat: median kejadian yang arahnya sama dengan mayoritas + pita 25-75% semua kejadian
    if paths:
        maj = 1 if pred["pct_up"] >= 50 else -1
        grp = [x for x in paths if x[0] == maj] or paths
        Cm, Hm, Lm = (np.array([x[i] for x in grp]) for i in (1, 2, 3))
        Ca = np.array([x[1] for x in paths])
        pred["path"] = {"dir": maj, "n": len(grp), "n_all": len(paths),
                        "close": np.median(Cm, 0).round(3).tolist(), "high": np.median(Hm, 0).round(3).tolist(),
                        "low": np.median(Lm, 0).round(3).tolist(),
                        "p25": np.percentile(Ca, 25, 0).round(3).tolist(), "p75": np.percentile(Ca, 75, 0).round(3).tolist()}
        # contoh nyata paling mirip median (dipakai untuk candle bayangan: naik-turunnya asli dari riwayat)
        med = np.median(Cm, 0)
        k = int(np.argmin([np.abs(x[1] - med).mean() for x in grp]))
        ex = grp[k]
        # jalur nyata DIPERPANJANG sampai batas trade (limit 48 + tahan 200 candle) -> animasi bisa sampai kena TP / SL
        Dx, sx = D_of[ex[4]], ex[6]
        Ax, cx = Dx["a"][sx], Dx["c"][sx]
        e2 = min(len(Dx["c"]), sx + 1 + SL.HOLD + SL.FILL_WAIT)
        pred["path"]["real"] = {"symbol": ex[4], "time": ex[5],
                                "close": np.round((Dx["c"][sx + 1:e2] - cx) / Ax, 3).tolist(),
                                "high": np.round((Dx["h"][sx + 1:e2] - cx) / Ax, 3).tolist(),
                                "low": np.round((Dx["l"][sx + 1:e2] - cx) / Ax, 3).tolist()}
    # terapkan ke sekarang: aturan terbaik yang bisa dipakai di struktur sekarang (per arah)
    plans = []
    g_now = AG.Ctx(lh, ll, lc)                                   # SL live: anti-gocekan + tembok order book (kalau ada)
    for d in (0, 1):
        r = _entries(d, seq_now, s_now, lh, ll, lc, la)
        if r is None:
            continue
        E, base, ext = r
        A = la[s_now]
        cand = []
        for rule in [x for x in rules if x["dir"] == d]:
            if rule["entry"] not in E:
                continue
            e = E[rule["entry"]]
            slp = AG.sl_at(g_now, s_now, d == 0, e, walls, detail=True)
            if slp is None:
                continue
            sl_info = slp
            slp = slp["sl"]
            risk = (e - slp) if d == 0 else (slp - e)
            if not (SL.MIN_RISK * A <= risk <= SL.MAX_RISK * A):
                continue
            tp = e + rule["rr"] * risk if d == 0 else e - rule["rr"] * risk
            age = len(lc) - 1 - s_now
            status, live = _status(d, rule["entry"], e, slp, tp, ext, s_now, lh, ll, age)
            fill_ok = rule["entry"] == "market" or (rule["fill_pct"] or 0) >= MIN_FILL_PCT
            profit_ok = bool(rule["exp_sig"] > 0 and rule["proven"])          # untung DAN tetap untung di data uji
            wr_ok = min_wr is None or (rule["wr"] >= min_wr and (rule["wr_test"] is None or rule["n_test"] < 5 or rule["wr_test"] >= min_wr))
            why = None if live and fill_ok and profit_ok and wr_ok else (
                status if not live else f"jarang terisi ({rule['fill_pct']:.0f}% < {MIN_FILL_PCT:.0f}%)" if not fill_ok
                else "rata-rata rugi" if rule["exp_sig"] <= 0 else "rugi di data uji (belum terbukti)" if not profit_ok
                else f"lebih sering kalah (WR {rule['wr']:.0f}%" + (f", data uji {rule['wr_test']:.0f}%" if rule["wr_test"] is not None else "") + f" < {min_wr:.0f}%)")
            exp_t = int(lt[s_now] + (SL.FILL_WAIT + 1) * TF_MS[tf]) if rule["entry"] != "market" else None
            cand.append({**rule, "price_entry": float(e), "price_sl": float(slp), "price_tp": float(tp), "risk_pct": float(risk / e * 100),
                         "age": int(age), "status": status, "live": live, "fill_ok": bool(fill_ok), "profit_ok": profit_ok, "wr_ok": bool(wr_ok),
                         "usable": why is None, "why_not": why, "expires": exp_t, "sl_reasons": sl_info["reasons"],
                         "sl_walls": bool(walls),
                         "ext": float(ext), "confirm_time": int(lt[s_now])})
        us = [x for x in cand if x["usable"]]
        if bounce and us:                                            # scan banyak koin: dari yang layak, pilih yang paling sering MANTUL
            plans.append(max(us, key=lambda x: (round((x["bounce_pct"] or 0) / 5), x["exp_sig"])))
        elif cand:                                                   # utamakan yang bisa dipasang (berlaku, sering terisi, untung)
            plans.append(next((x for x in cand if x["usable"]), next((x for x in cand if x["live"] and x["profit_ok"] and x["wr_ok"]),
                                                                         next((x for x in cand if x["live"] and x["profit_ok"]), cand[0]))))
    plans.sort(key=lambda p: (not p["usable"], not p["live"], not p["proven"], -p["exp_sig"]))
    # kelas A/B/C + Elliott: bukti di tiap kejadian aturan itu (tidak membuang setup)
    if plans:
        try:
            V_now = now_votes(store, symbol, tf, lt, lo_, lh, ll, lc, live_ev)
            for p in plans:
                X = acc.get((p["dir"], p["entry"], p["sl"], p["rr"])) or {}
                p["evidence"] = grade_trades(store, tf, X.get("occ", []), p["dir"], V_now)
        except (ValueError, KeyError, IndexError) as ex:
            for p in plans:
                p["evidence"] = {"note": f"bukti tidak bisa dihitung: {ex}"}
    if bounce:                                                   # scan banyak koin: entry dievaluasi (pilihan kedua untuk user)
        for p in plans:
            if p["usable"]:
                p["eval"] = _eval_entry(p, evq.get((p["dir"], p["entry"], p["sl"]), []), D_of, float(lc[-1]), min_wr)
                p["bounce_pct"], p["main_pct"] = p["eval"]["signal"]["clean_pct"], p["eval"]["signal"]["main_pct"]
    # sinyal utama hanya setup yang masih berlaku, SERING TERISI (>= 70%) dan TIDAK RUGI (untung + terbukti di data uji)
    best = next((p for p in plans if p["usable"]), None)
    last = None if best else (plans[0] if plans else None)
    vis = _visual(lt, lo_, lh, ll, lc, la, seq_now, s_now, best, pred)
    return {"symbol": symbol, "tf": tf, "swing": swing, "scope": scope, "source": src, "pattern": list(want), "len": pick,
            "n_occ": len(occ), "n_coins": len({o[0] for o in occ}), "pred": pred, "rules": rules[:20], "plans": plans, "best": best,
            "filters": P_["filters"],
            "last_plan": last,
            "examples": examples[-150:], "now_time": int(lt[-1]), "now_price": float(lc[-1]), "confirm_time": int(lt[s_now]),
            "elapsed": round(time.time() - t0, 1), **vis}


def _status(d, en, e, sl, tp, ext, s, h, l, age):
    """Status rencana di harga sekarang -> (teks, masih_bisa_dipakai)."""
    seg_h, seg_l = h[s + 1:], l[s + 1:]
    if en == "market":
        f = s
    else:
        touch = (seg_l <= e) if d == 0 else (seg_h >= e)
        run = (seg_h > ext) if d == 0 else (seg_l < ext)
        it = int(np.argmax(touch)) if touch.any() else None
        ir = int(np.argmax(run)) if run.any() else None
        if it is None:
            if ir is not None:
                return ("batal (harga sudah membuat high baru)" if d == 0 else "batal (harga sudah membuat low baru)"), False
            if age > SL.FILL_WAIT:
                return "kedaluwarsa (limit tidak tersentuh)", False
            return "aktif · limit belum tersentuh", True
        if ir is not None and ir <= it:
            return ("batal (high baru sebelum limit tersentuh)" if d == 0 else "batal (low baru sebelum limit tersentuh)"), False
        f = s + 1 + it
    # sudah masuk: cek SL / TP sesudahnya (candle terisi ikut dicek SL-nya, sama seperti backtest)
    hh, ll_ = h[f:], l[f:]
    hit_sl = (ll_ <= sl) if d == 0 else (hh >= sl)
    hit_tp = (hh[1:] >= tp) if d == 0 else (ll_[1:] <= tp)
    isl = int(np.argmax(hit_sl)) if hit_sl.any() else None
    itp = int(np.argmax(hit_tp)) + 1 if hit_tp.any() else None
    if isl is not None and (itp is None or isl <= itp):
        return "selesai: kena SL", False
    if itp is not None:
        return "selesai: sudah kena TP", False
    if en == "market":
        return ("aktif · entry market sekarang" if age <= 3 else f"berjalan · market {age} candle lalu"), age <= 3
    return "berjalan · limit sudah terisi", False


def _visual(t, o, h, l, c, a, seq, s, best, pred, nbar=150):
    n = len(c)
    a0 = max(0, n - nbar)
    cand = [[int(t[i]), float(o[i]), float(h[i]), float(l[i]), float(c[i])] for i in range(a0, n)]
    sw = [{"time": int(t[x[0]]), "price": x[1], "label": x[3] or ("H" if x[2] == "H" else "L")} for x in seq if x[0] >= a0]
    proj = None
    if pred and (pred["up"] + pred["down"]):
        up = pred["pct_up"] >= 50
        A = a[-1] if a[-1] == a[-1] else 0
        bars = pred["bars_up"] if up else pred["bars_down"]
        if A and bars:
            dt = int(t[-1] - t[-2]) if n > 1 else 0
            proj = {"from_time": int(t[-1]), "from_price": float(c[-1]), "to_time": int(t[-1] + max(2, int(bars)) * dt),
                    "to_price": float(c[-1] + (1 if up else -1) * MOVE_ATR * A), "pct": pred["pct_up"] if up else pred["pct_down"],
                    "dir": 1 if up else -1, "bars": float(bars)}
    if proj is not None and pred.get("path"):
        proj["path"] = dict(pred["path"])
        proj["atr"] = float(A)
        try:                                                     # jalur price action (mantul di SNR minor) untuk animasi
            lv, retr, p0 = PA.minor_levels(h, l), PA.median_retrace(h, l, c), float(c[-1])
            if best:
                pa, lbl = pa_for_plan(p0, A, best["dir"] == 0, best["price_entry"], best["price_sl"], best["price_tp"], best.get("wr"),
                                      best.get("tp_bars"), best.get("sl_bars"), best.get("fill_bars") if best["entry"] != "market" else None,
                                      lv, retr, "riwayat aturan ini")
            else:
                upm = proj["dir"] > 0
                tgt = p0 + (1 if upm else -1) * MOVE_ATR * A
                pa = PA.build(p0, p0, p0 - (1 if upm else -1) * 3 * A, tgt, upm, "tp", proj["bars"], A, lv, retr, seed=int(t[-1]) % 9973)
                lbl = None
            if pa:
                proj["path"].update(pa=pa, label=lbl, target_r=pa["close"][-1])
        except (ValueError, KeyError, IndexError, TypeError):
            pass
    return {"candles": cand, "swings_vis": sw, "proj": proj}


def pa_for_plan(p0, A, long, e, sl, tp, wr, tp_bars, sl_bars, fill_bars, levels, retr, where, sl_rate=None):
    """Jalur price action untuk 1 rencana: hasil yang paling sering (TP kalau WR >= 50%, atau >= % kena SL kalau
    diketahui) & lama dari riwayat."""
    outcome = "tp" if (wr or 0) >= (50 if sl_rate is None else sl_rate) else "sl"
    bars = tp_bars if outcome == "tp" else sl_bars
    if not bars:
        return None, None
    pa = PA.build(p0, e, sl, tp, long, outcome, min(240.0, float(bars)), A, levels, retr, fill_bars=fill_bars,
                  seed=int(abs(p0) * 1000) % 9973)
    lbl = f"{'✅ kena TP' if outcome == 'tp' else '❌ kena SL'} paling sering ({(wr or 0):.0f}% TP duluan, {where})"
    return pa, lbl


def summary(r):
    """Ringkasan 1 koin untuk tabel scan banyak koin."""
    P, B, F = r.get("pred") or {}, r.get("best"), r.get("filters") or {}
    down = (P.get("pct_down") or 0) > (P.get("pct_up") or 0)
    lp = r.get("last_plan")
    return {"symbol": r["symbol"], "pattern": r.get("pattern"), "n_occ": r.get("n_occ", 0), "n_coins": r.get("n_coins", 0),
            "dir_pred": -1 if down else 1, "pct": P.get("pct_down") if down else P.get("pct_up"), "edge": P.get("edge"),
            "edge_txt": P.get("edge_txt"), "htf_now": F.get("htf_now"), "htf": F.get("htf"), "mode": F.get("mode"),
            "usable": bool(B), "dir": B["dir"] if B else None, "entry": B["entry"] if B else None,
            "price_entry": B["price_entry"] if B else None, "price_sl": B["price_sl"] if B else None,
            "price_tp": B["price_tp"] if B else None, "rr": B["rr"] if B else None, "fill_pct": B["fill_pct"] if B else None,
            "wr": B["wr"] if B else None, "exp_sig": B["exp_sig"] if B else None, "bounce_pct": B.get("bounce_pct") if B else None, "main_pct": B.get("main_pct") if B else None,
            "eval": ({k: B["eval"][k] for k in ("signal", "best", "same")} if B and B.get("eval") else None), "status": B["status"] if B else None,
            "max_loss_streak": B.get("max_loss_streak") if B else None, "max_dd": B.get("max_dd") if B else None,
            "why_not": None if B else (lp.get("why_not") or lp.get("status")) if lp else "tidak ada aturan RR >= 1:3 yang untung",
            "now_price": r.get("now_price"), "source": r.get("source"),
            "evidence": {k: (B or lp or {}).get("evidence", {}).get(k) for k in ("grade", "agree", "against", "n_items", "note")}
            if (B or lp) else None}
