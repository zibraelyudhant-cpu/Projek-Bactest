"""Pembungkus umum: menu studi (Tes SNR, Penemu Strategi, Indikator Tester) dijalankan PARALEL di semua inti CPU,
bisa DIJEDA & DILANJUTKAN (lihat pausable.py), dan hasilnya otomatis DISIMPAN (results_store.py).

Modul studi menyediakan fungsi tingkat modul:
  _init_worker(data_dir)                 -> dipanggil di tiap proses paralel
  job_total(q, symbols)                  -> jumlah tugas
  job_state(q, symbols)                  -> keadaan awal (bisa di-pickle)
  job_call(state, q, symbols, i)         -> (fungsi, argumen) tugas ke-i
  job_merge(state, q, symbols, i, res)   -> gabungkan hasil tugas ke-i (dipanggil URUT 0, 1, 2, ... -> hasil sama persis
                                            dengan dihitung satu per satu)
  job_finalize(state, q, symbols, partial=False) -> hasil akhir (atau hasil sementara)
  job_ready(state, q, symbols, i)        -> (opsional) boleh kirim tugas ke-i sekarang?
"""
import time
import uuid

from . import results_store
from .pausable import PausableJobs


class StudyJobs(PausableJobs):
    def __init__(self, kind, mod, data_dir, paused_dir=None, partial_every=0.0):
        self._kind = kind
        self.mod = mod
        self.data_dir = data_dir
        self.partial_every = partial_every
        super().__init__(paused_dir)

    @property
    def KIND(self):   # noqa: N802
        return self._kind

    def start(self, symbols, q, workers=None, label=""):
        from .sysinfo import recommended_workers
        workers = max(1, min(int(workers or recommended_workers()), 32))
        symbols = list(symbols)
        job = self._new(uuid.uuid4().hex[:10], self.mod.job_total(q, symbols), workers, symbols=symbols, q=q,
                        state=self.mod.job_state(q, symbols), buffer={}, next=0, result=None, partial=None,
                        partial_at=0.0, times=[], recent=[], label=label, saved_id=None)
        self._launch(job)
        return job["id"]

    def pool_init(self):
        return self.mod._init_worker, (self.data_dir,)

    def task_call(self, job, i):
        return self.mod.job_call(job["state"], job["q"], job["symbols"], i)

    def ready(self, job, i):
        f = getattr(self.mod, "job_ready", None)
        return True if f is None else f(job["state"], job["q"], job["symbols"], i)

    def on_error(self, job, i, ex):
        return f"{type(ex).__name__}: {ex}"

    def on_result(self, job, i, res):
        job["buffer"][i] = res
        while job["next"] in job["buffer"]:                     # gabung urut supaya hasil sama persis
            k = job["next"]
            self.mod.job_merge(job["state"], job["q"], job["symbols"], k, job["buffer"].pop(k))
            job["next"] += 1
        sym = job["symbols"][i % len(job["symbols"])] if job["symbols"] else "?"
        job["times"].append(time.time())
        job["recent"] = ([{"symbol": f"{sym}|{'dilewati' if isinstance(res, str) else 'selesai'}", "error": isinstance(res, str)}]
                         + job["recent"])[:8]
        if self.partial_every and time.time() - job["partial_at"] >= self.partial_every:
            job["partial"] = self.mod.job_finalize(job["state"], job["q"], job["symbols"], partial=True)
            job["partial_at"] = time.time()

    def finish(self, job):
        job["result"] = self.mod.job_finalize(job["state"], job["q"], job["symbols"], partial=False)
        try:
            job["saved_id"] = results_store.save(self._kind, job["result"], job["q"], job.get("label"), job["symbols"])
            job["result"]["saved_id"] = job["saved_id"]
        except Exception:                                       # noqa: BLE001 - gagal simpan tidak boleh menggagalkan hasil
            pass

    def status(self, jid):
        job = self.jobs.get(jid)
        if not job:
            return None
        t, left = job.get("times") or [], job["total"] - job["done"]
        eta = None
        if len(t) >= 3 and left > 0:
            k = min(len(t) - 1, 30)
            eta = left * (t[-1] - t[-1 - k]) / k
        return {"id": jid, "kind": self._kind, "status": job["status"], "done": job["done"], "total": job["total"],
                "recent": job.get("recent", []), "elapsed": round(self.elapsed(job), 1), "eta": eta, "error": job.get("error"),
                "workers": job.get("workers"), "inflight": job.get("inflight", 0) if job.get("thread_alive") else 0,
                "result": job["result"] if job["status"] == "done" else None,
                "partial": job.get("partial") if job["status"] in ("running", "paused") else None}
