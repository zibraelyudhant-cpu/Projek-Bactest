"""🧭 Penentu Arah: semua sinyal strategi tetap diambil, model hanya MEMBALIK arah kalau yakin arah sebaliknya lebih
sering benar. Jumlah sinyal tidak berkurang.

Alur (disetujui pemilik):
  1. Sinyal riwayat strategi pilihan diputar ulang di data candle lokal banyak koin (logika sama dengan 🛡️ SL Backtest;
     ditambah 💧 Liquidity Sweep & 📈 MA Analisis). Satu sinyal = (candle sinyal, arah); beberapa jenis entry di candle
     yang sama dihitung satu kali.
  2. Jawaban tiap sinyal: harga lebih dulu bergerak +2 ATR atau -2 ATR dari close sinyal (batas 5 hari). Tidak sampai
     dua-duanya = "tidak bergerak" (tidak dihitung benar / salah).
  3. Faktor dicatat HANYA dari data yang sudah ada saat candle sinyal close (tanpa mengintip masa depan):
       tren  — tren TF besar (4H, 1D dirakit dari data lokal) & arah BTC (TF sama dan 4H)
       mom   — RSI, ADX (trend / sideway), jarak ke EMA200, gerak 12 candle, volatilitas
       order — order transaksi dari candle: perkiraan delta volume (posisi close x volume), lonjakan volume
       flow  — flow whale Binance (OI, taker beli/jual asli, long/short top trader, funding): riwayat hanya ±30 hari
       waktu — sesi, akhir pekan, struktur swing (HH/HL - LH/LL), posisi di range 50 candle
  4. Regresi logistik belajar di 70% data awal tiap koin: "yakin berapa % arah asli strategi SALAH".
  5. Ambang yakin dicari di bagian akhir data belajar yang tidak dipakai saat model belajar (supaya jujur), lalu model
     dilatih ulang dengan seluruh 70%. Sinyal dengan keyakinan >= ambang dibalik, sisanya tetap arah asli.
  6. Dinilai di 30% data terakhir (tidak pernah dilihat model). Naik = ✅ terbukti, tidak = ❌ tidak membantu.
"""
import json
import os
import time

import numpy as np

from . import antigocek as AG
from . import slbt as SB
from .data import TF_MS, aggregate, Bars
from .indicators import adx as _adx, atr as _atr, ema as _ema, pivots, rsi as _rsi

VERSION = 1
MOVE_ATR = 2.0
HOLD_DAYS = 5
SPLIT = 0.7
STRATS = {**SB.STRATS, "sweep": "💧 Liquidity Sweep (TA Pro)", "maa": "📈 MA Analisis (EMA 200 + RSI 14 overbought/oversold)"}
GROUPS = {"tren": "Tren TF besar + arah BTC", "mom": "Momentum & kondisi market", "order": "Order transaksi (delta & lonjakan volume)",
          "flow": "Flow whale (OI · taker · L/S · funding)", "waktu": "Waktu & struktur"}
# (kode, grup, nama tampil, arti kalau koefisien + / -)  - nilai "searah" sudah dikali arah sinyal (+ = mendukung arah strategi)
FEATS = [
    ("dir", "dasar", "Arah sinyal (LONG = +1)", ""),
    ("htf4", "tren", "Tren 4H searah sinyal", "sinyal melawan tren 4H sering salah"),
    ("htf1d", "tren", "Tren 1D searah sinyal", "sinyal melawan tren harian sering salah"),
    ("btc", "tren", "Arah BTC (TF sama) searah", "sinyal melawan arah BTC sering salah"),
    ("btc4", "tren", "Arah BTC 4H searah", "sinyal melawan BTC 4H sering salah"),
    ("btcmv", "tren", "Gerak BTC 12 candle searah (ATR)", "BTC baru bergerak berlawanan = sinyal sering salah"),
    ("rsi", "mom", "RSI searah (RSI-50)", "momentum searah = lebih sering benar"),
    ("adx", "mom", "ADX (kuat trend)", "saat trend kuat strategi lebih sering salah / benar"),
    ("ema200", "mom", "Jarak ke EMA200 searah (ATR)", "harga di sisi EMA200 yang searah = lebih sering benar"),
    ("mv12", "mom", "Gerak 12 candle searah (ATR)", "sudah bergerak jauh searah = sering kehabisan tenaga"),
    ("vol", "mom", "Volatilitas (ATR %)", "pasar sangat bergejolak mengubah peluang"),
    ("delta", "order", "Delta volume 12 candle searah", "tekanan transaksi searah = lebih sering benar"),
    ("delta3", "order", "Delta volume 3 candle searah", "tekanan transaksi terbaru searah"),
    ("spike", "order", "Lonjakan volume (x rata-rata)", "volume besar di candle sinyal"),
    ("spikedir", "order", "Lonjakan volume searah candle", "volume besar searah = dorongan nyata"),
    ("f_ok", "flow", "Data flow tersedia (30 hari terakhir)", ""),
    ("f_oi", "flow", "Perubahan OI x arah harga searah", "harga + OI searah = posisi baru mendorong arah sinyal"),
    ("f_tk", "flow", "Taker beli/jual asli searah", "taker searah = lebih sering benar"),
    ("f_ls", "flow", "Long/short top trader searah", "top trader menambah posisi searah"),
    ("f_fr", "flow", "Funding searah (ramai di sisi sinyal)", "pasar terlalu ramai di sisi sinyal = sering berbalik"),
    ("s_asia", "waktu", "Sesi Asia 00–07 UTC", ""),
    ("s_lon", "waktu", "Sesi London 07–12 UTC", ""),
    ("s_ovl", "waktu", "London–New York 12–16 UTC", ""),
    ("s_ny", "waktu", "New York 16–21 UTC", ""),
    ("wkend", "waktu", "Akhir pekan", ""),
    ("struct", "waktu", "Struktur swing searah (HH/HL vs LH/LL)", "struktur searah = lebih sering benar"),
    ("rng", "waktu", "Posisi di range 50 candle searah", "sinyal di ujung range yang searah sering kehabisan ruang"),
]
FK = [f[0] for f in FEATS]
NF = len(FK)
EX_KEEP = 300
_CACHE = {}


def hold_bars(tf):
    return max(2, int(HOLD_DAYS * 86_400_000 // TF_MS[tf]))


# ================================================================== sinyal: list (s, d) unik
def _sig_sweep(D):
    from . import sweeplab as SW
    t, o, h, l, c, v, a = D["t"], D["o"], D["h"], D["l"], D["c"], D["v"], D["a"]
    out = [(e["s"], 1) for e in SW.events_long(t, o, h, l, c, v, a)]
    out += [(e["s"], -1) for e in SW.events_long(t, -o, -l, -h, -c, v, a)]       # sweep high = cermin sweep low
    return out


def _sig_maa(D):
    from . import maa as MA_
    up, dn = MA_.touches(D, MA_.ma_of(D["c"], "ema", 200))
    cu, cd, _v = MA_.ind_cond(D, "rsi", 14)
    with np.errstate(invalid="ignore"):
        return [(int(s), 1) for s in np.flatnonzero(up & cu)] + [(int(s), -1) for s in np.flatnonzero(dn & cd)]


def signals(strat, D, tf, store=None, sym=None):
    if strat == "sweep":
        raw = _sig_sweep(D)
    elif strat == "maa":
        raw = _sig_maa(D)
    else:
        raw = [(int(x["s"]), int(x["d"])) for x in SB.signals(strat, D, tf, store, sym)]
    return sorted(set(raw))


# ================================================================== jawaban: +-2 ATR duluan
def first_move(D, s, hold):
    """-> (arah yang benar +1 / -1 / 0 tidak bergerak, candle sampai, R LONG RR 1:2, R SHORT RR 1:2) atau None (data kurang)."""
    h, l, c, a = D["h"], D["l"], D["c"], D["a"]
    A = a[s]
    if not (A > 0) or s + hold >= len(c):
        return None
    e = c[s]
    H, L = h[s + 1:s + 1 + hold], l[s + 1:s + 1 + hold]
    iu = np.flatnonzero(H >= e + MOVE_ATR * A)
    idn = np.flatnonzero(L <= e - MOVE_ATR * A)
    u, dn = (int(iu[0]) if len(iu) else None), (int(idn[0]) if len(idn) else None)
    if u is None and dn is None:
        y, xo = 0, hold
    elif dn is None or (u is not None and u < dn):
        y, xo = 1, u + 1
    elif u is None or dn < u:
        y, xo = -1, dn + 1
    else:
        y, xo = 0, u + 1                                  # dua-duanya di candle yang sama: tidak jelas
    return y, xo, _rr(H, L, c[s + hold], e, A, 1), _rr(H, L, c[s + hold], e, A, -1)


def _rr(H, L, cend, e, A, d):
    """Trade RR 1:2 (SL 1 ATR, TP 2 ATR dari close sinyal, 5 hari): +2 / -1 / waktu habis = sisa gerak (dibatasi -1..2)."""
    if d == 1:
        sl, tp = np.flatnonzero(L <= e - A), np.flatnonzero(H >= e + 2 * A)
    else:
        sl, tp = np.flatnonzero(H >= e + A), np.flatnonzero(L <= e - 2 * A)
    js, jt = (int(sl[0]) if len(sl) else None), (int(tp[0]) if len(tp) else None)
    if js is not None and (jt is None or js <= jt):
        return -1.0
    if jt is not None:
        return 2.0
    return float(np.clip(d * (cend - e) / A, -1, 2))


# ================================================================== faktor (tanpa mengintip masa depan)
def _trend(c):
    return np.sign(_ema(c, 20) - _ema(c, 50))


def _htf(t, tf, D, ms):
    """Tren TF besar dari candle yang SUDAH close saat candle sinyal close. 0 kalau TF besar <= TF sinyal."""
    n = len(t)
    if ms <= TF_MS[tf]:
        return np.zeros(n)
    B = aggregate(Bars(t, D["o"], D["h"], D["l"], D["c"], D["v"]), ms)
    tr = _trend(np.asarray(B.c, float))
    close_sig = t + TF_MS[tf]
    j = np.searchsorted(np.asarray(B.t, np.int64) + ms, close_sig, side="right") - 1
    return np.where(j >= 0, tr[np.clip(j, 0, None)], 0.0)


def _asof_same(t, bt, x):
    j = np.searchsorted(bt, t, side="right") - 1
    return np.where(j >= 0, x[np.clip(j, 0, None)], 0.0)


def _structure(h, l, k=3):
    """+1 = 2 swing high & low terakhir naik (HH+HL), -1 = turun (LH+LL), 0 lainnya. Swing diketahui k candle sesudahnya."""
    n = len(h)
    hi, lo = pivots(h, l, k)
    out = np.zeros(n)
    sh = np.zeros(n); sl = np.zeros(n)
    for idx, arr, src in ((hi, sh, h), (lo, sl, l)):
        idx = np.asarray(idx, int)
        if len(idx) < 2:
            continue
        sgn = np.sign(np.diff(src[idx]))                    # pivot ke-j dibanding pivot ke-(j-1)
        conf = idx[1:] + k
        j = np.searchsorted(conf, np.arange(n), side="right") - 1
        arr[:] = np.where(j >= 0, sgn[np.clip(j, 0, None)], 0)
    out[(sh > 0) & (sl > 0)] = 1
    out[(sh < 0) & (sl < 0)] = -1
    return out


def _roll_sum(x, n):
    cs = np.cumsum(np.r_[0.0, x])
    out = np.full(len(x), np.nan)
    out[n - 1:] = cs[n:] - cs[:-n]
    return out


def base_feats(D, tf, btc=None, flow=None):
    """Matriks faktor TANPA arah (dikali arah sinyal nanti) + faktor tak berarah. -> dict nama -> array panjang n."""
    t, o, h, l, c, v, a = D["t"], D["o"], D["h"], D["l"], D["c"], D["v"], D["a"]
    n = len(c)
    F = {}
    F["htf4"] = _htf(t, tf, D, TF_MS["4h"])
    F["htf1d"] = _htf(t, tf, D, TF_MS["1d"])
    if btc is not None and len(btc["c"]):
        bt, bc = btc["t"], btc["c"]
        ba = _atr(btc["h"], btc["l"], bc, 14)
        F["btc"] = _asof_same(t, bt, _trend(bc))
        F["btc4"] = _htf(bt, tf, btc, TF_MS["4h"]) if TF_MS[tf] < TF_MS["4h"] else _trend(bc)
        F["btc4"] = _asof_same(t, bt, F["btc4"])
        mv = np.zeros(len(bc))
        with np.errstate(invalid="ignore", divide="ignore"):
            mv[12:] = (bc[12:] - bc[:-12]) / ba[12:]
        F["btcmv"] = np.clip(np.nan_to_num(_asof_same(t, bt, mv)), -8, 8)
    else:
        F["btc"] = F["btc4"] = F["btcmv"] = np.zeros(n)
    with np.errstate(invalid="ignore", divide="ignore"):
        F["rsi"] = (_rsi(c, 14) - 50) / 50
        F["adx"] = _adx(h, l, c, 14) / 50
        F["ema200"] = np.clip((c - _ema(c, 200)) / a, -15, 15) / 5
        mv = np.zeros(n); mv[12:] = (c[12:] - c[:-12]) / a[12:]
        F["mv12"] = np.clip(mv, -10, 10) / 3
        F["vol"] = np.log(np.maximum(a / c * 100, 1e-4))
        rng = h - l
        clv = np.where(rng > 0, (2 * c - h - l) / rng, 0.0)
        dv = clv * v
        F["delta"] = np.nan_to_num(_roll_sum(dv, 12) / _roll_sum(v, 12))
        F["delta3"] = np.nan_to_num(_roll_sum(dv, 3) / _roll_sum(v, 3))
        vm = _roll_sum(v, 20) / 20
        vm = np.r_[np.nan, vm[:-1]]                          # rata-rata 20 candle SEBELUM candle sinyal
        sp = np.log(np.maximum(np.nan_to_num(v / vm, nan=1.0), 1e-3))
        F["spike"] = np.clip(sp, -3, 3)
        F["spikedir"] = np.clip(sp, 0, 3) * np.sign(c - o)
    from numpy.lib.stride_tricks import sliding_window_view as swv
    hi50 = np.full(n, np.nan); lo50 = np.full(n, np.nan)
    if n >= 50:
        hi50[49:] = swv(h, 50).max(1); lo50[49:] = swv(l, 50).min(1)
    with np.errstate(invalid="ignore", divide="ignore"):
        F["rng"] = np.nan_to_num((c - lo50) / (hi50 - lo50) - 0.5)
    F["struct"] = _structure(h, l, 3)
    hour = (t // 3_600_000) % 24
    F["s_asia"] = (hour < 7).astype(float)
    F["s_lon"] = ((hour >= 7) & (hour < 12)).astype(float)
    F["s_ovl"] = ((hour >= 12) & (hour < 16)).astype(float)
    F["s_ny"] = ((hour >= 16) & (hour < 21)).astype(float)
    F["wkend"] = (((t // 86_400_000) + 4) % 7 >= 5).astype(float)          # 1970-01-01 = Kamis
    for k in ("f_ok", "f_oi", "f_tk", "f_ls", "f_fr"):
        F[k] = np.zeros(n)
    if flow:
        _flow_feats(F, t, tf, flow)
    return F


def _flow_feats(F, t, tf, fl):
    """Flow Binance (±30 hari) disejajarkan ke candle sinyal: nilai periode flow yang sudah close saat candle sinyal close."""
    ft = np.asarray(fl["t"], np.int64)
    if not len(ft):
        return
    ms = int(fl["ms"])
    close_sig = t + TF_MS[tf]
    j = np.searchsorted(ft + ms, close_sig, side="right") - 1
    W = 4
    c, oi, ls, fr, tk = (np.asarray(fl[k], float) for k in ("c", "oi", "ls", "fr", "taker"))
    m = len(c)
    doi = np.full(m, np.nan); dp = np.full(m, np.nan); dls = np.full(m, np.nan); tkm = np.full(m, np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        doi[W:] = oi[W:] / oi[:-W] - 1
        dp[W:] = np.sign(c[W:] / c[:-W] - 1)
        dls[W:] = ls[W:] / ls[:-W] - 1
        tkm[W - 1:] = _roll_sum(np.nan_to_num(tk, nan=0.5), W)[W - 1:] / W - 0.5
    ok = (j >= W) & (j < m)
    jj = np.clip(j, 0, m - 1)
    has_oi = ok & np.isfinite(doi[jj])
    F["f_ok"] = has_oi.astype(float)
    F["f_oi"] = np.where(has_oi, np.clip(dp[jj] * doi[jj] * 20, -3, 3), 0.0)
    F["f_tk"] = np.where(ok & np.isfinite(tkm[jj]), np.clip(tkm[jj] * 10, -3, 3), 0.0)
    F["f_ls"] = np.where(ok & np.isfinite(dls[jj]), np.clip(dls[jj] * 20, -3, 3), 0.0)
    F["f_fr"] = np.where(ok & np.isfinite(fr[jj]), np.clip(fr[jj] * 1e4 / 2, -3, 3), 0.0)


UNSIGNED = {"adx", "vol", "spike", "f_ok", "s_asia", "s_lon", "s_ovl", "s_ny", "wkend"}


def rows_of(F, sig):
    """Satu baris faktor per sinyal: faktor berarah dikali arah sinyal (+ = mendukung arah strategi)."""
    X = np.zeros((len(sig), NF), np.float32)
    for r, (s, d) in enumerate(sig):
        for j, k in enumerate(FK):
            if k == "dir":
                X[r, j] = d
            else:
                v = F[k][s]
                v = 0.0 if not np.isfinite(v) else float(v)
                X[r, j] = v if k in UNSIGNED else v * d
    return X


# ================================================================== per koin
def coin_eval(sym, D, tf, strat, store=None, btc=None, flow=None):
    sig = signals(strat, D, tf, store, sym)
    hold = hold_bars(tf)
    t = D["t"]
    n = len(t)
    split_t = int(t[int(n * SPLIT)]) if n else 0
    F = base_feats(D, tf, btc, flow)
    keep, meta = [], []
    for s, d in sig:
        r = first_move(D, s, hold)
        if r is None:
            continue
        y, xo, rl, rs = r
        keep.append((s, d))
        meta.append((int(t[s]), d, y, xo, rl, rs, int(t[s]) >= split_t, float(D["c"][s]), float(D["a"][s]), s))
    X = rows_of(F, keep)
    M = np.array([m[:9] for m in meta], float) if meta else np.zeros((0, 9))
    return {"sym": sym, "n_sig": len(sig), "X": X, "M": M}


# ================================================================== model: regresi logistik (numpy, L2)
def fit_logit(X, y, lam=1.0, iters=25):
    mu = X.mean(0); sd = X.std(0); sd[sd < 1e-9] = 1.0
    Z = np.c_[np.ones(len(X)), (X - mu) / sd]
    w = np.zeros(Z.shape[1])
    R = lam * np.eye(Z.shape[1]); R[0, 0] = 0
    for _ in range(iters):
        p = 1 / (1 + np.exp(-np.clip(Z @ w, -30, 30)))
        g = Z.T @ (p - y) + R @ w
        Hs = (Z * (p * (1 - p))[:, None]).T @ Z + R + 1e-9 * np.eye(len(w))
        step = np.linalg.solve(Hs, g)
        w -= step
        if np.abs(step).max() < 1e-6:
            break
    return {"w": w, "mu": mu, "sd": sd}


def predict(m, X):
    Z = np.c_[np.ones(len(X)), (X - m["mu"]) / m["sd"]]
    return 1 / (1 + np.exp(-np.clip(Z @ m["w"], -30, 30)))


MIN_THR = 0.55                                         # "yakin": minimal 55% arah sebaliknya benar
THRS = [round(MIN_THR + 0.01 * i, 2) for i in range(0, 31)]


def _acc(right, flip):
    """right = arah asli benar? (bool, hanya sinyal yang bergerak). flip = dibalik? -> % benar setelah keputusan."""
    if not len(right):
        return None
    return 100 * float(np.mean(np.where(flip, ~right, right)))


def pick_thr(p, right, min_flip):
    base = _acc(right, np.zeros(len(right), bool))
    best = (0.0, None)
    for th in THRS:
        f = p >= th
        if f.sum() < min_flip:
            continue
        g = _acc(right, f) - base
        if g > best[0] + 1e-9:
            best = (g, th)
    return best[1], best[0]


def _mask(cols):
    return np.array([FEATS[j][1] in cols or FEATS[j][1] == "dasar" for j in range(NF)])


def train_eval(X, M, groups):
    """X, M digabung semua koin. -> dict hasil model + prediksi per baris."""
    t, d, y, test = M[:, 0], M[:, 1], M[:, 2], M[:, 6].astype(bool)
    mv = y != 0
    wrong = (y != d) & mv                                   # arah asli salah (hanya sinyal yang bergerak)
    right = (y == d) & mv
    cols = _mask(groups)
    tr, te = ~test & mv, test & mv
    out = {"n": int(len(M)), "n_move": int(mv.sum()), "n_train": int(tr.sum()), "n_test": int(te.sum()), "groups": list(groups)}
    if tr.sum() < 200 or te.sum() < 50:
        out["error"] = f"sinyal yang bergerak terlalu sedikit untuk model (data belajar {int(tr.sum())}, data uji {int(te.sum())}; butuh ≥ 200 / ≥ 50)"
        return out, None, None
    Xc = X[:, cols]
    # 5. ambang: model sementara belajar di 5/7 awal data belajar, ambang dipilih di 2/7 sisanya (tidak dilihat model sementara)
    idx = np.flatnonzero(tr)
    idx = idx[np.argsort(t[idx], kind="stable")]
    cut = int(len(idx) * 5 / 7)
    a_, b_ = idx[:cut], idx[cut:]
    m0 = fit_logit(Xc[a_], wrong[a_].astype(float))
    thr, gain_val = pick_thr(predict(m0, Xc[b_]), right[b_], max(15, int(0.01 * len(b_))))
    m = fit_logit(Xc[tr], wrong[tr].astype(float))
    p = predict(m, Xc)
    flip = (p >= thr) if thr is not None else np.zeros(len(p), bool)
    out.update(thr=thr, gain_val=gain_val, coef=[{"k": FK[j], "w": float(w)} for j, w in zip(np.flatnonzero(cols), m["w"][1:])])
    return out, p, flip


def summarise(M, p, flip, out):
    d, y, test, rl, rs = M[:, 1], M[:, 2], M[:, 6].astype(bool), M[:, 4], M[:, 5]
    mv = y != 0
    right = (y == d)
    used_d = np.where(flip, -d, d)
    R_orig = np.where(d == 1, rl, rs)
    R_used = np.where(used_d == 1, rl, rs)

    def block(sel):
        s2 = sel & mv
        nf = int((flip & sel).sum())
        return {"n": int(sel.sum()), "n_move": int(s2.sum()), "orig": _acc(right[s2], np.zeros(int(s2.sum()), bool)),
                "arb": _acc(right[s2], flip[s2]), "flips": nf, "flip_pct": 100 * nf / max(1, int(sel.sum())),
                "flip_right": 100 * float(np.mean(~right[flip & s2])) if (flip & s2).any() else None,
                "R_orig": float(R_orig[sel].mean()) if sel.any() else None, "R_arb": float(R_used[sel].mean()) if sel.any() else None,
                "neutral": int((sel & ~mv).sum())}
    allb, teb, trb = block(np.ones(len(M), bool)), block(test), block(~test)
    out.update(all=allb, test=teb, train=trb)
    g = (teb["arb"] or 0) - (teb["orig"] or 0)
    out["gain_test"] = g
    # terbukti = akurasi uji naik >= 0.5 poin, >= 20 sinyal dibalik, dan yang dibalik benar > 50% bukan kebetulan (z >= 1.64)
    fr_, nfl = teb["flip_right"], int((flip & test & mv).sum())
    out["z"] = float((fr_ / 100 - 0.5) / np.sqrt(0.25 / nfl)) if nfl and fr_ is not None else None
    out["proven"] = bool(out.get("thr") is not None and teb["flips"] >= 20 and g >= 0.5 and (out["z"] or 0) >= 1.64)
    # tabel keyakinan (data uji): sinyal yang arah modelnya berlawanan (p > 50%)
    bins = [(0.5, 0.55), (0.55, 0.6), (0.6, 0.65), (0.65, 0.7), (0.7, 0.8), (0.8, 1.01)]
    rows = []
    for lo, hi in bins:
        for part, sel in (("test", test), ("train", ~test)):
            s2 = sel & mv & (p >= lo) & (p < hi)
            if part == "test":
                r = {"lo": lo, "hi": hi, "n": int(s2.sum()), "orig": 100 * float(right[s2].mean()) if s2.any() else None}
                r["flipped"] = 100 - r["orig"] if r["orig"] is not None else None
                r["dec"] = "flip" if out.get("thr") is not None and lo >= out["thr"] - 1e-9 else ("part" if out.get("thr") is not None and hi > out["thr"] else "keep")
            else:
                r["n_train"] = int(s2.sum())
                r["flipped_train"] = 100 - 100 * float(right[s2].mean()) if s2.any() else None
        rows.append(r)
    out["conf"] = rows
    return out


def importance(X, M, groups, base_test):
    """Akurasi uji turun berapa poin kalau 1 grup faktor dibuang (model & ambang dihitung ulang tanpa grup itu)."""
    res = []
    for gk in groups:
        rest = [x for x in groups if x != gk]
        o2, p2, f2 = train_eval(X, M, rest)
        if p2 is None:
            continue
        test, y, d = M[:, 6].astype(bool), M[:, 2], M[:, 1]
        s2 = test & (y != 0)
        acc = _acc((y == d)[s2], f2[s2])
        res.append({"g": gk, "name": GROUPS[gk], "drop": (base_test or 0) - (acc or 0), "acc_without": acc, "thr_without": o2.get("thr")})
    res.sort(key=lambda r: -r["drop"])
    return res


def univariate(X, M):
    """Per faktor: akurasi arah asli saat faktor mendukung arah sinyal (> 0) vs melawan (< 0). Faktor tak berarah:
    di atas vs di bawah median. Faktor flow hanya dari sinyal yang punya data flow (±30 hari terakhir)."""
    d, y, test = M[:, 1], M[:, 2], M[:, 6].astype(bool)
    mv = y != 0
    right = y == d
    fok = X[:, FK.index("f_ok")] > 0
    out = []
    for j, (k, g, name, arti) in enumerate(FEATS):
        if k in ("dir", "f_ok"):
            continue
        base = mv & (fok if g == "flow" else True)
        x = X[:, j]
        if k in UNSIGNED:
            if k.startswith("s_") or k == "wkend":
                hi_, lo_ = x > 0.5, x <= 0.5
            else:
                med = float(np.median(x[base])) if base.any() else 0.0
                hi_, lo_ = x > med, x <= med
        else:
            hi_, lo_ = x > 1e-9, x < -1e-9
        r = {"k": k, "g": g, "name": name, "arti": arti, "unsigned": k in UNSIGNED}
        for part, sel in (("all", base), ("test", base & test)):
            a, b = sel & hi_, sel & lo_
            r[part] = {"n_hi": int(a.sum()), "n_lo": int(b.sum()), "acc_hi": 100 * float(right[a].mean()) if a.sum() >= 20 else None,
                       "acc_lo": 100 * float(right[b].mean()) if b.sum() >= 20 else None}
        A_, T_ = r["all"], r["test"]
        r["diff"] = (A_["acc_hi"] - A_["acc_lo"]) if A_["acc_hi"] is not None and A_["acc_lo"] is not None else None
        r["diff_test"] = (T_["acc_hi"] - T_["acc_lo"]) if T_["acc_hi"] is not None and T_["acc_lo"] is not None else None
        out.append(r)
    out.sort(key=lambda r: -abs(r["diff"] or 0))
    return out


# ================================================================== flow Binance (fase 1, di proses utama)
def fetch_flow(client, sym, tf):
    from . import flowstudy as FS
    period = tf if tf in FS.PERIODS else ("4h" if TF_MS[tf] >= TF_MS["4h"] else "1h" if TF_MS[tf] >= TF_MS["1h"] else "15m")
    D = FS.coin_flow(client, sym, period)
    return {"t": D["t"].tolist(), "ms": FS.PERIODS[period], "c": D["c"].tolist(), "oi": D["oi"].tolist(),
            "ls": D["ls"].tolist(), "fr": D["fr"].tolist(), "taker": D["taker"].tolist(), "period": period}


# ================================================================== jalankan (paralel, progres, cache, simpan)
_W = {}


def _init_worker(data_dir):
    from .data import DataStore
    _W["store"] = DataStore(data_dir, cache_size=4)


def _btc(store, tf):
    if "BTCUSDT" in store.catalog and tf in store.timeframes("BTCUSDT"):
        return SB.load(store, "BTCUSDT", tf)
    return None


def coin_job(sym, tf, strat, flow=None, store=None):
    st = store or _W["store"]
    try:
        D = SB.load(st, sym, tf)
        if len(D["c"]) < 500:
            return f"data terlalu sedikit ({len(D['c'])} candle)"
        return coin_eval(sym, D, tf, strat, st, _btc(st, tf), flow), len(D["c"])
    except (ValueError, KeyError, IndexError, OSError, ZeroDivisionError) as ex:
        return f"{type(ex).__name__}: {ex}"


def _disk(tf, strat):
    from .results_store import BASE
    return os.path.join(BASE, "arb_cache", f"res_{strat}_{tf}.json")


def _live_part(Xs, Ms):
    if not Ms:
        return {}
    M = np.vstack(Ms)
    d, y = M[:, 1], M[:, 2]
    mv = y != 0
    return {"n": int(len(M)), "n_move": int(mv.sum()), "orig": 100 * float((y[mv] == d[mv]).mean()) if mv.any() else None,
            "long_pct": 100 * float((d == 1).mean())}


def run(store, tf, strat, syms, client=None, use_flow=True, groups=None, progress=None, push=None, workers=None):
    if strat not in STRATS:
        raise ValueError(f"strategi tidak dikenal: {strat}")
    groups = [g for g in (groups or list(GROUPS)) if g in GROUPS] or list(GROUPS)
    use_flow = bool(use_flow and client is not None and "flow" in groups)
    hour = int(time.time() // 3600) if use_flow else 0
    key = json.dumps([VERSION, tf, strat, list(syms), [int(store.get(s_, tf).t[-1]) for s_ in syms], AG._cfg_sig(AG.whale_cfg.get()),
                      groups, use_flow, hour], default=str)
    if key in _CACHE:
        return _CACHE[key]
    try:
        with open(_disk(tf, strat), encoding="utf-8") as f_:
            Dk = json.load(f_)
        if Dk.get("key") == key:
            Dk["res"]["from_file"] = True
            _CACHE[key] = Dk["res"]
            return Dk["res"]
    except (OSError, ValueError, KeyError):
        pass
    t0 = time.time()
    nsteps = len(syms) * (2 if use_flow else 1)
    flows, flow_err = {}, []
    if use_flow:                                                    # fase 1: flow Binance (±30 hari) tiap koin
        for i, s_ in enumerate(syms):
            try:
                flows[s_] = fetch_flow(client, s_, tf)
            except Exception as ex:                                 # noqa: BLE001 - tanpa flow koin ini: faktor flow = 0
                flow_err.append(f"{s_}: {str(ex)[:120]}")
                if not flows and len(flow_err) >= 2:               # Binance tidak terjangkau: jangan menunggu tiap koin
                    flow_err.append("Binance tidak terjangkau → flow whale dilewati (koin lain tidak dicoba)")
                    if progress:
                        progress(len(syms), nsteps, s_, True)
                    break
            if progress:
                progress(i + 1, nsteps, s_, s_ not in flows)
            if push:
                push({"partial": True, "phase": "flow", "done": i + 1, "total": len(syms), "flow_ok": len(flows), "flow_err": flow_err[-3:],
                      "elapsed": round(time.time() - t0, 1)})
    off = len(syms) if use_flow else 0
    Xs, Ms, used, skipped, n_c, per_coin, syms_of, n_sig = [], [], [], [], 0, [], [], 0

    def take(i, s_, res):
        nonlocal n_c, n_sig
        if isinstance(res, str):
            skipped.append(f"{s_}: {res}")
        else:
            r, nc = res
            if len(r["M"]):
                Xs.append(r["X"]); Ms.append(r["M"]); syms_of.extend([s_] * len(r["M"]))
            used.append(s_); n_c += nc; n_sig += r["n_sig"]
            mv = r["M"][:, 2] != 0 if len(r["M"]) else np.zeros(0, bool)
            per_coin.append({"sym": s_, "n": int(len(r["M"])), "orig": 100 * float((r["M"][mv, 2] == r["M"][mv, 1]).mean()) if mv.any() else None})
        if progress:
            progress(off + i + 1, nsteps, s_, isinstance(res, str))
        if push and (i < 5 or (i + 1) % 2 == 0 or i + 1 == len(syms)):
            part = _live_part(Xs, Ms)
            part.update(partial=True, phase="sinyal", done=i + 1, total=len(syms), coins=list(used), candles=n_c, per_coin=per_coin[-12:],
                        skipped=skipped[-5:], elapsed=round(time.time() - t0, 1), flow_ok=len(flows))
            push(part)
    workers = workers if workers is not None else max(1, min(8, (os.cpu_count() or 2) - 1))
    done = False
    if workers > 1 and len(syms) > 2:
        try:
            from concurrent.futures import ProcessPoolExecutor, as_completed
            with ProcessPoolExecutor(max_workers=workers, initializer=_init_worker, initargs=(store.data_dir,)) as ex_:
                futs = {ex_.submit(coin_job, s_, tf, strat, flows.get(s_)): s_ for s_ in syms}
                for i, fu in enumerate(as_completed(futs)):
                    try:
                        res = fu.result()
                    except Exception as e:                                     # noqa: BLE001 - 1 koin gagal: lanjut
                        res = f"{type(e).__name__}: {e}"
                    take(i, futs[fu], res)
            done = True
        except (OSError, RuntimeError, ImportError):
            Xs, Ms, used, skipped, n_c, per_coin, syms_of, n_sig = [], [], [], [], 0, [], [], 0
    if not done:
        for i, s_ in enumerate(syms):
            take(i, s_, coin_job(s_, tf, strat, flows.get(s_), store))
    if push:
        push({"partial": True, "phase": "model", "done": len(syms), "total": len(syms), "coins": used, **_live_part(Xs, Ms)})
    if not Ms:
        res = {"n": 0, "n_sig": n_sig, "error": "tidak ada sinyal yang bisa diuji di data ini"}
    else:
        X, M = np.vstack(Xs), np.vstack(Ms)
        out, p, flip = train_eval(X, M, groups)
        if p is None:
            res = out
            res["live"] = _live_part(Xs, Ms)
        else:
            res = summarise(M, p, flip, out)
            if push:
                push({"partial": True, "phase": "faktor", "done": len(syms), "total": len(syms), "coins": used, **_live_part(Xs, Ms)})
            res["imp"] = importance(X, M, groups, res["test"]["arb"])
            res["examples"] = _examples(X, M, p, flip, syms_of)
            res["flow_rows"] = int((X[:, FK.index("f_ok")] > 0).sum())
            res["uni"] = univariate(X, M)
    res.update(tf=tf, strat=strat, strat_txt=STRATS[strat], coins=used, skipped=skipped[:20], n_skipped=len(skipped), candles=n_c,
               n_sig=n_sig, hold_bars=hold_bars(tf), use_flow=use_flow and bool(flows), flow_coins=len(flows), flow_err=flow_err[:10],
               group_names={g: GROUPS[g] for g in groups}, feat_names={f[0]: [f[1], f[2], f[3]] for f in FEATS},
               elapsed=round(time.time() - t0, 1), v=VERSION, workers=workers)
    if len(_CACHE) > 6:
        _CACHE.clear()
    _CACHE[key] = res
    try:
        os.makedirs(os.path.dirname(_disk(tf, strat)), exist_ok=True)
        with open(_disk(tf, strat) + ".tmp", "w", encoding="utf-8") as f_:
            json.dump({"key": key, "res": res}, f_, default=float)
        os.replace(_disk(tf, strat) + ".tmp", _disk(tf, strat))
    except (OSError, TypeError, ValueError):
        pass
    return res


SHOW = ("htf4", "btc4", "rsi", "adx", "delta", "spike", "f_oi", "f_tk", "struct")


def _examples(X, M, p, flip, syms_of):
    """Contoh: semua yang dibalik di data uji (maks 150) + sinyal uji terbaru lainnya, urut waktu."""
    test = M[:, 6].astype(bool)
    fi = np.flatnonzero(flip & test)[-150:]
    oi = np.flatnonzero(~flip & test)
    oi = oi[np.argsort(M[oi, 0])][-(EX_KEEP - len(fi)):]
    if len(fi) + len(oi) < EX_KEEP:                               # data uji sedikit: tambah dari data cari
        more = np.flatnonzero(~test)[-(EX_KEEP - len(fi) - len(oi)):]
        oi = np.r_[oi, more].astype(int)
    idx = sorted(set(fi.tolist()) | set(oi.tolist()), key=lambda i: M[i, 0])
    jx = {k: FK.index(k) for k in SHOW}
    out = []
    for i in idx:
        t, d, y, xo, rl, rs, te, c, a = M[i]
        d = int(d); used = -d if flip[i] else d
        out.append({"sym": syms_of[i], "t": int(t), "d": d, "y": int(y), "xo": int(xo), "p": round(float(p[i]) * 100, 1), "flip": bool(flip[i]),
                    "used": used, "ok": None if y == 0 else bool(y == used), "orig_ok": None if y == 0 else bool(y == d),
                    "R": float(rl if used == 1 else rs), "test": bool(te), "c": float(c), "A": float(a),
                    "f": {k: round(float(X[i, j]) * (1 if k in UNSIGNED else d), 3) for k, j in jx.items()}})
    return out


def history_symbols(store, tf, n=30):
    return SB.history_symbols(store, tf, n)
