@echo off
REM Download / update data candle dari data.binance.vision ke folder DATA_DIR.
REM Pertama kali: download 2 tahun terakhir. Berikutnya: hanya data yang baru.
cd /d "%~dp0"
set "DATA_DIR=D:\Data Candle Binance\all"
set "SYMBOLS=--all"
if exist "%~dp0config.bat" call "%~dp0config.bat"
echo Folder data : %DATA_DIR%
echo Koin        : %SYMBOLS%
echo.
python tools\download_binance.py %SYMBOLS% --out "%DATA_DIR%"
echo.
pause
