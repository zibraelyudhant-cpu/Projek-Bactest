@echo off
REM Menjalankan Futures Replay supaya juga bisa dibuka dari HP (Wi-Fi yang sama atau Tailscale).
REM Biarkan jendela ini terbuka selama dipakai; tutup untuk berhenti.
cd /d "%~dp0"
set "DATA_DIR=D:\Data Candle Binance\all"
set "ACCESS_PIN="
if exist "%~dp0config.bat" call "%~dp0config.bat"
REM numpy: 1 thread per proses, supaya proses paralel tidak menghabiskan RAM
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
set "LAN_MODE=1"
echo Folder data : %DATA_DIR%
echo.
echo Buka di PC  : http://127.0.0.1:8000
echo Buka di HP  : (klik tombol "HP" di pojok kanan atas aplikasi untuk QR code)
python -c "import sys; sys.path.insert(0, '.'); from backend.app import lan_addresses; [print('              http://%%s:8000' %% ip) for ip in lan_addresses()]" 2>nul
if "%ACCESS_PIN%"=="" (echo PIN         : tidak ada - siapa pun di Wi-Fi yang sama bisa membuka) else (echo PIN         : aktif)
echo.
echo Kalau Windows menanyakan izin firewall, pilih "Private networks" lalu Allow access.
echo (Tutup jendela ini untuk menghentikan server)
echo.
start "" http://127.0.0.1:8000
python -m uvicorn backend.app:app --host 0.0.0.0 --port 8000
echo.
echo Server berhenti. Kalau ada error di atas, lihat README bagian "Kalau ada masalah".
pause
