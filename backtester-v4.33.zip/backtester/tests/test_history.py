"""🕘 History Update: data riwayat versi & alur kerja lengkap dan konsisten dengan versi aplikasi."""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def test_history_data():
    d = json.load(open(os.path.join(ROOT, "frontend", "history_data.json")))
    V = d["versions"]
    from backend.app import VERSION
    assert V[0]["v"] == VERSION                                          # versi terbaru tercatat
    key = [(int(x["v"].split(".")[0]), int(x["v"].split(".")[1])) for x in V]
    assert key == sorted(key, reverse=True) and len(set(key)) == len(key)  # urut terbaru dulu, tidak dobel
    assert V[-1]["v"] == "1.1" and len(V) >= 100
    for x in V:
        assert x["notes"].strip() and x["date"] and isinstance(x["menus"], list)
        assert set(x["menus"]) <= set(d["menu_names"])
    for x in V:                                                           # v2.8+ : label dari kode, ada rincian perubahan kode
        if (int(x["v"].split(".")[0]), int(x["v"].split(".")[1])) >= (2, 8):
            assert x["tag_src"] == "kode" and x["code"] and "files" in x["code"], x["v"]
    names = [m["name"] for m in d["menus"]]
    tabs = ["🎮 Manual Replay", "🤖 Auto Backtest", "📍 Tes SNR", "🧪 Indikator Tester", "📐 Market Structure", "🌀 Studi Fibonacci v2", "📊 Screener", "🐋 Whale",
            "🧠 TA Pro Advance", "🛡️ SL Backtest", "📈 Moving Average Analisis", "🧭 Penentu Arah", "📒 Jurnal", "📚 Info Trading", "🕘 History Update"]
    assert names == tabs                                                  # sama dengan urutan tab di aplikasi
    assert all(f["steps"] for m in d["menus"] for f in m["features"])
