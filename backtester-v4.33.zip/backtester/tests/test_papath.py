"""Jalur animasi price action: mantul di SNR minor, tidak menyentuh SL/TP sebelum waktunya, berakhir di hasil backtest."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from backend import papath as PA  # noqa: E402


def _check(p, p0, A, entry, sl, tp, long, outcome):
    hi = [p0 + x * A for x in p["high"]]
    lo = [p0 + x * A for x in p["low"]]
    n = len(hi)
    for i in range(n - 1):                                      # sebelum candle terakhir: TP & SL tidak tersentuh
        assert lo[i] > min(sl, tp) - 1e-9 or not long
        if long:
            assert lo[i] > sl and hi[i] < tp, i
        else:
            assert hi[i] < sl and lo[i] > tp, i
    if outcome == "tp":
        assert (hi[-1] >= tp) if long else (lo[-1] <= tp)
    else:
        assert (lo[-1] <= sl) if long else (hi[-1] >= sl)


def test_long_tp_bounces_at_snr():
    p0, A = 100.0, 1.0
    p = PA.build(p0, 100, 97, 106, True, "tp", 30, A, levels=[102, 104, 95, 110], retr=0.5)
    assert [m["text"] for m in p["marks"]][:2] == ["mantul di SNR minor 102", "mantul di SNR minor 104"]
    assert p["marks"][-1]["text"] == "kena TP" and p["marks"][-1]["k"] == len(p["close"]) - 1
    assert abs(len(p["close"]) - 30) <= 4
    _check(p, p0, A, 100, 97, 106, True, "tp")


def test_short_sl_and_limit_fill():
    p0, A = 100.0, 2.0
    p = PA.build(p0, 103, 107, 95, False, "sl", 20, A, levels=[105], retr=0.6, fill_bars=5)
    texts = [m["text"] for m in p["marks"]]
    assert texts[0] == "entry terisi" and texts[-1] == "kena SL"
    hi = [p0 + x * A for x in p["high"]]
    assert max(hi[:4]) < 103 and hi[4] >= 103                    # limit SELL terisi tepat di candle ke-5
    _check(p, p0, A, 103, 107, 95, False, "sl")


def test_no_levels_uses_normal_pullback_and_bounce_never_hits_sl():
    p = PA.build(50.0, 50, 49, 56, True, "tp", 40, 0.5, levels=[], retr=0.75)
    assert p["synthetic"] and p["marks"][0]["text"] == "koreksi normal"
    _check(p, 50.0, 0.5, 50, 49, 56, True, "tp")


def test_retrace_from_data():
    import numpy as np
    x = np.r_[np.linspace(100, 110, 30), np.linspace(110, 105, 15), np.linspace(105, 115, 30), np.linspace(115, 110, 15),
              np.linspace(110, 120, 30)]
    r = PA.median_retrace(x + 0.3, x - 0.3, x)
    assert PA.RETR_MIN <= r <= PA.RETR_MAX
