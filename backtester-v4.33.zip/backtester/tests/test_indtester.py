"""Tes 🧪 Indikator Tester: parsing daftar angka, jenis MA, tanpa intip masa depan, hasil trade, semua tester."""
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend import indtester as IT  # noqa: E402
from backend.data import Bars, DataStore  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("itdata")
    make(str(d), days=200)
    return DataStore(str(d))


def test_parse_list():
    assert IT.parse_list("20, 50,100") == [20, 50, 100]
    assert IT.parse_list("10-30:10") == [10, 20, 30]
    assert IT.parse_list("0, 0.5-1:0.5", 0, 5, integer=False) == [0, 0.5, 1.0]
    assert IT.parse_list("5, 5, 1600", 2, IT.MAX_MA) == [5, 1600]     # dobel dibuang; MA panjang (1600) tetap dipakai
    with pytest.raises(ValueError, match="di luar batas"):
        IT.parse_list("5, 9999", 2, IT.MAX_MA)                           # tidak dipotong diam-diam
    with pytest.raises(ValueError):
        IT.parse_list("1-1000:1")                                       # terlalu banyak


@pytest.mark.parametrize("kind", IT.MA_TYPES)
def test_ma_types(kind):
    x = 100 + np.cumsum(np.random.default_rng(1).normal(0, 1, 500))
    m = IT.ma(x, 20, kind)
    assert len(m) == len(x) and np.isfinite(m[100:]).all()
    assert abs(np.nanmean(m[100:]) - np.mean(x[100:])) < 10           # mengikuti harga
    if kind != "HMA":
        assert np.isnan(m[:19]).all()                                   # belum valid sebelum n candle


def test_trade_outcomes_rules():
    # candle 1 menyentuh TP & SL sekaligus -> kalah; candle berikutnya tak bergerak -> waktu habis = tidak menang
    c = np.array([100, 100, 100, 100, 100, 100.0])
    h = np.array([100, 110, 100.5, 100.5, 100.5, 100.5])
    l = np.array([100, 90, 99.5, 99.5, 99.5, 99.5])
    a = np.full(6, 2.0)
    out = IT.trade_outcomes(h, l, c, a, sl_atr=1.0, rr=2.0, max_bars=3)
    win, R, ex, ok = out[0]
    assert ok[0] and not win[0] and R[0] == -1 and ex[0] == 1
    assert ok[1] and not win[1] and R[1] == 0 and ex[1] == 4         # waktu habis
    assert not ok[3]                                                   # masa depan kurang dari max_bars


def test_no_lookahead(store):
    b = store.get("SAMPLEUSDT", "1h")
    p = dict(IT.DEFAULTS)
    full = IT.Coin(b, p)
    k = len(b.c) - 300
    cut = IT.Coin(Bars(*(np.asarray(x)[:k] for x in (b.t, b.o, b.h, b.l, b.c, b.v))), p)
    for name, args in (("comp_ma_pair", (50, 20, "EMA", "SMA")), ("comp_rsi", (14, 70, "balik")), ("comp_stoch", (14, 3, 3, 80)),
                       ("comp_macd", (12, 26, 9, "nol")), ("comp_adx", (14, 25)), ("comp_force", (13, 0.5)),
                       ("comp_retest", (3, 20, 0.2))):
        f = getattr(IT, name)
        _, s_full = f(full, *args)
        _, s_cut = f(cut, *args)
        assert np.array_equal(s_full[:k], s_cut), name
    lo_f, hi_f = full.swings(3)
    lo_c, hi_c = cut.swings(3)
    assert np.allclose(lo_f[:k], lo_c, equal_nan=True) and np.allclose(hi_f[:k], hi_c, equal_nan=True)


@pytest.mark.parametrize("tester", ["ema", "rsi", "stoch", "macd", "adx", "force", "combo"])
def test_run_each_tester(store, tester):
    p = dict(IT.DEFAULTS, tester=tester, tf="1h", min_trades=3, ema_main="50, 100", ema_second="10, 20")
    r = IT.run(store, ["SAMPLEUSDT"], p)
    if tester == "ema":                                                  # EMA Tester: tes pantulan & pasangan (bukan trade)
        assert r["ema2"] and r["bounce"] and r["pairs"], r
        return
    assert r["n_combos"] >= 1 and r["rows"], r
    for row in r["rows"]:
        assert 0 <= row["wr"] <= 100 and row["n"] >= 3 and row["base_wr"] is not None
        assert row["n_long"] + row["n_short"] == row["n"]
    if tester in ("ema", "combo"):
        assert "struct" in r["rows"][0] and r["rows"][0]["sideways_pct"] is not None


def test_ema_lists_and_gap(store):
    base = dict(IT.DEFAULTS, tester="ema", tf="1h", ema_main="100, 200", ema_second="10, 20, 30, 80", bounce_list="20, 50")
    r = IT.run(store, ["SAMPLEUSDT"], base)
    assert r["n_pairs"] == 7                                           # 100-80 < 30 tidak dipakai
    assert all(x["main"] - x["second"] >= IT.EMA_GAP for x in r["pairs"])
    r = IT.run(store, ["SAMPLEUSDT"], dict(base, bounce_list=""))
    assert r["auto"] == ["daftar EMA pantulan"] and r["n_bounce"] == len(IT.parse_list(IT.AUTO["bounce_list"]))
    with pytest.raises(ValueError, match="minimal 30"):
        IT.plan(dict(base, ema_main="34", ema_second="30"))
    r = IT.run(store, ["SAMPLEUSDT"], dict(IT.DEFAULTS, tester="rsi", tf="1h", min_trades=1, rsi_len="", rsi_ob="70"))
    assert r["auto"] == ["panjang RSI"] and r["n_combos"] == len(IT.parse_list(IT.AUTO["rsi_len"]))
    # pengaturan lain diabaikan (aturan tetap): hasil sama
    r2 = IT.run(store, ["SAMPLEUSDT"], dict(base, retest_tol=1.5, hold_bars=50, body_pct=90, vol_mult=5, ma_type="SMA"))
    r1 = IT.run(store, ["SAMPLEUSDT"], base)
    assert r1["bounce"] == r2["bounce"] and r1["pairs"] == r2["pairs"]


def _bars(c, h=None, l=None, o=None, v=None):
    c = np.array(c, float)
    n = len(c)
    h = np.array(h, float) if h is not None else c + 0.1
    l = np.array(l, float) if l is not None else c - 0.1
    o = np.array(o, float) if o is not None else c
    v = np.array(v, float) if v is not None else np.ones(n)
    C = IT.Coin(Bars(np.arange(n, dtype=np.int64) * 3_600_000, o, h, l, c, v), dict(IT.DEFAULTS))
    C.a = np.ones(n)
    return C


def test_bounce_rules():
    m = lambda n: np.full(n, 100.0)   # noqa: E731  EMA datar di 100, ATR 1 -> 1R = 1
    # naik menjauh (>= 1 ATR), ekor turun menyentuh 100, lalu close 102 (2R searah tren) = MANTUL 2R
    c = [100, 101, 102, 104, 103, 101.5, 100.05, 100.6, 101.2, 102, 103]
    assert [(e[0], e[2]) for e in IT.bounce_events(_bars(c), m(len(c))) if e[1] > 0] == [(6, 1)]
    # setelah menyentuh, close 2R di bawah EMA lebih dulu = TEMBUS & TREN BERUBAH
    c2 = [100, 101, 102, 104, 103, 101.5, 100.05, 99.5, 99, 98, 97]
    assert [(e[0], e[2]) for e in IT.bounce_events(_bars(c2), m(len(c2))) if e[1] > 0] == [(6, 0)]
    # tusukan sedikit di bawah EMA (< 2R) lalu naik 2R = tetap MANTUL
    c3 = [100, 101, 102, 104, 103, 101.5, 100.05, 98.8, 100.4, 101.3, 102.1]
    assert [(e[0], e[2]) for e in IT.bounce_events(_bars(c3), m(len(c3))) if e[1] > 0] == [(6, 1)]
    # belum pernah menjauh 1 ATR = tidak dihitung (bukan tren)
    c4 = [100.3, 100.5, 100.2, 100.05, 100.6, 101.5]
    assert [e for e in IT.bounce_events(_bars(c4), m(len(c4))) if e[1] > 0] == []


def test_pair_rules():
    H = IT.EMA_HOLD
    n = 10 + H + 5
    m1, m2 = np.full(n, 100.0), np.full(n, 102.0)                     # EMA pertama 100, EMA kedua 102
    pre = [103, 103, 103, 101, 100.5]                                 # di atas keduanya -> jebol EMA kedua (101)
    # tembus EMA pertama (99) dan bertahan 200 candle = VALID
    c = pre + [99] * (n - len(pre))
    ev = IT.pair_events(_bars(c), m1, m2)
    assert ev[0][:4] == (3, 1, 0, 2)
    # tembus EMA pertama tapi close balik di atasnya sebelum 200 candle = TEMBUS LALU BALIK
    c2 = pre + [99] * 50 + [100.5] + [99] * (n - len(pre) - 51)
    assert IT.pair_events(_bars(c2), m1, m2)[0][2] == 2
    # setelah jebol EMA kedua, masuk range lalu close lagi di atas EMA kedua = BALIK (tren berlanjut)
    c3 = pre + [101, 102.5] + [104] * (n - len(pre) - 2)
    assert IT.pair_events(_bars(c3), m1, m2)[0][2] == 1
    # candle yang langsung jebol keduanya bukan "peringatan dulu" -> tidak dihitung
    c4 = [103, 103, 103] + [99] * (n - 3)
    assert IT.pair_events(_bars(c4), m1, m2) == []
    # data belum cukup 200 candle setelah tembus -> belum diketahui, tidak dihitung
    c5 = (pre + [99] * 20)
    assert IT.pair_events(_bars(c5), m1[:len(c5)], m2[:len(c5)]) == []


def test_too_many_combos():
    with pytest.raises(ValueError):                                     # 1 indikator saja: tidak bisa bertahap
        IT.plan(dict(IT.DEFAULTS, tester="ema", ema_main="100-159:1", ema_second="5-64:1"))
    total, staged = IT.plan(dict(IT.DEFAULTS, tester="combo", components=["ma_pair", "rsi", "force"],
                                 ema_main="", ema_second="", rsi_len="", rsi_ob="", fi_len="", fi_k=""))
    assert total > IT.MAX_COMBOS and staged


def test_staged_search(store):
    p = dict(IT.DEFAULTS, tester="combo", components=["ma_pair", "rsi", "force"], tf="15m", min_trades=3,
             ema_main="", ema_second="", rsi_len="", rsi_ob="", fi_len="", fi_k="")
    steps = []
    r = IT.run(store, ["SAMPLEUSDT"], p, lambda k, n, s, e: steps.append((k, n)))
    g = r["staged"]
    assert g and g["full"] > IT.MAX_COMBOS and g["stage2"] <= g["keep"] ** 3 and r["n_combos"] == g["stage1"] + g["stage2"]
    assert set(g["picked"]) == {"ma_pair", "rsi", "force"} and all(1 <= len(v) <= g["keep"] for v in g["picked"].values())
    assert steps[-1][0] == steps[-1][1]                                  # progres berakhir di 100%
    for row in r["rows"]:                                                # hasil akhir hanya dari angka terpilih tahap 1
        assert IT._label({"rsi": row["combo"]["rsi"]}, p) in g["picked"]["rsi"]


def test_main_must_be_bigger():
    g = IT._grid(dict(IT.DEFAULTS, tester="ema", ema_mode="find_both", ema_main="21, 55, 200", ema_second="9, 50, 75"))
    assert g and all(c["ma_pair"]["main"] > c["ma_pair"]["second"] for c in g) and len(g) == 1 + 2 + 3
    with pytest.raises(ValueError, match="LEBIH BESAR"):
        IT._grid(dict(IT.DEFAULTS, tester="ema", ema_mode="test", ema_main="21", ema_second="75"))



def _mini_coin(closes):
    c = np.array(closes, float)
    n = len(c)
    b = Bars(np.arange(n, dtype=np.int64) * 3_600_000, c, c + 0.3, c - 0.3, c, np.ones(n))
    return IT.Coin(b, dict(IT.DEFAULTS, max_bars=3))


def test_retest_entry_rules():
    # swing high di candle 3 (high 13.3), BOS di candle 9 (close 14), candle 11 turun menyentuh 13.3 lalu close 13.5 -> LONG
    base = [10, 11, 12, 13, 12, 11, 10, 11, 12, 14, 15]
    sig = IT.comp_retest(_mini_coin(base + [13.5, 15, 16, 17]), 3, 20, 0.0)[1]
    assert sig[11] == 1 and (sig[:11] == 0).all() and (sig[12:] == 0).all()
    # close jatuh di bawah level (13.0 < 13.3) = retest gagal, tidak ada entry sesudahnya
    sig = IT.comp_retest(_mini_coin(base + [13.0, 13.5, 15, 16]), 3, 20, 0.0)[1]
    assert (sig == 0).all()
    # retest datang terlambat (lewat batas waktu) = batal
    sig = IT.comp_retest(_mini_coin(base + [15, 15.5, 16, 13.5, 16]), 3, 2, 0.0)[1]
    assert (sig == 0).all()


def test_ema_tester_uses_retest_entries(store):
    p = dict(IT.DEFAULTS, tester="ema", tf="1h", min_trades=1, ema_mode="test", ema_main="100", ema_second="20")
    C = IT.Coin(store.get("SAMPLEUSDT", "1h"), p)
    parts = IT._parts(C, {"ma_pair": {"main": 100, "second": 20}}, p)
    sig, state = IT.combine(parts)
    rt = IT.comp_retest(C, p["swing"], p["retest_bars"], p["retest_tol"])[1]
    idx = np.flatnonzero(sig)
    assert len(idx) and (sig[idx] == rt[idx]).all() and (sig[idx] == state[idx]).all()   # entry = retest searah tren


def test_coin_without_data_in_period_is_skipped(tmp_path):
    # koin baru listing (tidak ada candle di periode yang dipilih) tidak boleh menghentikan backtest semua koin
    make(str(tmp_path), symbol="OLDUSDT", days=200)
    make(str(tmp_path), symbol="NEWUSDT", days=20, start_ms=1_735_689_600_000 + 300 * 86_400_000)
    st = DataStore(str(tmp_path))
    end = 1_735_689_600_000 + 190 * 86_400_000
    p = dict(IT.DEFAULTS, tester="ema", tf="1h", min_trades=1, ema_main="100", ema_second="20", start=None, end=end)
    r = IT.run(st, ["OLDUSDT", "NEWUSDT"], p)
    assert r["symbols"] == ["OLDUSDT"] and (r["bounce"] or r["pairs"])
    assert any(x.startswith("NEWUSDT: tidak ada data di periode ini") for x in r["skipped"])


def test_ema_events_match_result(store):
    p = dict(IT.DEFAULTS, tester="ema", tf="1h", ema_main="100", ema_second="20", bounce_list="20, 50")
    r = IT.run(store, ["SAMPLEUSDT"], p)
    for row in r["bounce"]:
        ev = IT.ema_events(store, "SAMPLEUSDT", r["params"], {"kind": "bounce", "n": row["n"]}, limit=100000)["events"]
        fit = [e for e in ev if not e["test"]]
        assert sum(e["result"] == "mantul" for e in fit) == row["ok"] and sum(e["result"] == "berubah" for e in fit) == row["fail"]
    pr = r["pairs"][0]
    ev = IT.ema_events(store, "SAMPLEUSDT", r["params"], {"kind": "pair", "main": 100, "second": 20}, limit=100000)["events"]
    fit = [e for e in ev if not e["test"]]
    assert len(fit) == pr["warn"] and sum(e["result"] == "valid" for e in fit) == pr["valid"]


@pytest.mark.parametrize("tester", ["rsi", "combo"])
def test_combo_trades_match_result(store, tester):
    """Contoh kejadian = trade yang sama persis dengan yang dihitung di tabel hasil (jumlah, WR, latih/uji)."""
    p = dict(IT.DEFAULTS, tester=tester, tf="1h", min_trades=1, top=5)
    if tester == "combo":
        p["components"] = ["rsi", "adx"]
    r = IT.run(store, ["SAMPLEUSDT"], p)
    assert r["rows"]
    for row in r["rows"][:3]:
        tr = IT.combo_trades(store, "SAMPLEUSDT", r["params"], row["combo"], limit=100000)
        fit = [t for t in tr["trades"] if not t["test"]]
        test = [t for t in tr["trades"] if t["test"]]
        assert len(fit) == row["n"] and len(test) == row["n_test"]
        assert abs(100 * sum(t["win"] for t in fit) / len(fit) - row["wr"]) < 1e-9
        assert all((t["sl"] < t["entry"] < t["tp"]) if t["side"] == "long" else (t["tp"] < t["entry"] < t["sl"]) for t in tr["trades"])
        assert all(t["exit_time"] > t["time"] for t in tr["trades"])


def test_long_ema_does_not_shrink_short_ones(store):
    """EMA panjang (mis. 3000) punya pemanasan sendiri: EMA pendek tetap pakai data penuh, koin tidak dilewati."""
    base = dict(IT.DEFAULTS, tester="ema", tf="1h", ema_main="200", ema_second="50")
    one = IT.run(store, ["SAMPLEUSDT"], dict(base, bounce_list="20"))
    both = IT.run(store, ["SAMPLEUSDT"], dict(base, bounce_list="20, 3000"))
    assert one["symbols"] == both["symbols"] == ["SAMPLEUSDT"]
    assert [x for x in both["bounce"] if x["n"] == 20] == [x for x in one["bounce"] if x["n"] == 20]
    assert "EMA 3000" in both["short"]                                 # data sampel < 9000 candle
    assert IT.plan(dict(base, bounce_list="3000", ema_main="3000", ema_second="1120"))


def test_hyperopt_tester(store):
    """🎛️ Hyperopt (disederhanakan): cukup pilih indikator + RR. Angka indikator, SL & lama tahan dicari sendiri.
    Cari 80% / uji 20%, walk-forward, dan contoh trade = hitungan tabel."""
    p = dict(IT.DEFAULTS, tester="hyper", tf="1h", components=["rsi"], top=10,
             rsi_len="7", rsi_ob="70", hyper_sl="5", min_trades=1, direction="long")   # isian lama diabaikan
    r = IT.run(store, ["SAMPLEUSDT"], p)
    st = IT.hyper_state(dict(p))
    assert st["G"]["_sl"] == IT.H_SL and st["G"]["_mb"] == IT._h_holds("1h") == [4, 12, 24]
    assert len(st["G"]["rsi"]) > 1 and len(st["grid"]) == len(st["G"]["rsi"]) * 9   # daftar otomatis, bukan "7" dari form
    assert r["hyper"] and r["n_combos"] == len(st["grid"]) <= IT.H_MAX and len(r["walk"]) == IT.H_FOLDS - 2
    assert r["params"]["min_trades"] == IT.H_MIN_N and r["params"]["direction"] == "both"
    assert all(x["n"] >= IT.H_MIN_N for x in r["rows"])
    assert all(x["sl"] in IT.H_SL and x["mb"] in (4, 12, 24) for x in r["rows"])
    ex = [x["exp_r"] for x in r["rows"]]
    assert ex == sorted(ex, reverse=True)                              # urut dari hasil data cari
    for row in r["rows"][:3]:
        assert row["n"] == sum(f["n"] for f in row["folds"][:-1]) and row["n_test"] == row["folds"][-1]["n"]
        tr = IT.combo_trades(store, "SAMPLEUSDT", dict(r["params"], sl_atr=row["sl"], max_bars=row["mb"]), row["combo"], limit=100000)["trades"]
        assert len([t for t in tr if not t["test"]]) == row["n"] and len([t for t in tr if t["test"]]) == row["n_test"]
    with pytest.raises(ValueError):
        IT.plan(dict(p, components=[]))
    big = IT.plan(dict(IT.DEFAULTS, tester="hyper", components=["rsi", "adx", "force"]))
    assert big[0] <= IT.H_MAX                                          # terlalu banyak -> diambil acak maks 3000 kombinasi
