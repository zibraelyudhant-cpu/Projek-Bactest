"""🧠 TA Pro Advance: setup tanpa intip masa depan, simulasi TP1/TP2, mantul bersih, statistik & pemilihan entry, endpoint."""
import contextlib
import io
import os
import sys
import time

import numpy as np
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from backend import tapro as TP  # noqa: E402
from backend.data import DataStore  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("tap")
    with contextlib.redirect_stdout(io.StringIO()):
        for i, s_ in enumerate(("BTCUSDT", "AAAUSDT", "BBBUSDT", "CCCUSDT")):
            make(str(d), symbol=s_, days=200, seed=i + 1)
    TP._FNG.update(t=time.time(), d={})                                   # tanpa internet
    return DataStore(str(d))


def _series(store, sym, style, cut=None):
    st = TP.STYLES[style]
    b = store.get(sym, st["tf"])
    n = cut or len(b.c)
    big = []
    for tfb in (st["htf"], st["d1"]):
        if tfb:
            bb = store.get(sym, tfb)
            big.append((np.asarray(bb.t, np.int64), np.asarray(bb.c, float), tfb))
    return TP.Series(sym, st["tf"], b.t[:n], b.o[:n], b.h[:n], b.l[:n], b.c[:n], b.v[:n], big)


def test_detect_causal(store):
    """Setup yang terdeteksi di candle s tidak berubah kalau candle sesudahnya dibuang."""
    full = _series(store, "AAAUSDT", "scalping")
    cut = full.n - 3000
    part = _series(store, "AAAUSDT", "scalping", cut)
    key = lambda e: (e[0], e[1], e[2], round(e[3], 9))  # noqa: E731
    a = {key(e) for e in TP.detect(full) if e[0] < cut - 30}
    b = {key(e) for e in TP.detect(part) if e[0] < cut - 30}
    assert a and a == b


def test_simulate_tp1_tp2():
    """TP1 = 2R ambil 50% + SL ke entry; TP2 sisa. SL duluan = -1R."""
    class S:
        pass
    S.n = 10
    S.h = np.array([10, 10.5, 11.0, 12.1, 13.2, 12.0, 11, 11, 11, 11.0])
    S.l = np.array([9.8, 9.9, 10.2, 11.5, 12.5, 9.5, 10, 10, 10, 10.0])
    S.c = np.array([10, 10.4, 10.9, 12.0, 13.0, 9.6, 10, 10, 10, 10.0])
    r = TP.simulate(S, 1, 0, 10.0, 9.0, 8, True)                        # risiko 1: TP1 12 (candle 3), TP2 1:3 = 13 (candle 4)
    assert r["hit1"] and r["R"][3.0] == pytest.approx(0.5 * 2 + 0.5 * 3) and r["R"][4.0] == pytest.approx(1.0)
    S.l = np.array([9.8, 8.9, 10.2, 11.5, 12.5, 9.5, 10, 10, 10, 10.0])
    r = TP.simulate(S, 1, 0, 10.0, 9.0, 8, True)
    assert not r["hit1"] and r["R"][3.0] == -1.0


def test_bounce_definition():
    h = np.array([10.3, 10.6, 11.1]); l = np.array([9.95, 10.1, 10.5]); c = np.array([10.2, 10.5, 10.9])
    assert TP._bounce(1, 0, 10.0, 9.0, h, l, c, False) == (True, False)
    assert TP._bounce(1, 0, 10.0, 9.0, h, l, np.array([10.2, 9.8, 10.9]), False) == (False, True)


def test_learn_and_best_entry(store):
    syms = TP.history_symbols(store, "scalping", 4)
    L = TP.learn(store, "scalping", syms)
    assert L["n_rows"] > 0 and L["stats"]
    for k, v in L["stats"].items():
        assert v["tp2"] >= 3 and 0 <= v["clean_pct"] <= 100 and v["n"] >= 15
        assert k[2] in ("market", TP.ENTRY_SWING)                     # kandidat entry riwayat = Whale (tembok hanya live)
        w = v["wr"] / 100
        assert v["exp_r"] == pytest.approx(w * 2 - (1 - w))             # rumus Whale di TP1 1:2
        assert v["ok"] == (v["n"] >= TP._min_trades() and v["exp_r"] > 0)   # layak = Whale: sampel & rata-rata untung
    code, d = next(iter(L["stats"]))[:2]
    best, cands = TP.best_entry(L["stats"], code, d)
    order = [(c["ok"], round(c["clean_pct"] / 5), c["exp_sig"]) for c in cands]
    assert order == sorted(order, reverse=True) and best is cands[0]


def test_decide():
    p = {"prob": 60.0, "stats": {"ok": True}}
    assert TP.decide(p, {})["decision"] == "ENTRY"
    w = {"items": [["x", "y", "warn"]]}
    assert TP.decide(p, {"sentiment": w, "orderbook": w})["decision"] == "TUNGGU"
    assert TP.decide(p, {"fundamental": {"veto": True, "items": []}})["decision"] == "JANGAN"
    assert TP.decide({"prob": 35.0, "stats": {"ok": True}}, {})["decision"] == "ENTRY"       # tanpa WR minimal (seperti Whale)
    ob = {"items": [["Tembok di jalur TP1", "x", "info"], ["Antrean", "y", "info"]]}
    assert TP.decide(p, {"orderbook": ob})["decision"] == "ENTRY"                          # order book = info
    assert TP.decide({"prob": 70.0, "stats": {"ok": False, "n": 100}}, {})["decision"] == "JANGAN"


def test_learn_disk_cache(store, tmp_path, monkeypatch):
    """Hasil backtest riwayat disimpan ke file: sesudah cache memori dikosongkan (aplikasi dibuka ulang) dibaca dari file."""
    from backend import results_store
    monkeypatch.setattr(results_store, "BASE", str(tmp_path))
    syms = TP.history_symbols(store, "intraday", 3)
    TP._CACHE.clear()
    a = TP.learn(store, "intraday", syms)
    assert os.path.exists(TP._disk("intraday")) and not a.get("from_file")
    TP._CACHE.clear()
    b = TP.learn(store, "intraday", syms)
    assert b.get("from_file") and b["n_rows"] == a["n_rows"] and set(b["stats"]) == set(a["stats"])
    k = next(iter(a["stats"]))
    assert b["stats"][k]["wr"] == pytest.approx(a["stats"][k]["wr"]) and b["stats"][k]["tp2"] == a["stats"][k]["tp2"]


def test_wall_entry_live(store):
    """Limit depan tembok (live saja) dinilai cara Whale: backtest candle koin itu, rumus WR x 2 - kalah."""
    syms = TP.history_symbols(store, "scalping", 4)
    S = TP._series_from_store(store, syms[0], "scalping")
    g = TP.AG.get_ctx(S, S.h, S.l, S.c)
    price = float(S.c[-1])
    walls = [{"side": "BUY", "price": price * 0.99, "usdt": 2e6, "seen": 3}, {"side": "SELL", "price": price * 1.01, "usdt": 2e6, "seen": 3}]
    for d in (1, -1):
        e, w = TP.wall_entry(S, g, d, walls)
        assert (e > w["price"]) if d == 1 else (e < w["price"])         # di DEPAN tembok
        sl = TP.AG.sl_at(g, S.n - 1, d == 1, e, walls)
        st = TP.wall_stats(S, "scalping", d, e, sl, 3.0)
        assert st["entry"] == TP.ENTRY_WALL and st["live_bt"]
        w_ = st["wr"] / 100
        assert st["exp_r"] == pytest.approx(w_ * 2 - (1 - w_)) and st["ok"] == (st["n"] >= TP._min_trades() and st["exp_r"] > 0)
    ST = TP.learn(store, "scalping", syms)["stats"]
    S.walls = walls
    for p in TP.current_signals(S, "scalping", ST):                    # tidak error & entry dari kandidat Whale
        assert p["entry_name"] in ("market", TP.ENTRY_SWING, TP.ENTRY_WALL)


def test_examples(store):
    """🔍 Contoh trade: kejadian terbaru per setup × arah × entry, level & hasil konsisten."""
    syms = TP.history_symbols(store, "scalping", 4)
    ST = TP.learn(store, "scalping", syms)["stats"]
    any_ = False
    for v in ST.values():
        X = v["examples"]
        assert len(X) <= TP.N_EXAMPLES and [x["t"] for x in X] == sorted(x["t"] for x in X)
        for x in X:
            any_ = True
            d = x["d"]
            assert (x["sl"] < x["e"] < x["tp1"] < x["tp2"]) if d == 1 else (x["tp2"] < x["tp1"] < x["e"] < x["sl"])
            if x["filled"]:
                assert x["res"] in ("SL", "waktu habis", "TP1 → TP2", "TP1 → BE", "TP1 → waktu habis") and x["win"] == x["res"].startswith("TP1")
                if x["res"] == "SL":
                    assert x["R"] == -1.0
    assert any_
