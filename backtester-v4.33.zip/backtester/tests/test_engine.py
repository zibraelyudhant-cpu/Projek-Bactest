"""Tes fill model + tes look-ahead. Jalankan dari folder proyek:  python -m pytest -q"""
import os
import sys

import numpy as np
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from backend.backtest import load_strategies, run_backtest  # noqa: E402
from backend.data import Bars, DataStore  # noqa: E402
from backend.engine import AccountConfig, Engine, bar_path, trigger_pos  # noqa: E402
from tools.make_sample_data import make  # noqa: E402

T0 = 1_735_689_600_000
M5 = 300_000


class MemStore:
    """DataStore palsu di memori: bars = list (o,h,l,c) untuk TF 5m."""

    def __init__(self, ohlc):
        a = np.array(ohlc, dtype=float)
        t = T0 + np.arange(len(a), dtype=np.int64) * M5
        self.bars = {"5m": Bars(t, a[:, 0], a[:, 1], a[:, 2], a[:, 3], np.ones(len(a)))}
        self.catalog = {"X": {"5m": None}}

    def base_tf(self, s):
        return "5m"

    def timeframes(self, s):
        return ["5m"]

    def get(self, s, tf):
        return self.bars[tf]


def eng(ohlc, **cfg):
    return Engine(MemStore(ohlc), "X", T0 + M5, cfg=AccountConfig(slippage_bps=0, **cfg))


# ---------------------------------------------------------------- jalur intrabar
def test_path_and_trigger():
    assert bar_path(10, 12, 9, 11) == [10, 9, 12, 11]   # bullish: low dulu
    assert bar_path(10, 12, 9, 9.5) == [10, 12, 9, 9.5]  # bearish: high dulu
    p = [10, 9, 12, 11]
    assert trigger_pos(p, 0, 9.5, -1) == pytest.approx(0.5)
    assert trigger_pos(p, 0, 9, -1, strict=True) is None   # cuma menyentuh, tidak tembus
    assert trigger_pos(p, 0, 9, -1, strict=False) == pytest.approx(1.0)
    assert trigger_pos(p, 1.0, 11.5, 1) == pytest.approx(1 + 2.5 / 3)


# ---------------------------------------------------------------- order baru aktif bar berikutnya
def test_order_not_filled_on_past_bar():
    e = eng([(100, 101, 99, 100), (100, 100.5, 99.8, 100.2), (100, 100.2, 98, 99)])
    e.place("buy", "limit", 1, 99.5)   # bar sebelumnya (low 99) sudah lewat: tidak boleh fill
    e.step()
    assert e.pos == 0
    e.step()
    assert e.pos == 1 and e.fills[-1]["price"] == 99.5 and e.fills[-1]["liquidity"] == "maker"


def test_market_fills_next_open():
    e = eng([(100, 100, 100, 100), (101, 102, 100, 101.5)])
    e.place("buy", "market", 1)
    e.step()
    assert e.fills[-1]["price"] == 101 and e.fills[-1]["liquidity"] == "taker"


def test_limit_through_vs_touch():
    bars = [(100, 100, 100, 100), (100, 100.5, 99, 100)]
    e = eng(bars)  # default "through": low == limit tidak fill
    e.place("buy", "limit", 1, 99)
    e.step()
    assert e.pos == 0
    e = eng(bars, limit_fill="touch")
    e.place("buy", "limit", 1, 99)
    e.step()
    assert e.pos == 1


def test_marketable_limit_is_taker_at_open():
    e = eng([(100, 100, 100, 100), (98, 99, 97, 98)])
    e.place("buy", "limit", 1, 99)   # open 98 < limit -> langsung fill di 98 (taker)
    e.step()
    assert e.fills[-1]["price"] == 98 and e.fills[-1]["liquidity"] == "taker"


def test_resting_limit_gap_fills_at_limit():
    e = eng([(100, 100, 100, 100), (100, 100.2, 99.9, 100), (97, 98, 96, 97.5)])
    e.place("buy", "limit", 1, 99)
    e.step()
    e.step()   # gap ke 97: resting limit fill di 99, maker
    assert e.fills[-1]["price"] == 99 and e.fills[-1]["liquidity"] == "maker"


def test_stop_gap_fills_at_open_worse():
    e = eng([(100, 100, 100, 100), (100, 100.2, 99.9, 100), (103, 104, 102.5, 103.5)])
    e.place("buy", "stop", 1, 101)
    e.step()
    e.step()
    assert e.fills[-1]["price"] == 103


def test_entry_and_sl_same_bar_in_order():
    # bullish bar: O->L->H->C. Entry limit 99 kena di jalan turun, SL 98 kena sesudahnya (low 97)
    e = eng([(100, 100, 100, 100), (100, 103, 97, 102)])
    e.place("buy", "limit", 1, 99, tp=110, sl=98)
    e.step()
    assert e.pos == 0 and [f["tag"] for f in e.fills] == ["limit", "sl"]


def test_tp_not_hit_before_entry_in_same_bar():
    # bearish bar: O->H->L->C. High 103 terjadi SEBELUM entry di 99, jadi TP 102 tidak boleh kena
    e = eng([(100, 100, 100, 100), (100, 103, 98, 98.5)])
    e.place("buy", "limit", 1, 99, tp=102, sl=90)
    e.step()
    assert e.pos == 1 and len(e.fills) == 1


def test_oco_and_pessimistic_mode():
    bars = [(100, 100, 100, 100), (100, 100, 100, 100), (100, 106, 94, 105)]
    for mode, tag in (("ohlc", "sl"), ("pessimistic", "sl")):
        e = eng(bars, intrabar=mode)
        e.place("buy", "market", 1, tp=105, sl=95)
        e.step()
        e.step()
        assert e.pos == 0 and e.fills[-1]["tag"] == tag
        assert not e.open_orders()  # TP ikut batal (OCO)


def test_pnl_fee_and_trade_record():
    e = Engine(MemStore([(100, 100, 100, 100), (100, 100, 100, 100), (110, 110, 110, 110)]), "X", T0 + M5,
               cfg=AccountConfig(balance=1000, slippage_bps=0, taker_fee=0.001))
    e.place("buy", "market", 1)
    e.step()
    e.close_position()
    e.step()
    assert e.balance == pytest.approx(1000 + 10 - 0.1 - 0.11)
    assert len(e.trades) == 1 and e.trades[0]["pnl"] == pytest.approx(10 - 0.21)


def test_liquidation_before_far_sl():
    e = eng([(100, 100, 100, 100), (100, 100, 100, 100), (100, 100, 80, 85)], leverage=10, use_margin=True)
    e.place("buy", "market", 1, sl=70)
    e.step()
    e.step()
    assert e.pos == 0 and e.fills[-1]["type"] == "liquidation"


def test_no_margin_mode_default():
    e = eng([(100, 100, 100, 100), (100, 100, 100, 100), (100, 100, 50, 60)], balance=100)
    e.place("buy", "market", 10)   # tanpa margin: tidak ditolak, tidak dilikuidasi
    e.step()
    e.step()
    assert e.pos == 10 and e.liq_price() is None and e.equity() == pytest.approx(100 - 400 - 0.5)


def test_margin_reject():
    e = eng([(100, 100, 100, 100), (100, 100, 100, 100)], balance=100, leverage=5, use_margin=True)
    e.place("buy", "market", 10)   # butuh margin 200 > 100
    e.step()
    assert e.pos == 0


# ---------------------------------------------------------------- look-ahead
@pytest.fixture(scope="module")
def sample_store(tmp_path_factory):
    d = tmp_path_factory.mktemp("data")
    make(str(d), days=120)
    return DataStore(str(d))


def test_forming_bar_uses_only_past(sample_store):
    s = sample_store
    e = Engine(s, "SAMPLEUSDT", T0 + 86_400_000 * 5 + 3_600_000 * 2 + 15 * 60_000)   # 02:15
    f = e.view.forming("4h")
    m5 = s.get("SAMPLEUSDT", "5m")
    i0 = np.searchsorted(m5.t, f["time"] * 1000)
    i1 = np.searchsorted(m5.t, e.now)
    assert i1 - i0 == 27  # 00:00 .. 02:10
    assert f["high"] == m5.h[i0:i1].max() and f["close"] == m5.c[i1 - 1]
    assert all(e.view.closed("4h", None).t + 14_400_000 <= e.now)


@pytest.mark.parametrize("strategy", sorted(load_strategies(os.path.join(ROOT, "strategies"))))
def test_future_poison_invariance(sample_store, tmp_path, strategy):
    """Data setelah T diganti angka acak. Semua yang dilihat strategi (closed + forming, semua TF)
    sampai T dan semua fill sebelum T harus identik dengan run di data asli."""
    base = load_strategies(os.path.join(ROOT, "strategies"))[strategy]
    cut = T0 + 80 * 86_400_000
    tfs = sample_store.file_timeframes("SAMPLEUSDT")

    def recorder():
        log = []

        class Rec(base):
            def on_bar(self, ctx):
                if ctx.now <= cut:
                    for tf in tfs:
                        b = ctx.closed(tf, 30)
                        log.append((ctx.now, tf, b.t.tobytes(), b.o.tobytes(), b.h.tobytes(),
                                    b.l.tobytes(), b.c.tobytes(), str(ctx._e.view.forming(tf))))
                super().on_bar(ctx)
        return Rec, log

    d = tmp_path / "poison"
    d.mkdir()
    rng = np.random.default_rng(1)
    for tf in tfs:
        b = sample_store.get("SAMPLEUSDT", tf)
        k = b.t < cut
        junk = lambda x: np.where(k, x, rng.uniform(1, 1000, len(x)))  # noqa: E731
        o, c, x1, x2 = junk(b.o), junk(b.c), junk(b.h), junk(b.l)
        np.savez(d / f"SAMPLEUSDT_{tf}.npz", t=b.t, o=o, c=c, v=b.v,
                 h=np.where(k, b.h, np.maximum.reduce([o, c, x1, x2])),
                 l=np.where(k, b.l, np.minimum.reduce([o, c, x1, x2])))

    r1, log1 = recorder()
    full = run_backtest(sample_store, "SAMPLEUSDT", r1)
    r2, log2 = recorder()
    poisoned = run_backtest(DataStore(str(d)), "SAMPLEUSDT", r2)
    assert len(log1) > 1000 and log1 == log2
    f1 = [f for f in full["fills"] if f["time"] < cut]
    f2 = [f for f in poisoned["fills"] if f["time"] < cut]
    assert strategy != "EmaCross" or len(f1) > 5, "strategi contoh harus menghasilkan fill"
    assert f1 == f2


def test_limit_price_modes():
    from types import SimpleNamespace as NS

    from backend.strategy import Context
    e = eng([(100, 100, 100, 100)] * 40)
    ctx = Context(e, "5m")
    p = lambda m: NS(entry=m, limit_offset_pct=1.0, limit_atr=0.5)  # noqa: E731
    assert ctx.limit_price("buy", 100, p("market")) == (100, "market")
    assert ctx.limit_price("buy", 100, p("limit_close")) == (100, "limit")
    assert ctx.limit_price("buy", 100, p("limit_pct"))[0] == pytest.approx(99)
    assert ctx.limit_price("sell", 100, p("limit_pct"))[0] == pytest.approx(101)
    assert ctx.limit_price("buy", 100, p("limit_level"), level=97) == (97, "limit")
    assert ctx.limit_price("buy", 100, p("limit_mid"), level=97, mid=98) == (98, "limit")
    assert ctx.limit_price("buy", 100, p("limit_level"), level=101) == (100, "market")      # level sudah dilewati
    assert ctx.limit_price("buy", 100, p("limit_level"), level=95, sl=96) == (100, "market")  # limit melewati SL
    assert ctx.limit_price("buy", 100, p("retest"), level=97) == (97, "limit")              # nama lama tetap jalan


@pytest.mark.parametrize("strategy", ["EmaCross", "SMC"])
def test_filters_no_lookahead(sample_store, tmp_path, strategy):
    """Filter umum (struktur TF besar/eksekusi + ADX) juga tidak boleh melihat data masa depan."""
    cls = load_strategies(os.path.join(ROOT, "strategies"))[strategy]
    params = {"ms_filter_tf": "4h", "ms_confirm_tf": "1h", "adx_filter_tf": "4h", "adx_filter_min": 15}
    cut = T0 + 80 * 86_400_000
    d = tmp_path / "poison"
    d.mkdir()
    rng = np.random.default_rng(2)
    for tf in sample_store.file_timeframes("SAMPLEUSDT"):
        b = sample_store.get("SAMPLEUSDT", tf)
        k = b.t < cut
        junk = lambda x: np.where(k, x, rng.uniform(1, 1000, len(x)))  # noqa: E731
        o, c, x1, x2 = junk(b.o), junk(b.c), junk(b.h), junk(b.l)
        np.savez(d / f"SAMPLEUSDT_{tf}.npz", t=b.t, o=o, c=c, v=b.v,
                 h=np.where(k, b.h, np.maximum.reduce([o, c, x1, x2])),
                 l=np.where(k, b.l, np.minimum.reduce([o, c, x1, x2])))
    full = run_backtest(sample_store, "SAMPLEUSDT", cls, params)
    poisoned = run_backtest(DataStore(str(d)), "SAMPLEUSDT", cls, params)
    f1 = [f for f in full["fills"] if f["time"] < cut]
    assert f1 == [f for f in poisoned["fills"] if f["time"] < cut]
    plain = run_backtest(sample_store, "SAMPLEUSDT", cls)
    assert len(full["trades"]) <= len(plain["trades"])
    assert strategy != "EmaCross" or len(full["trades"]) < len(plain["trades"])   # filter benar-benar menyaring


def test_evaluate_categories(sample_store):
    from backend.evaluate import advise, diagnose, merge
    cls = load_strategies(os.path.join(ROOT, "strategies"))["SMC"]
    res = run_backtest(sample_store, "SAMPLEUSDT", cls)
    raw, labels = diagnose(sample_store, "SAMPLEUSDT", res, cls.timeframe)
    assert len(labels) == len(res["trades"]) == raw["trades"]
    assert raw["losses"] == sum(e["n"] for e in raw["cats"].values())
    assert all(t.get("exit_reason") in ("tp", "sl", "end_of_test") for t in res["trades"])
    assert all(t.get("sl") and t.get("tp") for t in res["trades"])
    both = merge(raw, raw)
    assert both["trades"] == 2 * raw["trades"] and both["max_streak"] == raw["max_streak"]
    rep = advise(both, res["params"])
    assert rep["trades"] == 2 * raw["trades"] and isinstance(rep["suggestions"], list)
    for s in rep["suggestions"]:
        for v in s["try"]:
            assert v["params"] and all(k in res["params"] for k in v["params"])


def test_rules_and_adjustments_no_lookahead(sample_store, tmp_path):
    """Filter `rules` + sl_mult / tp_rr / entry_shift_r juga tidak boleh melihat data masa depan."""
    cls = load_strategies(os.path.join(ROOT, "strategies"))["EmaCross"]
    params = {"rules": "rsi@1h >= 45; adx@4h >= 10; sl_atr <= 5; e200@1h >= -50", "sl_mult": 1.5, "tp_rr": 1.5,
              "entry_shift_r": 0.25}
    cut = T0 + 80 * 86_400_000
    d = tmp_path / "poison"
    d.mkdir()
    rng = np.random.default_rng(3)
    for tf in sample_store.file_timeframes("SAMPLEUSDT"):
        b = sample_store.get("SAMPLEUSDT", tf)
        k = b.t < cut
        junk = lambda x: np.where(k, x, rng.uniform(1, 1000, len(x)))  # noqa: E731
        o, c, x1, x2 = junk(b.o), junk(b.c), junk(b.h), junk(b.l)
        np.savez(d / f"SAMPLEUSDT_{tf}.npz", t=b.t, o=o, c=c, v=b.v,
                 h=np.where(k, b.h, np.maximum.reduce([o, c, x1, x2])),
                 l=np.where(k, b.l, np.minimum.reduce([o, c, x1, x2])))
    full = run_backtest(sample_store, "SAMPLEUSDT", cls, params)
    poisoned = run_backtest(DataStore(str(d)), "SAMPLEUSDT", cls, params)
    f1 = [f for f in full["fills"] if f["time"] < cut]
    assert len(f1) > 2 and f1 == [f for f in poisoned["fills"] if f["time"] < cut]
    for t in full["trades"]:   # tp_rr 1.5 dari jarak SL yang sudah dikali sl_mult
        assert abs(abs(t["tp"] - t["entry"]) - 1.5 * abs(t["entry"] - t["sl"])) < 1e-6 * t["entry"]


def test_parse_rules():
    from backend.mining import parse_rules
    assert parse_rules("rsi@1h >= 55; ADX@4h<=30\nsl_atr <= 1.5") == [
        ("rsi", "1h", ">=", 55.0), ("adx", "4h", "<=", 30.0), ("sl_atr", None, "<=", 1.5)]
    for bad in ("rsi >= 5", "sl_atr@1h >= 1", "foo@1h >= 1", "rsi@1h => 5", "rsi@7m >= 5"):
        with pytest.raises(ValueError):
            parse_rules(bad)


def test_mining_analysis(sample_store):
    from backend.evaluate import advise, diagnose, merge
    from backend.mining import TF_FEATS, mine
    cls = load_strategies(os.path.join(ROOT, "strategies"))["EmaCross"]
    res = run_backtest(sample_store, "SAMPLEUSDT", cls, {"tf": "15m"})
    raw, _ = diagnose(sample_store, "SAMPLEUSDT", res, cls.timeframe)
    m = mine(sample_store, "SAMPLEUSDT", res, "15m", "1h")
    assert m["X"].shape == (len(res["trades"]), len(m["names"])) and "rsi@1h" in m["names"]
    assert len(m["names"]) == 4 * len(TF_FEATS) + 8   # 15m, 1h, 4h, 1d + geometri
    wins = m["y"] > 0
    g = m["G"][:, 2]   # SL x1: hasil simulasi RR = R asli harus cocok dengan arah hasil sebenarnya (kebanyakan)
    assert np.isfinite(g).all()
    raw["mine"] = merge(m, m)
    assert raw["mine"]["X"].shape[0] == 2 * len(res["trades"])
    rep = advise(raw, res["params"])
    assert rep["deep"]["enough"] and rep["deep"]["base"]["all"]["n"] == 2 * int(np.isfinite(m["y"]).sum())
    for s in rep["plan"]:
        assert s["valid"] in (True, False, None) and s["param"]
    assert wins.any() and (~wins).any()


def test_closed_symbol_no_lookahead(tmp_path):
    """ctx.closed_symbol (data koin lain, mis. BTC) hanya memberi candle yang sudah close di waktu replay."""
    from backend.strategy import Context
    make(str(tmp_path), "AAAUSDT", days=20, seed=1)
    make(str(tmp_path), "BTCUSDT", days=20, seed=2)
    s = DataStore(str(tmp_path))
    e = Engine(s, "AAAUSDT", T0 + 5 * 86_400_000 + 7 * 60_000 * 5)
    ctx = Context(e, "5m")
    for _ in range(50):
        e.step()
        b = ctx.closed_symbol("BTCUSDT", "15m", 20)
        assert len(b) == 20 and b.t[-1] + 900_000 <= e.now < b.t[-1] + 2 * 900_000
    assert ctx.closed_symbol("NOPEUSDT", "15m") is None


def test_money_magnet_modes(sample_store):
    cls = load_strategies(os.path.join(ROOT, "strategies"))["MoneyMagnetScalping"]
    cfg = AccountConfig(maker_fee=0, taker_fee=0, slippage_bps=0, limit_fill="touch")
    for mode in ("tp1", "tp2", "split"):
        r = run_backtest(sample_store, "SAMPLEUSDT", cls, {"tp_mode": mode}, cfg=cfg)
        assert r["metrics"]["trades"] > 0
        for t in r["trades"]:
            R = abs(t["entry"] - t["sl"])
            if mode == "tp1":
                assert abs(abs(t["tp"] - t["entry"]) - 2 * R) < 1e-6 * t["entry"]
            else:
                assert abs(t["tp"] - t["entry"]) >= (2 if mode == "split" else 3) * R - 1e-6 * t["entry"]


def test_fib_study_properties(sample_store):
    from backend.fibstudy import BRK, RET, aggregate, merge_agg, study_symbol, summarize
    r = study_symbol(sample_store, "SAMPLEUSDT", {"tf": "15m", "regime_tf": "4h"})
    assert r is not None and len(r["t"]) > 50
    assert (np.diff(r["t"]) >= 0).all()
    # limit hanya bisa terisi kalau eligible; level lebih dalam lebih jarang tersentuh
    assert not (r["fill"] & ~r["elig"]).any()
    agg = aggregate(r)
    res = summarize(agg, {})
    g = res["groups"][0]
    assert res["n"] == len(r["t"])
    two = summarize(merge_agg(aggregate(r), aggregate(r)), {})["groups"][0]   # dua koin identik = hitungan dobel
    assert two["n"] == 2 * g["n"] and two["levels"][3]["wr_0"] == g["levels"][3]["wr_0"]
    touch = [x["touch"] for x in g["levels"]]
    assert all(a >= b for a, b in zip(touch, touch[1:]))
    for x in g["levels"]:
        for t in ("0", "-0.272", "-0.618"):
            assert x["wr_" + t] is None or 0 <= x["wr_" + t] <= 100
    for x in g["breaks"]:
        assert x["broke"] == 0 or abs(x["bos_pct"] + x["fake_pct"] + x["open_pct"] - 100) < 1e-6
    assert len(g["levels"]) == len(RET) and len(g["breaks"]) == len(BRK)
    assert sum(gr["n"] for gr in res["groups"][1:]) == g["n"]   # 6 kelompok = semua gelombang


def test_fib_precision_consistent_with_study(sample_store):
    """Strategi FibPrecision memakai aturan yang sama: setiap trade = limit di level, SL di luar 1.0, TP di 0."""
    cls = load_strategies(os.path.join(ROOT, "strategies"))["FibPrecision"]
    lv = {k: 0.618 for k in ("lvl_bull_up", "lvl_bull_down", "lvl_bear_up", "lvl_bear_down", "lvl_side_up", "lvl_side_down")}
    r = run_backtest(sample_store, "SAMPLEUSDT", cls, lv, cfg=AccountConfig(maker_fee=0, taker_fee=0, slippage_bps=0, limit_fill="touch"))
    assert r["metrics"]["trades"] > 5
    for t in r["trades"]:
        assert t["order_type"] == "limit"
        # entry di 0.618 antara 0 (TP) dan 1.0 (dekat SL): jarak TP / jarak (SL-ish) ~ 0.618 / 0.382
        assert abs(t["tp"] - t["entry"]) > abs(t["entry"] - t["sl"]) * 1.2


def test_fib_conclusion(sample_store):
    from backend.fibstudy import aggregate, study_symbol, summarize
    res = summarize(aggregate(study_symbol(sample_store, "SAMPLEUSDT", {"tf": "15m", "regime_tf": "4h"})), {})
    regs = [c["regime"] for c in res["conclusion"]]
    assert regs == ["Bullish", "Bearish", "Sideways"]
    assert [g["name"] for g in res["groups"]][:3] == ["Semua setup", "Bullish · koreksi searah tren (BUY)",
                                                       "Bullish · koreksi melawan tren (SELL)"]
    sides = [[it["side"] for it in c["items"]] for c in res["conclusion"]]
    assert sides == [["BUY"], ["SELL"], ["BUY", "SELL"]]
    for c in res["conclusion"]:
        for it in c["items"]:
            if it.get("entry") is not None:
                assert 0 < it["entry"] < 1 and it["tp1"]["level"] < it["entry"] and it["tp1"]["pct"] >= 60
                assert it["tp2"] is None or (it["tp2"]["level"] < it["tp1"]["level"] and it["tp2"]["pct"] >= 35)
                assert it["exp_r"] > 0
                rows = (it.get("sl") or {}).get("rows") or []
                wr = [r["win_rate"] for r in rows]
                assert all(x <= y + 1e-9 for x, y in zip(wr, wr[1:]))   # SL makin jauh -> WR tidak turun
                assert all(r["level"] > it["entry"] for r in rows)
    for g in res["groups"]:   # kekuatan level: respek naik kalau SL (k ATR) makin longgar; S/R flip <= semua sentuhan
        for r in g.get("strength") or []:
            vals = [v for v in r["respect"] if v is not None]
            assert all(x <= y + 1e-9 for x, y in zip(vals, vals[1:]))
            assert r["conf_n"] <= r["n"]
        pw = g.get("power")
        if pw:
            assert pw["best"]["level"] < pw["alarm"] and 0.382 <= pw["best"]["level"]
    for g in res["groups"]:   # breakout: lanjut + palsu <= tembus, dan lanjut naik kalau tembusnya makin jauh (umumnya)
        for r in g.get("breakout") or []:
            assert r["ok_pct"] + r["fake_pct"] <= 100 + 1e-9
    for g in res["groups"]:   # entry selalu lebih dangkal dari level alarm
        pl = g.get("plan") or {}
        if pl.get("entry") is not None and pl.get("alarm"):
            assert pl["entry"] < pl["alarm"]["level"]
    # peluang TP makin kecil untuk target yang makin jauh
    for lv in res["groups"][0]["levels"]:
        pcts = [t["pct"] for t in lv.get("tp", [])]
        assert all(a >= b for a, b in zip(pcts, pcts[1:]))


def test_breakout_fibo_grid(sample_store):
    from backend.fibgrid import ENTRY_G, TP_G, merge, simulate, summarize
    cls = load_strategies(os.path.join(ROOT, "strategies"))["BreakoutFibo"]
    r = run_backtest(sample_store, "SAMPLEUSDT", cls, {"vol_mult": 0}, cfg=AccountConfig(maker_fee=0, taker_fee=0, slippage_bps=0, limit_fill="touch"))
    assert r["setups"], "strategi harus menemukan setup di data sampel"
    for s in r["setups"]:
        assert s["d"] in (1, -1) and s["atr"] > 0 and (s["B"] - s["A"]) * s["d"] > 0
    agg = simulate(sample_store.get("SAMPLEUSDT", "5m"), r["setups"], r["params"])
    two = summarize(merge(simulate(sample_store.get("SAMPLEUSDT", "5m"), r["setups"], r["params"]), agg), {})
    one = summarize(simulate(sample_store.get("SAMPLEUSDT", "5m"), r["setups"], r["params"]), {})
    assert two["n"] == 2 * one["n"] and len(one["rows"]) <= len(ENTRY_G) * len(TP_G)
    for row in one["rows"]:
        assert 0 <= row["win_rate"] <= 100 and row["fill_pct"] <= 100 + 1e-9


def test_fib_trend_bos_choch(sample_store):
    """Studi BOS / CHoCH saat tren EMA 50/200 (TF bisa diubah): persen masuk akal & makin dalam tembus makin sering CHoCH."""
    from backend.fibstudy import TLV, aggregate, study_symbol, summarize
    for ttf in ("1h", "4h"):
        r = study_symbol(sample_store, "SAMPLEUSDT", {"tf": "15m", "regime_tf": "4h", "trend_tf": ttf})
        res = summarize(aggregate(r), {"trend_tf": ttf})
        T = res["trend"]
        assert T["tf"] == ttf and [g["side"] for g in T["sides"]] == ["BUY", "SELL"]
        for g in T["sides"]:
            if not g["n"]:
                continue
            assert abs(sum(g["end"].values()) - 100) < 1e-6
            assert [x["level"] for x in g["rows"]] == TLV
            for x in g["rows"]:
                if x["broke"]:
                    assert x["choch_pct"] + x["bos_pct"] <= 100 + 1e-6
                    if x["retest"]:
                        rt = x["retest"]
                        assert 0 <= rt["direct"] <= 100 and rt["med"] <= 1
                        ps = [v["pct"] for v in rt["reach"]]
                        assert ps == sorted(ps) and abs(ps[-1] + rt["direct"] - 100) < 1e-6
                    assert 0 <= x["choch_pct"] <= 100 and x["reclaim"] <= x["broke"]
            assert abs(g["end"]["bos"] + g["end"]["choch"] + g["end"]["open"] - 100) < 1e-6


def test_fibstudy_v2_levels(sample_store):
    """Studi Fibonacci v2 = mesin sama, set angka fibo & TF default beda; v1 tidak ikut berubah."""
    from backend import fibstudy as F1, fibstudy2 as F2
    assert F2.DEFAULTS["tf"] == "5m" and F2.DEFAULTS["regime_tf"] == "1h" and F2.DEFAULTS["trend_tf"] == "1h"
    assert F1.DEFAULTS["tf"] == "15m" and 0.786 in F1.RET and 0.786 not in F2.RET
    allowed = set(F2.LEVELS)
    for name in ("RET", "BRK", "EXT", "TGT", "BINS", "BOK", "SLC", "TP_CAND", "TLV", "RT_LV"):
        assert set(getattr(F2, name)) <= allowed, name
    r = F2.study_symbol(sample_store, "SAMPLEUSDT", {"tf": "15m", "regime_tf": "4h"})
    res = F2.summarize(F2.aggregate(r), {})
    g = res["groups"][0]
    assert [x["level"] for x in g["levels"]] == F2.RET and [x["level"] for x in g["breaks"]] == F2.BRK
    assert [x["level"] for x in res["trend"]["sides"][0].get("rows", [])] in ([], F2.TLV)


def test_fib_v2_secret_roles(sample_store):
    """Angka rahasia (v2): tiap peran punya angka + penjelasan; angka di rentang wajar; v1 tidak menghitungnya."""
    from backend import fibstudy as F1, fibstudy2 as F2
    res = F2.summarize(F2.aggregate(F2.study_symbol(sample_store, "SAMPLEUSDT", {"tf": "15m", "regime_tf": "4h"})), F2.DEFAULTS)
    roles = [r for g in res["groups"] if g.get("secret") for r in g["secret"]["roles"]]
    assert roles
    for r in roles:
        assert r["lines"] and all(isinstance(x, str) and x for x in r["lines"])
        if r["level"] is not None:
            assert -3 <= r["level"] <= 2.5
    kinds = {r["kind"] for r in roles}
    assert {"stop", "sl"} & kinds
    r1 = F1.summarize(F1.aggregate(F1.study_symbol(sample_store, "SAMPLEUSDT", {"tf": "15m", "regime_tf": "4h"})), {})
    assert not any(g.get("secret") for g in r1["groups"])


def test_fib_examples_match_study(sample_store):
    """Contoh kejadian Studi Fibonacci = gelombang yang sama dengan yang dihitung (bisa dicek di chart)."""
    from backend.fibstudy import RET, TGT, pick_examples, study_symbol
    r = study_symbol(sample_store, "SAMPLEUSDT", {"tf": "15m", "regime_tf": "4h"})
    ex = r["ex"]
    assert len(ex) == len(r["t"]) and [e["t"] for e in ex] == r["t"].tolist()
    for e, fill, dep, end in zip(ex, r["fill"], r["depth"], r["end"]):
        assert e["fill"] == fill.tolist() and abs(e["depth"] - dep) < 1e-3 and e["end"] == end
        assert e["top"] > e["bot"] and len(e["W"]) == len(RET) and len(e["W"][0]) == len(TGT)
        for a in range(len(RET)):
            for b in range(len(TGT)):
                if e["W"][a][b] == 1:
                    assert e["R"][a][b] > 0
                if e["W"][a][b] == -1:
                    assert e["R"][a][b] == -1
                if not e["fill"][a]:
                    assert e["W"][a][b] == 0 and e["R"][a][b] is None
    p = pick_examples(ex, "SAMPLEUSDT", keep=5)
    assert all(x["symbol"] == "SAMPLEUSDT" for x in p) and len(p) <= 5 * 6
    assert [x["t"] for x in p] == sorted((x["t"] for x in p), reverse=True)
