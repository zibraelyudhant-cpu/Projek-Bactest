"""Tes screener live terhadap server tiruan Binance."""
import os
import sys

import numpy as np
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

from backend import indicators as ind  # noqa: E402
from backend.screener import Client, Screener  # noqa: E402
from fake_binance import serve  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def scr(tmp_path_factory):
    d = tmp_path_factory.mktemp("fx")
    for i, sym in enumerate(["AAAUSDT", "BBBUSDT", "CCCUSDT", "DDDUSDT"]):
        make(str(d), symbol=sym, days=40, seed=i)
    srv = serve(str(d))
    yield Screener(Client(f"http://127.0.0.1:{srv.server_address[1]}"))
    srv.shutdown()


def test_symbols_only_trading_perpetual(scr):
    assert scr.symbols() == ["AAAUSDT", "BBBUSDT", "CCCUSDT", "DDDUSDT"]


def test_filter_matches_direct_calculation(scr):
    res = scr.scan("1h", [{"a": {"f": "adx", "len": 14}, "op": "gte", "b": {"v": 25}}], [{"f": "rsi", "len": 14}])
    got = {r["symbol"]: r["values"] for r in res["rows"]}
    for sym in scr.symbols():
        a = scr.cache[(sym, "1h")]
        adx = ind.dmi(a[:, 2], a[:, 3], a[:, 4], 14)[2][-1]
        assert (sym in got) == (adx >= 25)
        if sym in got:
            assert got[sym]["adx(14)"] == pytest.approx(adx)
            assert got[sym]["rsi(14)"] == pytest.approx(ind.rsi(a[:, 4], 14)[-1])
    assert res["columns"] == ["adx(14)", "rsi(14)"] and res["errors"] == 0


def test_compare_two_indicators_and_cross(scr):
    above = scr.scan("4h", [{"a": {"f": "close"}, "op": "gt", "b": {"f": "ema", "len": 50}}])
    below = scr.scan("4h", [{"a": {"f": "close"}, "op": "lte", "b": {"f": "ema", "len": 50}}])
    assert len(above["rows"]) + len(below["rows"]) == 4
    cross = scr.scan("15m", [{"a": {"f": "ema", "len": 9}, "op": "xup", "b": {"f": "ema", "len": 21}}])
    for r in cross["rows"]:
        a = scr.cache[(r["symbol"], "15m")][:, 4]
        f, s = ind.ema(a, 9), ind.ema(a, 21)
        assert f[-2] <= s[-2] and f[-1] > s[-1]


def test_between_and_daily_change_and_incremental(scr):
    res = scr.scan("1h", [{"a": {"f": "rsi", "len": 14}, "op": "between", "b": {"v": 0}, "b2": {"v": 100}},
                          {"a": {"f": "chg_7d"}, "op": "gt", "b": {"v": -1000}}])
    assert len(res["rows"]) == 4 and all(r["values"]["chg_7d"] is not None for r in res["rows"])
    n = len(scr.cache[("AAAUSDT", "1h")])
    scr.scan("1h", [])                                  # scan kedua: hanya candle terbaru, tidak menumpuk
    assert len(scr.cache[("AAAUSDT", "1h")]) == n


def test_invalid_filter(scr):
    with pytest.raises(ValueError):
        scr.scan("1h", [{"a": {"f": "chg_24h"}, "op": "xup", "b": {"v": 1}}])


def test_market_structure_scan(scr):
    """Scan market structure: koin lolos kalau urutan swing terakhir (lama -> baru) sama dengan kode; 'ANY' = bebas."""
    from backend.screener import ms_labels
    # urutan swing yang sebenarnya untuk tiap koin (200 candle terakhir, fractal 3)
    scr.scan("1h", [], structure={"codes": ["ANY", "ANY", "ANY"], "bars": 200, "swing": 3})
    truth = {}
    for sym in scr.symbols():
        a = scr.cache[(sym, "1h")][-200:]
        truth[sym] = [x[2] for x in ms_labels(a[:, 2], a[:, 3], 3, a[:, 4], 0.0, True)]
    sym0 = next(s for s in truth if len(truth[s]) >= 4)
    codes = truth[sym0][-4:]
    res = scr.scan("1h", [], structure={"codes": codes, "bars": 200, "swing": 3})
    got = {r["symbol"]: r for r in res["rows"]}
    for sym, labs in truth.items():
        assert (sym in got) == (labs[-4:] == codes)
    assert got[sym0]["structure"].replace("*", "") == "-".join(codes)
    # bebas: semua koin dengan >= 3 swing lolos
    res = scr.scan("1h", [], structure={"codes": ["ANY"] * 3, "bars": 200, "swing": 3})
    assert {r["symbol"] for r in res["rows"]} == {s for s, l in truth.items() if len(l) >= 3}
    # swing high & low selang-seling (pola market structure yang benar)
    for labs in truth.values():
        kinds = ["H" if x in ("HH", "LH") else "L" for x in labs]
        assert all(a != b for a, b in zip(kinds, kinds[1:]))
    with pytest.raises(ValueError):
        scr.scan("1h", [], structure={"codes": ["HH", "HL"], "bars": 200})        # minimal 3 baris
    with pytest.raises(ValueError):
        scr.scan("1h", [], structure={"codes": ["HH", "XX", "HL"], "bars": 200})


def test_market_structure_live_and_min_size():
    """Gerakan yang sedang berjalan ikut dihitung (struktur patah langsung terlihat) & swing kecil bisa diabaikan."""
    from backend.screener import ms_labels
    # tren naik HL-HH lalu jatuh tajam di 2 candle terakhir menembus HL terakhir (belum terkonfirmasi fractal 3)
    pts = [10, 20, 15, 25, 18, 30]
    h, l = [], []
    for a, b in zip(pts, pts[1:]):
        for k in range(6):
            v = a + (b - a) * k / 6
            h.append(v + 0.2)
            l.append(v - 0.2)
    for v in (30, 27, 22, 16):
        h.append(v + 0.2)
        l.append(v - 0.2)
    h, l = np.array(h), np.array(l)
    c = (h + l) / 2
    old = [x[2] for x in ms_labels(h, l, 3)]
    new = ms_labels(h, l, 3, c, 0.0, True)
    assert old[-1] == "HH"                                   # tanpa gerakan berjalan: masih terlihat naik
    assert new[-1][2] == "LL" and new[-1][4] is True         # dengan gerakan berjalan: low baru di bawah HL = LL*
    # swing kecil (< 1 ATR) dibuang: pantulan mini tidak jadi HH/HL baru
    pts = [10, 14, 11, 16, 12, 20, 19.6, 20.3, 14, 22]
    h, l = [], []
    for a, b in zip(pts, pts[1:]):
        for k in range(6):
            v = a + (b - a) * k / 6
            h.append(v + 0.3)
            l.append(v - 0.3)
    h.append(22.3)
    l.append(21.7)
    h, l = np.array(h), np.array(l)
    c = (h + l) / 2
    small = [x[2] for x in ms_labels(h, l, 2, c, 0.0, False)]
    big = [x[2] for x in ms_labels(h, l, 2, c, 2.0, False)]
    assert len(big) < len(small)


def test_limit_top_volume_and_progress(scr):
    """Jumlah koin: hanya N koin volume 24 jam terbesar yang dipindai; progres dilaporkan per koin."""
    tick = scr.tickers()
    top2 = sorted(scr.symbols(), key=lambda s: -tick[s]["vol_24h"])[:2]
    seen = []
    res = scr.scan("1h", [], limit=2, progress=lambda k, n, sym, err: seen.append((k, n, sym)))
    assert res["scanned"] == 2 and {r["symbol"] for r in res["rows"]} == set(top2)
    assert [x[0] for x in seen] == [1, 2] and all(x[1] == 2 for x in seen) and {x[2] for x in seen} == set(top2)
