"""🧭 Flow whale: OI, taker buy/sell, long/short top trader & funding diuji vs arah normal (70% awal / 30% terakhir)."""
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
from backend import flowstudy as FS  # noqa: E402
from backend.screener import Client  # noqa: E402
from fake_binance import serve  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def cl(tmp_path_factory):
    d = tmp_path_factory.mktemp("flow")
    for i, s in enumerate(["AAAUSDT", "BBBUSDT", "CCCUSDT"]):
        make(str(d), symbol=s, days=60, seed=i)
    srv = serve(str(d))
    yield Client(f"http://127.0.0.1:{srv.server_address[1]}")
    srv.shutdown()


def test_asof_causal():
    ts = np.array([100, 200, 300])
    v = np.array([1.0, 2.0, 3.0])
    out = FS._asof(ts, v, np.array([50, 100, 250, 999]))
    assert np.isnan(out[0]) and list(out[1:]) == [1.0, 2.0, 3.0]          # hanya nilai yang SUDAH ada


def test_coin_flow_and_paging(cl):
    D = FS.coin_flow(cl, "AAAUSDT", "1h")
    assert D["n_oi"] > 500 and D["n_ls"] > 500                         # >500 baris = halaman ke-2 ikut diambil
    assert np.isfinite(D["taker"][-10:]).all() and ((D["taker"] > 0) & (D["taker"] < 1))[-10:].all()
    i = len(D["c"]) - 1
    st = FS._states(D, i)
    assert set(st) == {"oi", "taker", "ls", "fr"}
    dp = D["c"][i] / D["c"][i - FS.W] - 1
    assert st["oi"].startswith("harga naik" if dp > 0 else "harga turun")


def test_study(cl):
    r = FS.study(cl, "AAAUSDT", "1h", ["BBBUSDT", "CCCUSDT"])
    assert r["n_coins"] == 3 and r["n_samples"] > 100
    assert r["base"]["pct_up"] + r["base"]["pct_down"] == pytest.approx(100)
    for x in r["rows"]:
        up = x["pct_up"] >= 50
        assert x["dir"] == (1 if up else -1)
        assert x["edge"] == pytest.approx((x["pct_up"] - r["base"]["pct_up"]) if up else (x["pct_down"] - r["base"]["pct_down"]))
        assert x["proven"] == bool(x["n"] >= FS.MIN_N and x["n_test"] >= FS.MIN_TEST and x["edge_fit"] is not None
                                   and x["edge_test"] is not None and x["edge_fit"] > 0 and x["edge_test"] > 0)
        assert x["state"] == " · ".join(r["now"][k] for k in x["keys"])
    good = [x for x in r["rows"] if x["proven"] and x["edge"] > 0]
    if r["conflict"]:                                                   # sinyal terbukti berlawanan -> tidak ada arah
        assert r["best"] is None and len({x["dir"] for x in good}) == 2
    elif good:
        assert r["best"] in good
    else:
        assert r["best"] is None
    with pytest.raises(ValueError):
        FS.study(cl, "AAAUSDT", "2h")


def test_enrich_setups(cl):
    """Flow digabung ke 🎯 Cari setup: info searah / melawan + uji WR (cara baca flow dari 70% waktu awal saja)."""
    from backend.whales import scan_setups
    r = scan_setups(cl, n_coins=3, rr=[2.0], top=6, min_usdt=100_000)
    ft = r["flow_test"]
    assert "overall" in ft and ft["overall"]["verdict"] in ("terbukti membantu", "belum cukup data", "tidak terbukti membantu")
    for s in r["setups"]:
        f = s["flow"]
        assert f["agree"] in ("agree", "against", "neutral") and f["lean"] in (-1, 0, 1)
        side = 1 if s["side"] == "BUY" else -1
        assert f["agree"] == ("agree" if f["lean"] == side else "against" if f["lean"] == -side else "neutral")
    o = ft["overall"]
    assert o["helps"] == bool(o["gap_fit"] is not None and o["gap_test"] is not None and o["gap_fit"] >= 5 and o["gap_test"] >= 5)


def test_vote_table_only_fit():
    """Tabel arah flow hanya dari data CARI (waktu < split): sampel sesudah split tidak mempengaruhi."""
    S = [(t, 1, {"taker": "pembeli agresif dominan"}) for t in range(40)] + [(t, -1, {"taker": "penjual agresif dominan"}) for t in range(40)]
    S += [(t, -1, {"taker": "pembeli agresif dominan"}) for t in range(100, 400)]   # data uji berlawanan
    tb = FS._vote_table(S, 50)
    assert tb == {("taker", "pembeli agresif dominan"): 1, ("taker", "penjual agresif dominan"): -1}
    assert FS._lean(tb, {"taker": "pembeli agresif dominan"}) == (1, 1) and FS._lean(tb, {}) == (0, 0)
