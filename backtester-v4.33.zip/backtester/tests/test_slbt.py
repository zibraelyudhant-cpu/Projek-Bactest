"""🛡️ SL Backtest: sinyal dari 5 strategi, SL default + SL ATR 1..6 (TP RR 1:2), kotak ATR, batas 5 hari, TP1 / ½, endpoint."""
import contextlib
import io
import os
import sys
import time

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend import slbt as SB  # noqa: E402
from backend.data import DataStore  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("slbt")
    with contextlib.redirect_stdout(io.StringIO()):
        for i, s_ in enumerate(("BTCUSDT", "AAAUSDT", "BBBUSDT")):
            make(str(d), symbol=s_, days=150, seed=i + 1)
    return DataStore(str(d))


def test_constants():
    assert SB.KEYS == ["1", "1.5", "2", "2.5", "3", "3.5", "4", "4.5", "5", "5.5", "6"]
    assert SB.hold_bars("15m") == 480 and SB.hold_bars("1h") == 120 and SB.hold_bars("4h") == 30   # 5 hari


def _D(n=400):
    t = np.arange(n, dtype=np.int64) * 3_600_000
    c = np.full(n, 100.0)
    D = {"t": t, "o": c.copy(), "h": c + 0.1, "l": c - 0.1, "c": c.copy(), "v": np.ones(n), "a": np.full(n, 1.0)}
    return D


def test_box_rules_synthetic():
    """LONG entry 100, ATR 1: turun ke 96.5 (lewat ATR 3, belum ATR 4) lalu naik ke 108 -> kotak ATR 4 WIN."""
    D = _D()
    D["l"][12] = 96.5
    D["h"][30] = 108.5
    x = {"s": 10, "d": 1, "en": "market", "e": 100.0, "sl0": 99.0, "mk": True, "f": 10}
    r = SB.eval_signal(D, x, 120)
    assert r["def"][0] == "sl" and r["box"] == "4" and r["per"]["4"][0] == "win"
    assert all(r["per"][k][0] == "sl" for k in ("1", "1.5", "2", "2.5", "3", "3.5"))
    assert r["mae"] == pytest.approx(3.5)
    D["l"][12] = 93.5                                     # lewat ATR 6 -> benar-benar LOSE (tidak ada kotak)
    assert SB.eval_signal(D, x, 120)["box"] is None


def test_timeout_tp1_half_lose():
    D = _D()
    D["l"][12] = 98.5                                     # kotak ATR 2 (TP 104, RR 1:1 = 102)
    D["h"][20] = 102.5                                    # sempat RR 1:1, tidak sampai TP -> TP1 +1R
    x = {"s": 10, "d": 1, "en": "market", "e": 100.0, "sl0": 99.9, "mk": True, "f": 10}
    r = SB.eval_signal(D, x, 120)
    assert r["box"] == "2" and r["per"]["2"][0] == "tp1"
    D["h"][20] = 100.6; D["c"][130] = 100.5               # tidak sampai 1:1, akhir 5 hari di atas entry -> ½
    assert SB.eval_signal(D, x, 120)["per"]["2"][0] == "half"
    D["c"][130] = 99.5                                    # akhir 5 hari di area SL -> LOSE
    assert SB.eval_signal(D, x, 120)["per"]["2"][0] == "lose"
    x2 = dict(x, d=-1, sl0=100.1)                         # cermin SHORT: naik ke 101.5 lalu turun ke 96.9 -> kotak 1.5... TP 97
    D2 = _D(); D2["h"][12] = 101.4; D2["l"][20] = 96.9
    r2 = SB.eval_signal(D2, x2, 120)
    assert r2["box"] == "1.5" and r2["per"]["1.5"][0] == "win" and r2["def"][0] == "sl"


@pytest.mark.parametrize("strat", list(SB.STRATS))
def test_each_strategy(store, strat):
    D = SB.load(store, "BTCUSDT", "1h")
    sig = SB.signals(strat, D, "1h", store, "BTCUSDT")
    assert sig, strat
    for x in sig[:300]:
        assert x["d"] in (1, -1) and (x["e"] - x["sl0"]) * x["d"] > 0                 # SL default di sisi rugi
        if x["mk"]:
            assert x["f"] == x["s"]
        elif x["f"] is not None:
            assert x["f"] > x["s"] - 1
    G, EX = SB.coin_eval("BTCUSDT", D, "1h", strat, store)
    A = SB.analyse(G)
    if G["n"]:
        assert A["best"]["all"]["win"] == max(r["all"]["win"] for r in A["rows"])
        assert sum(r["box_n"] for r in A["rows"]) + A["lose"] == G["n"]
        for e in EX[:50]:
            k = float(e["box"]) if e["box"] else 6.0
            assert abs(e["e"] - e["sl"]) == pytest.approx(k * e["A"]) and abs(e["tp"] - e["e"]) == pytest.approx(2 * k * e["A"])


def test_run_parallel_cache_api(store, monkeypatch, tmp_path):
    from backend import results_store
    monkeypatch.setattr(results_store, "BASE", str(tmp_path))
    syms = SB.history_symbols(store, "1h", 3)
    pushes = []
    a = SB.run(store, "1h", "whale", syms, workers=2, push=lambda p: pushes.append(p["phase"]))
    SB._CACHE.clear(); os.remove(SB._disk("1h", "whale"))
    b = SB.run(store, "1h", "whale", syms, workers=1)
    assert a["n"] == b["n"] and a["best"]["k"] == b["best"]["k"] and pushes[-1] == "analisa"
    assert SB.run(store, "1h", "whale", syms) is b
    monkeypatch.setenv("DATA_DIR", store.data_dir)
    import importlib

    import backend.app as app_mod
    importlib.reload(app_mod)
    app_mod.store = store
    from fastapi.testclient import TestClient
    client = TestClient(app_mod.app)
    assert client.post("/api/slbt/run", json={"tf": "7m"}).status_code == 400
    assert client.post("/api/slbt/run", json={"tf": "1h", "strat": "x"}).status_code == 400
    r = client.post("/api/slbt/run", json={"tf": "1h", "strat": "cpat", "hist": 3})
    for _ in range(600):
        st = client.get(f"/api/screener/job/{r.json()['id']}").json()
        if st["status"] != "running":
            break
        time.sleep(0.1)
    assert st["status"] == "done", st
    R = st["result"]
    assert R["strat"] == "cpat" and len(R["coins"]) == 3 and R["saved_id"]
    x = R["examples"][-1]
    j = client.get("/api/slbt/candles", params={"sym": x["sym"], "tf": "1h", "t": x["t"], "after": x["xo"] + 10}).json()
    assert j["candles"][j["i"]][0] == x["t"]
