"""Tes backtest di banyak koin (paralel) lewat endpoint /api/backtest_all."""
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def test_backtest_all(tmp_path):
    from tools.make_sample_data import make
    make(str(tmp_path), "AAAUSDT", days=40, seed=1)
    make(str(tmp_path), "BBBUSDT", days=40, seed=2)
    make(str(tmp_path), "SHORTUSDT", days=10, seed=3)   # data pendek tetap diuji (default min_days 0)
    os.environ["DATA_DIR"] = str(tmp_path)
    import importlib

    import backend.app as app_mod
    importlib.reload(app_mod)
    from fastapi.testclient import TestClient
    client = TestClient(app_mod.app)

    assert client.post("/api/backtest_all", json={"strategy": "Nope"}).status_code == 400
    r = client.post("/api/backtest_all", json={"strategy": "EmaCross", "workers": 2}).json()
    assert r["total"] == 3
    rows, nxt = [], 0
    for _ in range(120):
        st = client.get(f"/api/backtest_all/{r['id']}?since={nxt}").json()
        rows += st["rows"]
        nxt = st["next"]
        if st["status"] != "running":
            break
        time.sleep(0.5)
    assert st["status"] == "done" and st["done"] == 3 and len(rows) == 3
    by = {x["symbol"]: x for x in rows}
    assert "trades" in by["SHORTUSDT"]
    s = st["summary"]
    assert s["coins"] == 3 and s["skipped"] == 0 and s["errors"] == 0
    assert s["trades"] == sum(x["trades"] for x in rows)
    # hasil per koin harus sama dengan backtest satu koin biasa
    one = client.post("/api/backtest", json={"symbol": "AAAUSDT", "strategy": "EmaCross"}).json()["metrics"]
    assert one["trades"] == by["AAAUSDT"]["trades"]
    assert abs(one["net_pnl"] - by["AAAUSDT"]["net_pnl"]) < 1e-9

    # rentang tanggal sebelum data koin ada -> dilewati (tidak ada data sama sekali)
    r = client.post("/api/backtest_all", json={"strategy": "EmaCross", "symbols": ["bbbusdt"], "end": 1}).json()
    assert r["total"] == 1
    for _ in range(60):
        st = client.get(f"/api/backtest_all/{r['id']}").json()
        if st["status"] != "running":
            break
        time.sleep(0.5)
    assert "skipped" in st["rows"][0]
    assert client.get("/api/backtest_all/xxx").status_code == 404


def test_pause_resume_survives_restart(tmp_path):
    """Jeda di tengah jalan -> 'aplikasi ditutup' (objek baru, dimuat dari disk) -> lanjut: hasil sama persis dengan
    proses tanpa jeda, tidak ada koin dobel / hilang, dan file jeda dihapus setelah selesai."""
    from tools.make_sample_data import make
    data, pd = tmp_path / "d", tmp_path / "paused"
    for i, sym in enumerate(("AAAUSDT", "BBBUSDT", "CCCUSDT", "DDDUSDT")):
        make(str(data), sym, days=25, seed=10 + i)
    from backend.multi import Jobs
    strat = os.path.join(ROOT, "strategies")
    syms = ["AAAUSDT", "BBBUSDT", "CCCUSDT", "DDDUSDT"]

    def wait(m, jid, cond, t=120):
        t0 = time.time()
        while not cond(m.jobs[jid]):
            time.sleep(0.1)
            assert time.time() - t0 < t, (m.jobs[jid]["status"], m.jobs[jid]["done"], m.jobs[jid]["inflight"], m.jobs[jid]["thread_alive"], m.jobs[jid].get("error"), len(m.jobs[jid]["pending"]))
    ref = Jobs(str(data), strat, str(pd))
    jr = ref.start(syms, "EmaCross", {}, None, None, {}, workers=1)
    wait(ref, jr, lambda j: j["status"] == "done")
    want = sorted((r["symbol"], r["trades"]) for r in ref.jobs[jr]["rows"])

    a = Jobs(str(data), strat, str(pd))
    jid = a.start(syms, "EmaCross", {}, None, None, {}, workers=1)
    wait(a, jid, lambda j: j["done"] >= 1)
    assert a.pause(jid)
    wait(a, jid, lambda j: not j["thread_alive"])
    if a.jobs[jid]["status"] == "done":              # dijeda tepat saat koin terakhir: langsung selesai, tidak macet
        assert sorted((r["symbol"], r["trades"]) for r in a.jobs[jid]["rows"]) == want and not os.listdir(pd)
        return
    assert a.jobs[jid]["status"] == "paused" and os.listdir(pd)
    assert a.running() is None                       # jeda tidak memblokir proses lain
    b = Jobs(str(data), strat, str(pd))               # aplikasi dibuka lagi
    assert [j["id"] for j in b.paused()] == [jid]
    done_before = b.jobs[jid]["done"]
    assert 1 <= done_before < 4
    assert b.resume(jid)
    wait(b, jid, lambda j: j["status"] == "done")
    got = sorted((r["symbol"], r["trades"]) for r in b.jobs[jid]["rows"])
    assert got == want
    assert not os.listdir(pd)
    # buang proses yang dijeda
    c = Jobs(str(data), strat, str(pd))
    j2 = c.start(syms, "EmaCross", {}, None, None, {}, workers=1)
    wait(c, j2, lambda j: j["done"] >= 1)
    c.pause(j2)
    wait(c, j2, lambda j: not j["thread_alive"])
    if c.jobs[j2]["status"] == "done":
        return
    c.cancel(j2)
    assert c.jobs[j2]["status"] == "cancelled" and not os.listdir(pd)
