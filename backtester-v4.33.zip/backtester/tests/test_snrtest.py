"""Tes 📍 Tes SNR + Dorongan %."""
import json
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend import snrtest as T  # noqa: E402
from backend.data import DataStore  # noqa: E402
from tools.make_sample_data import make  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))


@pytest.mark.parametrize("fx", ["dorongan_js.json", "dorongan_js_s10.json"])
def test_dorongan_same_as_chart(fx):
    # nilai dari indikator "Dorongan %" di chart (doronganCalc di app.js, diambil lewat browser) harus sama persis
    d = json.load(open(os.path.join(HERE, "fixtures", fx)))
    P, D = T.dorongan(np.array(d["h"]), np.array(d["l"]), np.array(d["c"]), np.array(d["v"]), n_smooth=d.get("smooth", 3))
    js = np.array([np.nan if x is None else x for x in d["p"]])
    assert np.array_equal(np.isnan(js), np.isnan(P))
    ok = ~np.isnan(P)
    assert np.allclose(js[ok], P[ok]) and (np.array(d["d"])[ok] == D[ok]).all()
    assert ((P[ok] >= 0) & (P[ok] <= 100)).all()


def test_dorongan_no_lookahead():
    rng = np.random.default_rng(5)
    c = 100 + np.cumsum(rng.normal(0, 1, 800))
    h, l, v = c + rng.uniform(0, 1, 800), c - rng.uniform(0, 1, 800), rng.uniform(10, 100, 800)
    P, D = T.dorongan(h, l, c, v)
    P2, D2 = T.dorongan(h[:500], l[:500], c[:500], v[:500])
    assert np.allclose(P[:500], P2, equal_nan=True) and (D[:500] == D2).all()


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("snrdata")
    make(str(d), symbol="AAAUSDT", days=150)
    make(str(d), symbol="BBBUSDT", days=150, seed=2)
    return DataStore(str(d))


def test_run_tables_and_recommendations(store):
    r = T.run(store, ["AAAUSDT", "BBBUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 10, "target": 55})
    assert r["n_events"] > 0 and set(r["table"]) == {"2", "1.5", "1", "0.5", "sentuh"}
    for band, rows in r["table"].items():
        assert len(rows) == 10
        for x in rows:
            assert x["n"] == x["breakout"] + x["respect"] + x["tidak_sampai"]
            if band == "sentuh":
                assert x["tidak_sampai"] == 0                 # sudah menyentuh -> pasti sampai
    for band, rc in r["rec"].items():
        assert "base" in rc
        if "limit" in rc:
            assert rc["limit"]["train"]["pct_respect"] >= 55
        if "breakout" in rc:
            assert rc["breakout"]["train"]["pct_breakout"] >= 55
    for e in r["examples"]:
        assert e["outcome"] in ("breakout", "respect", "fakeout") and e["side"] in ("support", "resistance")


def test_params_validation():
    with pytest.raises(ValueError):
        T._params({"tf": "1h", "snr_tf": "15m"})            # TF SNR tidak boleh lebih kecil dari TF entry
    q = T._params({"target": 200, "swing": 0})
    assert q["target"] == 95 and q["swing"] == 1



def test_smoothing_makes_it_calmer():
    d = json.load(open(os.path.join(HERE, "fixtures", "dorongan_js_s10.json")))
    a = [np.array(d[k]) for k in "hlcv"]
    ch = lambda P: np.nanmean(np.abs(np.diff(P[~np.isnan(P)])))  # noqa: E731
    assert ch(T.dorongan(*a, n_smooth=10)[0]) < 0.6 * ch(T.dorongan(*a, n_smooth=3)[0])


def test_auc():
    assert T._auc([1, 2, 3, 4], [0, 0, 1, 1]) == 100           # memisahkan sempurna
    assert T._auc([1, 2, 3, 4], [1, 1, 0, 0]) == 0
    assert T._auc([5, 5, 5, 5], [0, 1, 0, 1]) == 50            # tidak membedakan = tebak koin
    assert T._auc([1, 2], [1, 1]) is None


def test_auto_smoothing_and_default(store, monkeypatch, tmp_path):
    monkeypatch.setattr(T, "DEF_FILE", str(tmp_path / "def.json"))
    r = T.run(store, ["AAAUSDT", "BBBUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 10, "auto_smooth": True})
    assert [x["smooth"] for x in r["compare"]] == T.SMOOTHS
    ok = [x for x in r["compare"] if x["auc_train"] is not None and x["n_train"] >= 10]
    assert r["smooth"] == max(ok, key=lambda x: (round(x["auc_train"], 1), -abs(x["smooth"] - 10)))["smooth"]   # dipilih dari data CARI
    best = next(x for x in r["compare"] if x["smooth"] == r["smooth"])
    if r["saved_default"]:
        assert best["auc_test"] >= T.MIN_AUC and T.load_defaults()["15m"]["smooth"] == r["smooth"]
    else:
        assert T.load_defaults() == {}                             # tidak lolos uji -> default tidak diubah
    # memaksa lolos: batas diturunkan -> tersimpan
    monkeypatch.setattr(T, "MIN_AUC", 0.0)
    r2 = T.run(store, ["AAAUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 5, "auto_smooth": True})
    assert r2["saved_default"] and T.load_defaults()["15m"]["smooth"] == r2["smooth"]
    r3 = T.run(store, ["AAAUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 5, "auto_smooth": False, "smooth": 7})
    assert r3["smooth"] == 7 and len(r3["compare"]) == 1 and r3["saved_default"] is None


def test_midline(store):
    r = T.run(store, ["AAAUSDT", "BBBUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 10, "auto_smooth": False})
    m = r["midline"]
    assert m and 10 <= m["line"] <= 90 and m["line"] % 5 == 0 and m["n_above"] + m["n_below"] > 0
    assert m["sep_train"] >= 0
    # kasus buatan: breakout selalu Dorongan tinggi, respect rendah -> garis di antaranya, pemisahan 100
    vals = [80.0] * 10 + [20.0] * 10
    brk = [True] * 10 + [False] * 10
    tst = [False, True] * 10
    mm = T._midline(vals, brk, tst)
    assert 25 <= mm["line"] <= 80 and mm["sep_train"] == 100 and mm["sep_test"] == 100


def test_factors_and_breakout_followthrough(store):
    r = T.run(store, ["AAAUSDT", "BBBUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 10, "auto_smooth": False, "workers": 1})
    F = r["factors"]
    o = F["overall"]["train"]
    assert o["n"] == o["respect"] + o["breakout"] and o["fakeout"] <= o["respect"]
    assert o["lanjut"] + o["gagal"] <= o["breakout"] + o["fakeout"]     # lanjut dihitung dari semua close tembus
    assert {f["key"] for f in F["factors"]} == {"trend", "touches", "age", "speed"}
    for f in F["factors"]:                                   # tiap faktor membagi semua kejadian (jumlah = keseluruhan)
        assert sum(x["train"]["n"] for x in f["rows"]) == o["n"]
    for c in F["best_limit"]:
        assert c["train"]["n"] >= 10 and "belum cukup data" not in c["label"]
    lims = [c["train"]["pct_respect"] for c in F["best_limit"]]
    assert lims == sorted(lims, reverse=True)


def test_followthrough_rules():
    c = np.array([10.5, 10.6, 11.0, 11.6, 11.7])           # resistance 10, tembus di candle 0 (close 10.5), ATR 1
    h, l = c + 0.1, c - 0.1
    assert T._follow(h, l, c, 0, 10.0, 1, 1.0, 100) == 1    # sampai 11.5 (close tembus + 1 ATR) sebelum close < 10 -> lanjut
    c2 = np.array([10.5, 10.6, 9.8, 12.0])
    assert T._follow(c2 + 0.1, c2 - 0.1, c2, 0, 10.0, 1, 1.0, 100) == 0      # close balik di bawah 10 dulu -> fakeout
    c3 = np.array([10.5, 9.9])
    h3 = np.array([10.6, 11.6])                              # candle yang sama: sempat 11.6 tapi close 9.9 -> fakeout (hati-hati)
    assert T._follow(h3, c3 - 0.1, c3, 0, 10.0, 1, 1.0, 100) == 0
    c4 = np.array([9.5, 9.4, 8.2])                           # support 10, tembus ke bawah, turun >= 1 ATR -> lanjut
    assert T._follow(c4 + 0.1, c4 - 0.1, c4, 0, 10.0, -1, 1.0, 100) == 1
    assert T._follow(h, l, c, 0, 10.0, 1, 5.0, 100) == -1   # belum jelas sampai data habis


def test_simple_summary(store):
    r = T.run(store, ["AAAUSDT", "BBBUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 10, "auto_smooth": False, "workers": 1})
    S = r["summary"]
    assert S and S["base"]["n"] > 0
    for key, metric in (("limit", "pct_respect"), ("breakout", "pct_breakout")):
        z = S[key]
        if z:
            assert 0 <= z["from"] < z["to"] <= 100 and z["from"] % 10 == 0 and z["to"] % 10 == 0
            assert z["train"][metric] >= S["base"][metric]          # rentang memang lebih baik dari rata-rata (data cari)


def test_fakeout_counts_as_snr_held():
    # resistance 10: close tembus 10.4 lalu dalam 6 candle close balik di bawah 10 -> fakeout (SNR bertahan)
    c = np.array([10.4, 10.5, 10.2, 9.8, 9.5, 9.4, 9.3])
    assert T._holds(c, 0, 10.0, 1, 6) is False
    c2 = np.array([10.4, 10.5, 10.6, 10.8, 10.7, 10.9, 11.0])
    assert T._holds(c2, 0, 10.0, 1, 6) is True                # bertahan 6 candle -> breakout valid
    assert T._holds(np.array([9.6, 9.7, 10.1]), 0, 10.0, -1, 6) is False   # support: close balik di atas -> fakeout
    r = T._rate_from(b=2, r=3, ns=1, f=5)                    # respect (SNR bertahan) = respect + fakeout
    assert r["respect"] == 8 and r["fakeout"] == 5 and r["pct_respect"] == 80 and r["pct_breakout"] == 20 and r["n"] == 11


def test_respect_needs_hold_too():
    # BTC 2026-10-24: sentuh resistance 80620.1 di 22:35, close turun ke 80519.8 (23:05) lalu 23:30 close 80827.5
    # -> pantulan 23:05 BELUM respect karena dalam 6 candle ada close tembus (harusnya breakout)
    c = np.array([80519.8, 80541.5, 80591.8, 80827.5, 80860.2, 80832.4, 80872.7])
    assert T._holds(c, 0, 80620.1, -1, 6) is False
    assert T._holds(np.array([80519.8, 80500, 80450, 80400, 80380, 80300, 80250]), 0, 80620.1, -1, 6) is True


def test_hold_in_hours_same_for_all_tf():
    assert T._params({"tf": "5m", "hold_h": 1})["hold"] == 12
    assert T._params({"tf": "15m", "hold_h": 1})["hold"] == 4
    assert T._params({"tf": "1h", "snr_tf": "4h", "hold_h": 1})["hold"] == 1
    assert T._params({"tf": "5m"})["hold"] == 12                           # default 1 jam
    assert T._params({"tf": "5m", "hold": 6})["hold"] == 6                  # cara lama (candle) masih bisa


def test_hold_setting_changes_outcomes(store):
    r1 = T.run(store, ["AAAUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 5, "auto_smooth": False, "hold_h": 0.25, "workers": 1})
    r6 = T.run(store, ["AAAUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 5, "auto_smooth": False, "hold_h": 3, "workers": 1})
    b1 = sum(x["breakout"] for x in r1["table"]["1"])
    b6 = sum(x["breakout"] for x in r6["table"]["1"])
    assert b6 <= b1                                         # syarat bertahan lebih lama -> breakout valid lebih sedikit
    assert sum(x["fakeout"] for x in r6["table"]["1"]) >= sum(x["fakeout"] for x in r1["table"]["1"])


def test_adx_and_adxfi_modes(store):
    """ADX & ADX + Force Index dites dengan mesin Tes SNR yang sama (dibaca juga 1.5 ATR sebelum SNR)."""
    from backend.indicators import dmi
    r = T.run(store, ["AAAUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 5, "ind": "adx", "auto_smooth": False, "adx_len": 14, "workers": 1})
    assert r["n_events"] > 0 and r["smooth"] == 14 and r["summary"] is None or r["summary"]["band"] == "1.5"
    assert r["saved_default"] is None                                  # ADX tidak mengubah default Dorongan %
    auto = T.run(store, ["AAAUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 5, "ind": "adx", "workers": 1})
    assert [c["smooth"] for c in auto["compare"]] == T.ADX_LENS
    # nilai yang dibaca = ADX persis (dibulatkan 1 desimal)
    q = T._params({"tf": "15m", "snr_tf": "1h", "ind": "adx", "adx_len": 14})
    raw = T.study_coin(store, "AAAUSDT", q, [14])
    b = store.get("AAAUSDT", "15m")
    adx = np.round(dmi(np.asarray(b.h), np.asarray(b.l), np.asarray(b.c), 14)[2], 1)
    assert np.allclose(raw["pv"][:, 0], adx[raw["k"]], equal_nan=True)
    fi = T.run(store, ["AAAUSDT"], {"tf": "15m", "snr_tf": "1h", "min_n": 5, "ind": "adxfi", "auto_smooth": False, "workers": 1})
    sp = fi["split"]
    assert fi["fi_split"] and set(sp) == {"menuju", "melawan"}
    assert sp["menuju"]["n_events"] + sp["melawan"]["n_events"] == fi["n_events"]
    assert T._params({"ind": "adxfi", "toward": True})["toward"] is False   # dua arah FI selalu dihitung
