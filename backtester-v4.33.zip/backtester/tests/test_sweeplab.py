"""💧 Liquidity Sweep backtest: definisi sweep (ekor tembus, close balik), tanpa intip masa depan, cermin beli/jual,
rumus hasil seperti Whale, penyaring & kombinasi, endpoint."""
import contextlib
import io
import os
import sys
import time

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend import sweeplab as SW  # noqa: E402
from backend.data import DataStore  # noqa: E402
from backend.indicators import atr  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("swp")
    with contextlib.redirect_stdout(io.StringIO()):
        for i, s_ in enumerate(("BTCUSDT", "AAAUSDT", "BBBUSDT")):
            make(str(d), symbol=s_, days=200, seed=i + 1)
    return DataStore(str(d))


def _arr(store, sym="BTCUSDT", tf="15m"):
    b = store.get(sym, tf)
    return np.asarray(b.t, np.int64), *(np.asarray(z, float) for z in (b.o, b.h, b.l, b.c, b.v))


def test_sweep_definition_and_no_lookahead(store):
    t, o, h, l, c, v = _arr(store)
    a = atr(h, l, c, 14)
    E = SW.events_long(t, o, h, l, c, v, a)
    assert len(E) > 50
    for e in E:
        s = e["s"]
        assert l[s] < e["L"] and c[s] > e["L"] and e["types"]           # ekor tembus, close balik ke dalam
    N = len(c) - 500
    cut = {e["s"]: e for e in SW.events_long(t[:N], o[:N], h[:N], l[:N], c[:N], v[:N], a[:N])}
    full = {e["s"]: e for e in E if e["s"] < N}
    assert cut.keys() == full.keys()                                     # data masa depan tidak mengubah sweep lama
    for s in cut:
        assert cut[s]["L"] == full[s]["L"] and cut[s]["types"] == full[s]["types"]


def test_rows_whale_formula(store):
    t, o, h, l, c, v = _arr(store)
    R = SW.coin_rows("BTCUSDT", t, o, h, l, c, v, "15m")
    assert R and {r["d"] for r in R} == {1, -1}
    for r in R[:3000]:
        if r["d"] == 1:
            assert r["sl"] < r["e"] < r["tp"]
        else:
            assert r["tp"] < r["e"] < r["sl"]
        if r["filled"]:
            assert r["R"] == (pytest.approx(r["rr"]) if r["res"] == "TP" else -1.0)     # belum kena TP = tidak menang
        assert r["rr"] >= 2 - 1e-9                                                         # RR minimal 1:2
        if r["slm"] == "anti":
            assert abs(r["e"] - r["sl"]) / abs(r["e"]) <= 0.04 + 1e-9                     # batas SL Whale 4%
        if r["filled"] and r["res"] in ("TP", "SL"):
            assert r["rsi_e"] is None or 0 <= r["rsi_e"] <= 100
    assert {r["slm"] for r in R} == set(SW.SLS) and all(r["cara"].endswith("|" + r["slm"]) for r in R[:500])
    a = atr(h, l, c, 14)
    for r in R[:3000]:                                                                    # SL ATR = entry -+ k x ATR saat konfirmasi
        if r["slm"] != "anti":
            k = float(r["slm"][3:])
            j = int(np.searchsorted(t, r["t"])) + r["jo"]
            assert abs(r["e"] - r["sl"]) == pytest.approx(k * a[j], rel=1e-6)


def test_fast_trade_same_as_chartpat(store):
    from backend import chartpat as CP
    t, o, h, l, c, v = _arr(store)
    rng = np.random.default_rng(0)
    for _ in range(2000):
        f = int(rng.integers(0, len(c) - 60)); mk = bool(rng.integers(0, 2))
        e = c[f]; sl = e - rng.uniform(0.05, 3) * (h[f] - l[f] + 1e-9); tp = e + rng.uniform(0.5, 5) * (e - sl)
        assert SW._fast_trade(SW._seg(h, l, f, 50, mk, {}), f, sl, tp) == CP._trade(h, l, 1, f, e, sl, tp, 50, mk)


def test_regime_info(store):
    t, o, h, l, c, v = _arr(store, tf="1h")
    ad, rs, trend, bias, dur = SW._regime(h, l, c, "1h")
    assert ((trend == (np.nan_to_num(ad) >= 20)) | np.isnan(ad)).all() and set(np.unique(bias)) <= {1, -1}
    for i in range(1, len(c)):                                                            # lama kondisi = jam berturut-turut status sama
        assert dur[i] == (dur[i - 1] + 1 if trend[i] == trend[i - 1] else 1)


def test_analyse(store):
    syms = SW.history_symbols(store, "15m", 3)
    R = SW.run(store, "15m", syms)
    assert R["best"] and R["n_events"] > 0 and R["filters"]
    assert [x["sl"] for x in R["sl_table"]] == list(SW.SLS) and sum(x["is_best"] for x in R["sl_table"]) == 1
    assert {f["gk"] for f in R["filters"]} >= {"reg", "dur"}
    for x in R["examples"]:
        assert x["reg"].split()[0] in ("trend", "sideway") and x["dur_h"] > 0 and x["slm"] == R["best"]["sl"]
    b = R["best"]
    assert b["ok"] == (b["all"]["n"] >= SW.MIN_N and (b["all"]["exp"] or 0) > 0)
    for f in R["filters"]:
        if f["helps"]:
            assert f["fit"]["n"] >= SW.MIN_N and f["up_fit"] >= 0.05 and f["up_test"] > 0
    steps = R["combo"]["steps"]
    for prev, cur in zip([R["base"]] + steps, steps):                    # tiap langkah menaikkan hasil di data cari
        assert cur["fit"]["exp"] >= prev["fit"]["exp"] + 0.05 - 1e-9 and cur["fit"]["n"] >= SW.MIN_N
    assert SW.run(store, "15m", syms) is R                               # cache


def test_api(store, monkeypatch, tmp_path):
    monkeypatch.setenv("DATA_DIR", store.data_dir)
    import importlib

    import backend.app as app_mod
    importlib.reload(app_mod)
    app_mod.store = store
    from backend import results_store
    monkeypatch.setattr(results_store, "BASE", str(tmp_path))
    from fastapi.testclient import TestClient
    client = TestClient(app_mod.app)
    assert client.post("/api/sweep/run", json={"tf": "7m"}).status_code == 400
    r = client.post("/api/sweep/run", json={"tf": "1h", "hist": 3})
    for _ in range(600):
        st = client.get(f"/api/screener/job/{r.json()['id']}").json()
        if st["status"] != "running":
            break
        time.sleep(0.1)
    assert st["status"] == "done", st
    assert st["result"]["tf"] == "1h" and len(st["result"]["coins"]) == 3


def test_parallel_same_as_serial_and_candles(store, tmp_path, monkeypatch):
    """Hitung paralel (beberapa proses) = hitung satu per satu; agregat hemat memori; candle contoh untuk gambar visual."""
    from backend import results_store
    monkeypatch.setattr(results_store, "BASE", str(tmp_path))
    syms = SW.history_symbols(store, "1h", 3)
    SW._CACHE.clear()
    pushes = []
    a = SW.run(store, "1h", syms, workers=2, push=lambda p: pushes.append(p["phase"]))
    SW._CACHE.clear()
    os.remove(SW._disk("1h"))
    b = SW.run(store, "1h", syms, workers=1)
    assert a["best"]["key"] == b["best"]["key"] and a["best"]["all"] == b["best"]["all"] and a["n_events"] == b["n_events"]
    assert pushes[-1] == "analisa" and "riwayat" in pushes                   # progres: fase riwayat lalu analisa
    assert "sweeplab_cache" in SW._disk("1h")                                # cache tidak tercampur 📂 hasil tersimpan
    x = a["examples"][-1]
    c, i = SW.candles_around(store, x["sym"], "1h", x["t"])
    assert c[i][0] == x["t"] and len(c) > i
