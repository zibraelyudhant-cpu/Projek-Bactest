"""Bukti tambahan: Elliott Wave (aturan baku), tanpa intip masa depan, BTC sesuai korelasi, sapuan likuiditas, kelas A/B/C."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from backend import evidence as EV  # noqa: E402


def _path(points, per=20, noise=0.0, seed=1):
    """Harga linier antar titik (tiap leg `per` candle) -> t, o, h, l, c."""
    rng = np.random.default_rng(seed)
    c = []
    for a, b in zip(points[:-1], points[1:]):
        c.extend(np.linspace(a, b, per, endpoint=False))
    c.append(points[-1])
    c = np.array(c) + rng.normal(0, noise, len(c))
    o = np.r_[c[0], c[:-1]]
    h = np.maximum(o, c) + 0.2
    l = np.minimum(o, c) - 0.2
    t = np.arange(len(c), dtype=np.int64) * 900_000 + 1_700_000_000_000
    return t, o, h, l, c


def test_impulse_rules():
    assert EV._impulse_ok([100, 120, 110, 150, 135, 160], 1)
    assert not EV._impulse_ok([100, 120, 95, 150], 1)          # gel.2 melewati awal gel.1
    assert not EV._impulse_ok([100, 120, 110, 150, 118], 1)    # gel.4 masuk wilayah gel.1
    assert not EV._impulse_ok([100, 130, 120, 135, 128, 170], 1)  # gel.3 terpendek
    assert EV._impulse_ok([200, 180, 190, 150, 165, 140], -1)  # impuls turun (dicerminkan)


def test_ew_states_bull_impulse():
    P = [(100, -1), (120, 1), (110, -1)]
    lab, v, tgt = EV.ew_state(P, 125)                        # gel. 3 naik berjalan
    assert v == 1 and "gel. 3" in lab and tgt > 125
    P = [(100, -1), (120, 1), (110, -1), (150, 1)]
    lab, v, _ = EV.ew_state(P, 138)                          # gel. 4 koreksi 30% -> tunggu gel. 5 naik
    assert v == 1 and "gel. 4" in lab
    P = [(100, -1), (120, 1), (110, -1), (150, 1), (135, -1)]
    lab, v, _ = EV.ew_state(P, 155)
    assert v == 1 and "gel. 5" in lab
    P = [(100, -1), (120, 1), (110, -1), (150, 1), (135, -1), (165, 1)]
    lab, v, _ = EV.ew_state(P, 150)                          # impuls selesai -> koreksi ABC turun
    assert v == -1 and "ABC" in lab


def test_ew_abc():
    P = [(200, 1), (170, -1), (185, 1)]                      # A turun, B naik (50%), leg berjalan turun = gel. C
    lab, v, _ = EV.ew_state(P, 172)
    assert v == -1 and ("gel. C" in lab or "gel. 3" in lab)


def test_series_no_lookahead():
    t, o, h, l, c = _path([100, 120, 110, 150, 135, 165, 140, 155, 120], per=25, noise=0.3)
    a = EV._atr(h, l, c, 14)
    full = EV.ew_series(h, l, c, a)
    for cut in (60, 110, 160, 199):
        part = EV.ew_series(h[:cut], l[:cut], c[:cut], a[:cut])
        assert part["vote"][cut - 1] == full["vote"][cut - 1]
        assert part["label"][cut - 1] == full["label"][cut - 1]
    assert set(np.unique(full["vote"])) <= {-1, 0, 1}
    V = EV.coin_votes(t, o, h, l, c, "15m")
    V2 = EV.coin_votes(t[:150], o[:150], h[:150], l[:150], c[:150], "15m")
    for k in EV.KEYS:
        assert V[k][149] == V2[k][149], k


def test_btc_only_when_correlated():
    n = 400
    rng = np.random.default_rng(3)
    bt = np.arange(n, dtype=np.int64) * 900_000
    bc = 100 * np.exp(np.cumsum(rng.normal(0, 0.01, n)))
    a = np.full(n, 0.5)
    same = bc * 0.5                                           # bergerak persis bersama BTC
    vb, _, corr = EV.btc_votes(bt, same, a, bt, bc)
    assert np.nanmin(corr[EV.CORR_WIN + 5:]) > 0.99 and (vb[200:] != 0).all()
    own = 50 * np.exp(np.cumsum(rng.normal(0, 0.01, n)))      # jalan sendiri
    vb2, _, corr2 = EV.btc_votes(bt, own, a, bt, bc)
    assert np.nanmean(np.abs(corr2[EV.CORR_WIN + 5:])) < 0.3
    assert (vb2 != 0).mean() < 0.2                            # arah BTC hampir selalu diabaikan


def test_sweep():
    c = np.array([10, 9, 8, 9, 10, 11, 10.5, 10.2, 10.4, 10.6], float)
    h, l = c + 0.1, c - 0.1
    l[6] = 7.5                                                # ekor menembus swing low 8 (indeks 2), close balik di atas
    v = EV.sweep_votes(h, l, c, n=2)
    assert v[6] == 1 and v[7] == 1 and v[9] == 0


def test_learn_grades():
    rng = np.random.default_rng(5)
    S = []
    for i in range(3000):
        d = 1 if i % 2 else -1
        ew = int(rng.choice([-1, 0, 1]))
        p = 0.6 if ew * d > 0 else 0.35 if ew * d < 0 else 0.45   # Elliott searah = lebih sering menang
        S.append({"dir": d, "win": bool(rng.random() < p), "test": i >= 2100, "sess": None,
                  "v": {"ew": ew, "ew_htf": 0, "d1": int(rng.choice([-1, 1])), "btc": 0, "rs": 0, "sweep": 0}})
    M = EV.learn(S)
    assert M["w"]["ew"] > 0.1 and M["w"]["d1"] == 0          # D1 acak -> bobot 0
    g = M["grades"]
    assert g["A"]["wr"] > g["C"]["wr"] + 10 and M["proven"]
    assert EV.grade_of(M, EV.score(M, {"ew": 1}, 1)) == "A"
    assert EV.grade_of(M, EV.score(M, {"ew": -1}, 1)) == "C"
    # bukti acak semua -> tidak ada kelas (jujur)
    R = [{**s, "win": bool(rng.random() < 0.5), "v": {k: int(rng.choice([-1, 1])) for k in EV.KEYS}} for s in S]
    M2 = EV.learn(R)
    assert M2.get("cut") is None or not M2.get("proven")


def test_target_passed_not_shown():
    P = [(122.4, 1), (118.0, -1), (121.6, 1), (99.4, -1), (105.3, 1)]
    lab, v, tgt = EV.ew_state(P, 79.5)                      # gel. 5 turun sudah jauh melewati target gel.5 = gel.1
    assert v == -1 and tgt is None and "terlewati" in lab
    lab, v, tgt = EV.ew_state(P, 103.0)                      # bisa gel.2 naik ATAU gel.5 turun -> jujur: belum jelas
    assert v == 0 and "belum jelas" in lab
    lab, v, tgt = EV._ew_one(P, 103.0, -1)
    assert v == -1 and tgt < 103.0
