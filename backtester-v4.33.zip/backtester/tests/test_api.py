"""Tes API + WebSocket replay lewat TestClient (tanpa menjalankan server)."""
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    from tools.make_sample_data import make
    d = tmp_path_factory.mktemp("data")
    make(str(d), days=30)
    os.environ["DATA_DIR"] = str(d)
    import importlib

    import backend.app as app_mod
    importlib.reload(app_mod)
    from fastapi.testclient import TestClient
    return TestClient(app_mod.app)


def test_rest(client):
    assert client.get("/api/symbols").json()["symbols"] == ["SAMPLEUSDT"]
    info = client.get("/api/symbols/SAMPLEUSDT").json()
    assert info["base_tf"] == "5m" and "4h" in info["timeframes"]
    assert any(s["name"] == "EmaCross" for s in client.get("/api/strategies").json())
    r = client.post("/api/backtest", json={"symbol": "SAMPLEUSDT", "strategy": "EmaCross"})
    assert r.status_code == 200 and "metrics" in r.json()


def test_ws_replay(client):
    info = client.get("/api/symbols/SAMPLEUSDT").json()
    start = info["start"] + 10 * 86_400_000
    with client.websocket_connect("/ws/replay") as ws:
        ws.send_json({"cmd": "start", "symbol": "SAMPLEUSDT", "start": start, "tf": "1h", "req_id": 1})
        m = ws.receive_json()
        assert m["type"] == "init" and m["state"]["now"] == start
        assert m["bars"][-1]["time"] * 1000 + 3_600_000 <= start  # tidak ada bar masa depan
        ws.send_json({"cmd": "order", "side": "buy", "type": "market", "qty": 1, "req_id": 2})
        assert ws.receive_json()["state"]["orders"]
        ws.send_json({"cmd": "step_base", "n": 1, "req_id": 3})
        m = ws.receive_json()
        assert m["state"]["position"] == 1 and m["events"][0]["type"] == "fill"
        assert m["forming"]["time"] * 1000 == start  # candle 1h forming dari 1 bar M5
        ws.send_json({"cmd": "step", "n": 1, "req_id": 4})
        m = ws.receive_json()
        assert m["state"]["now"] == start + 3_600_000 and len(m["bars"]) == 1 and m["forming"] is None
        ws.send_json({"cmd": "set_tf", "tf": "4h", "req_id": 5})
        m = ws.receive_json()
        assert m["type"] == "init" and m["forming"] is not None
        ws.send_json({"cmd": "history", "tf": "5m", "before": start - 86_400_000, "n": 100, "req_id": 51})
        h = ws.receive_json()
        assert h["type"] == "history" and len(h["bars"]) == 100
        assert h["bars"][-1]["time"] * 1000 == start - 86_400_000 - 300_000
        ws.send_json({"cmd": "history", "tf": "1h", "before": start + 10 * 86_400_000, "n": 5, "req_id": 52})
        h = ws.receive_json()  # minta 'before' di masa depan: tetap dibatasi ke bar yang sudah close
        assert all(b["time"] * 1000 + 3_600_000 <= start + 3_600_000 for b in h["bars"])
        ws.send_json({"cmd": "close", "req_id": 6})
        ws.receive_json()
        ws.send_json({"cmd": "step_base", "n": 1, "req_id": 7})
        m = ws.receive_json()
        assert m["state"]["position"] == 0 and len(m["trades"]) == 1
        ws.send_json({"cmd": "order", "side": "buy", "type": "limit", "qty": 1, "req_id": 8})
        assert ws.receive_json()["type"] == "error"


def test_ws_step_back(client):
    info = client.get("/api/symbols/SAMPLEUSDT").json()
    start = info["start"] + 10 * 86_400_000
    H = 3_600_000
    with client.websocket_connect("/ws/replay") as ws:
        def cmd(**m):
            ws.send_json(m)
            return ws.receive_json()

        cmd(cmd="start", symbol="SAMPLEUSDT", start=start, tf="1h")
        cmd(cmd="step", n=2)                                       # now = start+2h
        cmd(cmd="order", side="buy", type="market", qty=1, tp=999, sl=1)
        full = cmd(cmd="step", n=5)                                # now = start+7h, posisi long
        assert full["state"]["position"] == 1

        back = cmd(cmd="step_back", n=3)                           # mundur ke start+4h: posisi tetap ada
        assert back["type"] == "init" and back["state"]["now"] == start + 4 * H
        assert back["state"]["position"] == 1 and len(back["fills"]) == 1
        assert all(b["time"] * 1000 + H <= start + 4 * H for b in back["bars"])
        again = cmd(cmd="step", n=3)                               # maju lagi: hasil identik
        assert again["state"] == full["state"]

        back = cmd(cmd="step_back", n=6)                           # ke start+1h: order (dibuat jam +2) batal
        assert back["state"]["now"] == start + H and back["state"]["position"] == 0
        assert not back["state"]["orders"] and not back["fills"]

        back = cmd(cmd="step_back", base=True, n=1)                # mundur 1 bar M5, melewati tanggal mulai
        assert back["state"]["now"] == start + H - 300_000
        back = cmd(cmd="step_back", n=5)
        assert back["state"]["now"] == start - 4 * H               # boleh ke sebelum tanggal mulai


def test_thresholds(client, tmp_path, monkeypatch):
    import backend.app as app_mod
    monkeypatch.setattr(app_mod, "SAVED_FILE", str(tmp_path / "s" / "t.json"))
    assert client.get("/api/thresholds").json() == []
    assert client.post("/api/thresholds", json={"name": "x"}).status_code == 400
    a = client.post("/api/thresholds", json={"name": " Bagus ", "strategy": "EmaCross", "params": {"fast": 10},
                                              "metrics": {"win_rate": 55.5, "profit_factor": None}}).json()
    b = client.post("/api/thresholds", json={"strategy": "EmaCross", "params": {"fast": 12}}).json()
    items = client.get("/api/thresholds").json()
    assert [i["id"] for i in items] == [a["id"], b["id"]] and items[0]["name"] == "Bagus" and items[1]["name"] == "EmaCross"
    assert items[0]["metrics"]["win_rate"] == 55.5
    assert client.patch(f"/api/thresholds/{b['id']}", json={"name": "B2"}).json()["name"] == "B2"
    client.delete(f"/api/thresholds/{a['id']}")
    assert [i["name"] for i in client.get("/api/thresholds").json()] == ["B2"]


def test_fibsaved(client, tmp_path, monkeypatch):
    import backend.app as app_mod
    monkeypatch.setattr(app_mod, "SAVED_FILE", str(tmp_path / "s" / "t.json"))
    assert client.get("/api/fibsaved").json() == []
    assert client.post("/api/fibsaved", json={"name": "x", "result": {}}).status_code == 400
    res = {"n": 10, "params": {"tf": "15m", "regime_tf": "4h"}, "groups": [{"key": "all", "n": 10}]}
    a = client.post("/api/fibsaved", json={"name": " M15 bagus ", "result": res, "symbols": None, "coins": 3}).json()
    assert a["name"] == "M15 bagus" and "result" not in a
    lst = client.get("/api/fibsaved").json()
    assert [x["id"] for x in lst] == [a["id"]] and lst[0]["n"] == 10 and lst[0]["coins"] == 3
    full = client.get(f"/api/fibsaved/{a['id']}").json()
    assert full["result"]["groups"][0]["n"] == 10
    client.patch(f"/api/fibsaved/{a['id']}", json={"name": "baru"})
    assert client.get("/api/fibsaved").json()[0]["name"] == "baru"
    assert client.get("/api/fibsaved/../x").status_code in (400, 404)
    client.delete(f"/api/fibsaved/{a['id']}")
    assert client.get("/api/fibsaved").json() == []


def test_fib_v2_endpoints(client, tmp_path, monkeypatch):
    """Studi Fibonacci v2: default TF M5 / H1, simpanan terpisah dari v1, dan ikut aturan satu proses berat."""
    import backend.app as app_mod
    monkeypatch.setattr(app_mod, "SAVED_FILE", str(tmp_path / "s" / "t.json"))
    d = client.get("/api/fibstudy2/defaults").json()
    assert (d["tf"], d["regime_tf"], d["trend_tf"]) == ("5m", "1h", "1h")
    assert client.get("/api/fibstudy/defaults").json()["tf"] == "15m"
    res = {"n": 5, "params": d, "groups": [{"key": "all", "n": 5}]}
    a = client.post("/api/fibsaved2", json={"name": "v2", "result": res}).json()
    assert [x["id"] for x in client.get("/api/fibsaved2").json()] == [a["id"]]
    assert client.get("/api/fibsaved").json() == []
    client.delete(f"/api/fibsaved2/{a['id']}")
    assert client.get("/api/fibsaved2").json() == []
    fake = {"id": "abc", "done": 1, "total": 4, "params": {}, "status": "running"}
    monkeypatch.setattr(app_mod.fibjobs2, "running", lambda: fake)
    assert client.get("/api/running").json()["busy"]["kind"] == "fib2"
    assert client.post("/api/fibstudy", json={}).status_code == 409


def test_one_heavy_job_at_a_time(client, monkeypatch):
    import backend.app as app_mod
    fake = {"id": "abc", "done": 3, "total": 10, "params": {}, "status": "running"}
    monkeypatch.setattr(app_mod.fibjobs, "running", lambda: fake)
    r = client.post("/api/backtest_all", json={"strategy": "EmaCross"})
    assert r.status_code == 409 and r.json()["detail"]["busy"]["kind"] == "fib"
    assert client.post("/api/fibstudy", json={}).status_code == 409
    assert client.get("/api/running").json()["busy"]["id"] == "abc"


def test_sysinfo_and_blas_threads():
    import os
    import backend  # noqa: F401
    from backend.sysinfo import info, recommended_workers
    assert os.environ["OPENBLAS_NUM_THREADS"] == "1"
    i = info()
    assert 1 <= i["recommended"] == recommended_workers() <= 8 and i["cpus"] >= 1


def test_threshold_detail(client, tmp_path, monkeypatch):
    import backend.app as app_mod
    monkeypatch.setattr(app_mod, "SAVED_FILE", str(tmp_path / "s" / "t.json"))
    a = client.post("/api/thresholds", json={"strategy": "EmaCross", "params": {"fast": 10},
                                              "detail": {"kind": "one", "trades": [{"side": "long"}]}}).json()
    b = client.post("/api/thresholds", json={"strategy": "EmaCross", "params": {}}).json()
    assert a["has_detail"] and "has_detail" not in b
    assert client.get(f"/api/thresholds/{a['id']}/detail").json()["trades"][0]["side"] == "long"
    assert client.get(f"/api/thresholds/{b['id']}/detail").status_code == 404
    client.delete(f"/api/thresholds/{a['id']}")
    assert client.get(f"/api/thresholds/{a['id']}/detail").status_code == 404


def test_indtester_api(client):
    import time as _t
    d = client.get("/api/indtester/defaults").json()
    assert "EMA" in d["ma_types"] and d["defaults"]["tester"] == "ema"
    bad = client.post("/api/indtester", json={"params": {"tester": "combo", "components": ["rsi"]}})
    assert bad.status_code == 400                                           # kombinasi butuh >= 2 indikator
    big = client.post("/api/indtester", json={"params": {"tester": "ema", "ema_main": "100-159:1", "ema_second": "5-64:1"}})
    assert big.status_code == 400 and "terlalu banyak" in big.json()["detail"]
    rev = client.post("/api/indtester", json={"params": {"tester": "ema", "ema_mode": "test", "ema_main": "21", "ema_second": "75"}})
    assert rev.status_code == 400 and "minimal 30 lebih besar" in rev.json()["detail"]   # pasangan terbalik / terlalu dekat ditolak
    assert client.get("/api/patterns/defaults").status_code == 404          # Pola Indikator sudah dihapus
    r = client.post("/api/indtester", json={"params": {"tester": "rsi", "tf": "15m", "min_trades": 1}})
    assert r.status_code == 200 and r.json()["kind"] == "indtester"
    for _ in range(600):
        st = client.get(f"/api/study/indtester/{r.json()['id']}").json()
        if st["status"] != "running":
            break
        _t.sleep(0.1)
    assert st["status"] == "done", st
    assert st["result"]["n_combos"] == 16


def test_stratlab_api(client):
    import time as _t
    d = client.get("/api/stratlab/defaults").json()
    assert d["defaults"]["tf"] == "15m" and "fib0.618" in d["entries"]
    assert client.post("/api/stratlab", json={"params": {"tf": "7m"}}).status_code == 400
    r = client.post("/api/stratlab", json={"params": {"tf": "15m", "rrs": "2, 3"}})
    assert r.status_code == 200
    for _ in range(900):
        st = client.get(f"/api/study/stratlab/{r.json()['id']}").json()
        if st["status"] != "running":
            break
        _t.sleep(0.1)
    assert st["status"] == "done", st
    res = st["result"]
    assert res["v"] == 5 and "rows" in res
    if res["rows"]:
        x = res["rows"][0]
        pat = {k: x[k] for k in ("len", "key", "dir", "entry", "sl", "rr")}
        t = client.post("/api/stratlab/trades", json={"symbol": res["symbols"][0], "params": res["params"], "pattern": pat})
        assert t.status_code == 200 and t.json()["n"] >= 1 and t.json()["trades"][0]["swings"]


def test_study_pause_resume_and_saved(client):
    import time as _t
    from backend import app as A
    ref = A._SNR.run(A.store, A.store.symbols(), {"tf": "15m", "snr_tf": "1h", "min_n": 5, "auto_smooth": False, "smooth": 10,
                                                  "workers": 1})
    r = client.post("/api/snrtest", json={"params": {"tf": "15m", "snr_tf": "1h", "min_n": 5, "auto_smooth": False, "smooth": 10}})
    assert r.status_code == 200
    jid = r.json()["id"]
    assert client.post(f"/api/job/snrtest/{jid}/pause").status_code == 200
    for _ in range(600):                                   # tunggu jeda selesai (koin yang sedang dihitung diselesaikan)
        st = client.get(f"/api/study/snrtest/{jid}").json()
        if st["status"] in ("paused", "done") and not st["inflight"]:
            break
        _t.sleep(0.1)
    if st["status"] == "paused":
        assert any(x["id"] == jid for x in client.get("/api/paused").json())
        assert client.post(f"/api/job/snrtest/{jid}/resume").status_code == 200
    for _ in range(900):
        st = client.get(f"/api/study/snrtest/{jid}").json()
        if st["status"] == "done":
            break
        _t.sleep(0.1)
    assert st["status"] == "done", st
    res = st["result"]
    assert res["table"] == A._clean(ref["table"]) and res["n_events"] == ref["n_events"]   # dijeda + paralel = hasil sama
    saved = client.get("/api/results/snrtest").json()
    assert saved and saved[0]["id"] == res["saved_id"]
    full = client.get(f"/api/results/snrtest/{res['saved_id']}").json()
    assert full["result"]["n_events"] == res["n_events"]
    assert client.patch(f"/api/results/snrtest/{res['saved_id']}", json={"label": "tes"}).status_code == 200
    assert client.get("/api/results/snrtest").json()[0]["label"] == "tes"
    assert client.delete(f"/api/results/snrtest/{res['saved_id']}").status_code == 200
    assert client.get("/api/results/snrtest").json() == []


def test_msa_screen_api(client, monkeypatch):
    """🔎 Screener Market Structure: Binance tidak bisa diakses -> struktur dari data lokal + catatan."""
    import time as _t
    import backend.app as app_mod

    def boom(*a, **k):
        raise ConnectionError("offline")
    monkeypatch.setattr(app_mod.whales.c, "get", boom)
    assert client.post("/api/msa/screen", json={"symbol": "", "tf": "1h"}).status_code == 400
    assert client.post("/api/msa/screen", json={"symbol": "BTC", "tf": "7m"}).status_code == 400
    assert client.post("/api/msa/screen", json={"symbol": "SAMPLEUSDT", "tf": "1h", "htf": "9h"}).status_code == 400
    assert client.post("/api/msa/screen", json={"symbol": "SAMPLEUSDT", "tf": "1h", "scope": "0"}).status_code == 400
    assert client.post("/api/msa/screen", json={"symbol": "SAMPLEUSDT", "tf": "1h", "scope": "xxx, yyy"}).status_code == 400
    assert client.post("/api/msa/screen", json={"symbol": "NOPEUSDT", "tf": "1h", "scope": "coin"}).status_code == 400
    j = client.post("/api/msa/screen", json={"symbol": "sample", "tf": "1h", "swing": "kecil"}).json()
    for _ in range(200):
        st = client.get(f"/api/screener/job/{j['id']}").json()
        if st["status"] != "running":
            break
        _t.sleep(0.05)
    assert st["status"] == "done", st
    r = st["result"]
    assert r["symbol"] == "SAMPLEUSDT" and r["source"] == "lokal" and "offline" not in (r["note"] or "x") and r["note"]
    j = client.post("/api/msa/screen", json={"symbol": "NOPEUSDT", "tf": "1h"}).json()
    for _ in range(200):
        st = client.get(f"/api/screener/job/{j['id']}").json()
        if st["status"] != "running":
            break
        _t.sleep(0.05)
    assert st["status"] == "error"


def test_msa_check_api(client, monkeypatch):
    """🧪 Cek entry posisi lewat API (Binance offline -> data lokal)."""
    import time as _t
    import backend.app as app_mod

    def boom(*a, **k):
        raise ConnectionError("offline")
    monkeypatch.setattr(app_mod.whales.c, "get", boom)
    assert client.post("/api/msa/check", json={"symbol": "SAMPLEUSDT", "tf": "1h", "entry": 10, "sl": 11, "tp": 12}).status_code == 400
    assert client.post("/api/msa/check", json={"symbol": "SAMPLEUSDT", "tf": "1h", "entry": "x", "sl": 1, "tp": 2}).status_code == 400
    assert client.post("/api/msa/check", json={"symbol": "NOPEUSDT", "tf": "1h", "entry": 10, "sl": 9, "tp": 12, "scope": "coin"}).status_code == 400
    px = client.get("/api/symbols/SAMPLEUSDT").json()
    j = client.post("/api/msa/screen", json={"symbol": "SAMPLEUSDT", "tf": "1h"}).json()
    for _ in range(200):
        st = client.get(f"/api/screener/job/{j['id']}").json()
        if st["status"] != "running":
            break
        _t.sleep(0.05)
    now = st["result"]["now_price"]
    j = client.post("/api/msa/check", json={"symbol": "SAMPLEUSDT", "tf": "1h", "entry": now * 0.995, "sl": now * 0.98, "tp": now * 1.03}).json()
    for _ in range(200):
        st = client.get(f"/api/screener/job/{j['id']}").json()
        if st["status"] != "running":
            break
        _t.sleep(0.05)
    assert st["status"] == "done", st
    r = st["result"]
    assert r["dir"] == 0 and not r["filled"] and r["note"] and "stats" in r and px


def test_whales_flow_validation(client):
    assert client.post("/api/whales/flow", json={"symbol": ""}).status_code == 400
    assert client.post("/api/whales/flow", json={"symbol": "BTC", "tf": "2h"}).status_code == 400
    assert client.post("/api/whales/flow", json={"symbol": "BTC", "coins": "x"}).status_code == 400


def test_msa_scan_api(client, monkeypatch):
    """🔎 Scan banyak koin: Binance offline -> koin & struktur dari data lokal; ringkasan per koin."""
    import time as _t
    import backend.app as app_mod

    def boom(*a, **k):
        raise ConnectionError("offline")
    monkeypatch.setattr(app_mod.whales.c, "get", boom)
    assert client.post("/api/msa/scan", json={"tf": "7m"}).status_code == 400
    assert client.post("/api/msa/scan", json={"tf": "1h", "htf": "9h"}).status_code == 400
    j = client.post("/api/msa/scan", json={"tf": "1h", "coins": 5}).json()
    for _ in range(300):
        st = client.get(f"/api/screener/job/{j['id']}").json()
        if st["status"] != "running":
            break
        _t.sleep(0.05)
    assert st["status"] == "done", st
    r = st["result"]
    assert r["note"] and r["n"] >= 1 and r["rows"][0]["symbol"] == "SAMPLEUSDT"
    assert r["n_usable"] == sum(1 for x in r["rows"] if x["usable"]) and set(r["full"]) <= {x["symbol"] for x in r["rows"] if x["usable"]}
    for x in r["rows"]:
        assert x["usable"] or x["why_not"]


def test_rules_api(client, tmp_path, monkeypatch):
    """🧱 Penyusun aturan lewat API (folder strategi sementara supaya folder asli tidak tersentuh)."""
    import backend.app as app_mod
    monkeypatch.setattr(app_mod, "STRATEGY_DIR", str(tmp_path))
    cat = client.get("/api/rules/catalog").json()
    assert "rsi" in cat["indicators"] and "cross_up" in cat["ops"]
    spec = {"name": "Tes API", "tf": "1h", "long": [{"a": {"ind": "rsi"}, "op": "<", "b": {"num": 30}}]}
    pv = client.post("/api/rules/preview", json={"spec": spec}).json()
    assert pv["class"] == "RB_TesAPI" and pv["describe"]["short"] == ["RSI(14) lebih besar dari 70"]
    assert client.post("/api/rules/preview", json={"spec": {**spec, "long": []}}).status_code == 400
    sv = client.post("/api/rules/save", json={"spec": spec}).json()
    assert (tmp_path / (sv["slug"] + ".py")).exists()
    assert [x["slug"] for x in client.get("/api/rules").json()["saved"]] == [sv["slug"]]
    assert client.post("/api/rules/delete", json={"slug": sv["slug"]}).json()["deleted"] == 2
    assert client.post("/api/rules/delete", json={"slug": "../x"}).status_code == 400


def test_ws_candle_struct(client):
    """Struktur candle: isi candle D1/H4 di TF kecil, tanpa data masa depan."""
    info = client.get("/api/symbols/SAMPLEUSDT").json()
    D, H = 86_400_000, 3_600_000
    start = (info["start"] // D + 10) * D + 5 * H + 1_800_000     # replay di tengah hari (05:30)
    with client.websocket_connect("/ws/replay") as ws:
        def cmd(**m):
            ws.send_json(m)
            return ws.receive_json()

        cmd(cmd="start", symbol="SAMPLEUSDT", start=start, tf="1d")
        d0 = start // D * D - D                                       # kemarin (sudah close)
        r = cmd(cmd="struct", low="1h", ranges=[[d0, d0 + D], [d0 - D, d0]])
        assert r["type"] == "struct" and len(r["items"]) == 2
        it = r["items"][0]
        assert len(it["bars"]) == 24 and it["done"] and it["bars"][0]["time"] * 1000 == d0
        b, bars = it["big"], it["bars"]
        assert b["high"] == max(x["high"] for x in bars) and b["low"] == min(x["low"] for x in bars)
        assert b["open"] == bars[0]["open"] and b["close"] == bars[-1]["close"]
        assert bars[it["i_high"]]["high"] == b["high"] and bars[it["i_low"]]["low"] == b["low"]
        assert it["first"] == ("high" if it["i_high"] < it["i_low"] else "low")
        d1 = cmd(cmd="set_tf", tf="1d")["bars"]                         # sama dengan candle D1 di chart
        k = next(x for x in d1 if x["time"] * 1000 == d0)
        assert abs(k["high"] - b["high"]) < 1e-9 and abs(k["low"] - b["low"]) < 1e-9 and abs(k["close"] - b["close"]) < 1e-9
        # candle hari ini masih terbentuk: hanya sampai waktu replay
        t = cmd(cmd="struct", low="1h", ranges=[[start // D * D, start // D * D + D]])["items"][0]
        assert not t["done"] and len(t["bars"]) == 6                  # 00..04 close + 05:00 forming
        assert all(x["time"] * 1000 < start for x in t["bars"])
        # minggu (W -> D1): 7 candle D1 dirakit dari 1d
        w = cmd(cmd="struct", low="1d", ranges=[[d0 - 6 * D, d0 + D]])["items"][0]
        assert len(w["bars"]) == 7
        assert cmd(cmd="struct", low="1d", ranges=[[d0, d0 + D]])["type"] == "error"     # TF kecil terlalu besar
        assert cmd(cmd="struct", low="5m", ranges=[[d0 - 9 * D, d0 + D]])["type"] == "error"  # terlalu banyak candle
        assert cmd(cmd="struct", low="7m", ranges=[[d0, d0 + D]])["type"] == "error"
