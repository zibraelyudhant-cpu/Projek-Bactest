"""📼 Perekam order book & uji tembok."""
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
from backend import obrec as OB  # noqa: E402
from backend.screener import Client  # noqa: E402
from fake_binance import serve  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture()
def ob(tmp_path, monkeypatch):
    monkeypatch.setattr(OB, "BASE", str(tmp_path / "ob"))
    return OB


@pytest.fixture(scope="module")
def cl(tmp_path_factory):
    d = tmp_path_factory.mktemp("obd")
    for i, s in enumerate(["AAAUSDT", "BBBUSDT"]):
        make(str(d), symbol=s, days=20, seed=i)
    srv = serve(str(d))
    yield Client(f"http://127.0.0.1:{srv.server_address[1]}")
    srv.shutdown()


def test_walls_spoof_and_seen():
    snaps = [{"t": 0, "mid": 100, "w": [["BUY", 90, 5e5], ["SELL", 110, 3e5]]},
             {"t": 1, "mid": 100, "w": [["BUY", 90, 6e5], ["SELL", 110, 3e5]]},
             {"t": 2, "mid": 94, "w": [["SELL", 110, 3e5]]},                 # BUY 90 hilang saat harga mendekat (94)
             {"t": 3, "mid": 100, "w": []}]                                   # SELL 110 hilang, harga tidak mendekat
    W = {w["side"]: w for w in OB._walls(snaps)}
    assert W["BUY"]["spoof"] and W["BUY"]["seen"] == 2 and W["BUY"]["usdt"] == 6e5
    assert not W["SELL"]["spoof"] and W["SELL"]["seen"] == 3


def test_outcome():
    n = 40
    t = np.arange(n) * 300_000
    a = np.full(n, 1.0)
    c = np.full(n, 100.0)
    h, l = c + 0.2, c - 0.2
    l[5], h[8] = 89.95, 101.5                                                # sentuh BUY 90 lalu naik
    c2 = c.copy(); c2[6] = 89.0                                             # close menembus 0.3 ATR
    assert OB._outcome(t, h, l, c, a, 0, 90, "BUY") == 1                     # sentuh lalu naik 1 ATR = mantul
    assert OB._outcome(t, h, l, c2, a, 0, 90, "BUY") == -1
    assert OB._outcome(t, h, l, c, a, 0, 50, "BUY") is None                  # tidak pernah tersentuh
    h3 = h.copy(); h3[5] = 105                                               # high candle sentuhan tidak dihitung mantul
    c3 = c.copy(); c3[5] = 89.0
    assert OB._outcome(t, h3, l, c3, a, 0, 90, "BUY") == -1


def test_record_status_and_test(ob, cl):
    cfg = ob.set_cfg({"coins": "aaa, bbb", "interval_min": 999, "min_usdt": 1, "band_pct": 50})
    assert cfg["interval_min"] == 60 and cfg["min_usdt"] == 10_000 and cfg["band_pct"] == 10 and not cfg["on"]
    for _ in range(3):
        assert ob.record_once(cl, cfg) == 2
    st = ob.status()
    assert st["coins"] == 2 and st["snapshots"] == 6 and not st["running"]
    snap = ob.load("AAAUSDT")[0]
    assert snap["w"] and all(w[0] in ("BUY", "SELL") and w[2] >= 10_000 for w in snap["w"])
    r = ob.wall_test(cl)
    assert set(r["groups"]) >= {"tembok bertahan", "pembanding (tanpa tembok)"} and isinstance(r["verdict"], str)
    assert not r["enough"] or r["edge"] is not None
