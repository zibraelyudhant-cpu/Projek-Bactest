import os
import tempfile

# tes tidak boleh terpengaruh threshold whale yang kamu simpan di saved/whale_config.json
os.environ.setdefault("WHALE_CFG_FILE", os.path.join(tempfile.mkdtemp(prefix="whcfg_"), "whale_config.json"))
# ... dan default penghalusan Dorongan % hasil Tes SNR
os.environ.setdefault("DORONGAN_DEF_FILE", os.path.join(tempfile.mkdtemp(prefix="dordef_"), "dorongan_default.json"))
os.environ.setdefault("RESULTS_DIR", os.path.join(tempfile.mkdtemp(prefix="results_"), "results"))
# ... jurnal sinyal & rekaman order book kamu juga tidak boleh tersentuh tes
os.environ.setdefault("JOURNAL_FILE", os.path.join(tempfile.mkdtemp(prefix="journal_"), "journal.json"))
os.environ.setdefault("JOURNAL_NO_THREAD", "1")
os.environ.setdefault("OBREC_DIR", os.path.join(tempfile.mkdtemp(prefix="obrec_"), "orderbook"))
