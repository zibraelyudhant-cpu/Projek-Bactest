"""📚 Info Trading: data materi (candle asli + anotasi) lengkap & konsisten, builder bisa jalan di data tiruan."""
import json
import os
import sys

import numpy as np

PA = ["sweep", "fakeout", "structure", "range", "ob", "fvg", "sd", "breaker", "flip", "fib", "pd", "elliott"]
IND = ["rsi_div", "stoch", "ma", "force", "macd", "adx", "atr", "volume", "bb", "vwap", "chartpat", "candle", "swingk", "fibtools", "fibext",
       "trendline", "slope"]
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def test_edu_data_valid():
    full = json.load(open(os.path.join(ROOT, "frontend", "edu_data.json")))
    data, gloss = full["topics"], full["glossary"]
    keys = [t["key"] for t in data]
    assert keys == PA + IND
    # kamus: 50 istilah, SEMUA punya animasi (topik + langkah yang ada)
    assert len(gloss) == 50 and [g["no"] for g in gloss] == list(range(1, 51))
    for g in gloss:
        assert g["topic"] is not None, g["term"]
        assert g["step"] < len(data[g["topic"]]["scenarios"][g["scn"]]["steps"])
    for t in data:
        assert t["scenarios"], t["key"]
        for s in t["scenarios"]:
            C = s["C"]
            n = len(C)
            assert 60 <= n <= 260, (t["key"], n)
            assert all(len(c) == 5 and c[2] >= max(c[1], c[4]) - 1e-9 and c[3] <= min(c[1], c[4]) + 1e-9 for c in C)
            assert all(b[0] > a[0] for a, b in zip(C, C[1:]))                    # urut waktu
            st = [x[3] for x in s["steps"]]
            assert st == sorted(st) and st[0] == 0 and st[-1] < n                 # langkah berurutan di dalam potongan
            for a in s["ann"]:
                assert 0 <= a["from"] <= n, a
                for k in ("i", "i0", "i1", "i2"):
                    if a.get(k) is not None:
                        assert 0 <= a[k] < n, (t["key"], a)
            assert all(0 <= x < n for x in s["slow"] + s["pause"][:-1])
            n_ = len(C)                                                          # indikator: panjang sama dengan candle
            for o in s.get("ov", []):
                assert len(o["v"]) == n_ and o["c"], (t["key"], o["n"])
            if s.get("pane"):
                assert s["pane"]["series"] and all(len(x["v"]) == n_ for x in s["pane"]["series"]), t["key"]
            if s.get("band"):
                assert s["band"]["a"] < len(s["ov"]) and s["band"]["b"] < len(s["ov"])
    assert len(data[0]["scenarios"]) == 2                                          # sweep vs breakdown asli
    assert {t["group"] for t in data} == {"Price Action & SMC", "Indikator", "Pola & alat"}
    assert len(next(t for t in data if t["key"] == "swingk")["scenarios"]) == 5        # swing minimal 1..5 ATR


def test_builder_runs_on_series(tmp_path):
    """Builder jalan di data apa pun (contoh mungkin tidak ditemukan -> topik kosong, tidak error)."""
    from tools import edu_build as EB
    rng = np.random.default_rng(1)
    c = 100 * np.exp(np.cumsum(rng.normal(0, 0.006, 1500)))
    o = np.r_[c[0], c[:-1]]
    h, l = np.maximum(o, c) * (1 + rng.random(1500) * 0.003), np.minimum(o, c) * (1 - rng.random(1500) * 0.003)
    rows = [[1_700_000_000_000 + i * 3_600_000, o[i], h[i], l[i], c[i], 1.0] for i in range(1500)]
    json.dump(rows, open(tmp_path / "TESTUSDT_1h.json", "w"))
    out = EB.build_all(str(tmp_path))["topics"]
    assert [t["key"] for t in out] == PA + IND
    for t in out:
        for s in t["scenarios"]:
            assert s["sym"] == "TESTUSDT" and s["steps"]


def test_indicator_formulas():
    """Rumus indikator Info Trading: nilai dalam rentang yang benar & tanpa look-ahead."""
    from tools import edu_ind as I
    rng = np.random.default_rng(3)
    c = 100 * np.exp(np.cumsum(rng.normal(0, 0.01, 600)))
    h, l, v = c * 1.004, c * 0.996, rng.random(600) + 1
    r = I.rsi(c)
    assert np.nanmin(r) >= 0 and np.nanmax(r) <= 100
    K, D = I.stoch(h, l, c)
    assert np.nanmin(K) >= 0 and np.nanmax(K) <= 100
    ax, p, m = I.adx(h, l, c)
    assert np.nanmin(ax) >= 0 and np.nanmax(ax) <= 100
    for f in (lambda x: I.sma(x, 20), lambda x: I.ema(x, 20), lambda x: I.wma(x, 20), lambda x: I.hma(x, 20), lambda x: I.tema(x, 20)):
        a, b = f(c), f(np.r_[c[:400], c[400:] * 2])                       # masa depan diubah -> masa lalu tetap
        assert np.allclose(a[:400], b[:400], equal_nan=True)
    mid, up, lo = I.boll(c)
    assert np.all((up >= mid) | np.isnan(up)) and np.all((lo <= mid) | np.isnan(lo))
    sw = I.zz(h, l, np.full(600, 1.0), 3.0)
    assert all(abs(b[1] - a[1]) >= 3.0 - 1e-9 for a, b in zip(sw, sw[1:]))
