"""📒 Jurnal sinyal: catat sinyal layak & pantau dengan aturan yang sama dengan backtest."""
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from backend import journal as JN  # noqa: E402

M = 900_000   # 15m


@pytest.fixture()
def jn(tmp_path, monkeypatch):
    monkeypatch.setattr(JN, "PATH", str(tmp_path / "journal.json"))
    return JN


def sig(**k):
    base = {"source": "msa", "symbol": "AAAUSDT", "tf": "15m", "dir": 0, "kind": "limit", "entry": 99.0, "sl": 98.0, "tp": 102.0,
            "rr": 3.0, "created": 0, "ref_price": 100.0, "wait_until": 10 * M, "hold_ms": 20 * M, "cancel_at": 105.0,
            "bt": {"wr": 40, "exp_r": 0.6, "exp_sig": 0.5, "fill_pct": 80, "proven": True}}
    base.update(k)
    return base


def arr(h, l, c):
    n = len(c)
    return np.arange(n) * M, np.array(h, float), np.array(l, float), np.array(c, float)


def test_simulate_rules():
    # limit 99 tersentuh di candle 1, TP 102 di candle 3
    t, h, l, c = arr([100.5, 100, 101, 102.5], [99.5, 98.9, 99.5, 101], [100, 99.5, 100.5, 102])
    u = JN.simulate(sig(), t, h, l, c, 4 * M)
    assert u["status"] == "TP" and u["fill_time"] == M and u["result_r"] == 3.0
    # TP & SL di candle yang sama sesudah terisi = SL
    t, h, l, c = arr([100.5, 100, 102.5], [99.5, 98.9, 97.5], [100, 99.5, 100])
    assert JN.simulate(sig(), t, h, l, c, 3 * M)["status"] == "SL"
    # harga lari melewati ujung leg sebelum limit tersentuh = batal
    t, h, l, c = arr([101, 106], [100, 103], [100.5, 105.5])
    assert JN.simulate(sig(), t, h, l, c, 2 * M)["status"].startswith("batal (harga lari")
    # tidak tersentuh sampai batas tunggu = batal; belum lewat batas = menunggu
    t, h, l, c = arr([101] * 12, [100] * 12, [100.5] * 12)
    assert JN.simulate(sig(cancel_at=None), t, h, l, c, 12 * M)["status"] == "batal (tidak terisi)"
    assert JN.simulate(sig(cancel_at=None), t[:5], h[:5], l[:5], c[:5], 5 * M)["status"] == "menunggu"
    # market: terisi candle pertama, waktu habis ditutup di close (R dibatasi -1 .. RR)
    t, h, l, c = arr([100.5] * 25, [99.5] * 25, [100.0] * 24 + [100.0])
    u = JN.simulate(sig(kind="market", entry=100.0, sl=99.0, tp=103.0, hold_ms=20 * M), t, h, l, c, 25 * M)
    assert u["status"] == "waktu habis" and u["result_r"] == pytest.approx(0.0)


def test_add_dedupe_summary(jn):
    assert jn.add(sig()) and not jn.add(sig())                       # sinyal sama tidak dobel
    assert jn.add(sig(created=5 * M))
    d = jn._load()
    a, b = d["signals"]
    with jn._LOCK:
        a.update(status="TP", fill_time=M, exit_time=3 * M, result_r=3.0)
        b.update(status="batal (tidak terisi)", exit_time=9 * M)
        jn._save(d)
    S = jn.summary()["summary"]["msa"]
    assert S["n"] == 2 and S["done"] == 1 and S["wr"] == 100 and S["fill_pct"] == 50 and S["r_per_signal"] == pytest.approx(1.5)
    assert S["bt_exp_sig"] == pytest.approx(0.5)
    assert S["wins"] == 1 and S["losses"] == 0 and S["timeouts"] == 0                # jumlah menang / kalah
    jn.set_auto(False)
    assert not jn.add(sig(created=9 * M))                             # otomatis mati -> tidak dicatat
    assert jn.add(sig(source="manual", created=9 * M))                # entry kamu tetap bisa
    assert jn.delete(all_=True) == 3


def test_from_msa():
    r = {"symbol": "AAAUSDT", "tf": "15m", "now_time": 0, "now_price": 100.0, "pattern": ["LH", "LL"],
         "best": {"usable": True, "dir": 1, "entry": "fib0.5", "price_entry": 101.0, "price_sl": 102.0, "price_tp": 98.0, "rr": 3.0,
                  "expires": 49 * M, "ext": 95.0, "wr": 40, "exp_r": 0.5, "exp_sig": 0.4, "fill_pct": 75, "proven": True}}
    s = JN.from_msa(r)
    assert s["created"] == M and s["kind"] == "limit" and s["cancel_at"] == 95.0 and s["wait_until"] == 49 * M
    assert JN.from_msa({**r, "best": None}) is None


def test_version_filter(jn):
    """📒 Jurnal per versi: sinyal lama (tanpa versi) = "lama", filter versi hanya menghitung sinyal versi itu."""
    assert jn.add(sig(created=1 * M))                                       # versi lama (tanpa app_version)
    assert jn.add({**sig(created=2 * M), "app_version": "4.11"})
    assert jn.add({**sig(created=3 * M), "app_version": "4.10"})
    assert jn.add({**sig(created=4 * M), "app_version": "4.11"})
    J = jn.summary()
    assert [x["v"] for x in J["versions"]] == ["4.11", "4.10", "lama"] and J["versions"][0]["n"] == 2
    assert jn.summary("4.11")["summary"]["msa"]["n"] == 2
    assert jn.summary("lama")["summary"]["msa"]["n"] == 1
    assert jn.summary()["summary"]["msa"]["n"] == 4
    jn.delete(all_=True)


def test_version_estimate(jn, monkeypatch):
    """Sinyal lama: perkiraan '≤ versi' = versi terakhir yang sudah rilis saat candle sinyal close."""
    monkeypatch.setattr(jn, "_releases", lambda: [(10 * M, "4.05"), (20 * M, "4.06"), (40 * M, "4.07")])
    s_ = sig(created=25 * M)
    assert jn.est_version(s_) == "4.06" and jn.vkey(s_) == "lama:4.06"
    assert jn.est_version(sig(created=1)) is None
    assert jn.vkey({**s_, "app_version": "4.11"}) == "4.11"
    assert jn.add(s_) and jn.add({**sig(created=30 * M), "app_version": "4.11"})
    J = jn.summary()
    assert [x["v"] for x in J["versions"]] == ["4.11", "lama:4.06"]
    assert jn.summary("lama:4.06")["summary"]["msa"]["n"] == 1 and jn.summary("lama")["summary"]["msa"]["n"] == 1
    assert J["signals"][-1].get("app_version_est") == "4.06"
    jn.delete(all_=True)


def test_trend_info():
    """Jurnal mencatat tren yang dipakai sinyal (TF + arah) untuk tiap sumber."""
    from backend import journal as J
    s = {"usable": True, "how": "market (harga sekarang)", "symbol": "XUSDT", "side": "SELL", "entry": 1.0, "sl": 1.1, "tp": 0.7, "rr": 3.0,
         "bt_tf": "15m", "trend_tf": "15m", "trend_up": False}
    w = J.from_whale(s)
    assert w["trend"] == {"tf": "15m", "dir": -1, "txt": "EMA20 < EMA50"}
    r = {"best": {"usable": True, "entry": "market", "dir": 0, "price_entry": 1.0, "price_sl": 0.9, "price_tp": 1.3, "rr": 3.0},
         "tf": "15m", "now_time": 0, "symbol": "XUSDT", "filters": {"htf": "4h", "htf_now": "naik"}}
    assert J.from_msa(r)["trend"]["tf"] == "4h" and J.from_msa(r)["trend"]["dir"] == 1
    r["filters"] = {}
    assert J.from_msa(r)["trend"] is None


# ================================================================== 🔍 evaluasi (v4.31)
H = 3_600_000


def test_wib_block_day():
    t0 = 1_763_942_400_000 - 7 * H                       # 2025-11-24 00:00 WIB (Senin) dalam ms UTC
    assert JN.wib_day(t0) == 0 and JN.wib_block(t0) == 4  # 00:00 WIB -> blok 23–03
    assert JN.wib_block(t0 + 7 * H) == 0                  # 07:00 WIB -> 07–11
    assert JN.wib_block(t0 + 19 * H) == 3                 # 19:00 WIB -> 19–23
    assert JN.wib_day(t0 + 24 * H * 5) == 5               # Sabtu


def test_scan_times_exact_and_estimate():
    S = [dict(id="a", source="whale", created=1000, scan_start=500), dict(id="b", source="whale", created=10 * 60_000),
         dict(id="c", source="whale", created=20 * 60_000), dict(id="d", source="whale", created=200 * 60_000),
         dict(id="e", source="msa", created=20 * 60_000)]
    T = JN.scan_times(S)
    assert T["a"] == (500, True)
    assert T["b"] == T["c"] == (10 * 60_000, False)       # tercatat berdekatan = 1 scan, perkiraan = sinyal paling awal
    assert T["d"] == (200 * 60_000, False) and T["e"] == (20 * 60_000, False)


def test_path_stats_mfe_tp_after_be():
    # BUY market entry 100, SL 99 (R=1), TP 103. Naik ke 101.5 (+1,5R), lalu turun kena SL, lalu naik sampai TP (dalam batas waktu)
    h = [100.2, 100.5, 101.5, 100.2, 99.5, 101, 103.5, 100]
    l = [99.8, 99.9, 100.5, 99.5, 98.5, 99.8, 101, 99.5]
    c = [100, 100.4, 101, 99.8, 99, 100.8, 103, 100]
    t = np.arange(len(c)) * M
    s = sig(kind="market", entry=100.0, sl=99.0, tp=103.0, rr=3.0, hold_ms=7 * M, fill_time=0, exit_time=4 * M, status="SL", result_r=-1.0)
    p = JN.path_stats(s, t, np.array(h), np.array(l), np.array(c), 10 * M)
    assert p["mfe"] == pytest.approx(1.5) and p["bars"] == 4 and p["tp_after"] is True and p["final"]
    assert p["be_r"] == 0.0                              # SL ke entry setelah +1R: candle 3 menyentuh 100 -> 0R


def _done(i, **k):
    base = sig(kind="market", fill_time=i * H, exit_time=i * H + 4 * M, status="SL", result_r=-1.0, created=i * H, id=f"s{i}",
               source="whale", app_version="4.31", trend={"tf": "1h", "dir": 1, "txt": ""})
    base.update(k)
    return base


def test_evaluate_groups_scan_tips(jn):
    import json
    sigs = []
    t0 = 1_763_942_400_000 - 7 * H                       # Senin 00:00 WIB
    for i in range(40):
        good = i % 2 == 0                                # BUY searah tren (untung) vs SELL melawan tren (rugi)
        st = t0 + (19 * H if good else 8 * H) + (i // 2) * 24 * H
        sigs.append(_done(i, dir=0 if good else 1, status="TP" if good else "SL", result_r=3.0 if good else -1.0, scan_start=st, created=st,
                          fill_time=st + M, exit_time=st + 5 * M, path={"mfe": 1.4 if not good else 3.0, "bars": 4, "tp_after": False, "be_r": 0.0 if not good else 3.0, "final": True}))
    json.dump({"auto": True, "signals": sigs}, open(JN.PATH, "w"))
    E = JN.evaluate("whale", min_n=10)
    assert E["n_done"] == 40 and E["n_exact"] == 40
    arah = next(g for g in E["groups"] if g["title"] == "Arah")["rows"]
    assert arah[0]["label"] == "▲ BUY" and arah[0]["r"] == 3.0 and arah[1]["r"] == -1.0
    tren = {r["label"]: r for r in next(g for g in E["groups"] if g["title"] == "Tren saat sinyal")["rows"]}
    assert tren["melawan tren"]["badge"] == "bad" and tren["searah tren"]["n"] == 20
    assert E["sl"]["n"] == 20 and E["sl"]["mfe1"] == 100 and E["sl"]["be"]["r_be"] > E["sl"]["be"]["r_now"]
    B = {r["label"]: r for r in E["scan"]["blocks"]}
    assert B["19–23"]["r"] == 3.0 and B["07–11"]["r"] == -1.0      # jam MULAI scan (WIB), bukan waktu selesai
    assert sum(c["n"] for row in E["scan"]["heat"] for c in row) == 40
    txt = " ".join(E["tips"])
    assert "melawan tren" in txt and "geser SL ke entry" in txt and "19–23 WIB" in txt
    assert E["summary"]
    assert JN.evaluate("whale", exact_only=True)["scan"]["n"] == 40


def test_scan_start_recorded(monkeypatch, tmp_path):
    """_bg_scan menyimpan waktu MULAI scan; sinyal yang dicatat selama scan membawa scan_start itu."""
    import time as _t
    import backend.app as APP
    monkeypatch.setattr(JN, "PATH", str(tmp_path / "j.json"))
    got = {}

    def work(prog):
        _t.sleep(0.3)
        APP._journal_add(lambda J: sig(source="whale", created=123))
        return {}
    jid = APP._bg_scan(work)["id"]
    t_click = _t.time() * 1000
    for _ in range(50):
        if APP._scan_jobs[jid]["status"] != "running":
            break
        _t.sleep(0.05)
    s = JN._load()["signals"][0]
    assert abs(s["scan_start"] - t_click) < 1000 and s["scan_start"] <= s.get("scan_start") and got == {}


def test_rr_group_rounded(jn):
    import json
    sigs = [_done(i, rr=r, result_r=-1.0) for i, r in enumerate((1.01367, 0.76865, 1.0724, 2.11564, 3.0))]
    json.dump({"auto": True, "signals": sigs}, open(JN.PATH, "w"))
    rr = {r["label"]: r["n"] for r in next(g for g in JN.evaluate("whale", min_n=3)["groups"] if g["title"] == "RR")["rows"]}
    assert rr == {"1:1": 3, "1:2": 1, "1:3": 1}


def test_scan_count_and_tip_needs_scans(jn):
    """v4.32: jam / hari scan menghitung scan berbeda; saran jam / hari hanya kalau >= 5 scan."""
    import json
    t0 = 1_763_942_400_000 - 7 * H
    sigs = []
    for i in range(30):                                   # 30 trade dari HANYA 2 scan (jam 19 menang, jam 08 kalah)
        good = i % 2 == 0
        st = t0 + (19 * H if good else 8 * H)
        sigs.append(_done(i, result_r=3.0 if good else -1.0, status="TP" if good else "SL", scan_start=st, created=st))
    json.dump({"auto": True, "signals": sigs}, open(JN.PATH, "w"))
    E = JN.evaluate("whale", min_n=10)
    assert E["scan"]["n_scans"] == 2 and all(r["scans"] == 1 for r in E["scan"]["blocks"])
    assert sum(c["scans"] for row in E["scan"]["heat"] for c in row) == 2
    assert not any("Mulai scan" in t for t in E["tips"])  # 1 scan per jam: belum boleh disimpulkan


def test_whale_market_mid_candle_checks_first_candle():
    """v4.33 (F): sinyal Whale market dicatat saat scan (tengah candle) -> candle yang sedang berjalan ikut dicek SL / TP."""
    t, h, l, c = arr([100.5, 100.2, 100.4], [99.5, 98.5, 99.8], [100, 99, 100])
    s = sig(source="whale", kind="market", entry=100.0, sl=99.0, tp=103.0, created=M + M // 2, hold_ms=10 * M, wait_until=None, cancel_at=None)
    u = JN.simulate(s, t, h, l, c, 3 * M)
    assert u["status"] == "SL" and u["fill_time"] == M and u["exit_time"] == M      # SL kena di candle saat scan
    # sinyal tepat di close candle (menu lain): candle sesudahnya = candle terisi, dicek mulai candle berikutnya (seperti dulu)
    s2 = sig(kind="market", entry=100.0, sl=99.0, tp=103.0, created=M, hold_ms=10 * M, wait_until=None, cancel_at=None)
    assert JN.simulate(s2, t, h, l, c, 3 * M)["status"] == "terisi"


def test_from_whale_uses_scan_time():
    s = {"usable": True, "how": "market (harga sekarang)", "bt_tf": "15m", "symbol": "AAAUSDT", "side": "BUY", "entry": 1.0, "sl": 0.9,
         "tp": 1.2, "rr": 2.0, "t_scan": 1_700_000_123_456, "candles": [[1_700_000_000_000, 1, 1, 1, 1]]}
    assert JN.from_whale(s)["created"] == 1_700_000_123_456
