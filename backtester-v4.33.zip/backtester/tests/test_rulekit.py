"""🧱 Penyusun aturan: spesifikasi -> Python yang pasti, tanpa intip masa depan, dan trade sesuai aturan."""
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from backend import rulekit as RK  # noqa: E402
from backend.backtest import load_strategies, run_backtest  # noqa: E402
from backend.data import TF_MS, DataStore  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("rk")
    make(str(d), days=60)
    return DataStore(str(d))


def test_all_indicators(store):
    b = store.get("SAMPLEUSDT", "1h")
    for k, (name, params, kind, _h) in RK.CAT.items():
        p = {a: dflt for a, _l, dflt, *_ in params}
        x = RK.ind(k, b, **p)
        assert len(x) == len(b.c), k
        assert np.isfinite(x[-50:]).all(), k                            # nilai akhir terisi
    assert RK.ind("donch_high", b, n=5)[-1] == max(b.h[-6:-1])          # n candle SEBELUMNYA


def test_mirror():
    L = RK.validate({"name": "x", "tf": "1h", "long": [
        {"a": {"ind": "rsi"}, "op": "<", "b": {"num": 30}},
        {"a": {"ind": "adx"}, "op": ">", "b": {"num": 25}},
        {"a": {"ind": "close"}, "op": "cross_up", "b": {"ind": "bb_upper"}},
        {"a": {"ind": "willr"}, "op": "<", "b": {"num": -80}},
        {"a": {"ind": "macd_hist"}, "op": "rising", "k": 2},
        {"a": {"ind": "plus_di"}, "op": ">", "b": {"ind": "minus_di"}}]})
    S = L["short"]
    assert S[0]["op"] == ">" and S[0]["b"]["num"] == 70                  # RSI < 30 -> > 70
    assert S[1] == L["long"][1]                                          # ADX (kekuatan) tidak dicerminkan
    assert S[2]["op"] == "cross_dn" and S[2]["b"]["ind"] == "bb_lower"
    assert S[3]["op"] == ">" and S[3]["b"]["num"] == -20                 # W%R -80 -> -20
    assert S[4]["op"] == "falling"
    assert S[5]["a"]["ind"] == "minus_di" and S[5]["b"]["ind"] == "plus_di"


def test_validate_errors():
    with pytest.raises(ValueError):
        RK.validate({"name": "", "tf": "1h", "long": [{"a": {"ind": "rsi"}, "op": "<", "b": {"num": 30}}]})
    with pytest.raises(ValueError):
        RK.validate({"name": "x", "tf": "1h", "long": []})
    with pytest.raises(ValueError):                                      # TF indikator lebih kecil dari TF strategi
        RK.validate({"name": "x", "tf": "1h", "long": [{"a": {"ind": "rsi", "tf": "15m"}, "op": "<", "b": {"num": 30}}]})
    with pytest.raises(ValueError):                                      # setting di luar batas
        RK.validate({"name": "x", "tf": "1h", "long": [{"a": {"ind": "ema", "p": {"n": 0}}, "op": ">", "b": {"num": 1}}]})


def test_generated_trades_follow_rule(store, tmp_path):
    spec = {"name": "Close tembus SMA", "tf": "1h", "dir": "long", "mirror": True, "entry": "market", "sl_mode": "atr", "rr": 2,
            "long": [{"a": {"ind": "close"}, "op": "cross_up", "b": {"ind": "sma", "p": {"n": 20}}},
                     {"a": {"ind": "rsi", "p": {"n": 14}}, "op": ">", "b": {"num": 50}}]}
    r = RK.save(str(tmp_path), spec)
    assert RK.list_saved(str(tmp_path))[0]["slug"] == r["slug"]
    cls = load_strategies(str(tmp_path))[r["class"]]
    res = run_backtest(store, "SAMPLEUSDT", cls)
    assert res["metrics"]["trades"] > 5 and all(t["side"] == "long" for t in res["trades"])
    b = store.get("SAMPLEUSDT", "1h")
    c = np.asarray(b.c, float)
    s20 = RK.ind("sma", b, n=20)
    rsi = RK.ind("rsi", b, n=14)
    t = np.asarray(b.t)
    for tr in res["trades"]:
        i = int(np.searchsorted(t, tr["entry_time"])) - 1                 # candle sinyal = candle sebelum entry market
        assert c[i - 1] <= s20[i - 1] and c[i] > s20[i], tr                # close memotong SMA ke atas di candle sinyal
        assert rsi[i] > 50 - 3                                           # RSI (jendela 850 candle ~ penuh) > 50
    assert RK.delete(str(tmp_path), r["slug"]) == 2


def test_many_indicators_compile(store, tmp_path):
    conds = [{"a": {"ind": k}, "op": ">", "b": {"num": -1e9}} for k in RK.CAT]
    spec = {"name": "Semua indikator", "tf": "1h", "dir": "both", "long": conds[:12], "mirror": False, "short": conds[12:24]}
    r = RK.save(str(tmp_path), spec)
    compile(r["code"], "x", "exec")
    spec2 = {"name": "Semua indikator 2", "tf": "1h", "dir": "long", "long": conds[24:36]}
    compile(RK.save(str(tmp_path), spec2)["code"], "x", "exec")
