"""🛡️ SL anti-gocekan (logika Whale) untuk Market Structure & TA Pro: tanpa intip masa depan, batas 4%, tembok live."""
import numpy as np

from backend import antigocek as AG, whale_cfg


def _series(n=1500, seed=3):
    rng = np.random.default_rng(seed)
    c = 100 + np.cumsum(rng.normal(0, 0.4, n))
    h = c + rng.uniform(0.05, 0.6, n)
    l = c - rng.uniform(0.05, 0.6, n)
    return h, l, c


def test_no_lookahead():
    h, l, c = _series()
    g = AG.Ctx(h, l, c)
    for s in (400, 700, 1100):
        g2 = AG.Ctx(h[:s + 1], l[:s + 1], c[:s + 1])        # data masa depan dibuang -> SL harus sama persis
        for long in (True, False):
            ref = float(c[s])
            assert AG.sl_at(g, s, long, ref) == AG.sl_at(g2, s, long, ref)


def test_side_and_cap():
    h, l, c = _series()
    g = AG.Ctx(h, l, c)
    mx = whale_cfg.get()["sl.max_pct"]
    for s in range(300, 1400, 37):
        ref = float(c[s])
        lo, hi = AG.sl_at(g, s, True, ref), AG.sl_at(g, s, False, ref)
        assert lo is None or (lo < ref and (ref - lo) / ref * 100 <= mx + 1e-9)
        assert hi is None or (hi > ref and (hi - ref) / ref * 100 <= mx + 1e-9)


def test_beyond_swing_and_walls():
    h, l, c = _series()
    g = AG.Ctx(h, l, c)
    s = 1200
    ref = float(c[s])
    d = AG.sl_at(g, s, True, ref, detail=True)
    sw = g.swing(s, True, ref)
    if sw is not None and not d["capped"]:
        assert d["sl"] < sw                                 # selalu di luar swing (bukan tepat di swing = rawan disapu)
    wall = {"side": "BUY", "price": ref * 0.98, "usdt": 1e6, "seen": 3}
    dw = AG.sl_at(g, s, True, ref, walls=[wall], detail=True)
    assert dw["sl"] <= d["sl"] and any("tembok" in r for r in dw["reasons"])   # tembok live: kandidat terjauh dipakai


def test_menus_use_anti_gocek():
    from backend import msscreen as MS, stratlab as SL
    assert SL.SLS == ("anti",) and "anti" in SL.SL_TXT
    h, l, c = _series()
    g = AG.Ctx(h, l, c)
    st = MS._stops(g, 1000, 0, float(c[1000]))
    assert list(st) in (["anti"], [])
