"""Tes parsing & agregasi script download (offline)."""
import datetime as dt
import io
import os
import sys
import zipfile

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
import download_binance as d  # noqa: E402


def _zip(lines):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("x.csv", "\n".join(lines))
    return buf.getvalue()


def test_parse_zip_with_and_without_header_and_microseconds():
    row = "1735689600000,93548.80,93690.00,93514.20,93648.40,341.604,1735689899999,1,2,3,4,0"
    a = d.parse_zip(_zip(["open_time,open,high,low,close,volume,close_time,q,c,tb,tq,i", row]))
    b = d.parse_zip(_zip([row]))
    c = d.parse_zip(_zip(["1735689600000000," + row.split(",", 1)[1]]))
    assert a.shape == (1, 6) and (a == b).all() and (a == c).all()
    assert a[0, 0] == 1735689600000 and a[0, 5] == 341.604


def test_aggregate_matches_manual():
    t0 = 1735689600000
    rng = np.random.default_rng(0)
    n = 288 * 2
    c = 100 + np.cumsum(rng.normal(0, 1, n))
    o = np.r_[100, c[:-1]]
    a = np.column_stack([t0 + np.arange(n) * 300_000, o, np.maximum(o, c) + 1, np.minimum(o, c) - 1, c, np.ones(n)])
    h4 = d.aggregate(a, d.TF_MS["4h"])
    assert len(h4) == 12
    assert h4[1, 1] == a[48, 1] and h4[1, 4] == a[95, 4]
    assert h4[1, 2] == a[48:96, 2].max() and h4[1, 3] == a[48:96, 3].min() and h4[1, 5] == 48


def test_file_list_monthly_then_daily():
    today = dt.date(2026, 10, 25)
    jobs = d.file_list("BTCUSDT", "5m", dt.date(2026, 8, 15), dt.date(2026, 10, 24), today)
    monthly = [m for m, _ in jobs if m]
    assert monthly[0].endswith("BTCUSDT-5m-2026-08.zip") and monthly[-1].endswith("2026-09.zip")
    daily = [x for m, ds in jobs if not m for x in ds]
    assert len(daily) == 24 and daily[0].endswith("2026-10-01.zip")
