"""Client Binance: 429 ditunggu singkat lalu lanjut; 418 / blokir panjang langsung dilaporkan (tidak menunggu diam-diam
berjam-jam) dan permintaan berikutnya ditolak tanpa menghubungi Binance; status bisa ditampilkan di aplikasi."""
import http.server
import json
import os
import sys
import threading
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.screener import BinanceError, Client  # noqa: E402

PLAN = []
HITS = []


class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        HITS.append(self.path)
        code, hdr = PLAN.pop(0) if PLAN else (200, {})
        self.send_response(code)
        for k, v in hdr.items():
            self.send_header(k, v)
        self.send_header("X-MBX-USED-WEIGHT-1M", "5")
        self.end_headers()
        self.wfile.write(json.dumps({"ok": True}).encode())

    def log_message(self, *a):
        pass


@pytest.fixture()
def srv():
    s = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=s.serve_forever, daemon=True).start()
    PLAN.clear(); HITS.clear()
    yield f"http://127.0.0.1:{s.server_address[1]}"
    s.shutdown()


def test_429_waits_then_ok(srv):
    c = Client(srv)
    PLAN.append((429, {"Retry-After": "1"}))
    t0 = time.time()
    assert c.get("/x") == {"ok": True}
    assert 0.9 <= time.time() - t0 < 5 and c.status()["code"] == "ok" and c.state["errors"] == 1


def test_418_fails_fast_and_blocks_next(srv):
    c = Client(srv)
    PLAN.append((418, {"Retry-After": "900"}))
    t0 = time.time()
    with pytest.raises(BinanceError, match="418"):
        c.get("/x")
    assert time.time() - t0 < 3                                    # tidak menunggu 15 menit diam-diam
    st = c.status()
    assert st["code"] == "blokir" and 800 < st["wait_s"] <= 900
    n = len(HITS)
    with pytest.raises(BinanceError, match="memblokir"):
        c.get("/y")
    assert len(HITS) == n                                           # selama diblokir tidak menghubungi Binance (blokir tidak diperpanjang)
