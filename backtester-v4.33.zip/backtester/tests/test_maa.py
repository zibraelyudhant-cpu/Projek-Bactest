"""📈 Moving Average Analisis: sentuh MA, syarat RSI / Stochastic / MACD, respect 2 ATR sebelum melawan 1 ATR, poin bonus,
tanpa intip masa depan, endpoint + visual."""
import contextlib
import io
import os
import sys
import time

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend import maa as M  # noqa: E402
from backend.data import DataStore  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("maa")
    with contextlib.redirect_stdout(io.StringIO()):
        for i, s_ in enumerate(("BTCUSDT", "AAAUSDT", "BBBUSDT")):
            make(str(d), symbol=s_, days=150, seed=i + 1)
    return DataStore(str(d))


def _D(n=300):
    c = np.full(n, 100.0)
    return {"t": np.arange(n, dtype=np.int64) * 900_000, "o": c.copy(), "h": c + 0.1, "l": c - 0.1, "c": c.copy(), "a": np.full(n, 1.0)}


def test_points_and_outcome():
    D = _D()
    D["h"][15] = 102.2; D["h"][20] = 103.5                 # 2 ATR lalu 3 ATR, tidak pernah melawan 1 ATR
    o = M.outcome(D, 10, 1, 480 if False else 200)
    assert o["resp"] and o["lv"] == 3 and M.points(o) == 1.5
    D["l"][12] = 97.4                                     # melawan 2,5 ATR lebih dulu -> gagal
    o = M.outcome(D, 10, 1, 200)
    assert not o["resp"] and M.points(o) == -1.0
    D2 = _D(); D2["l"][14] = 97.9; D2["h"][14] = 100.5     # SHORT: turun 2 ATR tanpa melawan 1 ATR
    o = M.outcome(D2, 10, -1, 200)
    assert o["resp"] and o["lv"] == 2
    D3 = _D(); D3["h"][14] = 102.5; D3["l"][14] = 97.4      # 2 ATR & -2,5 ATR di candle sama = gagal (konservatif)
    assert not M.outcome(D3, 10, 1, 200)["resp"]
    assert M.points({"resp": True, "mx": 9.0}) == 2.5 and M.hold_bars("15m") == 480


def test_touch_rule(store):
    D = M.load(store, "BTCUSDT", "1h")
    ma = M.ma_of(D["c"], "ema", 100)
    up, dn = M.touches(D, ma)
    assert up.any() and dn.any() and not (up & dn).any()
    i = np.flatnonzero(up)[:50]
    assert (D["c"][i] > ma[i]).all() and (D["l"][i] <= ma[i] + 0.3 * D["a"][i] + 1e-9).all()
    k = np.flatnonzero(dn)[:50]
    assert (D["c"][k] < ma[k]).all() and (D["h"][k] >= ma[k] - 0.3 * D["a"][k] - 1e-9).all()


@pytest.mark.parametrize("ind", list(M.INDS))
def test_each_indicator_and_no_lookahead(store, ind):
    D = M.load(store, "BTCUSDT", "1h")
    T, E = M.coin_eval("BTCUSDT", D, "1h", "ema", 100, ind, M.LIST)
    assert set(T["per"]) == {str(p) for p in M.LIST}
    for p, G in T["per"].items():
        assert G["n"] == G["fail"] + G["lv2"] and G["n"] <= T["base"]["n"] + G["n"]
    A = M.analyse(T, E, ind)
    assert A["best"] and A["rows"][0]["p"] == A["best"]["p"]
    cu, cd, _ = M.ind_cond(D, ind, 21)                   # syarat indikator di candle N tidak berubah kalau data sesudah N dibuang
    N = len(D["c"]) - 400
    Dc = {k: v[:N] for k, v in D.items()}
    cu2, cd2, _ = M.ind_cond(Dc, ind, 21)
    assert (cu[:N] == cu2).all() and (cd[:N] == cd2).all()


def test_run_api_visual(store, monkeypatch, tmp_path):
    from backend import results_store
    monkeypatch.setattr(results_store, "BASE", str(tmp_path))
    syms = M.history_symbols(store, "1h", 3)
    pushes = []
    a = M.run(store, "1h", "ema", 100, "rsi", "auto", syms, workers=2, push=lambda p: pushes.append(p["phase"]))
    M._CACHE.clear()
    import shutil
    shutil.rmtree(os.path.join(str(tmp_path), "maa_cache"))
    b = M.run(store, "1h", "ema", 100, "rsi", "auto", syms, workers=1)
    assert a["best"]["p"] == b["best"]["p"] and a["best"]["n"] == b["best"]["n"] and len(a["rows"]) == 56 and pushes[-1] == "analisa"
    assert M.run(store, "1h", "ema", 100, "rsi", "auto", syms) is b
    monkeypatch.setenv("DATA_DIR", store.data_dir)
    import importlib

    import backend.app as app_mod
    importlib.reload(app_mod)
    app_mod.store = store
    from fastapi.testclient import TestClient
    client = TestClient(app_mod.app)
    assert client.post("/api/maa/run", json={"tf": "7m"}).status_code == 400
    assert client.post("/api/maa/run", json={"tf": "1h", "ind": "cci"}).status_code == 400
    r = client.post("/api/maa/run", json={"tf": "1h", "ma_type": "sma", "ma_len": 100, "ind": "stoch", "mode": "list", "hist": 3})
    for _ in range(600):
        st = client.get(f"/api/screener/job/{r.json()['id']}").json()
        if st["status"] != "running":
            break
        time.sleep(0.1)
    assert st["status"] == "done", st
    R = st["result"]
    assert R["ma_type"] == "sma" and R["ind"] == "stoch" and R["saved_id"] and R["examples"]
    x = R["examples"][-1]
    v = client.get("/api/maa/visual", params={"sym": x["sym"], "tf": "1h", "t": x["t"], "ma_type": "sma", "ma_len": 100, "ind": "stoch",
                                              "p": R["best"]["p"], "after": x["xo"] + 20}).json()
    assert v["candles"][v["i"]][0] == x["t"] and len(v["ma"]) == len(v["candles"]) and set(v["ind"]) == {"k", "d"}
    assert v["ma"][v["i"]] == pytest.approx(x["ma"])


def test_fail_25_atr_and_touch_cap(store):
    D = _D()
    D["h"][15] = 101.6; D["l"][12] = 98.8; D["h"][20] = 102.2   # melawan 1,2 ATR dulu lalu 2 ATR: v4.29 tetap respect (batas gagal 2,5 ATR)
    o = M.outcome(D, 10, 1, 200)
    assert M.FAIL_ATR == 2.5 and o["resp"] and o["lv"] == 2
    D = M.load(store, "BTCUSDT", "1h")
    ma = M.ma_of(D["c"], "ema", 100)
    up, dn = M.touches(D, ma)
    i, k = np.flatnonzero(up), np.flatnonzero(dn)
    assert (np.abs(D["l"][i] - ma[i]) <= 0.3 * D["a"][i] + 1e-9).all()        # ekor cuma menyentuh: tidak menembus > 0,3 ATR
    assert (np.abs(D["h"][k] - ma[k]) <= 0.3 * D["a"][k] + 1e-9).all()


def test_ma_auto_scan(store, monkeypatch, tmp_path):
    """Periode MA otomatis 13..993 tiap 10: pasangan terbaik = skor tertinggi (>= 30 sinyal), lalu detail memakai MA itu;
    hasil 1 pasangan di scan = hasil mode biasa dengan MA & periode yang sama."""
    from backend import results_store
    monkeypatch.setattr(results_store, "BASE", str(tmp_path))
    assert M.MA_AUTO[0] == 13 and M.MA_AUTO[1] == 23 and M.MA_AUTO[-1] == 993 and len(M.MA_AUTO) == 99
    syms = M.history_symbols(store, "15m", 3)
    R = M.run(store, "15m", "ema", 0, "rsi", "list", syms, workers=1)
    S = R["scan"]
    assert R["ma_auto"] and R["ma_len"] == S["best"]["m"] and S["n_combo"] > 0
    oks = [r for r in S["top"] if r["ok"]]
    assert oks and S["best"]["score"] == max(r["score"] for r in oks)
    row = next(r for r in R["rows"] if r["p"] == S["best"]["p"])
    assert row["n"] == S["best"]["n"] and row["score"] == pytest.approx(S["best"]["score"])     # scan = mode biasa
