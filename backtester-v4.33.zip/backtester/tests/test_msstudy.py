"""Tes 📐 Analisa Market Structure: label swing, tren BOS / CHoCH, tabel peluang, koreksi, jalan via API."""
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend import msstudy as M  # noqa: E402
from backend.data import DataStore  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("msdata")
    make(str(d), days=120)
    return DataStore(str(d))


def test_label_runs_and_hazard():
    # swing high: HH HH HH LH HH LH  -> deret HH: 3, 1
    seq = [(0, 10, "H", None), (2, 11, "H", "HH"), (4, 12, "H", "HH"), (6, 13, "H", "HH"), (8, 12.5, "H", "LH"),
           (10, 14, "H", "HH"), (12, 13, "H", "LH")]
    assert M.label_runs(seq)["HH"] == [3, 1]
    hz = M._hazard([1] * 10 + [3] * 10)
    k1 = next(r for r in hz if r["k"] == 1)
    assert k1["reach"] == 20 and k1["stop"] == 10 and k1["pct_stop"] == 50


def _zigzag(points, step=4):
    """Harga zigzag melewati titik-titik (naik turun linear) untuk tes tren."""
    out = []
    for a, b in zip(points, points[1:]):
        out += list(np.linspace(a, b, step, endpoint=False))
    out.append(points[-1])
    return np.array(out, float)


def test_trend_bos_and_choch():
    # turun (LH / LL) -> berbalik naik: tembus LH 170 (CHoCH naik) -> BOS tembus 175 & 185 -> turun tembus low dilindungi (CHoCH turun)
    pts = [200, 180, 190, 170, 180, 160, 170, 150, 165, 158, 175, 168, 185, 178, 195, 180, 170, 175, 160, 165, 150, 155, 140]
    c = _zigzag(pts, 8)
    h, l = c + 0.2, c - 0.2
    TR = M.trends(h, l, c, 3)
    up = [t for t in TR if t["dir"] == 1]
    assert len(up) == 1 and len(up[0]["bos"]) == 2
    assert c[up[0]["start"]] > 170 and up[0]["end"] > up[0]["bos"][-1][0]
    segs = M._segments(up[0], h, l, np.ones(len(c)))
    assert [s_["ends_bos"] for s_ in segs] == [True, True, False]       # 2 koreksi berakhir BOS, terakhir berbalik (CHoCH)
    assert all(s_["corr_bars"] > 0 and 0 < s_["depth_fib"] for s_ in segs)


def test_run_summary(store):
    r = M.run(store, ["SAMPLEUSDT"], {"tf": "15m", "n": 8000, "swing": "kecil"})
    assert r["n_trends"] > 5 and set(r["by"]) == {"naik", "turun"}
    for g in r["by"].values():
        if g["n"]:
            assert 0 <= g["valid_pct"] <= 100 and g["hazard"][0]["k"] == 0
            if g["corr"]["bars"]:
                assert g["corr"]["bars"]["p25"] <= g["corr"]["bars"]["med"] <= g["corr"]["bars"]["p75"]
    assert r["runs"]["HH"]["hazard"][0]["k"] == 1
    big = M.run(store, ["SAMPLEUSDT"], {"tf": "15m", "n": 8000, "swing": "besar"})
    assert big["n_trends"] < r["n_trends"]                             # swing besar = struktur lebih makro, tren lebih sedikit
    assert r["examples"] and r["examples"][0]["swings"]


def test_params():
    q = M._params({"tf": "1h", "n": 10, "swing": "aneh"})
    assert q["n"] == 500 and q["swing"] == "kecil"
    with pytest.raises(ValueError):
        M._params({"tf": "7m"})
