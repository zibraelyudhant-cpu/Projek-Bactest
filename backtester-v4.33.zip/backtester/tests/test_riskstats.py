"""Kalah beruntun terpanjang & drawdown terdalam (R), urut waktu."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from backend.riskstats import risk_seq  # noqa: E402


def test_risk_seq():
    # +3, -1, -1, -1, +3, -1  -> kalah beruntun 3x; puncak 3 -> 0 (DD 3), naik ke 3 lagi -> 2
    r = risk_seq([3, -1, -1, -1, 3, -1])
    assert r == {"max_loss_streak": 3, "max_dd": 3.0, "n_seq": 6}
    assert risk_seq([])["max_loss_streak"] == 0 and risk_seq([None, 1])["n_seq"] == 1
    assert risk_seq([-1, -1])["max_dd"] == 2.0                   # rugi dari awal = drawdown dari 0
    assert risk_seq([-0.4, 2])["max_loss_streak"] == 1           # waktu habis yang rugi dihitung kalah
