"""Tes 🧠 Penemu Strategi v4 (pola market structure): label swing, tanpa intip masa depan, aturan isi limit & hasil,
hitungan gabungan = contoh trade."""
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend import stratlab as SL  # noqa: E402
from backend.data import DataStore  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("sldata")
    make(str(d), days=120)
    return DataStore(str(d))


def _arr(store, tf="15m"):
    return SL._load(store, "SAMPLEUSDT", SL._params({"tf": tf}))


def test_params():
    q = SL._params({"tf": "15m", "rrs": "3, 2, 99"})
    assert q["rrs"] == [2.0, 3.0, 10.0]
    with pytest.raises(ValueError):
        SL._params({"tf": "7m"})
    with pytest.raises(ValueError):
        SL._params({"rrs": "dua"})


def test_swing_labels():
    # high 10 -> low 5 -> high 12 (HH) -> low 7 (HL) -> high 12.05 (sama = double top) -> low 6.5 sweep (close 7.2 di atas 7)
    seq = [7, 7.5, 8, 9, 10, 9, 8, 7, 6, 5, 6, 7, 8, 9, 12, 11, 10, 9, 8, 7, 8, 9, 10, 12.05, 11, 10, 9, 8, 7.5, 6.5, 7.6, 8, 9, 10]
    h = np.array(seq, float)
    l = h.copy()
    c = h.copy()
    c[29] = 7.2                                                     # candle sweep: ekor 6.5, close 7.2 > low sebelumnya 7
    a = np.full(len(h), 1.0)
    labs = [x[3] for x in SL.swing_events(h, l, c, a)[-1][1]]
    assert labs[-4:] == ["HH", "HL", "EH", "XL"] and labs[1] is None      # swing pertama tiap jenis belum punya pembanding


def test_no_lookahead(store):
    t, o, h, l, c, v = _arr(store)
    q = SL._params({"tf": "15m", "rrs": "2, 3"})
    full = SL.occurrences(t, o, h, l, c, v, q)
    k = len(c) - 1500
    cut = SL.occurrences(t[:k], o[:k], h[:k], l[:k], c[:k], v[:k], q)
    key = lambda x: (x["s"], x["len"], x["key"], x["d"], x["entry"], x["sl"], round(x["e"], 8), x["fill"],  # noqa: E731
                     None if x["res"] is None else tuple((round(a, 8), b, cc) for a, b, cc in x["res"]))
    B = {key(x) for x in cut}
    done = [x for x in full if x["res"] is not None and x["fill"] + SL.HOLD < k - 1]
    assert done and all(key(x) in B for x in done)                  # kejadian yang sudah selesai sebelum potongan = sama persis


def test_outcome_rules():
    n = 260
    h = np.full(n, 101.0); l = np.full(n, 99.0); c = np.full(n, 100.0)   # noqa: E702
    # LONG entry 100, SL 98, TP 1:2 = 104. Candle 5 menyentuh 104 -> menang
    h2 = h.copy(); h2[5] = 104.5
    assert SL._outcome(0, 2, 100.0, 98.0, [2.0], h2, l, c, True)[0][:2] == (2.0, 1)
    # TP & SL di candle yang sama = kalah
    l3 = l.copy(); l3[5] = 97.0
    assert SL._outcome(0, 2, 100.0, 98.0, [2.0], h2, l3, c, True)[0][:2] == (-1.0, -1)
    # limit: candle terisi ikut dicek SL-nya (kena SL di candle yang sama dengan terisi = kalah)
    l4 = l.copy(); l4[2] = 97.0
    assert SL._outcome(0, 2, 100.0, 98.0, [2.0], h2, l4, c, False)[0][:2] == (-1.0, -1)
    # belum kena sampai HOLD = waktu habis, R dari close
    assert SL._outcome(0, 2, 100.0, 98.0, [2.0], h, l, c, True)[0][1] == 0
    # limit batal kalau harga lebih dulu membuat high baru (di atas ujung leg)
    hh = h.copy(); hh[3] = 106.0; ll = l.copy(); ll[6] = 95.0
    assert SL._fill(0, 1, 96.0, 105.0, hh, ll, "fib0.5") is None
    assert SL._fill(0, 1, 96.0, 107.0, hh, ll, "fib0.5") == 6


def test_run_matches_trades(store):
    r = SL.run(store, ["SAMPLEUSDT"], {"tf": "15m", "rrs": "2"})
    assert r["v"] == 5 and r["rows"]
    for row in r["rows"][:3]:
        pat = {k: row[k] for k in ("len", "key", "dir", "entry", "sl", "rr")}
        tr = SL.pattern_trades(store, "SAMPLEUSDT", r["params"], pat, limit=100000)["trades"]
        fit = [x for x in tr if not x["test"] and x["filled"]]
        assert len(fit) == row["n"]
        assert abs(100 * sum(x["result"] == "TP" for x in fit) / len(fit) - row["wr"]) < 1e-9
        assert all(x["swings"] and len(x["swings"]) == row["len"] for x in tr)
        for x in tr:
            if row["dir"] == 0:
                assert x["sl"] < x["entry"] < x["tp"]
            else:
                assert x["tp"] < x["entry"] < x["sl"]
