"""Tes PIN akses & endpoint alamat LAN."""
import importlib
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def load_app(monkeypatch, tmp_path, pin):
    from tools.make_sample_data import make
    make(str(tmp_path), days=20)
    monkeypatch.setenv("DATA_DIR", str(tmp_path))
    monkeypatch.setenv("ACCESS_PIN", pin)
    monkeypatch.setenv("LAN_MODE", "1")
    import backend.app as a
    importlib.reload(a)
    from fastapi.testclient import TestClient
    return TestClient(a.app)


def test_pin_required_for_other_devices(monkeypatch, tmp_path):
    c = load_app(monkeypatch, tmp_path, "2580")      # TestClient = perangkat lain (bukan 127.0.0.1)
    r = c.get("/")
    assert r.status_code == 401 and "PIN" in r.text
    assert c.get("/api/symbols").status_code == 401
    assert c.get("/?pin=salah").status_code == 401
    r = c.get("/?pin=2580", follow_redirects=False)
    assert r.status_code in (302, 307) and "pin=" in r.headers.get("set-cookie", "")
    c.cookies.set("pin", "2580")
    assert c.get("/api/symbols").status_code == 200
    with c.websocket_connect("/ws/replay") as ws:
        ws.send_json({"cmd": "start", "symbol": "SAMPLEUSDT", "start": 1735689600000 + 5 * 86400000})
        assert ws.receive_json()["type"] == "init"


def test_no_pin_and_lan_endpoint(monkeypatch, tmp_path):
    c = load_app(monkeypatch, tmp_path, "")
    assert c.get("/").status_code == 200
    r = c.get("/api/lan").json()
    assert r["lan_mode"] is True and r["pin"] is False
    assert all(u["url"].startswith("http://") for u in r["urls"])
