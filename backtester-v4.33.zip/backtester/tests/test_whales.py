"""Tes pelacak whale terhadap server tiruan Binance."""
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

from backend.screener import Client  # noqa: E402
from backend.whales import Whales, walk_impact  # noqa: E402
from fake_binance import serve  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def wh(tmp_path_factory):
    d = tmp_path_factory.mktemp("fxw")
    for i, sym in enumerate(["AAAUSDT", "BBBUSDT", "CCCUSDT"]):
        make(str(d), symbol=sym, days=20, seed=i)
    srv = serve(str(d))
    yield Whales(Client(f"http://127.0.0.1:{srv.server_address[1]}"))
    srv.shutdown()


def test_walk_impact():
    asks = [(100.0, 10.0), (101.0, 10.0), (102.0, 10.0)]          # 1000 + 1010 + 1020 USDT
    assert walk_impact(asks, 500) == 0.0                           # habis di level pertama
    assert walk_impact(asks, 1500) == pytest.approx(1.0)           # sampai 101
    assert walk_impact(asks, 2500) == pytest.approx(2.0)           # sampai 102


def test_whale_scan(wh):
    seen = []
    res = wh.scan(n_coins=3, top=5, min_usdt=100_000, progress=lambda k, n, s, e: seen.append(k))
    assert res["scanned"] == 3 and seen == [1, 2, 3]
    walls, trades = res["walls"], res["trades"]
    # tiap koin punya 1 tembok BUY (150 x 2000 USDT) & 1 tembok SELL (90 x 2000) & 1 transaksi BUY 250 rb USDT
    assert len(walls) == 5 and len(trades) == 3
    assert {w["side"] for w in walls} == {"BUY", "SELL"} and all(w["usdt"] >= 100_000 for w in walls)
    assert all(t["side"] == "BUY" and t["usdt"] == pytest.approx(250_000, rel=1e-3) for t in trades)
    assert all(w["impact_pct"] > 0 for w in walls) and all(t["impact_pct"] > 0 for t in trades)
    # urut dari dampak terbesar
    assert [w["impact_pct"] for w in walls] == sorted((w["impact_pct"] for w in walls), reverse=True)
    for w in walls:
        assert (w["side"] == "BUY") == (w["dist_pct"] < 0)          # tembok beli di bawah harga, jual di atas
    assert {c["symbol"] for c in res["coins"]} == {"AAAUSDT", "BBBUSDT", "CCCUSDT"}
    # filter dampak minimal & jumlah daftar
    res2 = wh.scan(n_coins=3, top=2, min_usdt=100_000, min_impact=99)
    assert res2["walls"] == [] and res2["trades"] == []
    assert len(wh.scan(n_coins=3, top=2, min_usdt=100_000)["walls"]) == 2


def test_whale_single_coin(wh):
    from backend.whales import analyse_coin, usdt_to_move
    steps = []
    r = analyse_coin(wh.c, "aaausdt", top=5, min_usdt=100_000, progress=lambda k, n, s, e: steps.append(k))
    assert r["symbol"] == "AAAUSDT" and steps == [1, 2, 3, 4]
    assert r["near_support"]["side"] == "BUY" and r["near_support"]["price"] < r["mid"]
    assert r["near_resist"]["side"] == "SELL" and r["near_resist"]["price"] > r["mid"]
    assert r["trade_buy"] == pytest.approx(250_000, rel=1e-3) and r["trade_sell"] == 0
    assert len(r["heat"]) == 40 and sum(h["bid"] for h in r["heat"]) > 0 and sum(h["ask"] for h in r["heat"]) > 0
    for p in ("0.5", "1", "2"):
        assert r["move"][p]["up"] > 0 and r["move"][p]["down"] > 0
    assert r["move"]["2"]["up"] >= r["move"]["1"]["up"]                 # makin jauh makin mahal
    assert any("BELI" in x for x in r["lines"])
    # USDT untuk menggerakkan harga: dihitung dari order book
    asks = [(100.0, 10.0), (100.5, 10.0), (101.5, 10.0)]
    assert usdt_to_move(asks, 100.0, 1) == pytest.approx(1000 + 1005)


def test_whale_plan_sl_tp_and_bounce(wh):
    """Rencana: kekuatan pasar 100%, SL di balik tembok whale, TP di depan tembok lawan, pantulan dari tembok."""
    from backend.whales import analyse_coin
    r = analyse_coin(wh.c, "BBBUSDT", top=5, min_usdt=100_000)
    p = r["plan"]
    assert p is not None and abs(p["bull"] + p["bear"] + p["side"] - 100) < 1e-6
    assert p["regime"] in ("BULLISH", "BEARISH", "SIDEWAYS") and 0 <= p["side"] <= 100
    L, S = p["plans"]["long"], p["plans"]["short"]
    assert L["sl"] < L["entry"] < L["tp1"] <= L["tp2"]
    assert S["sl"] > S["entry"] > S["tp1"] >= S["tp2"]
    if p["strong_support"]:
        assert L["sl"] < p["strong_support"]["price"]                     # SL di balik tembok BELI
    assert p["pred"]["move_1d"] > 0 and p["pred"]["move_4h"] > 0
    for t in p["touch"]:
        assert (t["side"] == "BUY") == (t["target"] > t["price"])          # tembok BELI -> memantul naik
        assert t["hours"] is not None and t["hours"] >= 0


def test_wick_backtest_and_spoof_tracking():
    import numpy as np

    from backend.whales import _WALL_HIST, track_walls, wick_backtest
    # swing low di 100, lalu ekor candle menembus ke 99.5 dan close balik di atas 100 (gocekan),
    # kemudian swing low 98 ditembus dan close tetap di bawah (tembus beneran)
    h, l, c = [], [], []
    def bar(lo, hi, cl):
        l.append(lo); h.append(hi); c.append(cl)
    for v in (104, 103, 102, 101, 100.5):
        bar(v - 0.5, v + 0.5, v)
    bar(100, 101, 100.6)                                   # swing low 100
    for v in (101.5, 102, 102.5, 103, 102, 101):
        bar(v - 0.5, v + 0.5, v)
    bar(99.5, 101, 100.8)                                  # sapu 100 -> close balik di atas = gocekan
    for v in (101.5, 101, 100, 99, 98.5):
        bar(v - 0.5, v + 0.5, v)
    bar(98, 99, 98.6)                                      # swing low 98
    for v in (99, 99.5, 99.2, 98.8):
        bar(v - 0.4, v + 0.4, v)
    for v in (97.5, 97, 96.5, 96, 95.5):                   # tembus 98 beneran, close tetap di bawah
        bar(v - 0.3, v + 0.3, v)
    h, l, c = np.array(h), np.array(l), np.array(c)
    a = np.full(len(c), 1.0)
    r = wick_backtest(h, l, c, a, swing=2)
    assert r["fake"] >= 1 and r["real"] >= 1 and r["p90"] is not None and r["p90"] > 0
    # tembok palsu: ada di scan 1, hilang di scan 2 saat harga mendekat
    _WALL_HIST.pop("TSTUSDT", None)
    w1 = [{"side": "BUY", "price": 99.0, "usdt": 500_000}, {"side": "SELL", "price": 103.0, "usdt": 400_000}]
    track_walls("TSTUSDT", 101.0, w1, now=1000.0)
    w2 = [{"side": "SELL", "price": 103.0, "usdt": 420_000}]
    res = track_walls("TSTUSDT", 99.6, w2, now=1030.0)    # harga turun mendekati 99, tembok BELI 99 hilang
    assert [v["price"] for v in res["vanished"]] == [99.0]
    assert w2[0]["seen"] == 2                               # tembok JUAL 103 bertahan 2 scan = lebih bisa dipercaya


def test_first_touch_backtest_and_check_entry(wh):
    import numpy as np

    from backend.whales import check_entry, first_touch_backtest
    # harga naik 1% per candle: LONG TP 2% kena di candle ke-2, SL 1% tidak pernah
    c = 100 * 1.01 ** np.arange(30)
    h, l, o = c * 1.001, c * 0.999, c
    r = first_touch_backtest(o, h, l, c, sl_pct=1, tp_pct=2, long=True, max_bars=10)
    assert r["wr"] == 100 and r["bars_med"] == 2
    r = first_touch_backtest(o, h, l, c, sl_pct=1, tp_pct=2, long=False, max_bars=10)
    assert r["wr"] == 0
    # cek entry lewat server tiruan: arah terbaca otomatis, peluang & verdict ada, posisi salah ditolak
    px = wh.c.get("/fapi/v1/ticker/24hr", symbol="CCCUSDT")["lastPrice"]
    p = float(px)
    res = check_entry(wh.c, "ccc", p, p * 0.98, p * 1.04, "running")
    assert res["side"] == "LONG" and res["rr"] == pytest.approx(2, rel=1e-6)
    assert res["verdict"] in ("PROFIT", "LOSE", "50:50") and 0 < res["prob"] < 100
    assert res["backtest_all"]["n"] > 0 and res["checks"]
    assert check_entry(wh.c, "CCCUSDT", p, p * 1.02, p * 0.96, "running")["side"] == "SHORT"
    with pytest.raises(ValueError):
        check_entry(wh.c, "CCCUSDT", p, p * 1.02, p * 1.04, "running")
    with pytest.raises(ValueError):
        check_entry(wh.c, "CCCUSDT", p, p * 0.98, p * 1.04, "otomatis")        # status wajib dipilih
    with pytest.raises(ValueError, match="SL"):
        check_entry(wh.c, "CCCUSDT", p, p * 0.98, p * 1.04, "running", side="SELL")   # SELL tapi SL di bawah
    assert check_entry(wh.c, "CCCUSDT", p, p * 1.02, p * 0.96, "running", side="SELL")["side"] == "SHORT"
    # belum kena entry: limit di bawah harga -> peluang terisi + saran entry/SL/TP
    pen = check_entry(wh.c, "CCCUSDT", p * 0.995, p * 0.975, p * 1.03, "pending")
    assert pen["state"]["order"] == "limit" and pen["state"]["fill"]["fill_pct"] is not None
    sg = pen["suggest"]
    assert sg
    for case in (pen, check_entry(wh.c, "CCCUSDT", p * 0.995, p * 0.975, p * 1.03, "pending", min_rr=3),
                 check_entry(wh.c, "CCCUSDT", p * 1.01, p * 1.03, p * 0.96, "pending", side="SELL")):
        g = case["suggest"]
        if g.get("none"):
            continue                                                       # punyamu sudah terbaik: boleh tanpa saran
        assert g["wr"] >= g["user_wr"] - 1e-9 and g["exp_r"] > g["user_exp"]   # saran HARUS lebih baik di keduanya
        assert g["rr"] >= g["min_rr"] - 1e-9
        if case["side"] == "LONG":
            assert g["sl"] < g["entry"] < g["tp"]
        else:
            assert g["tp"] < g["entry"] < g["sl"]
    # sudah berjalan & harga sudah lewat SL -> ditandai kena SL
    run = check_entry(wh.c, "CCCUSDT", p * 1.05, p * 1.01, p * 1.10, "running")
    assert run["state"]["done"] == "SL" and run["verdict"] == "LOSE"


def test_scan_setups_respects_rr(wh):
    from backend.whales import scan_setups
    steps = []
    r = scan_setups(wh.c, n_coins=3, rr=3.0, top=10, min_usdt=100_000, progress=lambda k, n, s, e: steps.append(k))
    assert r["scanned"] == 3 and steps == [1, 2, 3] and r["breakeven"]["3"] == pytest.approx(25)
    assert r["setups"]
    for s in r["setups"]:
        risk = abs(s["entry"] - s["sl"])
        assert abs(s["tp"] - s["entry"]) == pytest.approx(3 * risk, rel=1e-6)          # TP = RR user x risiko
        if s["side"] == "BUY":
            assert s["sl"] < s["entry"] < s["tp"]
        else:
            assert s["tp"] < s["entry"] < s["sl"]
        assert s["exp_r"] == pytest.approx(s["wr"] / 100 * 3 - (1 - s["wr"] / 100), rel=1e-6)
        assert len(s["candles"]) == 96 and all(len(c) == 5 and c[3] <= c[1] <= c[2] for c in s["candles"])   # kartu visual
        assert s["walls_vis"] and all(w["side"] in ("BUY", "SELL") for w in s["walls_vis"])
    key = [(not s["usable"], -s["score"]) for s in r["setups"]]          # yang layak dipasang di atas, lalu skor
    assert key == sorted(key)
    for s in r["setups"]:                                              # layak v4.33: untung + data cari & uji + gerak beda + WR wajar
        ok = (s["exp_r"] > 0 and s["exp_fit"] is not None and s["exp_fit"] > 0 and s["n_test"] >= 10 and s["exp_test"] > 0
              and s["n_moves"] >= 15 and not s["too_good"])
        assert s["usable"] == ok and (s["usable"] or s["why_not"])
        assert s["proven"] == (s["exp_test"] is not None and s["exp_test"] > 0 and s["n_test"] >= 10)
        assert s["fill_ok"] == (s["fill_pct"] is not None and s["fill_pct"] >= 70)
        assert s["n_fit"] + s["n_test"] == s["n"]
    assert r["n_usable"] == sum(1 for s in r["setups"] if s["usable"]) or len(r["setups"]) < r["n_shown"]
    only_buy = scan_setups(wh.c, n_coins=3, rr=2.0, sides=("BUY",), min_usdt=100_000)
    assert {s["side"] for s in only_buy["setups"]} == {"BUY"}


def test_first_touch_counts_unfinished_as_not_win():
    """Trade yang tidak kena TP maupun SL dalam batas waktu dihitung tidak menang (bukan dibuang)."""
    import numpy as np

    from backend.whales import first_touch_backtest
    c = np.full(300, 100.0)
    c[150:] = 103.0                                       # sekali naik 3%, sisanya datar
    h, l = c + 0.05, c - 0.05
    r = first_touch_backtest(c, h, l, c, sl_pct=5, tp_pct=2, long=True, max_bars=20)
    assert r["open"] > 0 and r["wins"] >= 1
    assert r["wr"] == pytest.approx(100 * r["wins"] / (r["wins"] + r["losses"] + r["open"]))
    assert r["wr"] < 20                                   # dulu (open dibuang) = 100%


def test_scan_setups_compare_rr_and_min_wr(wh):
    from backend.whales import scan_setups
    r = scan_setups(wh.c, n_coins=3, rr=[1, 1.5, 2, 3], top=20, min_usdt=100_000)
    assert r["rrs"] == [1, 1.5, 2, 3] and r["compare"]
    for g in r["compare"]:
        assert set(g["rr"]) <= {"1", "1.5", "2", "3"} and g["best_rr"] in g["rr"]
        assert g["rr"][g["best_rr"]]["score"] == max(v["score"] for v in g["rr"].values())
    # RR lebih kecil -> WR tidak lebih rendah (TP lebih dekat, SL sama)
    for g in r["compare"]:
        if "1" in g["rr"] and "3" in g["rr"]:
            assert g["rr"]["1"]["wr"] >= g["rr"]["3"]["wr"] - 1e-9
    f = scan_setups(wh.c, n_coins=3, rr=[1, 3], top=20, min_usdt=100_000, min_wr=50)
    assert all(s["wr"] >= 50 for s in f["setups"]) and f["n_shown"] <= f["n_all"]


def test_scan_setups_manual_symbols(wh):
    from backend.whales import scan_setups
    r = scan_setups(wh.c, rr=[2], min_usdt=100_000, symbols=["AAAUSDT", "ZZZNOPEUSDT"])
    assert r["scanned"] == 1 and r["n_errors"] == 1 and r["errors"][0].startswith("ZZZNOPEUSDT")
    assert {s["symbol"] for s in r["setups"]} <= {"AAAUSDT"}


def test_scan_setups_replaces_failed_coins(wh, monkeypatch):
    import backend.whales as W
    real = W.coin_setups
    tick = wh.c.get("/fapi/v1/ticker/24hr")
    top = max(tick, key=lambda t: float(t["quoteVolume"]))["symbol"]

    def flaky(c, sym, *a, **k):
        if sym == top:
            raise ValueError("data belum cukup")
        return real(c, sym, *a, **k)
    monkeypatch.setattr(W, "coin_setups", flaky)
    r = W.scan_setups(wh.c, n_coins=2, rr=[2], min_usdt=100_000)
    assert r["scanned"] == 2 and r["target"] == 2 and r["skipped"] == 1     # koin gagal diganti koin berikutnya
    assert top not in {s["symbol"] for s in r["setups"]}
    big = W.scan_setups(wh.c, n_coins=500, rr=[2], min_usdt=100_000)   # minta lebih dari yang ada -> semua koin
    assert big["target"] == big["available"] and big["scanned"] == big["available"] - 1


def test_whale_config_changes_results(wh, tmp_path, monkeypatch):
    import backend.whale_cfg as cfg
    from backend.whales import scan_setups
    monkeypatch.setattr(cfg, "PATH", str(tmp_path / "whale_config.json"))
    cfg.reset()
    base = scan_setups(wh.c, n_coins=3, rr=[2], top=50, min_usdt=100_000)
    assert base["setups"]
    # nilai di luar batas dibatasi, kunci asing dibuang, pilihan tak dikenal diabaikan
    v = cfg.save({"bt.suspicious_wr": 999, "ngawur": 1, "sl.cap_mode": "hapus", "walls.depth": "1000"})
    assert v["bt.suspicious_wr"] == 100 and "ngawur" not in v and v["sl.cap_mode"] == "tolak" and v["walls.depth"] == 1000   # default v4.33
    cfg.save({"bt.suspicious_wr": 50})
    r = scan_setups(wh.c, n_coins=3, rr=[2], top=50, min_usdt=100_000)
    assert all(s["too_good"] == (s["wr"] > 50) for s in r["setups"])
    # hanya entry market
    cfg.save({"entry.use_wall": "tidak", "entry.use_swing": "tidak"})
    r = scan_setups(wh.c, n_coins=3, rr=[2], top=50, min_usdt=100_000)
    assert r["setups"] and all(s["how"].startswith("market") for s in r["setups"])
    # SL maks super kecil + tolak -> tidak ada setup; potong -> SL tepat di batas
    cfg.save({"sl.max_pct": 0.5, "sl.cap_mode": "tolak"})
    assert scan_setups(wh.c, n_coins=3, rr=[2], top=50, min_usdt=100_000)["setups"] == []
    cfg.save({"sl.max_pct": 0.5, "sl.cap_mode": "potong"})
    r = scan_setups(wh.c, n_coins=3, rr=[2], top=50, min_usdt=100_000)
    assert r["setups"] and all(abs(s["sl"] / s["price"] - 1) <= 0.005 + 1e-9 for s in r["setups"])
    cfg.reset()
    assert cfg.get() == cfg.DEFAULTS


def test_scan_setups_partial_results(wh):
    from backend.whales import scan_setups
    seen = []

    def prog(k, n, s, e):
        pass
    prog.partial = lambda d: seen.append(d)
    r = scan_setups(wh.c, n_coins=3, rr=[2], top=50, min_usdt=100_000, progress=prog)
    assert seen and all(d["partial"] for d in seen) and not r["partial"]
    assert [d["scanned"] for d in seen] == sorted(d["scanned"] for d in seen)        # bertambah terus
    strip = lambda L: [{k: v for k, v in x.items() if k not in ("flow", "evidence")} for x in L]   # noqa: E731 - flow & kelas ditambah di akhir
    assert seen[-1]["n_all"] == r["n_all"] and strip(seen[-1]["setups"]) == strip(r["setups"])  # sementara terakhir = akhir
    assert all(not any(k.startswith("_") for k in x) for x in r["setups"])   # data internal tidak dikirim
    ev = [x["evidence"] for x in r["setups"] if x.get("evidence")]
    assert ev and all(e["n_items"] == 6 and e["agree"] + e["against"] <= 6 for e in ev)   # kelas A/B/C + Elliott
    assert all(e["grade"] in (None, "A", "B", "C") for e in ev) and "ev_model" in r


def test_setup_trades_match_scan(wh):
    """Contoh trade 🎯 Cari setup = entry yang sama persis dengan backtest saat scan (jumlah & WR)."""
    from backend.whales import scan_setups, setup_trades
    r = scan_setups(wh.c, n_coins=3, rr=2.0, top=10, min_usdt=100_000)
    assert r["setups"]
    for s in r["setups"][:4]:
        lim = {"dist_pct": abs(s["entry"] / s["price"] - 1) * 100, "down": s["entry"] < s["price"]} if s["bt_kind"] == "limit" else {}
        tr = setup_trades(wh.c, s["symbol"], s["side"], s["sl_pct"], s["tp_pct"], **lim)
        assert tr["n"] == s["n"] and tr["tf"] == s["bt_tf"]
        wins = sum(t["result"] == 1 for t in tr["trades"])
        assert len(tr["trades"]) == min(300, tr["n"])
        if tr["n"] <= 300:
            assert abs(100 * wins / tr["n"] - s["wr"]) < 1e-9
        for t in tr["trades"]:
            assert t["exit_time"] > t["time"]
            assert (t["sl"] < t["entry"] < t["tp"]) if s["side"] == "BUY" else (t["tp"] < t["entry"] < t["sl"])


def test_one_at_a_time():
    from backend.whales import _one_at_a_time
    det = [(0, -1, 3), (1, -1, 4), (2, 1, 6), (4, 1, 9), (7, -1, 8), (10, 1, 12)]   # (entry, hasil, keluar)
    assert _one_at_a_time(det, 2.0) == [-1.0, 1 * 2.0, 2.0]               # entry 0 (keluar 3) -> 4 (keluar 9) -> 10


def test_scan_setups_only_aligned(wh):
    """v4.32: hanya setup searah kondisi pasar — setup melawan / sideways disembunyikan & dihitung."""
    from backend.whales import scan_setups
    a = scan_setups(wh.c, n_coins=3, rr=[2.0, 3.0], top=20, min_usdt=100_000, flow=False)
    b = scan_setups(wh.c, n_coins=3, rr=[2.0, 3.0], top=20, min_usdt=100_000, flow=False, only_aligned=True)
    assert b["only_aligned"] and all(s["aligned"] for s in b["setups"])
    n_all = len(a["setups"]) if len(a["setups"]) < 20 else None
    if n_all is not None:
        assert len(b["setups"]) + b["n_against"] >= n_all and b["n_against"] == sum(1 for s in a["setups"] if not s["aligned"])


# ================================================================== v4.33: celah logika Whale A–E
def test_limit_backtest_starts_at_touch():
    """(D) Entry limit: trade baru dimulai saat harga menyentuh limit; tidak tersentuh = tidak ada trade;
    SL di candle terisi ikut dihitung; TP mulai candle berikutnya."""
    import numpy as np

    from backend.whales import limit_backtest
    n = 60
    c = np.full(n, 100.0)
    h, l = c + 0.1, c - 0.1
    l[12] = 98.9                                          # limit 99 (1% di bawah close 100) tersentuh di candle 12
    h[15] = 102.1                                         # TP = 99 x 1,02 = 100,98 tersentuh candle 15
    r = limit_backtest(c, h, l, c, 1.0, True, 1.0, 2.0, True, max_bars=20, fill_bars=5, detail=True)
    d = {i: (res, ex) for i, res, ex, *_ in r["detail"]}
    assert d[10] == (1, 15) and d[7] == (1, 15)          # sinyal 7..11 menunggu sentuhan di candle 12
    assert 13 not in d and 20 not in d                   # tidak tersentuh dalam 5 candle -> bukan trade
    assert r["n_signal"] > r["filled"] == r["n"]
    l[12] = 97.9                                          # ekor sampai di bawah SL (98,01) di candle terisi = kalah
    r2 = limit_backtest(c, h, l, c, 1.0, True, 1.0, 2.0, True, max_bars=20, fill_bars=5, detail=True)
    assert {i: res for i, res, *_ in r2["detail"]}[10] == -1


def test_usable_rules_and_flags(wh, tmp_path, monkeypatch):
    """(A, B, C, E) alasan tidak layak tertulis; aturan bisa dimatikan; tren campur & jenis backtest ditandai."""
    import backend.whale_cfg as cfg
    from backend.whales import scan_setups
    monkeypatch.setattr(cfg, "PATH", str(tmp_path / "whale_config.json"))
    cfg.reset()
    r = scan_setups(wh.c, n_coins=3, rr=[2, 3], top=50, min_usdt=100_000, flow=False)
    assert r["setups"]
    for s in r["setups"]:
        assert isinstance(s["n_moves"], int) and 0 < s["n_moves"] <= s["n"]
        assert s["bt_kind"] in ("market", "limit") and (s["bt_kind"] == "market") == s["how"].startswith("market")
        assert isinstance(s["trend_mixed"], bool) and s["t_scan"] > 0
        if not s["usable"]:
            assert s["why_not"]
    cfg.save({"setup.require_test": "tidak", "setup.min_moves": 1, "setup.reject_too_good": "tidak"})   # aturan lama
    old = scan_setups(wh.c, n_coins=3, rr=[2, 3], top=50, min_usdt=100_000, flow=False)
    assert all(s["usable"] == (s["exp_r"] > 0) for s in old["setups"])
    assert old["n_usable"] >= r["n_usable"]
    cfg.save({"bt.suspicious_wr": 50})
    sus = scan_setups(wh.c, n_coins=3, rr=[2], top=50, min_usdt=100_000, flow=False)
    assert all(not s["usable"] for s in sus["setups"] if s["too_good"])
    cfg.reset()
