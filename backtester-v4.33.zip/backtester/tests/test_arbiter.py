"""🧭 Penentu Arah: jawaban ±2 ATR, faktor tanpa mengintip masa depan, model & ambang (70/30), jumlah sinyal tetap, flow, endpoint."""
import contextlib
import io
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from backend import arbiter as AR  # noqa: E402
from backend.data import DataStore  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("arb")
    with contextlib.redirect_stdout(io.StringIO()):
        for i, s_ in enumerate(("BTCUSDT", "AAAUSDT", "BBBUSDT", "CCCUSDT")):
            make(str(d), symbol=s_, days=150, seed=i + 1)
    return DataStore(str(d))


def _D(n=300):
    t = np.arange(n, dtype=np.int64) * 3_600_000
    c = np.full(n, 100.0)
    return {"t": t, "o": c.copy(), "h": c + 0.1, "l": c - 0.1, "c": c.copy(), "v": np.ones(n), "a": np.full(n, 1.0)}


def test_first_move_rules():
    D = _D()
    D["h"][15] = 102.5                                        # +2 ATR duluan
    D["l"][20] = 97.0
    y, xo, rl, rs = AR.first_move(D, 10, 120)
    assert (y, xo) == (1, 5) and rl == 2.0 and rs == -1.0     # LONG RR 1:2 kena TP (102), SHORT kena SL (101)
    D = _D(); D["l"][12] = 97.5
    assert AR.first_move(D, 10, 120)[0] == -1
    D = _D()
    assert AR.first_move(D, 10, 120)[0] == 0                   # tidak bergerak
    D = _D(); D["h"][14] = 103; D["l"][14] = 97
    assert AR.first_move(D, 10, 120)[0] == 0                   # dua-duanya di candle yang sama: tidak jelas
    assert AR.first_move(_D(), 250, 120) is None               # masa depan belum cukup


def test_features_no_lookahead(store):
    """Faktor di candle s tidak berubah kalau data sesudah s diubah."""
    from backend import slbt as SB
    D = SB.load(store, "AAAUSDT", "15m")
    btc = SB.load(store, "BTCUSDT", "15m")
    F1 = AR.base_feats(D, "15m", btc)
    s = len(D["c"]) // 2
    D2 = {k: (v.copy() if hasattr(v, "copy") else v) for k, v in D.items()}
    for k in ("o", "h", "l", "c"):
        D2[k][s + 1:] *= 1.3
    D2["v"][s + 1:] *= 5
    D2["a"] = SB._atr(D2["h"], D2["l"], D2["c"], 14)
    F2 = AR.base_feats(D2, "15m", btc)
    for k in AR.FK[1:]:
        a, b = F1[k][s - 50:s + 1], F2[k][s - 50:s + 1]
        assert np.allclose(np.nan_to_num(a), np.nan_to_num(b)), k


def test_rows_signed():
    F = {k: np.zeros(5) for k in AR.FK[1:]}
    F["htf4"][2] = 1.0; F["adx"][2] = 0.6
    X = AR.rows_of(F, [(2, 1), (2, -1)])
    j, ja, jd = AR.FK.index("htf4"), AR.FK.index("adx"), AR.FK.index("dir")
    assert X[0, j] == 1 and X[1, j] == -1                      # faktor berarah: + = mendukung arah sinyal
    assert X[0, ja] == X[1, ja] == pytest.approx(0.6)          # faktor tak berarah tidak dikali arah
    assert X[0, jd] == 1 and X[1, jd] == -1


def test_model_learns_flip_and_keeps_count():
    """Data buatan: kalau tren 4H melawan sinyal, arah asli salah 80% -> model membalik, jumlah sinyal tetap, terbukti di uji."""
    rng = np.random.default_rng(0)
    n = 4000
    X = rng.normal(size=(n, AR.NF)).astype(np.float32)
    d = rng.choice([-1, 1], n)
    X[:, AR.FK.index("dir")] = d
    against = rng.random(n) < 0.4
    X[:, AR.FK.index("htf4")] = np.where(against, -1, 1)
    p_right = np.where(against, 0.2, 0.6)
    right = rng.random(n) < p_right
    y = np.where(right, d, -d)
    M = np.zeros((n, 9))
    M[:, 0] = np.arange(n); M[:, 1] = d; M[:, 2] = y; M[:, 4] = np.where(y == 1, 2, -1); M[:, 5] = np.where(y == -1, 2, -1)
    M[:, 6] = np.arange(n) >= int(n * 0.7)
    out, p, flip = AR.train_eval(X, M, list(AR.GROUPS))
    assert out["thr"] is not None and out["thr"] >= AR.MIN_THR
    res = AR.summarise(M, p, flip, out)
    assert res["all"]["n"] == n                                # jumlah sinyal tidak berkurang
    assert res["test"]["arb"] > res["test"]["orig"] + 10 and res["proven"]
    assert flip[against].mean() > 0.8 and flip[~against].mean() < 0.2
    imp = AR.importance(X, M, list(AR.GROUPS), res["test"]["arb"])
    assert imp[0]["g"] == "tren" and imp[0]["drop"] > 5


def test_no_edge_not_proven():
    rng = np.random.default_rng(1)
    n = 3000
    X = rng.normal(size=(n, AR.NF)).astype(np.float32)
    d = rng.choice([-1, 1], n)
    X[:, 0] = d
    y = np.where(rng.random(n) < 0.5, d, -d)
    M = np.zeros((n, 9)); M[:, 0] = np.arange(n); M[:, 1] = d; M[:, 2] = y; M[:, 6] = np.arange(n) >= 2100
    out, p, flip = AR.train_eval(X, M, list(AR.GROUPS))
    res = AR.summarise(M, p, flip, out)
    assert not res["proven"]                                   # acak: tidak boleh "terbukti"


def test_run_all_sources_and_cache(store, tmp_path, monkeypatch):
    import backend.results_store as RS
    monkeypatch.setattr(RS, "BASE", str(tmp_path))
    syms = AR.history_symbols(store, "15m", 4)
    parts = []
    r = AR.run(store, "15m", "sweep", syms, push=parts.append, workers=1)
    assert r["n"] > 200 and r["coins"] and "test" in r and len(r["examples"]) > 0
    assert {p_["phase"] for p_ in parts} >= {"sinyal", "model", "faktor"}
    assert r["test"]["n"] + r["train"]["n"] == r["n"]
    x = r["examples"][0]
    assert x["used"] in (1, -1) and (x["used"] == -x["d"]) == x["flip"]
    assert r["uni"] and r["imp"]
    r2 = AR.run(store, "15m", "sweep", syms, workers=1)
    assert r2 is r                                             # cache
    for st in ("whale", "ms", "maa"):
        rr = AR.run(store, "15m", st, syms, workers=1)
        assert rr["n_sig"] >= 0 and ("test" in rr or rr.get("error"))


def test_flow_with_fake_binance(store, tmp_path, monkeypatch):
    import backend.results_store as RS
    from backend.screener import Client
    from fake_binance import serve
    monkeypatch.setattr(RS, "BASE", str(tmp_path))
    srv = serve(store.data_dir)
    try:
        c = Client(f"http://127.0.0.1:{srv.server_address[1]}")
        syms = AR.history_symbols(store, "15m", 4)
        r = AR.run(store, "15m", "sweep", syms, client=c, workers=1)
        assert r["use_flow"] and r["flow_coins"] == 4 and r["flow_rows"] > 0
        assert any(u["g"] == "flow" for u in r["uni"])
    finally:
        srv.shutdown()


def test_flow_unreachable_skips_fast(store, tmp_path, monkeypatch):
    import backend.results_store as RS
    monkeypatch.setattr(RS, "BASE", str(tmp_path))

    class Bad:
        calls = 0

        def get(self, *a, **k):
            Bad.calls += 1
            raise RuntimeError("tidak bisa terhubung")
    syms = AR.history_symbols(store, "15m", 4)
    r = AR.run(store, "15m", "ms", syms, client=Bad(), workers=1)
    assert Bad.calls == 2 and not r["use_flow"] and "dilewati" in r["flow_err"][-1]


def test_endpoint(store, monkeypatch, tmp_path):
    import time
    from fastapi.testclient import TestClient
    import backend.app as APP
    import backend.results_store as RS
    monkeypatch.setattr(APP, "store", store)
    monkeypatch.setattr(RS, "BASE", str(tmp_path))
    cl = TestClient(APP.app)
    assert cl.post("/api/arb/run", json={"strat": "xx"}).status_code == 400
    assert cl.post("/api/arb/run", json={"groups": ["zzz"]}).status_code == 400
    j = cl.post("/api/arb/run", json={"strat": "sweep", "tf": "15m", "hist": 4, "groups": ["tren", "mom", "order", "waktu"]}).json()
    for _ in range(300):
        st = cl.get(f"/api/screener/job/{j['id']}").json()
        if st["status"] != "running":
            break
        time.sleep(0.3)
    assert st["status"] == "done", st.get("error")
    R = st["result"]
    assert R["saved_id"] and not R["use_flow"]
    x = R["examples"][0]
    c = cl.get(f"/api/arb/candles?sym={x['sym']}&tf=15m&t={x['t']}&after=60").json()
    assert c["candles"][c["i"]][0] == x["t"]
