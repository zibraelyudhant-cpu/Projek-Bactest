"""Server tiruan API Binance Futures (format respons sama dengan aslinya) untuk tes screener tanpa internet.

Pakai: python tests/fake_binance.py <folder_npz> [port]
lalu jalankan aplikasi dengan BINANCE_FAPI_URL=http://127.0.0.1:<port>
"""
import json
import os
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.data import DataStore, aggregate  # noqa: E402
from backend.screener import INTERVAL_MS  # noqa: E402


def _taker_buy(b):
    """Volume beli agresif tiruan: candle hijau cenderung didominasi pembeli (tetap / bisa dihitung ulang)."""
    import numpy as np
    rng = np.random.default_rng(7)
    body = (b.c - b.o) / np.maximum(b.h - b.l, 1e-12)
    frac = np.clip(0.5 + 0.2 * body + rng.normal(0, 0.05, len(b.c)), 0.05, 0.95)
    return b.v * frac


def _flow_rows(path, sym, b, ts):
    """OI, rasio long/short top trader, funding tiruan (format sama dengan Binance)."""
    import numpy as np
    rng = np.random.default_rng(sum(map(ord, sym)) + len(path))
    n = len(b.c)
    if path.endswith("openInterestHist"):
        oi = 1e6 * np.exp(np.cumsum(rng.normal(0, 0.01, n) + 0.3 * np.r_[0, np.diff(np.log(b.c))]))
        return [{"symbol": sym, "sumOpenInterest": f"{v:.3f}", "sumOpenInterestValue": f"{v * c:.3f}", "timestamp": int(t)}
                for v, c, t in zip(oi, b.c, ts)]
    if path.endswith("topLongShortPositionRatio"):
        r = np.clip(1.2 + np.cumsum(rng.normal(0, 0.02, n)) * 0.2, 0.3, 3.0)
        return [{"symbol": sym, "longShortRatio": f"{v:.4f}", "longAccount": f"{v / (1 + v):.4f}",
                 "shortAccount": f"{1 / (1 + v):.4f}", "timestamp": int(t)} for v, t in zip(r, ts)]
    f = rng.normal(0.0001, 0.0002, n)
    return [{"symbol": sym, "fundingRate": f"{v:.8f}", "fundingTime": int(t), "markPrice": f"{c}"} for v, t, c in zip(f, ts, b.c)]


def make_handler(store):
    syms = store.symbols()

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def send(self, obj, code=200):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("X-MBX-USED-WEIGHT-1M", "10")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            u = urllib.parse.urlparse(self.path)
            if u.path == "/fapi/v1/depth" and os.environ.get("FAKE_BN_DELAY"):   # tes: perlambat supaya progres terlihat
                time.sleep(float(os.environ["FAKE_BN_DELAY"]))
            q = dict(urllib.parse.parse_qsl(u.query))
            if u.path == "/fapi/v1/ping":
                return self.send({})
            if u.path == "/fapi/v1/exchangeInfo":
                s = [{"symbol": x, "contractType": "PERPETUAL", "quoteAsset": "USDT", "status": "TRADING"} for x in syms]
                s += [{"symbol": "DEADUSDT", "contractType": "PERPETUAL", "quoteAsset": "USDT", "status": "SETTLING"},
                      {"symbol": "BTCUSDT_261225", "contractType": "CURRENT_QUARTER", "quoteAsset": "USDT", "status": "TRADING"}]
                return self.send({"symbols": s})
            if u.path == "/fapi/v1/ticker/24hr":
                out = []
                for x in syms:
                    b = store.get(x, "1h")
                    c0, c1 = b.c[-25], b.c[-1]
                    out.append({"symbol": x, "lastPrice": str(c1), "priceChangePercent": f"{100 * (c1 / c0 - 1):.3f}",
                                "quoteVolume": str(float((b.v[-24:] * b.c[-24:]).sum()))})
                if "symbol" in q:                                   # satu koin: objek, bukan list (seperti Binance)
                    one = [o for o in out if o["symbol"] == q["symbol"]]
                    return self.send(one[0]) if one else self.send({"code": -1121, "msg": "Invalid symbol."}, 400)
                return self.send(out)
            if u.path == "/fapi/v1/klines":
                x, iv, lim = q["symbol"], q["interval"], int(q.get("limit", 500))
                if x not in syms:
                    return self.send({"code": -1121, "msg": "Invalid symbol."}, 400)
                ms = INTERVAL_MS[iv]
                b = aggregate(store.get(x, store.base_tf(x)), ms)
                tb = _taker_buy(b)                                  # volume beli agresif (kolom 9 Binance)
                rows = [[int(t), f"{o}", f"{h}", f"{lo}", f"{c}", f"{v}", int(t) + ms - 1, "0", 1, f"{q}", "0", "0"]
                        for t, o, h, lo, c, v, q in zip(b.t[-lim:], b.o[-lim:], b.h[-lim:], b.l[-lim:], b.c[-lim:], b.v[-lim:], tb[-lim:])]
                return self.send(rows)
            if u.path in ("/futures/data/openInterestHist", "/futures/data/topLongShortPositionRatio", "/fapi/v1/fundingRate"):
                x = q["symbol"]
                if x not in syms:
                    return self.send({"code": -1121, "msg": "Invalid symbol."}, 400)
                fund = u.path == "/fapi/v1/fundingRate"
                ms = 8 * 3_600_000 if fund else INTERVAL_MS[q["period"]]
                b = aggregate(store.get(x, store.base_tf(x)), ms)
                ts = (b.t + ms).astype("int64")                     # nilai diketahui saat periode selesai
                rows = _flow_rows(u.path, x, b, ts)
                end = int(q.get("endTime", 10**15))
                start = int(q.get("startTime", 0))
                lim = min(int(q.get("limit", 100 if fund else 30)), 1000 if fund else 500)
                key = "fundingTime" if fund else "timestamp"
                rows = [r for r in rows if start <= r[key] <= end][-lim:]
                return self.send(rows)
            if u.path in ("/fapi/v1/depth", "/fapi/v1/aggTrades"):
                import random
                x = q["symbol"]
                if x not in syms:
                    return self.send({"code": -1121, "msg": "Invalid symbol."}, 400)
                px = float(store.get(x, "1h").c[-1])
                rnd = random.Random(sum(map(ord, x)))           # data tetap per koin (tes bisa dihitung ulang)
                if u.path == "/fapi/v1/depth":
                    lim = int(q.get("limit", 500))
                    unit = 2000 / px                                # +- 2000 USDT per level
                    bids = [[f"{px * (1 - 0.0005 * (i + 1)):.6f}", f"{unit * rnd.uniform(0.5, 1.5):.4f}"] for i in range(lim)]
                    asks = [[f"{px * (1 + 0.0005 * (i + 1)):.6f}", f"{unit * rnd.uniform(0.5, 1.5):.4f}"] for i in range(lim)]
                    w = rnd.randint(3, 15)                          # satu tembok besar per sisi
                    bids[w][1] = f"{unit * 150:.4f}"
                    asks[w + 2][1] = f"{unit * 90:.4f}"
                    return self.send({"lastUpdateId": 1, "E": 0, "T": 0, "bids": bids, "asks": asks})
                lim = int(q.get("limit", 500))
                t0 = int(store.get(x, "1h").t[-1])
                rows = [{"a": i, "p": f"{px * rnd.uniform(0.999, 1.001):.6f}", "q": f"{rnd.uniform(5, 500) / px:.4f}",
                         "f": i, "l": i, "T": t0 + i * 1000, "m": rnd.random() < 0.5} for i in range(lim)]
                rows[lim // 2]["q"] = f"{250000 / px:.4f}"         # satu transaksi whale
                rows[lim // 2]["m"] = False                         # pembeli agresif = BUY
                return self.send(rows)
            self.send({"code": -1, "msg": "not found"}, 404)

    return H


def serve(data_dir, port=0):
    srv = ThreadingHTTPServer(("127.0.0.1", port), make_handler(DataStore(data_dir, cache_size=200)))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


if __name__ == "__main__":
    s = serve(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 8790)
    print("fake binance di port", s.server_address[1], flush=True)
    threading.Event().wait()
