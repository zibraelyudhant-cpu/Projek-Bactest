"""🧩 Chart Pattern Screener & 🔄 Find Reversal: deteksi pola, break tanpa intip masa depan, cermin naik/turun, syarat
layak seperti Whale, sinyal valid / menunggu, endpoint scan."""
import contextlib
import io
import os
import sys
import time

import numpy as np
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from backend import chartpat as CP  # noqa: E402
from backend.data import DataStore  # noqa: E402
from backend.indicators import atr  # noqa: E402
from tools.make_sample_data import make  # noqa: E402


@pytest.fixture(scope="module")
def store(tmp_path_factory):
    d = tmp_path_factory.mktemp("cpat")
    with contextlib.redirect_stdout(io.StringIO()):
        for i, s_ in enumerate(("BTCUSDT", "AAAUSDT", "BBBUSDT", "CCCUSDT")):
            make(str(d), symbol=s_, days=200, seed=i + 1)
    return DataStore(str(d))


def _arr(store, sym="BTCUSDT", tf="1h"):
    b = store.get(sym, tf)
    return np.asarray(b.t, np.int64), *(np.asarray(z, float) for z in (b.o, b.h, b.l, b.c))


def test_window_bars():                       # permintaan user: TF < 1H = 24 jam, TF >= 1H = 2 hari
    assert CP.window_bars("5m") == 288 and CP.window_bars("15m") == 96 and CP.window_bars("30m") == 48
    assert CP.window_bars("1h") == 48 and CP.window_bars("4h") == 12 and CP.window_bars("1d") == 2


def test_swings_alternate(store):
    t, o, h, l, c = _arr(store)
    sw = CP.swings(h, l, 3)
    assert len(sw) > 50 and all(a[2] != b[2] for a, b in zip(sw, sw[1:])) and all(x[3] == x[0] + 3 for x in sw)


def test_double_top_synthetic():
    """Double top buatan: 2 puncak sama + close tembus lembah -> VALID tepat di candle tembus, TP measured = lembah - tinggi."""
    path = [100, 110, 120, 130, 120, 112, 120, 130, 120, 108, 100, 95]
    c = np.concatenate([np.linspace(path[i], path[i + 1], 6, endpoint=False) for i in range(len(path) - 1)] + [np.full(30, 95.0)])
    c = np.concatenate([np.full(40, 100.0) + np.sin(np.arange(40)) * 0.3, c])
    h, l = c + 0.4, c - 0.4
    a = atr(h, l, c, 14)
    F = [x for x in CP.formations(h, l, c, a, 3) if x["code"] == "dt" and x["dir"] == -1]
    assert F
    x = F[-1]
    b, st = CP.find_break(x, h, l, c)
    neck = x["trig"][1]
    assert st == "break" and c[b] < neck and all(c[x["f"]:b] >= neck) and b >= x["f"]
    tp = CP.tp_price(x, b, float(c[b]), float(c[b]) + 3.0, -1, "measured")
    assert tp == pytest.approx(neck - x["height"])


def test_mirror_symmetry(store):
    """Versi naik = versi turun pada harga cermin (kecuali Cup & Handle yang hanya versi naik)."""
    t, o, h, l, c = _arr(store)
    a = atr(h, l, c, 14)
    A = {(x["code"], x["dir"], x["f"]) for x in CP.formations(h, l, c, a, 3) if x["code"] != "cup"}
    a2 = atr(-l, -h, -c, 14)
    B = {(x["code"], -x["dir"], x["f"]) for x in CP.formations(-l, -h, -c, a2, 3) if x["code"] != "cup"}
    assert A and A == B


def test_no_lookahead(store):
    """Pola & break di candle N tidak berubah kalau data sesudah N dibuang."""
    t, o, h, l, c = _arr(store)
    N = len(c) - 300
    a = atr(h, l, c, 14)
    full = {(x["code"], x["dir"], x["f"]): x for x in CP.formations(h, l, c, a, 3)}
    cut = {(x["code"], x["dir"], x["f"]): x for x in CP.formations(h[:N], l[:N], c[:N], a[:N], 3)}
    n_chk = 0
    for k_, x in cut.items():
        assert k_ in full
        b_full, _ = CP.find_break(full[k_], h, l, c)
        if b_full is not None and b_full < N:
            b_cut, _ = CP.find_break(x, h[:N], l[:N], c[:N])
            assert b_cut == b_full
            n_chk += 1
    assert n_chk > 5


def test_stats_like_whale(store):
    syms = CP.history_symbols(store, "1h", 4)
    L = CP.learn(store, "1h", syms)
    assert L["n_rows"] > 0 and L["stats"]
    for k_, v in L["stats"].items():
        assert v["ok"] == (v["n"] >= CP._min_trades() and v["exp_r"] > 0)          # layak = Whale: sampel & rata-rata untung
        if k_[3] in ("rr2", "rr3"):
            rr = 2 if k_[3] == "rr2" else 3
            w = v["wr"] / 100
            assert v["exp_r"] == pytest.approx(w * rr - (1 - w))                   # rumus Whale WR x RR - kalah
        assert len(v["examples"]) <= CP.N_EXAMPLES
        for x in v["examples"]:
            d = k_[1]
            assert (x["sl"] < x["e"] < x["tp"]) if d == 1 else (x["tp"] < x["e"] < x["sl"])
    assert CP.learn(store, "1h", syms) is L                                         # cache memori


def test_current_signals(store):
    syms = CP.history_symbols(store, "1h", 4)
    ST = CP.learn(store, "1h", syms)["stats"]
    seen = 0
    for s_ in syms:
        t, o, h, l, c = _arr(store, s_)
        for r in CP.current(s_, t, o, h, l, c, "1h", ST, fresh=60):
            seen += 1
            d = r["dir"]
            assert r["status"] in ("valid", "wait") and r["trend"]["tf"] == "1h" and r["trend"]["dir"] in (1, -1)   # info tren jurnal
            assert (r["price_sl"] < r["price_entry"] < r["price_tp"]) if d == 1 else (r["price_tp"] < r["price_entry"] < r["price_sl"])
            if r["status"] == "wait":
                assert r["why"] and r["break_time"] is None
                if r["code"] != "rv":
                    assert (c[-1] <= r["trigger"]) if d == 1 else (c[-1] >= r["trigger"])      # belum tembus pemicu
            else:
                assert r["age"] <= 60
            cd = CP.card_data(t, o, h, l, c, r)
            assert len(cd["candles"]) == 120
    assert seen > 0


def test_api_scan(store, monkeypatch, tmp_path):
    monkeypatch.setenv("DATA_DIR", store.data_dir)
    import importlib

    import backend.app as app_mod
    importlib.reload(app_mod)
    app_mod.store = store
    from backend import results_store

    monkeypatch.setattr(results_store, "BASE", str(tmp_path))

    def no_net(*a, **k):
        raise ConnectionError("tanpa internet (tes)")
    monkeypatch.setattr(app_mod.whales.c, "get", no_net)
    from fastapi.testclient import TestClient
    client = TestClient(app_mod.app)
    assert client.post("/api/cpat/scan", json={"tf": "7m"}).status_code == 400
    for mode in ("pattern", "reversal"):
        r = client.post("/api/cpat/scan", json={"mode": mode, "tf": "1h", "coins": "btc, aaa, bbb, ccc", "hist": 4, "fresh": 80})
        assert r.status_code == 200
        for _ in range(600):
            st = client.get(f"/api/screener/job/{r.json()['id']}").json()
            if st["status"] != "running":
                break
            time.sleep(0.1)
        assert st["status"] == "done", st
        R = st["result"]
        assert R["mode"] == mode and R["scanned"] == 4 and R["learn"]["coins"]
        for x in R["rows"]:
            assert (x["code"] == "rv") == (mode == "reversal") and x["symbol"] in R["candles"]
