@echo off
REM Menjalankan Futures Replay. Biarkan jendela ini terbuka selama dipakai; tutup untuk berhenti.
cd /d "%~dp0"
set "DATA_DIR=D:\Data Candle Binance\all"
if exist "%~dp0config.bat" call "%~dp0config.bat"
REM numpy: 1 thread per proses, supaya proses paralel tidak menghabiskan RAM
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
echo Folder data : %DATA_DIR%
echo Alamat      : http://127.0.0.1:8000
echo (Tutup jendela ini untuk menghentikan server)
echo.
start "" http://127.0.0.1:8000
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
echo.
echo Server berhenti. Kalau ada error di atas, lihat README bagian "Kalau ada masalah".
pause
