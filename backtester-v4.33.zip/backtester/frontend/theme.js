// 🎨 Tema aplikasi: 18 tema bawaan + tema kustom (warna, huruf, sudut, efek latar, animasi pindah menu & tombol).
// Hanya tampilan — fitur & logika tidak berubah. Pilihan disimpan di browser ini (localStorage).
(function () {
  const C = (bg, panel, panel2, border, border2, text, muted, accent, accentBg, onAccent, up, down, warn) =>
    ({ bg, panel, panel2, border, border2, text, muted, accent, accentBg, onAccent, up, down, warn });
  const THEMES = [
    { id: "asli", name: "Asli", desc: "Tampilan bawaan aplikasi", c: C("#0f1218", "#161a22", "#1c212b", "#262c38", "#3a4252", "#d5dae3", "#7d8696", "#3b82f6", "#1e3a8a", "#ffffff", "#26a69a", "#ef5350", "#f0b90b"),
      fx: "ticker", tab: "fade", btn: "ripple", radius: 6 },
    { id: "neon", name: "Neon Cyber", desc: "Neon cyan–ungu, grid bergerak", c: C("#070b14", "#0d1426", "#111b33", "#1d2a4a", "#2c3f6b", "#e6f1ff", "#7f93b8", "#19e3ff", "#0c3a52", "#050912", "#2dffb0", "#ff3d7f", "#ffd23f"),
      font: "Inter", head: "Orbitron", fx: "grid", tab: "glitch", btn: "pulse", radius: 8, glow: "0 0 14px rgba(25,227,255,.5)" },
    { id: "aurora", name: "Aurora Glass", desc: "Kaca buram di atas aurora", c: C("#0b1020", "rgba(255,255,255,.06)", "rgba(255,255,255,.09)", "rgba(255,255,255,.14)", "rgba(255,255,255,.28)", "#f2f4ff", "#a9b0d6", "#8f9bff", "rgba(143,155,255,.22)", "#0b1020", "#5ff0c0", "#ff7a9a", "#ffd27a"),
      font: "Inter", head: "Space Grotesk", fx: "aurora", tab: "blur", btn: "ripple", radius: 12, glass: true },
    { id: "amber", name: "Terminal Amber", desc: "Terminal klasik, layar CRT", c: C("#0a0805", "#100c06", "#161007", "#3a2a10", "#5a4218", "#ffcf7a", "#b0874a", "#ffb000", "#3a2500", "#0a0805", "#7dff7a", "#ff6b4a", "#ffd36a"),
      font: "IBM Plex Mono", head: "IBM Plex Mono", fx: "scan", tab: "wipe", btn: "flash", radius: 2 },
    { id: "gold", name: "Midnight Gold", desc: "Navy premium, aksen emas", c: C("#0c1220", "#121b30", "#17223b", "#253150", "#3a4a72", "#eef1f7", "#95a0bd", "#e8c27a", "#3a2f17", "#1a1408", "#4fd6a4", "#f07d7d", "#e8c27a"),
      font: "Inter", head: "Playfair Display", fx: "golddust", tab: "flip", btn: "shine", radius: 10 },
    { id: "light", name: "Clean Light", desc: "Terang & bersih untuk siang", c: C("#f6f7fb", "#ffffff", "#f1f4f9", "#dfe4ee", "#c5ccda", "#18202e", "#66728a", "#2563eb", "#dbe7ff", "#ffffff", "#0e9f6e", "#e02d4b", "#c78a00"),
      font: "Inter", head: "Space Grotesk", fx: "bokeh", tab: "rise", btn: "bounce", radius: 9, light: true },
    { id: "cyberpunk", name: "Cyberpunk", desc: "Kuning–magenta, glitch kota malam", c: C("#0d0221", "#1a0b35", "#241047", "#3d1d6b", "#6b2fa8", "#f5f0ff", "#a58fd1", "#fcee0a", "#3d3a00", "#0d0221", "#00f0ff", "#ff2a6d", "#fcee0a"),
      font: "Inter", head: "Orbitron", fx: "rain", tab: "rgbsplit", btn: "pulse", radius: 3, glow: "0 0 14px rgba(255,42,109,.55)", gridColor: "rgba(255,42,109,.10)" },
    { id: "ai", name: "Artificial Intelligence", desc: "Jaringan saraf bercahaya", c: C("#050816", "#0b1230", "#101a40", "#1c2a5c", "#2e4290", "#e8eeff", "#8ea0d8", "#7c5cff", "#24185c", "#ffffff", "#22d3ee", "#fb7185", "#fbbf24"),
      font: "Inter", head: "Space Grotesk", fx: "neural", tab: "zoom", btn: "spark", radius: 10, glow: "0 0 16px rgba(124,92,255,.55)" },
    { id: "matrix", name: "Matrix Code", desc: "Hujan kode hijau", c: C("#000500", "#031007", "#06180b", "#0f3a18", "#1d6b2e", "#b9ffc9", "#4fbf6a", "#00ff66", "#00331a", "#001a08", "#00ff66", "#ff4d4d", "#d4ff00"),
      font: "JetBrains Mono", head: "JetBrains Mono", fx: "matrix", tab: "decode", btn: "flash", radius: 3, glow: "0 0 10px rgba(0,255,102,.5)" },
    { id: "synth", name: "Synthwave", desc: "Matahari senja & grid 80-an", c: C("#1a0b2e", "#241141", "#2e1650", "#4a2a78", "#7a46b8", "#fde7ff", "#c49bd8", "#ff4fd8", "#4a1046", "#1a0b2e", "#36f9f6", "#fe4450", "#fede5d"),
      font: "Inter", head: "Orbitron", fx: "synth", tab: "drive", btn: "shine", radius: 8, glow: "0 0 14px rgba(255,79,216,.5)" },
    { id: "ocean", name: "Ocean Deep", desc: "Biru laut dalam, gelembung", c: C("#021b2b", "#06283d", "#0a3350", "#12466a", "#1d6694", "#dff6ff", "#7fb3cc", "#1ec8e0", "#0b4458", "#021b2b", "#2ee6a6", "#ff6b81", "#ffd166"),
      font: "Inter", head: "Space Grotesk", fx: "bubbles", tab: "sway", btn: "ripple", radius: 10 },
    { id: "purple", name: "Ungu Malam", desc: "Ungu gelap, bintang berkelip", c: C("#1e1f29", "#282a36", "#313342", "#44475a", "#6272a4", "#f8f8f2", "#a4a8c4", "#bd93f9", "#3c2f5c", "#1e1f29", "#50fa7b", "#ff5555", "#f1fa8c"),
      font: "Inter", head: "Space Grotesk", fx: "stars", tab: "swing", btn: "ripple", radius: 8 },
    { id: "nord", name: "Nord Frost", desc: "Biru-abu dingin, salju turun", c: C("#242933", "#2e3440", "#3b4252", "#434c5e", "#5e6a82", "#eceff4", "#a3adc2", "#88c0d0", "#2f4a55", "#1d232d", "#a3be8c", "#bf616a", "#ebcb8b"),
      font: "Inter", head: "Space Grotesk", fx: "snow", tab: "drop", btn: "ripple", radius: 8 },
    { id: "sakura", name: "Sakura", desc: "Terang merah muda, kelopak jatuh", c: C("#fff5f8", "#ffffff", "#fdeef3", "#f3d3df", "#e8b4c6", "#3a2430", "#9a6f80", "#e84f8a", "#fde0ea", "#ffffff", "#2f9e72", "#d6336c", "#c98a00"),
      font: "Inter", head: "Playfair Display", fx: "petals", tab: "spinin", btn: "bounce", radius: 12, light: true },
    { id: "forest", name: "Hutan Malam", desc: "Hijau tua, kunang-kunang", c: C("#0d1510", "#132018", "#192a1f", "#24392b", "#3a5a44", "#e3f1e6", "#8fb59a", "#4ade80", "#1a4a2c", "#062010", "#4ade80", "#f87171", "#facc15"),
      font: "Inter", head: "Space Grotesk", fx: "fireflies", tab: "curtain", btn: "ripple", radius: 10 },
    { id: "solar", name: "Solar Flare", desc: "Merah-oranye, bara api naik", c: C("#140806", "#1f0d09", "#29120c", "#4a1f14", "#7a3420", "#ffe9e0", "#d39a85", "#ff6a2b", "#5a2410", "#140806", "#3ddc97", "#ff3b3b", "#ffc145"),
      font: "Inter", head: "Orbitron", fx: "embers", tab: "flare", btn: "pulse", radius: 6, glow: "0 0 14px rgba(255,106,43,.5)" },
    { id: "contrast", name: "Kontras Tinggi", desc: "Hitam–putih–kuning, paling jelas dibaca", c: C("#000000", "#0a0a0a", "#141414", "#5a5a5a", "#9a9a9a", "#ffffff", "#d0d0d0", "#ffe600", "#3a3500", "#000000", "#00e676", "#ff5252", "#ffe600"),
      font: "", head: "", fx: "ekg", tab: "cut", btn: "flash", radius: 4 },
    { id: "paper", name: "Kertas Sepia", desc: "Terang hangat seperti kertas", c: C("#f4ecd8", "#fbf6ea", "#efe5cf", "#dccfae", "#c7b68d", "#3b2f1e", "#7d6a4b", "#9c5b1a", "#f0dcc0", "#ffffff", "#2f7d4f", "#b23a2a", "#a87500"),
      font: "", head: "Playfair Display", fx: "ink", tab: "unfold", btn: "bounce", radius: 6, light: true },
    { id: "anime", name: "Anime Pastel", desc: "Pastel ceria, kilau bintang", c: C("#fdf6ff", "#ffffff", "#f6eefe", "#ead9f7", "#d4b8ec", "#33264a", "#86709f", "#a259ff", "#efe0ff", "#ffffff", "#19b394", "#ff5c8a", "#f5a623"),
      font: "Inter", head: "Space Grotesk", fx: "sparkles", tab: "pop", btn: "spark", radius: 14, light: true },
    { id: "animenight", name: "Anime Malam", desc: "Langit malam neon pink–biru, kilau bintang", c: C("#120b24", "#1b1236", "#231849", "#3a2a6b", "#5b43a3", "#fbefff", "#b9a6dc", "#ff6ec7", "#4a1a42", "#120b24", "#5ce1e6", "#ff5c8a", "#ffd166"),
      font: "Inter", head: "Space Grotesk", fx: "starfall", tab: "circle", btn: "spark", radius: 12, glow: "0 0 14px rgba(255,110,199,.5)" },
    { id: "hantu", name: "Hantu", desc: "Kabut dingin & hantu melayang", c: C("#0b0f0e", "#121817", "#18201f", "#26302e", "#3d4a47", "#dfe8e4", "#86958f", "#9fe8c9", "#1f3a31", "#0b0f0e", "#9fe8c9", "#e06c75", "#d9c27a"),
      font: "Inter", head: "Playfair Display", fx: "ghosts", tab: "ghost", btn: "ripple", radius: 8, glow: "0 0 18px rgba(159,232,201,.35)" },
    { id: "halloween", name: "Halloween", desc: "Oranye–ungu, kelelawar terbang", c: C("#120a16", "#1c1022", "#26152e", "#3e2348", "#64387a", "#fbe9ff", "#b897c4", "#ff7a1a", "#4a2410", "#120a16", "#9be15d", "#ff4d6d", "#ffb02e"),
      font: "Inter", head: "Orbitron", fx: "bats", tab: "flicker", btn: "flash", radius: 8, glow: "0 0 14px rgba(255,122,26,.45)" },
    { id: "galaxy", name: "Galaxy", desc: "Nebula ungu–biru & bintang", c: C("#05030f", "#0e0b22", "#151033", "#271f55", "#3f3485", "#ece9ff", "#9d97c9", "#6ea8ff", "#1c2b55", "#05030f", "#5eead4", "#f472b6", "#fde68a"),
      font: "Inter", head: "Orbitron", fx: "galaxy", tab: "warp", btn: "shine", radius: 10 },
  ];
  const FX = { none: "tanpa efek", grid: "grid bergerak", aurora: "aurora", scan: "garis layar CRT", stars: "bintang berkelip", matrix: "hujan kode", neural: "jaringan saraf (AI)",
    synth: "matahari & grid 80-an", bubbles: "gelembung", snow: "salju", petals: "kelopak bunga", fireflies: "kunang-kunang", embers: "bara api",
    sparkles: "kilau bintang (anime)", ghosts: "hantu melayang + kabut", bats: "kelelawar", galaxy: "nebula, bintang & meteor",
    ticker: "chart candle berjalan", golddust: "debu emas", bokeh: "cahaya bokeh lembut", rain: "hujan neon", starfall: "bintang jatuh", ink: "tetes tinta", ekg: "garis detak harga" };
  const TAB = { none: "tanpa animasi", fade: "pudar", glitch: "geser + glitch", blur: "muncul dari blur", wipe: "tersapu", flip: "terbuka 3D", rise: "naik halus", zoom: "zoom",
    rgbsplit: "pecah RGB (glitch)", decode: "piksel terurai", drive: "meluncur dari cakrawala", sway: "ayunan ombak", swing: "pintu berputar", drop: "jatuh memantul",
    spinin: "berputar lembut", curtain: "tirai terbuka", flare: "kilatan cahaya", cut: "potong + garis tegas", unfold: "kertas terbuka", pop: "meletup (anime)",
    circle: "lingkaran membesar", ghost: "muncul seperti hantu", flicker: "lilin berkedip", warp: "lompat warp" };
  const BTN = { none: "tanpa animasi", ripple: "riak air", pulse: "gelombang neon", flash: "kedip terbalik", shine: "kilau menyapu", bounce: "memantul", spark: "percikan bintang" };
  const FONTS = ["", "Inter", "Space Grotesk", "JetBrains Mono", "IBM Plex Mono", "Orbitron", "Playfair Display"];
  const KEYS = [["bg", "Latar"], ["panel", "Panel / kartu"], ["panel2", "Input & tombol"], ["border", "Garis"], ["border2", "Garis (hover)"], ["text", "Teks"], ["muted", "Teks redup"],
    ["accent", "Aksen (tombol utama)"], ["accentBg", "Aksen redup"], ["onAccent", "Teks di atas aksen"], ["up", "Naik / TP"], ["down", "Turun / SL"], ["warn", "Peringatan / emas"]];
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* abaikan */ } } };
  const root = document.documentElement;
  let cur = null;

  function all() { return THEMES.concat(LS.get("themeCustom", [])); }
  function find(id) { return all().find((t) => t.id === id) || THEMES[0]; }
  function fontStack(f, mono) { return f ? `"${f}", ${mono || /Mono/.test(f) ? "ui-monospace, Consolas, monospace" : "system-ui, \"Segoe UI\", sans-serif"}` : "system-ui, -apple-system, \"Segoe UI\", sans-serif"; }
  function loadFonts(t) {
    const fam = [...new Set([t.font, t.head].filter(Boolean))];
    if (!fam.length) return;
    const id = "tfont-" + fam.join("-").replace(/\W/g, "");
    if (document.getElementById(id)) return;
    const l = document.createElement("link");
    l.id = id; l.rel = "stylesheet";
    l.href = "https://fonts.googleapis.com/css2?" + fam.map((f) => "family=" + f.replace(/ /g, "+") + ":wght@400;500;600;700").join("&") + "&display=swap";
    document.head.appendChild(l);
  }
  function hexA(c, a) {                                           // warna aksen transparan (untuk glow default)
    const m = /^#([0-9a-f]{6})$/i.exec(c || "");
    if (!m) return c;
    const n = parseInt(m[1], 16);
    return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`;
  }
  function apply(t, save) {
    cur = t;
    const c = t.c;
    const map = { bg: "--bg", panel: "--panel", panel2: "--panel2", border: "--border", border2: "--border2", text: "--text", muted: "--muted", accent: "--accent",
      accentBg: "--accent-bg", onAccent: "--on-accent", up: "--up", down: "--down", warn: "--warn" };
    for (const k in map) root.style.setProperty(map[k], c[k]);
    root.style.setProperty("--radius", (t.radius != null ? t.radius : 6) + "px");
    root.style.setProperty("--font", fontStack(t.font));
    root.style.setProperty("--font-head", fontStack(t.head || t.font));
    root.style.setProperty("--glow", t.glow || "none");
    root.style.setProperty("--grid-color", t.gridColor || hexA(c.accent, 0.07));
    root.dataset.tab = anim() ? (t.tab || "fade") : "none";
    root.dataset.btnfx = anim() ? (t.btn || "ripple") : "none";
    root.dataset.glass = t.glass ? "1" : "";
    root.dataset.glow = t.glow ? "1" : "";
    root.dataset.light = t.light ? "1" : "";
    root.style.colorScheme = t.light ? "light" : "dark";
    loadFonts(t);
    if (document.body) startFx(fxOn() ? (t.fx || "none") : "none");
    if (save) LS.set("theme", t.id);
    if (panel) renderPanel();
  }
  const anim = () => LS.get("themeAnim", true) && !matchMedia("(prefers-reduced-motion: reduce)").matches;
  const fxOn = () => LS.get("themeFx", true);

  // ---------------------------------------------------------------- efek latar (CSS + canvas ringan, 30 fps, berhenti saat tab browser tidak aktif)
  let fxEl, cv, ctx, raf = 0, parts = [], kind = "none", last = 0, tk = 0, meteors = [];
  function startFx(k) {
    kind = k;
    if (!fxEl) {
      fxEl = document.createElement("div"); fxEl.id = "themeFx"; fxEl.setAttribute("aria-hidden", "true");
      cv = document.createElement("canvas"); cv.id = "themeFxCanvas"; cv.setAttribute("aria-hidden", "true");
      document.body.prepend(cv); document.body.prepend(fxEl);
      ctx = cv.getContext("2d");
      addEventListener("resize", size);
    }
    fxEl.dataset.fx = k;
    cancelAnimationFrame(raf);
    const canvasFx = ["stars", "matrix", "neural", "bubbles", "snow", "petals", "fireflies", "embers", "sparkles", "ghosts", "bats", "galaxy",
      "ticker", "golddust", "bokeh", "rain", "starfall", "ink", "ekg"].includes(k);
    cv.style.display = canvasFx ? "block" : "none";
    root.dataset.fx = k;
    if (!canvasFx) return;
    size(); seed(); raf = requestAnimationFrame(tick);
  }
  function size() { if (!cv) return; cv.width = innerWidth; cv.height = innerHeight; if (kind === "matrix") seed(); }
  function seed() {
    const W = cv.width, H = cv.height, r = Math.random;
    const n = { stars: 110, neural: 46, bubbles: 40, snow: 90, petals: 34, fireflies: 40, embers: 60, sparkles: 45, ghosts: 7, bats: 9, galaxy: 140,
      golddust: 70, bokeh: 22, rain: 120, starfall: 60, ink: 18, ticker: 0, ekg: 0 }[kind] || 0;
    parts = [];
    if (kind === "matrix") { parts = Array.from({ length: Math.ceil(W / 16) }, () => ({ y: r() * H, v: 2 + r() * 4 })); return; }
    if (kind === "ticker") { let p = 0; parts = Array.from({ length: Math.ceil(W / 14) + 2 }, () => { const o = p; p += (r() - 0.5) * 18; return { o, c: p, h: Math.max(o, p) + r() * 8, l: Math.min(o, p) - r() * 8 }; }); tk = 0; return; }
    if (kind === "ekg") { parts = []; tk = 0; return; }
    meteors = [];
    for (let i = 0; i < n; i++) parts.push({ x: r() * W, y: r() * H, vx: (r() - 0.5) * 0.4, vy: (r() - 0.5) * 0.4, s: 0.6 + r() * 2.2, p: r() * 6.28, rot: r() * 6.28 });
  }
  function tick(ts) {
    raf = requestAnimationFrame(tick);
    if (document.hidden || ts - last < 33) return;
    last = ts;
    const W = cv.width, H = cv.height, cs = getComputedStyle(root), acc = cs.getPropertyValue("--accent").trim(), up = cs.getPropertyValue("--up").trim();
    if (kind === "matrix") {
      ctx.fillStyle = "rgba(0,5,0,.12)"; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = acc; ctx.font = "14px monospace"; ctx.globalAlpha = 0.28;
      parts.forEach((p, i) => { ctx.fillText(String.fromCharCode(0x30A0 + Math.random() * 96), i * 16, p.y); p.y = p.y > H + Math.random() * 400 ? 0 : p.y + p.v * 4; });
      ctx.globalAlpha = 1; return;
    }
    ctx.clearRect(0, 0, W, H);
    if (kind === "ticker") {                                       // chart candle samar yang terus berjalan ke kiri
      tk += 0.5; const step = 14, off = tk % step, base = H * 0.62;
      if (tk >= step) { tk -= step; const L0 = parts[parts.length - 1], o = L0.c, c = o + (Math.random() - 0.5) * 18 - (o - 0) * 0.04;
        parts.shift(); parts.push({ o, c, h: Math.max(o, c) + Math.random() * 8, l: Math.min(o, c) - Math.random() * 8 }); }
      ctx.globalAlpha = 0.16;
      parts.forEach((q, i) => { const x = i * step - off, upc = q.c >= q.o; ctx.fillStyle = ctx.strokeStyle = upc ? up : cs.getPropertyValue("--down").trim();
        ctx.beginPath(); ctx.moveTo(x, base - q.h * 2); ctx.lineTo(x, base - q.l * 2); ctx.stroke(); ctx.fillRect(x - 4, base - Math.max(q.o, q.c) * 2, 8, Math.max(2, Math.abs(q.o - q.c) * 2)); });
      ctx.globalAlpha = 1; return;
    }
    if (kind === "ekg") {                                          // garis detak harga yang terus tergambar
      tk = (tk + 6) % (W + 200); const y0 = H * 0.55; ctx.globalAlpha = 0.35; ctx.strokeStyle = acc; ctx.lineWidth = 2; ctx.beginPath();
      for (let x = Math.max(0, tk - 420); x <= tk; x += 4) { const ph = (x % 220); const y = ph > 90 && ph < 130 ? y0 - Math.sin((ph - 90) / 40 * Math.PI) * (ph < 110 ? 60 : -30) : y0 + Math.sin(x / 15) * 2;
        x === Math.max(0, tk - 420) ? ctx.moveTo(x, y) : ctx.lineTo(x, y); }
      ctx.stroke(); ctx.lineWidth = 1; ctx.globalAlpha = 1; return;
    }
    if (kind === "galaxy" || kind === "starfall") {               // meteor / bintang jatuh
      if (Math.random() < (kind === "starfall" ? 0.06 : 0.02)) meteors.push({ x: Math.random() * W, y: -10, v: 6 + Math.random() * 6, l: 60 + Math.random() * 80 });
      meteors = meteors.filter((m) => m.y < H + 50);
      for (const m of meteors) { m.x -= m.v * 0.7; m.y += m.v; const g = ctx.createLinearGradient(m.x, m.y, m.x + m.l * 0.7, m.y - m.l); g.addColorStop(0, "rgba(255,255,255,.9)"); g.addColorStop(1, "rgba(255,255,255,0)");
        ctx.globalAlpha = 0.8; ctx.strokeStyle = g; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.x + m.l * 0.7, m.y - m.l); ctx.stroke(); }
      ctx.lineWidth = 1;
    }
    for (const p of parts) {
      p.p += 0.04;
      if (kind === "stars") { ctx.globalAlpha = 0.25 + 0.55 * Math.abs(Math.sin(p.p)); ctx.fillStyle = cur && cur.id === "gold" ? "#e8c27a" : "#ffffff"; ctx.fillRect(p.x, p.y, p.s, p.s); continue; }
      if (kind === "neural") {
        p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > W) p.vx *= -1; if (p.y < 0 || p.y > H) p.vy *= -1;
        ctx.globalAlpha = 0.8; ctx.fillStyle = acc; ctx.beginPath(); ctx.arc(p.x, p.y, p.s + 0.8, 0, 6.28); ctx.fill();
        for (const q of parts) { const d = Math.hypot(p.x - q.x, p.y - q.y); if (q !== p && d < 170) { ctx.globalAlpha = (1 - d / 170) * 0.35; ctx.strokeStyle = up; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke(); } }
        continue;
      }
      if (kind === "bubbles") { p.y -= 0.4 + p.s * 0.3; p.x += Math.sin(p.p) * 0.3; if (p.y < -10) { p.y = H + 10; p.x = Math.random() * W; }
        ctx.globalAlpha = 0.35; ctx.strokeStyle = acc; ctx.beginPath(); ctx.arc(p.x, p.y, p.s * 3, 0, 6.28); ctx.stroke(); continue; }
      if (kind === "snow") { p.y += 0.4 + p.s * 0.35; p.x += Math.sin(p.p) * 0.4; if (p.y > H + 5) { p.y = -5; p.x = Math.random() * W; }
        ctx.globalAlpha = 0.6; ctx.fillStyle = "#ffffff"; ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, 6.28); ctx.fill(); continue; }
      if (kind === "petals") { p.y += 0.5 + p.s * 0.25; p.x += Math.sin(p.p) * 0.8; p.rot += 0.02; if (p.y > H + 10) { p.y = -10; p.x = Math.random() * W; }
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.globalAlpha = 0.55; ctx.fillStyle = "#f7a1c0"; ctx.beginPath(); ctx.ellipse(0, 0, p.s * 3.2, p.s * 1.8, 0, 0, 6.28); ctx.fill(); ctx.restore(); continue; }
      if (kind === "fireflies") { p.x += p.vx * 2; p.y += p.vy * 2; if (p.x < 0 || p.x > W) p.vx *= -1; if (p.y < 0 || p.y > H) p.vy *= -1;
        const a = 0.2 + 0.7 * Math.abs(Math.sin(p.p)); ctx.globalAlpha = a; ctx.fillStyle = up; ctx.shadowColor = up; ctx.shadowBlur = 12; ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, 6.28); ctx.fill(); ctx.shadowBlur = 0; continue; }
      if (kind === "sparkles") {                                   // bintang 4 sudut berkilau (anime)
        p.y += 0.15; p.x += Math.sin(p.p * 0.5) * 0.2; if (p.y > H + 10) { p.y = -10; p.x = Math.random() * W; }
        const k2 = Math.abs(Math.sin(p.p)), r = p.s * 3 * k2 + 1;
        ctx.globalAlpha = 0.25 + 0.6 * k2; ctx.fillStyle = Math.sin(p.rot) > 0 ? acc : "#ffd1f0";
        ctx.beginPath(); ctx.moveTo(p.x, p.y - r); ctx.quadraticCurveTo(p.x, p.y, p.x + r, p.y); ctx.quadraticCurveTo(p.x, p.y, p.x, p.y + r);
        ctx.quadraticCurveTo(p.x, p.y, p.x - r, p.y); ctx.quadraticCurveTo(p.x, p.y, p.x, p.y - r); ctx.fill(); continue;
      }
      if (kind === "ghosts") {                                     // hantu melayang pelan, timbul tenggelam
        p.x += p.vx * 1.2; p.y += Math.sin(p.p * 0.6) * 0.35; if (p.x < -60) p.x = W + 60; if (p.x > W + 60) p.x = -60;
        const R = 14 + p.s * 7, a2 = 0.05 + 0.12 * Math.abs(Math.sin(p.p * 0.3));
        ctx.globalAlpha = a2; ctx.fillStyle = "#e8fff6"; ctx.beginPath(); ctx.arc(p.x, p.y, R, Math.PI, 0);
        for (let w = 0; w <= 4; w++) ctx.lineTo(p.x + R - (w * R) / 2, p.y + R * 1.3 + (w % 2 ? -6 : 0) + Math.sin(p.p + w) * 3);
        ctx.closePath(); ctx.fill(); ctx.globalAlpha = a2 * 2.2; ctx.fillStyle = "#0b0f0e";
        ctx.beginPath(); ctx.arc(p.x - R * 0.35, p.y - 2, R * 0.13, 0, 6.28); ctx.arc(p.x + R * 0.35, p.y - 2, R * 0.13, 0, 6.28); ctx.fill(); continue;
      }
      if (kind === "bats") {                                       // kelelawar mengepak
        p.x += 1.1 + p.s * 0.4; p.y += Math.sin(p.p) * 0.8; if (p.x > W + 30) { p.x = -30; p.y = Math.random() * H * 0.6; }
        const f = Math.sin(p.p * 6) * 6, z = 0.7 + p.s * 0.3;
        ctx.globalAlpha = 0.45; ctx.fillStyle = "#05020a"; ctx.strokeStyle = acc; ctx.lineWidth = 0.6;
        ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.quadraticCurveTo(p.x - 10 * z, p.y - 8 * z - f, p.x - 20 * z, p.y + f * 0.4); ctx.quadraticCurveTo(p.x - 10 * z, p.y - 2, p.x, p.y + 4 * z);
        ctx.quadraticCurveTo(p.x + 10 * z, p.y - 2, p.x + 20 * z, p.y + f * 0.4); ctx.quadraticCurveTo(p.x + 10 * z, p.y - 8 * z - f, p.x, p.y); ctx.fill(); ctx.stroke(); continue;
      }
      if (kind === "galaxy") { ctx.globalAlpha = 0.2 + 0.6 * Math.abs(Math.sin(p.p * 0.7)); ctx.fillStyle = p.s > 2.3 ? acc : "#ffffff"; ctx.fillRect(p.x, p.y, p.s * 0.8, p.s * 0.8); continue; }
      if (kind === "golddust") { p.x += p.vx; p.y -= 0.15 + p.s * 0.1; if (p.y < -5) { p.y = H + 5; p.x = Math.random() * W; }
        ctx.globalAlpha = 0.2 + 0.6 * Math.abs(Math.sin(p.p)); ctx.fillStyle = "#e8c27a"; ctx.shadowColor = "#e8c27a"; ctx.shadowBlur = 6; ctx.beginPath(); ctx.arc(p.x, p.y, p.s * 0.8, 0, 6.28); ctx.fill(); ctx.shadowBlur = 0; continue; }
      if (kind === "bokeh") { p.x += p.vx * 0.6; p.y += p.vy * 0.6; if (p.x < -80) p.x = W + 80; if (p.x > W + 80) p.x = -80; if (p.y < -80) p.y = H + 80; if (p.y > H + 80) p.y = -80;
        const R = 30 + p.s * 30, g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, R); g.addColorStop(0, acc); g.addColorStop(1, "rgba(255,255,255,0)");
        ctx.globalAlpha = 0.08 + 0.05 * Math.sin(p.p); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, R, 0, 6.28); ctx.fill(); continue; }
      if (kind === "rain") { p.y += 10 + p.s * 4; p.x -= 2; if (p.y > H) { p.y = -20; p.x = Math.random() * (W + 200); }
        ctx.globalAlpha = 0.35; ctx.strokeStyle = p.s > 1.8 ? acc : up; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + 3, p.y - 14 - p.s * 4); ctx.stroke(); continue; }
      if (kind === "starfall") { ctx.globalAlpha = 0.2 + 0.5 * Math.abs(Math.sin(p.p)); ctx.fillStyle = p.s > 2 ? acc : "#ffffff"; ctx.fillRect(p.x, p.y, p.s * 0.9, p.s * 0.9); continue; }
      if (kind === "ink") { p.y += 0.12; p.x += p.vx * 0.3; if (p.y > H + 40) { p.y = -40; p.x = Math.random() * W; }
        ctx.globalAlpha = 0.07 + 0.03 * Math.sin(p.p); ctx.fillStyle = cs.getPropertyValue("--text").trim(); const rr = 3 + p.s * 3;
        ctx.beginPath(); ctx.arc(p.x, p.y, rr, 0, 6.28); ctx.arc(p.x + rr * 1.3 * Math.cos(p.rot), p.y + rr * 1.3 * Math.sin(p.rot), rr * 0.35, 0, 6.28);
        ctx.arc(p.x - rr * 1.6 * Math.sin(p.rot), p.y + rr * 1.1 * Math.cos(p.rot), rr * 0.22, 0, 6.28); ctx.fill(); continue; }
      if (kind === "embers") { p.y -= 0.6 + p.s * 0.4; p.x += Math.sin(p.p) * 0.6; if (p.y < -10) { p.y = H + 10; p.x = Math.random() * W; }
        ctx.globalAlpha = 0.25 + 0.5 * Math.abs(Math.sin(p.p)); ctx.fillStyle = Math.sin(p.p * 3) > 0 ? acc : "#ffc145"; ctx.fillRect(p.x, p.y, p.s * 1.4, p.s * 1.4); }
    }
    ctx.globalAlpha = 1;
  }

  // ---------------------------------------------------------------- animasi pindah menu (setiap .tabpane yang jadi aktif) & tombol
  function enter(el) {
    if (!el || root.dataset.tab === "none") return;
    el.classList.remove("tp-enter"); void el.offsetWidth; el.classList.add("tp-enter");
    clearTimeout(el._tpT); el._tpT = setTimeout(() => el.classList.remove("tp-enter"), 700);
  }
  function watchPanes() {
    const mo = new MutationObserver((ms) => ms.forEach((m) => {
      const el = m.target, on = el.classList.contains("active") || (!el.classList.contains("hidden") && el.matches(".cp-pane, #scrFilterPane"));
      const was = (m.oldValue || "").split(" ");
      if (on && (el.matches(".tabpane") ? !was.includes("active") : was.includes("hidden"))) enter(el);
    }));
    document.querySelectorAll(".tabpane, .cp-pane, #scrFilterPane").forEach((el) => mo.observe(el, { attributes: true, attributeFilter: ["class"], attributeOldValue: true }));
  }
  document.addEventListener("pointerdown", (e) => {
    const b = e.target.closest("button");
    const fx = root.dataset.btnfx;
    if (!b || !fx || fx === "none" || b.disabled) return;
    const host = getComputedStyle(b).position === "static";              // tombol sementara jadi wadah efek, lalu dikembalikan
    if (host) b.classList.add("tfx-host");
    if (fx === "spark") {                                            // percikan bintang keluar dari titik klik
      for (let i = 0; i < 8; i++) { const d = document.createElement("span"); d.className = "tfx-spark"; d.textContent = "✦";
        d.style.left = e.clientX + "px"; d.style.top = e.clientY + "px"; d.style.setProperty("--dx", Math.cos(i / 8 * 6.28) * 38 + "px"); d.style.setProperty("--dy", Math.sin(i / 8 * 6.28) * 38 + "px");
        document.body.appendChild(d); setTimeout(() => d.remove(), 650); }
      b.classList.remove("tfx-bounce"); void b.offsetWidth; b.classList.add("tfx-bounce"); setTimeout(() => { b.classList.remove("tfx-bounce"); if (host) b.classList.remove("tfx-host"); }, 500);
      return;
    }
    if (fx === "ripple" || fx === "pulse") {
      const r = b.getBoundingClientRect(), d = document.createElement("span");
      d.className = "tfx-" + fx; d.style.left = e.clientX - r.left + "px"; d.style.top = e.clientY - r.top + "px";
      b.appendChild(d); setTimeout(() => { d.remove(); if (host) b.classList.remove("tfx-host"); }, 650);
    } else { b.classList.remove("tfx-" + fx); void b.offsetWidth; b.classList.add("tfx-" + fx); setTimeout(() => { b.classList.remove("tfx-" + fx); if (host) b.classList.remove("tfx-host"); }, 700); }
  }, true);

  // ---------------------------------------------------------------- panel 🎨 Tema
  let panel = null, editing = null;
  const esc = (s) => String(s).replace(/[&<>"]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[ch]);
  const toHex = (v) => { if (/^#[0-9a-f]{6}$/i.test(v)) return v; const m = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(v || ""); return m ? "#" + [m[1], m[2], m[3]].map((x) => (+x).toString(16).padStart(2, "0")).join("") : "#000000"; };
  function swatch(t) {
    const c = t.c;
    return `<button type="button" class="tsw${cur && cur.id === t.id ? " on" : ""}" data-tid="${esc(t.id)}" title="${esc(t.desc || "")}">
      <span class="tsw-prev" style="background:${c.bg};border-color:${c.border}"><i style="background:${c.panel};border-color:${c.border}"></i><b style="background:${c.accent}"></b><em style="background:${c.up}"></em><em style="background:${c.down}"></em></span>
      <span class="tsw-n">${esc(t.name)}${t.custom ? " ✏️" : ""}</span><small>${esc(t.desc || "kustom")}</small>
      <small class="tsw-fx">✨ ${esc(FX[t.fx] || "—")} · 🔀 ${esc(TAB[t.tab] || "—")} · 👆 ${esc(BTN[t.btn] || "—")}</small></button>`;
  }
  function renderPanel() {
    const L = all(), E = editing;
    panel.innerHTML = `<div class="tp-head"><b>🎨 Tema</b><span class="hint">${L.length} tema · tersimpan di browser ini</span><span style="flex:1"></span><button type="button" class="mini" data-act="close">✕ Tutup</button></div>
      <div class="tp-opts"><label class="chk"><input type="checkbox" data-opt="anim" ${LS.get("themeAnim", true) ? "checked" : ""}> Animasi menu &amp; tombol</label>
        <label class="chk"><input type="checkbox" data-opt="fx" ${fxOn() ? "checked" : ""}> Efek latar</label></div>
      <div class="tsw-grid">${L.map(swatch).join("")}</div>
      <div class="tp-custom"><div class="tp-head"><b>✏️ ${E ? (E.custom && E.id !== "__new" ? "Ubah tema kustom" : "Buat tema kustom") : "Tema kustom"}</b><span style="flex:1"></span>
        ${E ? "" : `<button type="button" class="primary mini" data-act="new">+ Buat dari tema sekarang</button>`}</div>
      ${E ? `<div class="tp-form">
          <label class="field"><span>Nama</span><input data-ed="name" value="${esc(E.name)}"></label>
          <div class="tp-colors">${KEYS.map(([k, lab]) => `<label class="tp-c"><input type="color" data-col="${k}" value="${toHex(E.c[k])}"><span>${lab}</span></label>`).join("")}</div>
          <div class="tp-sel">
            <label class="field"><span>Huruf teks</span><select data-ed="font">${FONTS.map((f) => `<option value="${f}" ${f === (E.font || "") ? "selected" : ""}>${f || "bawaan sistem"}</option>`).join("")}</select></label>
            <label class="field"><span>Huruf judul</span><select data-ed="head">${FONTS.map((f) => `<option value="${f}" ${f === (E.head || "") ? "selected" : ""}>${f || "sama dengan teks"}</option>`).join("")}</select></label>
            <label class="field"><span>Efek latar</span><select data-ed="fx">${Object.entries(FX).map(([k, v]) => `<option value="${k}" ${k === E.fx ? "selected" : ""}>${v}</option>`).join("")}</select></label>
            <label class="field"><span>Animasi pindah menu</span><select data-ed="tab">${Object.entries(TAB).map(([k, v]) => `<option value="${k}" ${k === E.tab ? "selected" : ""}>${v}</option>`).join("")}</select></label>
            <label class="field"><span>Animasi tombol</span><select data-ed="btn">${Object.entries(BTN).map(([k, v]) => `<option value="${k}" ${k === E.btn ? "selected" : ""}>${v}</option>`).join("")}</select></label>
            <label class="field"><span>Sudut membulat (${E.radius}px)</span><input type="range" min="0" max="16" data-ed="radius" value="${E.radius}"></label>
            <label class="chk"><input type="checkbox" data-ed="glowOn" ${E.glow ? "checked" : ""}> Cahaya (glow) di tombol aktif</label>
            <label class="chk"><input type="checkbox" data-ed="glass" ${E.glass ? "checked" : ""}> Panel kaca buram</label>
            <label class="chk"><input type="checkbox" data-ed="light" ${E.light ? "checked" : ""}> Tema terang</label>
          </div>
          <div class="tp-btns"><button type="button" class="primary" data-act="save">💾 Simpan tema</button><button type="button" data-act="cancel">Batal</button>
            ${E.custom && E.id !== "__new" ? `<button type="button" data-act="del">🗑️ Hapus tema ini</button>` : ""}<button type="button" data-act="export">📋 Salin kode tema</button></div>
        </div>` : `<p class="hint">Klik <b>+ Buat dari tema sekarang</b> untuk menyalin tema yang sedang dipakai lalu mengubah warna, huruf, sudut, efek latar dan animasinya. Klik ✏️ pada tema kustom untuk mengubahnya. Perubahan langsung terlihat (pratinjau).</p>
          <div class="tp-import"><input data-act-in="import" placeholder="tempel kode tema di sini lalu tekan Enter"></div>`}
      </div>`;
  }
  function openPanel() {
    if (!panel) {
      panel = document.createElement("div"); panel.id = "themePanel"; panel.className = "theme-panel"; panel.setAttribute("role", "dialog"); panel.setAttribute("aria-label", "Pilih tema");
      document.body.appendChild(panel);
      panel.addEventListener("click", onClick); panel.addEventListener("input", onInput); panel.addEventListener("change", onInput);
      panel.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.dataset.actIn === "import") importTheme(e.target.value); });
    }
    renderPanel(); panel.classList.add("open");
  }
  function closePanel() { if (panel) panel.classList.remove("open"); if (editing) { editing = null; apply(find(LS.get("theme", "asli")), false); } }
  function onClick(e) {
    const sw = e.target.closest(".tsw");
    if (sw && !editing) { const t = find(sw.dataset.tid); apply(t, true); if (t.custom && e.target.closest(".tsw-n")) { editing = JSON.parse(JSON.stringify(t)); renderPanel(); } return; }
    const a = e.target.closest("[data-act]");
    if (!a) return;
    const act = a.dataset.act;
    if (act === "close") return closePanel();
    if (act === "new") { editing = JSON.parse(JSON.stringify(cur)); editing.id = "__new"; editing.custom = true; editing.name = (cur.custom ? cur.name : cur.name + " (kustom)"); editing.desc = "kustom"; renderPanel(); return; }
    if (act === "cancel") { editing = null; apply(find(LS.get("theme", "asli")), false); return; }
    if (act === "save") {
      const L = LS.get("themeCustom", []);
      if (editing.id === "__new") editing.id = "c" + Date.now().toString(36);
      const i = L.findIndex((x) => x.id === editing.id);
      if (i >= 0) L[i] = editing; else L.push(editing);
      LS.set("themeCustom", L); const t = editing; editing = null; apply(t, true); return;
    }
    if (act === "del") { LS.set("themeCustom", LS.get("themeCustom", []).filter((x) => x.id !== editing.id)); editing = null; apply(THEMES[0], true); return; }
    if (act === "export") { const txt = JSON.stringify({ ...editing, id: undefined }); (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => alertMini("Kode tema disalin 📋"), () => prompt("Salin kode tema:", txt)); }
  }
  function onInput(e) {
    const el = e.target;
    if (el.dataset.opt) { LS.set(el.dataset.opt === "anim" ? "themeAnim" : "themeFx", el.checked); apply(editing || cur, false); return; }
    if (!editing) return;
    if (el.dataset.col) editing.c[el.dataset.col] = el.value;
    const k = el.dataset.ed;
    if (k === "name") editing.name = el.value;
    else if (k === "radius") { editing.radius = +el.value; el.previousElementSibling.textContent = `Sudut membulat (${el.value}px)`; }
    else if (k === "glowOn") editing.glow = el.checked ? `0 0 14px ${hexA(editing.c.accent, 0.5)}` : "";
    else if (k === "glass" || k === "light") editing[k] = el.checked;
    else if (k) editing[k] = el.value;
    const keep = panel.querySelector(".tp-custom").scrollTop;
    apply(editing, false);
    if (e.type === "change" && k !== "name" && !el.dataset.col && k !== "radius") renderPanel();
    panel.querySelector(".tp-custom").scrollTop = keep;
  }
  function importTheme(txt) {
    try {
      const t = JSON.parse(txt);
      if (!t || !t.c || !t.c.bg) throw new Error("kode tidak valid");
      t.id = "c" + Date.now().toString(36); t.custom = true; t.name = t.name || "Tema impor";
      const L = LS.get("themeCustom", []); L.push(t); LS.set("themeCustom", L); apply(t, true); alertMini("Tema ditambahkan ✅");
    } catch (ex) { alertMini("Kode tema tidak valid"); }
  }
  function alertMini(msg) { if (window.toast) window.toast(msg); }

  // ---------------------------------------------------------------- mulai
  apply(find(LS.get("theme", "asli")), false);
  function boot() {
    const host = document.getElementById("btnHp");
    if (host && !document.getElementById("btnTheme")) {
      const b = document.createElement("button"); b.id = "btnTheme"; b.type = "button"; b.title = "Ganti tema tampilan"; b.textContent = "🎨 Tema";
      b.addEventListener("click", () => (panel && panel.classList.contains("open") ? closePanel() : openPanel()));
      host.parentElement.parentElement.insertBefore(b, host.parentElement);
    }
    startFx(fxOn() ? (cur.fx || "none") : "none");
    watchPanes();
    addEventListener("keydown", (e) => { if (e.key === "Escape" && panel && panel.classList.contains("open")) closePanel(); });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
  window.THEME = { list: all, apply: (id) => apply(find(id), true), enter, THEMES };
})();
