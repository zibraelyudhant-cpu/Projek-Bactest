"use strict";
const $ = (id) => document.getElementById(id);
const TF_SEC = { "1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "2h": 7200,
  "4h": 14400, "6h": 21600, "8h": 28800, "12h": 43200, "1d": 86400 };
const COLORS = { up: "#26a69a", down: "#ef5350", text: "#d5dae3", grid: "#1b2029", warn: "#f0b90b", muted: "#7d8696",
  border: "#262c38", accent: "#3b82f6" };

const S = {
  ws: null, reqId: 0, pending: new Map(), info: null, tf: "1h", started: false,
  fills: [], state: null, playing: false, side: "buy", type: "limit", busy: false,
  drawing: null, selected: null, magnet: false,
};

// ------------------------------------------------------------------ util
const fmtTime = (ms) => new Date(ms).toISOString().slice(0, 16).replace("T", " ") + " UTC";
const toInput = (ms) => new Date(ms).toISOString().slice(0, 16);
const fromInput = (v) => (v ? Date.parse(v + ":00Z") : null);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function decimalsFor(p) {
  if (!p || !isFinite(p) || p <= 0) return 4;
  return Math.max(2, Math.min(10, 4 - Math.floor(Math.log10(p))));
}
let DEC = 4;
const fp = (x) => (x == null || !isFinite(x) ? "—" : Number(x).toFixed(DEC));
const f2 = (x) => (x == null || !isFinite(x) ? "—" : Number(x).toFixed(2));
const cls = (x) => (x > 0 ? "pos" : x < 0 ? "neg" : "");
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* abaikan */ } },
};
function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.style.display = "block";
  clearTimeout(toast._h);
  toast._h = setTimeout(() => (t.style.display = "none"), 4000);
}
function config() {
  return {
    balance: +$("cfgBalance").value, leverage: +$("cfgLeverage").value,
    maker_fee: +$("cfgMaker").value / 100, taker_fee: +$("cfgTaker").value / 100,
    slippage_bps: +$("cfgSlip").value, mmr: +$("cfgMmr").value / 100,
    limit_fill: $("cfgLimitFill").value, intrabar: $("cfgIntrabar").value, use_margin: $("cfgMargin").checked,
  };
}
// Backtest: mode teknikal murni (default) = tanpa fee, tanpa slippage, limit & TP terisi begitu harga menyentuh.
function btConfig() {
  const c = config();
  return { ...c, maker_fee: 0, taker_fee: 0, slippage_bps: 0, limit_fill: "touch", use_margin: false };
}
const toK = (b) => ({ timestamp: b.time * 1000, open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume });

// ------------------------------------------------------------------ overlay kustom
const kc = klinecharts;
kc.registerOverlay({   // garis order/posisi/likuidasi (tidak bisa digeser)
  name: "orderLine", totalStep: 2, needDefaultPointFigure: false, needDefaultXAxisFigure: false, needDefaultYAxisFigure: false,
  createPointFigures: ({ overlay, coordinates, bounding }) => {
    const y = coordinates[0].y, d = overlay.extendData;
    return [
      { type: "line", attrs: { coordinates: [{ x: 0, y }, { x: bounding.width, y }] }, ignoreEvent: true,
        styles: { style: d.solid ? "solid" : "dashed", color: d.color, size: 1, dashedValue: [5, 4] } },
      { type: "text", attrs: { x: 6, y, text: d.text, align: "left", baseline: "middle" }, ignoreEvent: true,
        styles: { color: "#fff", backgroundColor: d.color, size: 11, paddingLeft: 4, paddingRight: 4, paddingTop: 2,
          paddingBottom: 2, borderRadius: 2, borderSize: 0 } },
    ];
  },
  createYAxisFigures: ({ overlay, coordinates, bounding }) => [{
    type: "text", attrs: { x: 0, y: coordinates[0].y, text: (+overlay.points[0].value).toFixed(DEC), align: "left", baseline: "middle" },
    ignoreEvent: true, styles: { color: "#fff", backgroundColor: overlay.extendData.color, size: 11, paddingLeft: 3,
      paddingRight: 3, paddingTop: 2, paddingBottom: 2, borderRadius: 2, borderSize: 0 } }],
});
kc.registerOverlay({   // panah fill / likuidasi
  name: "fillMark", totalStep: 2, needDefaultPointFigure: false, needDefaultXAxisFigure: false, needDefaultYAxisFigure: false,
  createPointFigures: ({ overlay, coordinates }) => {
    const { x, y } = coordinates[0], d = overlay.extendData, s = d.buy ? 1 : -1;
    const tip = y + s * 2, base = y + s * 11;
    return [
      { type: "polygon", attrs: { coordinates: [{ x, y: tip }, { x: x - 5, y: base }, { x: x + 5, y: base }] },
        styles: { style: "fill", color: d.color }, ignoreEvent: true },
      { type: "text", attrs: { x, y: base + s * 3, text: d.text, align: "center", baseline: d.buy ? "top" : "bottom" },
        styles: { color: d.color, size: 10, backgroundColor: "transparent", borderSize: 0, paddingLeft: 0, paddingRight: 0,
          paddingTop: 0, paddingBottom: 0 }, ignoreEvent: true },
    ];
  },
});
// ---- alat gambar dengan warna, tebal, gaya garis dan teks (disimpan di extendData)
const DEFAULT_STYLE = { color: "#3b82f6", width: 1, dashed: false, label: "", fontSize: 12 };
const hexA = (hex, a) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};
function labelFigure(coords, d) {
  if (!d || !d.label || !coords.length) return [];
  const [a, b] = coords;
  const x = b ? (a.x + b.x) / 2 : a.x + 6, y = b ? (a.y + b.y) / 2 : a.y;
  return [{ type: "text", ignoreEvent: true, attrs: { x, y: y - 4, text: d.label, align: b ? "center" : "left", baseline: "bottom" },
    styles: { color: d.color, size: d.fontSize || 12, backgroundColor: "transparent", borderSize: 0,
      paddingLeft: 0, paddingRight: 0, paddingTop: 0, paddingBottom: 0 } }];
}
// bungkus alat bawaan KLineChart supaya bisa diberi teks
const BUILTIN = ["segment", "rayLine", "straightLine", "horizontalStraightLine", "horizontalRayLine", "verticalStraightLine",
  "parallelStraightLine", "priceChannelLine", "fibonacciLine", "priceLine"];
// ---- Fibonacci retracement ala TradingView: tiap level punya warna sendiri, latar transparan di antara level,
// label "angka (harga)", garis tren putus-putus, perpanjang kiri/kanan, dan panel pengaturan level.
// Klik 1 = awal swing (level 1), klik 2 = ujung swing (level 0).
const FIB_COLORS = { "-0.618": "#2962ff", "-0.414": "#673ab7", "-0.272": "#9c27b0", "-0.13": "#e91e63", "0": "#787b86",
  "0.236": "#f23645", "0.382": "#ff9800", "0.5": "#4caf50", "0.618": "#089981", "0.65": "#089981", "0.705": "#00897b",
  "0.786": "#00bcd4", "0.886": "#2196f3", "1": "#787b86", "1.13": "#e91e63", "1.272": "#9c27b0", "1.414": "#673ab7", "1.618": "#2962ff" };
const FIB_LV = [1.618, 1.414, 1.272, 1.13, 1, 0.886, 0.786, 0.705, 0.618, 0.5, 0.382, 0.236, 0, -0.13, -0.272, -0.414, -0.618];
const FIB_FACTORY = () => ({ levels: FIB_LV.map((v) => ({ v, color: FIB_COLORS[String(v)] || "#787b86", on: true })),
  bg: true, bgAlpha: 0.12, extL: false, extR: false, prices: true, values: true, trend: true, reverse: false, labelPos: "left" });
const fibDefault = () => { const d = store.get("fibDefault", null); return d && Array.isArray(d.levels) ? d : FIB_FACTORY(); };
const fibCfg = (ext) => ({ ...FIB_FACTORY(), ...((ext && ext.fib) || {}) });
function fibFigures({ coordinates: c, bounding, overlay }) {
  const pt = overlay.points;
  if (c.length < 2 || pt.length < 2 || pt[0].value == null || pt[1].value == null) return [];
  const ext = overlay.extendData || {}, cfg = fibCfg(ext);
  let [a, b] = [0, 1];                                    // a = level 1, b = level 0
  if (cfg.reverse) [a, b] = [1, 0];
  const x0 = cfg.extL ? 0 : Math.min(c[0].x, c[1].x), x1 = cfg.extR ? bounding.width : Math.max(c[0].x, c[1].x);
  const lv = cfg.levels.filter((l) => l.on && Number.isFinite(+l.v)).map((l) => ({ ...l, v: +l.v })).sort((p, q) => p.v - q.v);
  const yOf = (v) => c[b].y + (c[a].y - c[b].y) * v, pxOf = (v) => pt[b].value + (pt[a].value - pt[b].value) * v;
  const out = [];
  if (cfg.bg) for (let i = 0; i + 1 < lv.length; i++) {
    const ya = yOf(lv[i].v), yb = yOf(lv[i + 1].v);
    out.push({ type: "polygon", ignoreEvent: true, attrs: { coordinates: [{ x: x0, y: ya }, { x: x1, y: ya }, { x: x1, y: yb }, { x: x0, y: yb }] },
      styles: { style: "fill", color: hexA(lv[i + 1].color, cfg.bgAlpha ?? 0.12) } });
  }
  if (cfg.trend) out.push({ type: "line", ignoreEvent: true, attrs: { coordinates: [c[0], c[1]] },
    styles: { style: "dashed", dashedValue: [4, 4], color: "#787b86", size: 1 } });
  const w = ext.width || 1;
  for (const l of lv) {
    const y = yOf(l.v);
    out.push({ type: "line", attrs: { coordinates: [{ x: x0, y }, { x: x1, y }] },
      styles: { style: ext.dashed ? "dashed" : "solid", dashedValue: [6, 4], color: l.color, size: w } });
    if (cfg.values || cfg.prices) {
      const txt = (cfg.values ? `${l.v}` : "") + (cfg.prices ? `${cfg.values ? " (" : ""}${(+pxOf(l.v)).toFixed(DEC)}${cfg.values ? ")" : ""}` : "");
      const left = cfg.labelPos !== "right", inside = left ? x0 < 90 : x1 > bounding.width - 90;   // tidak muat di luar: taruh di dalam, di atas garis
      const ax = left ? (inside ? x0 + 4 : x0 - 4) : (inside ? x1 - 4 : x1 + 4);
      const al = left ? (inside ? "left" : "right") : (inside ? "right" : "left");
      out.push({ type: "text", ignoreEvent: true, attrs: { x: ax, y: inside ? y - 2 : y, text: txt, align: al, baseline: inside ? "bottom" : "middle" },
        styles: { color: l.color, size: ext.fontSize || 11, backgroundColor: "transparent", borderSize: 0,
          paddingLeft: 0, paddingRight: 0, paddingTop: 0, paddingBottom: 0 } });
    }
  }
  return out;
}
for (const name of BUILTIN) {
  const base = new (kc.getOverlayClass(name))();
  if (name === "fibonacciLine") base.createPointFigures = fibFigures;
  kc.registerOverlay({
    name: "x_" + name, totalStep: base.totalStep, needDefaultPointFigure: true, needDefaultXAxisFigure: true,
    needDefaultYAxisFigure: true, performEventPressedMove: base.performEventPressedMove,
    performEventMoveForDrawing: base.performEventMoveForDrawing,
    createPointFigures: (params) => {
      const f = base.createPointFigures ? base.createPointFigures(params) : [];
      return (Array.isArray(f) ? f : [f]).concat(labelFigure(params.coordinates, params.overlay.extendData));
    },
  });
}
kc.registerOverlay({   // persegi (zona)
  name: "rect", totalStep: 3, needDefaultPointFigure: true, needDefaultXAxisFigure: true, needDefaultYAxisFigure: true,
  createPointFigures: ({ coordinates, overlay }) => {
    if (coordinates.length < 2) return [];
    const [a, b] = coordinates, d = overlay.extendData || DEFAULT_STYLE;
    return [{ type: "polygon", attrs: { coordinates: [a, { x: b.x, y: a.y }, b, { x: a.x, y: b.y }] },
      styles: { style: "stroke_fill", color: hexA(d.color, 0.15), borderColor: d.color, borderSize: d.width,
        borderStyle: d.dashed ? "dashed" : "solid", borderDashedValue: [6, 4] } },
      ...labelFigure([{ x: Math.min(a.x, b.x), y: Math.min(a.y, b.y) + (d.fontSize || 12) + 6 }], d)];  // teks di pojok kiri atas
  },
});
kc.registerOverlay({   // teks bebas
  name: "textNote", totalStep: 2, needDefaultPointFigure: true, needDefaultXAxisFigure: false, needDefaultYAxisFigure: false,
  createPointFigures: ({ coordinates, overlay }) => {
    const d = overlay.extendData || DEFAULT_STYLE;
    return [{ type: "text", attrs: { x: coordinates[0].x, y: coordinates[0].y, text: d.label || "Teks", align: "left", baseline: "middle" },
      styles: { color: d.color, size: d.fontSize || 14, backgroundColor: "transparent", borderSize: 0,
        paddingLeft: 4, paddingRight: 4, paddingTop: 2, paddingBottom: 2 } }];
  },
});
// ---- alat gambar tambahan (gaya TradingView)
const lineSt = (d, extra) => ({ style: d.dashed ? "dashed" : "solid", dashedValue: [6, 4], color: d.color, size: d.width || 1, ...(extra || {}) });
const txtSt = (color, size) => ({ color, size: size || 11, backgroundColor: "transparent", borderSize: 0, paddingLeft: 0, paddingRight: 0, paddingTop: 0, paddingBottom: 0 });
// Fib Extension (trend-based): klik 1 awal tren, klik 2 ujung tren, klik 3 ujung koreksi. Level = titik 3 + (titik 2 - titik 1) x angka
const FIBX_LV = [0, 0.382, 0.618, 1, 1.272, 1.414, 1.618, 2, 2.618];
const FIBX_COL = ["#787b86", "#ff9800", "#089981", "#787b86", "#9c27b0", "#673ab7", "#2962ff", "#e91e63", "#f23645"];
kc.registerOverlay({
  name: "fibExt", totalStep: 4, needDefaultPointFigure: true, needDefaultXAxisFigure: true, needDefaultYAxisFigure: true,
  createPointFigures: ({ coordinates: c, overlay, bounding }) => {
    const d = overlay.extendData || DEFAULT_STYLE, pt = overlay.points, out = [];
    if (c.length >= 2) out.push({ type: "line", ignoreEvent: true, attrs: { coordinates: c.slice(0, 3) }, styles: { style: "dashed", dashedValue: [4, 4], color: "#787b86", size: 1 } });
    if (c.length < 3 || pt.length < 3 || pt.some((p) => p.value == null)) return out;
    const dy = c[1].y - c[0].y, dv = pt[1].value - pt[0].value;
    const x0 = Math.min(c[1].x, c[2].x), x1 = d.extR ? bounding.width : Math.max(c[1].x, c[2].x) + 40;
    const lv = FIBX_LV.map((v, i) => ({ v, color: FIBX_COL[i], y: c[2].y + dy * v, px: pt[2].value + dv * v }));
    for (let i = 0; i + 1 < lv.length; i++) out.push({ type: "polygon", ignoreEvent: true,
      attrs: { coordinates: [{ x: x0, y: lv[i].y }, { x: x1, y: lv[i].y }, { x: x1, y: lv[i + 1].y }, { x: x0, y: lv[i + 1].y }] },
      styles: { style: "fill", color: hexA(lv[i + 1].color, 0.1) } });
    for (const l of lv) {
      out.push({ type: "line", attrs: { coordinates: [{ x: x0, y: l.y }, { x: x1, y: l.y }] }, styles: { style: "solid", color: l.color, size: d.width || 1 } });
      out.push({ type: "text", ignoreEvent: true, attrs: { x: x0 + 4, y: l.y - 2, text: `${l.v} (${(+l.px).toFixed(DEC)})`, align: "left", baseline: "bottom" }, styles: txtSt(l.color) });
    }
    return out;
  },
});
// panah (garis dengan kepala panah)
kc.registerOverlay({
  name: "arrowLine", totalStep: 3, needDefaultPointFigure: true, needDefaultXAxisFigure: true, needDefaultYAxisFigure: true,
  createPointFigures: ({ coordinates: c, overlay }) => {
    if (c.length < 2) return [];
    const d = overlay.extendData || DEFAULT_STYLE, [a, b] = c, ang = Math.atan2(b.y - a.y, b.x - a.x), L = 10 + 2 * (d.width || 1);
    const p1 = { x: b.x - L * Math.cos(ang - 0.4), y: b.y - L * Math.sin(ang - 0.4) }, p2 = { x: b.x - L * Math.cos(ang + 0.4), y: b.y - L * Math.sin(ang + 0.4) };
    return [{ type: "line", attrs: { coordinates: [a, b] }, styles: lineSt(d) },
      { type: "polygon", attrs: { coordinates: [b, p1, p2] }, styles: { style: "fill", color: d.color } }, ...labelFigure(c, d)];
  },
});
// tanda panah naik / turun (satu klik, di bawah / di atas candle)
for (const [name, up] of [["arrowUp", true], ["arrowDown", false]]) {
  kc.registerOverlay({
    name, totalStep: 2, needDefaultPointFigure: true, needDefaultXAxisFigure: false, needDefaultYAxisFigure: false,
    createPointFigures: ({ coordinates: c, overlay }) => {
      const d = overlay.extendData || {}, col = d.arrowColor || (up ? COLORS.up : COLORS.down), { x, y } = c[0], s = up ? 1 : -1, z = 7 + 2 * (d.width || 1);
      return [{ type: "polygon", attrs: { coordinates: [{ x, y }, { x: x - z, y: y + s * z }, { x: x - z / 2.4, y: y + s * z },
        { x: x - z / 2.4, y: y + s * 2.2 * z }, { x: x + z / 2.4, y: y + s * 2.2 * z }, { x: x + z / 2.4, y: y + s * z }, { x: x + z, y: y + s * z }] },
        styles: { style: "fill", color: col } },
        ...(d.label ? [{ type: "text", ignoreEvent: true, attrs: { x, y: y + s * (2.2 * z + 4), text: d.label, align: "center", baseline: up ? "top" : "bottom" }, styles: txtSt(col, d.fontSize || 12) }] : [])];
    },
  });
}
// penggaris harga & waktu (Measure): selisih harga, %, jumlah candle
kc.registerOverlay({
  name: "measure", totalStep: 3, needDefaultPointFigure: true, needDefaultXAxisFigure: true, needDefaultYAxisFigure: true,
  createPointFigures: ({ coordinates: c, overlay }) => {
    if (c.length < 2) return [];
    const pt = overlay.points, [a, b] = c, up = pt[1].value >= pt[0].value, col = up ? "#2962ff" : "#f23645";
    const dv = pt[1].value - pt[0].value, pct = (100 * dv) / pt[0].value;
    const bars = pt[1].dataIndex != null && pt[0].dataIndex != null ? pt[1].dataIndex - pt[0].dataIndex : null;
    const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    const txt = `${dv >= 0 ? "+" : ""}${(+dv).toFixed(DEC)} (${pct >= 0 ? "+" : ""}${pct.toFixed(2)}%)${bars != null ? ` · ${bars} candle` : ""}`;
    return [{ type: "polygon", ignoreEvent: true, attrs: { coordinates: [a, { x: b.x, y: a.y }, b, { x: a.x, y: b.y }] }, styles: { style: "fill", color: hexA(col, 0.18) } },
      { type: "line", ignoreEvent: true, attrs: { coordinates: [{ x: mx, y: a.y }, { x: mx, y: b.y }] }, styles: { style: "solid", color: col, size: 1 } },
      { type: "line", ignoreEvent: true, attrs: { coordinates: [{ x: a.x, y: my }, { x: b.x, y: my }] }, styles: { style: "solid", color: col, size: 1 } },
      { type: "text", ignoreEvent: true, attrs: { x: mx, y: (up ? Math.min(a.y, b.y) : Math.max(a.y, b.y)) + (up ? -6 : 6), text: txt, align: "center", baseline: up ? "bottom" : "top" },
        styles: { color: "#fff", size: 12, backgroundColor: col, borderSize: 0, paddingLeft: 6, paddingRight: 6, paddingTop: 3, paddingBottom: 3, borderRadius: 3 } }];
  },
});
// lingkaran (klik 1 pusat, klik 2 jari-jari) & segitiga (3 titik)
kc.registerOverlay({
  name: "circleShape", totalStep: 3, needDefaultPointFigure: true, needDefaultXAxisFigure: true, needDefaultYAxisFigure: true,
  createPointFigures: ({ coordinates: c, overlay }) => {
    if (c.length < 2) return [];
    const d = overlay.extendData || DEFAULT_STYLE, r = Math.hypot(c[1].x - c[0].x, c[1].y - c[0].y);
    return [{ type: "circle", attrs: { x: c[0].x, y: c[0].y, r }, styles: { style: "stroke_fill", color: hexA(d.color, 0.15), borderColor: d.color, borderSize: d.width || 1 } }, ...labelFigure([c[0]], d)];
  },
});
kc.registerOverlay({
  name: "triangleShape", totalStep: 4, needDefaultPointFigure: true, needDefaultXAxisFigure: true, needDefaultYAxisFigure: true,
  createPointFigures: ({ coordinates: c, overlay }) => {
    const d = overlay.extendData || DEFAULT_STYLE;
    if (c.length < 2) return [];
    if (c.length === 2) return [{ type: "line", attrs: { coordinates: c }, styles: lineSt(d) }];
    return [{ type: "polygon", attrs: { coordinates: c }, styles: { style: "stroke_fill", color: hexA(d.color, 0.15), borderColor: d.color, borderSize: d.width || 1 } }];
  },
});
function overlayStyles(d) {   // gaya untuk figure bawaan (garis, teks fib, titik)
  return {
    line: { color: d.color, size: d.width, style: d.dashed ? "dashed" : "solid", dashedValue: [6, 4] },
    text: { color: "#fff", backgroundColor: hexA(d.color, 0.85), borderColor: d.color },   // label fib / harga
    polygon: { color: hexA(d.color, 0.12), borderColor: d.color },
    point: { color: d.color, borderColor: hexA(d.color, 0.35), activeColor: d.color, activeBorderColor: hexA(d.color, 0.35) },
  };
}

// ---- ukuran posisi: "Size (USDT)" = nilai posisi, "Risiko di SL (USDT)" = rugi kalau kena SL (termasuk fee & slippage)
function sizing(entry, sl, tp, type) {
  const c = config(), val = +$("sizeUsdt").value, slip = c.slippage_bps / 1e4;
  const feeIn = type === "limit" ? c.maker_fee : c.taker_fee;
  if (!(entry > 0) || !(val > 0)) return { error: "Isi harga dan size" };
  // biaya per 1 koin kalau kena SL: jarak harga + fee masuk + fee keluar (stop = taker) + slippage stop
  const lossUnit = sl > 0 ? Math.abs(entry - sl) + entry * feeIn + sl * (c.taker_fee + slip) : null;
  let qty;
  if ($("sizeMode").value === "risk") {
    if (!lossUnit || sl === entry) return { error: "Mode risiko butuh Stop loss" };
    qty = val / lossUnit;
  } else qty = val / entry;
  return { qty, notional: qty * entry, loss: lossUnit ? qty * lossUnit : null,
    gain: tp > 0 ? qty * (Math.abs(tp - entry) - entry * feeIn - tp * c.maker_fee) : null };
}
function renderPreview() {
  const type = S.type, price = type === "market" ? S.state && S.state.last_price : +$("price").value;
  const z = sizing(price, +$("sl").value, +$("tp").value, type);
  if (z.error) { $("orderPreview").textContent = $("sizeMode").value === "risk" ? z.error : ""; return; }
  const q = z.qty < 1 ? z.qty.toPrecision(4) : z.qty.toFixed(z.qty < 100 ? 3 : 1);
  $("orderPreview").innerHTML = `Qty <b>${q}</b> · Nilai <b>${f2(z.notional)}</b> USDT` +
    (z.loss != null ? `<br>Kena SL: <span class="neg">−${f2(z.loss)}</span>` : "") +
    (z.gain != null ? ` · Kena TP: <span class="pos">+${f2(z.gain)}</span>` : "") +
    (z.loss != null || z.gain != null ? ' <span class="muted">(sudah termasuk fee)</span>' : "");
}

// ---- alat Long / Short Position: 3 titik di sisi kiri (entry, TP, SL); lebar kotak = extendData.bars candle
//      (lebar dihitung sendiri supaya kotak bisa melewati candle terakhir saat replay)
kc.registerOverlay({
  name: "position", totalStep: 4, needDefaultPointFigure: true, needDefaultXAxisFigure: false, needDefaultYAxisFigure: true,
  createPointFigures: ({ coordinates, overlay, barSpace }) => {
    if (coordinates.length < 3) return [];
    const [e, t, s] = coordinates;
    const [pe, pt, ps] = overlay.points.map((p) => p.value);
    const x0 = e.x, w = Math.max((overlay.extendData.bars || 20) * barSpace.bar, 30);
    const z = sizing(pe, ps, pt, "limit");
    const pct = (a) => (Math.abs(a - pe) / pe) * 100;
    const rr = Math.abs(pe - ps) > 0 ? Math.abs(pt - pe) / Math.abs(pe - ps) : 0;
    const zone = (y, color) => ({ type: "rect", attrs: { x: x0, y: Math.min(e.y, y), width: w, height: Math.abs(y - e.y) },
      styles: { style: "fill", color } });
    const tag = (y, text, bg) => ({ type: "text", ignoreEvent: true,
      attrs: { x: x0 + 2, y: y < e.y ? y - 3 : y + 3, text, align: "left", baseline: y < e.y ? "bottom" : "top" },
      styles: { color: "#fff", backgroundColor: bg, size: 11, paddingLeft: 5, paddingRight: 5, paddingTop: 3,
        paddingBottom: 3, borderRadius: 3, borderSize: 0 } });
    return [
      zone(t.y, "rgba(38,166,154,0.22)"), zone(s.y, "rgba(239,83,80,0.22)"),
      { type: "line", attrs: { coordinates: [{ x: x0, y: e.y }, { x: x0 + w, y: e.y }] }, styles: { color: "#c9d1d9", size: 1 } },
      tag(t.y, `Target ${(+pt).toFixed(DEC)}  (${pct(pt).toFixed(2)}%)  +${z.gain != null ? f2(z.gain) : "—"}`, "#1f8f84"),
      tag(s.y, `Stop ${(+ps).toFixed(DEC)}  (${pct(ps).toFixed(2)}%)  -${z.loss != null ? f2(z.loss) : "—"}`, "#c0403d"),
      { type: "text", ignoreEvent: true, attrs: { x: x0 + 4, y: e.y, text: `${overlay.extendData.side === "short" ? "Short" : "Long"}  RR ${rr.toFixed(2)}`,
        align: "left", baseline: "middle" }, styles: { color: "#fff", backgroundColor: "#4a5468", size: 11, paddingLeft: 4,
        paddingRight: 4, paddingTop: 2, paddingBottom: 2, borderRadius: 2, borderSize: 0 } },
    ];
  },
  performEventPressedMove: ({ points }) => {
    // TP & SL hanya naik-turun dan selalu sejajar entry; menggeser entry ikut menggeser sisi kiri kotak
    for (const i of [1, 2]) { points[i].timestamp = points[0].timestamp; points[i].dataIndex = points[0].dataIndex; }
  },
});

// ------------------------------------------------------------------ suara (Web Audio, tanpa file)
const Sound = {
  ctx: null,
  get() {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    if (!this.ctx) this.ctx = new AC();
    if (this.ctx.state === "suspended") this.ctx.resume();
    return this.ctx;
  },
  tone(f, at, dur, { type = "sine", gain = 1, to = null } = {}) {
    const c = this.get(), vol = $("cfgSound").checked ? +$("cfgVolume").value : 0;
    if (!c || !vol) return;
    const t = c.currentTime + at, o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    if (to) o.frequency.exponentialRampToValueAtTime(to, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.25 * vol * gain, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(c.destination);
    o.start(t);
    o.stop(t + dur + 0.05);
  },
  bell() {   // TP: lonceng "ding-ding" (nada parsial seperti lonceng)
    for (const [at, f] of [[0, 1318.5], [0.22, 1760]])
      [[1, 1], [2.76, 0.35], [5.4, 0.15]].forEach(([m, g]) => this.tone(f * m, at, 1.4, { gain: g }));
  },
  loss() {   // SL / likuidasi: dua nada rendah turun
    this.tone(392, 0, 0.32, { type: "triangle", gain: 1.2, to: 262 });
    this.tone(294, 0.3, 0.55, { type: "triangle", gain: 1.2, to: 147 });
  },
  fill() { this.tone(988, 0, 0.12, { gain: 0.6 }); },   // entry ke-fill: "tik" pendek
};
function playEventSounds(events, trades) {
  let win = false, lose = false, fill = false;
  for (const e of events) {
    if (e.type === "liquidation" || e.tag === "sl") lose = true;
    else if (e.tag === "tp") win = true;
    else if (e.type === "fill" && e.tag === "close") (trades.length && trades[trades.length - 1].pnl > 0 ? (win = true) : (lose = true));
    else if (e.type === "fill") fill = true;
  }
  if (win) Sound.bell();
  if (lose) setTimeout(() => Sound.loss(), win ? 700 : 0);
  if (fill && !win && !lose) Sound.fill();
}
document.addEventListener("pointerdown", () => Sound.get(), { once: true });   // browser butuh interaksi sebelum bersuara

// ------------------------------------------------------------------ chart
const chart = kc.init("chart");
chart.setTimezone("UTC");
chart.setOffsetRightDistance(220);   // ruang kosong di kanan untuk menggambar (mis. Long/Short Position)
chart.setStyles({
  grid: { horizontal: { color: COLORS.grid }, vertical: { color: COLORS.grid } },
  candle: {
    bar: { upColor: COLORS.up, downColor: COLORS.down, noChangeColor: COLORS.muted, upBorderColor: COLORS.up,
      downBorderColor: COLORS.down, upWickColor: COLORS.up, downWickColor: COLORS.down },
    priceMark: { last: { upColor: COLORS.up, downColor: COLORS.down } },
    tooltip: { text: { color: COLORS.text } },
  },
  indicator: { tooltip: { text: { color: COLORS.text } } },
  xAxis: { axisLine: { color: COLORS.border }, tickLine: { color: COLORS.border }, tickText: { color: COLORS.muted } },
  yAxis: { axisLine: { color: COLORS.border }, tickLine: { color: COLORS.border }, tickText: { color: COLORS.muted } },
  separator: { color: COLORS.border },
  crosshair: {
    horizontal: { line: { color: "#5a6478" }, text: { backgroundColor: "#2a3140", borderColor: "#2a3140" } },
    vertical: { line: { color: "#5a6478" }, text: { backgroundColor: "#2a3140", borderColor: "#2a3140" } },
  },
  overlay: { line: { color: COLORS.accent }, point: { color: COLORS.accent, borderColor: "#3b82f655", activeColor: COLORS.accent,
    activeBorderColor: "#3b82f655" }, text: { color: COLORS.text }, rectText: { backgroundColor: COLORS.accent } },
});
new ResizeObserver(() => chart.resize()).observe($("chart"));

// candle lama dimuat saat chart di-scroll ke ujung kiri (server hanya kirim bar sebelum waktu replay)
chart.setLoadDataCallback(async ({ type, data, callback }) => {
  if (type !== "forward" || !S.started || !data) return callback([], false);
  const tf = S.tf;
  const r = await send({ cmd: "history", tf, before: data.timestamp, n: 2000 });
  if (r.type !== "history" || tf !== S.tf) return callback([], false);
  callback(r.bars.map(toK), r.bars.length > 0);
});

// Shift+klik = isi harga, Alt+klik = SL, Ctrl+klik = TP (klik biasa dipakai untuk menggambar/memilih garis)
let downAt = null;
$("chart").addEventListener("mousedown", (e) => (downAt = { x: e.clientX, y: e.clientY }), true);
$("chart").addEventListener("click", (e) => {
  if (!downAt || Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) > 4) return;
  const rect = $("chart").getBoundingClientRect();
  const pt = chart.convertFromPixel([{ x: e.clientX - rect.left, y: e.clientY - rect.top }], { paneId: "candle_pane" });
  const v = pt && pt[0] && pt[0].value;
  if (v == null || !isFinite(v)) return;
  if (S.pendingPos) return placePosition(S.pendingPos, pt[0]);
  if (S.drawing || !(e.shiftKey || e.altKey || e.ctrlKey || e.metaKey)) return;
  const id = e.altKey ? "sl" : e.ctrlKey || e.metaKey ? "tp" : "price";
  $(id).value = (+v).toFixed(DEC);
});

// harga terakhir di titik sentuhan (HP) / kursor (PC), dipakai tombol 📍
function trackPrice(e) {
  const r = $("chart").getBoundingClientRect();
  const pt = chart.convertFromPixel([{ x: e.clientX - r.left, y: e.clientY - r.top }], { paneId: "candle_pane" });
  if (pt && pt[0] && isFinite(pt[0].value) && e.clientY - r.top < chart.getSize("candle_pane").height) S.cross = pt[0].value;
}
["pointerdown", "pointermove"].forEach((ev) => $("chart").addEventListener(ev, trackPrice, true));
document.addEventListener("click", (e) => {
  const b = e.target.closest("button.pick");
  if (!b) return;
  if (S.cross == null) return toast("Sentuh / arahkan kursor ke harga di chart dulu");
  $(b.dataset.for).value = (+S.cross).toFixed(DEC);
  $(b.dataset.for).dispatchEvent(new Event("input"));
});

function setPrecision(price) {
  DEC = decimalsFor(price);
  chart.setPriceVolumePrecision(DEC, 2);
}
function lastTs() {
  const d = chart.getDataList();
  return d.length ? d[d.length - 1].timestamp : Date.now();
}

function renderMarkers() {
  chart.removeOverlay({ groupId: "fills" });
  const step = TF_SEC[S.tf] * 1000;
  for (const f of S.fills) {
    const buy = f.side === "buy";
    const liq = f.type === "liquidation";
    chart.createOverlay({
      name: "fillMark", groupId: "fills", lock: true,
      points: [{ timestamp: Math.floor(f.time / step) * step, value: f.price }],
      extendData: { buy, color: liq ? COLORS.warn : buy ? COLORS.up : COLORS.down,
        text: liq ? "LIQ" : (f.tag || "").toUpperCase() },
    });
  }
}

function renderLines() {
  chart.removeOverlay({ groupId: "sys" });
  const st = S.state;
  if (!st) return;
  const ts = lastTs();
  const add = (price, color, text, solid) => price && chart.createOverlay({
    name: "orderLine", groupId: "sys", lock: true, points: [{ timestamp: ts, value: price }], extendData: { color, text, solid } });
  for (const o of st.orders) {
    const c = o.tag === "tp" ? COLORS.up : o.tag === "sl" ? COLORS.down : o.side === "buy" ? "#4f9cff" : "#ff8a65";
    add(o.price, c, `${o.tag && o.tag !== "manual" ? o.tag.toUpperCase() : o.type} ${o.side} #${o.id}`);
    if (!o.reduce_only) {
      add(o.tp, "#1f7f76", `TP #${o.id}`);
      add(o.sl, "#b23c3a", `SL #${o.id}`);
    }
  }
  if (st.entry) add(st.entry, "#6b7385", `${st.position > 0 ? "LONG" : "SHORT"} ${Math.abs(st.position).toPrecision(4)}`, true);
  if (st.liq) add(st.liq, "#b8860b", "LIQ");
}

// ------------------------------------------------------------------ alat gambar
const ICON = (d) => `<svg viewBox="0 0 24 24">${d}</svg>`;
const TOOLS = [
  { name: "x_segment", title: "Trendline", icon: ICON('<path d="M4 19L20 5"/><circle cx="4" cy="19" r="1.5"/><circle cx="20" cy="5" r="1.5"/>') },
  { name: "x_rayLine", title: "Ray", icon: ICON('<path d="M4 19L21 4"/><circle cx="4" cy="19" r="1.5"/><circle cx="11" cy="13" r="1.5"/>') },
  { name: "x_straightLine", title: "Garis panjang (extended)", icon: ICON('<path d="M2 21L22 3"/><circle cx="8" cy="15.5" r="1.5"/><circle cx="16" cy="8.5" r="1.5"/>') },
  { name: "x_horizontalStraightLine", title: "Garis horizontal", icon: ICON('<path d="M2 12h20"/><circle cx="12" cy="12" r="1.5"/>') },
  { name: "x_horizontalRayLine", title: "Ray horizontal", icon: ICON('<path d="M6 12h16"/><circle cx="6" cy="12" r="1.5"/>') },
  { name: "x_verticalStraightLine", title: "Garis vertikal", icon: ICON('<path d="M12 2v20"/><circle cx="12" cy="12" r="1.5"/>') },
  { name: "x_parallelStraightLine", title: "Parallel channel", icon: ICON('<path d="M3 16L17 4M7 20L21 8"/>') },
  { name: "x_priceChannelLine", title: "Price channel", icon: ICON('<path d="M3 14L15 4M3 20L15 10M3 8l12-10"/>') },
  { name: "x_fibonacciLine", title: "Fibonacci retracement", icon: ICON('<path d="M3 4h18M3 9h18M3 14h18M3 20h18"/><path d="M5 20L19 4" stroke-dasharray="2 2"/>') },
  { name: "rect", title: "Persegi (zona)", icon: ICON('<rect x="4" y="6" width="16" height="12" rx="1"/>') },
  { name: "x_priceLine", title: "Label harga", icon: ICON('<path d="M4 12h10"/><path d="M14 8h7v8h-7z"/>') },
  { name: "long", title: "Long Position", icon: ICON('<rect x="4" y="4" width="16" height="8" fill="#26a69a55" stroke="#26a69a"/><rect x="4" y="12" width="16" height="6" fill="#ef535055" stroke="#ef5350"/>') },
  { name: "short", title: "Short Position", icon: ICON('<rect x="4" y="6" width="16" height="6" fill="#ef535055" stroke="#ef5350"/><rect x="4" y="12" width="16" height="8" fill="#26a69a55" stroke="#26a69a"/>') },
  { name: "textNote", title: "Teks", icon: ICON('<path d="M6 5h12M12 5v14"/>') },
  { name: "fibExt", title: "Fib Extension (3 titik: awal tren, ujung tren, ujung koreksi)", icon: ICON('<path d="M3 20L9 6l5 9"/><path d="M14 15h8M14 9h8M14 4h8" stroke-dasharray="2 2"/>') },
  { name: "arrowLine", title: "Panah", icon: ICON('<path d="M4 20L19 5"/><path d="M12 5h7v7"/>') },
  { name: "arrowUp", title: "Tanda panah naik (1 klik)", icon: ICON('<path d="M12 4l-6 7h4v9h4v-9h4z" fill="#26a69a" stroke="#26a69a"/>') },
  { name: "arrowDown", title: "Tanda panah turun (1 klik)", icon: ICON('<path d="M12 20l-6-7h4V4h4v9h4z" fill="#ef5350" stroke="#ef5350"/>') },
  { name: "measure", title: "Penggaris harga & waktu (selisih, %, jumlah candle)", icon: ICON('<rect x="4" y="5" width="16" height="14" rx="1"/><path d="M12 5v14M4 12h16"/>') },
  { name: "circleShape", title: "Lingkaran", icon: ICON('<circle cx="12" cy="12" r="8"/>') },
  { name: "triangleShape", title: "Segitiga", icon: ICON('<path d="M12 4L21 20H3z"/>') },
];

function drawKey() { return "draw:" + (S.info ? S.info.symbol : ""); }
S.drawStyle = { ...DEFAULT_STYLE, ...store.get("drawStyle", {}), label: "" };
function saveDrawings() {
  const list = [];
  for (const id of S.drawIds) {
    const o = chart.getOverlayById(id);
    if (o) list.push({ name: o.name, points: o.points.map((p) => ({ timestamp: p.timestamp, value: p.value })), extendData: o.extendData });
  }
  S.drawIds = new Set([...S.drawIds].filter((id) => chart.getOverlayById(id)));
  store.set(drawKey(), list);
}
S.drawIds = new Set();
function drawingCallbacks() {
  return {
    groupId: "draw",
    mode: S.magnet ? "weak_magnet" : "normal",
    onDrawEnd: (e) => {
      S.drawing = null; renderDrawBar(); setTimeout(saveDrawings);
      const nid = e.overlay.id;
      selectDrawing(nid);            // gambar baru langsung terpilih: panel gaya terbuka
      setTimeout(() => { if (chart.getOverlayById(nid)) selectDrawing(nid); }, 60);   // chart sempat melepas pilihan setelah klik terakhir
      if (e.overlay.name === "textNote") setTimeout(() => $("stLabel").focus(), 50);
      return false;
    },
    onPressedMoveEnd: (e) => { setTimeout(saveDrawings); if (e.overlay.name === "position") selectDrawing(e.overlay.id); return false; },
    onRemoved: (e) => { if (S.selected === e.overlay.id) selectDrawing(null); setTimeout(saveDrawings); return false; },
    onSelected: (e) => { if (e.overlay.id !== S.drawing) selectDrawing(e.overlay.id); return false; },
    onDeselected: (e) => { if (S.selected === e.overlay.id) selectDrawing(null); return false; },
  };
}
function createDrawing(name, extra) {
  const d = extra.extendData || { ...S.drawStyle, label: "", ...(name === "x_fibonacciLine" ? { fib: fibDefault(), width: 1, dashed: false } : {}) };
  return chart.createOverlay({ name, ...drawingCallbacks(), ...extra, extendData: d, styles: overlayStyles(d) });
}
function placePosition(side, p) {
  const data = chart.getDataList(), vr = chart.getVisibleRange();
  const vis = data.slice(Math.max(0, Math.floor(vr.from)), Math.ceil(vr.to));
  const range = vis.length ? Math.max(...vis.map((b) => b.high)) - Math.min(...vis.map((b) => b.low)) : p.value * 0.02;
  const dist = range * 0.08 || p.value * 0.01, dir = side === "long" ? 1 : -1;
  const bars = Math.max(10, Math.round((vr.to - vr.from) * 0.12));
  const at = { timestamp: p.timestamp, dataIndex: p.dataIndex };
  const id = createDrawing("position", {
    points: [{ ...at, value: p.value }, { ...at, value: p.value + dir * dist * 2 }, { ...at, value: p.value - dir * dist }],   // RR 1:2
    extendData: { ...DEFAULT_STYLE, side, bars },
  });
  S.pendingPos = null;
  S.drawIds.add(id);
  renderDrawBar();
  saveDrawings();
  selectDrawing(id);
}
function startDrawing(tool) {
  if (S.drawing) chart.removeOverlay(S.drawing);
  selectDrawing(null);
  if (tool === "long" || tool === "short") {   // klik sekali di chart untuk menaruh
    S.pendingPos = S.pendingPos === tool ? null : tool;
    S.drawTool = tool;
    S.drawing = null;
    return renderDrawBar();
  }
  S.pendingPos = null;
  const id = createDrawing(tool, {});
  S.drawing = id;
  S.drawTool = tool;
  S.drawIds.add(id);
  renderDrawBar();
}
const LEGACY = { simpleAnnotation: "textNote" };
function loadDrawings() {
  chart.removeOverlay({ groupId: "draw" });
  selectDrawing(null);
  S.drawIds = new Set();
  for (const d of store.get(drawKey(), [])) {
    let name = LEGACY[d.name] || (BUILTIN.includes(d.name) ? "x_" + d.name : d.name);   // gambar dari v1.2
    let ext = d.extendData && typeof d.extendData === "object" ? d.extendData : { ...DEFAULT_STYLE, label: d.extendData || "" };
    const id = createDrawing(name, { points: d.points, extendData: { ...DEFAULT_STYLE, ...ext }, lock: !!ext.locked });
    if (id) S.drawIds.add(id);
  }
  applyDrawVisibility();
}

// ---- panel gaya gambar terpilih
const SWATCH = ["#3b82f6", "#26a69a", "#ef5350", "#f0b90b", "#a855f7", "#ec4899", "#d5dae3", "#ff8a65"];
function selectDrawing(id) {
  if (id !== S.selected) { $("fibLevels").classList.remove("open"); $("toolSet").classList.remove("open"); }
  S.selected = id;
  const o = id && chart.getOverlayById(id);
  const panel = $("stylePanel");
  if (!o) { panel.classList.remove("open"); return; }
  const d = { ...DEFAULT_STYLE, ...(o.extendData || {}) };
  if (o.name === "position") {
    const [pe, pt, ps] = o.points.map((p) => p.value);
    panel.innerHTML = `<b class="${d.side === "short" ? "neg" : "pos"}">${d.side === "short" ? "SHORT" : "LONG"}</b>` +
      `<span class="muted">Entry ${(+pe).toFixed(DEC)} · TP ${(+pt).toFixed(DEC)} · SL ${(+ps).toFixed(DEC)} · ${sizeText(pe, ps, pt)}</span>` +
      '<button data-act="posorder" class="primary">Pasang Order</button><button data-act="flip">Balik arah</button>' +
      '<button data-act="narrow" title="Perkecil lebar">◂▸</button><button data-act="widen" title="Perlebar">◂ ▸</button>' +
      '<span class="sep"></span><button data-act="del" title="Hapus (Delete)">Hapus</button><button data-act="close" title="Tutup (Esc)">✕</button>';
    panel.classList.add("open");
    return;
  }
  if (o.name === "x_fibonacciLine") {
    const f = fibCfg(d), on = (k) => (f[k] ? "on" : "");
    panel.innerHTML = `<b>Fib Retracement</b>` +
      [1, 2, 3].map((w) => `<button class="wbtn ${w === d.width ? "on" : ""}" data-width="${w}" title="Tebal ${w}px"><i style="height:${w}px"></i></button>`).join("") +
      `<button class="wbtn ${d.dashed ? "on" : ""}" data-dashed="1" title="Putus-putus"><i class="dash"></i></button><span class="sep"></span>` +
      `<button class="tg ${on("bg")}" data-fib="bg" title="Warna latar di antara level">Latar</button>` +
      `<button class="tg ${on("extL")}" data-fib="extL" title="Perpanjang garis ke kiri">◂ Kiri</button>` +
      `<button class="tg ${on("extR")}" data-fib="extR" title="Perpanjang garis ke kanan">Kanan ▸</button>` +
      `<button class="tg ${on("values")}" data-fib="values" title="Tampilkan angka level">Angka</button>` +
      `<button class="tg ${on("prices")}" data-fib="prices" title="Tampilkan harga">Harga</button>` +
      `<button class="tg ${on("trend")}" data-fib="trend" title="Garis tren putus-putus antara 2 titik">Tren</button>` +
      `<button class="tg ${on("reverse")}" data-fib="reverse" title="Balik arah (1 ↔ 0)">⇅ Balik</button>` +
      `<button data-act="fiblv" title="Atur level, angka & warna">⚙️ Level</button>` +
      `<span class="sep"></span><button data-act="toolset" title="Pengaturan: gaya, koordinat, visibilitas per TF">⚙</button><button class="tg ${d.locked ? "on" : ""}" data-act="lock" title="Kunci (tidak bisa digeser)">🔒</button>` +
      '<button data-act="clone" title="Duplikat">📋</button>' +
      '<button data-act="del" title="Hapus (Delete)">Hapus</button><button data-act="close" title="Tutup (Esc)">✕</button>';
    panel.classList.add("open");
    return;
  }
  panel.innerHTML =
    SWATCH.map((c) => `<button class="sw ${c === d.color ? "on" : ""}" data-color="${c}" style="background:${c}" title="${c}"></button>`).join("") +
    `<input type="color" id="stColor" value="${d.color}" title="Warna lain">` +
    '<span class="sep"></span>' +
    [1, 2, 3, 4].map((w) => `<button class="wbtn ${w === d.width ? "on" : ""}" data-width="${w}" title="Tebal ${w}px"><i style="height:${w}px"></i></button>`).join("") +
    `<button class="wbtn ${d.dashed ? "on" : ""}" data-dashed="1" title="Putus-putus"><i class="dash"></i></button>` +
    '<span class="sep"></span>' +
    `<input type="text" id="stLabel" placeholder="Teks…" value="${(d.label || "").replace(/"/g, "&quot;")}">` +
    `<select id="stSize" title="Ukuran teks">${[10, 12, 14, 18, 24, 32].map((z) => `<option ${z === d.fontSize ? "selected" : ""}>${z}</option>`).join("")}</select>` +
    `<span class="sep"></span><button data-act="toolset" title="Pengaturan: gaya, koordinat, visibilitas per TF">⚙</button><button class="tg ${d.locked ? "on" : ""}" data-act="lock" title="Kunci (tidak bisa digeser)">🔒</button>` +
    '<button data-act="clone" title="Duplikat">📋</button>' +
    '<button data-act="del" title="Hapus (Delete)">Hapus</button><button data-act="close" title="Tutup (Esc)">✕</button>';
  panel.classList.add("open");
}
function sizeText(pe, ps, pt) {
  const z = sizing(pe, ps, pt, "limit");
  return z.error ? z.error : `Qty ${z.qty.toPrecision(4)} · Nilai ${f2(z.notional)} · Risiko ${f2(z.loss)} USDT`;
}
async function orderFromPosition(id) {
  const o = chart.getOverlayById(id);
  if (!o || !S.started) return toast("Mulai replay dulu");
  const [pe, pt, ps] = o.points.map((p) => p.value);
  const z = sizing(pe, ps, pt, "limit");
  if (z.error) return toast(z.error);
  const qty = z.qty;
  const r = await send({ cmd: "order", side: o.extendData.side === "short" ? "sell" : "buy", type: "limit", qty, price: pe, tp: pt, sl: ps });
  if (r.type !== "error") toast(`Order ${o.extendData.side} limit ${(+pe).toFixed(DEC)} terpasang (TP ${(+pt).toFixed(DEC)}, SL ${(+ps).toFixed(DEC)})`);
}
function updateSelected(patch) {
  const o = S.selected && chart.getOverlayById(S.selected);
  if (!o) return;
  const d = { ...DEFAULT_STYLE, ...(o.extendData || {}), ...patch };
  chart.overrideOverlay({ id: o.id, extendData: d, styles: overlayStyles(d) });
  const { label, ...style } = d;   // gaya (tanpa teks) jadi default untuk gambar berikutnya
  S.drawStyle = { ...style, label: "" };
  store.set("drawStyle", style);
  saveDrawings();
  if (!("label" in patch)) selectDrawing(o.id);
}
$("stylePanel").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.dataset.color) updateSelected({ color: b.dataset.color });
  if (b.dataset.width) updateSelected({ width: +b.dataset.width });
  if (b.dataset.dashed) updateSelected({ dashed: !b.classList.contains("on") });
  if (b.dataset.act === "del") { chart.removeOverlay(S.selected); selectDrawing(null); }
  if (b.dataset.act === "posorder") orderFromPosition(S.selected);
  if (b.dataset.act === "narrow" || b.dataset.act === "widen") {
    const o = chart.getOverlayById(S.selected), bars = o.extendData.bars || 20;
    chart.overrideOverlay({ id: o.id, extendData: { ...o.extendData,
      bars: b.dataset.act === "widen" ? Math.round(bars * 1.4) : Math.max(3, Math.round(bars / 1.4)) } });
    saveDrawings();
  }
  if (b.dataset.act === "flip") {
    const o = chart.getOverlayById(S.selected), [e, t, s] = o.points;
    chart.overrideOverlay({ id: o.id, points: [e, { ...t, value: 2 * e.value - t.value }, { ...s, value: 2 * e.value - s.value }],
      extendData: { ...o.extendData, side: o.extendData.side === "short" ? "long" : "short" } });
    saveDrawings();
    selectDrawing(o.id);
  }
  if (b.dataset.fib) {
    const o = chart.getOverlayById(S.selected), f = fibCfg(o.extendData);
    updateSelected({ fib: { ...f, [b.dataset.fib]: !f[b.dataset.fib] } });
  }
  if (b.dataset.act === "fiblv") openFibLevels();
  if (b.dataset.act === "toolset") openToolSettings("st");
  if (b.dataset.act === "lock") {
    const o = chart.getOverlayById(S.selected), lk = !(o.extendData || {}).locked;
    chart.overrideOverlay({ id: o.id, lock: lk });
    updateSelected({ locked: lk });
  }
  if (b.dataset.act === "clone") {
    const o = chart.getOverlayById(S.selected);
    const vals = o.points.map((p) => p.value), span = (Math.max(...vals) - Math.min(...vals)) || Math.abs(vals[0]) * 0.01;
    const id = createDrawing(o.name, { points: o.points.map((p) => ({ timestamp: p.timestamp, value: p.value + span * 0.15 })),
      extendData: { ...o.extendData, locked: false } });
    if (id) { S.drawIds.add(id); saveDrawings(); selectDrawing(id); toast("Gambar diduplikat (sedikit di atas aslinya)"); }
  }
  if (b.dataset.act === "close") selectDrawing(null);
});
// ---- panel level fibo (seperti Settings → Levels di TradingView)
// ---- pengaturan alat gambar (seperti TradingView): Gaya / Koordinat / Visibilitas per TF
const ALL_TFS = ["5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"];
const TOOL_NAME = Object.fromEntries(TOOLS.map((t) => [t.name, t.title.split(" (")[0]]));
function openToolSettings(tab) {
  const o = S.selected && chart.getOverlayById(S.selected);
  if (!o) return;
  $("fibLevels").classList.remove("open");
  const d = { ...DEFAULT_STYLE, ...(o.extendData || {}) }, tfs = d.tfs || ALL_TFS;
  const box = $("toolSet");
  box.innerHTML = `<div class="fl-head"><b>${esc(TOOL_NAME[o.name] || "Gambar")}</b><button class="mini" data-ts="close">✕</button></div>
    <div class="is-tabs">${[["st", "Gaya"], ["co", "Koordinat"], ["vi", "Visibilitas"]].map(([k, t]) => `<button class="mini ${k === tab ? "on" : ""}" data-tab="${k}">${t}</button>`).join("")}</div>
    <div class="is-pane ${tab === "st" ? "" : "hidden"}" data-pane="st">
      <label class="is-row">Warna <input type="color" class="ts-color" value="${d.color}"></label>
      <label class="is-row">Tebal garis <select class="ts-width">${[1, 2, 3, 4].map((w) => `<option ${w === d.width ? "selected" : ""}>${w}</option>`).join("")}</select></label>
      <label class="is-row">Putus-putus <input type="checkbox" class="ts-dash" ${d.dashed ? "checked" : ""}></label>
      <label class="is-row">Teks <input type="text" class="ts-label" value="${esc(d.label || "")}"></label>
      <label class="is-row">Ukuran teks <select class="ts-size">${[10, 12, 14, 18, 24, 32].map((z) => `<option ${z === d.fontSize ? "selected" : ""}>${z}</option>`).join("")}</select></label></div>
    <div class="is-pane ${tab === "co" ? "" : "hidden"}" data-pane="co">${o.points.map((p, i) => `<div class="ts-pt" data-i="${i}"><b>Titik ${i + 1}</b>
      <label class="is-row">Harga <input type="number" step="any" class="ts-price" value="${(+p.value).toFixed(DEC)}"></label>
      <label class="is-row">Waktu (UTC) <input type="datetime-local" class="ts-time" value="${p.timestamp ? toInput(p.timestamp) : ""}"></label></div>`).join("")}</div>
    <div class="is-pane ${tab === "vi" ? "" : "hidden"}" data-pane="vi"><p class="hint">Tampilkan gambar ini di timeframe:</p>
      <div class="ts-tfs">${ALL_TFS.map((t) => `<label><input type="checkbox" class="ts-tf" value="${t}" ${tfs.includes(t) ? "checked" : ""}> ${t.toUpperCase()}</label>`).join("")}</div>
      <div class="fl-btns"><button class="mini" data-ts="all">Semua</button><button class="mini" data-ts="only">Hanya TF ini</button></div></div>
    <div class="fl-btns" style="margin-top:8px"><button class="mini primary" data-ts="close">OK</button></div>`;
  box.classList.add("open");
}
function applyDrawVisibility() {
  for (const id of S.drawIds) {
    const o = chart.getOverlayById(id);
    if (!o) continue;
    const tfs = (o.extendData || {}).tfs;
    chart.overrideOverlay({ id, visible: !tfs || tfs.includes(S.tf) });
  }
}
$("toolSet").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.dataset.tab) openToolSettings(b.dataset.tab);
  if (b.dataset.ts === "close") $("toolSet").classList.remove("open");
  if (b.dataset.ts === "all" || b.dataset.ts === "only") {
    updateSelected({ tfs: b.dataset.ts === "all" ? null : [S.tf] });
    applyDrawVisibility();
    openToolSettings("vi");
  }
});
$("toolSet").addEventListener("change", (e) => {
  const t = e.target, o = S.selected && chart.getOverlayById(S.selected);
  if (!o) return;
  if (t.classList.contains("ts-color")) updateSelected({ color: t.value });
  if (t.classList.contains("ts-width")) updateSelected({ width: +t.value });
  if (t.classList.contains("ts-dash")) updateSelected({ dashed: t.checked });
  if (t.classList.contains("ts-label")) updateSelected({ label: t.value });
  if (t.classList.contains("ts-size")) updateSelected({ fontSize: +t.value });
  if (t.classList.contains("ts-price") || t.classList.contains("ts-time")) {
    const i = +t.closest(".ts-pt").dataset.i, pts = o.points.map((p) => ({ timestamp: p.timestamp, value: p.value }));
    if (t.classList.contains("ts-price") && isFinite(+t.value)) pts[i].value = +t.value;
    if (t.classList.contains("ts-time") && t.value) pts[i].timestamp = fromInput(t.value);
    chart.overrideOverlay({ id: o.id, points: pts });
    saveDrawings();
  }
  if (t.classList.contains("ts-tf")) {
    const tfs = [...$("toolSet").querySelectorAll(".ts-tf:checked")].map((x) => x.value);
    updateSelected({ tfs: tfs.length === ALL_TFS.length ? null : tfs });
    applyDrawVisibility();
  }
  if (!t.classList.contains("ts-tf")) openToolSettings($("toolSet").querySelector(".is-tabs .on").dataset.tab);
});
function openFibLevels() {
  const o = S.selected && chart.getOverlayById(S.selected);
  if (!o) return;
  const f = fibCfg(o.extendData);
  const box = $("fibLevels");
  const rows = f.levels.map((l, i) => `<div class="fl" data-i="${i}"><input type="checkbox" class="fl-on" ${l.on ? "checked" : ""}>
      <input type="number" step="0.001" class="fl-v" value="${l.v}"><input type="color" class="fl-c" value="${l.color}">
      <button class="mini fl-rm" title="Hapus level">✕</button></div>`).join("");
  box.innerHTML = `<div class="fl-head"><b>Level Fibonacci</b><button class="mini" data-fl="close">✕</button></div>
    <div class="fl-grid">${rows}</div>
    <div class="fl-opts">
      <label>Transparansi latar <input type="range" min="0" max="0.5" step="0.02" class="fl-alpha" value="${f.bgAlpha ?? 0.12}"></label>
      <label>Label <select class="fl-pos"><option value="left" ${f.labelPos !== "right" ? "selected" : ""}>kiri</option><option value="right" ${f.labelPos === "right" ? "selected" : ""}>kanan</option></select></label>
    </div>
    <div class="fl-btns"><button class="mini" data-fl="add">+ Level</button><button class="mini" data-fl="sort">Urutkan</button>
      <button class="mini" data-fl="reset" title="Kembali ke set bawaan aplikasi">Reset bawaan</button>
      <button class="mini primary" data-fl="def" title="Fibo baru memakai pengaturan ini">Jadikan default</button></div>
    <p class="hint">Klik 1 = awal swing (level 1), klik 2 = ujung swing (level 0). Minus = lewat ujung swing.</p>`;
  box.classList.add("open");
}
function fibLevelsApply(mut) {
  const o = S.selected && chart.getOverlayById(S.selected);
  if (!o) return;
  const f = fibCfg(o.extendData);
  const g = { ...f, levels: f.levels.map((l) => ({ ...l })) };
  mut(g);
  updateSelected({ fib: g });
}
$("fibLevels").addEventListener("input", (e) => {
  const row = e.target.closest(".fl");
  if (row) {
    const i = +row.dataset.i;
    fibLevelsApply((g) => {
      if (e.target.classList.contains("fl-on")) g.levels[i].on = e.target.checked;
      if (e.target.classList.contains("fl-v") && e.target.value !== "") g.levels[i].v = +e.target.value;
      if (e.target.classList.contains("fl-c")) g.levels[i].color = e.target.value;
    });
  }
  if (e.target.classList.contains("fl-alpha")) fibLevelsApply((g) => (g.bgAlpha = +e.target.value));
  if (e.target.classList.contains("fl-pos")) fibLevelsApply((g) => (g.labelPos = e.target.value));
});
$("fibLevels").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.classList.contains("fl-rm")) { const i = +b.closest(".fl").dataset.i; fibLevelsApply((g) => g.levels.splice(i, 1)); openFibLevels(); }
  const act = b.dataset.fl;
  if (act === "close") $("fibLevels").classList.remove("open");
  if (act === "add") { fibLevelsApply((g) => g.levels.push({ v: 0.65, color: "#ff9800", on: true })); openFibLevels(); }
  if (act === "sort") { fibLevelsApply((g) => g.levels.sort((p, q) => q.v - p.v)); openFibLevels(); }
  if (act === "reset") { fibLevelsApply((g) => Object.assign(g, FIB_FACTORY())); openFibLevels(); }
  if (act === "def") {
    const o = S.selected && chart.getOverlayById(S.selected);
    if (o) { store.set("fibDefault", fibCfg(o.extendData)); toast("Pengaturan fibo ini jadi default untuk fibo berikutnya"); }
  }
});
$("stylePanel").addEventListener("input", (e) => {
  if (e.target.id === "stLabel") updateSelected({ label: e.target.value });
  if (e.target.id === "stColor") updateSelected({ color: e.target.value });
  if (e.target.id === "stSize") updateSelected({ fontSize: +e.target.value });
});

function renderDrawBar() {
  $("drawBar").innerHTML = TOOLS.map((t) =>
    `<button data-tool="${t.name}" title="${t.title}" class="${(S.drawing && S.drawTool === t.name) || S.pendingPos === t.name ? "active" : ""}">${t.icon}</button>`).join("") +
    "<hr>" +
    `<button data-act="magnet" title="Magnet ke OHLC" class="${S.magnet ? "active" : ""}">${ICON('<path d="M6 4v8a6 6 0 0 0 12 0V4M6 8h4M14 8h4"/>')}</button>` +
    `<button data-act="delsel" title="Hapus gambar terpilih (Delete)">${ICON('<path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"/>')}</button>` +
    `<button data-act="clear" title="Hapus semua gambar">${ICON('<path d="M5 7h14M7 7l1 13h8l1-13M10 11l4 5M14 11l-4 5"/>')}</button>`;
  requestAnimationFrame(fitDrawBar);
}
// toolbar gambar: kalau tidak muat setinggi chart (layar pendek), pakai 2 kolom
function fitDrawBar() {
  const d = $("drawBar");
  if (!d) return;
  d.classList.remove("two");
  if (window.innerWidth > 900 && d.scrollHeight > d.clientHeight + 4) d.classList.add("two");
  if (typeof chart !== "undefined") setTimeout(() => chart.resize());
}
window.addEventListener("resize", () => { clearTimeout(fitDrawBar.t); fitDrawBar.t = setTimeout(fitDrawBar, 150); });
$("drawBar").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.dataset.tool) return startDrawing(b.dataset.tool);
  if (b.dataset.act === "magnet") { S.magnet = !S.magnet; renderDrawBar(); }
  if (b.dataset.act === "delsel" && S.selected) { chart.removeOverlay(S.selected); selectDrawing(null); }
  if (b.dataset.act === "clear" && confirm("Hapus semua gambar di simbol ini?")) {
    chart.removeOverlay({ groupId: "draw" });
    S.drawIds = new Set();
    selectDrawing(null);
    store.set(drawKey(), []);
  }
});

// ------------------------------------------------------------------ indikator (gaya TradingView: dialog cari, legend 👁 ⚙ ✕, pengaturan input & warna)
// ---- indikator buatan sendiri: Dorongan % = gabungan ADX (kekuatan tren) + Force Index (dorongan harga x volume) + Volume
// 0–100%. Tinggi = harga sedang didorong kuat; rendah = dorongan lemah. Ditampilkan satu garis seperti RSI.
// Batas "breakout" / "cuma nyentuh" belum ditetapkan — dicari lewat backtest.
function doronganCalc(list, p) {
  const [nAdx, nFi, nVol] = p, nSm = Math.max(1, p[3] || 10), mid = p[4] != null && isFinite(p[4]) ? +p[4] : 50;   // nSm = penghalusan (EMA) hasil akhir: makin besar makin tenang
  const n = list.length, out = new Array(n).fill(null).map(() => ({}));
  if (n < 3) return out;
  const wil = (prev, x, k) => (prev * (k - 1) + x) / k;
  let tr = 0, pdm = 0, ndm = 0, adx = null, dxs = [], fi = null, fiAbs = [], vols = [], ema3 = null;
  const aFi = 2 / (nFi + 1), aS = 2 / (nSm + 1);
  for (let i = 1; i < n; i++) {
    const c = list[i], q = list[i - 1];
    const up = c.high - q.high, dn = q.low - c.low;
    const t = Math.max(c.high - c.low, Math.abs(c.high - q.close), Math.abs(c.low - q.close));
    const p1 = up > dn && up > 0 ? up : 0, n1 = dn > up && dn > 0 ? dn : 0;
    if (i <= nAdx) { tr += t; pdm += p1; ndm += n1; } else { tr = wil(tr, t, nAdx); pdm = wil(pdm, p1, nAdx); ndm = wil(ndm, n1, nAdx); }
    let pdi = null, ndi = null;
    if (i >= nAdx && tr > 0) {
      pdi = (100 * pdm) / tr; ndi = (100 * ndm) / tr;
      const dx = pdi + ndi > 0 ? (100 * Math.abs(pdi - ndi)) / (pdi + ndi) : 0;
      if (adx == null) { dxs.push(dx); if (dxs.length === nAdx) adx = dxs.reduce((a, b) => a + b, 0) / nAdx; } else adx = wil(adx, dx, nAdx);
    }
    const raw = (c.close - q.close) * (c.volume || 0);
    fi = fi == null ? raw : aFi * raw + (1 - aFi) * fi;
    fiAbs.push(Math.abs(fi)); if (fiAbs.length > 100) fiAbs.shift();
    const vAvg = vols.length ? vols.reduce((a, b) => a + b, 0) / vols.length : null;
    vols.push(c.volume || 0); if (vols.length > nVol) vols.shift();
    if (adx == null || vAvg == null || fiAbs.length < 20) continue;
    const fiAvg = fiAbs.reduce((a, b) => a + b, 0) / fiAbs.length;
    const cl = (x) => Math.max(0, Math.min(1, x));
    const sA = cl(adx / 50);                                     // ADX 25 = 50%, 50+ = 100%
    const sF = fiAvg > 0 ? cl(Math.abs(fi) / (2 * fiAvg)) : 0;   // Force Index 1x rata-rata = 50%, 2x = 100%
    const sV = vAvg > 0 ? cl((c.volume || 0) / vAvg / 3) : 0;    // volume normal = 33%, 3x rata-rata = 100%
    const score = 100 * (0.4 * sA + 0.35 * sF + 0.25 * sV);
    ema3 = ema3 == null ? score : aS * score + (1 - aS) * ema3;
    const dir = fi > 0 ? 1 : fi < 0 ? -1 : (pdi || 0) >= (ndi || 0) ? 1 : -1;
    out[i] = { p: +ema3.toFixed(1), mid, dir, adx: +adx.toFixed(1), fi_pct: +(100 * sF).toFixed(0), vol_pct: +(100 * sV).toFixed(0) };
  }
  return out;
}
kc.registerIndicator({
  name: "DORONGAN", shortName: "Dorongan %", calcParams: [14, 13, 20, 10, 50], precision: 1, minValue: 0, maxValue: 100,
  figures: [{ key: "p", title: "Dorongan: ", type: "line" },       // simpel seperti RSI: satu garis, satu angka
    { key: "mid", title: "Garis: ", type: "line",                  // garis tengah: di atas = condong breakout, di bawah = pullback/retest
      styles: () => ({ color: "rgba(160,170,190,.75)", style: "dashed", size: 1, dashedValue: [4, 4] }) }],
  calc: (list, ind) => doronganCalc(list, ind.calcParams),
});
const INDICATORS = [
  { name: "MA", main: true, desc: "Moving Average (rata-rata sederhana)", params: ["Periode 1", "Periode 2", "Periode 3", "Periode 4"], def: [5, 10, 30, 60], multi: true },
  { name: "EMA", main: true, desc: "Exponential Moving Average", params: ["Periode 1", "Periode 2", "Periode 3"], def: [6, 12, 20], multi: true },
  { name: "SMA", main: true, desc: "Smoothed Moving Average", params: ["Periode", "Bobot"], def: [12, 2] },
  { name: "BOLL", main: true, desc: "Bollinger Bands", params: ["Periode", "Deviasi"], def: [20, 2] },
  { name: "SAR", main: true, desc: "Parabolic SAR", params: ["Awal", "Langkah", "Maks"], def: [2, 2, 20] },
  { name: "BBI", main: true, desc: "Bull and Bear Index", params: ["P1", "P2", "P3", "P4"], def: [3, 6, 12, 24] },
  { name: "AVP", main: true, desc: "Average Price (harga rata-rata berbobot volume)", params: [], def: [] },
  { name: "VOL", main: false, desc: "Volume + MA volume", params: ["MA 1", "MA 2", "MA 3"], def: [5, 10, 20] },
  { name: "MACD", main: false, desc: "MACD", params: ["Cepat", "Lambat", "Sinyal"], def: [12, 26, 9] },
  { name: "RSI", main: false, desc: "Relative Strength Index", params: ["Periode 1", "Periode 2", "Periode 3"], def: [6, 12, 24], multi: true },
  { name: "KDJ", main: false, desc: "Stochastic KDJ", params: ["Periode", "K", "D"], def: [9, 3, 3] },
  { name: "DMI", main: false, desc: "DMI / ADX (kekuatan tren)", params: ["Periode", "ADX"], def: [14, 6] },
  { name: "CCI", main: false, desc: "Commodity Channel Index", params: ["Periode"], def: [20] },
  { name: "WR", main: false, desc: "Williams %R", params: ["P1", "P2", "P3"], def: [6, 10, 14] },
  { name: "OBV", main: false, desc: "On Balance Volume", params: ["MA"], def: [30] },
  { name: "AO", main: false, desc: "Awesome Oscillator", params: ["Pendek", "Panjang"], def: [5, 34] },
  { name: "MTM", main: false, desc: "Momentum", params: ["Periode", "MA"], def: [12, 6] },
  { name: "ROC", main: false, desc: "Rate of Change", params: ["Periode", "MA"], def: [12, 6] },
  { name: "TRIX", main: false, desc: "Triple EMA (TRIX)", params: ["Periode", "MA"], def: [12, 9] },
  { name: "BIAS", main: false, desc: "Bias (jarak harga dari MA)", params: ["P1", "P2", "P3"], def: [6, 12, 24] },
  { name: "PSY", main: false, desc: "Psychological Line", params: ["Periode", "MA"], def: [12, 6] },
  { name: "BRAR", main: false, desc: "BRAR (sentimen)", params: ["Periode"], def: [26] },
  { name: "CR", main: false, desc: "CR (energi harga)", params: ["P1", "P2", "P3", "P4", "P5"], def: [26, 10, 20, 40, 60] },
  { name: "DMA", main: false, desc: "Different of MA", params: ["Pendek", "Panjang", "MA"], def: [10, 50, 10] },
  { name: "VR", main: false, desc: "Volume Ratio", params: ["Periode", "MA"], def: [24, 30] },
  { name: "EMV", main: false, desc: "Ease of Movement", params: ["Periode", "MA"], def: [14, 9] },
  { name: "PVT", main: false, desc: "Price and Volume Trend", params: [], def: [] },
  { name: "DORONGAN", main: false, desc: "Dorongan % — gabungan ADX + Force Index + Volume (buatan sendiri)", params: ["Panjang ADX", "EMA Force Index", "Rata-rata volume", "Penghalusan (makin besar makin tenang)", "Garis tengah (%): atas = breakout, bawah = pullback"], def: [14, 13, 20, 10, 50] },
];
const IND_LINE_COLORS = ["#ff9800", "#9c27b0", "#2196f3", "#e91e63", "#00bcd4"];
let IND = store.get("indicators", { VOL: { on: true, params: "" }, EMA: { on: true, params: "20,50,200" } });
const indPane = {};
// kunci IND: "RSI" atau "RSI#2" (indikator yang sama dipasang lebih dari sekali di panel bawah)
const indBase = (key) => String(key).split("#")[0];
const indDef = (key) => INDICATORS.find((i) => i.name === indBase(key));
let DOR_DEF = {};                                    // penghalusan Dorongan % terbaik per TF (hasil Tes SNR yang lolos uji)
const doronganDefault = () => [14, 13, 20, (DOR_DEF[S.tf] && DOR_DEF[S.tf].smooth) || 10, (DOR_DEF[S.tf] && DOR_DEF[S.tf].line) || 50];
const indParams = (name) => {
  const def = indDef(name), cfg = IND[name] || {};
  if (indBase(name) === "DORONGAN" && !(cfg.params || "").trim()) return doronganDefault();   // belum diatur sendiri: pakai default TF
  const p = (cfg.params || "").split(",").map((x) => parseFloat(x)).filter((x) => isFinite(x));
  return p.length ? p : def ? def.def.slice() : [];
};
function indStyles(name) {
  const cfg = IND[name] || {};
  const cols = cfg.colors || IND_LINE_COLORS;
  return { lines: cols.map((c) => ({ color: c, size: cfg.width || 1, style: "solid", smooth: false, dashedValue: [2, 2] })) };
}
function applyIndicator(key) {
  const name = key, def = indDef(key);
  if (!def) return;
  const cfg = IND[name] || { on: false, params: "" };
  const paneId = def.main ? "candle_pane" : indPane[name];
  if (paneId) chart.removeIndicator(paneId, def.name);
  delete indPane[name];
  if (!cfg.on) return;
  const params = indParams(name);
  const create = { name: def.name, ...(params.length ? { calcParams: params } : {}), styles: indStyles(name), visible: !cfg.hidden };
  if (def.main) chart.createIndicator(create, true, { id: "candle_pane" });
  else indPane[name] = chart.createIndicator(create, false, { height: cfg.height || 110 });
}
function saveInd(name) { store.set("indicators", IND); if (name) applyIndicator(name); }
// legend indikator: ikon 👁 sembunyikan, ⚙ pengaturan, ✕ hapus (seperti TradingView)
chart.setStyles({ indicator: { tooltip: { icons: [
  { id: "vis", position: "middle", marginLeft: 8, marginTop: 4, marginRight: 0, marginBottom: 0, paddingLeft: 2, paddingTop: 0,
    paddingRight: 2, paddingBottom: 0, icon: "◉", fontFamily: "sans-serif", size: 12, color: "#7d8696", activeColor: "#d5dae3",
    backgroundColor: "transparent", activeBackgroundColor: "rgba(127,127,127,.2)" },
  { id: "set", position: "middle", marginLeft: 4, marginTop: 4, marginRight: 0, marginBottom: 0, paddingLeft: 2, paddingTop: 0,
    paddingRight: 2, paddingBottom: 0, icon: "⚙", fontFamily: "sans-serif", size: 12, color: "#7d8696", activeColor: "#d5dae3",
    backgroundColor: "transparent", activeBackgroundColor: "rgba(127,127,127,.2)" },
  { id: "del", position: "middle", marginLeft: 4, marginTop: 4, marginRight: 0, marginBottom: 0, paddingLeft: 2, paddingTop: 0,
    paddingRight: 2, paddingBottom: 0, icon: "✕", fontFamily: "sans-serif", size: 12, color: "#7d8696", activeColor: "#ef5350",
    backgroundColor: "transparent", activeBackgroundColor: "rgba(239,83,80,.15)" },
] } } });
chart.subscribeAction("onTooltipIconClick", (d) => {
  if (!d || !d.indicatorName) return;
  const name = d.paneId === "candle_pane" ? d.indicatorName : Object.keys(indPane).find((k) => indPane[k] === d.paneId && indBase(k) === d.indicatorName);
  if (!name || !IND[name]) return;
  if (d.iconId === "vis") { IND[name].hidden = !IND[name].hidden; saveInd(name); toast(IND[name].hidden ? `${name} disembunyikan (buka lagi lewat ƒx Indikator)` : `${name} ditampilkan`); }
  if (d.iconId === "set") openIndSettings(name);
  if (d.iconId === "del") { IND[name].on = false; saveInd(name); if (name.includes("#")) { delete IND[name]; store.set("indicators", IND); } renderIndPanel(); }
});
// dialog daftar indikator (cari + klik untuk tambah / hapus)
function renderIndPanel() {
  const q = ($("indSearch") && $("indSearch").value.trim().toLowerCase()) || "";
  const list = INDICATORS.filter((i) => !q || i.name.toLowerCase().includes(q) || i.desc.toLowerCase().includes(q));
  const row = (i) => {
    const on = IND[i.name] && IND[i.name].on, hid = on && IND[i.name].hidden;
    const extra = Object.keys(IND).filter((k) => k.startsWith(i.name + "#") && IND[k].on);
    return `<div class="ind-item ${on ? "on" : ""}" data-ind="${i.name}"><b>${i.name}</b><span>${esc(i.desc)}</span>
      ${on ? `<em>${hid ? "tersembunyi" : "aktif"}</em><button class="mini ind-set" title="Pengaturan">⚙</button>` : "<em></em><i></i>"}
      ${!i.main && (on || extra.length) ? '<button class="mini ind-add" title="Pasang lagi (mis. RSI kedua dengan periode lain)">+1</button>' : ""}</div>` +
      extra.map((k) => `<div class="ind-item sub on" data-ind="${k}"><b>${k}</b><span>${esc(indParams(k).join(", "))}</span>
        <em>${IND[k].hidden ? "tersembunyi" : "aktif"}</em><button class="mini ind-set" title="Pengaturan">⚙</button><button class="mini ind-rm" title="Hapus">✕</button></div>`).join("");
  };
  const sec = (title, arr) => (arr.length ? `<h4>${title}</h4>${arr.map(row).join("")}` : "");
  $("indPanel").innerHTML = `<div class="ind-head"><b>Indikator</b><button class="mini" id="indClose">✕</button></div>
    <input id="indSearch" placeholder="Cari indikator… (mis. RSI, MACD, bollinger)" value="${esc(q)}">
    <div class="ind-list">${sec("Di atas candle", list.filter((i) => i.main))}${sec("Panel bawah", list.filter((i) => !i.main))}</div>
    <div class="ind-tpl"><b>Template</b><select id="indTpl"><option value="">— pilih template —</option>${Object.keys(store.get("indTemplates", {}))
      .map((n) => `<option>${esc(n)}</option>`).join("")}</select>
      <button class="mini" id="indTplApply">Terapkan</button><button class="mini" id="indTplSave">Simpan set ini</button><button class="mini" id="indTplDel">Hapus</button></div>
    <p class="hint">Klik untuk menambah / menghapus. <b>+1</b> = pasang indikator yang sama sekali lagi. Di chart: ◉ sembunyikan, ⚙ pengaturan, ✕ hapus.</p>`;
  $("indTplSave").onclick = () => {
    const n = (prompt("Nama template indikator:", "Set saya") || "").trim();
    if (!n) return;
    const t = store.get("indTemplates", {});
    t[n] = JSON.parse(JSON.stringify(IND));
    store.set("indTemplates", t);
    toast(`Template "${n}" disimpan`);
    renderIndPanel();
  };
  $("indTplApply").onclick = () => {
    const n = $("indTpl").value, t = store.get("indTemplates", {})[n];
    if (!t) return toast("Pilih template dulu");
    for (const k of Object.keys(IND)) { IND[k].on = false; applyIndicator(k); }
    IND = JSON.parse(JSON.stringify(t));
    store.set("indicators", IND);
    Object.keys(IND).forEach(applyIndicator);
    toast(`Template "${n}" diterapkan`);
    renderIndPanel();
  };
  $("indTplDel").onclick = () => {
    const n = $("indTpl").value, t = store.get("indTemplates", {});
    if (!n || !t[n] || !confirm(`Hapus template "${n}"?`)) return;
    delete t[n];
    store.set("indTemplates", t);
    renderIndPanel();
  };
  const inp = $("indSearch");
  inp.oninput = () => { const pos = inp.selectionStart; renderIndPanel(); $("indSearch").focus(); $("indSearch").setSelectionRange(pos, pos); };
  $("indClose").onclick = () => $("indPanel").classList.remove("open");
}
$("indPanel").addEventListener("click", (e) => {
  const it = e.target.closest(".ind-item");
  if (!it) return;
  const name = it.dataset.ind;
  if (e.target.classList.contains("ind-set")) return openIndSettings(name);
  if (e.target.classList.contains("ind-add")) {
    let n = 2;
    while (IND[`${name}#${n}`] && IND[`${name}#${n}`].on) n++;
    const key = `${name}#${n}`;
    IND[key] = { on: true, params: (IND[name] && IND[name].params) || "" };
    saveInd(key);
    renderIndPanel();
    return openIndSettings(key);
  }
  if (e.target.classList.contains("ind-rm")) { IND[name].on = false; saveInd(name); delete IND[name]; store.set("indicators", IND); return renderIndPanel(); }
  IND[name] = IND[name] || { on: false, params: "" };
  IND[name].on = !IND[name].on;
  IND[name].hidden = false;
  saveInd(name);
  renderIndPanel();
});
$("btnInd").addEventListener("click", (e) => { e.stopPropagation(); $("chartSetPanel").classList.remove("open"); renderIndPanel(); $("indPanel").classList.toggle("open"); if ($("indPanel").classList.contains("open")) $("indSearch").focus(); });
document.addEventListener("click", (e) => {   // klik di luar menutup panel (elemen yang baru digambar ulang tidak dihitung)
  if (e.target.isConnected && !e.target.closest(".popwrap") && !e.target.closest("#indSet")) $("indPanel").classList.remove("open");
});
// pengaturan satu indikator: tab Input (parameter) & Gaya (warna & tebal garis), seperti TradingView
function openIndSettings(name) {
  const def = indDef(name);
  if (!def) return;
  IND[name] = IND[name] || { on: true, params: "" };
  const cfg = IND[name], params = indParams(name), cols = cfg.colors || IND_LINE_COLORS;
  const nLines = def.multi ? params.length : Math.max(1, def.params.length || 1, params.length);
  $("indSet").innerHTML = `<div class="ind-head"><b>${esc(name)} · ${esc(def.desc)}</b><button class="mini" data-is="close">✕</button></div>
    <div class="is-tabs"><button class="mini on" data-tab="in">Input</button><button class="mini" data-tab="st">Gaya</button></div>
    <div class="is-pane" data-pane="in">${def.multi
      ? params.map((v, k) => `<label class="is-row"><span><i class="is-dot" style="background:${cols[k] || IND_LINE_COLORS[k % 5]}"></i>Garis ${k + 1} (periode)</span>
        <span class="is-pair"><input type="number" step="1" min="1" class="is-p" data-k="${k}" value="${v}">${params.length > 1 ? `<button class="mini" data-is="rmline" data-k="${k}" title="Hapus garis ini">✕</button>` : ""}</span></label>`).join("") +
        (params.length < 6 ? '<button class="mini" data-is="addline">+ Tambah garis</button>' : "") +
        `<p class="hint">Mau 1 ${esc(def.name)} saja? Hapus garis lain dengan ✕.</p>`
      : def.params.length ? def.params.map((lb, k) => `<label class="is-row">${esc(lb)}
      <input type="number" step="any" class="is-p" data-k="${k}" value="${params[k] ?? ""}"></label>`).join("") : '<p class="hint">Indikator ini tidak punya input.</p>'}</div>
    <div class="is-pane hidden" data-pane="st">${Array.from({ length: Math.min(5, nLines) }, (_, k) => `<label class="is-row">Garis ${k + 1}
      <input type="color" class="is-c" data-k="${k}" value="${cols[k] || IND_LINE_COLORS[k % 5]}"></label>`).join("")}
      <label class="is-row">Tebal garis <select class="is-w">${[1, 2, 3].map((w) => `<option ${w === (cfg.width || 1) ? "selected" : ""}>${w}</option>`).join("")}</select></label>
      ${def.main ? "" : `<label class="is-row">Tinggi panel <input type="number" min="60" max="400" step="10" class="is-h" value="${cfg.height || 110}"></label>`}
      <label class="is-row">Tampilkan <input type="checkbox" class="is-v" ${cfg.hidden ? "" : "checked"}></label></div>
    <div class="fl-btns"><button class="mini" data-is="reset">Kembali ke bawaan</button><button class="mini primary" data-is="ok">OK</button></div>`;
  $("indSet").dataset.name = name;
  $("indSet").classList.add("open");
}
$("indSet").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const name = $("indSet").dataset.name;
  if (b.dataset.tab) {
    $("indSet").querySelectorAll(".is-tabs button").forEach((x) => x.classList.toggle("on", x === b));
    $("indSet").querySelectorAll(".is-pane").forEach((p) => p.classList.toggle("hidden", p.dataset.pane !== b.dataset.tab));
  }
  if (b.dataset.is === "close" || b.dataset.is === "ok") $("indSet").classList.remove("open");
  if (b.dataset.is === "reset") { IND[name] = { on: true, params: "" }; saveInd(name); openIndSettings(name); }
  if (b.dataset.is === "rmline" || b.dataset.is === "addline") {
    const cfg = IND[name], ps = indParams(name), cols = (cfg.colors || IND_LINE_COLORS).slice();
    if (b.dataset.is === "rmline") { ps.splice(+b.dataset.k, 1); cols.splice(+b.dataset.k, 1); }
    else { ps.push(Math.min(1000, (ps[ps.length - 1] || 20) * 2)); cols.push(IND_LINE_COLORS[ps.length % 5]); }
    cfg.params = ps.join(","); cfg.colors = cols;
    saveInd(name); openIndSettings(name);
    $("indSet").querySelectorAll(".is-tabs button").forEach((x) => x.classList.toggle("on", x.dataset.tab === "in"));
  }
});
$("indSet").addEventListener("input", (e) => {
  const name = $("indSet").dataset.name, cfg = IND[name], t = e.target;
  if (t.classList.contains("is-p")) {
    const ps = [...$("indSet").querySelectorAll(".is-p")].map((x) => x.value.trim());
    if (indDef(name).multi) {
      const ok = ps.filter((x) => x !== "" && isFinite(+x) && +x >= 1);   // kolom kosong = garis itu tidak dipakai
      if (ok.length) cfg.params = ok.join(",");
    } else if (ps.every((x) => x !== "" && isFinite(+x))) cfg.params = ps.join(",");
  }
  if (t.classList.contains("is-c")) { cfg.colors = (cfg.colors || IND_LINE_COLORS).slice(); cfg.colors[+t.dataset.k] = t.value; }
  if (t.classList.contains("is-w")) cfg.width = +t.value;
  if (t.classList.contains("is-h")) cfg.height = Math.max(60, Math.min(400, +t.value || 110));
  if (t.classList.contains("is-v")) cfg.hidden = !t.checked;
  saveInd(name);
});

// ------------------------------------------------------------------ pengaturan chart (gaya TradingView: Symbol / Tampilan)
const CHART_DEF = { type: "candle_solid", up: COLORS.up, down: COLORS.down, border: true, upBorder: COLORS.up, downBorder: COLORS.down,
  wick: true, upWick: COLORS.up, downWick: COLORS.down, bg: "#0f1218", gridV: true, gridH: true, gridColor: COLORS.grid,
  cross: "dashed", lastLine: true, legend: true };
let CHART_SET = { ...CHART_DEF, ...store.get("chartSet", {}) };
function applyChartSet() {
  const c = CHART_SET;
  chart.setStyles({
    grid: { show: c.gridV || c.gridH, horizontal: { show: c.gridH, color: c.gridColor }, vertical: { show: c.gridV, color: c.gridColor } },
    candle: {
      type: c.type,
      bar: { upColor: c.up, downColor: c.down, noChangeColor: COLORS.muted,
        upBorderColor: c.border ? c.upBorder : c.up, downBorderColor: c.border ? c.downBorder : c.down,
        upWickColor: c.wick ? c.upWick : "rgba(0,0,0,0)", downWickColor: c.wick ? c.downWick : "rgba(0,0,0,0)" },
      area: { lineColor: "#2962ff", backgroundColor: [{ offset: 0, color: "rgba(41,98,255,0.01)" }, { offset: 1, color: "rgba(41,98,255,0.25)" }] },
      priceMark: { last: { show: c.lastLine, upColor: c.up, downColor: c.down, line: { show: c.lastLine } } },
      tooltip: { showRule: c.legend ? "always" : "none" },
    },
    crosshair: { horizontal: { line: { style: c.cross, dashedValue: [4, 4] } }, vertical: { line: { style: c.cross, dashedValue: [4, 4] } } },
  });
  $("chart").style.background = c.bg;
}
function renderChartSet() {
  const c = CHART_SET;
  const col = (k) => `<input type="color" data-cs="${k}" value="${c[k]}">`;
  const chk = (k) => `<input type="checkbox" data-cs="${k}" ${c[k] ? "checked" : ""}>`;
  $("chartSetPanel").innerHTML = `<div class="ind-head"><b>Pengaturan chart</b><button class="mini" data-csa="close">✕</button></div>
    <h4>Candle</h4>
    <label class="is-row">Tipe <select data-cs="type">${[["candle_solid", "Candle"], ["candle_stroke", "Hollow candle"],
      ["candle_up_stroke", "Hollow naik saja"], ["ohlc", "Bar (OHLC)"], ["area", "Line / Area"]]
      .map(([v, t]) => `<option value="${v}" ${c.type === v ? "selected" : ""}>${t}</option>`).join("")}</select></label>
    <label class="is-row">Body (naik / turun) <span>${col("up")} ${col("down")}</span></label>
    <label class="is-row">${chk("border")} Border <span>${col("upBorder")} ${col("downBorder")}</span></label>
    <label class="is-row">${chk("wick")} Wick (ekor) <span>${col("upWick")} ${col("downWick")}</span></label>
    <h4>Tampilan</h4>
    <label class="is-row">Latar ${col("bg")}</label>
    <label class="is-row"><span>${chk("gridV")} Grid vertikal ${chk("gridH")} horizontal</span>${col("gridColor")}</label>
    <label class="is-row">Crosshair <select data-cs="cross"><option value="dashed" ${c.cross === "dashed" ? "selected" : ""}>putus-putus</option>
      <option value="solid" ${c.cross === "solid" ? "selected" : ""}>garis penuh</option></select></label>
    <label class="is-row">${chk("lastLine")} Garis &amp; label harga terakhir</label>
    <label class="is-row">${chk("legend")} Legend OHLC di kiri atas</label>
    <div class="fl-btns"><button class="mini" data-csa="reset">Kembali ke bawaan</button><button class="mini primary" data-csa="close">OK</button></div>`;
}
$("chartSetPanel").addEventListener("input", (e) => {
  const k = e.target.dataset.cs;
  if (!k) return;
  CHART_SET[k] = e.target.type === "checkbox" ? e.target.checked : e.target.value;
  store.set("chartSet", CHART_SET);
  applyChartSet();
});
$("chartSetPanel").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.dataset.csa === "close") $("chartSetPanel").classList.remove("open");
  if (b.dataset.csa === "reset") { CHART_SET = { ...CHART_DEF }; store.set("chartSet", CHART_SET); applyChartSet(); renderChartSet(); }
});
$("btnChartSet").addEventListener("click", (e) => { e.stopPropagation(); $("indPanel").classList.remove("open"); renderChartSet(); $("chartSetPanel").classList.toggle("open"); });
document.addEventListener("click", (e) => { if (e.target.isConnected && !e.target.closest(".popwrap")) $("chartSetPanel").classList.remove("open"); });
applyChartSet();

// ------------------------------------------------------------------ panels
function renderState() {
  const st = S.state;
  if (!st) return;
  $("clock").textContent = fmtTime(st.now) + (st.done ? (st.equity <= 0 ? "  (saldo habis)" : "  (data habis)") : "");
  const rows = [
    ["Saldo", f2(st.balance)], ["Equity", f2(st.equity)],
    ["Posisi", st.position ? `<span class="${cls(st.position)}">${st.position > 0 ? "LONG" : "SHORT"} ${Math.abs(st.position).toPrecision(6)}</span>` : "—"],
    ["Entry", fp(st.entry)], ["Unrealized", `<span class="${cls(st.upnl)}">${f2(st.upnl)}</span>`],
    ...(st.liq != null ? [["Likuidasi", fp(st.liq)]] : []), ["Harga terakhir", fp(st.last_price)], ["Total fee", f2(st.fees)],
  ];
  $("account").innerHTML = rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join("");
  $("ordersTbl").innerHTML = st.orders.length
    ? "<tr><th>#</th><th>Order</th><th>Harga</th><th>Qty</th><th></th></tr>" +
      st.orders.map((o) => `<tr><td>${o.id}</td><td class="${o.side === "buy" ? "pos" : "neg"}">${o.tag && o.tag !== "manual" ? o.tag.toUpperCase() : o.type} ${o.side}</td>
        <td>${o.price ? fp(o.price) : "mkt"}</td><td>${o.qty.toPrecision(5)}</td><td><button data-cancel="${o.id}">×</button></td></tr>`).join("")
    : '<tr><td class="muted">Tidak ada order</td></tr>';
  renderLines();
  renderPreview();
}

function renderTrades(trades, el, limit) {
  const list = [...trades].reverse().slice(0, limit);
  el.innerHTML = list.length
    ? "<tr><th>Masuk</th><th>Sisi</th><th>Entry</th><th>Exit</th><th>PnL</th><th>%</th></tr>" +
      list.map((t) => `<tr><td>${fmtTime(t.entry_time).slice(0, 16)}</td><td class="${t.side === "long" ? "pos" : "neg"}">${t.side}</td>
        <td>${fp(t.entry)}</td><td>${fp(t.exit)}</td><td class="${cls(t.pnl)}">${f2(t.pnl)}</td><td class="${cls(t.pnl)}">${f2(t.return_pct)}</td></tr>`).join("")
    : '<tr><td class="muted">Belum ada trade</td></tr>';
}

// ------------------------------------------------------------------ websocket
function connect() {
  return new Promise((resolve) => {
    const ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws/replay`);
    S.ws = ws;
    ws.onopen = () => { S.wsLost = false; resolve(); };
    ws.onclose = () => {
      if (S.ws !== ws) return;
      S.started = false; S.playing = false; updatePlayBtn();
      for (const [, p] of S.pending) p.resolve({ type: "error", msg: "koneksi putus" });   // jangan ada perintah yang menggantung
      S.pending.clear();
      if (!S.wsLost) toast("Koneksi ke server putus — akan tersambung lagi otomatis saat dipakai.");
      S.wsLost = true;
      resolve();
    };
    ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data);
      const p = S.pending.get(msg.req_id);
      S.pending.delete(msg.req_id);
      if (msg.type === "error") { toast(msg.msg); p && p.resolve(msg); return; }
      onMessage(msg);
      p && p.resolve(msg);
    };
  });
}
async function ensureWs() {
  if (S.ws && S.ws.readyState === WebSocket.OPEN) return true;
  if (S.ws && S.ws.readyState === WebSocket.CONNECTING) await new Promise((ok) => setTimeout(ok, 500));
  if (S.ws && S.ws.readyState === WebSocket.OPEN) return true;
  await connect();                                          // sambung ulang otomatis
  return !!(S.ws && S.ws.readyState === WebSocket.OPEN);
}
function sendRaw(cmd) {
  const req_id = ++S.reqId;
  return new Promise((resolve) => {
    S.pending.set(req_id, { resolve });
    setTimeout(() => { if (S.pending.has(req_id)) { S.pending.delete(req_id); resolve({ type: "error", msg: "server tidak menjawab" }); } }, 60000);
    S.ws.send(JSON.stringify({ ...cmd, req_id }));
  });
}
async function send(cmd) {
  const wasOpen = S.ws && S.ws.readyState === WebSocket.OPEN;
  if (!(await ensureWs())) { toast("Tidak bisa tersambung ke server. Pastikan aplikasi masih berjalan."); return { type: "error", msg: "offline" }; }
  if (cmd.cmd === "start") S.lastStart = { ...cmd };
  else if (!wasOpen && S.lastStart) {                        // sesi baru di server: mulai ulang replay dulu
    toast("Tersambung lagi — replay dimulai ulang dari tanggal mulai.");
    await sendRaw(S.lastStart);
  }
  return sendRaw(cmd);
}

function onMessage(msg) {
  if (msg.type === "history" || msg.type === "struct") return;
  S.state = msg.state;
  if (msg.type === "init") {
    S.tf = msg.tf;
    const bars = msg.bars.map(toK);
    if (msg.forming) bars.push(toK(msg.forming));
    if (bars.length) setPrecision(bars[bars.length - 1].close);
    const space = chart.getBarSpace();   // pertahankan zoom saat mundur / ganti TF
    chart.applyNewData(bars, true);
    if (IND.DORONGAN && IND.DORONGAN.on && !(IND.DORONGAN.params || "").trim()) applyIndicator("DORONGAN");   // default per TF
    if (space) chart.setBarSpace(typeof space === "number" ? space : space.bar);
    S.fills = msg.fills.slice();
    renderTfButtons();
    if (window.CStruct) CStruct.renderMarks();   // tanda candle pilihan ikut pindah TF
  } else {
    for (const b of msg.bars) chart.updateData(toK(b));
    if (msg.forming) chart.updateData(toK(msg.forming));
    for (const e of msg.events) {
      if (e.type === "fill" || e.type === "liquidation") S.fills.push(e);
      if (e.type === "rejected") toast(`Order #${e.order.id} ditolak: ${e.order.note}`);
      if (e.type === "liquidation") toast("Posisi terlikuidasi!");
    }
    playEventSounds(msg.events, msg.trades);
  }
  if (msg.type === "init" || msg.events.some((e) => e.type === "fill" || e.type === "liquidation")) renderMarkers();
  renderState();
  renderTrades(msg.trades, $("tradesTbl"), 30);
  if (msg.state.done && S.playing) { S.playing = false; updatePlayBtn(); }
}

// ------------------------------------------------------------------ controls
function renderTfButtons() {
  const tfs = S.info ? S.info.timeframes : [];
  $("tfButtons").innerHTML = tfs.map((tf) => `<button data-tf="${tf}" class="${tf === S.tf ? "active" : ""}">${tf.toUpperCase()}</button>`).join("");
}

// ---- pilihan periode cepat: dihitung mundur dari akhir data koin terpilih; kalau data lebih pendek, pakai semua data
const PERIODS = [["1 bln", 1], ["2 bln", 2], ["3 bln", 3], ["6 bln", 6], ["1 thn", 12], ["2 thn", 24], ["3 thn", 36],
  ["4 thn", 48], ["5 thn", 60], ["Semua", 0]];
function renderPeriodButtons() {
  document.querySelectorAll(".presets").forEach((el) => {
    el.innerHTML = PERIODS.map(([lb, m]) => `<button type="button" class="mini" data-m="${m}">${lb}</button>`).join("");
    el.onclick = (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      if (!S.info) return toast("Pilih simbol dulu (dipakai untuk tahu rentang datanya)");
      const m = +b.dataset.m, end = S.info.end, first = S.info.start;
      let start = first;
      if (m) {
        const d = new Date(end);
        d.setUTCMonth(d.getUTCMonth() - m);
        start = d.getTime();
        if (start < first) {
          const have = (end - first) / (30.44 * 86400e3);
          toast(`Data ${S.info.symbol} cuma ada ±${have >= 12 ? (have / 12).toFixed(1) + " tahun" : Math.round(have) + " bulan"} → dipakai semua data`);
          start = first;
        }
      }
      $(el.dataset.from).value = toInput(start);
      $(el.dataset.to).value = toInput(end);
      el.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
    };
  });
  ["btFrom", "btTo", "fbFrom", "fbTo", "f2From", "f2To", "itFrom", "itTo", "slFrom", "slTo", "snFrom", "snTo"].forEach((id) => $(id).addEventListener("input", () =>
    $(id).closest(".tabpane, section, body").querySelectorAll(".presets button.on").forEach((x) => x.classList.remove("on"))));
}

async function loadSymbol(sym) {
  const r = await fetch(`/api/symbols/${encodeURIComponent(sym)}`);
  if (!r.ok) { $("symInfo").textContent = "simbol tidak ditemukan"; S.info = null; return false; }
  S.info = await r.json();
  $("symInfo").textContent = `${S.info.timeframes.join(", ")} · ${fmtTime(S.info.start).slice(0, 10)} → ${fmtTime(S.info.end).slice(0, 10)}`;
  const start = Math.min(S.info.start + 30 * 86400e3, S.info.end);
  $("startAt").value = toInput(start);
  $("startAt").min = toInput(S.info.start); $("startAt").max = toInput(S.info.end);
  $("startRange").textContent = `data: ${fmtTime(S.info.start).slice(0, 16)} → ${fmtTime(S.info.end).slice(0, 16)}`;
  $("btFrom").value = toInput(S.info.start);
  $("btTo").value = toInput(S.info.end);
  if (!S.info.timeframes.includes(S.tf)) S.tf = S.info.timeframes[Math.min(2, S.info.timeframes.length - 1)];
  renderTfButtons();
  if (STRATS.length) onStrategyChange();
  store.set("symbol", sym);
  return true;
}

// tanggal mulai replay selalu di dalam data koin ini: paling awal = awal data + 3 hari (supaya chart sudah ada candle)
function startMin() { return Math.min(S.info.start + 3 * 86400e3, S.info.end); }
function clampStart(quiet) {
  if (!S.info) return null;
  const v = fromInput($("startAt").value), lo = startMin(), hi = S.info.end;
  let t = v, why = "";
  if (v == null || !isFinite(v)) { t = Math.min(S.info.start + 30 * 86400e3, hi); why = "kosong"; }
  else if (v < S.info.start) { t = lo; why = `data ${S.info.symbol} baru mulai ${fmtTime(S.info.start).slice(0, 16)}`; }
  else if (v > hi) { t = hi; why = `data ${S.info.symbol} hanya sampai ${fmtTime(hi).slice(0, 16)}`; }
  if (t !== v) {
    $("startAt").value = toInput(t);
    if (!quiet) toast(`Tanggal mulai disesuaikan ke ${fmtTime(t).slice(0, 16)} UTC (${why}).`);
  }
  return t;
}
$("startAt").addEventListener("change", () => clampStart());
$("startFirst").onclick = () => { if (S.info) $("startAt").value = toInput(startMin()); };
$("startLast").onclick = () => { if (S.info) $("startAt").value = toInput(Math.max(startMin(), S.info.end - 86400e3)); };

async function startReplay() {
  if (!S.info) return toast("Pilih simbol dulu");
  S.playing = false; updatePlayBtn();
  const start = clampStart() ?? S.info.start;
  chart.removeOverlay({ groupId: "moment" });                // garis penanda kejadian sebelumnya
  const r = await send({ cmd: "start", symbol: S.info.symbol, start, tf: S.tf, config: config() });
  if (r.type !== "error") {
    S.started = true;
    loadDrawings();
  }
  return r;
}

async function step(base) {
  if (!S.started || S.busy) return;
  S.busy = true;
  try { await send(base ? { cmd: "step_base", n: 1 } : { cmd: "step", n: 1 }); } finally { S.busy = false; }
}

async function stepBack(base) {
  if (!S.started || S.busy) return;
  if (S.playing) { S.playing = false; updatePlayBtn(); }
  S.busy = true;
  try { await send({ cmd: "step_back", n: 1, base }); } finally { S.busy = false; }
}

function updatePlayBtn() { $("btnPlay").textContent = S.playing ? "❚❚ Pause" : "▶ Play"; }
async function togglePlay() {
  if (!S.started) return;
  S.playing = !S.playing;
  updatePlayBtn();
  while (S.playing) {
    await step($("smooth").checked);
    await sleep(+$("speed").value || 0);
  }
}

async function placeOrder() {
  if (!S.started) return toast("Mulai replay dulu");
  const price = +$("price").value || null;
  if (S.type !== "market" && !price) return toast("Isi harga");
  const ref = S.type === "market" ? S.state.last_price : price;
  const z = sizing(ref, +$("sl").value, +$("tp").value, S.type);
  if (z.error) return toast(z.error);
  const qty = z.qty;
  await send({ cmd: "order", side: S.side, type: S.type, qty, price: S.type === "market" ? null : price,
    tp: +$("tp").value || null, sl: +$("sl").value || null, reduce_only: $("reduceOnly").checked });
}

function bindSeg(id, key, attr) {
  $(id).addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    S[key] = b.dataset[attr];
    [...$(id).children].forEach((c) => c.classList.toggle("active", c === b));
    if (key === "type") $("price").disabled = S.type === "market";
  });
}

// ------------------------------------------------------------------ backtest tab
let eqChart = null, eqSeries = null, STRATS = [];
async function loadStrategies() {
  STRATS = await (await fetch("/api/strategies")).json();
  $("btStrategy").innerHTML = STRATS.map((s) => `<option value="${s.name}">${s.name} (${s.timeframe})</option>`).join("");
  onStrategyChange();
  renderSaved();
  gridVisible();
}
const isTfKey = (k) => k === "tf" || k === "htf" || k.endsWith("_tf");
const CHOICES = { entry: [["edge", "mid"], ["retest", "close"]], tp_mode: [["range", "rr"]] };
function onStrategyChange() {
  const s = STRATS.find((x) => x.name === $("btStrategy").value);
  if (!s) return;
  $("btDoc").textContent = s.doc;
  renderParamForm(s, { ...s.params, ...store.get("params:" + s.name, {}) });
}
function renderParamForm(s, values) {
  const tfs = (S.info && S.info.timeframes) || Object.keys(TF_SEC);
  const field = (k, def, v) => {
    if (isTfKey(k)) {
      const opts = (def === "" || k === "confirm_tf" ? [""] : []).concat(tfs);   // confirm_tf boleh kosong
      return `<select data-k="${k}">${opts.map((t) => `<option value="${t}" ${t === v ? "selected" : ""}>${t ? t.toUpperCase() : "— tidak —"}</option>`).join("")}</select>`;
    }
    if (typeof def === "boolean") return `<input type="checkbox" data-k="${k}" ${v ? "checked" : ""}>`;
    if (typeof def === "number") return `<input type="number" step="any" data-k="${k}" value="${v}">`;
    const ch = (s.choices || {})[k] || (CHOICES[k] || []).find((c) => c.includes(def));
    if (ch) return `<select data-k="${k}">${ch.map((o) => `<option ${o === v ? "selected" : ""}>${o}</option>`).join("")}</select>`;
    return `<input type="text" data-k="${k}" value="${String(v).replace(/"/g, "&quot;")}">`;
  };
  const help = s.help || {};
  const LEGACY = { retest: "limit_level", close: "market", edge: "limit_level", mid: "limit_mid" };
  if (values.entry in LEGACY) values = { ...values, entry: LEGACY[values.entry] };   // nilai lama yang tersimpan
  const atr = s.atr_tf || {};
  const HIDE = new Set(["risk_usdt", "risk_pct"]);   // ukuran posisi / uang: bukan urusan backtest teknikal
  $("btForm").innerHTML = Object.entries(s.params).filter(([k]) => !HIDE.has(k)).map(([k, def]) =>
    `<label class="${isTfKey(k) ? "tfrow" : ""}" title="${help[k] || ""}">${k}${atr[k] ? ` <span class="atrtag" data-tfk='${JSON.stringify(atr[k])}'></span>` : ""}</label>${field(k, def, values[k] ?? def)}` +
    (help[k] ? `<div class="phelp">${help[k]}</div>` : "")).join("");
  updateAtrTags();
}
// label "ATR14 · 1H" di parameter yang memakai ATR, ikut berubah kalau TF di formulir diganti
function updateAtrTags() {
  const s = STRATS.find((x) => x.name === $("btStrategy").value);
  const val = (k) => { const el = $("btForm").querySelector(`[data-k="${k}"]`); return el ? el.value : ""; };
  $("btForm").querySelectorAll(".atrtag").forEach((t) => {
    const tf = JSON.parse(t.dataset.tfk).map(val).find(Boolean) || (s && s.default_tf) || "";
    t.textContent = `ATR · ${tf.toUpperCase()}`;
    t.title = `ATR dihitung dari candle ${tf.toUpperCase()}`;
  });
}
function readParams() {
  const s = STRATS.find((x) => x.name === $("btStrategy").value);
  const out = {};
  for (const el of $("btForm").querySelectorAll("[data-k]")) {
    const k = el.dataset.k, def = s.params[k];
    out[k] = el.type === "checkbox" ? el.checked : typeof def === "number" ? +el.value : el.value;
  }
  store.set("params:" + s.name, out);
  return out;
}
async function runBacktest() {
  if (!S.info) return toast("Pilih simbol dulu");
  const params = readParams();
  $("btnRun").disabled = true;
  $("btStatus").textContent = "Menjalankan…";
  const t0 = performance.now();
  $("btMetrics").innerHTML = `<div class="card waiting" style="grid-column:1/-1"><div class="spinner"></div><div style="flex:1">
    <div class="live-title">Menguji ${esc($("btStrategy").value)} di ${esc(S.info.symbol)}<span class="dots"></span></div>
    <div class="progress big run"><div style="width:100%"></div></div>
    <div class="hint" id="btWaitTime">0 dtk</div><div class="tip" id="btWaitTip"></div></div></div>`;
  startTips("btWaitTip", BT_TIPS);
  const waitTimer = setInterval(() => { const el = $("btWaitTime"); if (el) el.textContent = fmtDur((performance.now() - t0) / 1000) + " · memproses candle satu per satu tanpa melihat masa depan"; }, 500);
  try {
    const r = await fetch("/api/backtest", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol: S.info.symbol, strategy: $("btStrategy").value, params,
        start: fromInput($("btFrom").value), end: fromInput($("btTo").value), config: btConfig() }),
    });
    const res = await r.json();
    if (!r.ok) throw new Error(res.detail || r.statusText);
    clearInterval(waitTimer); clearInterval(TIP_TIMERS.btWaitTip);
    $("btStatus").textContent = `Selesai dalam ${((performance.now() - t0) / 1000).toFixed(1)} dtk`;
    showResult(res);
    const ctx = { strategy: $("btStrategy").value, params, symbols: [S.info.symbol],
      start: fromInput($("btFrom").value), end: fromInput($("btTo").value), config: btConfig() };
    renderEval($("btEval"), res.evaluation, ctx);
    const ts = techStats(res.trades);
    setLastRun(ctx, { trades: ts.n, wins: ts.w, losses: ts.l, win_rate: ts.wr }, res.start, res.end,
      { kind: "one", symbol: res.symbol, trades: res.trades, evaluation: res.evaluation, start: res.start, end: res.end });
  } catch (e) {
    $("btStatus").textContent = "";
    $("btMetrics").innerHTML = "";
    toast("Backtest gagal: " + e.message);
  } finally {
    clearInterval(waitTimer); clearInterval(TIP_TIMERS.btWaitTip);
    $("btnRun").disabled = false;
  }
}
// ------------------------------------------------------------------ backtest semua koin
const BA = { id: null, rows: [], next: 0, timer: null, sort: { key: "wr", dir: -1 }, sel: null, summary: null };
const BA_COLS = [["days", "Hari"], ["trades", "Trade"], ["wins", "Menang"], ["losses", "Kalah"], ["wr", "Win %"]];
function scopeChanged() {
  const v = $("btScope").value;
  $("btAllOpts").classList.toggle("hidden", v === "one");
  $("btListWrap").classList.toggle("hidden", v !== "list");
  $("btnRun").textContent = v === "one" ? "Jalankan Backtest" : v === "all" ? "Jalankan di Semua Koin" : "Jalankan di Daftar Koin";
  store.set("btScope", v);
}
async function runBacktestAll() {
  const params = readParams();
  const symbols = $("btScope").value === "list" ? $("btSymbols").value.toUpperCase().split(/[\s,;]+/).filter(Boolean) : null;
  if (symbols && !symbols.length) return toast("Isi daftar koin dulu");
  store.set("btSymbols", $("btSymbols").value);
  const res = await startJob("/api/backtest_all", { strategy: $("btStrategy").value, params, symbols, start: fromInput($("btFrom").value),
    end: fromInput($("btTo").value), config: btConfig(), workers: +$("btWorkers").value || null });
  if (!res) return;
  Object.assign(BA, { id: res.id, rows: [], next: 0, sel: null, summary: null, strategy: $("btStrategy").value,
    ctx: { strategy: $("btStrategy").value, params, symbols, start: fromInput($("btFrom").value),
      end: fromInput($("btTo").value), config: btConfig() } });
  $("btAllEval").classList.add("hidden");
  $("baLive").classList.remove("hidden");
  BA.shownTrades = 0;
  startTips("baTip", BT_TIPS);
  $("btAll").classList.remove("hidden");
  $("btAllCancel").classList.remove("hidden");
  $("btnRun").disabled = true;
  pollAll();
}
async function pollAll() {
  clearTimeout(BA.timer);
  let res;
  try {
    const r = await fetch(`/api/backtest_all/${BA.id}?since=${BA.next}`);
    res = await r.json();
    if (!r.ok) throw new Error(res.detail || r.statusText);
  } catch (e) {
    $("btnRun").disabled = false;
    return toast("Gagal ambil hasil: " + e.message);
  }
  BA.rows.push(...res.rows);
  BA.next = res.next;
  BA.summary = res.summary;
  const pct = res.total ? (100 * res.done) / res.total : 100;
  $("btAllBar").style.width = Math.max(pct, 1) + "%";
  $("btAllProg").classList.toggle("run", res.status === "running");
  const warm = res.done >= Math.min(res.total, 2 * res.workers);   // koin-koin pertama ikut menanggung waktu start proses
  const eta = res.status !== "running" ? "" : warm ? ` · sisa ±${fmtDur((res.elapsed / res.done) * (res.total - res.done))}` : " · sisa menghitung…";
  const st = { running: "berjalan", paused: "⏸️ dijeda", done: "selesai", cancelled: "dibatalkan", error: "error" }[res.status] || res.status;
  $("btAllInfo").textContent = `${BA.strategy} · ${res.done}/${res.total} koin · ${res.workers} proses · ${fmtDur(res.elapsed)}${eta} · ${st}`;
  renderBALive(res, warm);
  renderAllSummary();
  renderAllTable();
  setPauseBtn($("btAllPause"), res);
  if (res.status === "running" || res.status === "paused") {
    $("btnRun").disabled = res.status === "running";
    BA.timer = setTimeout(pollAll, res.status === "paused" ? 2000 : 1000);
  } else {
    $("btnRun").disabled = false;
    $("btAllCancel").classList.add("hidden");
    if (BA.wasPaused) loadPaused();
    if (res.evaluation) renderEval($("btAllEval"), res.evaluation, BA.ctx);
    if (res.status === "done") setLastRun(BA.ctx, res.summary, null, null,
      { kind: "all", rows: BA.rows, summary: res.summary, evaluation: res.evaluation, strategy: BA.strategy });
    if (res.error) toast("Backtest gagal: " + res.error);
    else if (res.status === "done") $("btStatus").textContent = `Selesai: ${res.total} koin dalam ${fmtDur(res.elapsed)}`;
  }
}
const BT_TIPS = [
  "💡 <b>Menang</b> = harga kena TP dulu, <b>kalah</b> = kena SL dulu. Uang, fee dan ukuran posisi tidak dihitung.",
  "💡 Setelah selesai, buka kartu <b>Evaluasi</b>: ada saran presisi entry, SL dan TP dalam ATR.",
  "💡 WR gabungan banyak koin lebih bisa dipercaya daripada satu koin yang kebetulan bagus.",
  "💡 Klik nama koin di tabel untuk melihat daftar trade-nya, lalu klik trade untuk membukanya di Manual Replay.",
  "💡 Saran berlabel <b>lolos uji</b> sudah dicek di 30% data terakhir. Yang <b>tidak konsisten</b> sebaiknya diabaikan.",
  "💡 <b>SL terlalu ketat</b> terlihat dari trade menang yang sempat minus jauh dulu sebelum ke TP.",
];
function renderBALive(res, warm) {
  const s = BA.summary || {};
  const pct = res.total ? (100 * res.done) / res.total : 0;
  $("baPct").textContent = pct > 0 && pct < 10 ? pct.toFixed(1) : Math.floor(pct);
  $("baTitle").innerHTML = res.status === "running" ? (res.done ? `Menguji ${BA.strategy} di ${res.total} koin<span class="dots"></span>` : `Menyiapkan ${res.workers} proses paralel<span class="dots"></span>`)
    : res.status === "done" ? "Selesai! 🎉" : res.status === "cancelled" ? "Dibatalkan" : "Error";
  $("baCoins").textContent = `${res.done}/${res.total}`;
  animateNumber($("baTrades"), BA.shownTrades || 0, s.trades || 0);
  BA.shownTrades = s.trades || 0;
  $("baWins").textContent = (s.wins ?? 0).toLocaleString("id-ID");
  $("baLosses").textContent = (s.losses ?? 0).toLocaleString("id-ID");
  $("baWr").textContent = s.trades ? f2(s.win_rate) + "%" : "—";
  $("baElapsed").textContent = fmtDur(res.elapsed);
  $("baEta").textContent = res.status !== "running" ? "0 dtk" : warm && res.done ? "±" + fmtDur((res.elapsed / res.done) * (res.total - res.done)) : "menghitung…";
  const ok = BA.rows.filter((r) => "trades" in r);
  $("baRecent").innerHTML = BA.rows.slice(-8).reverse().map((r) => `<li><span>${"trades" in r ? (r.trades && r.wr >= 50 ? "🟢" : "🔴") : "⚪"} ${esc(r.symbol)}</span>
    <span class="muted">${"trades" in r ? `${r.trades} trade · WR ${r.trades ? f2(r.wr) + "%" : "—"}` : r.skipped ? "dilewati" : "error"}</span></li>`).join("");
  $("baTop").innerHTML = ok.filter((r) => r.trades >= 5).sort((a, b) => b.wr - a.wr).slice(0, 5)
    .map((r) => `<li><span>${esc(r.symbol)}</span> <span class="muted">WR ${f2(r.wr)}% · ${r.trades}</span></li>`).join("");
  $("baDots").innerHTML = ok.map((r) => `<i class="${!r.trades ? "n" : r.wr >= 50 ? "g" : "r"}" title="${esc(r.symbol)}: ${r.trades} trade, WR ${r.trades ? f2(r.wr) : "—"}%"></i>`).join("");
  if (res.status !== "running") { clearInterval(BA.tipTimer); setTimeout(() => $("baLive").classList.add("hidden"), 2500); }
}
function fmtDur(s) {
  s = Math.round(s);
  return s >= 3600 ? `${Math.floor(s / 3600)} jam ${Math.round((s % 3600) / 60)} mnt` : s >= 60 ? `${Math.floor(s / 60)} mnt ${s % 60} dtk` : `${s} dtk`;
}
function renderAllSummary() {
  const m = BA.summary;
  if (!m) return;
  const items = [
    ["Koin diuji", m.coins], ["Koin WR ≥ 50%", `${m.coins_wr50 ?? 0} (${m.coins ? f2((100 * (m.coins_wr50 || 0)) / m.coins) : "0"}%)`],
    ["Koin ada trade", m.coins_with_trades], ["Total trade", m.trades], ["Menang (TP)", m.wins ?? "—", "pos"], ["Kalah (SL)", m.losses ?? "—", "neg"],
    ["Win rate gabungan", f2(m.win_rate) + "%", m.win_rate >= 50 ? "pos" : ""],
    ["Dilewati / error", `${m.skipped} / ${m.errors}`],
  ];
  $("btAllSum").innerHTML = items.map(([k, v, c]) => `<div class="metric"><div class="k">${k}</div><div class="v ${c || ""}">${v}</div></div>`).join("");
}
function renderAllTable() {
  const q = $("btAllSearch").value.trim().toUpperCase();
  const { key, dir } = BA.sort;
  const val = (r) => (r[key] === undefined ? null : r[key]);
  const rows = BA.rows.filter((r) => !q || r.symbol.includes(q)).sort((a, b) => {
    if (key === "symbol") return dir * a.symbol.localeCompare(b.symbol);
    const x = val(a), y = val(b);
    return x == null ? 1 : y == null ? -1 : x === y ? 0 : dir * (x > y ? 1 : -1);
  });
  const th = (k, label, num) => `<th data-k="${k}" class="${num ? "num" : ""} ${key === k ? "sorted" : ""}" data-dir="${dir > 0 ? "▲" : "▼"}">${label}</th>`;
  const cell = (r, k) => {
    const v = r[k];
    if (k === "wr") return r.trades ? f2(v) : "—";
    if (k === "days" || k === "trades" || k === "wins" || k === "losses") return v ?? "—";
    return f2(v);
  };
  const colored = new Set();
  $("btAllTable").innerHTML = "<tr>" + th("symbol", "Koin") + BA_COLS.map(([k, l]) => th(k, l, true)).join("") + "</tr>" +
    rows.map((r) => `<tr class="${r.symbol === BA.sel ? "sel" : ""}"><td><a class="symlink" data-sym="${r.symbol}">${r.symbol}</a></td>` +
      ("trades" in r
        ? BA_COLS.map(([k]) => `<td class="num ${colored.has(k) ? cls(r[k]) : ""}">${cell(r, k)}</td>`).join("")
        : `<td colspan="${BA_COLS.length}" class="hint">${r.skipped ? "dilewati: " + r.skipped : "error: " + r.error}</td>`) +
      "</tr>").join("");
}
$("btAllTable").addEventListener("click", async (e) => {
  const h = e.target.closest("th");
  if (h) {
    BA.sort = { key: h.dataset.k, dir: BA.sort.key === h.dataset.k ? -BA.sort.dir : h.dataset.k === "symbol" ? 1 : -1 };
    return renderAllTable();
  }
  const a = e.target.closest(".symlink");
  if (!a) return;
  const sym = a.dataset.sym;
  if (!(await loadSymbol(sym))) return toast(`Data ${sym} tidak bisa dibuka`);
  $("symbol").value = sym;
  BA.sel = sym;
  renderAllTable();
  await runBacktest();
  $("btMetrics").scrollIntoView({ behavior: "smooth", block: "start" });
});
function exportAllCsv() {
  const cols = ["symbol", ...BA_COLS.map(([k]) => k), "note"];
  const lines = [cols.join(",")].concat(BA.rows.map((r) =>
    cols.map((k) => (k === "note" ? (r.skipped || r.error || "").replace(/,/g, ";") : r[k] ?? "")).join(",")));
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([lines.join("\n")], { type: "text/csv" }));
  a.download = `backtest_${BA.strategy}_semua_koin.csv`;
  a.click();
}
// ------------------------------------------------------------------ evaluasi strategi
const WIN_LABEL = { win: "Menang (TP)", tp_too_close: "Menang, harga lanjut ≥ 1R setelah TP" };
const LEVEL = { high: "penting", medium: "sedang", low: "minor", good: "bagus", info: "info" };
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
const pfTxt = (x) => (x == null ? "∞" : f2(x));
const paramTxt = (p) => Object.entries(p).map(([k, v]) => `${k}=${v}`).join(", ");
let BT_LAST = null;   // hasil backtest satu koin terakhir (untuk klik trade)

function renderBtTrades(res) {
  BT_LAST = res;
  const cats = (res.evaluation && res.evaluation.cats) || {};
  const why = (t) => (t.diag ? (isWin(t) ? WIN_LABEL[t.diag.cat] : cats[t.diag.cat]) || t.diag.cat : "");
  const tip = (t) => {
    const d = t.diag || {};
    return [d.htf && `struktur TF besar: ${d.htf}`, d.ltf && `struktur TF eksekusi: ${d.ltf}`, d.adx != null && `ADX TF besar ${d.adx}`,
      d.mfe_r != null && `sempat jalan searah ${d.mfe_r}× jarak SL sebelum kena SL`, d.beyond_sl_r != null && `tembus ${d.beyond_sl_r}× jarak SL melewati SL sebelum ke TP`,
      d.cont_r != null && `lanjut ${d.cont_r}× jarak SL setelah TP`].filter(Boolean).join(" · ");
  };
  const list = res.trades.map((t, i) => [t, i]).reverse();
  $("btTrades").innerHTML = list.length
    ? "<tr><th>Masuk</th><th>Sisi</th><th>Entry</th><th>SL</th><th>TP</th><th>Exit</th><th>Hasil</th><th>Evaluasi</th></tr>" +
      list.map(([t, i]) => `<tr data-i="${i}" title="${esc(tip(t))}"><td>${fmtTime(t.entry_time).slice(0, 16)}</td>
        <td class="${t.side === "long" ? "pos" : "neg"}">${t.side}</td><td>${fp(t.entry)}</td><td>${t.sl ? fp(t.sl) : "—"}</td>
        <td>${t.tp ? fp(t.tp) : "—"}</td><td>${fp(t.exit)}</td>
        <td class="${isWin(t) ? "pos" : "neg"}">${t.exit_reason === "tp" ? "✅ TP" : t.exit_reason === "sl" ? "❌ SL" : isWin(t) ? "✅ " + (t.exit_reason || "") : "❌ " + (t.exit_reason || "")}</td>
        <td class="muted">${esc(why(t))}</td></tr>`).join("")
    : '<tr><td class="muted">Belum ada trade</td></tr>';
}
$("btTrades").addEventListener("click", async (e) => {
  const tr = e.target.closest("tr[data-i]");
  if (!tr || !BT_LAST) return;
  const t = BT_LAST.trades[+tr.dataset.i];
  if (!(await loadSymbol(BT_LAST.symbol))) return;
  $("symbol").value = BT_LAST.symbol;
  const tf = BT_LAST.params.tf || BT_LAST.params.confirm_tf;
  if (tf && S.info.timeframes.includes(tf)) S.tf = tf;
  $("startAt").value = toInput(t.signal_time || t.entry_time);
  document.querySelector('.tab[data-tab="replay"]').click();
  await startReplay();
  toast(`Momen sinyal ${t.side} ${fmtTime(t.signal_time || t.entry_time).slice(0, 16)}: entry ${fp(t.entry)}, SL ${t.sl ? fp(t.sl) : "—"}, TP ${t.tp ? fp(t.tp) : "—"}. Step maju untuk melihat kelanjutannya.`);
});

function ctxTable(title, data, order) {
  const keys = order.filter((k) => data && data[k]);
  if (!keys.length) return "";
  return `<div><table class="tbl"><tr><th>${title}</th><th class="num">Trade</th><th class="num">Win %</th></tr>` +
    keys.map((k) => { const r = data[k]; return `<tr><td>${esc(k)}</td><td class="num">${r.n}</td><td class="num">${f2(r.win_rate)}%</td></tr>`; }).join("") + "</table></div>";
}
// ---- analisa mendalam: rencana perbaikan, pola menang vs kalah, timeframe, simulasi TP/SL/entry
const VALID = { true: ["lolos uji", "good"], null: ["perlu diuji", "medium"], false: ["tidak konsisten", "low"] };
const rTxt = (x) => (x == null ? "—" : `${x >= 0 ? "+" : ""}${f2(x)}R`);
function statLine(b, a) {
  if (!b || !a) return "";
  const arrow = (x, y, f) => `${f(x)} → <b class="${y > x ? "pos" : y < x ? "neg" : ""}">${f(y)}</b>`;
  return `WR ${arrow(b.win_rate, a.win_rate, (v) => f2(v) + "%")}` +
    (a.n != null ? ` · ${b.n ?? "?"} → ${a.n} trade` : "");
}
function renderDeep(ev, ctx) {
  const d = ev.deep, plan = ev.plan || [];
  if (!d) return { plan: "", detail: "" };
  if (!d.enough) return { plan: `<h4>Rencana perbaikan</h4><p class="hint">${esc(d.message || "")}</p>`, detail: "" };
  const span = `data latih = 50% trade pertama, validasi = 20% berikutnya, <b>uji = 30% trade terakhir</b> (${fmtDate(d.split.valid_end)} → akhir), tidak dipakai untuk mencari saran`;
  const steps = plan.map((s) => {
    const [vt, vc] = VALID[s.valid];
    return `<div class="sugg ${vc}"><div class="t"><span class="lv">${vt}</span>${s.step}. ${esc(s.title)}</div>
      <div class="d">${esc(s.why)}</div>
      <ul class="how">${s.how.map((h) => `<li><code>${esc(h)}</code></li>`).join("")}</ul>
      <div class="e">${s.kind === "existing" ? "Dekat batas vs sisanya" : "Data uji"}: ${statLine(s.before, s.after)}</div>
      ${s.fit_before ? `<div class="e">Data latih: ${statLine(s.fit_before, s.fit_after)}</div>` : ""}
      ${s.note ? `<div class="e">${esc(s.note)}</div>` : ""}
      <div class="tries"><button class="mini plan-use" data-p='${esc(JSON.stringify(s.param))}'>Pakai di formulir</button>
        <span>${esc(paramTxt(s.param))}</span></div></div>`;
  }).join("");
  const none = !plan.some((s) => s.valid);
  const planHtml = `<h4>Rencana perbaikan (apa yang harus diubah)</h4>
    <p class="hint">Dicari dari ${d.n} trade (${span}). Hanya saran berlabel <b>lolos uji</b> yang terbukti membaik juga di data uji.</p>
    ${none ? `<div class="sugg info"><div class="t">Belum ada perubahan yang konsisten</div><div class="d">Tidak ada filter / TP / SL / entry yang
      membaik di data latih <i>dan</i> data uji sekaligus. Biasanya karena trade masih sedikit (coba semua koin / periode lebih panjang),
      atau ide entry-nya memang belum punya keunggulan. Lihat pola di bawah sebagai bahan ide.</div></div>` : ""}
    ${steps}`;

  const feats = d.features.filter((f) => f.strength !== "tidak ada").slice(0, 12);
  const featHtml = feats.length ? `<table class="tbl"><tr><th>Indikator</th><th>Pembeda</th><th>Konsisten</th><th>Pola</th></tr>` +
    feats.map((f) => `<tr><td title="${esc(f.desc)}"><code>${esc(f.name)}</code><br><span class="muted">${esc(f.label)}</span></td>
      <td>${f.strength} (${f2(Math.abs(f.auc - 0.5) * 200)})</td><td>${f.stable ? "✔ dua periode" : "✖ berubah-ubah"}</td><td>${esc(f.text)}</td></tr>`).join("") + "</table>"
    : '<p class="hint">Tidak ada indikator yang membedakan trade menang & kalah.</p>';
  const tfHtml = `<table class="tbl"><tr><th>Timeframe</th><th class="num">Kekuatan</th><th class="num">Fitur konsisten</th><th>Pembeda terkuat</th></tr>` +
    d.timeframes.map((t) => `<tr><td>${t.tf.toUpperCase()}</td><td class="num">${f2(t.power * 200)}</td><td class="num">${t.n_stable}</td><td>${esc(t.best)}</td></tr>`).join("") + "</table>";

  const g = d.grid;
  const heat = (tb) => {
    if (!tb) return "";
    const ri = g.rr.reduce((b, r, i) => (Math.abs(r - (g.rr_now || 2)) < Math.abs(g.rr[b] - (g.rr_now || 2)) ? i : b), 0);
    return `<div class="scroll"><table class="tbl heat"><tr><th>SL × \\ TP (RR)</th>${g.rr.map((r) => `<th class="num">${r}</th>`).join("")}</tr>` +
      g.k.map((k, a) => `<tr><th>SL × ${k}</th>${g.rr.map((r, i) => {
        const w = tb.win_rate[a][i];
        const bg = w >= 50 ? `rgba(38,166,154,${Math.min(0.55, (w - 50) / 60)})` : `rgba(239,83,80,${Math.min(0.55, (50 - w) / 60)})`;
        return `<td class="num ${k === 1 && i === ri ? "now" : ""}" style="background:${bg}" title="SL × ${k}, TP ${r}× jarak SL: WR ${f2(w)}%">${f2(w)}%</td>`;
      }).join("")}</tr>`).join("") + "</table></div>";
  };
  const depthHtml = `<table class="tbl"><tr><th>Entry lebih dalam</th><th class="num">Terisi</th><th class="num">WR (terisi)</th><th class="num">WR data uji</th></tr>
    <tr class="base"><td>Sekarang</td><td class="num">100%</td><td class="num">${f2(d.base.all.win_rate)}%</td><td class="num">${f2(d.base.test.win_rate)}%</td></tr>` +
    d.depth.map((x) => `<tr><td>${x.x} × jarak SL</td><td class="num">${f2(x.fill_pct)}%</td><td class="num">${f2(x.win_rate)}%</td>
      <td class="num">${x.test && x.test.win_rate != null ? f2(x.test.win_rate) + "%" : "—"}</td></tr>`).join("") + "</table>";
  const tried = d.rules_tried.length ? `<h4>Filter yang dicoba tapi ditolak (bagus di data latih, gagal di validasi)</h4><ul class="hint">` +
    d.rules_tried.map((r) => `<li><code>${esc(r.text)}</code>: latih WR ${f2(r.train.win_rate)}% → validasi WR ${f2(r.valid.win_rate)}%</li>`).join("") + "</ul>" : "";
  const mfe = d.mfe_pct.length ? `<p class="hint">Sebelum kena SL: ${[1, 2, 3, 4].map((i) => `${d.mfe_pct[i] ?? 0}% trade kalah sempat jalan searah ${i * 0.5}× jarak SL`).join(" · ")}.</p>` : "";
  const detail = `<details class="deep"><summary><h4>Analisa mendalam: pola menang vs kalah, timeframe, simulasi</h4></summary>
    <h4>Pola kesalahan: indikator yang membedakan trade menang & kalah</h4>
    <p class="hint">Diukur saat sinyal (candle yang sudah close) di beberapa TF. "Searah" = dilihat dari arah trade. Pembeda 0 = tidak ada beda, 100 = pembeda sempurna.
      Pakai nama di kolom pertama untuk parameter <code>rules</code>, mis. <code>${esc(feats[0] ? feats[0].name : "rsi@1h")} >= …</code>.</p>${featHtml}
    <h4>Timeframe paling berpengaruh</h4>${tfHtml}
    <h4>Simulasi TP / SL (semua trade)</h4><p class="hint">Tiap sel: win rate & R per trade kalau SL dikali × dan TP = RR × jarak SL. Kotak bergaris = setting sekarang.
      TP & SL di candle yang sama dihitung kalah.</p>${heat(g.all)}
    ${g.rules ? `<h4>Simulasi TP / SL setelah filter baru</h4>${heat(g.rules)}` : ""}
    <h4>Simulasi entry limit lebih dalam (SL & TP tetap)</h4>${depthHtml}${mfe}${tried}</details>`;
  return { plan: planHtml, detail };
}

// presisi entry / SL / TP dalam ATR TF eksekusi (teknikal, tanpa uang)
function precisionBlock(p) {
  if (!p) return "";
  const tf = String(p.tf).toUpperCase();
  const slState = p.win_mae80 == null ? "" : p.sl_atr < 0.9 * p.win_mae80 ? "⚠️ terlalu ketat" : p.win_mae90 && p.sl_atr > 1.6 * p.win_mae90 ? "ℹ️ lebih jauh dari yang dibutuhkan" : "✅ wajar";
  const entryState = p.win_mae50 == null ? "" : p.win_mae50 >= 0.5 ? "⚠️ kurang presisi" : p.win_mae50 >= 0.3 ? "ℹ️ bisa lebih presisi" : "✅ presisi";
  return `<h4>🎯 Presisi entry / SL / TP <span class="hint">(dalam ATR ${tf}, dari ${p.n} trade)</span></h4><ul class="prec">
    <li><b>Entry</b> ${entryState}: separuh trade yang kena TP sempat minus ≤ ${p.win_mae50 ?? "—"} ATR dulu setelah entry (80%: ≤ ${p.win_mae80 ?? "—"} ATR).</li>
    <li><b>SL</b> ${slState}: rata-rata ${f2(p.sl_atr)} ATR dari entry. Supaya 80% trade yang benar tidak ikut kena SL, butuh ≥ ${p.win_mae80 ?? "—"} ATR.</li>
    <li><b>TP</b>: rata-rata ${f2(p.tp_atr)} ATR dari entry. Trade yang kalah, separuhnya sempat jalan searah ≥ ${p.loss_mfe50 ?? "—"} ATR sebelum berbalik ke SL.</li></ul>`;
}
function renderEval(el, ev, ctx) {
  if (!ev) { el.classList.add("hidden"); return; }
  el.classList.remove("hidden");
  el._ev = ev;
  el._ctx = ctx;
  const multi = ctx.symbols == null || ctx.symbols.length > 1;
  const sugg = ev.suggestions.map((s) => `<div class="sugg ${s.level}"><div class="t"><span class="lv">${LEVEL[s.level] || s.level}</span>${esc(s.title)}</div>
    <div class="d">${esc(s.detail)}</div>${s.evidence ? `<div class="e">${esc(s.evidence)}</div>` : ""}
    ${s.try.length ? `<div class="tries">${s.try.map((v) => `<span title="${esc(paramTxt(v.params))}">coba: ${esc(v.label)} (${esc(paramTxt(v.params))})</span>`).join("")}</div>` : ""}</div>`).join("")
    || '<p class="hint">Tidak ada masalah menonjol yang terdeteksi.</p>';
  const maxShare = Math.max(1, ...ev.loss_causes.map((c) => Math.max(c.share, c.random || 0)));
  const causes = ev.loss_causes.length
    ? `<div class="causes">` + ev.loss_causes.map((c) => `<div title="${esc(c.desc)}">${esc(c.label)}</div>
      <div class="bar" title="${c.random != null ? `garis putih = normalnya kalau harga bergerak acak (${f2(c.random)}% dari trade kena SL)` : ""}"><i style="width:${(100 * c.share) / maxShare}%"></i>${c.random != null ? `<b style="left:${(100 * c.random) / maxShare}%"></b>` : ""}</div>
      <div class="num">${c.n} (${c.share.toFixed(0)}%)</div>`).join("") + "</div>"
    : '<p class="hint">Tidak ada trade kalah.</p>';
  const tc = ev.tp_cont || {};
  const extra = [
    ev.avg_mfe_loss_r != null && `Trade kalah rata-rata sempat jalan searah ${f2(ev.avg_mfe_loss_r)}× jarak SL sebelum kena SL`,
    tc.n && `Setelah TP: ${tc.more}/${tc.n} trade masih lanjut sejauh jarak SL lagi`,
    `Kalah beruntun terpanjang: ${ev.max_streak}`,
    ev.missed && `Limit kadaluarsa: ${ev.missed} (${ev.missed_win} harga lanjut ke TP, ${ev.missed_loss} akan kena SL)`,
  ].filter(Boolean).map((x) => `<li>${esc(x)}</li>`).join("");
  const c = ev.context || {};
  const tags = Object.keys(ev.tags || {});
  const deep = renderDeep(ev, ctx);
  el.innerHTML = `<h3>Evaluasi strategi <span class="hint">TF eksekusi ${ev.exec_tf.toUpperCase()} · TF besar ${ev.htf.toUpperCase()} · ${ev.trades} trade${multi ? " (gabungan semua koin)" : ""}</span></h3>
    <p class="hint">Dianalisa dari pergerakan harga sesudah tiap trade (apa yang terjadi setelah kena SL/TP). Ini hanya untuk evaluasi; strategi sendiri tetap tidak melihat data masa depan.</p>
    ${precisionBlock(ev.precision)}
    ${deep.plan}
    <h4>Catatan dari penyebab kalah</h4>${sugg}
    ${ev.variants.length ? `<div class="evalbtns"><button class="primary ev-run">Uji saran (${ev.variants.length} variasi${multi ? " × semua koin" : ""})</button>
      <span class="hint ev-status"></span><button class="mini ev-cancel hidden">Batal</button></div><div class="varres"></div>` : ""}
    <h4>Penyebab trade kalah</h4>${causes}
    <h4>Kondisi saat entry</h4><div class="ctxgrid">
      ${ctxTable(`Struktur ${ev.htf.toUpperCase()}`, c.f_htf, ["searah", "netral", "melawan"])}
      ${ctxTable(`Struktur ${ev.exec_tf.toUpperCase()}`, c.f_ltf, ["searah", "netral", "melawan"])}
      ${ctxTable(`ADX ${ev.htf.toUpperCase()}`, c.f_adx, ["> 25", "20-25", "< 20"])}
      ${ctxTable("Sisi", c.sides, ["long", "short"])}
      ${tags.length ? ctxTable("Tag / konfluensi", ev.tags, tags) : ""}</div>
    <h4>Lainnya</h4><ul class="hint">${extra}</ul>${deep.detail}`;
  el.querySelectorAll(".plan-use").forEach((b) => (b.onclick = () => applyThreshold(ctx.strategy, JSON.parse(b.dataset.p))));
  const run = el.querySelector(".ev-run");
  if (run) run.onclick = () => runVariants(el);
  const cancel = el.querySelector(".ev-cancel");
  if (cancel) cancel.onclick = () => el._job && fetch(`/api/backtest_all/${el._job}/cancel`, { method: "POST" });
}
async function runVariants(el, variants = el._ev.variants, ctx = el._ctx) {
  el._ctx = ctx;
  const res = await startJob("/api/backtest_all", { ...ctx, variants, workers: +$("btWorkers").value || null });
  if (!res) return;
  el._job = res.id;
  el.querySelector(".ev-run").disabled = true;
  el.querySelector(".ev-cancel").classList.remove("hidden");
  const poll = async () => {
    const st = await (await fetch(`/api/backtest_all/${res.id}`)).json();
    el.querySelector(".ev-status").textContent = `${st.done}/${st.total} backtest${ctx.baseline === false ? ` di ${coinsTxt(ctx.symbols)}` : ""} · ${fmtDur(st.elapsed)}` +
      (st.status === "running" ? "" : st.status === "done" ? " · selesai" : " · " + st.status);
    renderVariants(el, st.by_label || {}, ctx);
    if (st.status === "running") return setTimeout(poll, 1000);
    el.querySelector(".ev-run").disabled = false;
    el.querySelector(".ev-cancel").classList.add("hidden");
  };
  poll();
}
function renderVariants(el, by, ctx) {
  const base = by["Sekarang"];
  const multi = ctx.symbols == null || ctx.symbols.length > 1;
  const d = (v, b, good) => (b == null || v == null ? "" : ` <span class="${(v - b) * good > 0 ? "pos" : (v - b) * good < 0 ? "neg" : ""}">(${v - b >= 0 ? "+" : ""}${f2(v - b)})</span>`);
  const cmp = ctx.baseline === false;   // membandingkan threshold tersimpan: urutkan menurut win rate
  const rows = Object.entries(by).sort((a, b) => (cmp ? (b[1].win_rate || 0) - (a[1].win_rate || 0) : 0));
  const bestWr = cmp && rows.length ? rows[0][0] : null;
  el.querySelector(".varres").innerHTML = `<table class="tbl"><tr><th>${cmp ? "Threshold" : "Variasi"}</th><th>${cmp ? "Beda dari default" : "Perubahan"}</th><th class="num">Trade</th>` +
    `<th class="num">Menang</th><th class="num">Kalah</th>` + (multi ? `<th class="num">Koin WR ≥ 50%</th>` : "") + `<th class="num">Win %</th><th></th></tr>` +
    rows.map(([label, s]) => `<tr class="${label === "Sekarang" ? "base" : ""}"><td>${label === bestWr ? "🏆 " : ""}${esc(label)}</td><td class="muted">${esc(paramTxt(paramDiff(s.params, ctx.params))) || "—"}</td>
      <td class="num">${s.trades}</td><td class="num pos">${s.wins ?? "—"}</td><td class="num neg">${s.losses ?? "—"}</td>
      ${multi ? `<td class="num">${s.coins_wr50 ?? 0}/${s.coins}</td>` : ""}
      <td class="num"><b>${f2(s.win_rate)}%</b>${label === "Sekarang" ? "" : d(s.win_rate, base && base.win_rate, 1)}</td>
      <td>${label === "Sekarang" ? "" : `<button class="mini ev-apply" data-p='${esc(JSON.stringify(s.params))}'>Pakai</button>`}</td></tr>`).join("") +
    `</table><p class="hint">Hasil variasi diuji di data yang sama; hati-hati overfitting, cek lagi di periode / koin lain sebelum dipakai.</p>`;
  el.querySelectorAll(".ev-apply").forEach((b) => (b.onclick = () => {
    const s = STRATS.find((x) => x.name === ctx.strategy);
    if ($("btStrategy").value !== ctx.strategy) { $("btStrategy").value = ctx.strategy; onStrategyChange(); }
    renderParamForm(s, { ...readParams(), ...JSON.parse(b.dataset.p) });
    readParams();
    toast("Parameter variasi dipasang di formulir. Klik Jalankan untuk melihat hasil lengkapnya.");
  }));
}

// ------------------------------------------------------------------ threshold: copy / paste / simpan / bandingkan
let LAST_RUN = null;
let SAVED = [];
const paramDiff = (p, base) => Object.fromEntries(Object.entries(p || {}).filter(([k, v]) => !base || base[k] !== v));
const fmtDate = (ms) => (ms ? new Date(ms).toISOString().slice(0, 10) : "awal");
const costTxt = (c) => (!c ? "" : c.taker_fee || c.maker_fee || c.slippage_bps ? " · +fee" : " · teknikal");
const coinsTxt = (syms) => (syms == null ? "semua koin" : syms.length === 1 ? syms[0] : `${syms.length} koin`);

function setLastRun(ctx, m, start, end, detail) {
  const multi = ctx.symbols == null || ctx.symbols.length > 1;
  LAST_RUN = { ...ctx, start: ctx.start ?? start ?? null, end: ctx.end ?? end ?? null,
    metrics: { trades: m.trades, win_rate: m.win_rate, wins: m.wins, losses: m.losses,
      coins: multi ? m.coins : null, coins_wr50: multi ? m.coins_wr50 : null }, detail };
  $("btnSave").disabled = false;
  if ($("btAutoSave").checked) saveCurrent(true);
}
function resultTxt(m, syms, start, end) {
  if (!m) return "";
  return `# hasil: ${coinsTxt(syms)} ${fmtDate(start)} → ${fmtDate(end)} · ${m.trades} trade · ` +
    (m.wins != null ? `menang ${m.wins} · kalah ${m.losses} · ` : "") + `WR ${f2(m.win_rate)}%` +
    (m.coins ? ` · ${m.coins_wr50 ?? 0}/${m.coins} koin WR ≥ 50%` : "");
}
function thresholdText(strategy, params, extra = "") {
  return [`# threshold ${strategy} (Futures Replay)`, extra, `strategy = ${strategy}`]
    .concat(Object.entries(params).map(([k, v]) => `${k} = ${v}`)).filter(Boolean).join("\n");
}
function parseThreshold(text) {
  text = text.trim();
  let strategy = null, params = {};
  if (text.startsWith("{")) {
    const o = JSON.parse(text);
    strategy = o.strategy || null;
    params = o.params || Object.fromEntries(Object.entries(o).filter(([k]) => k !== "strategy"));
  } else {
    for (const line of text.split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][\w]*)\s*[:=]\s*(.*?)\s*$/);
      if (!m || line.trim().startsWith("#")) continue;
      if (m[1] === "strategy") strategy = m[2];
      else params[m[1]] = m[2];
    }
  }
  return { strategy, params };
}
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);   // butuh https / localhost
  } catch {
    const ta = document.createElement("textarea");   // cadangan untuk HP lewat http://IP
    ta.value = text;
    ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
}
function copyCurrent() {
  const s = $("btStrategy").value, params = readParams();
  const same = LAST_RUN && LAST_RUN.strategy === s && JSON.stringify(LAST_RUN.params) === JSON.stringify(params);
  copyText(thresholdText(s, params, same ? resultTxt(LAST_RUN.metrics, LAST_RUN.symbols, LAST_RUN.start, LAST_RUN.end) : ""))
    .then(() => toast("Threshold disalin. Tempel di catatan / chat, atau pakai tombol paste untuk memuat lagi."));
}
function applyThreshold(strategy, params) {
  if (strategy && strategy !== $("btStrategy").value) {
    if (!STRATS.some((x) => x.name === strategy)) return toast(`Strategi ${strategy} tidak ada`);
    $("btStrategy").value = strategy;
    onStrategyChange();
  }
  const s = STRATS.find((x) => x.name === $("btStrategy").value);
  const vals = readParams(), unknown = [];
  for (const [k, v] of Object.entries(params)) {
    if (!(k in s.params)) { unknown.push(k); continue; }
    const def = s.params[k];
    vals[k] = typeof def === "boolean" ? v === true || String(v).toLowerCase() === "true"
      : typeof def === "number" ? +v : String(v);
  }
  renderParamForm(s, vals);
  readParams();
  toast("Threshold dimuat ke formulir" + (unknown.length ? ` (diabaikan: ${unknown.join(", ")})` : ""));
}
async function loadSaved() {
  SAVED = await (await fetch("/api/thresholds")).json();
  renderSaved();
}
function renderSaved() {
  const cur = $("btStrategy").value, all = $("btSavedFilter").value === "all";
  const list = SAVED.filter((x) => all || x.strategy === cur).sort((a, b) => (b.metrics?.win_rate ?? -1) - (a.metrics?.win_rate ?? -1));
  $("btSavedCount").textContent = `(${SAVED.length})`;
  const best = list.length ? list[0].id : null;
  const defs = (name) => (STRATS.find((x) => x.name === name) || {}).params;
  $("btSavedTable").innerHTML = list.length
    ? `<tr><th></th><th>Nama</th>${all ? "<th>Strategi</th>" : ""}<th>Dites di</th><th class="num">Trade</th><th class="num">Win %</th>
      <th>Beda dari default</th><th></th></tr>` +
      list.map((x) => { const m = x.metrics || {}; return `<tr data-id="${x.id}" class="${x.id === best ? "best" : ""}">
        <td><input type="checkbox" class="pick"></td><td class="nm" title="Klik 2x untuk ganti nama · ${esc(new Date(x.created).toLocaleString())}">${esc(x.name)}</td>
        ${all ? `<td>${esc(x.strategy)}</td>` : ""}<td class="muted">${esc(coinsTxt(x.symbols))}<br>${fmtDate(x.start)} → ${fmtDate(x.end)}</td>
        <td class="num">${m.trades ?? "—"}</td><td class="num wr">${m.win_rate == null ? "—" : f2(m.win_rate)}</td>
        <td class="chg">${esc(paramTxt(paramDiff(x.params, defs(x.strategy)))) || "default"}</td>
        <td class="act"><button class="mini view">Lihat</button><button class="mini use">Pakai</button><button class="mini cp">Copy</button><button class="mini del">Hapus</button></td></tr>`; }).join("")
    : '<tr><td class="muted">Belum ada threshold tersimpan. Jalankan backtest lalu klik 💾 Simpan threshold + hasil.</td></tr>';
}
// buka lagi hasil lengkap threshold yang disimpan, persis seperti saat backtest selesai (formulir + hasil)
async function viewSaved(x) {
  const r = await fetch(`/api/thresholds/${x.id}/detail`);
  const det = r.ok ? await r.json() : null;
  // 1) formulir kiri: strategi, parameter, periode, pilihan koin, simbol
  const st = STRATS.find((q) => q.name === x.strategy);
  if (st) {
    $("btStrategy").value = x.strategy;
    $("btDoc").textContent = st.doc;
    renderParamForm(st, { ...st.params, ...x.params });
    readParams();
    gridVisible();
    renderSaved();
  }
  $("btFrom").value = x.start ? toInput(x.start) : "";
  $("btTo").value = x.end ? toInput(x.end) : "";
  const syms = x.symbols;
  $("btScope").value = syms == null ? "all" : syms.length === 1 ? "one" : "list";
  if (syms && syms.length > 1) $("btSymbols").value = syms.join(", ");
  scopeChanged();
  if (syms && syms.length === 1 && (!S.info || S.info.symbol !== syms[0]) && (await loadSymbol(syms[0]))) $("symbol").value = syms[0];
  $("btSavedView").classList.add("hidden");
  const when = new Date(x.created).toLocaleString("id-ID");
  if (!det) {
    $("btStatus").textContent = `📂 "${x.name}" disimpan sebelum v3.18: hasil lengkap tidak ada. Klik Jalankan untuk menghitung ulang.`;
    toast("Threshold dimuat. Hasil lengkapnya tidak tersimpan (versi lama), klik Jalankan untuk menghitung ulang.");
    return;
  }
  const ctx = { strategy: x.strategy, params: x.params, symbols: syms, start: x.start, end: x.end, config: btConfig() };
  // 2) hasil: sama seperti saat backtest selesai
  if (det.kind === "all") {
    clearTimeout(BA.timer);
    Object.assign(BA, { id: null, rows: det.rows || [], next: 0, sel: null, summary: det.summary, strategy: x.strategy, ctx });
    $("btMetrics").innerHTML = "";
    $("btEval").classList.add("hidden");
    $("btTrades").innerHTML = "";
    $("btAll").classList.remove("hidden");
    $("baLive").classList.add("hidden");
    $("btAllCancel").classList.add("hidden");
    const n = (det.rows || []).length;
    $("btAllInfo").textContent = `${x.strategy} · ${n}/${n} koin · selesai`;
    renderAllSummary();
    renderAllTable();
    if (det.evaluation) renderEval($("btAllEval"), det.evaluation, ctx); else $("btAllEval").classList.add("hidden");
    $("btStatus").textContent = `📂 Hasil tersimpan "${x.name}" (disimpan ${when})`;
    $("btAll").scrollIntoView({ behavior: "smooth", block: "start" });
  } else {
    $("btAll").classList.add("hidden");
    showResult({ symbol: det.symbol, trades: det.trades || [], evaluation: det.evaluation, params: x.params });
    if (det.evaluation) renderEval($("btEval"), det.evaluation, { ...ctx, symbols: [det.symbol] }); else $("btEval").classList.add("hidden");
    $("btStatus").textContent = `📂 Hasil tersimpan "${x.name}" (disimpan ${when})`;
    $("btMetrics").scrollIntoView({ behavior: "smooth", block: "start" });
  }
  LAST_RUN = { ...ctx, metrics: x.metrics, detail: det };
}
async function saveCurrent(auto = false) {
  if (!LAST_RUN) return;
  const r = LAST_RUN, m = r.metrics;
  const def = `${r.strategy} · WR ${f2(m.win_rate)}% · ${coinsTxt(r.symbols)}`;
  const name = auto ? `${def} · otomatis ${new Date().toLocaleString("id-ID")}` : prompt("Nama threshold:", def);
  if (name === null) return;
  const res = await fetch("/api/thresholds", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: name || def, strategy: r.strategy, params: r.params, symbols: r.symbols,
      start: r.start, end: r.end, metrics: m, config: r.config, detail: r.detail }) });
  if (!res.ok) return toast("Gagal menyimpan");
  await loadSaved();
  $("btSaved").open = true;
  toast(auto ? "💾 Hasil disimpan otomatis (lihat 📂 Threshold tersimpan)" : "Threshold + hasil disimpan");
  if (auto) $("btnSave").disabled = true;
}
$("btSavedTable").addEventListener("click", async (e) => {
  const tr = e.target.closest("tr[data-id]");
  if (!tr) return;
  const x = SAVED.find((s) => s.id === tr.dataset.id);
  if (e.target.classList.contains("view")) viewSaved(x);
  if (e.target.classList.contains("use")) applyThreshold(x.strategy, x.params);
  if (e.target.classList.contains("cp")) copyText(thresholdText(x.strategy, x.params, `# ${x.name}\n` + resultTxt(x.metrics, x.symbols, x.start, x.end))).then(() => toast("Threshold disalin"));
  if (e.target.classList.contains("del") && confirm(`Hapus "${x.name}"?`)) {
    await fetch(`/api/thresholds/${x.id}`, { method: "DELETE" });
    loadSaved();
  }
});
$("btSavedTable").addEventListener("dblclick", async (e) => {
  const td = e.target.closest("td.nm");
  if (!td) return;
  const x = SAVED.find((s) => s.id === td.parentElement.dataset.id);
  const name = prompt("Nama baru:", x.name);
  if (!name) return;
  await fetch(`/api/thresholds/${x.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name }) });
  loadSaved();
});
function compareSaved() {
  const ids = [...$("btSavedTable").querySelectorAll("tr[data-id]")].filter((tr) => tr.querySelector(".pick").checked).map((tr) => tr.dataset.id);
  const picked = SAVED.filter((x) => ids.includes(x.id));
  if (!picked.length) return toast("Centang dulu threshold yang mau dibandingkan");
  const strat = picked[0].strategy;
  if (picked.some((x) => x.strategy !== strat)) return toast("Yang dibandingkan harus strategi yang sama");
  if ($("btStrategy").value !== strat) { $("btStrategy").value = strat; onStrategyChange(); }
  const scope = $("btScope").value;
  if (scope === "one" && !S.info) return toast("Pilih simbol dulu");
  const symbols = scope === "one" ? [S.info.symbol] : scope === "list" ? $("btSymbols").value.toUpperCase().split(/[\s,;]+/).filter(Boolean) : null;
  const used = new Set();
  const variants = picked.map((x) => { let l = x.name; while (used.has(l) || l === "Sekarang") l += " ·"; used.add(l); return { label: l, params: x.params }; });
  runVariants($("btSaved"), variants, { strategy: strat, params: { ...STRATS.find((x) => x.name === strat).params }, symbols,
    start: fromInput($("btFrom").value), end: fromInput($("btTo").value), config: btConfig(), baseline: false });
}

// hasil teknikal: kena TP = menang, kena SL = kalah (exit lain dinilai dari arah harga). Uang tidak ditampilkan.
const isWin = (t) => (t.exit_reason === "tp" ? true : t.exit_reason === "sl" ? false : (t.side === "long" ? t.exit > t.entry : t.exit < t.entry));
function techStats(trades) {
  const w = trades.filter(isWin).length, n = trades.length;
  const side = (sd) => { const x = trades.filter((t) => t.side === sd); const ww = x.filter(isWin).length; return { n: x.length, w: ww, wr: x.length ? (100 * ww) / x.length : null }; };
  const other = trades.filter((t) => t.exit_reason !== "tp" && t.exit_reason !== "sl").length;
  return { n, w, l: n - w, wr: n ? (100 * w) / n : 0, long: side("long"), short: side("short"), other };
}
function showResult(res) {
  const s = techStats(res.trades);
  let streak = 0, maxL = 0;
  for (const t of res.trades) { streak = isWin(t) ? 0 : streak + 1; maxL = Math.max(maxL, streak); }
  const items = [
    ["Trade", s.n], ["Menang (kena TP)", s.w, "pos"], ["Kalah (kena SL)", s.l, "neg"], ["Win rate", f2(s.wr) + "%", s.wr >= 50 ? "pos" : ""],
    ["WR Long", s.long.wr == null ? "—" : `${f2(s.long.wr)}% (${s.long.n})`], ["WR Short", s.short.wr == null ? "—" : `${f2(s.short.wr)}% (${s.short.n})`],
    ["Kalah beruntun terpanjang", maxL], ...(s.other ? [["Keluar lain (akhir tes)", s.other]] : []),
  ];
  $("btMetrics").innerHTML = items.map(([k, v, c]) => `<div class="metric"><div class="k">${k}</div><div class="v ${c || ""}">${v}</div></div>`).join("");
  $("equityChart").classList.add("hidden");
  renderBtTrades(res);
}

// ------------------------------------------------------------------ proses berat (semua koin / studi): satu sekaligus
async function startJob(url, body) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const res = await r.json().catch(() => ({}));
    if (r.ok) return res;
    const d = res.detail;
    if (r.status === 409 && d && d.busy && attempt === 0) {
      if (!confirm(`${d.msg}\n\nSupaya RAM tidak habis, hanya satu proses yang boleh jalan sekaligus.\nBatalkan proses itu lalu jalankan yang baru?`)) return null;
      await fetch("/api/running/cancel", { method: "POST" });
      await new Promise((ok) => setTimeout(ok, 1500));
      continue;
    }
    toast("Gagal: " + (typeof d === "string" ? d : (d && d.msg) || r.statusText));
    return null;
  }
  return null;
}
// ---- jeda / lanjutkan proses berat (backtest semua koin, studi fibonacci v1/v2, cari angka fibo terbaik)
async function jobAction(kind, id, act) {
  const r = await fetch(`/api/job/${kind}/${id}/${act}`, { method: "POST" });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { toast("Gagal: " + ((j.detail && j.detail.msg) || j.detail || r.statusText)); return false; }
  return true;
}
// tombol jeda: status running -> "⏸️ Jeda"; paused -> "▶️ Lanjutkan" (atau "menjeda…" kalau koin terakhir masih dihitung)
function setPauseBtn(el, st) {
  if (!el) return;
  const show = st.status === "running" || st.status === "paused";
  el.classList.toggle("hidden", !show);
  el.dataset.st = st.status;
  el.disabled = st.status === "paused" && st.inflight > 0;
  el.textContent = st.status !== "paused" ? "⏸️ Jeda" : st.inflight > 0 ? `⏳ Menjeda… menunggu ${st.inflight} koin selesai` : "▶️ Lanjutkan";
}
function bindPauseBtn(el, kind, getId, after) {
  el.onclick = async () => {
    const id = getId();
    if (!id) return;
    const act = el.dataset.st === "paused" ? "resume" : "pause";
    el.disabled = true;
    if (await jobAction(kind, id, act)) {
      toast(act === "pause" ? "⏸️ Dijeda. Koin yang sedang dihitung diselesaikan dulu; hasil yang sudah ada aman." : "▶️ Dilanjutkan dari koin yang belum selesai");
      if (after) after(act);
    }
    el.disabled = false;
    loadPaused();
  };
}
function attachBacktest(j) {
  if (!j.req) return toast(`${j.label}: tampilan tidak bisa disambungkan (proses lama).`);
  Object.assign(BA, { id: j.id, rows: [], next: 0, sel: null, summary: null, strategy: j.strategy, ctx: j.req });
  $("btAll").classList.remove("hidden");
  $("baLive").classList.remove("hidden");
  $("btAllCancel").classList.remove("hidden");
  $("btnRun").disabled = true;
  pollAll();
}
function attachGrid(j) {
  GR.id = j.id;
  GR.strategy = j.strategy || GR.strategy;
  gridPanel();
  pollGrid();
}
function attachJob(kind, j) {
  if (kind === "fib" || kind === "fib2") FIBS[kind === "fib2" ? 2 : 1].resume(j);
  else if (kind === "backtest") attachBacktest(j);
  else if (kind === "grid") attachGrid(j);
  else if (kind === "snrtest") attachSnr(j);
  else if (kind === "stratlab") attachStratLab(j);
  else if (kind === "indtester") attachIndTest(j);
}
const TAB_OF = { backtest: "backtest", variants: "backtest", grid: "backtest", fib: "fib", fib2: "fib2",
  snrtest: "snrtest", stratlab: "stratlab", indtester: "indtest", msa: "msa" };
// halaman dibuka / di-refresh saat proses masih berjalan: sambungkan lagi tampilannya
async function resumeRunning() {
  loadPaused();
  const { busy } = await (await fetch("/api/running")).json();
  if (!busy) return;
  if (["fib", "fib2", "grid", "snrtest", "stratlab", "indtester"].includes(busy.kind) || (busy.kind === "backtest" && busy.req)) {
    attachJob(busy.kind, busy);
    toast(`${busy.label} masih berjalan (${busy.done}/${busy.total} koin) — tampilan disambungkan lagi.`);
  } else {
    toast(`${busy.label} masih berjalan (${busy.done}/${busy.total}). Proses baru bisa dijalankan setelah selesai atau dibatalkan.`);
  }
}
// daftar proses yang dijeda (tetap ada walau aplikasi ditutup): lanjutkan / buang
async function loadPaused() {
  let list = [];
  try { list = await (await fetch("/api/paused")).json(); } catch (e) { return; }
  const bar = $("pausedBar");
  bar.classList.toggle("hidden", !list.length);
  bar.innerHTML = list.map((j) => `<div class="pz" data-kind="${j.kind}" data-id="${j.id}">
      <span>⏸️ <b>${esc(j.label)}</b> dijeda · ${j.done}/${j.total} koin selesai${j.paused_at ? ` · ${new Date(j.paused_at).toLocaleString("id-ID")}` : ""}
      ${j.draining ? ` · <i>menunggu ${j.inflight} koin terakhir selesai…</i>` : ""}</span>
      <button class="mini primary pz-go" ${j.draining ? "disabled" : ""}>▶️ Lanjutkan</button>
      <button class="mini pz-open">Lihat</button>
      <button class="mini pz-del">🗑️ Buang</button></div>`).join("");
  bar.querySelectorAll(".pz").forEach((row) => {
    const kind = row.dataset.kind, id = row.dataset.id, j = list.find((x) => x.id === id);
    const k = kind === "variants" ? "backtest" : kind;
    const show = () => document.querySelector(`.tab[data-tab="${TAB_OF[kind]}"]`).click();
    row.querySelector(".pz-go").onclick = async () => {
      if (!(await jobAction(k, id, "resume"))) return;
      show();
      attachJob(k, j);
      toast("▶️ Dilanjutkan dari koin yang belum selesai");
      loadPaused();
    };
    row.querySelector(".pz-open").onclick = () => { show(); attachJob(k, j); };
    row.querySelector(".pz-del").onclick = async () => {
      if (!confirm(`Buang "${j.label}" (${j.done}/${j.total} koin)? Hasil yang sudah dihitung ikut hilang.`)) return;
      await jobAction(k, id, "cancel");
      loadPaused();
    };
  });
}
function workersHint(c) {
  return `${c.recommended} (otomatis${c.ram_free_gb ? ` · RAM bebas ${c.ram_free_gb} GB` : ""})`;
}

// ------------------------------------------------------------------ cari angka fibo terbaik (BreakoutFibo)
const GR = { id: null, timer: null, res: null };
function gridVisible() {
  const st = STRATS.find((x) => x.name === $("btStrategy").value);
  $("btnGrid").classList.toggle("hidden", !(st && st.fib_grid));
}
async function runGrid() {
  const scope = $("btScope").value;
  if (scope === "one" && !S.info) return toast("Pilih simbol dulu");
  const symbols = scope === "one" ? [S.info.symbol] : scope === "list" ? $("btSymbols").value.toUpperCase().split(/[\s,;]+/).filter(Boolean) : null;
  const res = await startJob("/api/fibgrid", { strategy: $("btStrategy").value, params: readParams(), symbols,
    start: fromInput($("btFrom").value), end: fromInput($("btTo").value), config: btConfig(), workers: +$("btWorkers").value || null });
  if (!res) return;
  GR.id = res.id;
  GR.strategy = $("btStrategy").value;
  gridPanel();
  pollGrid();
}
function gridPanel() {
  $("btnGrid").disabled = true;
  $("btGridOut").classList.remove("hidden");
  $("btGridOut").innerHTML = `<h3>🔎 Cari angka fibo terbaik</h3><div class="progress big run"><div id="grBar"></div></div><p class="hint" id="grStatus">Menyiapkan…</p>
    <button class="mini hidden" id="grPause">⏸️ Jeda</button> <button class="mini" id="grCancel">Batal</button>`;
  $("grCancel").onclick = () => fetch(`/api/fibgrid/${GR.id}/cancel`, { method: "POST" });
  bindPauseBtn($("grPause"), "grid", () => GR.id, () => { clearTimeout(GR.timer); pollGrid(); });
  $("btGridOut").scrollIntoView({ behavior: "smooth", block: "start" });
}
async function pollGrid() {
  clearTimeout(GR.timer);
  const st = await (await fetch(`/api/fibgrid/${GR.id}`)).json();
  const bar = $("grBar");
  if (bar) bar.style.width = Math.max(1, st.total ? (100 * st.done) / st.total : 100) + "%";
  if ($("grStatus")) $("grStatus").textContent = `${st.done}/${st.total} koin · ${st.setups.toLocaleString("id-ID")} setup · ${fmtDur(st.elapsed)}${st.status === "paused" ? " · ⏸️ dijeda" : ""}`;
  setPauseBtn($("grPause"), st);
  if (st.status === "running" || st.status === "paused") { GR.timer = setTimeout(pollGrid, st.status === "paused" ? 2000 : 1000); return; }
  $("btnGrid").disabled = false;
  if (st.error) { toast("Gagal: " + st.error); return; }
  GR.res = st.result;
  renderGrid();
}
const GR_SIDE_ICON = { bull: "🟢", bear: "🔴", all: "⚪" };
function gridConclusion(sd, one) {
  const c = one && one.conclusion;
  const head = sd === "bull" ? "🟢 <b>Bullish koreksi</b> (harga turun dulu → <b>BUY</b>)" : "🔴 <b>Bearish koreksi</b> (harga naik dulu → <b>SELL</b>)";
  if (!c) return `<div class="gr-concl"><p>${head}</p><p class="hint">Data belum cukup (butuh ≥ 30 trade & entry tersentuh ≥ 20% setup).</p></div>`;
  const nm = c.entry === "conf" ? "FVG / S/R" : c.entry;
  const tp = (x) => `<b>${x.tp}</b> (WR ${f2(x.win_rate)}%)`;
  let tps = "—";
  if (c.tp_most) tps = (c.tp_most.win_rate >= 50 ? `biasanya sampai ${tp(c.tp_most)}` : `paling sering sampai ${tp(c.tp_most)}, belum ada yang ≥ 50%`)
    + (c.tp_often ? `, kadang lanjut ke ${tp(c.tp_often)}` : "");
  const ok = c.valid ? "✅ konsisten di data uji" : "⚠️ belum konsisten di data uji";
  return `<div class="gr-concl"><p>${head}</p>
    <p>📍 Entry presisi terbaik: <b>${nm}</b> — harga pullback/retest ke sini di <b>${f2(c.fill_pct)}%</b> setup · WR ${f2(c.wr_rr)}% (TP RR 1:2)
      · data uji ${c.test_wr_rr == null ? "—" : f2(c.test_wr_rr) + "%"} · ${ok}</p>
    <p>🎯 TP dari entry ${nm}: ${tps}</p>
    <button class="mini gr-use" data-s="${sd}" data-e="${c.entry}" data-t="${(c.tp_most || { tp: "RR 1:2" }).tp}">Pakai entry ${nm} + TP ini</button></div>`;
}
function gridSideBody(one, sd) {
  if (!one || !one.n) return '<p class="hint">Tidak ada setup di kondisi ini.</p>';
  const name = (e) => (e === "conf" ? "FVG / S/R" : e);
  const cell = (e, tp) => one.rows.find((x) => String(x.entry) === String(e) && x.tp === tp);
  const per = (one.per_tp || []).map((x) => `<li>TP <b>${x.tp}</b> → entry terbaik <b>${name(x.entry)}</b>: WR ${f2(x.win_rate)}% (${x.trades} trade, tersentuh ${f2(x.fill_pct)}%)
    · data uji ${x.test_win_rate == null ? "—" : f2(x.test_win_rate) + "%"} · <b>${x.valid ? "konsisten" : "tidak konsisten"}</b>
    <button class="mini gr-use" data-s="${sd}" data-e="${x.entry}" data-t="${x.tp}">Pakai</button></li>`).join("");
  const matrix = `<div class="scroll"><table class="tbl heat"><tr><th>Entry \\ TP</th>${one.tps.map((t) => `<th class="num">${t}</th>`).join("")}</tr>` +
    one.entries.map((e) => `<tr><th>${name(e)}</th>${one.tps.map((t) => {
      const x = cell(e, t);
      if (!x) return "<td>—</td>";
      const w = x.win_rate, bg = w >= 50 ? `rgba(38,166,154,${Math.min(0.55, (w - 50) / 60)})` : `rgba(239,83,80,${Math.min(0.55, (50 - w) / 60)})`;
      return `<td style="background:${bg}" title="tersentuh ${f2(x.fill_pct)}% setup · ${x.trades} trade · data uji WR ${x.test_win_rate == null ? "—" : f2(x.test_win_rate) + "%"}">${f2(w)}%${x.valid ? " ✔" : ""}<br><small>${x.trades} trade</small></td>`;
    }).join("")}</tr>`).join("") + "</table></div>";
  return `<details><summary>Entry terbaik per target TP</summary><ul>${per}</ul></details>
    <h4>Semua kombinasi <span class="hint">${one.n.toLocaleString("id-ID")} setup</span></h4>${matrix}`;
}
function renderGrid() {
  const r = GR.res;
  if (!r || !r.n) { $("btGridOut").innerHTML = `<h3>🔎 Cari angka fibo terbaik</h3><p class="hint">Tidak ada setup yang ditemukan.</p>`; return; }
  const sides = r.sides || {};
  GR.side = GR.side || "bull";
  const tabs = ["bull", "bear", "all"].map((sd) => {
    const one = sd === "all" ? r : sides[sd];
    const lbl = sd === "bull" ? "Bullish → BUY" : sd === "bear" ? "Bearish → SELL" : "Gabungan";
    return `<button class="mini gr-tab${GR.side === sd ? " on" : ""}" data-s="${sd}">${GR_SIDE_ICON[sd]} ${lbl} <small>(${((one && one.n) || 0).toLocaleString("id-ID")})</small></button>`;
  }).join(" ");
  const cur = GR.side === "all" ? r : sides[GR.side];
  $("btGridOut").innerHTML = `<h3>🔎 Cari angka fibo terbaik <span class="hint">${GR.strategy} · ${r.n.toLocaleString("id-ID")} setup · SL ${r.params.sl_atr} × ATR</span></h3>
    <div class="gr-sum">${gridConclusion("bull", sides.bull)}${gridConclusion("bear", sides.bear)}</div>
    <p class="hint">Sideways tidak ada: BreakoutFibo hanya entry searah tren H1 (koreksi searah tren). Untuk sideways lihat tab <b>Studi Fibonacci</b> → bagian breakout.
      Angka fibo: 1 = awal swing, 0 = ujung swing, minus = lewat ujung swing (BUY: di atas high, SELL: di bawah low).</p>
    <div class="gr-tabs">${tabs}</div>
    <p class="hint">Warna = WR, bukan arah: <span style="background:rgba(38,166,154,.45);padding:0 4px">hijau ≥ 50%</span>
      <span style="background:rgba(239,83,80,.45);padding:0 4px">merah &lt; 50%</span> · ✔ = konsisten di data uji.
      Presisi entry dibandingkan adil di kolom <b>RR 1:2</b>.</p>
    ${gridSideBody(cur, GR.side)}`;
  $("btGridOut").querySelectorAll(".gr-tab").forEach((b) => (b.onclick = () => { GR.side = b.dataset.s; renderGrid(); }));
  $("btGridOut").querySelectorAll(".gr-use").forEach((b) => (b.onclick = () => {
    const e = b.dataset.e, t = b.dataset.t, sd = b.dataset.s;
    const prm = {};
    if (sd === "bear") {                                  // angka SELL sendiri, angka BUY tidak diubah
      prm.sell_same = false;
      if (e === "conf") prm.entry_at = "confluence"; else { prm.entry_at = "fib"; prm.entry_fib_sell = +e; }
      if (t === "RR 1:2") Object.assign(prm, { tp_mode: "tp1", tp1_rr: 2 }); else Object.assign(prm, { tp_mode: "tp2", tp2_level_sell: +t });
    } else {
      if (sd === "all") prm.sell_same = true;
      if (e === "conf") prm.entry_at = "confluence"; else { prm.entry_at = "fib"; prm.entry_fib = +e; }
      Object.assign(prm, t === "RR 1:2" ? { tp_mode: "tp1", tp1_rr: 2 } : { tp_mode: "tp2", tp2_level: +t });
    }
    applyThreshold(GR.strategy, prm);
    toast(sd === "bear" ? "Dipasang ke angka SELL (sell_same mati)" : sd === "bull" ? "Dipasang ke angka BUY" : "Dipasang untuk BUY & SELL");
  }));
}

// ------------------------------------------------------------------ studi fibonacci (v1 & v2: kode tampilan sama, beda set angka fibo)
const FIB_TIPS = [
  "💡 <b>0.618</b> sering disebut <i>golden ratio</i>. Studi ini mengecek apakah benar lebih sering memantul di sana dibanding level lain.",
  "💡 <b>Tersentuh</b> = ekor candle sampai level. <b>Tembus</b> = candle <b>close</b> melewati level. Wick bukan breakout.",
  "💡 Level alarm berguna untuk tahu kapan <b>berhenti</b> buy the dip: setelah close tembus level itu, struktur biasanya patah.",
  "💡 <b>Respek</b> = setelah harga menyentuh level, berapa persen yang memantul sampai ujung swing tanpa menembus level terlalu dalam.",
  "💡 Hasil dicek di <b>30% data terakhir</b> yang tidak dipakai untuk memilih level, supaya bukan kebetulan.",
  "💡 Fibo baru dihitung setelah swing <b>terkonfirmasi</b>, sama seperti saat kamu menarik fibo di chart live. Tidak ada intip masa depan.",
  "💡 Bandingkan beberapa TF (M5, M15, H1): level terbaik bisa berbeda per timeframe.",
  "💡 Kondisi pasar dipisah: level terbaik saat <b>bullish</b> bisa beda dengan saat <b>sideways</b>.",
  "💡 Extension <b>1.272</b> dan <b>1.618</b> setelah BOS cocok jadi target TP untuk posisi arah sebaliknya.",
];
const TIP_TIMERS = {};
function startTips(id = "fbTip", tips = FIB_TIPS) {
  clearInterval(TIP_TIMERS[id]);
  let i = Math.floor(Math.random() * tips.length);
  const show = () => { const el = $(id); if (!el) return; el.style.opacity = 0; setTimeout(() => { el.innerHTML = tips[i++ % tips.length]; el.style.opacity = 1; }, 400); };
  show();
  TIP_TIMERS[id] = setInterval(show, 9000);
  if (id === "baTip") BA.tipTimer = TIP_TIMERS[id];
}
function animateNumber(el, from, to, ms = 900) {
  const t0 = performance.now();
  const step = (t) => { const k = Math.min(1, (t - t0) / ms); el.textContent = Math.round(from + (to - from) * (1 - (1 - k) ** 3)).toLocaleString("id-ID");
    if (k < 1) requestAnimationFrame(step); };
  requestAnimationFrame(step);
}
function makeFib(V) {
  const FBP = V === 2 ? "f2" : "fb", SUF = V === 2 ? "2" : "", FORM_KEY = V === 2 ? "fb2Form" : "fbForm";
  const TITLE = V === 2 ? "Studi Fibonacci v2" : "Studi Fibonacci";
  const DEF = V === 2 ? { tf: "5m", regime_tf: "1h", trend_tf: "1h" } : { tf: "15m", regime_tf: "4h", trend_tf: "1h" };
  const PANE = document.getElementById(V === 2 ? "tab-fib2" : "tab-fib");
  const $ = (id) => document.getElementById(V === 2 && id.startsWith("fb") ? "f2" + id.slice(2) : id);
  const FB = { id: null, timer: null, res: null, group: "all" };
  function fbScopeChanged() { $("fbListWrap").classList.toggle("hidden", $("fbScope").value !== "list"); }
  function fbParams() {
    return { tf: $("fbTf").value, regime_tf: $("fbRegTf").value, trend_tf: $("fbTrendTf").value, swing: +$("fbSwing").value, min_leg_atr: +$("fbMinLeg").value,
      adx_min: +$("fbAdx").value, sl_buffer_atr: +$("fbSlBuf").value, max_bars: +$("fbMaxBars").value,
      ...(V === 2 ? { ema_fast: +$("fbEmaFast").value || 50, ema_slow: +$("fbEmaSlow").value || 200 } : {}) };
  }
  async function runFib() {
    const scope = $("fbScope").value;
    if (scope === "one" && !S.info) return toast("Pilih simbol dulu");
    const symbols = scope === "one" ? [S.info.symbol] : scope === "list" ? $("fbSymbols").value.toUpperCase().split(/[\s,;]+/).filter(Boolean) : null;
    store.set(FORM_KEY, { ...fbParams(), scope, symbols: $("fbSymbols").value });
    const res = await startJob(`/api/fibstudy${SUF}`, { params: fbParams(), symbols, start: fromInput($("fbFrom").value), end: fromInput($("fbTo").value),
      workers: +$("fbWorkers").value || null });
    if (!res) return;
    FB.id = res.id;
    FB.reqSymbols = symbols;
    FB.shownLegs = 0;
    $("fbRun").disabled = true;
    $("fbCancel").classList.remove("hidden");
    $("fbOut").classList.remove("hidden");
    $("fbLive").classList.remove("hidden");
    $("fbBody").innerHTML = "";
    if ($("fbFlow")) $("fbFlow").innerHTML = "";
    $("fbGroups").innerHTML = "";
    $("fbRecent").innerHTML = "";
    $("fbTop").innerHTML = "";
    $("fbPreview").textContent = "Menunggu koin pertama selesai…";
    startTips(FBP + "Tip");
    if (window.innerWidth < 900) $("fbOut").scrollIntoView({ behavior: "smooth", block: "start" });
    pollFib();
  }
  function renderFibLive(st) {
    const pct = st.total ? (100 * st.done) / st.total : 0;
    $("fbPct").textContent = pct < 10 && pct > 0 ? pct.toFixed(1) : Math.floor(pct);
    $("fbBar").style.width = Math.max(pct, 1) + "%";
    $("fbTitle").innerHTML = st.status === "running"
      ? (st.done ? `Menganalisa Fibonacci di ${st.total} koin<span class="dots"></span>` : `Menyiapkan ${st.workers} proses paralel<span class="dots"></span>`)
      : st.status === "done" ? "Selesai! 🎉" : st.status === "cancelled" ? "Dibatalkan" : "Error";
    $("fbCoins").textContent = `${st.done}/${st.total}`;
    animateNumber($("fbLegs"), FB.shownLegs || 0, st.legs);
    FB.shownLegs = st.legs;
    $("fbRate").textContent = st.rate_min == null ? "—" : st.rate_min.toFixed(1);
    $("fbElapsed").textContent = fmtDur(st.elapsed);
    $("fbEta").textContent = st.status !== "running" ? "0 dtk" : st.eta == null ? "menghitung…" : "±" + fmtDur(st.eta);
    $("fbWorkersN").textContent = st.workers;
    $("fbRecent").innerHTML = st.recent.map((r) => `<li><span>${r.error ? "⚠️" : "✅"} ${esc(r.symbol)}</span><span class="muted">${r.legs.toLocaleString("id-ID")} gel · ${r.seconds ?? "?"} dtk</span></li>`).join("");
    $("fbTop").innerHTML = st.top.map((r) => `<li><span>${esc(r.symbol)}</span> <span class="muted">${r.legs.toLocaleString("id-ID")}</span></li>`).join("");
    const g = st.preview && st.preview.groups && st.preview.groups[0];
    if (g && g.n) {
      const a = g.advice || {};
      $("fbPreview").innerHTML = `<div class="pv"><span class="hd">Level</span><span class="hd">Tersentuh</span><span></span><span class="hd">WR → 0 (TP di ujung setup)</span><span></span>` +
        g.levels.filter((x) => x.level < 1).map((x) => `<b>${x.level}</b><div class="bar"><i style="width:${x.touch}%"></i></div><span>${f2(x.touch)}%</span>
          <div class="bar w"><i style="width:${x.wr_0 ?? 0}%"></i></div><span>${x.wr_0 == null ? "—" : f2(x.wr_0) + "%"}</span>`).join("") + "</div>" +
        `<div style="margin-top:6px">${a.alarm ? `🚨 Sementara: close tembus <b>${a.alarm.level}</b> → ${f2(a.alarm.bos_pct)}% jadi BOS. ` : ""}` +
        `${a.limit ? `🎯 Sementara: limit terbaik <b>${a.limit.level}</b> (TP ${a.limit.target}).` : ""}</div>`;
    }
  }
  async function pollFib() {
    clearTimeout(FB.timer);
    const st = await (await fetch(`/api/fibstudy${SUF}/${FB.id}`)).json();
    renderFibLive(st);
    const eta = st.status === "running" && st.eta != null ? ` · sisa ±${fmtDur(st.eta)}` : "";
    $("fbStatus").textContent = `${st.done}/${st.total} koin · ${st.legs.toLocaleString("id-ID")} setup · ${fmtDur(st.elapsed)}${eta}` +
      (st.status === "running" ? "" : st.status === "done" ? " · selesai" : st.status === "paused" ? " · ⏸️ dijeda" : " · " + st.status) + (st.errors.length ? ` · ${st.errors.length} error` : "");
    setPauseBtn($("fbPause"), st);
    if (st.status === "running" || st.status === "paused") {
      $("fbRun").disabled = st.status === "running";
      FB.timer = setTimeout(pollFib, st.status === "paused" ? 2000 : 1000);
      return;
    }
    clearInterval(TIP_TIMERS[FBP + "Tip"]);
    setTimeout(() => $("fbLive").classList.add("hidden"), st.status === "done" ? 1500 : 0);
    $("fbRun").disabled = false;
    $("fbCancel").classList.add("hidden");
    if (st.error) return toast("Studi gagal: " + st.error);
    FB.res = st.result;
    FB.opened = null;
    FB.meta = { symbols: FB.reqSymbols, start: fromInput($("fbFrom").value), end: fromInput($("fbTo").value), coins: st.done };
    renderFib();
    if (st.status === "done" && FB.res && FB.res.n && $("fbAutoSave").checked) saveFib(true);
  }
  const lvTxt = (x) => (x === 0 ? "0" : String(x));
  function fbPrice(x, d) { return d < 0 ? 100 + x * 100 : 200 - x * 100; }   // contoh setup 100 -> 200 (naik) / 200 -> 100 (turun)
  // ---- kesimpulan sederhana per kondisi pasar
  // Fibo selalu ditarik searah setup: 0 = ujung setup, 1.0 = titik awal. Contoh harga pakai setup 100 & 200.
  function concPrice(level, side) { return side === "BUY" ? 200 - level * 100 : 100 + level * 100; }
  const concHow = (side) => side === "BUY"
    ? "Tarik fibo dari swing LOW → swing HIGH (0 = high, 1 = low). Koreksi turun, entry BUY. Contoh 100 → 200."
    : "Tarik fibo dari swing HIGH → swing LOW (0 = low, 1 = high). Koreksi naik, entry SELL. Contoh 200 → 100.";
  function concItemLines(it) {
    const px = (lv) => f2(concPrice(lv, it.side));
    if (!it.entry) return [`Belum ada entry yang konsisten untung dengan TP1 yang dicapai ≥ 60% trade${it.n < 30 ? ` (setup baru ${it.n})` : ""}.`];
    const L = [
      `Entry retest terbaik: limit ${it.side} di ${it.entry} (contoh ${px(it.entry)}) · terisi di ${f2(it.fill_pct)}% setup`,
      `TP1: ${it.tp1.level} (contoh ${px(it.tp1.level)}) · dicapai ${f2(it.tp1.pct)}% trade`,
      it.tp2 ? `TP2: ${it.tp2.level} (contoh ${px(it.tp2.level)}) · dicapai ${f2(it.tp2.pct)}% trade` : "TP2: — (tidak ada level yang dicapai ≥ 35% trade)",
      it.avg != null ? `Rata-rata (median) pantulan sampai: ${f2(it.avg)} (contoh ${px(it.avg)})${it.avg < 0 ? `, lewat ${it.side === "BUY" ? "high" : "low"} terakhir` : ""}` : "",
      ...slLines(it, px),
      it.test ? `Data uji (30% terakhir): TP1 tercapai ${f2(it.test.wr_tp1)}%` : "",
      it.alarm ? `🚨 Batal/berhenti ${it.side}: kalau candle close tembus ${it.alarm.level} (contoh ${px(it.alarm.level)}), ${f2(it.alarm.bos_pct)}% jadi BOS` : "",
      it.alarm && it.alarm.level <= it.entry ? `⚠️ Level alarm (${it.alarm.level}) sama / lebih dangkal dari entry (${it.entry}): setelah limit terisi, kalau ada candle CLOSE melewati ${it.alarm.level}, pertimbangkan cut lebih awal tanpa menunggu SL` : "",
      it.after_bos ? `📍 Setelah BOS, ${f2(it.after_bos.pct)}% sampai ${it.after_bos.level} (contoh ${px(it.after_bos.level)}): target posisi arah sebaliknya` : "",
    ];
    return L.filter(Boolean);
  }
  // SL hasil uji (studi v3.11+): terbaik = R/trade tertinggi, aman = paling longgar dengan hasil >= 80% dari terbaik
  function slLines(it, px) {
    if (it.sl_k) return [`SL: ${it.side === "SELL" ? "di atas" : "di bawah"} entry sejauh ${it.sl_k} × ATR`];
    const sl = it.sl;
    if (!sl || !sl.rows) return [`SL: di luar level 1.0 (contoh ${px(1)}) + buffer ATR`];
    const row = (lv) => sl.rows.find((r) => r.level === lv);
    if (!sl.best) return [`SL: tidak ada letak SL yang untung untuk entry ini (lihat tabel uji SL)`];
    const b = row(sl.best), s = row(sl.safe);
    const t = (r) => `WR ${f2(r.win_rate)}% · uji: WR ${r.test_win_rate == null ? "—" : f2(r.test_win_rate) + "%"}`;
    const L = [`SL terbaik: fibo ${b.level} (contoh ${px(b.level)}) · ${t(b)}`];
    if (s && s.level !== b.level) L.push(`SL aman (lebih longgar, tahan sweep): fibo ${s.level} (contoh ${px(s.level)}) · ${t(s)}`);
    return L;
  }
  function slTable(it, px) {
    const sl = it.sl;
    if (!sl || !sl.rows) return "";
    return `<details class="sltab"><summary>Lihat uji semua letak SL</summary><table class="tbl"><tr><th>SL di fibo</th><th class="num">Contoh</th>
      <th class="num">WR</th><th class="num">WR uji</th></tr>` +
      sl.rows.map((r) => `<tr class="${r.level === sl.best ? "best" : r.level === sl.safe ? "safe" : ""}"><td><b>${r.level}</b>${r.level === sl.best ? " ⭐ terbaik" : r.level === sl.safe ? " 🛡️ aman" : ""}</td>
        <td class="num">${px(r.level)}</td><td class="num">${f2(r.win_rate)}%</td>
        <td class="num">${r.test_win_rate == null ? "—" : f2(r.test_win_rate) + "%"}</td></tr>`).join("") +
      `</table><p class="hint">Entry & TP tetap (TP1), SL digeser. TP & SL di candle yang sama dihitung kena SL.</p></details>`;
  }

  // ---- kekuatan level fibo (tanpa RR): sering tersentuh? respek (pantul ke 0)? S/R flip? pantulan sampai mana? SL ATR?
  const pc = (x) => (x == null ? "—" : f2(x) + "%");
  function powerLines(pw, side, tf) {
    if (!pw) return ["Data belum cukup untuk mengukur kekuatan level (butuh minimal 30 setup per level)."];
    const px = (lv) => f2(concPrice(lv, side));
    const b = pw.best, up = b.respect_conf != null && b.respect_noconf != null ? b.respect_conf - b.respect_noconf : null;
    return [
      pw.zone ? `Pullback paling sering berhenti di zona ${pw.zone.lo}–${pw.zone.hi} (${f2(pw.zone.pct)}% setup)` : "",
      `⭐ Level terkuat: ${b.level} (contoh ${px(b.level)}) · tersentuh ${pc(b.touch)} setup · respek ${pc(b.respect)} (memantul sampai 0)` +
        (pw.test_respect != null ? ` · data uji ${pc(pw.test_respect)}` : ""),
      `🛡️ SL oke: level ${side === "BUY" ? "−" : "+"} ${pw.k} × ATR ${String(tf).toUpperCase()} (melindungi ±80% pantulan dari tusukan / sweep)`,
      up != null ? `S/R flip (resistance jadi support${side === "SELL" ? " / support jadi resistance" : ""}) di level ${b.level}: respek ${pc(b.respect_conf)} vs tanpa ${pc(b.respect_noconf)} → ${up >= 3 ? `menambah kekuatan (+${f2(up)}%)` : up <= -3 ? `justru lebih lemah (${f2(up)}%)` : "tidak banyak beda"}` : "",
      pw.best_conf && pw.best_conf.level !== b.level ? `Dengan S/R flip, level paling respek: ${pw.best_conf.level} (${pc(pw.best_conf.respect_conf)})` : "",
      b.reach_med != null ? `Rata-rata pantulan sampai: ${f2(b.reach_med)} (contoh ${px(b.reach_med)})${b.reach_med <= 0.02 ? ` — sampai/lewat ${side === "BUY" ? "high" : "low"} terakhir` : ""}` : "",
    ].filter(Boolean);
  }
  function powerTable(pw, side) {
    if (!pw) return "";
    const px = (lv) => f2(concPrice(lv, side));
    return `<div class="scroll"><table class="tbl pwtab"><tr><th>Level</th><th class="num">Contoh</th><th class="num">Tersentuh</th><th class="num">Respek</th>
      <th class="num">+S/R flip</th><th class="num">Tanpa</th><th class="num">Pantul s/d</th></tr>` +
      pw.rows.map((r) => `<tr class="${r.level === pw.best.level ? "best" : ""}"><td><b>${r.level}</b>${r.level === pw.best.level ? " ⭐" : ""}</td><td class="num">${px(r.level)}</td>
        <td class="num">${pc(r.touch)}</td><td class="num">${pc(r.respect)}</td><td class="num">${pc(r.respect_conf)}</td><td class="num">${pc(r.respect_noconf)}</td>
        <td class="num">${r.reach_med == null ? "—" : f2(r.reach_med)}</td></tr>`).join("") +
      `</table></div><p class="hint">Respek = setelah harga menyentuh level, memantul sampai 0 tanpa menembus level lebih dari ${pw.k} × ATR dan tanpa close tembus 1.0.
        Level ≥ alarm (${pw.alarm}) tidak dibandingkan.</p>`;
  }
  // label kondisi pasar yang mudah dibaca
  function marketLabel(key) {
    return { bull_up: "Bullish · tren naik, koreksi turun → BUY", bear_down: "Bearish · tren turun, koreksi naik → SELL",
      side_up: "Sideways · koreksi turun → BUY", side_down: "Sideways · koreksi naik → SELL",
      bull_down: "Bullish · koreksi melawan tren → SELL", bear_up: "Bearish · koreksi melawan tren → BUY" }[key] || key;
  }
  // "Kalau pullback ke X → kebanyakan naik sampai A, sering juga sampai B" untuk tiap level
  function bounceLines(g, side) {
    if (!g || !g.levels) return [];
    const alarm = g.advice && g.advice.alarm ? g.advice.alarm.level : 1;
    return g.levels.filter((r) => r.level >= 0.382 && r.level < alarm && (r.tp || []).length && r.filled >= 30).map((r) => {
      const most = [...r.tp].reverse().find((t) => t.pct >= 50);
      const often = [...r.tp].reverse().find((t) => t.pct >= 30 && (!most || t.level < most.level));
      if (!most && !often) return `📍 ${r.level} → jarang memantul jauh`;
      return `📍 ${r.level} → ` + (most ? `biasanya sampai ${most.level}` : `kadang sampai ${often.level}`) +
        (most && often ? `, kadang ${often.level}` : "");
    });
  }
  function conclusionLines(it, g, tf) {
    const pw = it.power;
    const L = bounceLines(g, it.side).map((x) => ({ text: x }));
    if (pw) {
      L.push({ text: `⭐ Terkuat: ${pw.best.level} (memantul ${f2(pw.best.respect)}%)` });
      L.push({ text: `🛡️ SL: ${pw.k} × ATR ${String(tf).toUpperCase()} dari entry` });
      const b = pw.best, up = b.respect_conf != null && b.respect_noconf != null ? b.respect_conf - b.respect_noconf : null;
      if (up != null && Math.abs(up) >= 3) L.push({ text: `🔁 S/R flip: ${up > 0 ? "menambah kekuatan" : "melemahkan"} (${up > 0 ? "+" : ""}${f2(up)}%)` });
    }
    if (it.alarm) L.push({ text: `🚨 Batal: candle close tembus ${it.alarm.level}` });
    return L;
  }
  function renderConclusion(res) {
    const el = $("fbConc");
    if (!res.conclusion) {
      el.innerHTML = `<div class="conc hint">Kesimpulan belum tersedia untuk hasil yang disimpan sebelum versi 3.8. Jalankan ulang studinya.</div>`;
      return;
    }
    const p = res.params || {};
    const by = Object.fromEntries((res.groups || []).map((g) => [g.key, g]));
    const hasPower = res.conclusion.some((c) => c.items.some((it) => it.power !== undefined));
    const lineHtml = (l) => l.list ? `<li>${esc(l.head)}<ul>${l.list.map((x) => `<li>${esc(x)}</li>`).join("")}</ul></li>` : `<li>${esc(l.text)}</li>`;
    el.innerHTML = `<div class="conc"><h3>🧾 Kesimpulan <span class="hint">fibo ${String(p.tf).toUpperCase()} · kondisi pasar dari ${String(p.regime_tf).toUpperCase()} · ${res.n.toLocaleString("id-ID")} setup</span>
        <button class="mini" id="${FBP}CopyConc">Salin kesimpulan</button></h3>
      ${hasPower ? "" : '<p class="hint">Hasil lama (sebelum v3.13): sebagian angka belum ada. Jalankan ulang studinya.</p>'}
      ${guideBlock(res)}
      <div class="conc-grid">${res.conclusion.map((c) => c.items.map((it) => `<div class="conc-reg">
        <h4>${c.icon} ${esc(marketLabel(it.key).replace(" · tren naik, koreksi turun", " · koreksi turun").replace(" · tren turun, koreksi naik", " · koreksi naik"))}</h4>
        <div class="how">${it.side === "BUY" ? "fibo low → high (0 = high)" : "fibo high → low (0 = low)"}</div>
        <ul>${conclusionLines(it, by[it.key], p.tf).map(lineHtml).join("")}</ul>
        <details class="sltab"><summary>Detail angka</summary>${powerTable(it.power, it.side)}
          ${it.entry ? `<ul>${concItemLines(it).map((l) => `<li>${esc(l)}</li>`).join("")}</ul>${slTable(it, (lv) => f2(concPrice(lv, it.side)))}` : ""}</details>
      </div>`).join("")).join("")}</div>${trendBlock(res)}${secretBlock(res)}${breakoutBlock(res)}</div>`;
    if ($("fbCopySet")) $("fbCopySet").onclick = () => copyText(fibSet(res).map((x) => x.level).join(", ")).then(() => toast("Set fibo disalin"));
    $("fbCopyConc").onclick = () => {
      const txt = [`Kesimpulan Studi Fibonacci — fibo ${String(p.tf).toUpperCase()}, kondisi pasar dari ${String(p.regime_tf).toUpperCase()}`];
      for (const c of res.conclusion) for (const it of c.items) {
        txt.push(`\n${c.icon} ${marketLabel(it.key)}`);
        for (const l of conclusionLines(it, by[it.key], p.tf)) {
          if (l.list) { txt.push(l.head); l.list.forEach((x) => txt.push("  - " + x)); } else txt.push(l.text);
        }
      }
      const tl = trendLines(res);
      if (tl.length) txt.push(`\n📐 BOS / CHoCH saat tren EMA ${res.trend.ema_fast ?? 50}/${res.trend.ema_slow ?? 200} ${String(res.trend.tf).toUpperCase()}`, ...tl);
      const sl = secretLines(res);
      if (sl.length) txt.push("\n🔍 Angka rahasia market", ...sl);
      const gl = guideLines(res);
      if (gl.length) txt.push("\n📘 Cara pakai fibo (untuk pemula)", ...gl);
      const fs = fibSet(res);
      if (fs.length > 2) txt.push("\n📋 Saran set fibo: " + fs.map((x) => x.level).join(", "), ...fs.map((x) => `  ${x.level}: ${x.uses.join(" · ")}`));
      const bk = breakoutLines(res);
      if (bk.length) txt.push("\n🚀 Breakout sideways (buy stop / sell stop)", ...bk);
      copyText(txt.join("\n")).then(() => toast("Kesimpulan disalin"));
    };
  }
  // ---- BOS / CHoCH saat tren EMA 50/200: close tembus angka fibo berapa -> biasanya CHoCH / BOS
  function trendSideLines(g) {
    const out = [], buy = g.side === "BUY";
    if (!g.n) return out;
    const uji = (v) => (v == null ? "" : ` (data uji ${f2(v)}%)`);
    if (g.choch) out.push(`🔻 CHoCH: koreksi close tembus ${buy ? "ke bawah" : "ke atas"} ${g.choch.level} → ${f2(g.choch.choch_pct)}% jadi CHoCH${uji(g.choch.test_choch_pct)}${g.choch.strong ? "" : " (belum ada yang ≥ 70%)"}`);
    const rt = g.choch && g.choch.retest;
    if (rt && rt.n >= 30) {
      const lv = [...rt.reach].reverse().slice(0, 3).map((r) => `${f2(r.pct)}% sampai ${r.level}`).join(", ");
      out.push(`🔁 Setelah close tembus ${g.choch.level} (yang jadi CHoCH), sebelum tembus 1 biasanya retest dulu ke ±${f2(rt.med)}: ${lv} · ${f2(rt.direct)}% langsung tanpa retest`);
    }
    if (g.bos) out.push(`🔺 BOS: setelah tembus, close balik ${buy ? "di atas" : "di bawah"} ${g.bos.level} → ${f2(g.bos.rc_bos_pct)}% lanjut BOS${uji(g.bos.test_rc_bos_pct)}`);
    if (g.depth_med != null) out.push(`📏 Koreksi sebelum BOS biasanya sampai ${f2(g.depth_med)}, 80% tidak lewat ${f2(g.depth_p80)}`);
    const far = (rows) => [...rows].reverse().find((r) => r.pct >= 50);
    const ab = g.after_bos && far(g.after_bos.reach), ac = g.after_choch && far(g.after_choch.reach);
    if (ab) out.push(`🎯 Setelah BOS biasanya sampai ${ab.level} (${f2(ab.pct)}%)`);
    if (ac) out.push(`↩️ Setelah CHoCH biasanya sampai ${ac.level} (${f2(ac.pct)}%)`);
    return out;
  }
  function trendLines(res) {
    if (!res.trend) return [];
    const out = [];
    for (const g of res.trend.sides) { out.push(`${g.side === "BUY" ? "📈" : "📉"} ${g.name}`); trendSideLines(g).forEach((l) => out.push("  " + l)); }
    return out;
  }
  function trendBlock(res) {
    const T = res.trend;
    if (!T) return "";
    const tf = String(T.tf).toUpperCase();
    const card = (g) => {
      const buy = g.side === "BUY";
      const lines = trendSideLines(g);
      const tbl = g.rows ? `<details class="sltab"><summary>Detail per angka fibo</summary><div class="scroll"><table class="tbl">
        <tr><th>Close tembus</th><th class="num">Kejadian</th><th class="num">→ CHoCH</th><th class="num">→ BOS</th><th class="num">Close balik → BOS</th><th class="num">Retest sebelum CHoCH (median)</th></tr>
        ${g.rows.map((r) => `<tr><td>${r.level}</td><td class="num">${r.broke} (${f2(r.broke_pct)}%)</td>
          <td class="num" style="background:${r.choch_pct >= 70 ? "rgba(239,83,80,.3)" : "transparent"}">${f2(r.choch_pct)}%</td><td class="num">${f2(r.bos_pct)}%</td>
          <td class="num" style="background:${r.rc_bos_pct >= 70 ? "rgba(38,166,154,.3)" : "transparent"}">${r.reclaim ? f2(r.rc_bos_pct) + "%" : "—"}</td>
          <td class="num">${r.retest ? `±${f2(r.retest.med)} · ${f2(r.retest.direct)}% langsung` : "—"}</td></tr>`).join("")}</table></div></details>` : "";
      return `<div class="conc-reg"><h4>${buy ? "📈" : "📉"} ${esc(g.name)} · ${tf}</h4>
        <div class="how">swing ${buy ? "naik: fibo low → high (1 = low, 0 = high)" : "turun: fibo high → low (1 = high, 0 = low)"} · ${g.n.toLocaleString("id-ID")} swing</div>
        ${lines.length ? `<ul>${lines.map((l) => `<li>${esc(l)}</li>`).join("")}</ul>` : '<p class="hint">Tidak ada data.</p>'}${tbl}</div>`;
    };
    return `<h3 style="margin-top:14px">📐 BOS / CHoCH saat tren EMA ${T.ema_fast ?? 50}/${T.ema_slow ?? 200} ${tf}</h3>
      <p class="hint">BOS = close tembus 0 (lanjut tren). CHoCH = close tembus 1 (struktur berubah). Semua pakai <b>close</b> candle TF fibo.</p>
      <div class="conc-grid">${T.sides.map(card).join("")}</div>`;
  }
  // ---- panduan pemula: cara tarik & pakai fibo per kondisi pasar, angka diambil dari hasil studi ini
  function guideNums(res, key) {
    const g = (res.groups || []).find((x) => x.key === key) || {};
    const it = (res.conclusion || []).flatMap((c) => c.items).find((x) => x.key === key) || {};
    const role = (k) => { const r = g.secret && g.secret.roles.find((x) => x.kind === k && x.level != null); return r && r.valid ? r : null; };
    const num = (v) => (v == null ? null : +(+v).toFixed(2));
    const entry = role("entry") || role("stop");
    const anyStop = g.secret && g.secret.roles.find((x) => x.kind === "stop" && x.level != null);
    const best = it.power && it.power.best ? it.power.best.level : null;
    // urutan: angka lolos uji -> rencana kesimpulan -> angka terbaik yang belum pasti (diberi tanda)
    const entryV = entry ? num(entry.level) : it.entry != null ? num(it.entry) : anyStop ? num(anyStop.level) : num(best);
    return {
      entry: entryV, entryWeak: !entry && it.entry == null && entryV != null,
      entrySrc: entry ? "role" : it.entry != null ? "plan" : entryV != null ? "weak" : null,
      alarm: role("alarm") ? num(role("alarm").level) : it.alarm ? num(it.alarm.level) : null,
      sl: role("sl") ? num(role("sl").level) : null, slk: it.sl_k || null,
      tpFast: role("end") ? num(role("end").level) : it.tp1 ? num(it.tp1.level) : null,
      tpFar: role("tp") ? num(role("tp").level) : it.tp2 ? num(it.tp2.level) : null,
      bk: role("breakout") ? num(role("breakout").level) : it.breakout && it.breakout.pick ? num(it.breakout.pick.level) : null,
      retest: role("retest") ? num(role("retest").level) : null,
      fake: role("fake") ? num(role("fake").level) : null,
      n: g.n || 0,
    };
  }
  function trendTxt(res) {
    const p = res.params || {}, T = res.trend;
    const tf = String(p.trend_tf || (T && T.tf) || "1h").toUpperCase();
    return { tf, ema: `EMA ${p.ema_fast || (T && T.ema_fast) || 50} / ${p.ema_slow || (T && T.ema_slow) || 200}`,
      ftf: String(p.tf).toUpperCase(), rtf: String(p.regime_tf).toUpperCase(), sw: p.swing || 3 };
  }
  // gambar sederhana: garis angka fibo + jalur harga (impuls, koreksi, lanjut)
  function fibDiagram(kind, N) {
    const W = 300, H = 230, L = 46, R = W - 8;
    const lv = [{ v: 1, t: "1", c: "#9aa0a6" }, { v: 0, t: "0", c: "#9aa0a6" }];
    const add = (v, t, c) => { if (v != null && !lv.some((x) => Math.abs(x.v - v) < 0.015)) lv.push({ v, t: `${v} ${t}`, c }); };
    if (kind === "side") { add(N.bk, "breakout", "#42a5f5"); add(N.fake, "gagal BO →", "#b8860b"); add(N.entry, "entry", "#26a69a"); }
    else { add(N.entry, "entry", "#26a69a"); add(N.alarm, "alarm", "#ef5350"); add(N.sl, "SL", "#ef5350"); add(N.tpFast, "TP cepat", "#42a5f5"); }
    const vs = lv.map((x) => x.v), lo = Math.min(...vs, 0) - 0.08, hi = Math.max(...vs, 1) + 0.08;
    const up = kind !== "bear";                       // bullish & sideways buy: 0 di atas
    const y = (v) => 10 + ((up ? v - lo : hi - v) / (hi - lo)) * (H - 20);
    const pts = kind === "side"
      ? [[L + 6, y(1)], [L + 60, y(0)], [L + 105, y(N.entry ?? 0.5)], [L + 150, y(0)], [L + 175, y(N.bk ?? -0.2)], [L + 205, y(0.15)], [R - 10, y(N.fake ?? 0.4)]]
      : [[L + 6, y(1)], [L + 95, y(0)], [L + 150, y(N.entry ?? 0.5)], [R - 10, y(N.tpFast ?? -0.3)]];
    return `<svg class="fibdiag" viewBox="0 0 ${W} ${H}" width="100%" style="max-width:${W}px">
      ${lv.map((x) => `<line x1="${L}" x2="${R}" y1="${y(x.v)}" y2="${y(x.v)}" stroke="${x.c}" stroke-dasharray="${x.v === 0 || x.v === 1 ? "" : "4 3"}" stroke-width="1"/>
        <text x="2" y="${y(x.v) + 4}" font-size="10" fill="${x.c}">${esc(x.t)}</text>`).join("")}
      <polyline points="${pts.map((q) => q.join(",")).join(" ")}" fill="none" stroke="currentColor" stroke-width="2"/>
      <circle cx="${pts[0][0]}" cy="${pts[0][1]}" r="4" fill="#42a5f5"/><circle cx="${pts[1][0]}" cy="${pts[1][1]}" r="4" fill="#42a5f5"/>
      <text x="${pts[0][0] + 6}" y="${pts[0][1] + (up ? -6 : 12)}" font-size="10" fill="currentColor">klik 1</text>
      <text x="${pts[1][0] + 6}" y="${pts[1][1] + (up ? 12 : -6)}" font-size="10" fill="currentColor">klik 2</text></svg>`;
  }
  function guideSteps(res, kind) {
    const t = trendTxt(res), out = [];
    const f = (v) => (v == null ? "—" : String(v));
    const fe = (N) => (N.entry == null ? "—" : `${N.entry}${N.entryWeak ? " (belum pasti, pakai kecil dulu)" : ""}`);
    if (kind === "bull" || kind === "bear") {
      const buy = kind === "bull", N = guideNums(res, buy ? "bull_up" : "bear_down");
      const low = buy ? "swing low" : "swing high", high = buy ? "swing high" : "swing low";
      out.push(`1. Cek tren: di TF ${t.tf}, ${t.ema.replace(" / ", buy ? " di atas EMA " : " di bawah EMA ")} (atau kondisi pasar ${t.rtf} ${buy ? "bullish" : "bearish"}). Kalau ya, hanya cari ${buy ? "BUY" : "SELL"}.`);
      out.push(`2. Di chart TF ${t.ftf}, cari dorongan ${buy ? "naik" : "turun"} terakhir yang sudah selesai: dari ${low} (titik ${buy ? "terendah sebelum naik" : "tertinggi sebelum turun"}) ke ${high} (${buy ? "puncak" : "dasar"} terbaru). ${high[0].toUpperCase() + high.slice(1)} dianggap selesai kalau sudah ada ${t.sw} candle di kanannya yang ${buy ? "high-nya lebih rendah" : "low-nya lebih tinggi"}.`);
      out.push(`3. Tarik fibo: klik pertama di ${low} (= 1), klik kedua di ${high} (= 0).`);
      out.push(`4. Tunggu harga koreksi ${buy ? "turun" : "naik"}. Pasang ${buy ? "buy" : "sell"} limit di ${fe(N)}.`);
      out.push(N.sl != null ? `5. SL: ${buy ? "di bawah" : "di atas"} ${f(N.sl)} (tambah sedikit jarak ATR ${t.ftf}).` :
        N.slk ? `5. SL: ${buy ? "di bawah" : "di atas"} harga entry sejauh ${N.slk} × ATR ${t.ftf}.` : `5. SL: sedikit ${buy ? "di bawah" : "di atas"} angka 1.`);
      out.push(`6. TP: ambil sebagian di ${f(N.tpFast)}${N.tpFar != null ? `, sisanya bisa ditahan sampai ${f(N.tpFar)}` : ""}. Angka minus = ${buy ? "di atas swing high" : "di bawah swing low"}.`);
      if (N.alarm != null) out.push(`7. Batal: kalau candle close ${buy ? "di bawah" : "di atas"} ${f(N.alarm)} sebelum limit kena, hapus limit. Struktur kemungkinan patah (CHoCH).`);
      out.push(`${N.alarm != null ? 8 : 7}. Kalau harga tembus 0 (${buy ? "high" : "low"} baru) tanpa menyentuh limit: hapus fibo lama, tunggu swing baru, lalu tarik ulang.`);
      return { N, steps: out };
    }
    const Nb = guideNums(res, "side_up"), Ns = guideNums(res, "side_down");
    out.push(`1. Cek: harga bolak-balik di antara high dan low yang sama (tidak bikin high/low baru), dan kondisi pasar ${t.rtf} sideways.`);
    out.push(`2. Tarik fibo dari swing terakhir yang sudah selesai. Kalau gerakan terakhir NAIK: klik low (= 1) lalu high (= 0). Kalau gerakan terakhir TURUN: klik high (= 1) lalu low (= 0).`);
    out.push(`3. Main di dalam range: setelah swing naik, buy limit di ${fe(Nb)}. Setelah swing turun, sell limit di ${fe(Ns)}. SL di luar angka 1, TP dekat ujung range (0).`);
    if (Nb.bk != null || Ns.bk != null) out.push(`4. Main breakout: buy stop kalau candle close di atas ${f(Nb.bk)} (fibo low → high). Sell stop kalau close di bawah ${f(Ns.bk)} (fibo high → low). Baru close tembus 0 sering palsu.`);
    if (Nb.retest != null || Ns.retest != null) out.push(`5. Setelah breakout valid, harga biasanya retest dulu ke sekitar ${f(Nb.retest ?? Ns.retest)}. Bisa jadi tempat masuk kalau ketinggalan.`);
    if (Nb.fake != null || Ns.fake != null) out.push(`6. Kalau breakout gagal (close balik ke dalam range), harga biasanya lari ke arah sebaliknya sampai ±${f(Nb.fake ?? Ns.fake)}.`);
    return { N: Nb, steps: out };
  }
  function guideLines(res) {
    if (!res.conclusion) return [];
    const out = [];
    for (const [k, title] of [["bull", "📈 Bullish (BUY)"], ["bear", "📉 Bearish (SELL)"], ["side", "↔️ Sideways"]]) {
      out.push(title, ...guideSteps(res, k).steps.map((x) => "  " + x));
    }
    return out;
  }
  function guideBlock(res) {
    if (!res.conclusion) return "";
    const card = (k, title) => {
      const { N, steps } = guideSteps(res, k);
      return `<div class="conc-reg guide"><h4>${title}</h4>${fibDiagram(k, N)}
        <ol>${steps.map((x) => `<li>${esc(x.replace(/^\d+\. /, ""))}</li>`).join("")}</ol></div>`;
    };
    return `<details class="guidebox" open><summary><b>📘 Cara pakai fibo (untuk pemula)</b> <span class="hint">angka diambil dari hasil studi ini · klik untuk tutup/buka</span></summary>
      <p class="hint">Fibo selalu ditarik dari <b>awal dorongan</b> (klik 1 = angka 1) ke <b>ujung dorongan</b> (klik 2 = angka 0).
        Angka 0.xx = koreksi, angka minus = lewat ujung (target), angka di atas 1 = struktur sudah patah. Gunakan TF ${esc(trendTxt(res).ftf)} untuk menarik fibo.</p>
      <div class="conc-grid">${card("bull", "📈 Bullish → BUY")}${card("bear", "📉 Bearish → SELL")}${card("side", "↔️ Sideways → BUY / SELL")}</div></details>`;
  }
  // ---- angka rahasia market: pemindaian tiap 0.01, tiap angka diberi peran + penjelasan (v2)
  const SECRET_KEYS = ["bull_up", "bear_down", "side_up", "side_down"];
  function secretGroups(res) {
    return (res.groups || []).filter((g) => SECRET_KEYS.includes(g.key) && g.secret && g.secret.roles.length);
  }
  function secretLines(res) {
    const out = [];
    for (const g of secretGroups(res)) {
      out.push(fbGroupName(g));
      for (const r of g.secret.roles) {
        out.push(`  ${r.icon} ${r.title}: ${r.level == null ? "—" : r.level}${r.new ? " (🆕 angka baru)" : ""} · ${r.valid ? "lolos uji" : "belum pasti"}`);
        r.lines.forEach((l) => out.push("     " + l));
      }
    }
    return out;
  }
  // saran set fibo: angka yang lolos uji dari semua kondisi pasar, digabung (angka berdekatan ±0.02 jadi satu)
  const ROLE_SHORT = { entry: "entry limit", stop: "entry koreksi", alarm: "alarm CHoCH", sl: "SL", tp: "TP jauh", end: "TP cepat",
    breakout: "buy/sell stop", retest: "retest breakout", fake: "target breakout gagal" };
  const COND_SHORT = { bull_up: "bullish", bear_down: "bearish", side_up: "sideways buy", side_down: "sideways sell" };
  function fibSet(res) {
    // kumpulkan angka yang lolos uji, lalu gabung yang berdekatan (≤ 0.03) jadi satu angka (rata-rata) supaya set ringkas
    const raw = [];
    for (const g of secretGroups(res)) for (const r of g.secret.roles) {
      if (r.level == null || !r.valid) continue;
      raw.push({ level: r.level, use: `${ROLE_SHORT[r.kind] || r.kind} (${COND_SHORT[g.key]})` });
    }
    raw.push({ level: 0, use: "ujung swing / BOS", fixed: true }, { level: 1, use: "awal swing / CHoCH", fixed: true });
    raw.sort((a, b) => a.level - b.level);
    const out = [];
    for (const x of raw) {
      const c = out[out.length - 1];
      if (c && x.level - c.levels[c.levels.length - 1] <= 0.0301 && x.level - c.first <= 0.0501) {
        c.levels.push(x.level);
        if (x.fixed) c.fixed = x.level;
        if (!c.uses.includes(x.use)) c.uses.push(x.use);
      } else out.push({ first: x.level, levels: [x.level], uses: [x.use], fixed: x.fixed ? x.level : null });
    }
    return out.map((c) => ({ level: c.fixed != null ? c.fixed : +(c.levels.reduce((a, b) => a + b, 0) / c.levels.length).toFixed(2), uses: c.uses }));
  }
  function fibSetBlock(res) {
    const set = fibSet(res);
    if (set.length <= 2) return "";
    const txt = set.map((x) => x.level).join(", ");
    return `<div class="conc-reg" style="margin-top:10px"><h4>📋 Saran set fibo untuk chart kamu</h4>
      <div class="how">gabungan angka yang ✅ lolos uji · 1 = awal swing, 0 = ujung swing, minus = lewat ujung swing</div>
      <p><b class="sec-lv">${esc(txt)}</b> <button class="mini" id="${FBP}CopySet">Salin set</button></p>
      <table class="tbl"><tr><th>Angka</th><th>Dipakai untuk</th></tr>
        ${set.map((x) => `<tr><td><b>${x.level}</b></td><td>${esc(x.uses.join(" · "))}</td></tr>`).join("")}</table>
      <p class="hint">Cara pakai: masukkan angka-angka ini ke level Fibonacci di chart (TradingView: Settings → Levels).
        Tarik fibo dari awal swing (1) ke ujung swing (0), sama seperti di studi ini.</p></div>`;
  }
  function secretBlock(res) {
    const gs = secretGroups(res);
    if (!gs.length) return "";
    const role = (r) => `<div class="sec-role ${r.valid ? "ok" : "warn"}">
        <div class="sec-head"><span>${r.icon} ${esc(r.title)}</span>
          <b class="sec-lv">${r.level == null ? "—" : r.level}</b>${r.new ? '<span class="badge new">🆕 angka baru</span>' : r.level == null ? "" : '<span class="badge">angka umum</span>'}
          <span class="badge ${r.valid ? "pass" : "fail"}">${r.valid ? "✅ lolos uji" : "⚠️ belum pasti"}</span></div>
        <ul>${r.lines.map((l) => `<li>${esc(l)}</li>`).join("")}</ul></div>`;
    return `<h3 style="margin-top:14px">🔍 Angka rahasia market <span class="hint">dipindai tiap 0.01, dipilih di 70% data awal, dicek di 30% data terakhir</span></h3>
      <p class="hint">Angka di sini <b>tidak harus</b> angka fibo yang umum. 🆕 = angka yang bukan angka fibo biasa. ✅ lolos uji = hasilnya tetap sama di data uji.
        Kemiringan impuls: landai &lt; 0.5 ATR/candle, sedang 0.5–1, curam &gt; 1. Angka minus = lewat ujung swing (0), di atas 1 = lewat awal swing.</p>
      <div class="conc-grid">${gs.map((g) => `<div class="conc-reg"><h4>${esc(fbGroupName(g))}</h4>
        <div class="how">${g.key.endsWith("_up") ? "fibo low → high (1 = low, 0 = high)" : "fibo high → low (1 = high, 0 = low)"} · ${g.n.toLocaleString("id-ID")} swing</div>
        ${g.secret.roles.map(role).join("")}</div>`).join("")}</div>${fibSetBlock(res)}`;
  }
  // ---- breakout sideways: close tembus level fibo di luar range -> biasanya lanjut? (buy stop / sell stop)
  function breakoutLines(res) {
    const out = [];
    for (const c of res.conclusion || []) for (const it of c.items) {
      const b = it.breakout;
      if (!b || !it.key.startsWith("side")) continue;
      const buy = it.side === "BUY", r0 = b.rows.find((r) => r.level === 0);
      out.push(`${buy ? "Buy stop" : "Sell stop"}: candle close ${buy ? "di atas" : "di bawah"} ${b.pick.level} → ${f2(b.pick.ok_pct)}% lanjut ${buy ? "naik" : "turun"}` +
        `, rata-rata sampai ${f2(b.pick.ext_med)}` + (b.test_ok_pct != null ? ` (data uji ${f2(b.test_ok_pct)}%)` : ""));
      if (r0 && b.pick.level !== 0) out.push(`  Baru close ${buy ? "di atas" : "di bawah"} 0 → cuma ${f2(r0.ok_pct)}% lanjut (sering palsu)`);
    }
    return out;
  }
  function breakoutBlock(res) {
    const lines = breakoutLines(res);
    if (!lines.length) return "";
    const tables = (res.conclusion || []).flatMap((c) => c.items).filter((it) => it.breakout && it.key.startsWith("side")).map((it) =>
      `<b>${it.side === "BUY" ? "Breakout ke atas (buy stop)" : "Breakout ke bawah (sell stop)"}</b><div class="scroll"><table class="tbl pwtab"><tr><th>Close tembus</th>
        <th class="num">Lanjut</th><th class="num">Palsu</th><th class="num">Rata-rata sampai</th></tr>` +
      it.breakout.rows.map((r) => `<tr class="${r.level === it.breakout.pick.level ? "best" : ""}"><td><b>${r.level}</b>${r.level === it.breakout.pick.level ? " ⭐" : ""}</td>
        <td class="num">${f2(r.ok_pct)}%</td><td class="num">${f2(r.fake_pct)}%</td><td class="num">${r.ext_med == null ? "—" : f2(r.ext_med)}</td></tr>`).join("") + "</table></div>").join("");
    return `<div class="conc-reg bkblock"><h4>🚀 Breakout sideways (pasang buy stop / sell stop)</h4>
      <ul>${lines.map((l) => `<li>${esc(l.trim())}</li>`).join("")}</ul>
      <details class="sltab"><summary>Detail angka</summary>${tables}
        <p class="hint">Lanjut = setelah candle close tembus level, harga bergerak lagi minimal 0.382 × lebar range sebelum close balik ke dalam range. Palsu = balik ke dalam range dulu.</p></details></div>`;
  }

  // kartu limit: jelaskan harga entry / TP / SL dan RR, dan katakan terus terang kalau tidak ada level yang untung
  // kartu 🎯: rencana entry yang sama persis dengan Kesimpulan (entry di atas level alarm, TP1/TP2, SL terbaik/aman)
  const K_ATR = [0.1, 0.25, 0.5, 0.75, 1, 1.5, 2, 3];
  function strengthSection(g, d, p) {
    if (!g.strength) return "";
    const k = FB.k ?? (g.power ? g.power.k : 1);
    const ki = Math.max(0, K_ATR.indexOf(k));
    const px = (lv) => f2(fbPrice(lv, d));
    const alarm = g.advice && g.advice.alarm ? g.advice.alarm.level : 1;
    return `<h4>Kekuatan level: seberapa sering tersentuh & respek (memantul sampai 0)</h4>
      <div class="evalbtns">SL = level ${d > 0 ? "−" : "+"} <select id="${FBP}K">${K_ATR.map((x) => `<option value="${x}" ${x === k ? "selected" : ""}>${x}</option>`).join("")}</select>
        × ATR ${String(p.tf).toUpperCase()} <span class="hint">${g.power ? `saran: ${g.power.k} (melindungi ±80% pantulan)` : ""}</span></div>
      <div class="scroll"><table class="tbl"><tr><th>Level</th><th class="num">Contoh</th><th class="num">Tersentuh</th><th class="num">Respek</th>
        <th class="num">+S/R flip</th><th class="num">Tanpa S/R flip</th><th class="num">S/R flip ada di</th><th class="num">Tusukan 80% (ATR)</th><th class="num">Pantul s/d (median)</th><th class="num">Respek data uji</th></tr>` +
      g.strength.map((r) => {
        const t = ((g.test && g.test.strength) || []).find((x) => x.level === r.level);
        return `<tr class="${g.power && r.level === g.power.best.level ? "best" : ""}"><td><b>${r.level}</b>${r.level >= alarm ? ' <span title="Di / lewat level alarm">⚠️</span>' : ""}</td>
          <td class="num">${px(r.level)}</td><td class="num">${pc(r.touch)}</td><td class="num">${pc(r.respect[ki])}</td>
          <td class="num">${pc(r.respect_conf_k[ki])}</td><td class="num">${pc(r.respect_noconf_k[ki])}</td><td class="num">${pc(r.conf_share)}</td>
          <td class="num">${r.pen80 == null ? "—" : f2(r.pen80)}</td><td class="num">${r.reach_med == null ? "—" : f2(r.reach_med)}</td>
          <td class="num">${t && t.n >= 20 ? pc(t.respect[ki]) : "—"}</td></tr>`;
      }).join("") + `</table></div>
      <p class="hint">Tersentuh = % setup yang koreksinya sampai level ini. Respek = dari yang menyentuh (setelah fibo digambar), % yang memantul sampai 0
        tanpa menembus level lebih dari k × ATR dan tanpa close tembus 1.0. S/R flip = swing high lama yang sudah ditembus (resistance → support; untuk SELL kebalikannya)
        berada dekat level (±${p.conf_tol_atr ?? 0.25} ATR). Tusukan 80% = 80% pantulan menembus level tidak lebih dari angka ini (ATR) sebelum memantul.</p>`;
  }
  function planCard(pl, d) {
    const side = d > 0 ? "BUY" : "SELL";
    const px = (lv) => f2(fbPrice(lv, d));
    if (!pl.entry) return `<b>❌ Tidak ada entry ${side} yang konsisten untung di kelompok ini.</b>` +
      (pl.alarm ? ` Entry hanya dicari di atas level alarm ${pl.alarm.level}.` : "");
    const it = { ...pl, side };
    const badge = pl.valid === true ? "lolos uji" : pl.valid === false ? "tidak lolos uji" : "belum bisa diuji";
    return `<b>Limit ${side} di ${pl.entry}</b> (contoh ${px(pl.entry)}) · <b>${badge}</b><ul style="margin:4px 0 0 16px;padding:0">` +
      [`TP1: ${pl.tp1.level} (contoh ${px(pl.tp1.level)}) · dicapai ${f2(pl.tp1.pct)}% trade`,
       pl.tp2 ? `TP2: ${pl.tp2.level} (contoh ${px(pl.tp2.level)}) · dicapai ${f2(pl.tp2.pct)}% trade` : "",
       ...slLines(it, px),
       pl.test ? `Data uji: TP1 tercapai ${f2(pl.test.wr_tp1)}%` : "",
       pl.alarm ? `Entry dipilih hanya di atas level alarm ${pl.alarm.level} (di/lewat alarm struktur biasanya patah)` : ""]
        .filter(Boolean).map((l) => `<li>${esc(l)}</li>`).join("") + "</ul>";
  }
  // nama kelompok (hasil lama memakai istilah "gelombang naik/turun")
  function fbGroupName(g) {
    if (g.key === "all") return "Semua setup";
    if (["bull_up", "bear_down", "side_up", "side_down", "bull_down", "bear_up"].includes(g.key)) return marketLabel(g.key);
    const side = g.dir > 0 ? "BUY" : "SELL";
    if (g.reg === 0) return `Sideways · ${side}`;
    return `${g.reg > 0 ? "Bullish" : "Bearish"} · koreksi ${g.reg === g.dir ? "searah" : "melawan"} tren (${side})`;
  }
  function limitCard(L, d, g) {
    if (g.plan && !(g.reg !== 0 && g.key !== "all" && g.reg !== g.dir)) return planCard(g.plan, d);
    if (g.reg !== 0 && g.reg != null && g.key !== "all" && g.reg !== g.dir)
      return `<b>❌ Tidak disarankan: ini koreksi melawan tren.</b> Data di bawah hanya untuk info. Yang berguna di sini: level alarm
        (kapan koreksi melawan tren gagal) dan target setelah BOS, untuk entry <b>searah tren</b>.`;
    if (!L) return "Belum cukup data (butuh minimal 30 setup).";
    const side = d > 0 ? "BUY" : "SELL";
    const px = (lv) => f2(fbPrice(lv, d));
    const rr = (L.level - Number(L.target)) / (1 - L.level);
    const trend = g.note ? ` (${g.note})` : "";
    const lines = `Limit ${side} di <b>${L.level}</b> (contoh ${px(L.level)}), TP di <b>${L.target}</b> (contoh ${px(Number(L.target))}), SL di luar 1.0 (contoh ${px(1)}).
      RR ±1:${f2(rr)} → butuh WR di atas ±${f2(100 / (1 + rr))}% supaya untung.
      <br>Data latih: WR ${f2(L.fit_wr)}%, ${rTxt(L.fit_r_leg)}/setup. Data uji (30% terakhir): WR ${f2(L.test_wr)}%, ${rTxt(L.test_r_leg)}/setup · <b>${L.valid ? "lolos uji" : "tidak lolos uji"}</b>`;
    if (L.fit_r_leg > 0.005) return lines + (L.valid ? "" : `<div class="e" style="margin-top:4px">⚠️ Untung di data latih, tapi tidak di data terbaru (uji): belum bisa dipercaya, jangan dipakai dulu.</div>`);
    return `<b>❌ Tidak ada level ${side} yang menguntungkan di kelompok ini${trend}.</b> Hindari entry ${side} di koreksi kondisi ini.
      <div class="e" style="margin-top:4px">Yang paling tidak rugi: ${lines}</div>`;
  }

  // ---- 🧭 workflow & threshold strategi (v2): ringkasan siap pakai dari angka terbaik hasil backtest ini
  const FLOW_KEYS = [["bull_up", "📈 Bullish", "BUY", "swing low → swing high"], ["bear_down", "📉 Bearish", "SELL", "swing high → swing low"],
    ["side_up", "↔️ Sideways (setelah naik)", "BUY", "swing low → swing high"], ["side_down", "↔️ Sideways (setelah turun)", "SELL", "swing high → swing low"]];
  function flowData(res) {
    const p = res.params || {}, t = trendTxt(res), byIt = Object.fromEntries((res.conclusion || []).flatMap((c) => c.items).map((x) => [x.key, x]));
    const set = res.conclusion ? fibSet(res).map((x) => x.level) : [];
    const setup = [
      ["TF untuk menarik fibo", t.ftf],
      ["TF kondisi pasar", `${t.rtf} (EMA50 + ADX 14 ≥ ${p.adx_min} + BOS swing 3)`],
      ["Tren (BOS / CHoCH)", `${t.ema} di TF ${t.tf}`],
      ["Swing dianggap selesai", `ada ${t.sw} candle di kanan & kiri yang tidak melewatinya (fractal ${t.sw})`],
      ["Dorongan minimal", `${p.min_leg_atr} × ATR14 ${t.ftf} (lebih kecil = abaikan)`],
      ["Limit berlaku maksimal", `${p.max_bars} candle ${slDur(p.max_bars, p.tf)} setelah fibo digambar`],
      ["Set angka fibo di chart", set.length > 2 ? set.join(", ") : "0, 0.382, 0.5, 0.618, 0.705, 1, -0.272, -0.618"],
    ];
    const rows = FLOW_KEYS.map(([key, name, side, draw]) => {
      const N = guideNums(res, key), it = byIt[key] || {};
      const buy = side === "BUY";
      const pc = (v) => (v == null ? "" : ` (${f2(v)}%)`);
      const tp1pct = it.tp1 && N.tpFast === +(+it.tp1.level).toFixed(2) ? pc(it.tp1.pct) : "";
      const tp2pct = it.tp2 && N.tpFar === +(+it.tp2.level).toFixed(2) ? pc(it.tp2.pct) : "";
      const status = N.n < 30 ? { t: `❓ data kurang (${N.n} setup)`, c: "muted" }
        : N.entrySrc === "role" ? { t: "✅ lolos uji (angka terbaik dicek di data uji)", c: "pos" }
        : N.entrySrc === "weak" ? { t: "❓ belum pasti — pakai kecil dulu", c: "" }
        : it.valid === true ? { t: `✅ lolos uji${it.test ? ` (TP1 ${f2(it.test.wr_tp1)}% di data uji)` : ""}`, c: "pos" }
        : it.valid === false ? { t: `⚠️ tidak lolos uji${it.test ? ` (TP1 ${f2(it.test.wr_tp1)}% di data uji)` : ""}`, c: "neg" }
        : N.entryWeak ? { t: "❓ belum pasti — pakai kecil dulu", c: "" } : N.entry == null ? { t: "— tidak ada entry yang konsisten", c: "muted" } : { t: "ℹ️ belum dicek di data uji", c: "" };
      return { key, name, side, draw, N, it, status,
        entry: N.entry == null ? "—" : `${buy ? "Buy" : "Sell"} limit ${N.entry}${it.fill_pct != null && N.entry === +(+it.entry).toFixed(2) ? ` (terisi ${f2(it.fill_pct)}%)` : ""}`,
        sl: N.sl != null ? `fibo ${N.sl} + sedikit ATR` : N.slk ? `${N.slk} × ATR ${t.ftf} ${buy ? "di bawah" : "di atas"} entry` : "di luar 1.0",
        tp1: N.tpFast == null ? "—" : `${N.tpFast}${tp1pct}`, tp2: N.tpFar == null ? "—" : `${N.tpFar}${tp2pct}`,
        alarm: N.alarm == null ? "—" : `close ${buy ? "di bawah" : "di atas"} ${N.alarm}`,
        bk: key.startsWith("side") && N.bk != null ? `${buy ? "buy" : "sell"} stop: close ${buy ? "di atas" : "di bawah"} ${N.bk}` : "—",
        after: it.after_bos ? `${it.after_bos.level} (${f2(it.after_bos.pct)}%)` : "—" };
    });
    const steps = [
      `Persiapan: buka chart TF ${t.ftf}, pasang ${t.ema} (TF ${t.tf}) dan ADX 14 (TF ${t.rtf}). Simpan set fibo: ${setup[6][1]}.`,
      `Cek kondisi pasar di TF ${t.rtf}: BULLISH = BOS terakhir naik + close di atas EMA50 + ADX ≥ ${p.adx_min}. BEARISH = BOS terakhir turun + close di bawah EMA50 + ADX ≥ ${p.adx_min}. Selain itu SIDEWAYS.`,
      "Pilih arah: Bullish → hanya BUY, Bearish → hanya SELL, Sideways → BUY di bawah / SELL di atas range. Koreksi melawan tren TIDAK dipakai.",
      `Tunggu dorongan selesai: swing ujungnya sudah terkonfirmasi (${t.sw} candle di kanannya) dan panjangnya ≥ ${p.min_leg_atr} × ATR14. Kalau belum, jangan tarik fibo dulu.`,
      "Tarik fibo: klik 1 di AWAL dorongan (= 1), klik 2 di UJUNG dorongan (= 0). BUY: swing low → swing high. SELL: swing high → swing low.",
      "Pasang order sesuai tabel threshold: limit di angka entry, SL, TP1 (ambil sebagian) dan TP2 (sisanya). Hanya pakai baris yang ✅ lolos uji; yang ❓ / ⚠️ pakai kecil atau lewati.",
      `Selama menunggu: kalau candle CLOSE melewati angka "batal", hapus limit (struktur kemungkinan patah). Kalau harga tembus 0 tanpa menyentuh limit, hapus fibo & tunggu swing baru. Limit tidak dipakai lagi setelah ${p.max_bars} candle.`,
      "Setelah BOS (close tembus 1.0): fibo lama selesai. Target harga arah sebaliknya ada di kolom \"setelah BOS\" — cari setup baru searah struktur yang baru.",
      "Sideways: selain limit di dalam range, bisa buy stop / sell stop saat candle close menembus angka breakout (kolom breakout).",
      "Cek dulu di chart: buka 🔍 Contoh kejadian (bagian 5) dan step di Manual Replay sebelum dipakai uang sungguhan.",
    ];
    const how = [
      "1 = titik AWAL dorongan, 0 = titik UJUNG dorongan. Angka 0.xx = koreksi (tempat limit), angka minus (−0.272, −0.618) = lewat ujung (target TP), angka di atas 1 = struktur sudah patah.",
      "Tarik hanya dari swing yang SUDAH selesai (ada candle di kanannya yang tidak melewatinya). Swing yang masih berjalan bisa bergeser dan angkanya jadi salah.",
      "Satu fibo untuk satu dorongan terakhir. Kalau terbentuk high/low baru, hapus fibo lama dan tarik ulang dari dorongan yang baru.",
      `Selalu tarik di TF ${t.ftf} (TF yang sama dengan studi). Angka dari studi ini tidak berlaku untuk fibo di TF lain.`,
      "Klik pakai ekor (wick) candle: low terendah untuk swing low, high tertinggi untuk swing high.",
    ];
    return { t, setup, rows, steps, how };
  }
  function flowBlock(res) {
    if (!res || !res.n || !res.conclusion) return "";
    const D = flowData(res);
    return `<div class="conc flow" style="margin-top:14px"><h3>🧭 Workflow &amp; threshold strategi
        <span class="hint">angka terbaik hasil backtest ini · fibo ${D.t.ftf} · kondisi pasar ${D.t.rtf} · ${res.n.toLocaleString("id-ID")} setup</span>
        <button class="mini" id="${FBP}CopyFlow">Salin workflow</button></h3>
      <h4>⚙️ Pengaturan (sama dengan studi)</h4>
      <table class="tbl">${D.setup.map(([k, v]) => `<tr><td>${esc(k)}</td><td><b>${esc(v)}</b></td></tr>`).join("")}</table>
      <h4>📊 Threshold per kondisi pasar <span class="hint">angka = level fibo · persen = seberapa sering terjadi di backtest</span></h4>
      <div class="scroll"><table class="tbl"><tr><th>Kondisi</th><th>Tarik fibo</th><th>Entry</th><th>SL</th><th>TP1</th><th>TP2</th><th>Batal kalau</th><th>Breakout</th><th>Setelah BOS</th><th>Status</th></tr>
        ${D.rows.map((r) => `<tr><td><b>${esc(r.name)}</b><br>${r.side === "BUY" ? '<span class="pos">BUY</span>' : '<span class="neg">SELL</span>'}</td>
          <td>${esc(r.draw)}</td><td><b>${esc(r.entry)}</b></td><td>${esc(r.sl)}</td><td>${esc(r.tp1)}</td><td>${esc(r.tp2)}</td>
          <td>${esc(r.alarm)}</td><td>${esc(r.bk)}</td><td>${esc(r.after)}</td><td class="${r.status.c}">${esc(r.status.t)}</td></tr>`).join("")}</table></div>
      <h4>🔁 Workflow (urutan kerja setiap mau entry)</h4><ol>${D.steps.map((x) => `<li>${esc(x)}</li>`).join("")}</ol>
      <h4>📐 Cara pakai fibo</h4><ul>${D.how.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
      <p class="hint">Gambar langkah demi langkah per kondisi pasar ada di <b>📘 Cara pakai fibo</b> (bagian Kesimpulan di atas). Angka berubah kalau studi dijalankan ulang dengan koin / periode / TF lain.</p></div>`;
  }
  function flowText(res) {
    const D = flowData(res), L = [`🧭 Workflow & threshold strategi — Studi Fibonacci v2 (fibo ${D.t.ftf}, kondisi pasar ${D.t.rtf}, ${res.n} setup)`, "", "⚙️ Pengaturan"];
    D.setup.forEach(([k, v]) => L.push(`- ${k}: ${v}`));
    L.push("", "📊 Threshold");
    for (const r of D.rows) L.push(`${r.name} → ${r.side} (fibo ${r.draw})`, `  Entry: ${r.entry} | SL: ${r.sl} | TP1: ${r.tp1} | TP2: ${r.tp2}`,
      `  Batal kalau: ${r.alarm} | Breakout: ${r.bk} | Setelah BOS: ${r.after} | Status: ${r.status.t}`);
    L.push("", "🔁 Workflow", ...D.steps.map((x, i) => `${i + 1}. ${x}`), "", "📐 Cara pakai fibo", ...D.how.map((x) => `- ${x}`));
    return L.join("\n");
  }
  // ---- contoh kejadian: tiap setup fibo bisa dibuka di Manual Replay (fibo, limit, SL & TP otomatis digambar)
  const FB_END = ["✅ lanjut (close tembus 0)", "💥 BOS (close tembus 1.0)", "⏱️ belum selesai"];
  function fibExRes(e, res, lim) {
    if (!lim || !res.ret) return { txt: "—", cls: "" };
    const a = res.ret.indexOf(lim.level), b = (res.tgt || []).indexOf(String(lim.target));
    if (a < 0) return { txt: "—", cls: "" };
    if (e.elig && !e.elig[a]) return { txt: "dilewati (level sudah tersentuh sebelum fibo digambar)", cls: "muted" };
    if (!e.fill[a]) return { txt: "tidak terisi", cls: "muted" };
    const r = b >= 0 && e.R ? e.R[a][b] : null;
    if (r == null) return { txt: "terisi", cls: "" };
    const w = e.W ? e.W[a][b] : 0;
    return w === -1 ? { txt: "❌ SL", cls: "neg" } : w === 1 ? { txt: `✅ TP (+${r.toFixed(2)}R)`, cls: "pos" }
      : { txt: `⏱️ belum selesai (${r >= 0 ? "+" : ""}${r.toFixed(2)}R)`, cls: "" };
  }
  function fibExamplesHtml(res, g, a) {
    const all = res.examples || [];
    if (!res.examples) return `<h4>5. 🔍 Contoh kejadian</h4><p class="hint">Hasil ini dari versi lama (belum menyimpan contoh). Jalankan ulang studinya untuk melihat contoh.</p>`;
    const ex = all.filter((e) => g.key === "all" || (e.reg === g.reg && e.dir === g.dir)).slice(0, 80);
    const lim = a.limit;
    FB.ex = ex; FB.exLim = lim;
    return `<details class="fbex"><summary><b>5. 🔍 Contoh kejadian (${ex.length} setup terbaru di kelompok ini)</b> <small class="hint">klik baris untuk buka di Manual Replay — cek apakah hitungannya benar di chart</small></summary>
      <p class="hint">Waktu = candle saat fibo digambar (swing ujung terkonfirmasi). Garis: kuning = 0 &amp; 1.0, abu-abu = level fibo,
        biru = ${lim ? `limit terbaik ${lim.level}` : "limit"}, merah = SL (di luar 1.0 + buffer), hijau = TP${lim ? ` ${lim.target}` : ""}.</p>
      <div class="scroll" style="max-height:420px"><table class="tbl"><tr><th>Waktu (UTC)</th><th>Koin</th><th>Arah</th><th>Kondisi</th>
        <th class="num">Koreksi terdalam</th><th>${lim ? `Limit ${lim.level} → TP ${lim.target}` : "Limit"}</th><th>Akhir gelombang</th></tr>` +
      (ex.length ? ex.map((e, i) => { const r = fibExRes(e, res, lim);
        return `<tr data-ex="${i}" title="Buka di chart"><td>${fmtTime(e.t).slice(0, 16)}</td><td>${esc(e.symbol || "")}</td>
          <td class="${e.dir > 0 ? "pos" : "neg"}">${e.dir > 0 ? "BUY" : "SELL"}</td><td>${["Sideways", "Bullish", "Bearish"][e.reg === 1 ? 1 : e.reg === -1 ? 2 : 0]}</td>
          <td class="num">${e.depth.toFixed(3)}</td><td class="${r.cls}">${r.txt}</td><td>${FB_END[e.end] || "—"}</td></tr>`; }).join("")
        : '<tr><td colspan="7" class="hint">Tidak ada contoh di kelompok ini.</td></tr>') + "</table></div></details>";
  }
  PANE.addEventListener("click", async (e) => {
    const tr = e.target.closest("tr[data-ex]");
    if (!tr || !FB.ex || !FB.res) return;
    const x = FB.ex[+tr.dataset.ex], lim = FB.exLim, d = x.dir, rng = x.top - x.bot, P0 = d > 0 ? x.top : x.bot;
    const lv = (f) => P0 - d * f * rng;
    const marks = [{ price: lv(0), color: "#eab308", size: 2, label: "0" }, { price: lv(1), color: "#eab308", size: 2, label: "1.0" }];
    for (const f of FB.res.ret || []) if (f < 1 && (!lim || f !== lim.level)) marks.push({ price: lv(f), color: "rgba(160,170,190,.8)", dash: true, label: String(f) });
    if (lim) {
      marks.push({ price: lv(lim.level), color: "#42a5f5", size: 2, label: `Limit ${lim.level}` });
      marks.push({ price: lv(Number(lim.target)), color: "#26a69a", dash: true, label: `TP ${lim.target}` });
    }
    marks.push({ price: x.sl, color: "#ef5350", dash: true, label: "SL" });
    const r = fibExRes(x, FB.res, lim);
    await openMoment(x.symbol, FB.res.params.tf, x.t, marks,
      `${fmtTime(x.t).slice(0, 16)} ${x.symbol}: fibo ${d > 0 ? "BUY (low → high)" : "SELL (high → low)"} baru digambar. Koreksi terdalam ${x.depth.toFixed(3)} · ` +
      `${lim ? `limit ${lim.level}: ${r.txt.replace(/<[^>]+>/g, "")} · ` : ""}akhir: ${(FB_END[x.end] || "").replace(/^\S+ /, "")} (${fmtTime(x.t_end).slice(0, 16)}). Step maju untuk melihat kelanjutannya.`);
  });
  function renderFib() {
    const res = FB.res;
    if (!res || !res.n) { $("fbConc").innerHTML = ""; if ($("fbFlow")) $("fbFlow").innerHTML = ""; $("fbBody").innerHTML = '<p class="hint">Tidak ada setup yang memenuhi syarat. Coba TF lebih kecil, swing lebih kecil, atau periode lebih panjang.</p>'; return; }
    renderConclusion(res);
    if (V === 2 && $("fbFlow")) {
      $("fbFlow").innerHTML = flowBlock(res);
      if ($("fbCopyFlow")) $("fbCopyFlow").onclick = () => copyText(flowText(res)).then(() => toast("Workflow & threshold disalin"));
    }
    $("fbGroups").innerHTML = res.groups.map((g) => `<button data-k="${g.key}" class="${g.key === FB.group ? "on" : ""} ${g.note === "koreksi melawan tren" ? "counter" : ""}"
      title="${g.note === "koreksi melawan tren" ? "Melawan tren: hanya data, tidak disarankan untuk entry" : ""}">${g.note === "koreksi melawan tren" ? "⚠️ " : ""}${esc(fbGroupName(g))} <small>${g.n.toLocaleString("id-ID")}</small></button>`).join("");
    const g = res.groups.find((x) => x.key === FB.group) || res.groups[0];
    if (!g.n) { $("fbBody").innerHTML = `<p class="hint">Tidak ada setup di kelompok ini.</p>`; return; }
    const d = g.dir || 1;
    const a = g.advice || {};
    const ex = d > 0 ? "contoh: tarik fibo low 100 → high 200 (BUY)" : "contoh: tarik fibo high 200 → low 100 (SELL)";
    const conc = `<div class="fbconc">
      <div class="sugg ${a.limit ? (a.limit.valid ? "good" : "low") : "info"}"><div class="t">🎯 Level limit terbaik</div><div class="d">${limitCard(a.limit, d, g)}
        ${!g.plan && a.high_wr ? `<div class="e" style="margin-top:6px">WR tertinggi yang tetap untung: limit <b>${a.high_wr.level}</b>, TP <b>${a.high_wr.target}</b> —
          latih WR ${f2(a.high_wr.fit_wr)}% (${rTxt(a.high_wr.fit_r)}/trade), uji WR ${f2(a.high_wr.test_wr)}% (${rTxt(a.high_wr.test_r)}/trade) · ${a.high_wr.valid ? "lolos uji" : "tidak lolos uji"}</div>` : ""}</div></div>
      <div class="sugg ${a.alarm ? "high" : "info"}"><div class="t">🚨 Level alarm (tanda awal BOS)</div><div class="d">${a.alarm
        ? `Kalau candle <b>close tembus ${a.alarm.level}</b>, <b>${f2(a.alarm.bos_pct)}%</b> akhirnya jadi BOS (struktur patah), rata-rata ${a.alarm.bars_med ?? "?"} candle kemudian.
           Data uji: ${a.alarm.test_bos_pct == null ? "—" : f2(a.alarm.test_bos_pct) + "%"}. Batalkan entry ini; mulai cari arah sebaliknya.`
        : "Tidak ada level yang tembusannya ≥ 70% jadi BOS (atau data kurang)."}</div></div>
      <div class="sugg ${a.target_after_bos ? "medium" : "info"}"><div class="t">📍 Target setelah BOS</div><div class="d">${a.target_after_bos
        ? `Setelah BOS, ${f2(a.target_after_bos.pct)}% sampai <b>${a.target_after_bos.level}</b> (${f2(fbPrice(a.target_after_bos.level, d))} di contoh). Cocok untuk TP posisi arah sebaliknya.`
        : "Data BOS belum cukup."}</div></div></div>`;
    const bestLv = g.plan ? g.plan.entry : a.limit && a.limit.level, alarmLv = a.alarm && a.alarm.level;
    const lvRows = g.levels.map((x) => {
      const tst = (g.test.levels || []).find((y) => y.level === x.level) || {};
      return `<tr class="${x.level === bestLv ? "best" : ""}"><td><b>${x.level}</b>${alarmLv && x.level >= alarmLv ? ` <span title="Di / lewat level alarm ${alarmLv}: kalau candle close di sini struktur biasanya patah. Tidak disarankan untuk entry.">⚠️</span>` : ""}</td><td class="num">${f2(fbPrice(x.level, d))}</td>
        <td class="num">${f2(x.touch)}%</td><td class="num">${f2(x.fill)}%</td>
        <td class="num">${x.wr_0 == null ? "—" : f2(x.wr_0) + "%"}</td><td class="num">${x["wr_-0.272"] == null ? "—" : f2(x["wr_-0.272"]) + "%"}</td>
        <td class="num">${x["wr_-0.618"] == null ? "—" : f2(x["wr_-0.618"]) + "%"}</td>
        <td class="num">${x.bounce_pct == null ? "—" : f2(x.bounce_pct) + "%"}</td>
        <td class="num">${tst.wr_0 == null ? "—" : f2(tst.wr_0) + "%"}</td></tr>`;
    }).join("");
    const maxT = Math.max(1, ...g.turn.map((x) => x.pct), g.end.bos);
    const hist = `<div class="fbhist">${g.turn.map((x) => `<div>${lvTxt(x.lo)} – ${x.hi}</div><div class="bar"><i style="width:${(100 * x.pct) / maxT}%"></i></div><div class="num">${f2(x.pct)}%</div>`).join("")}
      <div>tembus 1.0 (BOS)</div><div class="bar bos"><i style="width:${(100 * g.end.bos) / maxT}%"></i></div><div class="num">${f2(g.end.bos)}%</div></div>`;
    const brRows = g.breaks.map((x) => `<tr class="${x.level === alarmLv ? "alarm" : ""}"><td><b>${x.level}</b></td><td class="num">${f2(fbPrice(x.level, d))}</td>
      <td class="num">${x.broke} <span class="muted">(${f2(x.broke_pct)}%)</span></td><td class="num ${x.bos_pct >= 70 ? "neg" : ""}">${f2(x.bos_pct)}%</td>
      <td class="num">${f2(x.fake_pct)}%</td><td class="num">${f2(x.open_pct)}%</td><td class="num">${x.bars_med ?? "—"}</td></tr>`).join("");
    const ab = g.after_bos;
    const abRows = ab.reach.map((x) => `<tr><td><b>${x.level}</b></td><td class="num">${f2(fbPrice(x.level, d))}</td><td class="num">${f2(x.pct)}%</td></tr>`).join("");
    $("fbBody").innerHTML = `<h3>${esc(fbGroupName(g))} <span class="hint">${g.n.toLocaleString("id-ID")} setup · ${ex}</span></h3>
      ${conc}
      ${FB.opened ? `<div class="openbanner">📂 Hasil tersimpan: <b>${esc(FB.opened.name)}</b> · disimpan ${new Date(FB.opened.created).toLocaleString("id-ID")}</div>` : ""}
      <div class="evalbtns"><button class="primary" id="${FBP}Use">Pakai di strategi FibPrecision</button>
        ${FB.opened ? "" : `<button id="${FBP}Save">💾 Simpan hasil studi</button>`}
        <span class="hint">Isi level terbaik (yang lolos uji) tiap kondisi pasar ke strategi FibPrecision di Auto Backtest.</span></div>
      ${strengthSection(g, d, res.params)}
      <h4>1. Limit entry di tiap level: sering tersentuh? menang? memantul sejauh apa?</h4>
      <p class="hint">Limit di level, SL di luar 1.0 (+buffer), TP di 0 / −0.272 / −0.618. Tersentuh = ekor candle sampai level (dari semua setup).
        Terisi = limit sempat terisi setelah Fibonacci digambar. Pantulan = median gerak searah (%) setelah terisi sebelum kena SL.</p>
      <div class="scroll"><table class="tbl"><tr><th>Level</th><th class="num">Harga contoh</th><th class="num">Tersentuh</th><th class="num">Terisi</th>
        <th class="num">WR → 0</th><th class="num">WR → −0.272</th><th class="num">WR → −0.618</th><th class="num">Pantulan median</th>
        <th class="num">WR → 0 (data uji)</th></tr>${lvRows}</table></div>
      <h4>2. Harga berbalik (mentok) di mana sebelum lanjut</h4><p class="hint">Titik terdalam koreksi pada setup yang akhirnya lanjut (close tembus 0), dan berapa yang malah tembus 1.0.</p>${hist}
      <h4>3. Candle close tembus level → jadi BOS?</h4>
      <p class="hint">Dihitung dari setup yang levelnya belum tembus saat Fibonacci digambar. Jadi BOS = setelah close tembus level, harga close tembus 1.0 (struktur patah) sebelum bikin ${d > 0 ? "high" : "low"} baru.
        Palsu = malah lanjut bikin ${d > 0 ? "high" : "low"} baru. Tembusan di candle BOS itu sendiri tidak dihitung (bukan tanda awal).</p>
      <div class="scroll"><table class="tbl"><tr><th>Close tembus</th><th class="num">Harga contoh</th><th class="num">Kejadian</th><th class="num">Jadi BOS</th>
        <th class="num">Palsu</th><th class="num">Belum jelas</th><th class="num">Median candle ke BOS</th></tr>${brRows}</table></div>
      <h4>4. Setelah BOS, harga sampai mana (sebelum close balik ke dalam struktur)</h4>
      <table class="tbl"><tr><th>Extension</th><th class="num">Harga contoh</th><th class="num">Tercapai</th></tr>${abRows}</table>
      <p class="hint">${ab.n} setup BOS. Data uji = 30% setup terakhir (setelah ${fmtDate(res.split)}).</p>
      ${fibExamplesHtml(res, g, a)}`;
    $("fbUse").onclick = useFibInStrategy;
    const ks = $("fbK");
    if (ks) ks.onchange = () => { FB.k = +ks.value; renderFib(); };
    if ($("fbSave")) $("fbSave").onclick = saveFib;
  }
  $("fbGroups").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-k]");
    if (!b) return;
    FB.group = b.dataset.k;
    renderFib();
  });
  // ---- simpan / buka hasil studi
  const fbTitle = (p, symbols, coins) => `${(p.tf || "").toUpperCase()} · kondisi ${(p.regime_tf || "").toUpperCase()} · ${symbols == null ? `${coins ?? "semua"} koin` : symbols.length === 1 ? symbols[0] : symbols.length + " koin"}`;
  async function saveFib(auto = false) {
    if (!FB.res) return;
    const def = `${fbTitle(FB.res.params, FB.meta.symbols, FB.meta.coins)} · ${new Date().toLocaleDateString("id-ID")}`;
    const name = auto === true ? `${def} · otomatis ${new Date().toLocaleTimeString("id-ID")}` : prompt("Nama hasil studi:", def);
    if (name === null) return;
    const r = await fetch(`/api/fibsaved${SUF}`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name || def, result: FB.res, ...FB.meta }) });
    if (!r.ok) return toast("Gagal menyimpan");
    const it = await r.json();
    FB.opened = it;
    renderFib();
    await loadFibSaved();
    $("fbSaved").open = true;
    toast("Hasil studi disimpan. Buka lagi kapan saja dari '📂 Hasil studi tersimpan'.");
  }
  async function loadFibSaved() {
    const list = await (await fetch(`/api/fibsaved${SUF}`)).json();
    $("fbSavedCount").textContent = `(${list.length})`;
    $("fbSavedList").innerHTML = list.map((x) => `<div class="saved-item ${FB.opened && FB.opened.id === x.id ? "on" : ""}" data-id="${x.id}">
      <div class="nm" title="Klik 2x untuk ganti nama">${esc(x.name)}</div>
      <div class="meta">${esc(fbTitle(x.params || {}, x.symbols, x.coins))} · ${(x.n || 0).toLocaleString("id-ID")} setup ·
        ${x.start || x.end ? `${fmtDate(x.start)} → ${fmtDate(x.end)}` : "seluruh data"} · disimpan ${new Date(x.created).toLocaleString("id-ID")}</div>
      <button class="mini fb-open">Buka</button><button class="mini fb-del">Hapus</button></div>`).join("")
      || '<p class="hint">Belum ada. Setelah studi selesai, klik 💾 Simpan hasil studi.</p>';
  }
  $("fbSavedList").addEventListener("click", async (e) => {
    const it = e.target.closest(".saved-item");
    if (!it) return;
    const id = it.dataset.id;
    if (e.target.classList.contains("fb-open")) {
      const full = await (await fetch(`/api/fibsaved${SUF}/${id}`)).json();
      FB.res = full.result;
      FB.opened = full;
      FB.group = "all";
      $("fbOut").classList.remove("hidden");
      $("fbLive").classList.add("hidden");
      renderFib();
      loadFibSaved();
      $("fbOut").scrollIntoView({ behavior: "smooth", block: "start" });
    }
    if (e.target.classList.contains("fb-del") && confirm(`Hapus "${it.querySelector(".nm").textContent}"?`)) {
      await fetch(`/api/fibsaved${SUF}/${id}`, { method: "DELETE" });
      if (FB.opened && FB.opened.id === id) FB.opened = null;
      loadFibSaved();
    }
  });
  $("fbSavedList").addEventListener("dblclick", async (e) => {
    const nm = e.target.closest(".nm");
    if (!nm) return;
    const id = nm.parentElement.dataset.id;
    const name = prompt("Nama baru:", nm.textContent);
    if (!name) return;
    await fetch(`/api/fibsaved${SUF}/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name }) });
    if (FB.opened && FB.opened.id === id) { FB.opened.name = name; renderFib(); }
    loadFibSaved();
  });

  function useFibInStrategy() {
    const res = FB.res;
    if (!STRATS.some((x) => x.name === "FibPrecision")) return toast("Strategi FibPrecision tidak ditemukan");
    const p = res.params, out = { tf: p.tf, regime_tf: p.regime_tf, swing: p.swing, min_leg_atr: p.min_leg_atr, adx_min: p.adx_min,
      sl_buffer_atr: 0, max_bars: p.max_bars, target: "0", sl_level: 1.0 };
    const used = [];
    for (const g of res.groups) {
      if (g.key === "all") continue;
      const counter = g.reg !== 0 && g.reg !== g.dir;
      const pl = g.plan;
      const ok = pl && pl.entry && pl.valid && !counter;
      out["lvl_" + g.key] = ok ? pl.entry : 0;
      out["tp_" + g.key] = ok ? String(pl.tp1.level) : "";
      out["sl_" + g.key] = ok && pl.sl && pl.sl.best ? pl.sl.best : 0;
      if (ok) used.push(`${fbGroupName(g)}: entry ${pl.entry} · TP ${pl.tp1.level} · SL ${out["sl_" + g.key] || 1.0}`);
    }
    if (!res.groups.some((g) => g.plan)) {   // hasil lama (sebelum v3.12): pakai cara lama
      for (const g of res.groups) {
        if (g.key === "all") continue;
        const lim = g.advice && g.advice.limit;
        out["lvl_" + g.key] = lim && lim.valid ? lim.level : 0;
      }
      out.sl_buffer_atr = p.sl_buffer_atr;
    }
    document.querySelector('.tab[data-tab="backtest"]').click();
    applyThreshold("FibPrecision", out);
    toast(used.length ? `Dipasang: ${used.join(" | ")}. Kondisi lain = 0 (tidak trade). Klik Jalankan.` : "Tidak ada rencana yang lolos uji; semua kondisi diisi 0.");
  }

  function init() {
      const tfs = ["5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"], f = store.get(FORM_KEY, {});
      $("fbTf").innerHTML = tfs.map((t) => `<option value="${t}">${t.toUpperCase()}</option>`).join("");
      $("fbRegTf").innerHTML = $("fbTf").innerHTML;
      $("fbTrendTf").innerHTML = $("fbTf").innerHTML;
      $("fbTrendTf").value = f.trend_tf || DEF.trend_tf;
      $("fbTf").value = f.tf || DEF.tf; $("fbRegTf").value = f.regime_tf || DEF.regime_tf;
      for (const [id, k] of [["fbSwing", "swing"], ["fbMinLeg", "min_leg_atr"], ["fbAdx", "adx_min"], ["fbSlBuf", "sl_buffer_atr"], ["fbMaxBars", "max_bars"],
        ...(V === 2 ? [["fbEmaFast", "ema_fast"], ["fbEmaSlow", "ema_slow"]] : [])])
        if (f[k] != null) $(id).value = f[k];
      $("fbScope").value = f.scope || "all";
      $("fbSymbols").value = f.symbols || "";
      const fbAtr = () => PANE.querySelectorAll(".fbatr").forEach((t) => (t.textContent = `ATR · ${$("fbTf").value.toUpperCase()}`));
      $("fbTf").addEventListener("change", fbAtr);
      fbAtr();
      $("fbScope").onchange = fbScopeChanged;
      fbScopeChanged();
      $("fbRun").onclick = runFib;
      loadFibSaved();
      $("fbCancel").onclick = () => FB.id && fetch(`/api/fibstudy${SUF}/${FB.id}/cancel`, { method: "POST" });
      bindPauseBtn($("fbPause"), V === 2 ? "fib2" : "fib", () => FB.id, () => { clearTimeout(FB.timer); pollFib(); });
  }
  function resume(busy) {
      FB.id = busy.id;
      FB.shownLegs = 0;
      $("fbRun").disabled = true;
      $("fbCancel").classList.remove("hidden");
      $("fbOut").classList.remove("hidden");
      $("fbLive").classList.remove("hidden");
      startTips(FBP + "Tip");
      pollFib();
  }
  return { FB, init, resume };
}
// v2: salin panel v1 (id fb* -> f2*), lalu jalankan kode yang sama dengan set angka & TF default v2
{
  const p1 = document.getElementById("tab-fib"), p2 = p1.cloneNode(true);
  p2.id = "tab-fib2";
  p2.classList.remove("active");
  p2.querySelectorAll("[id]").forEach((el) => { if (el.id.startsWith("fb")) el.id = "f2" + el.id.slice(2); });
  p2.querySelectorAll("[data-from], [data-to]").forEach((el) => {
    el.dataset.from = el.dataset.from.replace(/^fb/, "f2"); el.dataset.to = el.dataset.to.replace(/^fb/, "f2"); });
  p2.querySelector("h3").textContent = "Studi Fibonacci v2";
  const hint = document.createElement("p");
  hint.className = "hint";
  hint.innerHTML = "Angka fibo v2: <b>−0.618 · −0.414 · −0.272 · −0.13 · 0 · 0.295 · 0.382 · 0.441 · 0.5 · 0.559 · 0.618 · 0.705 · 1 · 1.13 · 1.272 · 1.414 · 1.618</b>. Default TF fibo M5, kondisi pasar &amp; tren H1 (bisa diganti).";
  p2.querySelector("h3").after(hint);
  const tr = p2.querySelector("#f2TrendTf").closest(".field");
  tr.insertAdjacentHTML("afterend", `<div class="field"><label title="EMA cepat untuk tren (bullish = EMA cepat di atas EMA lambat)">EMA cepat</label><input id="f2EmaFast" type="number" min="1" value="50"></div>
    <div class="field"><label title="EMA lambat untuk tren">EMA lambat</label><input id="f2EmaSlow" type="number" min="2" value="200"></div>`);
  tr.querySelector("label").textContent = "TF tren (EMA)";
  p1.after(p2);
}
const FIBS = { 1: makeFib(1), 2: makeFib(2) };
const FB = FIBS[1].FB;
renderPeriodButtons();
// ------------------------------------------------------------------ screener (live Binance Futures)
const SC = { fields: [], intervals: [], filters: [], rows: [], columns: [], sort: { key: "vol_24h", dir: -1 }, timer: null, busy: false };
const OPS = [["gte", "≥"], ["gt", ">"], ["lte", "≤"], ["lt", "<"], ["between", "antara"], ["eq", "="],
  ["xup", "cross ↑"], ["xdn", "cross ↓"]];
const NO_LEN = (f) => { const d = SC.fields.find((x) => x.key === f); return !d || d.len == null; };
const fieldLabel = (key) => {   // "rsi(14)" -> "RSI 14"
  const m = key.match(/^([a-z_0-9]+?)(?:\((\d+)\))?$/), d = SC.fields.find((x) => x.key === (m ? m[1] : key));
  return d ? d.label + (m && m[2] ? " " + m[2] : "") : key;
};
function fieldSelect(cls, val) {
  const groups = [...new Set(SC.fields.map((f) => f.group))];
  return `<select class="${cls}">` + groups.map((g) => `<optgroup label="${g}">` + SC.fields.filter((f) => f.group === g)
    .map((f) => `<option value="${f.key}" ${f.key === val ? "selected" : ""}>${f.label}</option>`).join("") + "</optgroup>").join("") + "</select>";
}
function renderFilters() {
  $("scFilters").innerHTML = SC.filters.map((f, i) => {
    const bIsField = "f" in f.b;
    const rhs = f.op === "between"
      ? `<input type="number" step="any" class="bv" value="${f.b.v ?? ""}"><input type="number" step="any" class="b2" value="${(f.b2 || {}).v ?? ""}">`
      : `<select class="btype"><option value="v" ${bIsField ? "" : "selected"}>angka</option><option value="f" ${bIsField ? "selected" : ""}>indikator</option></select>` +
        (bIsField ? fieldSelect("bf", f.b.f) + (NO_LEN(f.b.f) ? "" : `<input type="number" class="len blen" value="${f.b.len}">`)
                  : `<input type="number" step="any" class="bv" value="${f.b.v ?? ""}">`);
    return `<div class="frow" data-i="${i}">${fieldSelect("af", f.a.f)}` +
      (NO_LEN(f.a.f) ? "<span></span>" : `<input type="number" class="alen" title="Periode" value="${f.a.len}">`) +
      `<select class="op">${OPS.map(([k, l]) => `<option value="${k}" ${k === f.op ? "selected" : ""}>${l}</option>`).join("")}</select>` +
      `<button class="rm" title="Hapus filter">×</button><div class="rhs">${rhs}</div></div>`;
  }).join("") || '<p class="hint">Belum ada filter: semua koin akan ditampilkan.</p>';
}
function defLen(f) { const d = SC.fields.find((x) => x.key === f); return d ? d.len : null; }
$("scFilters").addEventListener("change", (e) => {
  const row = e.target.closest(".frow");
  if (!row) return;
  const f = SC.filters[+row.dataset.i], t = e.target;
  if (t.classList.contains("af")) f.a = { f: t.value, len: defLen(t.value) };
  if (t.classList.contains("alen")) f.a.len = +t.value;
  if (t.classList.contains("op")) { f.op = t.value; if (f.op === "between") { f.b = { v: f.b.v ?? 0 }; f.b2 = f.b2 || { v: 100 }; } }
  if (t.classList.contains("btype")) f.b = t.value === "f" ? { f: "ema", len: 200 } : { v: 0 };
  if (t.classList.contains("bf")) f.b = { f: t.value, len: defLen(t.value) };
  if (t.classList.contains("blen")) f.b.len = +t.value;
  if (t.classList.contains("bv")) f.b = { v: +t.value };
  if (t.classList.contains("b2")) f.b2 = { v: +t.value };
  renderFilters();
  store.set("scState", { tf: $("scTf").value, closed: $("scClosed").checked, filters: SC.filters, limit: $("scLimit").value });
});
$("scFilters").addEventListener("click", (e) => {
  if (!e.target.classList.contains("rm")) return;
  SC.filters.splice(+e.target.closest(".frow").dataset.i, 1);
  renderFilters();
});
const BASE_COLS = [{ f: "close" }, { f: "chg_24h" }, { f: "vol_24h" }];
// ---- market structure: gembok kode (▲ / ▼ ganti kode per baris), 3-6 baris
const MS_CODES = ["HH", "HL", "LH", "LL", "ANY"];
const MS_NAME = { HH: "HH", HL: "HL", LH: "LH", LL: "LL", ANY: "Bebas" };
const MS_TIP = { HH: "Higher High: swing high lebih tinggi dari swing high sebelumnya", HL: "Higher Low: swing low lebih tinggi dari swing low sebelumnya",
  LH: "Lower High: swing high lebih rendah dari swing high sebelumnya", LL: "Lower Low: swing low lebih rendah dari swing low sebelumnya", ANY: "Bebas: swing apa saja" };
const MS = { codes: ["HH", "HL", "HH", "HL", "HH", "HL"], n: 4 };
function msRender() {
  $("msLock").innerHTML = MS.codes.slice(0, MS.n).map((c, i) => `<div class="msrow" data-i="${i}">
      <span class="msno">${i + 1}${i === 0 ? " <small>lama</small>" : i === MS.n - 1 ? " <small>terbaru</small>" : ""}</span>
      <button type="button" class="mini msup" title="Kode sebelumnya">▲</button>
      <span class="mscode ms-${c}" title="${MS_TIP[c]}">${MS_NAME[c]}</span>
      <button type="button" class="mini msdn" title="Kode berikutnya">▼</button></div>`).join("");
  document.querySelectorAll('input[name="msN"]').forEach((r) => (r.checked = +r.value === MS.n));
  const cs = MS.codes.slice(0, MS.n);
  // swing high & low selalu selang-seling: baris genap semua high atau semua low, baris ganjil kebalikannya
  const kind = (c) => (c === "HH" || c === "LH" ? "H" : c === "HL" || c === "LL" ? "L" : null);
  const ok = ["H", "L"].some((first) => cs.every((c, i) => !kind(c) || kind(c) === (i % 2 === 0 ? first : first === "H" ? "L" : "H")));
  $("msBox").classList.toggle("off", !$("msOn").checked);
  $("msPreview").innerHTML = ($("msOn").checked ? "✅ <b>Aktif</b> · " : "⛔ <b>Mati</b> (centang untuk memakai pola ini) · ") +
    "Pola: <b>" + cs.map((c) => MS_NAME[c]).join(" → ") + "</b> (kiri = lama, kanan = terbaru)" +
    (ok ? "" : '<br><span class="neg">⚠️ Pola ini tidak mungkin terjadi: swing high (HH/LH) dan swing low (HL/LL) selalu selang-seling. ' +
      "Contoh yang benar: HH → HL → HH → HL (tren naik) atau LH → LL → LH → LL (tren turun).</span>");
  store.set("msState", { codes: MS.codes, n: MS.n, on: $("msOn").checked, bars: $("msBars").value, swing: $("msSwing").value,
    min_atr: $("msMinAtr").value, live: $("msLive").checked });
}
$("msLock").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const i = +b.closest(".msrow").dataset.i, k = MS_CODES.indexOf(MS.codes[i]);
  MS.codes[i] = MS_CODES[(k + (b.classList.contains("msup") ? -1 : 1) + MS_CODES.length) % MS_CODES.length];
  $("msOn").checked = true;              // mengatur kode = mau scan struktur
  msRender();
});
document.querySelectorAll('input[name="msN"]').forEach((r) => r.addEventListener("change", () => { MS.n = +r.value; $("msOn").checked = true; msRender(); }));
{
  const st = store.get("msState", null);
  if (st) {
    if (Array.isArray(st.codes) && st.codes.length === 6 && st.codes.every((c) => MS_CODES.includes(c))) MS.codes = st.codes;
    MS.n = Math.min(6, Math.max(3, +st.n || 4));
    $("msOn").checked = !!st.on;
    if (st.bars) $("msBars").value = st.bars;
    if (st.swing) $("msSwing").value = st.swing;
    if (st.min_atr != null) $("msMinAtr").value = st.min_atr;
    if (st.live != null) $("msLive").checked = !!st.live;
  }
  ["msOn", "msBars", "msSwing", "msMinAtr", "msLive"].forEach((id) => $(id).addEventListener("change", msRender));
  msRender();
}
function msRequest() {
  if (!$("msOn").checked) return null;
  return { codes: MS.codes.slice(0, MS.n), bars: +$("msBars").value || 200, swing: +$("msSwing").value || 3,
    min_atr: Math.max(0, +$("msMinAtr").value || 0), live: $("msLive").checked };
}
const SC_TIPS = [
  "💡 Pilih <b>Jumlah koin</b> lebih sedikit (mis. 20–50 koin volume terbesar) supaya scan jauh lebih cepat.",
  "💡 <b>HH → HL → HH → HL</b> = tren naik, <b>LH → LL → LH → LL</b> = tren turun. Swing high &amp; low selalu selang-seling.",
  "💡 Tanda <b>*</b> = swing yang sedang berjalan (belum terkonfirmasi). Bisa berubah di candle berikutnya.",
  "💡 Swing terlalu kecil? Naikkan <b>Min. besar swing (×ATR)</b> atau <b>Swing (fractal)</b> untuk membaca struktur yang lebih besar.",
  "💡 Scan pertama mengambil data semua koin dari Binance; scan berikutnya jauh lebih cepat karena hanya candle terbaru.",
  "💡 Klik nama koin di hasil untuk membuka chart di Manual Replay.",
];
function scWhat() {
  const ms = msRequest();
  const parts = [`TF <b>${$("scTf").value.toUpperCase()}</b>`, $("scLimit").value === "0" ? "semua koin" : `${$("scLimit").value} koin volume terbesar`];
  if (ms) parts.push(`struktur <b>${ms.codes.map((c) => MS_NAME[c]).join(" → ")}</b> di ${ms.bars} candle`);
  if (SC.filters.length) parts.push(`${SC.filters.length} filter`);
  return parts.join(" · ");
}
async function runScan(silent) {
  if (SC.busy) return;
  SC.busy = true;
  $("scRun").disabled = true;
  store.set("scState", { tf: $("scTf").value, closed: $("scClosed").checked, filters: SC.filters, limit: $("scLimit").value });
  const body = { tf: $("scTf").value, closed_only: $("scClosed").checked, filters: SC.filters, columns: BASE_COLS,
    structure: msRequest(), limit: +$("scLimit").value || null };
  if (!silent) {
    $("scStatus").textContent = "Memindai…";
    $("scLive").classList.remove("hidden");
    $("scPct").textContent = "0"; $("scBar").style.width = "1%"; $("scRecent").innerHTML = "";
    $("scTitle").innerHTML = 'Mengambil daftar koin dari Binance<span class="dots"></span>';
    $("scWhat").innerHTML = scWhat();
    startTips("scTip", SC_TIPS);
  }
  try {
    const r = await fetch("/api/screener/start", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    let st;
    for (;;) {
      st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (!silent) {
        const pct = st.total ? (100 * st.done) / st.total : 0;
        $("scPct").textContent = Math.floor(pct);
        $("scBar").style.width = Math.max(pct, 1) + "%";
        $("scCoins").textContent = `${st.done}/${st.total || "?"}`;
        $("scElapsed").textContent = fmtDur(st.elapsed);
        $("scEta").textContent = st.status !== "running" ? "0 dtk" : st.eta == null ? "menghitung…" : "±" + fmtDur(st.eta);
        $("scTitle").innerHTML = st.status === "running" ? (st.total ? `Memindai ${st.total} koin<span class="dots"></span>` : 'Mengambil daftar koin dari Binance<span class="dots"></span>') : "Selesai! 🎉";
        $("scRecent").innerHTML = st.recent.map((x) => `<li><span>${x.error ? "⚠️" : "✅"} ${esc(x.symbol)}</span></li>`).join("");
      }
      if (st.status !== "running") break;
      await new Promise((ok) => setTimeout(ok, 500));
    }
    if (st.status === "error") throw new Error(st.error);
    const res = st.result;
    SC.rows = res.rows;
    SC.columns = ["close", "chg_24h", "vol_24h", ...res.columns.filter((c) => !["close", "chg_24h", "vol_24h"].includes(c))];
    SC.ms = res.structure || null;
    if (SC.ms) SC.columns.push("ms_age");
    $("scStatus").textContent = `Update ${new Date(res.time).toLocaleTimeString()} · ${res.scanned} koin dipindai dalam ${res.elapsed} dtk` +
      (res.errors ? ` · ${res.errors} gagal` : "") + (res.closed_only ? " · candle close" : " · termasuk candle berjalan") +
      (res.structure ? ` · struktur ${res.structure.codes.map((c) => MS_NAME[c]).join("-")} di ${res.structure.bars} candle ${res.interval.toUpperCase()}`
        : " · ⛔ scan market structure MATI (semua koin ditampilkan)");
    renderScTable();
  } catch (e) {
    $("scStatus").innerHTML = `<span class="neg">Gagal: ${esc(e.message)}</span><br>Kalau Binance diblokir di jaringan lu: ganti DNS ke 1.1.1.1 / 8.8.8.8, atau pakai VPN, lalu coba lagi.`;
  } finally {
    SC.busy = false;
    $("scRun").disabled = false;
    clearInterval(TIP_TIMERS.scTip);
    setTimeout(() => $("scLive").classList.add("hidden"), silent ? 0 : 1200);
  }
}
const fmtNum = (k, v) => {
  if (v == null) return "—";
  if (k === "ms_age") return String(Math.round(v));
  if (k === "vol_24h" || k === "vol") return v >= 1e9 ? (v / 1e9).toFixed(2) + "B" : v >= 1e6 ? (v / 1e6).toFixed(2) + "M" : (v / 1e3).toFixed(1) + "K";
  if (k === "close" || /^(ema|sma)\(/.test(k)) return v.toPrecision(6).replace(/\.?0+$/, "");
  return Math.abs(v) >= 1000 ? v.toFixed(0) : v.toFixed(2);
};
function renderScTable() {
  const q = $("scSearch").value.trim().toUpperCase();
  const { key, dir } = SC.sort;
  const rows = SC.rows.filter((r) => !q || r.symbol.includes(q)).sort((a, b) => {
    if (key === "symbol") return dir * a.symbol.localeCompare(b.symbol);
    const x = a.values[key], y = b.values[key];
    return x == null ? 1 : y == null ? -1 : dir * (x - y);
  });
  $("scCount").textContent = `(${rows.length} koin)`;
  const th = (k, label, num) => `<th data-k="${k}" class="${num ? "num" : ""} ${key === k ? "sorted" : ""}" data-dir="${dir > 0 ? "▲" : "▼"}">${label}</th>`;
  const cls = (k, v) => (k.startsWith("chg") && v != null ? (v > 0 ? "pos" : v < 0 ? "neg" : "") : "");
  const lbl = (c) => (c === "ms_age" ? "Swing terakhir (candle lalu)" : fieldLabel(c));
  $("scTable").innerHTML = "<tr>" + th("symbol", "Koin") + (SC.ms ? "<th>Struktur (lama → baru)</th>" : "") + SC.columns.map((c) => th(c, lbl(c), true)).join("") + "</tr>" +
    rows.map((r) => `<tr><td><a class="symlink" data-sym="${r.symbol}">${r.symbol}</a><a class="ext" target="_blank" rel="noopener" href="https://www.binance.com/en/futures/${r.symbol}">↗</a>
      <button class="mini sc-vis" data-sym="${r.symbol}" title="Gambar visual entry (Screener Market Structure) koin ini">📐 Visual</button></td>` +
      (SC.ms ? `<td>${(r.structure || "").split("-").map((c) => `<span class="mscode sm ms-${c.replace("*", "")}" title="${c.includes("*") ? "swing sementara: gerakan yang sedang berjalan, belum terkonfirmasi" : ""}">${c}</span>`).join("")}</td>` : "") +
      SC.columns.map((c) => `<td class="num ${cls(c, r.values[c])}">${fmtNum(c, r.values[c])}</td>`).join("") + "</tr>").join("");
}
$("scTable").addEventListener("click", async (e) => {
  const h = e.target.closest("th");
  if (h) {
    SC.sort = { key: h.dataset.k, dir: SC.sort.key === h.dataset.k ? -SC.sort.dir : -1 };
    return renderScTable();
  }
  const v = e.target.closest(".sc-vis");
  if (v) return scVisual(v.dataset.sym);
  const a = e.target.closest(".symlink");
  if (!a) return;
  const sym = a.dataset.sym;
  if (!(await loadSymbol(sym))) return toast(`Data lokal ${sym} belum ada. Jalankan update_data.bat dulu.`);
  $("symbol").value = sym;
  $("startAt").value = toInput(S.info.end);
  const tf = $("scTf").value;
  if (S.info.timeframes.includes(tf)) S.tf = tf;
  document.querySelector('.tab[data-tab="replay"]').click();
  await startReplay();
});
// 📐 kartu visual entry untuk koin hasil screener (struktur live -> pola di riwayat -> entry / SL / TP)
const SCV = { res: null, plan: 0, busy: false };
async function scVisual(sym) {
  if (SCV.busy) return toast("Masih membuat visual koin sebelumnya, tunggu sebentar.");
  const box = $("scVis");
  box.classList.remove("hidden"); SCV.busy = true;
  const tf = $("scTf").value;
  box.innerHTML = `<div class="card evalcard msc-empty"><h3>⏳ ${esc(sym)} ${esc(tf.toUpperCase())}: membaca struktur &amp; mencari pola di riwayat<span class="dots"></span></h3></div>`;
  box.scrollIntoView({ behavior: "smooth", block: "start" });
  try {
    SCV.res = await mscFetch({ symbol: sym, tf, swing: "kecil", scope: "all" }); SCV.plan = 0;
    renderScVisual();
  } catch (ex) {
    box.innerHTML = `<div class="card evalcard msc-empty"><h3>⚠️ Visual ${esc(sym)} gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { SCV.busy = false; }
}
function renderScVisual() {
  const R = mscNorm(SCV.res), box = $("scVis");
  if (!R.n_occ) { box.innerHTML = `<div class="card evalcard msc-empty"><h3>${esc(R.symbol)}: pola ${esc((R.pattern || []).join(" › "))} tidak ditemukan di riwayat</h3></div>`; return; }
  const B = SCV.plan === 0 ? R.best : R.plans[SCV.plan - 1], sg = (x) => `${x >= 0 ? "+" : ""}${x.toFixed(2)}R`;
  box.innerHTML = `<div class="msc-out"><div class="msc-card">${MSC.card(mscFull(R, B), B || null, false)}</div>
    <div class="msc-btns"><button class="mini${SCV.plan === 0 ? " on" : ""}" data-scp="0">⭐ Terbaik</button>
      ${R.plans.map((p, i) => `<button class="mini${SCV.plan === i + 1 ? " on" : ""}" data-scp="${i + 1}">${p.dir === 0 ? "🟢 LONG" : "🔴 SHORT"} ${sg(p.exp_sig != null ? p.exp_sig : p.exp_r)}/sinyal${p.usable === false ? " ⚠" : ""}</button>`).join("")}
      <span style="flex:1"></span><button class="mini" data-scv="copy">📋 Salin sinyal</button><button class="mini" data-scv="dl">⬇ Unduh gambar</button>
      <button class="mini" data-scv="open">📐 Detail di Market Structure</button><button class="mini" data-scv="close">✖ Tutup</button></div>
    ${R.note ? `<p class="hint">⚠️ ${esc(R.note)}</p>` : ""}</div>`;
}
$("scVis").addEventListener("click", async (e) => {
  const R = SCV.res;
  const p = e.target.closest("[data-scp]");
  if (p && R) { SCV.plan = +p.dataset.scp; return renderScVisual(); }
  const b = e.target.closest("[data-scv]");
  if (!b) return;
  if (b.dataset.scv === "close") { $("scVis").classList.add("hidden"); return; }
  if (!R) return;
  const B = SCV.plan === 0 ? R.best : R.plans[SCV.plan - 1];
  if (b.dataset.scv === "copy") { await copyText(MSC.signal(mscFull(R, B), B || null)); return toast("Sinyal disalin 📋"); }
  if (b.dataset.scv === "dl") { try { await MSC.download(mscFull(R, B), B || null); } catch (ex) { toast("Gagal membuat gambar: " + ex.message); } return; }
  if (b.dataset.scv === "open") {
    MSC_S.res = R; MSC_S.plan = SCV.plan;
    $("mscSym").value = R.symbol; if ([...$("mscTf").options].some((o) => o.value === R.tf)) $("mscTf").value = R.tf;
    document.querySelector('.tab[data-tab="msa"]').click(); renderMsc();
  }
});
function renderPresets() {
  const ps = store.get("scPresets", {});
  $("scPreset").innerHTML = '<option value="">— preset —</option>' + Object.keys(ps).map((n) => `<option>${n}</option>`).join("");
}
function exportCsv() {
  const cols = ["symbol", ...SC.columns];
  const lines = [cols.map((c) => (c === "symbol" ? "symbol" : fieldLabel(c))).join(",")]
    .concat(SC.rows.map((r) => [r.symbol, ...SC.columns.map((c) => r.values[c] ?? "")].join(",")));
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([lines.join("\n")], { type: "text/csv" }));
  a.download = `screener_${$("scTf").value}_${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.csv`;
  a.click();
}
async function initScreener() {
  const r = await (await fetch("/api/screener/fields")).json();
  SC.fields = r.fields;
  $("scTf").innerHTML = r.intervals.map((t) => `<option value="${t}">${t.toUpperCase()}</option>`).join("");
  const st = store.get("scState", null);
  $("scTf").value = (st && st.tf) || "1h";
  $("scClosed").checked = !!(st && st.closed);
  $("scLimit").value = (st && st.limit) || "50";
  SC.filters = (st && st.filters) || [{ a: { f: "adx", len: 14 }, op: "gte", b: { v: 25 } }];
  renderFilters();
  renderPresets();
  $("scAdd").onclick = () => { SC.filters.push({ a: { f: "rsi", len: 14 }, op: "gt", b: { v: 50 } }); renderFilters(); };
  $("scRun").onclick = () => runScan(false);
  $("scSearch").oninput = renderScTable;
  $("scCsv").onclick = exportCsv;
  $("scAuto").onchange = () => {
    clearInterval(SC.timer);
    const sec = +$("scAuto").value;
    if (sec) SC.timer = setInterval(() => document.querySelector("#tab-screener.active") && runScan(true), sec * 1000);
  };
  $("scSave").onclick = () => {
    const name = prompt("Nama preset:", $("scPreset").value || "");
    if (!name) return;
    const ps = store.get("scPresets", {});
    ps[name] = { tf: $("scTf").value, closed: $("scClosed").checked, filters: SC.filters };
    store.set("scPresets", ps);
    renderPresets();
    $("scPreset").value = name;
  };
  $("scDel").onclick = () => {
    const ps = store.get("scPresets", {}), n = $("scPreset").value;
    if (!n || !confirm(`Hapus preset "${n}"?`)) return;
    delete ps[n];
    store.set("scPresets", ps);
    renderPresets();
  };
  $("scPreset").onchange = () => {
    const p = store.get("scPresets", {})[$("scPreset").value];
    if (!p) return;
    $("scTf").value = p.tf;
    $("scClosed").checked = p.closed;
    SC.filters = JSON.parse(JSON.stringify(p.filters));
    renderFilters();
  };
}

// ---- buka satu kejadian di Manual Replay: koin, TF & tanggal yang tepat + garis penanda otomatis
async function openMoment(sym, tf, t, marks, msg) {
  if (!(await loadSymbol(sym))) return toast(`Simbol ${sym} tidak ditemukan di data lokal — unduh / update data candle koin ini dulu.`);
  if (t < S.info.start || t > S.info.end)
    return toast(`Data lokal ${sym} hanya ${fmtDate(S.info.start)} → ${fmtDate(S.info.end)}, kejadian ${fmtTime(t).slice(0, 16)} di luar itu. Update data candle dulu untuk melihatnya di chart.`);
  $("symbol").value = sym;
  if (S.info.timeframes.includes(tf)) S.tf = tf;
  const step = ((IT_TF_MIN[tf] || 5) * 60000);
  $("startAt").value = toInput(Math.min(t + step, S.info.end));       // candle kejadian sudah close
  document.querySelector('.tab[data-tab="replay"]').click();
  const r = await startReplay();
  if (r && r.type === "error") return;
  chart.removeOverlay({ groupId: "moment" });
  for (const m of marks) {                                           // tidak ikut disimpan sebagai gambar kamu
    if (m.price == null || !isFinite(m.price)) continue;
    if (m.point) {                                                   // label di titik (mis. swing HH / HL)
      chart.createOverlay({ name: "simpleAnnotation", groupId: "moment", lock: true, points: [{ timestamp: m.time, value: m.price }], extendData: m.label });
      continue;
    }
    chart.createOverlay({ name: "horizontalStraightLine", groupId: "moment", lock: true, points: [{ timestamp: t, value: m.price }],
      styles: { line: { color: m.color, size: m.size || 1, style: m.dash ? "dashed" : "solid", dashedValue: [6, 4] } } });
    chart.createOverlay({ name: "simpleTag", groupId: "moment", lock: true, points: [{ timestamp: t, value: m.price }], extendData: m.label,
      styles: { text: { color: "#fff", backgroundColor: m.color, borderColor: m.color }, line: { show: false } } });
  }
  chart.createOverlay({ name: "verticalStraightLine", groupId: "moment", lock: true, points: [{ timestamp: t }],
    styles: { line: { color: "rgba(66,165,245,.55)", style: "dashed", dashedValue: [3, 3] } } });
  toast(msg);
}

// ---- menu studi (Tes SNR / Penemu Strategi / Indikator Tester): paralel, bisa dijeda & dilanjutkan, hasil disimpan
async function studyPoll(kind, id, ui) {
  ui.state.id = id;
  for (;;) {
    let st;
    try { st = await (await fetch(`/api/study/${kind}/${id}`)).json(); } catch (e) { await new Promise((ok) => setTimeout(ok, 1500)); continue; }
    if (ui.state.id !== id) return;                       // sudah diganti proses lain
    if (st.detail) { ui.error(st.detail); return; }
    setPauseBtn(ui.pause, st);
    ui.cancel.classList.toggle("hidden", !(st.status === "running" || st.status === "paused"));
    ui.tick(st);
    if (st.status === "done") { ui.done(st.result); loadPaused(); return; }
    if (st.status === "error") { ui.error(st.error || "gagal"); return; }
    if (st.status === "cancelled") { ui.error("dibatalkan"); return; }
    await new Promise((ok) => setTimeout(ok, st.status === "paused" ? 1500 : 700));
  }
}
function studyBind(kind, ui, reattach) {
  bindPauseBtn(ui.pause, kind, () => ui.state.id, (act) => { if (act === "resume" && ui.state.id) reattach({ id: ui.state.id }); });
  ui.cancel.onclick = async () => {
    if (!ui.state.id || !confirm("Batalkan proses ini? Hasil yang belum selesai dibuang.")) return;
    await jobAction(kind, ui.state.id, "cancel");
    loadPaused();
  };
}
// daftar hasil tersimpan per menu
async function savedResults(kind, box, open) {
  box.innerHTML = '<p class="hint">Memuat…</p>';
  let list = [];
  try { list = await (await fetch(`/api/results/${kind}`)).json(); } catch (e) { box.innerHTML = '<p class="neg">Gagal memuat</p>'; return; }
  if (!list.length) { box.innerHTML = '<p class="hint">Belum ada hasil tersimpan. Hasil otomatis tersimpan setiap kali proses selesai.</p>'; return; }
  const sum = (it) => {
    const p = it.params || {};
    const tf = p.tf ? `${String(p.tf).toUpperCase()}${p.snr_tf ? " · SNR " + String(p.snr_tf).toUpperCase() : ""}${p.ctx_tf ? " · tren " + String(p.ctx_tf).toUpperCase() : ""}` : "";
    const extra = p.ma ? ` · ${p.ma} + ${String(p.ind || "").toUpperCase()}${p.mode === "auto" ? " (otomatis)" : ""}` : p.strat ? ` · ${{ whale: "🐋 Whale", ms: "📐 Market Structure", tapro: "🧠 TA Pro", cpat: "🧩 Chart Pattern", rev: "🔄 Reversal", sweep: "💧 Sweep", maa: "📈 MA Analisis" }[p.strat] || p.strat}` : p.tester ? ` · ${p.tester}` : p.style ? ` · ${p.style}` : p.rr ? ` · RR ${[].concat(p.rr).join("/")}` : "";
    return `${tf}${extra}${it.symbols ? ` · ${it.symbols} koin` : ""}`;
  };
  box.innerHTML = `<table class="tbl saved-tbl">` + list.slice(0, 50).map((it) => `<tr data-id="${it.id}">
      <td>${new Date(it.time).toLocaleString("id-ID")}</td><td>${it.label ? `<b>${esc(it.label)}</b><br>` : ""}<small class="hint">${esc(sum(it))}</small></td>
      <td><button class="mini sv-open">Buka</button> <button class="mini sv-name">✏️</button> <button class="mini sv-del">🗑️</button></td></tr>`).join("") + "</table>";
  box.onclick = async (e) => {
    const tr = e.target.closest("tr[data-id]");
    if (!tr) return;
    const id = tr.dataset.id;
    if (e.target.classList.contains("sv-open")) {
      const it = await (await fetch(`/api/results/${kind}/${id}`)).json();
      open(it.result, it.params || {});
      toast(`Hasil tersimpan ${new Date(it.time).toLocaleString("id-ID")} dibuka (tanpa menghitung ulang).`);
    } else if (e.target.classList.contains("sv-name")) {
      const n = prompt("Nama untuk hasil ini:", "");
      if (n == null) return;
      await fetch(`/api/results/${kind}/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ label: n }) });
      savedResults(kind, box, open);
    } else if (e.target.classList.contains("sv-del")) {
      if (!confirm("Hapus hasil tersimpan ini?")) return;
      await fetch(`/api/results/${kind}/${id}`, { method: "DELETE" });
      savedResults(kind, box, open);
    }
  };
}

// ------------------------------------------------------------------ 📍 tes SNR + dorongan %
const SN = { def: null, res: null };
const SN_BAND = { "2": "2 ATR sebelum SNR", "1.5": "1.5 ATR sebelum SNR", "1": "1 ATR sebelum SNR", "0.5": "0.5 ATR sebelum SNR", sentuh: "saat menyentuh SNR" };
const SN_FIELDS = { snTf: "tf", snSnrTf: "snr_tf", snTarget: "target", snMin: "min_n", snHold: "hold_h", snSwing: "swing", snLife: "life", snTouch: "touch",
  snAway: "away", snAdx: "adx_len", snFi: "fi_len", snVol: "vol_len", snSmooth: "smooth", snInd: "ind", snReadBand: "read_band" };
function snUpdate() {
  $("snLifeDur").textContent = slDur($("snLife").value, $("snTf").value);
  { const tfm = { "1m": 1, "3m": 3, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "2h": 120, "4h": 240, "6h": 360, "8h": 480, "12h": 720, "1d": 1440 }[$("snTf").value];
    const hh = parseFloat($("snHold").value);
    $("snHoldDur").textContent = tfm && hh > 0 ? `= ${Math.max(1, Math.round(hh * 60 / tfm))} candle ${$("snTf").value}` : ""; }
  $("snSmooth").disabled = $("snAuto").checked;
  const ind = $("snInd").value, adx = ind !== "dorongan";
  $("snAutoTxt").textContent = adx ? "🔎 Bandingkan panjang ADX 7, 10, 14, 20, 28 & pakai yang paling bisa dipercaya" : "🔎 Cari penghalusan Dorongan % terbaik otomatis & jadikan default";
  $("snTowardWrap").classList.toggle("hidden", adx);
  document.querySelectorAll("#tab-snrtest .sn-dor-only").forEach((x) => x.classList.toggle("hidden", adx));
  $("snAdx").disabled = adx && $("snAuto").checked;
  const d = DOR_DEF[$("snTf").value];
  if (d && document.activeElement !== $("snSmooth")) $("snSmooth").value = d.smooth;
}
const SN_UI = { state: { id: null } };
async function runSnrTest() {
  const scope = $("snScope").value;
  if (scope === "one" && !S.info) return toast("Pilih simbol dulu di atas");
  const symbols = scope === "one" ? [S.info.symbol] : scope === "list" ? $("snSymbols").value.toUpperCase().split(/[\s,;]+/).filter(Boolean).map((x) => (x.endsWith("USDT") ? x : x + "USDT")) : null;
  const params = { toward: $("snInd").value === "dorongan" && $("snToward").checked, auto_smooth: $("snAuto").checked };
  for (const [id, k] of Object.entries(SN_FIELDS)) params[k] = $(id).value;
  params.start = $("snFrom").value ? fromInput($("snFrom").value) : null;
  params.end = $("snTo").value ? fromInput($("snTo").value) : null;
  store.set("snForm", { ...params, scope, symbols: $("snSymbols").value });
  const j = await startJob("/api/snrtest", { params, symbols });
  if (j) attachSnr(j);
}
function attachSnr(j) {
  $("snRun").disabled = true;
  $("snOut").classList.remove("hidden"); $("snLive").classList.remove("hidden"); $("snBody").innerHTML = "";
  $("snPct").textContent = "0"; $("snBar").style.width = "2%"; $("snTitle").textContent = "Menyiapkan…";
  const end = () => { $("snRun").disabled = false; $("snLive").classList.add("hidden"); };
  studyPoll("snrtest", j.id, Object.assign(SN_UI, {
    tick: (st) => {
      const pct = st.total ? (100 * st.done) / st.total : 0;
      $("snPct").textContent = Math.floor(pct); $("snBar").style.width = Math.max(pct, 2) + "%";
      $("snDone").textContent = `${st.done}/${st.total || "?"}`; $("snElapsed").textContent = fmtDur(st.elapsed);
      $("snEta").textContent = st.status === "paused" ? "dijeda" : st.eta ? "±" + fmtDur(st.eta) : "menghitung…";
      const it = st.recent && st.recent[0] ? st.recent[0].symbol.split("|") : null;
      $("snTitle").textContent = st.status === "paused" ? "⏸️ Dijeda — klik Lanjutkan untuk meneruskan dari koin yang belum selesai"
        : it ? `${it[0]}: ${it[1] || ""} · ${st.workers || 1} proses paralel` : `Menyiapkan · ${st.workers || 1} proses paralel`;
    },
    done: async (res) => {
      end();
      SN.res = res; SN.view = "menuju";
      if (res.saved_default) {                            // default baru: dipakai indikator chart & form
        DOR_DEF = await (await fetch("/api/dorongan/defaults")).json();
        if (IND.DORONGAN && IND.DORONGAN.on && !(IND.DORONGAN.params || "").trim()) applyIndicator("DORONGAN");
      }
      renderSnrTest();
      $("snStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${res.elapsed} dtk · 💾 tersimpan`;
      $("snOut").scrollIntoView({ behavior: "smooth", block: "start" });
    },
    error: (msg) => { end(); $("snBody").innerHTML = `<p class="neg">Gagal: ${esc(String(msg))}</p>`; },
  }));
}
function snName(R) { return { adx: "ADX", adxfi: "ADX" }[R.params.ind] || "Dorongan %"; }
function snU(R) { return R.params.ind === "adx" || R.params.ind === "adxfi" ? "" : "%"; }
function snBandTxt(b) { return SN_BAND[b] || b; }
function snSummaryHtml(R) {
  const N = snName(R), U = snU(R), N1 = N.replace(" %", "");
  const S_ = R.summary;
  if (!S_) return "";
  const f0 = (v) => (v == null ? "—" : v.toFixed(0) + "%");
  const held = (a, b) => (b != null && a != null && b >= a - 5 ? '<span class="pos">✅ bertahan di data uji</span>' : '<span class="neg">⚠️ di data uji turun — hati-hati</span>');
  const L = S_.limit, B = S_.breakout;
  const lim = L
    ? `📥 <b>Entry limit (pullback / retest)</b>: ${N1} <b>${L.from}${U} – ${L.to}${U}</b> → respect <b class="pos">${f0(L.train.pct_respect)}</b>
       <small>(rata-rata ${f0(S_.base.pct_respect)} · ${L.train.n} kejadian · data uji ${f0(L.test.pct_respect)})</small> ${held(L.train.pct_respect, L.test.pct_respect)}`
    : `📥 <b>Entry limit (pullback / retest)</b>: <span class="hint">tidak ada rentang ${N} yang respect-nya di atas rata-rata (${f0(S_.base.pct_respect)}).</span>`;
  const brk = B
    ? `🚀 <b>Entry breakout</b>: ${N1} <b>${B.from}${U} – ${B.to}${U}</b> → breakout <b class="pos">${f0(B.train.pct_breakout)}</b>, yang lanjut ≥ 1 ATR <b>${f0(B.train.pct_lanjut)}</b>
       <small>(rata-rata breakout ${f0(S_.base.pct_breakout)} · ${B.train.n} kejadian · data uji ${f0(B.test.pct_breakout)} / lanjut ${f0(B.test.pct_lanjut)})</small> ${held(B.train.pct_breakout, B.test.pct_breakout)}`
    : `🚀 <b>Entry breakout</b>: <span class="hint">tidak ada rentang ${N} yang breakout-nya di atas rata-rata (${f0(S_.base.pct_breakout)}).</span>`;
  const small = [L && L.train.pct_respect - S_.base.pct_respect, B && B.train.pct_breakout - S_.base.pct_breakout].filter((x) => x != null);
  const note = small.length && Math.max(...small) < 8
    ? `<p class="hint">ℹ️ Selisih dengan rata-rata kecil (&lt; 8 poin): ${N} hanya sedikit membantu — pakai bersama faktor lain di atas.</p>` : "";
  return `<div class="sn-summary"><h4>📝 Ringkasan simpel <span class="hint">dibaca ${snBandTxt(S_.band || "1")} · ${R.params.tf.toUpperCase()} · SNR ${R.params.snr_tf.toUpperCase()}</span></h4>
    <div class="sn-rec">${lim}</div><div class="sn-rec">${brk}</div>${note}</div>`;
}
function snFactorsHtml(R) {
  const F = R.factors;
  if (!F) return "";
  const P = R.params, f0 = (v) => (v == null ? "—" : v.toFixed(0) + "%");
  const o = F.overall;
  const bar = (v, cls) => (v == null ? "—" : `<span class="sn-bar ${cls}" style="--w:${v.toFixed(0)}%"></span> ${v.toFixed(0)}%`);
  const ftab = (fac) => `<div><h4>${esc(fac.title)}</h4><table class="tbl sn-tbl"><tr><th>Kondisi</th><th class="num">Kejadian</th><th>Respect</th><th>Breakout</th><th title="Dari breakout: lanjut ≥ 1 ATR dari close tembus sebelum close balik ke dalam SNR">Breakout lanjut</th><th class="num" title="Respect di 30% data terakhir">Uji: respect</th></tr>` +
    fac.rows.map((x) => `<tr><td>${esc(x.label)}</td><td class="num">${x.train.n}</td><td>${bar(x.train.pct_respect, "resp")}</td><td>${bar(x.train.pct_breakout, "brk")}</td>
      <td>${bar(x.train.pct_lanjut, "reach")}</td><td class="num">${f0(x.test.pct_respect)}</td></tr>`).join("") + "</table></div>";
  const combo = (list, kind) => list.length ? `<ol class="sn-combo">` + list.map((c) => {
    const a = kind === "limit" ? c.train.pct_respect : c.train.pct_breakout_lanjut, b = kind === "limit" ? c.test.pct_respect : c.test.pct_breakout_lanjut;
    const ok = b != null && b >= a - 8;
    return `<li><b>${esc(c.label)}</b><br><small>data cari ${kind === "limit" ? "respect" : "tembus &amp; lanjut"} <b>${f0(a)}</b> (${c.train.n} kejadian) · data uji <b class="${ok ? "pos" : "neg"}">${f0(b)}</b> (${c.test.n})${ok ? " ✅ bertahan" : " ⚠️ turun di data uji"}</small></li>`;
  }).join("") + "</ol>" : `<p class="hint">Tidak ada kombinasi dengan ≥ ${P.min_n} kejadian.</p>`;
  return `<h4>🧩 Faktor yang mempengaruhi SNR <span class="hint">dibaca saat harga 1 ATR sebelum SNR · hanya yang sampai SNR</span></h4>
    <div class="sn-rec">Tanpa faktor: <b>respect ${f0(o.train.pct_respect)}</b> · <b>breakout ${f0(o.train.pct_breakout)}</b> (${o.train.n} kejadian).
      (respect termasuk ${f0(o.train.pct_fakeout)} fakeout = sempat close tembus lalu balik).
      Dari semua close tembus: <b class="pos">${f0(o.train.pct_lanjut)} lanjut ≥ 1 ATR</b> vs <b class="neg">${f0(o.train.pct_lanjut == null ? null : 100 - o.train.pct_lanjut)} gagal lanjut</b> (close balik ke dalam SNR dulu).
      <br><small>Data uji 30% terakhir: respect ${f0(o.test.pct_respect)} · breakout lanjut ${f0(o.test.pct_lanjut)}.
      Entry breakout di close tembus dengan target 1 ATR ≈ menang ${f0(o.train.pct_lanjut)} kalau batal saat close balik ke dalam SNR.</small></div>
    <div class="sn-ftables">${F.factors.map(ftab).join("")}</div>
    <div class="sn-recs"><div class="sn-band"><h4>📥 Kombinasi terbaik untuk entry limit (respect tertinggi)</h4>${combo(F.best_limit, "limit")}</div>
      <div class="sn-band"><h4>🚀 Kombinasi terbaik untuk entry breakout (tembus &amp; lanjut tertinggi)</h4>${combo(F.best_breakout, "breakout")}</div></div>
    <p class="hint">Kombinasi dipilih dari data cari (70% awal), lalu dibuktikan di data uji (30% terakhir). Yang ⚠️ turun jauh di data uji kemungkinan kebetulan.</p>`;
}
function snMidHtml(R) {
  const N = snName(R), U = snU(R);
  const m = R.midline;
  if (!m) return "";
  const f1 = (v) => (v == null ? "—" : v.toFixed(0) + "%");
  const good = (m.sep_test || 0) > 0;
  return `<h4>➖ Garis tengah ${N}: <b>${m.line}${U}</b></h4>
    <div class="sn-rec ${good ? "ok" : ""}">Di <b>atas ${m.line}${U}</b> condong <b>breakout</b>, di <b>bawah</b> condong <b>pullback / retest (respect)</b> — dibaca sebelum harga sampai SNR.<br>
      <small>Data uji 30% terakhir: di atas garis ${f1(m.test_breakout_above)} breakout (${m.n_above} kejadian) · di bawah garis ${f1(m.test_respect_below)} respect (${m.n_below} kejadian).
      ${R.saved_default && R.saved_default.line != null ? " ✅ Jadi garis default indikator di chart untuk TF ini." : good ? " Belum jadi default (penghalusannya belum lolos uji)." : ' <span class="neg">⚠️ Di data uji garis ini tidak memisahkan — jangan dipakai dulu.</span>'}</small></div>`;
}
function snCompareHtml(R) {
  if (!R.compare || R.compare.length < 2) return "";
  const N = snName(R), isAdx = R.params.ind && R.params.ind !== "dorongan";
  const P = R.params, f1 = (v) => (v == null ? "—" : v.toFixed(1) + "%");
  const rows = R.compare.map((x) => `<tr class="${x.smooth === R.smooth ? "sn-pick" : ""}"><td>${x.smooth}${x.smooth === R.smooth ? " ✅" : ""}</td>
    <td class="num">${f1(x.auc_train)}</td><td class="num"><b>${f1(x.auc_test)}</b></td><td class="num">${x.n_test}</td></tr>`).join("");
  const best = R.compare.find((x) => x.smooth === R.smooth);
  const msg = isAdx
    ? `<div class="sn-rec ${best && best.auc_test >= R.min_auc ? "ok" : ""}">Panjang ADX terbaik di data cari = <b>${R.smooth}</b>, data uji <b>${f1(best && best.auc_test)}</b>.
       ${best && best.auc_test >= R.min_auc ? "✅ ADX ini cukup bisa dipercaya untuk membedakan breakout vs respect." : `⚠️ Di bawah ${R.min_auc}%: ADX belum cukup bisa dipercaya membedakan breakout vs respect di koin / TF / periode ini.`}</div>`
    : R.saved_default
    ? `<div class="sn-rec ok">✅ <b>Penghalusan ${R.smooth}</b> dijadikan <b>default TF ${P.tf.toUpperCase()}</b> — dipakai indikator ${N} di chart (kalau belum kamu atur sendiri) &amp; Tes SNR. Data uji: ${f1(R.saved_default.auc_test)}.</div>`
    : `<div class="sn-rec">⚠️ Penghalusan terbaik di data cari = <b>${R.smooth}</b>, tapi di data uji cuma <b>${f1(best && best.auc_test)}</b> (di bawah ${R.min_auc}%) → <b>default tidak diubah</b>.
       ${N} belum cukup bisa dipercaya untuk membedakan breakout vs respect di koin / TF / periode ini. Coba lebih banyak koin atau periode lebih panjang.</div>`;
  return `<h4>🔎 ${isAdx ? "Panjang ADX" : "Penghalusan " + N} mana yang paling bisa dipercaya?</h4>
    <p class="hint">Skor = seberapa baik ${N} (dibaca sebelum sampai SNR) membedakan breakout dari respect. <b>50% = sama dengan tebak koin</b>, makin tinggi makin bisa dipercaya. Dipilih dari data cari, dibuktikan di data uji.</p>
    <table class="tbl sn-cmp"><tr><th>${isAdx ? "Panjang ADX" : "Penghalusan"}</th><th class="num">Skor data cari</th><th class="num">Skor data uji</th><th class="num">Kejadian uji</th></tr>${rows}</table>${msg}`;
}
function renderSnrTest() {
  const ALL = SN.res;
  const R = ALL.fi_split ? ALL.split[SN.view || "menuju"] : ALL, P = R.params, T = P.target, N = snName(R), U = snU(R), N1 = N.replace(" %", "");
  const fiTabs = ALL.fi_split ? `<div class="sn-fitabs"><p class="hint">ADX + Force Index: hasil dipisah menurut arah Force Index (${P.fi_len}) saat dibaca.</p>
      <div class="seg">${[["menuju", "FI menuju SNR (FI + ke resistance / FI − ke support)"], ["melawan", "FI melawan arah SNR"]].map(([k, t]) =>
        `<button type="button" class="${(SN.view || "menuju") === k ? "on" : ""}" data-fiv="${k}">${t} · ${ALL.split[k].n_events.toLocaleString("id-ID")}</button>`).join("")}</div>
      ${ALL.split.melawan.n_events < ALL.split.menuju.n_events / 5 ? `<p class="hint">ℹ️ Saat harga bergerak mendekati SNR, Force Index hampir selalu searah gerakan itu (menuju SNR), jadi kelompok "melawan" datanya sedikit.</p>` : ""}</div>` : "";
  const f0 = (v) => (v == null ? "—" : v.toFixed(0) + "%");
  const recCard = (band) => {
    const rc = R.rec[band] || {}, b = rc.base;
    const base = b && b.respect + b.breakout ? `<small class="hint">Tanpa filter ${N}: respect ${f0(b.pct_respect)} · breakout ${f0(b.pct_breakout)} (${b.respect + b.breakout} kejadian)</small>` : "";
    const L = rc.limit, B = rc.breakout;
    const lim = L ? `<div class="sn-rec ok">📥 <b>Entry limit (pullback / retest)</b>: ${N1} <b>di bawah ${L.max}${U}</b> → <b class="pos">${f0(L.train.pct_respect)} respect</b>
        <small>(${L.train.respect + L.train.breakout} kejadian · harga sampai SNR ${f0(L.train.pct_reach)})</small><br>
        <small>Data uji 30% terakhir: respect <b>${f0(L.test.pct_respect)}</b> (${L.test.respect + L.test.breakout} kejadian)${L.test.pct_respect != null && L.test.pct_respect < T - 10 ? ' <span class="neg">⚠️ turun jauh — belum bisa dipercaya</span>' : ""}</small></div>`
      : `<div class="sn-rec">📥 Entry limit: <span class="hint">belum ada batas ${N} yang mencapai respect ≥ ${T}% (min. ${P.min_n} kejadian).</span></div>`;
    const brk = B ? `<div class="sn-rec ok">🚀 <b>Entry breakout</b>: ${N1} <b>${B.min}${U} ke atas</b> → <b class="pos">${f0(B.train.pct_breakout)} breakout</b>
        <small>(${B.train.respect + B.train.breakout} kejadian)</small>${B.min === 0 ? ' <span class="hint">— semua kondisi sudah ≥ target, jadi ${N} belum menambah informasi</span>' : ""}<br>
        <small>Data uji 30% terakhir: breakout <b>${f0(B.test.pct_breakout)}</b> (${B.test.respect + B.test.breakout} kejadian)${B.test.pct_breakout != null && B.test.pct_breakout < T - 10 ? ' <span class="neg">⚠️ turun jauh — belum bisa dipercaya</span>' : ""}</small></div>`
      : `<div class="sn-rec">🚀 Entry breakout: <span class="hint">belum ada batas ${N} yang mencapai breakout ≥ ${T}% (min. ${P.min_n} kejadian).</span></div>`;
    return `<div class="sn-band"><h4>📏 Dibaca ${SN_BAND[band]}</h4>${lim}${brk}${base}</div>`;
  };
  const table = (band) => {
    const rows = R.table[band].filter((x) => x.n);
    if (!rows.length) return "";
    const bar = (v, cls) => (v == null ? "—" : `<span class="sn-bar ${cls}" style="--w:${v.toFixed(0)}%"></span> ${v.toFixed(0)}%`);
    return `<div><h4>${SN_BAND[band]}</h4><table class="tbl sn-tbl"><tr><th>${N}</th><th class="num">Kejadian</th><th>Sampai SNR</th><th title="SNR bertahan = respect + fakeout (tembus lalu balik)">Respect</th><th title="Close tembus DAN bertahan di luar SNR">Breakout</th></tr>` +
      rows.map((x) => `<tr><td>${x.bucket}–${x.bucket + 10}${U}</td><td class="num">${x.n}</td><td>${bar(x.pct_reach, "reach")}</td>
        <td>${bar(x.pct_respect, "resp")}</td><td>${bar(x.pct_breakout, "brk")}</td></tr>`).join("") + "</table></div>";
  };
  const ex = R.examples.slice().reverse().slice(0, 60);
  $("snBody").innerHTML = `<h3>📍 Tes SNR · entry ${P.tf.toUpperCase()} · SNR ${P.snr_tf.toUpperCase()} <span class="hint">${R.symbols.length} koin · ${R.n_events.toLocaleString("id-ID")} pembacaan · target ${T}% · indikator: ${P.ind === "adxfi" ? "ADX + Force Index" : N}${P.toward ? " · hanya dorongan menuju SNR" : ""}</span></h3>
    ${fiTabs}
    ${R.skipped.length ? `<details class="hint"><summary>⏭️ ${R.n_skipped} koin dilewati</summary>${R.skipped.map(esc).join("<br>")}</details>` : ""}
    ${snCompareHtml(R)}${snMidHtml(R)}
    <h4>🎯 Batas ${N} (dibaca SEBELUM harga sampai SNR) · ${P.ind && P.ind !== "dorongan" ? "panjang ADX" : "penghalusan"} ${R.smooth}</h4>
    <div class="sn-recs">${["1.5", "1", "0.5", "2", "sentuh"].filter((b) => R.rec[b]).map(recCard).join("")}</div>
    ${snFactorsHtml(R)}
    <h4>📊 Rincian per ${N}</h4><div class="sn-tables">${["2", "1.5", "1", "0.5", "sentuh"].filter((b) => R.table[b]).map(table).join("")}</div>
    <details><summary><b>🔍 Contoh kejadian saat menyentuh SNR</b> <small class="hint">klik untuk buka di Manual Replay</small></summary>
      <div class="scroll"><table class="tbl sl-trtbl"><tr><th>Waktu (UTC)</th><th>Koin</th><th>SNR</th><th class="num">Harga SNR</th><th class="num">${N}</th><th>Hasil</th></tr>` +
      ex.map((e) => `<tr data-t="${e.time}" data-sym="${e.symbol}" data-tf="${P.tf}" data-snr="${e.snr}" data-side="${e.side}" data-out="${e.outcome}" data-dor="${e.dorongan}" title="Buka di chart (garis SNR otomatis digambar)"><td>${fmtTime(e.time).slice(0, 16)}</td><td>${e.symbol}</td><td>${e.side}</td>
        <td class="num">${pxTxt(e.snr)}</td><td class="num">${e.dorongan}–${e.dorongan + 10}${U}</td>
        <td class="${e.outcome === "breakout" ? "neg" : "pos"}">${e.outcome === "respect" ? "↩️ respect" : e.outcome === "fakeout" ? "🪤 fakeout (tembus lalu balik)" : "💥 breakout"}</td></tr>`).join("") + "</table></div></details>" + snSummaryHtml(R);
}
{
  fetch("/api/dorongan/defaults").then((r) => r.json()).then((d) => { DOR_DEF = d || {}; if (IND.DORONGAN && IND.DORONGAN.on) applyIndicator("DORONGAN"); if ($("snTf").value) snUpdate(); }).catch(() => {});
  fetch("/api/snrtest/defaults").then((r) => r.json()).then((d) => {
    SN.def = d;
    const tfs = ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"];
    $("snTf").innerHTML = tfs.map((t) => `<option value="${t}">${t.toUpperCase()}</option>`).join("");
    $("snSnrTf").innerHTML = $("snTf").innerHTML;
    const f = { ...d.defaults, ...(store.get("snForm", null) || {}) };
    for (const [id, k] of Object.entries(SN_FIELDS)) if (f[k] != null) $(id).value = f[k];
    $("snToward").checked = f.toward !== false;
    $("snAuto").checked = f.auto_smooth !== false;
    if (f.scope) $("snScope").value = f.scope; if (f.symbols) $("snSymbols").value = f.symbols;
    $("snListWrap").classList.toggle("hidden", $("snScope").value !== "list");
    snUpdate();
  });
  $("tab-snrtest").addEventListener("input", snUpdate);
  $("tab-snrtest").addEventListener("change", snUpdate);
  $("snScope").onchange = () => $("snListWrap").classList.toggle("hidden", $("snScope").value !== "list");
  $("snRun").onclick = runSnrTest;
  studyBind("snrtest", Object.assign(SN_UI, { pause: $("snPause"), cancel: $("snCancel") }), attachSnr);
  $("snSavedBox").addEventListener("toggle", (e) => { if (e.target.open) savedResults("snrtest", $("snSaved"), (res) => {
    SN.res = res; SN.view = "menuju"; $("snOut").classList.remove("hidden"); $("snLive").classList.add("hidden"); renderSnrTest(); $("snOut").scrollIntoView({ behavior: "smooth" }); }); });
  $("snBody").addEventListener("click", async (e) => {
    const fv = e.target.closest("button[data-fiv]");
    if (fv) { SN.view = fv.dataset.fiv; return renderSnrTest(); }
    const tr = e.target.closest("tr[data-t]");
    if (!tr) return;
    const d = tr.dataset, t = +d.t, snr = +d.snr;
    await openMoment(d.sym, d.tf, t, [{ price: snr, color: "#eab308", size: 2, dash: true,
      label: `${d.side === "resistance" ? "R" : "S"} ${pxTxt(snr)}` }],
      `${fmtTime(t).slice(0, 16)} · ${d.sym}: harga menyentuh ${d.side} ${pxTxt(snr)} (${SN.res ? snName(SN.res.fi_split ? SN.res.split.menuju : SN.res).replace(" %", "") : "Dorongan"} ${d.dor}–${+d.dor + 10}${SN.res ? snU(SN.res) : "%"}) → ${d.out === "fakeout" ? "fakeout (sempat close tembus lalu balik — SNR bertahan)" : d.out}. Garis kuning = SNR. Step maju untuk melihat kelanjutannya.`);
  });
}

// ------------------------------------------------------------------ 🧠 penemu strategi
const SLAB = { def: null, res: null, params: null };
const SL_TIPS = [
  "💡 Pola = urutan swing (HH / HL / LH / LL, double top / bottom, sweep). Komputer mencari entry & SL terbaik tiap pola.",
  "💡 Pakai <b>banyak koin</b> dan periode panjang supaya pola yang ditemukan bukan kebiasaan satu koin saja.",
  "💡 Percayai hanya yang <b>✅ lolos</b>: untung juga di 30% data terakhir yang tidak dipakai mencari.",
  "💡 Setelah ketemu pola, klik <b>🔍 Contoh</b> lalu buka di chart: swing, entry, SL &amp; TP otomatis digambar.",
];
function slDur(n, tf) {
  const m = (IT_TF_MIN[tf] || 60) * (+n || 0);
  if (!m) return "";
  return "≈ " + (m < 60 ? `${m} menit` : m < 1440 ? `${+(m / 60).toFixed(1)} jam` : `${+(m / 1440).toFixed(1)} hari`) + ` di TF ${tf.toUpperCase()}`;
}
function slUpdate() {
  const rrs = $("slRr").value.split(/[,;\s]+/).map(Number).filter((x) => x > 0), mw = +$("slMinWr").value || 0;
  $("slWrNote").innerHTML = rrs.length ? `WR impas: ${rrs.map((x) => `1:${x} = ${Math.round(100 / (1 + x))}%`).join(" · ")}` +
    (mw && rrs.every((x) => mw > 100 / (1 + x) + 15) ? ` <span class="neg">· ⚠️ Min. WR ${mw}% terlalu tinggi untuk RR ini.</span>` : "") : "";
  $("slInfo").innerHTML = `Semua pola 3–4 swing × 6 entry × 2 SL × ${rrs.length || 1} RR, LONG &amp; SHORT, diuji otomatis. Limit berlaku ${slDur(48, $("slTf").value).replace("≈ ", "±")}; lama trade maks ${slDur(200, $("slTf").value).replace("≈ ", "±")}.`;
}
function slParams() {
  return { tf: $("slTf").value, rrs: $("slRr").value, min_wr: +$("slMinWr").value || 0,
    start: $("slFrom").value ? fromInput($("slFrom").value) : null, end: $("slTo").value ? fromInput($("slTo").value) : null };
}
const SL_UI = { state: { id: null } };
async function runStratLab() {
  const scope = $("slScope").value;
  if (scope === "one" && !S.info) return toast("Pilih simbol dulu di atas");
  const symbols = scope === "one" ? [S.info.symbol] : scope === "list" ? $("slSymbols").value.toUpperCase().split(/[\s,;]+/).filter(Boolean).map((x) => (x.endsWith("USDT") ? x : x + "USDT")) : null;
  const params = slParams();
  store.set("slForm2", { ...params, scope, symbols: $("slSymbols").value });
  SLAB.params = params;
  const j = await startJob("/api/stratlab", { params, symbols });
  if (j) attachStratLab(j);
}
function attachStratLab(j) {
  $("slRun").disabled = true;
  $("slOut").classList.remove("hidden"); $("slLive").classList.remove("hidden");
  $("slBody").innerHTML = '<p class="hint">⏳ Pola yang sudah ketemu akan langsung muncul di sini setiap ada koin yang selesai dibaca…</p>';
  $("slPct").textContent = "0"; $("slBar").style.width = "2%"; $("slRecent").innerHTML = ""; $("slRecent").dataset.last = "";
  $("slTitle").textContent = "Menyiapkan data…"; $("slEta").textContent = "menghitung…";
  startTips("slTip", SL_TIPS);
  let lastKey = "";
  const end = () => { $("slRun").disabled = false; $("slLive").classList.add("hidden"); clearInterval(TIP_TIMERS.slTip); };
  studyPoll("stratlab", j.id, Object.assign(SL_UI, {
    tick: (st) => {
      if (st.partial && `${st.partial.scanned}` !== lastKey) {
        lastKey = `${st.partial.scanned}`;
        const open = [...document.querySelectorAll("#slBody .sl-tr")].some((x) => x.innerHTML.trim());
        if (!open) { SLAB.res = st.partial; SLAB.params = SLAB.params || st.partial.params; renderStratLab(); }
      }
      const pct = st.total ? (100 * st.done) / st.total : 0;
      $("slPct").textContent = Math.floor(pct); $("slBar").style.width = Math.max(pct, 2) + "%";
      $("slDone").textContent = `${st.done}/${st.total || "?"}`; $("slElapsed").textContent = fmtDur(st.elapsed);
      $("slEta").textContent = st.status === "paused" ? "dijeda" : st.eta ? "±" + fmtDur(st.eta) : "menghitung…";
      const items = (st.recent || []).map((x) => x.symbol.split("|"));
      $("slTitle").textContent = st.status === "paused" ? "⏸️ Dijeda — klik Lanjutkan untuk meneruskan dari koin yang belum selesai"
        : items[0] ? `${items[0][0]}: ${items[0][1] || ""} · ${st.workers || 1} proses paralel` : `Membaca market structure · ${st.workers || 1} proses paralel`;
      const rec = items.map(([sym, lab]) => `<li><span>✅ ${esc(sym)}</span><small class="hint">${esc(lab || "")}</small></li>`).join("");
      if (rec !== $("slRecent").dataset.last) { $("slRecent").innerHTML = rec; $("slRecent").dataset.last = rec; }
    },
    done: (res) => {
      end();
      SLAB.res = res; SLAB.params = SLAB.params || res.params;
      renderStratLab();
      $("slStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${res.elapsed} dtk · 💾 tersimpan`;
      $("slOut").scrollIntoView({ behavior: "smooth", block: "start" });
    },
    error: (msg) => { end(); $("slBody").innerHTML = `<p class="neg">Gagal: ${esc(String(msg))}</p>`; },
  }));
}
function renderStratLab() {
  const R = SLAB.res;
  if (!R.v || R.v < 4) {
    $("slBody").innerHTML = '<p class="hint">Hasil ini dari Penemu Strategi versi lama (pola indikator). Jalankan ulang untuk memakai versi baru (pola market structure).</p>';
    return;
  }
  const P = R.params, X = R.rules;
  const f0 = (v) => (v == null ? "—" : v.toFixed(0));
  const rr = (v) => (v == null ? "—" : `<b class="${v > 0 ? "pos" : "neg"}">${v >= 0 ? "+" : ""}${v.toFixed(2)} R</b>`);
  const head = (R.partial ? `<div class="wh-partial">⏳ <b>Hasil sementara</b> — ${R.scanned}/${R.total} koin sudah dibaca. Urutan &amp; angka masih bisa berubah.</div>` : "") +
    `<h3>🧠 Penemu Strategi · ${P.tf.toUpperCase()} (single TF) · RR ${P.rrs.map((x) => "1:" + x).join(" / ")}
      <span class="hint">${R.symbols.length} koin · ${R.candles.toLocaleString("id-ID")} candle · ${R.n_patterns.toLocaleString("id-ID")} pola dengan ≥ ${X.min_n} trade</span></h3>
    <div class="sl-sum">${R.n_passed ? `✅ <b>${R.n_passed}</b> pola lolos uji data baru` : "❌ <b>Belum ada pola yang lolos</b> uji data baru"}
      ${P.min_wr ? ` (WR data uji ≥ ${P.min_wr}%)` : ""}. <span class="hint">Makin banyak koin &amp; makin panjang periode, makin bisa dipercaya.</span></div>
    ${R.skipped.length ? `<details class="hint"><summary>⏭️ ${R.n_skipped} koin dilewati</summary>${R.skipped.map(esc).join("<br>")}</details>` : ""}`;
  if (!R.rows.length) {
    $("slBody").innerHTML = head + `<p class="hint">Belum ada pola dengan ≥ ${X.min_n} trade terisi. Pakai periode lebih panjang atau tambah koin.</p>`;
    return;
  }
  const varTbl = (r) => r.variants.length ? `<details class="sltab"><summary>Entry / SL lain yang juga diuji untuk pola ini (${r.variants.length})</summary>
      <div class="scroll"><table class="tbl"><tr><th>Entry</th><th>SL</th><th class="num">RR</th><th class="num">Trade</th><th class="num">Terisi</th><th class="num">WR</th><th class="num">Rata-rata R</th><th class="num">Data uji</th><th></th></tr>` +
      r.variants.map((v) => `<tr><td>${esc(v.entry_txt)}</td><td>${esc(v.sl_txt)}</td><td class="num">1:${v.rr}</td><td class="num">${v.n}</td><td class="num">${f0(v.fill_pct)}%</td>
        <td class="num">${f0(v.wr)}%</td><td class="num">${rr(v.exp_r)}</td><td class="num">${v.wr_test == null ? "—" : f0(v.wr_test) + "%"} · ${rr(v.exp_test)}</td>
        <td>${v.passed ? "✅" : ""}</td></tr>`).join("") + "</table></div></details>" : "";
  const cards = R.rows.map((r, i) => `<div class="sl-card ${r.passed ? "ok" : ""}">
      <div class="sl-card-h"><b>${i + 1}. ${esc(r.name)}</b>${r.passed ? '<span class="badge pass">✅ lolos</span>' : '<span class="badge fail">⚠️ belum terbukti</span>'}</div>
      <ul class="sl-rules"><li>Pola: ${r.len} swing terakhir saat swing terbaru terkonfirmasi (TF ${P.tf.toUpperCase()}).</li>
        <li>Entry: <b>${esc(r.entry_txt)}</b></li><li>SL: <b>${esc(r.sl_txt)}</b></li><li>TP: <b>RR 1:${r.rr}</b></li></ul>
      <table class="tbl sl-stat"><tr><th></th><th class="num">Trade</th><th class="num">WR</th><th class="num">Rata-rata R</th></tr>
        <tr><td>Data cari (70% awal)</td><td class="num">${r.n}</td><td class="num"><b>${f0(r.wr)}%</b></td><td class="num">${rr(r.exp_r)}</td></tr>
        <tr><td>Dasar: entry / SL sama di semua pola</td><td class="num">—</td><td class="num">${f0(r.base_wr)}%</td><td class="num">${rr(r.base_r)}</td></tr>
        <tr><td>Data uji (30% terakhir)</td><td class="num">${r.n_test}</td><td class="num"><b>${r.wr_test == null ? "—" : f0(r.wr_test) + "%"}</b></td><td class="num">${rr(r.exp_test)}</td></tr></table>
      <p class="hint">${r.signals.toLocaleString("id-ID")} sinyal · limit terisi <b>${f0(r.fill_pct)}%</b> · ${r.coins >= 2 ? `untung di <b>${r.coins_pos}/${r.coins}</b> koin · ` : ""}waktu habis ${f0(r.timeout_pct)}%</p>
      ${varTbl(r)}
      <div class="sl-act"><select class="sl-sym">${R.symbols.map((x) => `<option>${x}</option>`).join("")}</select>
        <button class="mini sl-trades" data-i="${i}">🔍 Contoh</button>
        <button class="mini sl-spec" data-i="${i}">📄 Threshold &amp; workflow</button></div>
      <div class="sl-specbox hidden" id="slSpec${i}"></div>
      <div class="sl-tr" id="slTr${i}"></div></div>`).join("");
  $("slBody").innerHTML = head + cards;
}
// ---- 📄 threshold & workflow lengkap tiap strategi + spesifikasi program scan (untuk diuji / diberikan ke AI coding)
function slSpec(R, r) {
  const P = R.params, X = R.rules || {}, tf = P.tf.toUpperCase(), L = r.dir === 0;
  const fr = X.fractal || 3, eq = X.eq ?? 0.15, buf = X.sl_buf ?? 0.1, leg = X.min_leg ?? 1, rmin = X.min_risk ?? 0.2, rmax = X.max_risk ?? 8;
  const wait = X.fill_wait || 48, hold = X.hold || 200;
  const seq = r.key.split(">"), NM = { HH: "HH", LH: "LH", EH: "EH (double top)", XH: "XH (sweep high)", HL: "HL", LL: "LL", EL: "EL (double bottom)", XL: "XL (sweep low)" };
  const pct = (v) => (v == null ? "—" : v.toFixed(1) + "%"), Rr = (v) => (v == null ? "—" : (v >= 0 ? "+" : "") + v.toFixed(2) + "R");
  const fib = r.entry.startsWith("fib") ? +r.entry.slice(3) : null;
  const need = 500;                                   // ATR14 stabil + riwayat swing untuk pola 3–4 swing
  const entryRule = r.entry === "market" ? `MARKET di harga close candle s (candle saat pola terkonfirmasi).`
    : fib != null ? (L ? `LIMIT BUY = top − ${fib} × (top − base). Kalau level ini TIDAK di bawah close candle s → tidak ada sinyal.`
                       : `LIMIT SELL = bottom + ${fib} × (base − bottom). Kalau level ini TIDAK di atas close candle s → tidak ada sinyal.`)
    : (L ? `LIMIT BUY di harga swing HIGH terakhir SEBELUM swing low base (level yang ditembus / BOS). Syarat: base < level < top dan level < close candle s; kalau tidak terpenuhi → tidak ada sinyal.`
         : `LIMIT SELL di harga swing LOW terakhir SEBELUM swing high base (level yang ditembus / BOS). Syarat: bottom < level < base dan level > close candle s; kalau tidak → tidak ada sinyal.`);
  const slRule = r.sl === "swing" ? (L ? `SL = base − ${buf} × ATR14(s).` : `SL = base + ${buf} × ATR14(s).`)
    : (L ? `SL = (harga TERENDAH di antara semua swing LOW dalam ${r.len} swing pola, dan base) − ${buf} × ATR14(s).`
         : `SL = (harga TERTINGGI di antara semua swing HIGH dalam ${r.len} swing pola, dan base) + ${buf} × ATR14(s).`);
  const lines = [
    `STRATEGI: ${r.name}  (Penemu Strategi v4, price action, single TF ${tf})`,
    ``,
    `HASIL BACKTEST (${R.symbols.length} koin, ${R.candles.toLocaleString("id-ID")} candle):`,
    `- Data cari 70% awal: ${r.n} trade, WR ${pct(r.wr)}, rata-rata ${Rr(r.exp_r)} per trade (dasar semua pola: ${Rr(r.base_r)}).`,
    `- Data uji 30% terakhir: ${r.n_test} trade, WR ${pct(r.wr_test)}, rata-rata ${Rr(r.exp_test)}.`,
    `- Sinyal ${r.signals}, limit terisi ${pct(r.fill_pct)}, waktu habis ${pct(r.timeout_pct)}${r.coins >= 2 ? `, untung di ${r.coins_pos}/${r.coins} koin` : ""}. Status: ${r.passed ? "LOLOS uji" : "BELUM terbukti"}.`,
    ``,
    `=== THRESHOLD (semua angka TETAP, jangan diubah) ===`,
    `- TF: ${tf} saja (single TF). Hanya candle yang SUDAH close.`,
    `- ATR = ATR(14) Wilder / RMA (sama dengan ATR bawaan TradingView). ATR14(s) = nilai ATR di candle s.`,
    `- Swing: fractal ${fr} (${fr} candle kiri & ${fr} candle kanan).`,
    `- Sama tinggi (double top / bottom): selisih ≤ ${eq} × ATR14 di candle swing.`,
    `- Leg minimal: ${leg} × ATR14(s). Jarak SL: ${rmin}–${rmax} × ATR14(s) (di luar itu = tidak ada sinyal).`,
    `- Pola: ${r.len} swing terakhir = ${seq.map((x) => NM[x] || x).join(" → ")} (urutan persis, dari yang paling lama ke terbaru).`,
    `- Arah: ${L ? "LONG / BUY" : "SHORT / SELL"}. Entry: ${r.entry_txt}. SL: ${r.sl_txt}. TP: RR 1:${r.rr}.`,
    `- ${r.entry === "market" ? "" : `Limit berlaku ${wait} candle. `}Lama trade maksimal ${hold} candle.`,
    ``,
    `=== WORKFLOW (dijalankan setiap candle ${tf} close) ===`,
    `1. AMBIL DATA: minimal ${need} candle ${tf} TERTUTUP terakhir (abaikan candle yang sedang berjalan). Alasan: ATR14 butuh ±50 candle supaya stabil,`,
    `   dan pola ${r.len} swing biasanya terbentuk dalam ±100–200 candle (perkiraan); ${need} candle aman. Lebih banyak tidak mengubah hasil.`,
    `2. SWING: candle i = swing HIGH kalau high[i] = high tertinggi dari candle i−${fr} sampai i+${fr}; swing LOW kalau low[i] = low terendah dari i−${fr} sampai i+${fr}.`,
    `   Swing di candle i baru DIKETAHUI saat candle i+${fr} close (tidak boleh dipakai sebelum itu).`,
    `3. URUTAN SWING selang-seling HIGH / LOW, diproses urut waktu konfirmasi: kalau swing baru sejenis dengan swing terakhir di urutan,`,
    `   ganti swing terakhir kalau yang baru LEBIH EKSTREM (high lebih tinggi / low lebih rendah); kalau tidak, abaikan swing baru.`,
    `4. LABEL tiap swing dibanding swing SEJENIS sebelumnya di urutan (ATR = ATR14 di candle swing):`,
    `   HIGH: |selisih| ≤ ${eq}×ATR → EH; lebih tinggi DAN close candle swing di bawah high sebelumnya → XH (sweep high); lebih tinggi → HH; lebih rendah → LH.`,
    `   LOW : |selisih| ≤ ${eq}×ATR → EL; lebih rendah DAN close candle swing di atas low sebelumnya → XL (sweep low); lebih rendah → LL; lebih tinggi → HL.`,
    `   Swing pertama tiap jenis (belum ada pembanding) tidak punya label → pola yang memuatnya tidak dihitung.`,
    `5. CEK POLA hanya di candle s = candle saat swing terbaru TERKONFIRMASI (ditambah / mengganti urutan): ${r.len} label terakhir harus persis ${seq.join(" → ")}.`,
    L ? `6. LEG LONG: base = harga swing LOW terakhir di urutan; top = high tertinggi dari candle swing base sampai candle s. Kalau top − base < ${leg}×ATR14(s) → tidak ada sinyal.`
      : `6. LEG SHORT: base = harga swing HIGH terakhir di urutan; bottom = low terendah dari candle swing base sampai candle s. Kalau base − bottom < ${leg}×ATR14(s) → tidak ada sinyal.`,
    `7. ENTRY: ${entryRule}`,
    `8. SL: ${slRule} Kalau jarak entry–SL < ${rmin}×ATR14(s) atau > ${rmax}×ATR14(s) → tidak ada sinyal.`,
    `9. TP: ${L ? "entry + " : "entry − "}${r.rr} × |entry − SL|.`,
    r.entry === "market" ? `10. ORDER: market saat candle s close.`
      : `10. ORDER LIMIT: aktif mulai candle s+1, maksimal ${wait} candle. TERISI kalau ${L ? "low ≤ entry" : "high ≥ entry"}.`
        + ` BATAL kalau sebelum terisi (atau di candle yang sama dengan terisi) harga membuat ${L ? "high > top" : "low < bottom"} (struktur bergerak, tunggu pola baru), atau lewat ${wait} candle.`,
    `11. KELOLA POSISI: ${r.entry === "market" ? "mulai candle s+1" : "SL dicek mulai candle terisi itu sendiri, TP mulai candle sesudahnya"}. SL & TP kena di candle yang sama = dihitung SL.`
      + ` Belum kena sampai ${hold} candle setelah terisi → tutup di harga close.`,
    `12. SATU sinyal per kejadian pola (per candle s). Sinyal arah lain / pola lain dihitung terpisah.`,
    ``,
    `=== CATATAN UNTUK AI CODING ===`,
    `- Implementasikan PERSIS seperti di atas. JANGAN tambah filter, indikator, atau pengaturan lain. JANGAN ubah angka.`,
    `- Semua perhitungan hanya dari candle yang sudah close; jangan pakai data candle yang sedang berjalan.`,
    `- Simpan di jurnal tiap sinyal: waktu candle s, ${r.len} swing (waktu, harga, label), entry, SL, TP, terisi atau tidak, hasil (TP / SL / waktu habis / batal), lama sampai hasil (candle).`,
    `- Kalau ada bagian yang tidak jelas, TANYA dulu, jangan dikarang sendiri.`,
  ];
  return lines.join("\n");
}
async function slShowTrades(i, btn) {
  const r = SLAB.res.rows[i], sym = btn.closest(".sl-card").querySelector(".sl-sym").value;
  const box = $(`slTr${i}`);
  box.innerHTML = '<p class="hint">Menghitung…</p>';
  try {
    const res = await fetch("/api/stratlab/trades", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol: sym, params: SLAB.params || SLAB.res.params, pattern: { len: r.len, key: r.key, dir: r.dir, entry: r.entry, sl: r.sl, rr: r.rr } }) });
    const j = await res.json();
    if (!res.ok) throw new Error(j.detail || res.statusText);
    SLAB.trades = j;
    const list = j.trades.map((t, k) => [t, k]).reverse().slice(0, 80);
    box.innerHTML = `${j.n_seq ? `<p>😓 <b>Seberat apa dijalani di ${esc(sym)}:</b> kalah beruntun terpanjang <b>${j.max_loss_streak}×</b> · drawdown terdalam <b class="neg">−${j.max_dd.toFixed(1)} R</b> (${j.n_seq} trade terisi, urut waktu)</p>` : ""}<p class="hint">${j.n} sinyal di ${esc(sym)} (ditampilkan ${list.length} terbaru). Klik baris: chart terbuka di candle pola terkonfirmasi, swing pola + entry / SL / TP digambar.</p>
      <div class="scroll"><table class="tbl sl-trtbl"><tr><th>Waktu (UTC)</th><th>Arah</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP</th><th>Hasil</th><th>Data</th></tr>` +
      list.map(([t, k]) => `<tr data-k="${k}" title="Buka di chart"><td>${fmtTime(t.time).slice(0, 16)}</td>
        <td class="${t.side === "long" ? "pos" : "neg"}">${t.side}</td><td class="num">${pxTxt(t.entry)}</td><td class="num">${pxTxt(t.sl)}</td><td class="num">${pxTxt(t.tp)}</td>
        <td class="${t.result === "TP" ? "pos" : t.result === "SL" ? "neg" : ""}">${!t.filled ? "⏳ tidak terisi" : t.result === "TP" ? "✅ TP" : t.result === "SL" ? "❌ SL" : `⏱️ ${t.r >= 0 ? "+" : ""}${t.r.toFixed(2)}R`}</td>
        <td class="hint">${t.test ? "uji" : "cari"}</td></tr>`).join("") + "</table></div>";
  } catch (err) {
    box.innerHTML = `<p class="neg">Gagal: ${esc(err.message)}</p>`;
  }
}
{
  fetch("/api/stratlab/defaults").then((r) => r.json()).then((d) => {
    SLAB.def = d;
    const tfs = ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"];
    $("slTf").innerHTML = tfs.map((t) => `<option value="${t}">${t.toUpperCase()}</option>`).join("");
    const f = store.get("slForm2", null) || {};
    $("slTf").value = f.tf || d.defaults.tf;
    $("slRr").value = f.rrs || d.defaults.rrs;
    $("slMinWr").value = f.min_wr ? f.min_wr : "";
    if (f.scope) $("slScope").value = f.scope; if (f.symbols) $("slSymbols").value = f.symbols;
    $("slListWrap").classList.toggle("hidden", $("slScope").value !== "list");
    slUpdate();
  });
  $("tab-stratlab").addEventListener("input", (e) => { if (e.target.closest(".bt-form")) slUpdate(); });
  $("tab-stratlab").addEventListener("change", (e) => { if (e.target.closest(".bt-form")) slUpdate(); });
  $("slScope").onchange = () => $("slListWrap").classList.toggle("hidden", $("slScope").value !== "list");
  $("slRun").onclick = runStratLab;
  studyBind("stratlab", Object.assign(SL_UI, { pause: $("slPause"), cancel: $("slCancel") }), attachStratLab);
  $("slSavedBox").addEventListener("toggle", (e) => { if (e.target.open) savedResults("stratlab", $("slSaved"), (res, params) => {
    SLAB.res = res; SLAB.params = params; $("slOut").classList.remove("hidden"); $("slLive").classList.add("hidden"); renderStratLab(); $("slOut").scrollIntoView({ behavior: "smooth" }); }); });
  $("slBody").addEventListener("click", async (e) => {
    const b = e.target.closest(".sl-trades");
    if (b) return slShowTrades(+b.dataset.i, b);
    const sp = e.target.closest(".sl-spec");
    if (sp) {
      const i = +sp.dataset.i, box = $(`slSpec${i}`), txt = slSpec(SLAB.res, SLAB.res.rows[i]);
      if (!box.classList.contains("hidden")) { box.classList.add("hidden"); return; }
      box.innerHTML = `<div class="sl-spec-h"><b>📄 Threshold &amp; workflow lengkap</b> <button class="mini sl-copy" data-i="${i}">📋 Salin untuk AI coding</button></div>
        <pre class="sl-pre">${esc(txt)}</pre>`;
      box.classList.remove("hidden");
      return;
    }
    const cp = e.target.closest(".sl-copy");
    if (cp) return copyText(slSpec(SLAB.res, SLAB.res.rows[+cp.dataset.i])).then(() => toast("Threshold & workflow disalin — tinggal tempel ke AI coding"));
    const tr = e.target.closest("tr[data-k]");
    if (!tr || !SLAB.trades) return;
    const J = SLAB.trades, x = J.trades[+tr.dataset.k];
    const marks = [
      { price: x.entry, color: "#42a5f5", size: 2, label: `E ${pxTxt(x.entry)}` },
      { price: x.sl, color: "#ef5350", dash: true, label: `SL ${pxTxt(x.sl)}` },
      { price: x.tp, color: "#26a69a", dash: true, label: `TP ${pxTxt(x.tp)}` },
      ...x.swings.map((sw) => ({ point: true, time: sw.time, price: sw.price, label: sw.label }))];
    await openMoment(J.symbol, J.tf, x.time, marks,
      `${fmtTime(x.time).slice(0, 16)} ${J.symbol} ${J.tf.toUpperCase()}: pola terkonfirmasi (${x.swings.map((s_) => s_.label).join(" → ")}). ` +
      `Biru = entry, merah = SL, hijau = TP. Hasil: ${!x.filled ? "limit tidak terisi" : x.result} ${x.fill_time ? `(terisi ${fmtTime(x.fill_time).slice(0, 16)})` : ""}. Step maju untuk melihat kelanjutannya.`);
  });
}

// ------------------------------------------------------------------ 🔎 screener market structure (1 koin)
const MSC_S = { res: null, plan: 0 };
// isian "Riwayat": simpanan lama "all" / "coin" -> teks; kosong -> semua
function scopeTxt(v) { return v == null || v === "" || v === "all" ? "semua" : v === "coin" ? "koin ini" : String(v); }
// jalankan Screener Market Structure 1 koin di latar belakang -> hasil (dipakai juga oleh menu Screener)
async function mscFetch(body, onProg) {
  const r = await fetch("/api/msa/screen", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const j = await r.json();
  if (!r.ok) throw new Error(j.detail || r.statusText);
  let st;
  for (;;) {
    st = await (await fetch(`/api/screener/job/${j.id}`)).json();
    if (st.status !== "running") break;
    if (st.total && onProg) onProg(st);
    await new Promise((ok) => setTimeout(ok, 400));
  }
  if (st.status === "error") throw new Error(st.error);
  if (!st.result) throw new Error(`scan berhenti tanpa hasil (status: ${st.status})`);
  return st.result;
}
async function runMsc() {
  const body = { symbol: ($("mscSym").value || "").trim().toUpperCase(), tf: $("mscTf").value, swing: $("mscSwing").value, scope: $("mscScope").value, htf: $("mscHtf").value };
  if (!body.symbol) return toast("Isi koin dulu, mis. BTCUSDT");
  store.set("mscForm", body);
  $("mscRun").disabled = true; $("mscStatus").innerHTML = `Membaca struktur ${esc(body.symbol)} &amp; mencari pola di riwayat<span class="dots"></span>`;
  $("mscEmpty").classList.remove("hidden"); $("mscOut").classList.add("hidden");
  $("mscEmpty").innerHTML = `<h3>⏳ Scan ${esc(body.symbol)} ${esc(body.tf.toUpperCase())}<span class="dots"></span></h3><p class="hint">Gambar visual entry muncul di sini sebentar lagi.</p>`;
  try {
    MSC_S.res = await mscFetch(body, (st) => { $("mscStatus").innerHTML = `Mencari pola di riwayat ${st.done}/${st.total} koin<span class="dots"></span>`; });
    MSC_S.plan = 0;
    try { localStorage.setItem("mscLast", JSON.stringify(MSC_S.res)); } catch { /* penyimpanan penuh / diblokir: abaikan */ }
    const R = MSC_S.res;
    $("mscStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${R.elapsed} dtk · struktur dari ${R.source === "binance" ? "Binance (live)" : "data lokal"} · riwayat ${R.n_coins || 0} koin`;
    renderMsc();
    $("mscOut").scrollIntoView({ behavior: "smooth" });
  } catch (ex) {
    $("mscStatus").textContent = "⚠️ " + ex.message;
    $("mscEmpty").classList.remove("hidden"); $("mscOut").classList.add("hidden");
    $("mscEmpty").innerHTML = `<h3>⚠️ Scan gagal</h3><p>${esc(ex.message)}</p><p class="hint">Kirim tulisan ini kalau bingung.</p>`;
    console.error(ex);
  } finally { $("mscRun").disabled = false; }
}
// ---- ringkasan singkat DI DALAM gambar kartu (supaya cukup lihat 1 gambar)
const _p0 = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), _r2 = (x) => (x == null ? "—" : `${x >= 0 ? "+" : ""}${x.toFixed(2)}R`);
function predLine(R) {
  const P = R.pred;
  if (!P || !(P.up + P.down)) return null;
  const down = P.pct_down > P.pct_up, pct = down ? P.pct_down : P.pct_up, bars = down ? P.bars_down : P.bars_up;
  let t = `${down ? "📉 Turun" : "📈 Naik"} 2 ATR duluan ${_p0(pct)}${bars ? ` (±${bars} candle)` : ""}`, c = "#c9d1db";
  if (P.base_up != null) {
    const nb = down ? P.base_down : P.base_up, ed = P.edge;
    t += ` · normal ${_p0(nb)} → keunggulan ${ed >= 0 ? "+" : ""}${ed.toFixed(0)}% ${ed > 0 ? (P.edge_txt === "meyakinkan" ? "meyakinkan ✓" : P.edge_txt === "lemah" ? "lemah" : "bisa kebetulan ⚠") : "tidak unggul ⚠"}`;
    c = ed > 0 && P.edge_txt === "meyakinkan" ? "#36e3a1" : ed > 0 && P.edge_txt === "lemah" ? "#f5c451" : "#ff8a8a";
  }
  return { t, c, b: true };
}
function htfLine(R, posDir) {
  const F = R.filters;
  if (!F) return null;
  const P = R.pred, down = P && P.pct_down > P.pct_up;
  const parts = [];
  if (F.htf) {
    const tn = F.htf_now, ref = posDir != null ? (posDir === 0 ? "naik" : "turun") : down ? "turun" : "naik";
    parts.push(`🧭 Tren ${F.htf.toUpperCase()}: ${tn || "belum jelas"}${tn === "naik" || tn === "turun" ? (tn === ref ? ` (searah ${posDir != null ? "posisi kamu" : "prediksi"} ✓)` : ` (melawan ${posDir != null ? "posisi kamu" : "prediksi"} ⚠)`) : ""}`);
  } else parts.push("🧭 Tren TF besar: mati");
  const m = (F.modes || []).find((x) => x.name === F.mode);
  parts.push(`kejadian dipakai: ${F.mode} (${R.n_occ}${F.n_all ? ` dari ${F.n_all}` : ""})${m && m.test_hit != null ? ` · tebakan benar di data uji ${_p0(m.test_hit)}` : ""}`);
  return { t: parts.join(" · "), c: "#c9d1db" };
}
function timeLine(x, tf, mk, where) {                                // perkiraan waktu dari riwayat (median)
  if (!x || (x.tp_bars == null && x.sl_bars == null)) return null;
  const parts = [];
  if (!mk && x.fill_bars != null) parts.push(`limit terisi ${pcDur(x.fill_bars, tf)}`);
  if (x.tp_bars != null) parts.push(`kena TP ${pcDur(x.tp_bars, tf)}`);
  if (x.sl_bars != null) parts.push(`kena SL ${pcDur(x.sl_bars, tf)}`);
  return { t: `⏱ Perkiraan waktu${where ? ` (${where})` : ""}: ${parts.join(" · ")} sesudah entry (median riwayat)`, c: "#a5b4fc" };
}
function heavyLine(x, where) {
  if (!x || x.max_loss_streak == null) return null;
  const bad = x.max_loss_streak >= 8 || x.max_dd >= 8;
  return { t: `😓 Seberat apa dijalani${where ? ` (${where})` : ""}: kalah beruntun terpanjang ${x.max_loss_streak}× · drawdown terdalam −${x.max_dd.toFixed(1)} R${bad ? " — siapkan mental & kecilkan risiko per trade" : ""}`,
    c: bad ? "#f5c451" : "#c9d1db" };
}
// 🌊 Elliott Wave + 🏅 kelas A/B/C (bukti tambahan, tidak menyaring sinyal). ev = hasil backend evidence.describe
function paLine(R) {
  const pa = R && R.proj && R.proj.path && R.proj.path.pa;
  if (!pa) return null;
  const st = (pa.marks || []).filter((m) => /^mantul|^koreksi/.test(m.text)).map((m) => m.text.replace("mantul di SNR minor ", ""));
  return { t: `🎬 Animasi price action: ${pa.synthetic ? "koreksi normal di tengah jalan (tidak ada SNR minor di jalur)" : st.length ? `mantul di SNR minor ${st.join(" → ")}` : "langsung"} · dalam mantul ±${Math.round(pa.retr * 100)}% (median koin ini) · ${pa.outcome === "tp" ? "berakhir kena TP" : "berakhir kena SL"} = hasil paling sering (ilustrasi bentuk, bukan kepastian)`.slice(0, 175), c: "#c4b5fd" };
}
function evLines(ev) {
  if (!ev || !ev.items) return ev && ev.note ? [{ t: `🏅 Kelas: — (${ev.note})`, c: "#8b96a5" }] : [];
  const it = (k) => ev.items.find((x) => x.key === k) || {};
  const ew = it("ew"), eh = it("ew_htf");
  const L = [];
  if (ew.label || eh.label) {
    const mk = (x) => `${x.name}: ${x.label || "—"}${x.agree > 0 ? " ✓" : x.agree < 0 ? " ✗" : ""}`;
    L.push({ t: `🌊 ${[ew, eh].filter((x) => x.label).map(mk).join(" · ")}`.slice(0, 170), c: ew.agree < 0 ? "#f5c451" : "#c4b5fd" });
  }
  const sym = (x) => (x.agree > 0 ? "✓" : x.agree < 0 ? "✗" : "–");
  const short = { ew: "Elliott", ew_htf: "Elliott besar", d1: "D1", btc: "BTC", rs: "kuat vs BTC", sweep: "sapuan likuiditas" };
  const parts = ev.items.map((x) => `${sym(x)} ${short[x.key]}${x.key === "btc" && x.label ? ` (${x.label.split(" ·")[0]})` : ""}`).join(" · ");
  const G = ev.grades || {}, gw = (g) => (G[g] && G[g].wr != null ? `${g} ${G[g].wr.toFixed(0)}%` : null);
  const gtxt = ["A", "B", "C"].map(gw).filter(Boolean).join(" · ");
  const col = { A: "#36e3a1", B: "#f5c451", C: "#ff8a8a" }[ev.grade] || "#8b96a5";
  L.push({ t: ev.grade
      ? `🏅 Kelas ${ev.grade} — ${ev.agree} bukti searah, ${ev.against} melawan · WR data uji per kelas: ${gtxt}${ev.proven ? " ✓" : " ⚠ belum terbukti"}`
      : `🏅 Kelas: — (${ev.note || "belum bisa dinilai"}) · ${ev.agree} bukti searah, ${ev.against} melawan`, c: col, b: !!ev.grade });
  L.push({ t: `   ${parts}`.slice(0, 170), c: "#8b96a5" });
  return L;
}
function mscInsights(R, B) {
  const L = [predLine(R), htfLine(R, null)];
  const live = B && (B.usable != null ? B.usable : B.live !== false);
  if (B && live) {
    const mk = B.entry === "market";
    L.push({ t: `🎯 ${B.dir === 0 ? "BUY" : "SELL"} ${mk ? "MARKET" : "LIMIT"} ${pxTxt(B.price_entry)} · SL ${pxTxt(B.price_sl)} · TP ${pxTxt(B.price_tp)} (1:${B.rr}) · ${mk ? "masuk sekarang" : `limit terisi ${_p0(B.fill_pct)}`} · WR ${_p0(B.wr)} · ${_r2(B.exp_sig != null ? B.exp_sig : B.exp_r)}/sinyal ${B.proven ? "· terbukti di data uji ✓" : "· belum terbukti ⚠"}`, c: "#e6ebf2", b: true });
    L.push(timeLine(B, R.tf, B.entry === "market", ""));
    L.push(heavyLine(B, "riwayat aturan ini, semua koin"));
    L.push(...evLines(B.evidence));
    L.push(paLine(R));
  } else if (B) L.push({ t: `⚠ Setup ini tidak layak (${B.why_not || B.status}) — jangan dipasang.`, c: "#ff8a8a", b: true });
  else if (R.last_plan) {
    L.push({ t: `⏳ Jangan entry dulu — belum ada setup yang sering terisi (≥ 70%) DAN tidak rugi (setup terbaik: ${R.last_plan.why_not || R.last_plan.status}). Tunggu pola baru lalu Scan lagi.`, c: "#f5c451", b: true });
    L.push(...evLines(R.last_plan.evidence).slice(0, 1));             // keadaan Elliott tetap ditampilkan (info)
  }
  else L.push({ t: "⚠ Tidak ada aturan entry RR ≥ 1:3 yang untung untuk pola ini — jangan dipaksakan.", c: "#ff8a8a", b: true });
  const P = R.pred || {}, strong = P.edge > 0 && P.edge_txt === "meyakinkan";
  L.push(B && live && strong && B.proven ? { t: "✅ Kesimpulan: pola punya keunggulan nyata & setup terbukti — boleh diikuti, SL wajib dipasang.", c: "#36e3a1" }
    : B && live && strong ? { t: "🟡 Kesimpulan: arah pola meyakinkan, tapi setup belum terbukti di data uji — kecilkan risiko.", c: "#f5c451" }
    : B && live ? { t: "🟡 Kesimpulan: keunggulan arah pola lemah — kalau ikut, kecilkan risiko.", c: "#f5c451" }
    : { t: "⏸ Kesimpulan: belum ada yang perlu dipasang sekarang.", c: "#8b96a5" });
  return L.filter(Boolean);
}
function mscFull(R, B) { return { ...R, insights: mscInsights(R, B || null) }; }
function pcInsights(R) {
  const S = R.stats || {}, tf = R.tf, L = [];
  L.push(R.filled
    ? { t: `📍 Dari sekarang: TP duluan ${_p0(S.wr)} / SL duluan ${_p0(S.sl_pct)} · biasanya selesai ${pcDur(S.exit_bars, tf)} · hasil ${_r2(S.exp_sig)}/sinyal (${R.n_occ} kejadian)`, c: (S.wr || 0) >= (S.sl_pct || 0) ? "#36e3a1" : "#ff8a8a", b: true }
    : { t: `⏳ Limit kamu terisi ${_p0(S.fill_pct)} kejadian, biasanya ${pcDur(S.fill_bars, tf)} · kalau terisi: TP duluan ${_p0(S.wr)} / SL duluan ${_p0(S.sl_pct)} · hasil ${_r2(S.exp_sig)}/sinyal`, c: (S.exp_sig || 0) > 0 ? "#36e3a1" : "#ff8a8a", b: true });
  if (!R.filled && S.fill_pct != null && S.fill_pct < 70)
    L.push({ t: `⚠ Limit kamu JARANG terisi (${_p0(S.fill_pct)} < 70%) — sering harga pergi tanpa kamu. Geser entry lebih dekat ke harga sekarang.`, c: "#ff8a8a", b: true });
  L.push(timeLine(S, tf, R.filled, "entry kamu"));
  L.push(heavyLine(S, "entry kamu di riwayat"));
  const pl = predLine(R);
  if (pl) L.push(pl);
  L.push(htfLine(R, R.dir));
  L.push(...evLines(R.evidence));
  L.push(paLine(R));
  const nm = { entry: "Entry", sl: "SL", tp: "TP" };
  const why = (x) => x.kind === "sl" && x.anti ? `SL anti-gocekan Whale${x.better ? "" : ", tidak lebih baik — pembanding"}`
    : x.kind === "sl" && x.shift_atr > 0 ? `${_p0(S.wick_pct)} trade kena wick lalu tetap ke TP`
    : x.kind === "tp" ? (x.shift_atr > 0 ? "harga sering lanjut melewati TP kamu" : "TP kamu sering tidak tercapai")
    : x.kind === "entry" ? `terisi ${_p0(S.fill_pct)}→${_p0(x.stats.fill_pct)}` : "harga jarang balik sejauh SL kamu";
  const sg = (R.suggestions || []).map((x) => `${nm[x.kind]} → ${pxTxt(x.price)} (${why(x)}; ${_r2(S.exp_sig)}→${_r2(x.stats.exp_sig)}${x.proven ? " ✓" : " ⚠"})`);
  if (sg.length) sg.forEach((t, i) => L.push({ t: `${i ? "   " : "💡 Saran: "}${t}`, c: "#a5b4fc", b: true }));
  else L.push({ t: "✅ Level kamu sudah termasuk yang terbaik untuk pola ini (tidak ada geseran yang lebih baik).", c: "#36e3a1" });
  const good = (S.exp_sig || 0) > 0 && R.test && (R.test.exp_sig || 0) > 0;
  L.push(good ? { t: "✅ Kesimpulan: entry kamu rata-rata untung di riwayat & di data uji — layak dipertahankan.", c: "#36e3a1" }
    : (S.exp_sig || 0) > 0 ? { t: "🟡 Kesimpulan: untung di riwayat tapi tidak di data uji terbaru — hati-hati, pertimbangkan saran.", c: "#f5c451" }
    : { t: "⚠ Kesimpulan: entry ini rata-rata rugi untuk pola ini — pakai saran atau lewati.", c: "#ff8a8a" });
  return L.filter(Boolean);
}
// 🎯 seberapa akurat: pembanding (arah normal), filter tren TF besar & leg mirip — dinilai di 30% kejadian terakhir
function accHtml(R) {
  const F = R.filters, P = R.pred;
  if (!F || !P || P.base_up == null) return "";
  const pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), down = P.pct_down > P.pct_up;
  const nb = down ? P.base_down : P.base_up, ed = P.edge;
  const col = ed > 0 && P.edge_txt === "meyakinkan" ? "pos" : ed > 0 ? "" : "neg";
  return `<h4>🎯 Seberapa akurat prediksi ini?</h4>
    <ul><li>Setelah pola ini harga <b>${down ? "turun" : "naik"} 2 ATR duluan ${pc(down ? P.pct_down : P.pct_up)}</b>. Normalnya (setelah swing apa pun di koin &amp; TF yang sama)
      <b>${pc(nb)}</b> → keunggulan pola <b class="${col}">${ed >= 0 ? "+" : ""}${ed.toFixed(0)}%</b>
      (${ed > 0 ? (P.edge_txt === "meyakinkan" ? "meyakinkan ✅" : P.edge_txt === "lemah" ? "lemah — bisa jadi sebagian kebetulan" : "bisa kebetulan ⚠️") : "tidak lebih baik dari normal ⚠️"}).</li>
      <li>Tren ${F.htf ? `<b>${F.htf.toUpperCase()}</b> sekarang: <b>${esc(F.htf_now || "belum jelas")}</b>` : "TF besar: <b>mati</b>"}${F.legs_now ? ` · ukuran leg pola sekarang (ATR): ${F.legs_now.map((x) => (x > 0 ? "+" : "") + x).join(", ")}` : ""}.</li>
      <li>Kejadian yang dipakai: <b>${esc(F.mode)}</b> (${R.n_occ} dari ${F.n_all || R.n_occ}). Penyaring hanya dipakai kalau tebakan arah di 30% data terakhir lebih tepat ≥ 2%.</li></ul>
    <div class="scroll"><table class="tbl"><tr><th>Kejadian</th><th class="num">Jumlah</th><th class="num">Naik / turun duluan</th><th class="num">Tebakan benar di data uji</th><th></th></tr>` +
    F.modes.map((m) => `<tr${m.name === F.mode ? ' class="wh-best"' : ""}><td>${esc(m.name)}</td><td class="num">${m.n}</td><td class="num">${pc(m.pct_up)} / ${pc(m.pct_down)}</td>
      <td class="num">${m.test_hit == null ? "—" : `${pc(m.test_hit)} <small>(${m.n_test})</small>`}</td><td>${m.name === F.mode ? "✅ dipakai" : m.eligible ? "" : "<small class='hint'>sampel kurang</small>"}</td></tr>`).join("") + `</table></div>`;
}
function mscNorm(R) {                                               // hasil lama (≤ v3.84): setup yang sudah lewat jangan jadi sinyal utama
  if (R && R.best && (R.best.live === false || R.best.usable === false)) { R.last_plan = R.best; R.best = null; }
  return R;
}
// ---- 🔎 scan banyak koin (Screener Market Structure) -> koin dengan setup layak
const MSM = { res: null, busy: false };
async function runMscMulti() {
  if (MSM.busy) return;
  const raw = ($("mscMultiCoins").value || "50").trim();
  const body = { coins: /^\d+$/.test(raw) ? +raw : raw, tf: $("mscTf").value, swing: $("mscSwing").value, scope: $("mscScope").value, htf: $("mscHtf").value,
    min_leg: +$("mscMultiLeg").value };
  store.set("mscMultiCoins", raw);
  MSM.busy = true; $("mscMultiRun").disabled = true;
  $("mscMulti").classList.remove("hidden");
  $("mscMulti").innerHTML = `<h3>⏳ Scan banyak koin ${esc(body.tf.toUpperCase())}<span class="dots"></span></h3>`;
  try {
    const r = await fetch("/api/msa/scan", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    let st;
    for (;;) {
      st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (st.status !== "running") break;
      $("mscMultiStatus").innerHTML = `Scan ${st.done}/${st.total || "?"} koin${st.recent && st.recent[0] ? ` · ${esc(st.recent[0].symbol)}` : ""}<span class="dots"></span>`;
      if (st.partial) { MSM.res = st.partial; renderMscMulti(); }
      await new Promise((ok) => setTimeout(ok, 700));
    }
    if (st.status === "error") throw new Error(st.error);
    MSM.res = st.result;
    $("mscMultiStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${MSM.res.n} koin dibaca · ${MSM.res.n_usable} punya setup layak${MSM.res.n_errors ? ` · ${MSM.res.n_errors} dilewati` : ""}`;
    renderMscMulti();
  } catch (ex) {
    $("mscMultiStatus").textContent = "⚠️ " + ex.message;
    $("mscMulti").innerHTML = `<h3>⚠️ Scan gagal</h3><p>${esc(ex.message)}</p>`;
  } finally { MSM.busy = false; $("mscMultiRun").disabled = false; }
}
function renderMscMulti() {
  const R = MSM.res, box = $("mscMulti");
  if (!R) return;
  box.classList.remove("hidden");
  const pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), sg = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(2)}R`);
  const ok = R.rows.filter((x) => x.usable), no = R.rows.filter((x) => !x.usable);
  const pred = (x) => x.pct == null ? "—" : `${x.dir_pred > 0 ? "▲" : "▼"} ${pc(x.pct)}${x.edge != null ? ` <small>(${x.edge >= 0 ? "+" : ""}${x.edge.toFixed(0)}% ${esc(x.edge_txt || "")})</small>` : ""}`;
  box.innerHTML = `${R.partial ? `<p class="hint">⏳ Hasil sementara (${R.done}/${R.total} koin) — kartu bisa dibuka setelah scan selesai.</p>` : ""}${R.note ? `<p class="hint">⚠️ ${esc(R.note)}</p>` : ""}
    <h3>✅ ${ok.length} koin punya setup layak <small class="hint">${R.rows.length} koin dibaca · klik baris untuk kartu visual</small></h3>
    ${ok.length ? `<div class="scroll"><table class="tbl"><tr><th>Koin</th><th>Sinyal</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP</th><th class="num">Terisi</th><th class="num" title="MANTUL BERSIH di riwayat: entry hanya tersentuh ekor (close kembali di sisi untung), lalu +1R tercapai dalam 12 candle tanpa satu pun close di area entry–SL">🏓 Mantul bersih</th><th class="num" title="Di riwayat: sesudah entry kena, ada close di area entry–SL sebelum +1R (harga main dulu di area entry–SL)">⏳ Main dulu</th><th class="num">WR</th><th class="num">R/sinyal</th><th class="num">😓 Kalah beruntun · DD</th><th title="Kelas A/B/C dari bukti tambahan (Elliott, D1, BTC sesuai korelasi, kekuatan vs BTC, sapuan likuiditas, sesi)">🏅 Kelas</th><th>Prediksi pola</th><th>Tren TF besar</th></tr>` +
      ok.map((x) => `<tr data-msm="${esc(x.symbol)}" title="Buka kartu visual"><td><b>${esc(x.symbol)}</b></td>
        <td class="${x.dir === 0 ? "pos" : "neg"}">${x.dir === 0 ? "▲ BUY" : "▼ SELL"} ${x.entry === "market" ? "MARKET" : "LIMIT"} <small>1:${x.rr}</small></td>
        <td class="num">${pxTxt(x.price_entry)}${cpB(x.price_entry)}</td><td class="num neg">${pxTxt(x.price_sl)}${cpB(x.price_sl)}</td><td class="num pos">${pxTxt(x.price_tp)}${cpB(x.price_tp)}</td>
        <td class="num">${x.entry === "market" ? "100%" : pc(x.fill_pct)}</td><td class="num">${x.bounce_pct == null ? "—" : pc(x.bounce_pct)}</td><td class="num">${x.main_pct == null ? "—" : pc(x.main_pct)}</td><td class="num">${pc(x.wr)}</td><td class="num pos"><b>${sg(x.exp_sig)}</b></td>
        <td class="num">${x.max_loss_streak != null ? `${x.max_loss_streak}× · −${x.max_dd.toFixed(1)}R` : "—"}</td>
        <td>${gradeBadge(x.evidence, true)}</td>
        <td>${pred(x)}${(x.dir === 0) !== (x.dir_pred > 0) ? ' <span class="badge fail" title="Arah setup berlawanan dengan arah mayoritas pola">⚠ melawan prediksi</span>' : ""}</td>
        <td>${x.htf ? `${esc(x.htf.toUpperCase())} ${esc(x.htf_now || "?")}${(x.htf_now === "naik" || x.htf_now === "turun") && (x.htf_now === "naik") !== (x.dir === 0) ? " ⚠" : ""}` : "—"}</td></tr>${msmEvalRow(x, pc, sg)}`).join("") + `</table></div>`
      : `<p>⏳ <b>Jangan entry dulu</b> — tidak ada koin yang setupnya lolos semua syarat sekarang.</p>`}
    ${no.length ? `<details><summary><b>⏸ ${no.length} koin lain — jangan entry dulu</b> <small class="hint">alasan &amp; prediksi pola</small></summary>
      <div class="scroll" style="max-height:360px"><table class="tbl"><tr><th>Koin</th><th>Alasan</th><th>Pola</th><th>Prediksi pola</th><th>Tren TF besar</th></tr>` +
      no.map((x) => `<tr><td>${esc(x.symbol)}</td><td>${esc(x.why_not || "—")}</td><td>${esc((x.pattern || []).join(" › "))}</td><td>${pred(x)}</td><td>${x.htf ? `${esc(x.htf.toUpperCase())} ${esc(x.htf_now || "?")}` : "—"}</td></tr>`).join("") +
      `</table></div></details>` : ""}`;
}
// 🔬 entry dievaluasi (scan banyak koin): pilihan kedua di bawah tiap sinyal; user memilih entry mana yang dipakai
function msmEvalRow(x, pc, sg) {
  const E = x.eval;
  if (!E) return "";
  const pick = (MSM.pick || {})[x.symbol] || "sig", b = E.best;
  const radio = (v, t) => `<label class="msm-pick"><input type="radio" name="msmp_${esc(x.symbol)}" data-msmpick="${esc(x.symbol)}" value="${v}" ${pick === v ? "checked" : ""}> ${t}</label>`;
  if (E.same || !b) {
    return `<tr class="msm-eval"><td></td><td colspan="13"><span class="hint">🔬 Evaluasi entry: ${b ? "entry sinyal sudah yang paling sering <b>mantul bersih</b> dari semua geseran yang dicoba" : "tidak ada geseran entry yang lolos syarat (terisi ≥ 70%, untung, untung di data uji, WR ≥ 50%)"} — pakai entry sinyal.</span></td></tr>`;
  }
  const dir = b.frac > 0 ? `digeser ${(b.frac * 100).toFixed(0)}% risiko ke arah SL` : `digeser ${(-b.frac * 100).toFixed(0)}% risiko menjauhi SL`;
  return `<tr class="msm-eval"><td>${radio("sig", "Sinyal")}<br>${radio("eval", "🔬 Dievaluasi")}</td>
    <td><small>🔬 entry ${dir}</small><br><b>${b.entry === "market" ? "MARKET" : "LIMIT"}</b> <small>1:${x.rr}</small></td>
    <td class="num"><b>${pxTxt(b.price_entry)}</b>${cpB(b.price_entry)}</td><td class="num neg">${pxTxt(b.price_sl)}${cpB(b.price_sl)}</td><td class="num pos">${pxTxt(b.price_tp)}${cpB(b.price_tp)}</td>
    <td class="num">${b.entry === "market" ? "100%" : pc(b.fill_pct)}</td><td class="num"><b class="pos">${pc(b.clean_pct)}</b></td><td class="num">${pc(b.main_pct)}</td><td class="num">${pc(b.wr)}</td><td class="num pos"><b>${sg(b.exp_sig)}</b></td>
    <td colspan="4"><small>data uji ${sg(b.exp_test)} (${b.n_test}) · ${b.n} trade terisi · sinyal: mantul bersih ${pc(E.signal.clean_pct)}, main dulu ${pc(E.signal.main_pct)}</small></td></tr>`;
}
// kartu visual mengikuti pilihan entry user (sinyal / dievaluasi)
function msmPicked(R) {
  const p = (MSM.pick || {})[R.symbol], B = R.best;
  if (p !== "eval" || !B || !B.eval || !B.eval.best || B.eval.same) return R;
  const b = B.eval.best;
  const nb = { ...B, price_entry: b.price_entry, price_sl: b.price_sl, price_tp: b.price_tp, entry: b.entry, fill_pct: b.fill_pct, wr: b.wr,
    exp_r: b.exp_r, exp_sig: b.exp_sig, entry_txt: `🔬 entry dievaluasi (${b.entry === "market" ? "market" : "limit"})`, risk_pct: Math.abs(b.price_entry - b.price_sl) / b.price_entry * 100 };
  return { ...R, best: nb, plans: R.plans.map((q) => (q === B ? nb : q)), proj: null };   // animasi prediksi dibuat dari entry sinyal: tidak dipakai
}
function mscPlan() {
  const R = MSC_S.res;
  if (!R) return null;
  if (MSC_S.plan === 0) return R.best || null;
  return R.plans[MSC_S.plan - 1] || null;
}
function renderMsc() {
  const R = mscNorm(MSC_S.res), box = $("mscOut");
  box.classList.remove("hidden"); $("mscEmpty").classList.add("hidden");
  if (!R.pattern || !R.n_occ) {
    box.innerHTML = `<div class="card evalcard"><h3>🔎 ${esc(R.symbol)} · ${esc(R.tf.toUpperCase())}</h3><p>Pola sekarang ${esc((R.pattern || []).join(" › "))} tidak ditemukan di riwayat. Coba ukuran swing lain atau riwayat "Semua koin".</p></div>`;
    return;
  }
  const B = mscPlan(), P = R.pred, pc = (x) => `${x.toFixed(0)}%`, sg = (x) => (x == null ? "—" : `${x >= 0 ? "+" : ""}${x.toFixed(2)}R`);
  const dirW = (d) => (d === 0 ? "🟢 LONG" : "🔴 SHORT");
  const tabs = [`<button class="mini${MSC_S.plan === 0 ? " on" : ""}" data-mscp="0">⭐ Terbaik</button>`]
    .concat(R.plans.map((p, i) => `<button class="mini${MSC_S.plan === i + 1 ? " on" : ""}" data-mscp="${i + 1}">${dirW(p.dir)} ${sg(p.exp_sig != null ? p.exp_sig : p.exp_r)}/sinyal${p.usable === false ? " ⚠" : ""}</button>`)).join(" ");
  const nx = (P.next || []).map((x) => `<span class="chip">${esc(x.label)} <b>${pc(x.pct)}</b> <small>(${x.n})</small></span>`).join(" ");
  const ex = R.examples || [];
  box.innerHTML = `<div class="msc-card">${MSC.card(mscFull(R, B), B, false)}</div>
    <div class="msc-btns">${tabs}<span style="flex:1"></span>
      <button class="mini" id="mscCopy">📋 Salin sinyal</button><button class="mini" id="mscDl">⬇ Unduh gambar</button><button class="mini" id="mscReplay">▶ Putar ulang animasi</button></div>
    <details class="card evalcard msc-more"><summary><b>📄 Detail lengkap</b> <small class="hint">angka &amp; tabel di balik gambar — tidak wajib dibaca</small></summary>${R.note ? `<p class="hint">⚠️ ${esc(R.note)}</p>` : ""}
    ${!R.best && R.last_plan && MSC_S.plan === 0 ? `<p class="hint">⏳ <b>Jangan entry dulu.</b> Sinyal hanya diberikan kalau entry-nya di riwayat terisi ≥ 70% <b>dan</b> rata-rata untung (juga di data uji). Setup terbaik sekarang: ${esc(R.last_plan.why_not || R.last_plan.status)}.
      Entry dihitung saat swing terakhir terkonfirmasi, jadi tunggu swing / pola baru lalu klik Scan lagi. Setup lama tetap bisa dilihat lewat tombol LONG / SHORT di atas.</p>` : ""}
    ${!R.best && !R.last_plan ? `<p class="hint">⚠️ Tidak ada aturan entry RR ≥ 1:3 yang hasil backtest-nya untung untuk pola ini, jadi <b>tidak ada sinyal</b>. Prediksi arah tetap ditampilkan sebagai gambaran.</p>` : ""}
    ${B && !B.proven ? `<p class="hint">⚠️ Aturan ini <b>belum terbukti</b>: di 30% data terakhir hasilnya tidak untung / kejadiannya terlalu sedikit.</p>` : ""}
    <h4>📊 Biasanya sesudah pola ${R.pattern.map(esc).join(" › ")}</h4>
    <div class="chips"><span class="chip">🔢 <b>${R.n_occ}</b> kejadian · ${R.n_coins} koin</span>
      <span class="chip">▲ naik ${P.move_atr || 2} ATR duluan <b>${pc(P.pct_up)}</b>${P.bars_up ? ` · ±${P.bars_up} candle` : ""}</span>
      <span class="chip">▼ turun ${P.move_atr || 2} ATR duluan <b>${pc(P.pct_down)}</b>${P.bars_down ? ` · ±${P.bars_down} candle` : ""}</span>
      ${P.unclear ? `<span class="chip">↔ tidak jelas <b>${P.unclear}</b></span>` : ""}</div>
    <p class="hint">Swing berikutnya yang terbentuk: ${nx || "—"}</p>
    ${accHtml(R)}
    <details><summary><b>🧪 Semua aturan yang diuji</b> <small class="hint">${R.rules.length} aturan dengan ≥ 15 trade · diurutkan dari R per sinyal (R per trade × peluang terisi)</small></summary>
      <div class="scroll" style="max-height:360px"><table class="tbl"><tr><th>Arah</th><th>Entry</th><th>SL</th><th class="num">RR</th><th class="num">Trade</th><th class="num">Terisi</th><th class="num">WR</th><th class="num">R/trade</th><th class="num">R/sinyal</th><th class="num">Data uji</th><th class="num" title="Kalah beruntun terpanjang · drawdown terdalam (R), urut waktu">Kalah beruntun · DD</th><th></th></tr>` +
      R.rules.map((r) => `<tr><td>${dirW(r.dir)}</td><td>${esc(r.entry_txt)}</td><td>${esc(r.sl_txt)}</td><td class="num">1:${r.rr}</td><td class="num">${r.n}</td>
        <td class="num">${pc(r.fill_pct)}</td><td class="num">${pc(r.wr)}</td><td class="num ${r.exp_r >= 0 ? "pos" : "neg"}">${sg(r.exp_r)}</td>
        <td class="num ${(r.exp_sig || 0) >= 0 ? "pos" : "neg"}"><b>${r.exp_sig != null ? sg(r.exp_sig) : "—"}</b></td>
        <td class="num">${r.n_test ? `${sg(r.exp_test)} <small>(${r.n_test})</small>` : "—"}</td>
        <td class="num">${r.max_loss_streak != null ? `${r.max_loss_streak}× · −${r.max_dd.toFixed(1)}R` : "—"}</td><td>${r.proven ? "✅" : ""}</td></tr>`).join("") + `</table></div></details>
    <details><summary><b>🔍 Contoh kejadian</b> <small class="hint">${ex.length} kejadian pola yang sama · klik untuk buka di Manual Replay</small></summary>
      <div class="scroll" style="max-height:360px"><table class="tbl"><tr><th>Waktu (UTC)</th><th>Koin</th><th>Gerak duluan</th><th>Pola</th></tr>` +
      ex.map((e, i) => `<tr data-mscx="${i}" title="Buka di chart"><td>${fmtTime(e.time).slice(0, 16)}</td><td>${esc(e.symbol)}</td>
        <td class="${e.first_move > 0 ? "pos" : e.first_move < 0 ? "neg" : ""}">${e.first_move > 0 ? "▲ naik" : e.first_move < 0 ? "▼ turun" : "↔ tidak jelas"}</td>
        <td>${e.swings.map((x) => esc(x.label || "?")).join(" › ")}</td></tr>`).join("") + `</table></div></details></details>`;
}
{
  const tfs = ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"];
  $("mscTf").innerHTML = tfs.map((t) => `<option value="${t}">${t.toUpperCase()}</option>`).join("");
  const f = store.get("mscForm", null) || {};
  $("mscTf").value = f.tf || "15m"; $("mscSwing").value = f.swing || "kecil"; $("mscScope").value = scopeTxt(f.scope); $("mscHtf").value = f.htf || "auto";
  $("mscSym").value = f.symbol || $("symbol").value || "BTCUSDT";
  $("mscRun").onclick = runMsc;
  $("mscMultiRun").onclick = runMscMulti;
  { const mc = store.get("mscMultiCoins", null); if (mc) $("mscMultiCoins").value = mc; }
  $("mscMulti").addEventListener("click", (e) => {
    const rb = e.target.closest("input[data-msmpick]");
    if (rb) { MSM.pick = MSM.pick || {}; MSM.pick[rb.dataset.msmpick] = rb.value; toast(rb.value === "eval" ? "Dipakai: 🔬 entry dievaluasi (kartu visual ikut)" : "Dipakai: entry sinyal"); return; }
    if (e.target.closest("tr.msm-eval")) return;
    const tr = e.target.closest("tr[data-msm]");
    if (!tr || !MSM.res || !MSM.res.full) return;
    const R0 = MSM.res.full[tr.dataset.msm];
    if (!R0) return toast("Kartu tersedia setelah scan selesai.");
    const R = msmPicked(R0);
    MSC_S.res = R; MSC_S.plan = 0;
    $("mscSym").value = R.symbol;
    renderMsc();
    $("mscOut").scrollIntoView({ behavior: "smooth", block: "start" });
  });
  window.addEventListener("error", (e) => {                         // error tak terduga: tampilkan, jangan diam-diam
    if ($("tab-msa").classList.contains("active")) $("mscStatus").textContent = `⚠️ Error di halaman: ${e.message}`;
  });
  try {                                                              // tampilkan hasil scan terakhir (kalau ada)
    const last = JSON.parse(localStorage.getItem("mscLast") || "null");
    if (last && last.symbol) {
      MSC_S.res = last; renderMsc();
      $("mscStatus").textContent = `Hasil scan terakhir: ${last.symbol} ${last.tf.toUpperCase()} · candle ${fmtTime(last.now_time).slice(0, 16)} UTC — klik Scan untuk data terbaru`;
    }
  } catch { /* abaikan */ }
  $("mscOut").addEventListener("click", async (e) => {
    const R = MSC_S.res;
    if (!R) return;
    const t = e.target.closest("[data-mscp]");
    if (t) { MSC_S.plan = +t.dataset.mscp; renderMsc(); return; }
    if (e.target.id === "mscCopy") { await copyText(MSC.signal(mscFull(R, mscPlan()), mscPlan())); return toast("Sinyal disalin 📋"); }
    if (e.target.id === "mscDl") { try { await MSC.download(mscFull(R, mscPlan()), mscPlan()); } catch (ex) { toast("Gagal membuat gambar: " + ex.message); } return; }
    if (e.target.id === "mscReplay") { renderMsc(); return; }
    const tr = e.target.closest("tr[data-mscx]");
    if (tr) {
      const x = R.examples[+tr.dataset.mscx];
      await openMoment(x.symbol, R.tf, x.time, x.swings.map((sw) => ({ point: true, time: sw.time, price: sw.price, label: sw.label })),
        `Pola ${R.pattern.join(" › ")} di ${x.symbol} ${fmtTime(x.time).slice(0, 16)} UTC (candle terakhir = swing terakhir terkonfirmasi). Sesudahnya harga ${x.first_move > 0 ? "naik" : x.first_move < 0 ? "turun" : "tidak jelas bergerak"} ${R.pred.move_atr || 2} ATR duluan — lanjutkan replay untuk melihat.`);
    }
  });
}

// ------------------------------------------------------------------ 🧪 cek entry posisi (entry / SL / TP kamu vs pola di riwayat)
const PC = { res: null };
function pcDur(bars, tf) {
  if (bars == null) return "—";
  const m = bars * (IT_TF_MIN[tf] || 15);
  return m < 60 ? `±${Math.round(m)} menit` : m < 1440 ? `±${+(m / 60).toFixed(1)} jam` : `±${+(m / 1440).toFixed(1)} hari`;
}
async function runPc() {
  const body = { symbol: ($("pcSym").value || "").trim().toUpperCase(), tf: $("pcTf").value, swing: $("pcSwing").value, scope: $("pcScope").value, htf: $("pcHtf").value,
    filled: $("pcFilled").value === "1", entry: $("pcEntry").value, sl: $("pcSl").value, tp: $("pcTp").value };
  if (!body.symbol) return toast("Isi koin dulu, mis. BTCUSDT");
  if (!body.entry || !body.sl || !body.tp) return toast("Isi entry, SL dan TP");
  store.set("pcForm", body);
  $("pcRun").disabled = true;
  $("pcStatus").innerHTML = `Membaca struktur ${esc(body.symbol)} &amp; menguji entry kamu di pola yang sama<span class="dots"></span>`;
  $("pcOut").classList.remove("hidden");
  $("pcOut").innerHTML = `<div class="card evalcard msc-empty"><h3>⏳ Cek entry ${esc(body.symbol)} ${esc(body.tf.toUpperCase())}<span class="dots"></span></h3></div>`;
  try {
    const r = await fetch("/api/msa/check", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    let st;
    for (;;) {
      st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (st.status !== "running") break;
      if (st.total) $("pcStatus").innerHTML = `Mencari pola di riwayat ${st.done}/${st.total} koin<span class="dots"></span>`;
      await new Promise((ok) => setTimeout(ok, 400));
    }
    if (st.status === "error") throw new Error(st.error);
    if (!st.result) throw new Error(`cek berhenti tanpa hasil (status: ${st.status})`);
    PC.res = st.result;
    $("pcStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${PC.res.elapsed} dtk · struktur dari ${PC.res.source === "binance" ? "Binance (live)" : "data lokal"} · riwayat ${PC.res.n_coins || 0} koin`;
    renderPc();
    $("pcOut").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (ex) {
    $("pcStatus").textContent = "⚠️ " + ex.message;
    $("pcOut").innerHTML = `<div class="card evalcard msc-empty"><h3>⚠️ Cek entry gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { $("pcRun").disabled = false; }
}
function pcSpec(R) {
  const S = R.stats || {}, tf = R.tf, long = R.dir === 0, sg = (x) => (x == null ? "—" : `${x >= 0 ? "+" : ""}${x.toFixed(2)}R`);
  const sug = Object.fromEntries((R.suggestions || []).map((x) => [x.kind, x]));
  const kind = R.filled ? "market" : (long ? R.entry < R.now_price : R.entry > R.now_price) ? "limit" : "stop";
  const walls = [];
  if (sug.entry) walls.push({ keep: true, price: sug.entry.price, color: "#a78bfa", label: `saran entry ${pxTxt(sug.entry.price)}` });
  if (sug.sl) walls.push({ keep: true, price: sug.sl.price, color: "#fb923c", label: `saran SL ${pxTxt(sug.sl.price)}` });
  if (sug.tp) walls.push({ keep: true, price: sug.tp.price, color: "#22d3ee", label: `saran TP ${pxTxt(sug.tp.price)}` });
  const pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`);
  const box4 = R.filled
    ? ["TP vs SL DULUAN", `${pc(S.wr)} / ${pc(S.sl_pct)}`, (S.wr || 0) >= (S.sl_pct || 0) ? "#36e3a1" : "#ff6b73", `TP / SL · selesai ${pcDur(S.exit_bars, tf)}`]
    : ["LIMIT TERISI", pc(S.fill_pct), "#e6ebf2", `biasanya ${pcDur(S.fill_bars, tf)} · TP duluan ${pc(S.wr)}`];
  const Rv = { ...R, sub: "Cek entry posisi", icon: "🧪", walls, insights: pcInsights(R),
    boxes: [["ENTRY KAMU", pxTxt(R.entry), "#60a5fa", sug.entry ? `saran: ${pxTxt(sug.entry.price)}` : R.filled ? "posisi sudah masuk" : "sudah pas"],
      ["STOP LOSS", pxTxt(R.sl), "#ff6b73", sug.sl ? `saran: ${pxTxt(sug.sl.price)}` : `kena wick ${pc(S.wick_pct)}`],
      ["TAKE PROFIT", pxTxt(R.tp), "#36e3a1", sug.tp ? `saran: ${pxTxt(sug.tp.price)}` : `RR 1:${R.rr.toFixed(2)}`],
      box4,
      ["HASIL / SINYAL", sg(S.exp_sig), (S.exp_sig || 0) > 0 ? "#36e3a1" : "#ff6b73", `${S.n_fill || 0} trade · data uji ${sg(R.test && R.test.exp_sig)}`]],
    lines: [`Peluang: ${R.filled ? "" : `limit terisi ${pc(S.fill_pct)} (${pcDur(S.fill_bars, tf)}) · `}TP duluan ${pc(S.wr)} · SL duluan ${pc(S.sl_pct)} · hasil ${sg(S.exp_sig)}/sinyal dari ${R.n_occ} kejadian`]
      .concat((R.suggestions || []).map((x) => `Saran ${x.kind.toUpperCase()}: ${pxTxt(x.price)}${x.proven ? " ✅" : ""}`)) };
  const B = { dir: R.dir, price_entry: R.entry, price_sl: R.sl, price_tp: R.tp, rr: R.rr, entry: kind === "market" ? "market" : "limit",
    entry_txt: R.filled ? "posisi sudah masuk" : kind === "stop" ? "order stop kamu" : "limit kamu", risk_pct: Math.abs(R.entry - R.sl) / R.entry * 100, live: true,
    status: R.filled ? `posisi berjalan · TP duluan ${pc(S.wr)}` : `menunggu · terisi ${pc(S.fill_pct)} dalam ${pcDur(S.fill_bars, tf)}` };
  return { R: Rv, B };
}
function renderPc() {
  const R = PC.res, box = $("pcOut");
  box.classList.remove("hidden");
  if (!R.n_occ || !R.stats) {
    box.innerHTML = `<div class="card evalcard"><h3>🧪 ${esc(R.symbol)} · ${esc(R.tf.toUpperCase())}</h3><p>Pola sekarang ${esc((R.pattern || []).join(" › "))} tidak ditemukan di riwayat. Coba ukuran swing lain.</p></div>`;
    return;
  }
  const S = R.stats, tf = R.tf, pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), sg = (x) => (x == null ? "—" : `${x >= 0 ? "+" : ""}${x.toFixed(2)}R`);
  const sp = pcSpec(R), st = R.story || {}, long = R.dir === 0, A = R.atr;
  const nm = { entry: "Entry", sl: "Stop loss", tp: "Take profit" };
  const sugg = (R.suggestions || []).map((x, i) => `<div class="pc-sug">
      <div><b>${nm[x.kind]}${x.anti ? " (🛡️ anti-gocekan Whale)" : ""}: ${pxTxt(R[x.kind])} → <span class="${x.anti && !x.better ? "" : "pos"}">${pxTxt(x.price)}</span></b>${cpB(x.price)} ${x.proven ? '<span class="badge pass">✅ terbukti di data uji</span>' : '<span class="badge fail">⚠️ belum terbukti di data uji</span>'}
        <button class="mini pc-use" data-i="${i}">Pakai saran ini</button></div>
      <p>${esc(x.why)}</p>
      <table class="tbl"><tr><th></th><th class="num">Terisi</th><th class="num">TP duluan</th><th class="num">Hasil / sinyal</th><th class="num">Data uji (30% terakhir)</th></tr>
        <tr><td>Punya kamu</td><td class="num">${pc(S.fill_pct)}</td><td class="num">${pc(S.wr)}</td><td class="num">${sg(S.exp_sig)}</td><td class="num">${sg(R.test.exp_sig)}</td></tr>
        <tr><td>Saran</td><td class="num">${pc(x.stats.fill_pct)}</td><td class="num">${pc(x.stats.wr)}</td><td class="num"><b>${sg(x.stats.exp_sig)}</b></td><td class="num">${sg(x.test.exp_sig)}</td></tr></table></div>`).join("");
  const C = R.combined;
  const ex = R.examples || [];
  box.innerHTML = `<div class="msc-card">${MSC.card(sp.R, sp.B, false)}</div>
    <div class="msc-btns"><span style="flex:1"></span><button class="mini" id="pcCopy">📋 Salin hasil</button><button class="mini" id="pcDl">⬇ Unduh gambar</button><button class="mini" id="pcReplay">▶ Putar ulang animasi</button><button class="mini" id="pcJournal" title="Pantau entry ini di 📒 Jurnal sampai kena TP / SL">📒 Pantau di jurnal</button></div>
    <details class="card evalcard msc-more"><summary><b>📄 Detail lengkap</b> <small class="hint">angka &amp; tabel di balik gambar — tidak wajib dibaca</small></summary>${R.note ? `<p class="hint">⚠️ ${esc(R.note)}</p>` : ""}
    <h4>🎯 ${R.filled ? "Posisi kamu" : "Entry kamu"} di ${R.n_occ} kejadian pola ${(R.pattern || []).map(esc).join(" › ")} (${R.n_coins} koin)</h4>
    <ul>
      ${R.filled ? "" : `<li>Limit <b>terisi ${pc(S.fill_pct)}</b> kejadian, biasanya dalam <b>${pcDur(S.fill_bars, tf)}</b> (umumnya ${pcDur(S.fill_p25, tf)} – ${pcDur(S.fill_p75, tf)}). Tidak terisi dalam ${pcDur(96, tf)} = dianggap batal.</li>`}
      <li>${R.filled ? "Dari sekarang" : "Kalau terisi"}: <b class="pos">kena TP duluan ${pc(S.wr)}</b> · <b class="neg">kena SL duluan ${pc(S.sl_pct)}</b>${S.to_pct ? ` · belum kena dua-duanya ${pc(S.to_pct)}` : ""} · biasanya selesai dalam ${pcDur(S.exit_bars, tf)}.</li>
      <li>Hasil rata-rata <b>${sg(S.exp_sig)} per sinyal</b> (${sg(S.exp_r)} per trade terisi). Data uji 30% terakhir: ${sg(R.test.exp_sig)} per sinyal.</li>
      ${S.wick_pct ? `<li>${pc(S.wick_pct)} trade kena SL dulu lalu harga tetap sampai TP (kena wick / gocekan).</li>` : ""}
      ${st.counter_atr != null ? `<li>Pola ini rata-rata <b>${long ? "turun" : "naik"} dulu ±${st.counter_atr.toFixed(2)} ATR</b> (≈ ${pxTxt(long ? R.now_price - st.counter_atr * A : R.now_price + st.counter_atr * A)}) sebelum ${long ? "naik" : "turun"} 2 ATR.</li>` : ""}
      ${st.mfe_atr != null ? `<li>Median gerak maksimal searah setelah entry ±${st.mfe_atr.toFixed(2)} ATR (≈ ${pxTxt(long ? R.entry + st.mfe_atr * A : R.entry - st.mfe_atr * A)}).</li>` : ""}
      ${R.pred ? `<li>Prediksi arah dari pola: <b>${R.pred.pct_up >= 50 ? `naik ${pc(R.pred.pct_up)}` : `turun ${pc(R.pred.pct_down)}`}</b> (2 ATR duluan) — ${(R.pred.pct_up >= 50) === long ? "searah posisi kamu ✅" : "<span class='neg'>melawan posisi kamu ⚠️</span>"}.</li>` : ""}
    </ul>
    ${accHtml(R)}
    <h4>💡 Saran ${R.filled ? "SL / TP" : "entry / SL / TP"}</h4>
    ${sugg || `<p class="hint">Tidak ada geseran ${R.filled ? "TP" : "entry / TP"} yang menaikkan hasil ≥ 0,05R per sinyal — level kamu sudah termasuk yang terbaik untuk pola ini.</p>`}
    ${C ? `<div class="pc-sug"><div><b>Semua saran dipakai sekaligus:</b> entry ${pxTxt(C.entry)}${cpB(C.entry)} · SL ${pxTxt(C.sl)}${cpB(C.sl)} · TP ${pxTxt(C.tp)}${cpB(C.tp)}
        ${C.proven ? '<span class="badge pass">✅ terbukti di data uji</span>' : '<span class="badge fail">⚠️ belum terbukti</span>'} <button class="mini pc-use" data-i="all">Pakai semua</button></div>
        <p>Terisi ${pc(C.stats.fill_pct)} · TP duluan ${pc(C.stats.wr)} · hasil <b>${sg(C.stats.exp_sig)}</b> per sinyal (kamu ${sg(S.exp_sig)}) · data uji ${sg(C.test.exp_sig)}.</p></div>` : ""}
    <details><summary><b>🔍 Contoh kejadian</b> <small class="hint">${ex.length} kejadian · level kamu dipasang di tiap kejadian · klik untuk buka di Manual Replay</small></summary>
      <div class="scroll" style="max-height:360px"><table class="tbl"><tr><th>Waktu (UTC)</th><th>Koin</th><th>Terisi</th><th>Hasil</th></tr>` +
      ex.map((e, i) => `<tr data-pcx="${i}" title="Buka di chart"><td>${fmtTime(e.time).slice(0, 16)}</td><td>${esc(e.symbol)}</td>
        <td>${R.filled ? "—" : e.filled ? `✅ ${pcDur(e.fill_bars, tf)}` : "❌ tidak terisi"}</td>
        <td class="${e.code === 1 ? "pos" : e.code === -1 ? "neg" : ""}">${e.code === 1 ? "TP" : e.code === -1 ? "SL" : e.filled ? "waktu habis" : "—"}${e.result != null ? ` (${sg(e.result)})` : ""}</td></tr>`).join("") + `</table></div></details></details>`;
}
{
  const tfs = ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"];
  $("pcTf").innerHTML = tfs.map((t) => `<option value="${t}">${t.toUpperCase()}</option>`).join("");
  const f = store.get("pcForm", null) || {};
  $("pcTf").value = f.tf || "15m"; $("pcSwing").value = f.swing || "kecil"; $("pcScope").value = scopeTxt(f.scope); $("pcHtf").value = f.htf || "auto"; $("pcFilled").value = f.filled ? "1" : "0";
  $("pcSym").value = f.symbol || $("symbol").value || "BTCUSDT";
  for (const k of ["entry", "sl", "tp"]) if (f[k]) $("pc" + k[0].toUpperCase() + k.slice(1)).value = f[k];
  const dirInfo = () => {
    const e = +$("pcEntry").value, s = +$("pcSl").value, t = +$("pcTp").value;
    $("pcInfo").innerHTML = !(e && s && t) ? "LONG = SL &lt; entry &lt; TP · SHORT = TP &lt; entry &lt; SL. Arah dibaca otomatis dari susunan harga."
      : t > e && e > s ? `🟢 <b>LONG</b> · RR 1:${((t - e) / (e - s)).toFixed(2)}` : t < e && e < s ? `🔴 <b>SHORT</b> · RR 1:${((e - t) / (s - e)).toFixed(2)}`
      : `<span class="neg">⚠️ Susunan salah: LONG = SL &lt; entry &lt; TP, SHORT = TP &lt; entry &lt; SL</span>`;
  };
  ["pcEntry", "pcSl", "pcTp"].forEach((id) => $(id).addEventListener("input", dirInfo)); dirInfo();
  $("pcRun").onclick = runPc;
  $("pcOut").addEventListener("click", async (e) => {
    const R = PC.res;
    if (!R) return;
    const u = e.target.closest(".pc-use");
    if (u) {
      const pick = u.dataset.i === "all" ? R.combined : R.suggestions[+u.dataset.i];
      if (u.dataset.i === "all") { $("pcEntry").value = +pick.entry.toPrecision(6); $("pcSl").value = +pick.sl.toPrecision(6); $("pcTp").value = +pick.tp.toPrecision(6); }
      else $("pc" + { entry: "Entry", sl: "Sl", tp: "Tp" }[pick.kind]).value = +pick.price.toPrecision(6);
      dirInfo(); toast("Saran dipasang ke form. Klik 🧪 Cek entry untuk menguji ulang.");
      $("pcRun").scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    const sp = pcSpec(R);
    if (e.target.id === "pcCopy") { await copyText(MSC.signal(sp.R, sp.B)); return toast("Hasil disalin 📋"); }
    if (e.target.id === "pcDl") { try { await MSC.download(sp.R, sp.B); } catch (ex) { toast("Gagal membuat gambar: " + ex.message); } return; }
    if (e.target.id === "pcReplay") return renderPc();
    if (e.target.id === "pcJournal") {
      const r = await fetch("/api/journal/manual", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ result: R }) });
      const j = await r.json();
      return toast(!r.ok ? "⚠️ " + (j.detail || r.statusText) : j.added ? "📒 Entry kamu dipantau di menu Jurnal" : "Entry ini sudah ada di jurnal");
    }
    const tr = e.target.closest("tr[data-pcx]");
    if (tr) {
      const x = R.examples[+tr.dataset.pcx];
      await openMoment(x.symbol, R.tf, x.time, [
        { price: x.entry, color: "#42a5f5", size: 2, label: `E ${pxTxt(x.entry)}` },
        { price: x.sl, color: "#ef5350", dash: true, label: `SL ${pxTxt(x.sl)}` },
        { price: x.tp, color: "#26a69a", dash: true, label: `TP ${pxTxt(x.tp)}` }].concat(x.swings.map((sw) => ({ point: true, time: sw.time, price: sw.price, label: sw.label }))),
        `Pola ${(R.pattern || []).join(" › ")} di ${x.symbol} ${fmtTime(x.time).slice(0, 16)} UTC. Entry / SL / TP kamu dipasang dengan jarak ATR yang sama. ` +
        `${R.filled ? "" : x.filled ? `Limit terisi ${pcDur(x.fill_bars, R.tf)} kemudian. ` : "Limit tidak terisi. "}Hasil: ${x.code === 1 ? "TP" : x.code === -1 ? "SL" : x.filled ? "waktu habis" : "—"}. Step maju untuk melihat.`);
    }
  });
}

// ------------------------------------------------------------------ 🧱 penyusun aturan -> strategi Python
const RB = { cat: null, spec: null, saved: [], code: null };
function rbDefault() {
  return { name: "Strategi aturan saya", tf: "15m", dir: "both", mirror: true,
    long: [{ a: { ind: "ema", p: { n: 50 }, tf: "", shift: 0 }, op: ">", b: { ind: "ema", p: { n: 200 }, tf: "", shift: 0 } },
      { a: { ind: "rsi", p: { n: 14 }, tf: "", shift: 0 }, op: "cross_up", b: { num: 40 } }],
    short: [], entry: "market", limit_atr: 0.5, limit_pct: 0.2, expire_bars: 6,
    sl_mode: "atr", sl_atr: 1.5, sl_pct: 1.0, sl_swing: 10, sl_buf_atr: 0.1, rr: 2 };
}
function rbOperand(o, pre, isB) {
  const C = RB.cat, tfs = C.tfs;
  if (isB && o.num != null) {
    return `<select data-f="${pre}type"><option value="num" selected>angka</option><option value="ind">indikator</option></select>
      <input data-f="${pre}num" type="number" step="any" value="${o.num}" class="rb-num">`;
  }
  const meta = C.indicators[o.ind] || C.indicators.close;
  const opts = Object.entries(C.indicators).map(([k, v]) => `<option value="${k}" ${k === o.ind ? "selected" : ""}>${esc(v.name)}</option>`).join("");
  const ps = meta.params.map((p) => `<label class="rb-p" title="${esc(p.label)} (${p.min}–${p.max})">${esc(p.label)}<input data-f="${pre}p_${p.key}" type="number" min="${p.min}" max="${p.max}" step="${p.step}" value="${(o.p || {})[p.key] ?? p.default}"></label>`).join("");
  return `${isB ? `<select data-f="${pre}type"><option value="num">angka</option><option value="ind" selected>indikator</option></select>` : ""}
    <select data-f="${pre}ind" title="${esc(meta.help || "")}">${opts}</select>${ps}
    <label class="rb-p" title="TF indikator (kosong = TF strategi). Boleh lebih besar, mis. tren 4H untuk entry 15M">TF<select data-f="${pre}tf"><option value="">sama</option>${tfs.map((t) => `<option value="${t}" ${o.tf === t ? "selected" : ""}>${t.toUpperCase()}</option>`).join("")}</select></label>
    <label class="rb-p" title="0 = candle terakhir yang close, 1 = satu candle sebelumnya, dst.">candle lalu<input data-f="${pre}shift" type="number" min="0" max="500" value="${o.shift || 0}"></label>`;
}
function rbCond(cd, side, i) {
  const ops = Object.entries(RB.cat.ops).map(([k, v]) => `<option value="${k}" ${k === cd.op ? "selected" : ""}>${esc(v)}</option>`).join("");
  const kOp = cd.op === "rising" || cd.op === "falling";
  return `<div class="rb-cond" data-side="${side}" data-i="${i}"><span class="rb-no">${i + 1}</span>
    <div class="rb-a">${rbOperand(cd.a, "a_", false)}</div>
    <select data-f="op" class="rb-op">${ops}</select>
    <div class="rb-b">${kOp ? `<label class="rb-p">k candle<input data-f="k" type="number" min="1" max="200" value="${cd.k || 3}"></label>` : rbOperand(cd.b || { num: 0 }, "b_", true)}</div>
    <button type="button" class="mini rb-del" title="Hapus kondisi">✖</button></div>`;
}
function rbRender() {
  const s = RB.spec, C = RB.cat;
  const sideBlock = (side) => `<h4>${side === "long" ? "🟢 LONG" : "🔴 SHORT"} kalau SEMUA kondisi benar</h4>
    <div class="rb-list">${(s[side] || []).map((cd, i) => rbCond(cd, side, i)).join("")}</div>
    <button type="button" class="mini rb-add" data-side="${side}">+ Tambah kondisi</button>`;
  $("rbPanel").innerHTML = `<h3>🧱 Penyusun aturan <small class="hint">susun kondisi → program menulis strategi Python-nya (tanpa AI, pasti) → muncul di daftar strategi</small>
      <button type="button" class="mini" id="rbClose" style="float:right">✖ Tutup</button></h3>
    <div class="rb-row"><label>Nama<input id="rbName" value="${esc(s.name)}" maxlength="60"></label>
      <label>TF strategi<select id="rbTf">${C.tfs.map((t) => `<option value="${t}" ${t === s.tf ? "selected" : ""}>${t.toUpperCase()}</option>`).join("")}</select></label>
      <label>Arah<select id="rbDir"><option value="both" ${s.dir === "both" ? "selected" : ""}>LONG &amp; SHORT</option><option value="long" ${s.dir === "long" ? "selected" : ""}>LONG saja</option><option value="short" ${s.dir === "short" ? "selected" : ""}>SHORT saja</option></select></label>
      <label class="it-check"><input type="checkbox" id="rbMirror" ${s.mirror ? "checked" : ""}> SHORT = cermin LONG otomatis</label></div>
    ${s.dir !== "short" || s.mirror ? sideBlock("long") : ""}
    ${s.dir !== "long" && !s.mirror ? sideBlock("short") : ""}
    ${s.dir !== "long" && s.mirror ? `<p class="hint" id="rbMirrorTxt">🔴 SHORT = cermin LONG (RSI 30 → 70, memotong ke atas → ke bawah, Bollinger atas ↔ bawah; ADX / ATR / volume tidak dibalik). Klik 👁 Lihat Python untuk melihat hasilnya.</p>` : ""}
    <h4>⚙️ Entry · SL · TP</h4>
    <div class="rb-row">
      <label>Entry<select id="rbEntry">${[["market", "Market (candle berikutnya)"], ["limit_atr", "Limit X × ATR lebih bagus"], ["limit_pct", "Limit X % lebih bagus"], ["limit_close", "Limit di close candle sinyal"]].map(([k, v]) => `<option value="${k}" ${k === s.entry ? "selected" : ""}>${v}</option>`).join("")}</select></label>
      ${s.entry === "limit_atr" ? `<label>× ATR<input id="rbLimAtr" type="number" min="0.01" max="20" step="0.05" value="${s.limit_atr}"></label>` : ""}
      ${s.entry === "limit_pct" ? `<label>%<input id="rbLimPct" type="number" min="0.01" max="20" step="0.05" value="${s.limit_pct}"></label>` : ""}
      ${s.entry !== "market" ? `<label title="Limit batal kalau tidak tersentuh dalam N candle">Berlaku (candle)<input id="rbExp" type="number" min="1" max="500" value="${s.expire_bars}"></label>` : ""}
      <label>SL<select id="rbSl">${[["atr", "X × ATR dari entry"], ["pct", "X % dari entry"], ["swing", "Di balik swing N candle"]].map(([k, v]) => `<option value="${k}" ${k === s.sl_mode ? "selected" : ""}>${v}</option>`).join("")}</select></label>
      ${s.sl_mode === "atr" ? `<label>× ATR<input id="rbSlAtr" type="number" min="0.1" max="20" step="0.1" value="${s.sl_atr}"></label>` : ""}
      ${s.sl_mode === "pct" ? `<label>%<input id="rbSlPct" type="number" min="0.05" max="50" step="0.05" value="${s.sl_pct}"></label>` : ""}
      ${s.sl_mode === "swing" ? `<label>N candle<input id="rbSlSwing" type="number" min="2" max="500" value="${s.sl_swing}"></label><label>Buffer (× ATR)<input id="rbSlBuf" type="number" min="0" max="5" step="0.05" value="${s.sl_buf_atr}"></label>` : ""}
      <label>TP = RR 1:<input id="rbRr" type="number" min="0.2" max="20" step="0.1" value="${s.rr}"></label></div>
    <div class="rb-row"><button type="button" id="rbPreview">👁 Lihat Python</button><button type="button" class="primary" id="rbSave">💾 Simpan &amp; pakai di Auto Backtest</button>
      <button type="button" id="rbNew">🆕 Aturan baru</button><span id="rbMsg" class="hint"></span></div>
    <div id="rbCode"></div>
    <details class="savedlist" ${RB.saved.length ? "open" : ""}><summary><b>💾 Aturan tersimpan (${RB.saved.length})</b></summary>
      ${RB.saved.length ? `<table class="tbl">${RB.saved.map((x, i) => `<tr><td><b>${esc(x.spec.name)}</b> <small class="hint">${esc(x.spec.tf.toUpperCase())} · ${esc(x.class)}</small><br><small>🟢 ${esc(x.summary.long.join(" · ") || "—")}</small></td>
        <td><button type="button" class="mini rb-edit" data-i="${i}">✏️ Edit</button> <button type="button" class="mini rb-use" data-i="${i}">▶ Pakai</button> <button type="button" class="mini rb-rm" data-i="${i}">🗑️</button></td></tr>`).join("")}</table>` : '<p class="hint">Belum ada.</p>'}</details>`;
}
function rbCollect() {
  const s = RB.spec, v = (id) => ($(id) ? $(id).value : null), n = (id, d) => ($(id) ? +$(id).value : d);
  s.name = v("rbName") ?? s.name; s.tf = v("rbTf") ?? s.tf; s.dir = v("rbDir") ?? s.dir; s.mirror = $("rbMirror") ? $("rbMirror").checked : s.mirror;
  s.entry = v("rbEntry") ?? s.entry; s.limit_atr = n("rbLimAtr", s.limit_atr); s.limit_pct = n("rbLimPct", s.limit_pct); s.expire_bars = n("rbExp", s.expire_bars);
  s.sl_mode = v("rbSl") ?? s.sl_mode; s.sl_atr = n("rbSlAtr", s.sl_atr); s.sl_pct = n("rbSlPct", s.sl_pct); s.sl_swing = n("rbSlSwing", s.sl_swing);
  s.sl_buf_atr = n("rbSlBuf", s.sl_buf_atr); s.rr = n("rbRr", s.rr);
  for (const side of ["long", "short"]) {
    const rows = [...document.querySelectorAll(`#rbPanel .rb-cond[data-side="${side}"]`)];
    if (!rows.length) continue;
    s[side] = rows.map((row) => {
      const g = (f) => row.querySelector(`[data-f="${f}"]`);
      const opnd = (pre) => {
        if (pre === "b_" && g("b_type") && g("b_type").value === "num") return { num: +(g("b_num") ? g("b_num").value : 0) };
        const key = g(pre + "ind") ? g(pre + "ind").value : "close";
        const p = {};
        (RB.cat.indicators[key] || { params: [] }).params.forEach((q) => { const el = g(`${pre}p_${q.key}`); p[q.key] = el && el.value !== "" ? +el.value : q.default; });
        return { ind: key, p, tf: g(pre + "tf") ? g(pre + "tf").value : "", shift: g(pre + "shift") ? +g(pre + "shift").value || 0 : 0 };
      };
      const op = g("op").value, cd = { a: opnd("a_"), op };
      if (op === "rising" || op === "falling") cd.k = g("k") ? +g("k").value || 3 : 3;
      else cd.b = g("b_type") ? opnd("b_") : { num: 0 };
      return cd;
    });
  }
}
async function rbPost(url, body) {
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const j = await r.json();
  if (!r.ok) throw new Error(j.detail || r.statusText);
  return j;
}
async function rbOpen() {
  if (!RB.cat) RB.cat = await (await fetch("/api/rules/catalog")).json();
  RB.saved = (await (await fetch("/api/rules")).json()).saved;
  if (!RB.spec) RB.spec = store.get("rbDraft", null) || rbDefault();
  $("rbPanel").classList.remove("hidden");
  rbRender();
  $("rbPanel").scrollIntoView({ behavior: "smooth", block: "start" });
}
async function rbSelectStrategy(cls) {
  await loadStrategies();
  if ([...$("btStrategy").options].some((o) => o.value === cls)) { $("btStrategy").value = cls; $("btStrategy").dispatchEvent(new Event("change")); }
}
{
  $("rbOpen").onclick = rbOpen;
  $("rbPanel").addEventListener("change", (e) => {
    rbCollect();
    const f = e.target.dataset.f || "";
    // ganti indikator / jenis operand / operator / arah / entry / SL -> susun ulang tampilan (setting ikut berubah)
    if (/(^a_ind$|^b_ind$|^b_type$|^op$)/.test(f) || ["rbDir", "rbMirror", "rbEntry", "rbSl", "rbTf"].includes(e.target.id)) {
      if (f === "b_type") {
        const row = e.target.closest(".rb-cond"), cd = RB.spec[row.dataset.side][+row.dataset.i];
        cd.b = e.target.value === "num" ? { num: 0 } : { ind: "ema", p: { n: 50 }, tf: "", shift: 0 };
      }
      if (f === "op") {
        const row = e.target.closest(".rb-cond"), cd = RB.spec[row.dataset.side][+row.dataset.i];
        if ((cd.op === "rising" || cd.op === "falling") && !cd.k) cd.k = 3;
        if (!(cd.op === "rising" || cd.op === "falling") && !cd.b) cd.b = { num: 0 };
      }
      if (e.target.id === "rbMirror" && !RB.spec.mirror && !(RB.spec.short || []).length) RB.spec.short = JSON.parse(JSON.stringify(RB.spec.long));
      rbRender();
    }
    store.set("rbDraft", RB.spec);
  });
  $("rbPanel").addEventListener("input", () => { rbCollect(); store.set("rbDraft", RB.spec); });
  $("rbPanel").addEventListener("click", async (e) => {
    const t = e.target;
    if (t.id === "rbClose") { $("rbPanel").classList.add("hidden"); return; }
    if (t.classList.contains("rb-add")) {
      rbCollect();
      (RB.spec[t.dataset.side] = RB.spec[t.dataset.side] || []).push({ a: { ind: "close", p: {}, tf: "", shift: 0 }, op: ">", b: { ind: "ema", p: { n: 20 }, tf: "", shift: 0 } });
      return rbRender();
    }
    if (t.classList.contains("rb-del")) {
      rbCollect();
      const row = t.closest(".rb-cond");
      RB.spec[row.dataset.side].splice(+row.dataset.i, 1);
      return rbRender();
    }
    if (t.id === "rbNew") { RB.spec = rbDefault(); return rbRender(); }
    if (t.id === "rbPreview" || t.id === "rbSave") {
      rbCollect();
      try {
        const j = await rbPost(t.id === "rbSave" ? "/api/rules/save" : "/api/rules/preview", { spec: RB.spec });
        const d = j.describe || { long: (j.spec.long || []).map(() => ""), short: [] };
        $("rbCode").innerHTML = `${j.describe ? `<div class="rb-desc">${["long", "short"].filter((k) => j.describe[k].length && (j.spec.dir === "both" || j.spec.dir === k)).map((k) => `<p><b>${k === "long" ? "🟢 LONG" : "🔴 SHORT"}</b>: ${j.describe[k].map(esc).join(" <b>DAN</b> ")}</p>`).join("")}</div>` : ""}
          <details ${t.id === "rbPreview" ? "open" : ""}><summary><b>🐍 Python ${esc(j.class)}</b> <small class="hint">${t.id === "rbSave" ? `tersimpan: strategies/${esc(j.slug)}.py` : "belum disimpan"}</small></summary><pre class="rb-pre">${esc(j.code)}</pre></details>`;
        if (t.id === "rbSave") {
          RB.saved = (await (await fetch("/api/rules")).json()).saved;
          await rbSelectStrategy(j.class);
          const keep = $("rbCode").innerHTML; rbRender(); $("rbCode").innerHTML = keep;
          $("rbMsg").textContent = `✅ Tersimpan sebagai ${j.class} — sudah dipilih di daftar strategi, tinggal klik Jalankan Backtest.`;
        } else $("rbMsg").textContent = "";
      } catch (ex) { $("rbMsg").innerHTML = `<span class="neg">⚠️ ${esc(ex.message)}</span>`; }
      return;
    }
    const i = t.dataset.i != null ? +t.dataset.i : null;
    if (t.classList.contains("rb-edit")) { RB.spec = JSON.parse(JSON.stringify(RB.saved[i].spec)); rbRender(); $("rbMsg").textContent = "Mengedit aturan tersimpan — Simpan lagi untuk menimpa."; return; }
    if (t.classList.contains("rb-use")) { await rbSelectStrategy(RB.saved[i].class); return toast(`${RB.saved[i].class} dipilih — klik Jalankan Backtest`); }
    if (t.classList.contains("rb-rm")) {
      if (!confirm(`Hapus aturan "${RB.saved[i].spec.name}" (file Python-nya ikut terhapus)?`)) return;
      await rbPost("/api/rules/delete", { slug: RB.saved[i].slug });
      RB.saved = (await (await fetch("/api/rules")).json()).saved; await loadStrategies(); rbRender();
    }
  });
}

// ------------------------------------------------------------------ 📒 jurnal sinyal (forward test)
const JNL = { res: null, evOpen: {}, evOpt: { tf: "", min_n: 20, exact: 0 } };
async function jnLoad() {
  try {
    JNL.res = await (await fetch("/api/journal?version=" + encodeURIComponent(($("jnVer") && $("jnVer").value) || ""))).json();
    renderJournal();
  } catch (ex) { $("jnStatus").textContent = "⚠️ " + ex.message; }
}
function renderJournal() {
  const J = JNL.res;
  if (!J) return;
  $("jnAuto").checked = !!J.auto;
  {                                                                // pilihan versi (sinyal dicatat bersama versi aplikasi sejak v4.11)
    const vn = (v) => (v === "lama" ? "versi lama, tidak bisa diperkirakan" : v.startsWith("lama:") ? `≤ v${v.slice(5)} (perkiraan, versi lama)` : `v${v}`);
    const V = J.versions || [], nOld = V.filter((x) => x.v.startsWith("lama")).reduce((a, x) => a + x.n, 0);
    $("jnVer").innerHTML = `<option value="">Semua versi</option>` + V.map((x) => `<option value="${esc(x.v)}" ${J.version === x.v ? "selected" : ""}>${esc(vn(x.v))} · ${x.n} sinyal</option>`).join("") +
      (nOld ? `<option value="lama" ${J.version === "lama" ? "selected" : ""}>semua versi lama (sebelum v4.11) · ${nOld} sinyal</option>` : "");
  }
  const pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), sg = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(2)}R`);
  $("jnStatus").innerHTML = `${J.signals.length} sinyal tercatat · diperbarui ${J.last_update ? new Date(J.last_update).toLocaleTimeString() : "belum"}` +
    (J.errors && J.errors.length ? ` · <span class="neg">⚠️ ${J.errors.slice(-2).map(esc).join(" · ")}</span>` : "");
  const cards = Object.entries(J.summary).filter(([k]) => k !== "all" || Object.keys(J.summary).length > 2).map(([k, S]) => {
    const enough = S.done >= 20, good = S.r_per_signal != null && S.r_per_signal > 0 && (S.bt_exp_sig == null || S.r_per_signal >= 0.5 * S.bt_exp_sig);
    const verdict = !enough ? `<span class="hint">⏳ belum cukup data (${S.done}/20 sinyal selesai)</span>`
      : good ? '<span class="badge pass">✅ sesuai harapan backtest</span>' : '<span class="badge fail">⚠️ di bawah harapan backtest</span>';
    return `<div class="card evalcard jn-card"><h4>${esc(S.name)} ${verdict}</h4>
      <div class="jn-grid">
        <div><small>Sinyal</small><b>${S.n}</b><i>${S.open} terbuka</i></div>
        <div><small>Terisi live</small><b>${pc(S.fill_pct)}</b><i>backtest ${pc(S.bt_fill)}</i></div>
        <div><small>WR live</small><b>${pc(S.wr)}</b><i>backtest ${pc(S.bt_wr)} · ${S.done} selesai</i>
          <i><span class="pos">✅ ${S.wins || 0} menang (TP)</span> · <span class="neg">❌ ${S.losses || 0} kalah (SL)</span>${S.timeouts ? ` · ⏱ ${S.timeouts} waktu habis` : ""}</i></div>
        <div><small>R / sinyal live</small><b class="${(S.r_per_signal || 0) >= 0 ? "pos" : "neg"}">${sg(S.r_per_signal)}</b><i>janji backtest ${sg(S.bt_exp_sig)}</i></div>
        <div><small>Total</small><b class="${S.sum_r >= 0 ? "pos" : "neg"}">${sg(S.sum_r)}</b><i>😓 ${S.max_loss_streak}× kalah beruntun · DD −${(S.max_dd || 0).toFixed(1)}R</i></div>
      </div>
      ${S.done ? `<details class="jn-ev" data-src="${esc(k)}" ${JNL.evOpen[k] ? "open" : ""}><summary><b>🔍 Evaluasi</b> <small class="hint">kenapa hasil live beda dengan backtest · pecahan hasil · analisa SL · koin · jam &amp; hari MULAI scan · saran</small></summary><div class="jn-ev-body"><p class="hint">Memuat…</p></div></details>` : ""}</div>`;
  }).join("");
  const st = (x) => x.status === "TP" ? '<span class="badge pass">✅ TP</span>' : x.status === "SL" ? '<span class="badge fail">❌ SL</span>'
    : x.status === "terisi" ? '<span class="badge">🔵 berjalan</span>' : x.status === "menunggu" ? '<span class="badge">⏳ menunggu</span>' : `<span class="hint">${esc(x.status)}</span>`;
  const row = (x) => `<tr><td>${fmtTime(x.created).slice(0, 16)}</td><td>${esc((J.summary[x.source] || {}).name || x.source)}</td>
    <td><b>${esc(x.symbol)}</b> <a class="ext" target="_blank" rel="noopener" href="https://www.tradingview.com/chart/?symbol=BINANCE:${esc(x.symbol)}.P">↗</a></td><td>${esc(x.tf.toUpperCase())}</td>
    <td class="${x.dir === 0 ? "pos" : "neg"}">${x.dir === 0 ? "▲ BUY" : "▼ SELL"} ${x.kind === "market" ? "MARKET" : "LIMIT"} <small>1:${x.rr}</small></td><td>${jnTrend(x) || '<span class="hint">—</span>'}</td>
    <td class="num">${pxTxt(x.entry)}</td><td class="num neg">${pxTxt(x.sl)}</td><td class="num pos">${pxTxt(x.tp)}</td><td>${st(x)}</td>
    <td class="num ${(x.result_r ?? x.open_r ?? 0) >= 0 ? "pos" : "neg"}">${x.result_r != null ? sg(x.result_r) : x.open_r != null ? `${sg(x.open_r)} <small>berjalan</small>` : "—"}</td>
    <td><small>${x.app_version ? "v" + esc(x.app_version) : x.app_version_est ? `<span class="hint" title="Sinyal dicatat sebelum jurnal menyimpan versi (sebelum v4.11). Versi paling baru yang mungkin dipakai saat itu = versi terakhir yang sudah dirilis; bisa juga versi yang lebih lama.">≤ v${esc(x.app_version_est)} (perkiraan)</span>` : '<span class="hint">lama</span>'}</small></td><td><small class="hint">${esc(x.note || "")}</small></td><td><button class="mini jn-del" data-id="${esc(x.id)}" title="Hapus dari jurnal">🗑️</button></td></tr>`;
  const head = `<tr><th>Sinyal (UTC)</th><th>Sumber</th><th>Koin</th><th>TF</th><th>Arah</th><th title="Tren yang dipakai sinyal ini (TF + Bullish / Bearish / Sideway); searah = searah posisi">Tren</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP</th><th>Status</th><th class="num">Hasil</th><th title="Versi aplikasi yang membuat sinyal ini">Versi</th><th>Catatan</th><th></th></tr>`;
  const open = J.signals.filter((x) => x.status === "menunggu" || x.status === "terisi"), done = J.signals.filter((x) => !(x.status === "menunggu" || x.status === "terisi"));
  $("jnOut").innerHTML = (cards || `<div class="card evalcard msc-empty"><h3>📒 Jurnal masih kosong</h3><p>Jalankan 🔎 Screener Market Structure / 🎯 Cari setup Whale — setiap sinyal ✅ layak otomatis tercatat di sini dan dipantau sampai kena TP / SL.</p></div>`) +
    (open.length ? `<div class="card evalcard"><h4>🔵 Terbuka (${open.length})</h4><div class="scroll"><table class="tbl">${head}${open.map(row).join("")}</table></div></div>` : "") +
    (done.length ? `<div class="card evalcard"><h4>📜 Riwayat (${done.length})</h4><div class="scroll" style="max-height:520px"><table class="tbl">${head}${done.map(row).join("")}</table></div></div>` : "");
  document.querySelectorAll("#jnOut details.jn-ev").forEach((dt) => {
    dt.addEventListener("toggle", () => { JNL.evOpen[dt.dataset.src] = dt.open; if (dt.open) jnEval(dt); });
    if (dt.open) jnEval(dt);
  });
}
// 🔍 Evaluasi 1 sumber sinyal (trade selesai): pecahan hasil, analisa SL, koin, jam & hari MULAI scan (WIB), saran otomatis
const jnR = (v) => (v == null ? "—" : `${v >= 0 ? "+" : "−"}${Math.abs(v).toFixed(2).replace(".", ",")}R`);
const jnPc = (v) => (v == null ? "—" : `${Math.round(v)}%`);
const jnBadge = (b, n, minN) => (n < minN ? '<span class="hint">sedikit</span>' : b === "ok" ? '<span class="badge pass">✅</span>' : b === "mid" ? '<span class="badge jn-mid">⚠️</span>' : '<span class="badge fail">❌</span>');
async function jnEval(dt) {
  const body = dt.querySelector(".jn-ev-body"), src = dt.dataset.src, O = JNL.evOpt;
  body.innerHTML = '<p class="hint">Menghitung evaluasi…</p>';
  let E;
  try {
    const q = new URLSearchParams({ source: src, version: ($("jnVer") && $("jnVer").value) || "", tf: O.tf, min_n: O.min_n, exact: O.exact });
    const r = await fetch(`/api/journal/eval?${q}`); E = await r.json(); if (!r.ok) throw new Error(E.detail || r.statusText);
  } catch (ex) { body.innerHTML = `<p class="neg">⚠️ ${esc(ex.message)}</p>`; return; }
  const minN = E.min_n;
  const ctl = `<div class="jn-ev-ctl"><small class="hint">Lihat:</small>
      <select data-evopt="tf"><option value="">Semua TF</option>${(E.tfs || []).map((t) => `<option value="${esc(t)}" ${O.tf === t ? "selected" : ""}>${esc(t.toUpperCase())}</option>`).join("")}</select>
      <select data-evopt="min_n">${[5, 10, 20, 30, 50].map((v) => `<option value="${v}" ${+O.min_n === v ? "selected" : ""}>min. ${v} trade per kelompok</option>`).join("")}</select>
      <label class="it-check"><input type="checkbox" data-evopt="exact" ${O.exact ? "checked" : ""}> hanya sinyal dengan waktu scan pasti</label>
      <small class="hint">versi: ikut pilihan Versi di atas</small></div>`;
  if (!E.n_done) { body.innerHTML = ctl + '<p class="hint">Belum ada trade yang selesai untuk dievaluasi.</p>'; return; }
  const row = (r) => `<tr><td>${esc(r.label)}${r.sub ? ` <small class="hint">(${esc(r.sub)})</small>` : ""}</td><td class="num">${r.n}</td><td class="num">${jnPc(r.wr)}</td><td class="num">${jnPc(r.bt_wr)}</td>
      <td class="num ${r.r >= 0 ? "pos" : "neg"}">${jnR(r.r)}</td><td>${jnBadge(r.badge, r.n, minN)}</td></tr>`;
  const groups = (E.groups || []).map((g) => `<tr><td colspan="6" class="hint jn-ev-sec">${esc(g.title)}</td></tr>` + g.rows.map(row).join("")).join("");
  const SL = E.sl, mx = SL ? Math.max(1, ...SL.hist.map((h) => h.n)) : 1;
  const bar = (v, col) => `<span class="jn-bar" style="width:${Math.max(2, Math.round(v * 1.2))}px;background:${col}"></span>`;
  const slBox = SL ? `<table class="tbl">
      <tr><td>Sempat jalan ≥ +1R ke arah TP lalu berbalik kena SL</td><td class="num"><b class="warn">${jnPc(SL.mfe1)}</b></td><td>${bar(SL.mfe1, "var(--warn)")}</td></tr>
      <tr><td>Kena SL lalu harga <b>sampai TP</b> dalam batas waktu (SL terlalu sempit)</td><td class="num"><b class="warn">${jnPc(SL.tp_after)}</b></td><td>${bar(SL.tp_after, "var(--warn)")}</td></tr>
      <tr><td>Langsung kena SL (≤ 4 candle, tidak pernah +0,5R)</td><td class="num"><b class="neg">${jnPc(SL.quick)}</b></td><td>${bar(SL.quick, "var(--down)")}</td></tr>
      <tr><td>Median waktu sampai SL</td><td class="num"><b>${SL.median_h.toFixed(1).replace(".", ",")} jam</b></td><td></td></tr></table>
    <h5>Seberapa jauh harga sempat jalan ke arah TP sebelum kena SL</h5>
    <table class="tbl">${SL.hist.map((h, i) => `<tr><td>${esc(h.label)}</td><td class="num">${h.n}</td><td><span class="jn-bar" style="width:${Math.round(110 * h.n / mx)}px;background:${i === 0 ? "var(--down)" : i === 1 ? "var(--muted)" : "var(--warn)"}"></span></td></tr>`).join("")}</table>
    ${SL.be.n ? `<p class="hint">Kalau SL dipindah ke entry setelah +1R: ${SL.be.changed} trade SL berubah jadi 0R → perkiraan <b class="${(SL.be.r_be || 0) >= 0 ? "pos" : "neg"}">${jnR(SL.be.r_be)}/trade</b> (sekarang ${jnR(SL.be.r_now)}, dihitung ulang dari candle asli ${SL.be.n} trade).</p>` : ""}`
    : `<p class="hint">Analisa SL butuh candle sesudah tiap trade — klik 🔄 Perbarui sekarang (diambil sekali lalu disimpan).${E.n_need_path ? ` Belum dianalisa: ${E.n_need_path} trade.` : ""}</p>`;
  const C = E.coins || { worst: [], best: [] }, nC = Math.max(C.worst.length, C.best.length);
  const coinRow = (c) => (c ? `<td>${esc(c.sym)} <a class="ext" target="_blank" rel="noopener" href="https://www.tradingview.com/chart/?symbol=BINANCE:${esc(c.sym)}.P">↗</a></td><td class="num">${c.n}</td><td class="num ${c.sum >= 0 ? "pos" : "neg"}">${jnR(c.sum).replace("R", "R")}</td>` : "<td></td><td></td><td></td>");
  const coins = nC ? `<h5>🪙 Koin <small class="hint">min. 5 trade · total R</small></h5><div class="scroll" style="max-height:none"><table class="tbl"><tr><th>Paling rugi</th><th class="num">Trade</th><th class="num">Total</th><th>Paling untung</th><th class="num">Trade</th><th class="num">Total</th></tr>
      ${Array.from({ length: nC }, (_, i) => `<tr>${coinRow(C.worst[i])}${coinRow(C.best[i])}</tr>`).join("")}</table></div>` : "";
  const S = E.scan || {}, okR = (r) => r.n >= minN && (r.scans || 0) >= 5,
    best = (L) => (L && L.filter(okR).length ? L.filter(okR).reduce((a, b) => (b.r > a.r ? b : a)) : null);
  const bB = best(S.blocks), bD = best(S.days);
  const fewScan = (r) => (r.scans || 0) < 5;
  const tRow = (r, b) => `<tr><td>${b === r ? "<b>" : ""}${esc(r.label)}${r.sub ? ` <small class="hint">(${esc(r.sub)})</small>` : ""}${b === r ? "</b>" : ""}</td><td class="num">${r.n}</td>
      <td class="num ${fewScan(r) ? "warn" : ""}" title="Jumlah scan berbeda yang menghasilkan trade ini">${r.scans || 0}</td><td class="num">${jnPc(r.wr)}</td>
      <td class="num ${r.r >= 0 ? "pos" : "neg"}">${b === r ? "<b>" : ""}${jnR(r.r)}${b === r ? "</b>" : ""}</td><td>${fewScan(r) ? '<span class="hint" title="Dari kurang dari 5 scan: hasilnya mencerminkan kondisi market saat scan itu, bukan jam / hari scan">sedikit scan</span>' : b === r && r.r > 0 ? '<span class="badge pass">✅ terbaik</span>' : jnBadge(r.badge, r.n, minN)}</td></tr>`;
  const heat = (S.heat || []).map((rowH, di) => `<tr><th>${esc(S.day_names[di].slice(0, 3))}</th>${rowH.map((c) => {
      if (!c.n) return '<td class="jn-h0"></td>';
      if (c.n < 3) return `<td class="jn-h0">${c.n}</td>`;
      const a = Math.min(1, Math.abs(c.r) / 0.8), col = c.r >= 0 ? `rgba(38,166,154,${(0.15 + 0.6 * a).toFixed(2)})` : `rgba(239,83,80,${(0.15 + 0.6 * a).toFixed(2)})`;
      return `<td style="background:${col}" title="${c.n} trade dari ${c.scans} scan">${jnR(c.r).replace(",00", "")}<br><small>${c.n} · ${c.scans} scan</small></td>`; }).join("")}</tr>`).join("");
  const other = [S.delay_median_h != null ? `<tr><td>Jeda mulai scan → entry terisi (median)</td><td class="num"><b>${S.delay_median_h.toFixed(1).replace(".", ",")} jam</b></td></tr>` : "",
    S.stale ? `<tr><td>Terisi &gt; 12 jam setelah scan</td><td class="num">${S.stale.n} trade · <span class="${S.stale.r >= 0 ? "pos" : "neg"}">${jnR(S.stale.r)}</span></td></tr>` : "",
    S.batch_big ? `<tr><td>Scan yang menghasilkan ≥ 5 sinyal sekaligus</td><td class="num">${S.batch_big.n} trade · <span class="${S.batch_big.r >= 0 ? "pos" : "neg"}">${jnR(S.batch_big.r)}</span></td></tr>` : "",
    S.batch_small ? `<tr><td>Scan yang menghasilkan &lt; 5 sinyal</td><td class="num">${S.batch_small.n} trade · <span class="${S.batch_small.r >= 0 ? "pos" : "neg"}">${jnR(S.batch_small.r)}</span></td></tr>` : ""].join("");
  const scan = S.n ? `<div class="jn-ev-box"><h5>⏰ Waktu &amp; hari MULAI scan <small class="hint">dihitung dari saat tombol scan ditekan (WIB = UTC+7) · ${E.n_exact} trade waktu pasti · ${E.n_est} perkiraan (sinyal lama: dikelompokkan per scan)${E.exact_only ? " · perkiraan disembunyikan" : ""} · dari <b>${S.n_scans || 0} scan</b></small></h5>
      ${(S.n_scans || 0) < 20 ? `<p class="hint warn">⚠️ Baru ${S.n_scans || 0} scan. Banyak trade dari scan yang sama mencerminkan kondisi market saat scan itu, bukan jam / hari scan. Jam / hari dengan &lt; 5 scan ditandai "sedikit scan" dan tidak dipakai untuk saran.</p>` : ""}
      <div class="jn-ev-grid"><div><table class="tbl"><tr><th>Jam mulai scan (WIB)</th><th class="num">Trade</th><th class="num" title="Jumlah scan berbeda">Scan</th><th class="num">WR</th><th class="num">R/trade</th><th></th></tr>${(S.blocks || []).map((r) => tRow(r, bB)).join("")}</table>
        <table class="tbl" style="margin-top:8px"><tr><th>Hari mulai scan</th><th class="num">Trade</th><th class="num" title="Jumlah scan berbeda">Scan</th><th class="num">WR</th><th class="num">R/trade</th><th></th></tr>${(S.days || []).map((r) => tRow(r, bD)).join("")}</table></div>
      <div><div class="scroll" style="max-height:none"><table class="jn-heat"><tr><th>Hari \\ jam WIB</th>${(S.block_names || []).map((b) => `<th>${esc(b)}</th>`).join("")}</tr>${heat}</table>
        </div><p class="hint">Peta hari × jam mulai scan: hijau = untung, merah = rugi, angka kecil = jumlah trade · jumlah scan, kotak abu = &lt; 3 trade (bisa kebetulan).</p>
        ${other ? `<table class="tbl"><tr><th>Lain-lain dari waktu scan</th><th></th></tr>${other}</table>` : ""}</div></div></div>`
    : '<p class="hint">Belum ada trade dengan waktu scan.</p>';
  body.innerHTML = ctl + `<p class="hint">${E.n_done} trade selesai · dihitung ulang setiap dibuka · hanya info, tidak ada setelan yang diubah</p>
    ${E.summary ? `<div class="jn-ev-tip">💡 <b>Ringkasan:</b> ${E.summary}</div>` : ""}
    <div class="jn-ev-grid"><div class="jn-ev-box"><h5>📊 Pecahan hasil <small class="hint">live vs backtest · ✅ ≥ ½ janji backtest · ⚠️ untung tapi di bawah · ❌ rugi · "sedikit" = &lt; ${minN} trade</small></h5>
        <div class="scroll" style="max-height:none"><table class="tbl"><tr><th>Kelompok</th><th class="num">Trade</th><th class="num">WR live</th><th class="num">WR backtest</th><th class="num">R/trade</th><th></th></tr>${groups}</table></div></div>
      <div class="jn-ev-box"><h5>🛑 Analisa SL <small class="hint">${SL ? `${SL.n} trade kena SL` : ""}</small></h5>${slBox}${coins}</div></div>
    ${scan}
    <h5>💡 Saran otomatis <small class="hint">hanya dari kelompok ≥ ${minN} trade · info, kamu yang memutuskan</small></h5>
    ${E.tips && E.tips.length ? `<ol class="jn-ev-tips">${E.tips.map((t) => `<li>${t}</li>`).join("")}</ol>` : `<p class="hint">Belum ada saran: belum ada kelompok dengan ≥ ${minN} trade yang jelas berbeda. Turunkan "min. trade per kelompok" atau tunggu trade bertambah.</p>`}
    <p class="hint">Live vs backtest bisa beda karena pasar sekarang berbeda dengan masa backtest, slippage/biaya, dan setup dipilih dari banyak koin (yang terbaik di backtest sering kebetulan). Evaluasi ini menunjukkan <b>bagian mana</b> yang paling jauh dari janji backtest.</p>`;
  body.querySelectorAll("[data-evopt]").forEach((el) => el.addEventListener("change", () => {
    const k = el.dataset.evopt; O[k] = el.type === "checkbox" ? (el.checked ? 1 : 0) : el.value;
    document.querySelectorAll("#jnOut details.jn-ev[open]").forEach(jnEval);
  }));
}
// tren yang dipakai sinyal (TF + arah) — kecil di bawah harga entry; searah / melawan posisi
function jnTrend(x) {
  const T = x.trend;
  if (!T) return "";
  const name = T.dir > 0 ? "Bullish" : T.dir < 0 ? "Bearish" : "Sideway", col = T.dir > 0 ? "pos" : T.dir < 0 ? "neg" : "hint";
  const with_ = T.dir !== 0 && (T.dir > 0) === (x.dir === 0);                 // searah posisi
  return `<small class="jn-tr ${col}" title="${esc(T.txt || "")}">${esc(String(T.tf).toUpperCase())} ${with_ ? "searah " : ""}${name}</small>`;
}
async function jnUpdate() {
  $("jnUpdate").disabled = true; $("jnStatus").innerHTML = `Mengambil candle Binance untuk sinyal terbuka<span class="dots"></span>`;
  try {
    const j = await (await fetch("/api/journal/update", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).json();
    for (;;) { const st = await (await fetch(`/api/screener/job/${j.id}`)).json(); if (st.status !== "running") { if (st.status === "error") toast("⚠️ " + st.error); break; } await new Promise((ok) => setTimeout(ok, 600)); }
  } finally { $("jnUpdate").disabled = false; jnLoad(); }
}
{
  $("jnUpdate").onclick = jnUpdate;
  $("jnVer").onchange = jnLoad;
  $("jnAuto").onchange = async (e) => { await fetch("/api/journal/auto", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ on: e.target.checked }) }); toast(e.target.checked ? "Pencatatan otomatis menyala" : "Pencatatan otomatis dimatikan"); };
  $("jnClear").onclick = async () => {
    if (!confirm("Hapus SEMUA sinyal di jurnal? Tidak bisa dibatalkan.")) return;
    await fetch("/api/journal/delete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ all: true }) }); jnLoad();
  };
  $("jnOut").addEventListener("click", async (e) => {
    const b = e.target.closest(".jn-del");
    if (!b) return;
    await fetch("/api/journal/delete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids: [b.dataset.id] }) }); jnLoad();
  });
  document.querySelector('.tab[data-tab="journal"]').addEventListener("click", jnLoad);
}

// ------------------------------------------------------------------ 🧪 indikator tester
const IT = { t: "rsi", def: null, res: null, timer: null, id: null };
const IT_ROLE = {
  ema: "📈 Cukup pilih <b>TF</b> &amp; isi <b>angka EMA</b>. <b>Tes 1</b>: EMA mana yang paling sering disentuh harga lalu <b>mantul</b> searah tren. <b>Tes 2</b>: <b>EMA kedua</b> (angka kecil) dijebol = peringatan; <b>valid</b> kalau harga lanjut menembus <b>EMA pertama</b> (angka besar) dan tidak balik lagi = tren berubah.",
  rsi: "🎯 <b>Validasi LONG / SHORT</b>: mis. SHORT saat overbought. Dicek apakah harga benar turun atau malah lanjut naik.",
  stoch: "🎯 <b>Validasi LONG / SHORT</b>: %K memotong %D di zona overbought (SHORT) / oversold (LONG).",
  macd: "🎯 <b>Validasi LONG / SHORT</b>: MACD memotong garis signal.",
  force: "💪 <b>Kekuatan tren</b>: entry saat Force Index baru saja kuat searah (beli / jual bertenaga).",
  adx: "💪 <b>Kekuatan tren</b>: entry saat ADX baru saja di atas batas; arah dari +DI / −DI.",
  hyper: "🎛️ <b>Hyperopt Tester</b>: seperti hyperopt Freqtrade — angka indikator &amp; SL dicari otomatis, RR dari kamu. Bedanya langsung dicek <b>anti-overfitting</b>: hasil di 20% data terakhir yang tidak dipakai mencari, <b>walk-forward</b> (cari lalu dipakai di periode berikutnya), dan <b>kestabilan</b> angka tetangga. Angka yang cuma bagus di data lama akan kelihatan.",
  combo: "🧩 Cari <b>set angka kombinasi</b> yang paling cocok untuk TF ini, mis. EMA + Force Index atau ADX + Force Index. Kalau ada MA pasangan tanpa RSI / Stoch / MACD, entry = pullback / retest market structure.",
};
const IT_TIPS = [
  "💡 <b>WR dasar</b> = WR kalau entry di sembarang candle. Indikator yang bagus harus <b>di atas</b> WR dasar (Edge positif).",
  "💡 Angka dicari di <b>70% data awal</b>, lalu dicek di <b>30% terakhir</b>. Pilih yang ✅ konsisten, bukan cuma yang paling tinggi.",
  "💡 <b>MA utama = angka besar</b> (tren), <b>MA kedua = angka kecil</b>: tembus MA kedua = peringatan, tembus MA utama = konfirmasi.",
  "💡 Kolom angka yang <b>dikosongkan</b> dicari otomatis dari daftar angka umum.",
  "💡 Makin banyak trade, makin bisa dipercaya. Di bawah ±30 trade hasilnya bisa kebetulan.",
  "💡 Coba juga <b>TF lain</b>: angka yang cocok di 1H belum tentu cocok di 15M.",
  "💡 <b>Rata-rata R</b> lebih penting dari WR: WR 40% dengan RR 1:2 masih untung, WR 60% dengan RR 1:0.5 rugi.",
];
const IT_FIELDS = { itTf: "tf", itDir: "direction", itSl: "sl_atr", itRr: "rr", itMaxBars: "max_bars", itAtr: "atr_len", itMinTrades: "min_trades",
  itSort: "sort", itMaType: "ma_type", itMaType2: "ma_type2", itEmaMode: "ema_mode", itMain: "ema_main", itSecond: "ema_second",
  itBodyPct: "body_pct", itVol: "vol_mult", itSwing: "swing", itConfirm: "confirm_bars", itFilterLen: "filter_len",
  itRetestBars: "retest_bars", itRetestTol: "retest_tol", itHyperSl: "hyper_sl", itHyperObj: "hyper_obj", itBounce: "bounce_list", itBounceAway: "bounce_away", itHold: "hold_bars",
  itRsiLen: "rsi_len", itRsiOb: "rsi_ob", itRsiMode: "rsi_mode", itStK: "st_k", itStSmooth: "st_smooth", itStD: "st_d", itStOb: "st_ob",
  itMacdFast: "macd_fast", itMacdSlow: "macd_slow", itMacdSig: "macd_signal", itMacdMode: "macd_mode",
  itAdxLen: "adx_len", itAdxTh: "adx_th", itFiLen: "fi_len", itFiK: "fi_k" };
function itComps() { return [...document.querySelectorAll("#itComps input:checked")].map((x) => x.value); }
function itExpand(txt) {
  const out = [];
  for (const part of String(txt || "").split(/[,;]/).map((x) => x.trim()).filter(Boolean)) {
    const m = part.match(/^(-?[\d.]+)\s*-\s*([\d.]+)(?::([\d.]+))?$/);
    if (m) for (let v = +m[1]; v <= +m[2] + 1e-9 && out.length < 600; v += +m[3] || 1) out.push(Math.round(v));
    else if (isFinite(+part)) out.push(Math.round(+part));
  }
  return [...new Set(out)];
}
function itCountList(txt) {
  let n = 0;
  for (const part of String(txt || "").split(/[,;]/).map((x) => x.trim()).filter(Boolean)) {
    const m = part.match(/^(-?[\d.]+)\s*-\s*([\d.]+)(?::([\d.]+))?$/);
    n += m ? Math.max(1, Math.floor((+m[2] - +m[1]) / (+m[3] || 1) + 1e-9) + 1) : 1;
  }
  return n;
}
const IT_TF_MIN = { "1m": 1, "3m": 3, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "2h": 120, "4h": 240, "6h": 360, "8h": 480, "12h": 720, "1d": 1440 };
const IT_ADV = { itAtr: "atr_len", itBodyPct: "body_pct", itVol: "vol_mult", itSwing: "swing", itConfirm: "confirm_bars",
  itRetestBars: "retest_bars", itRetestTol: "retest_tol", itBounceAway: "bounce_away", itHold: "hold_bars" };
function itDurTxt(n) {
  const m = (IT_TF_MIN[$("itTf").value] || 60) * (+n || 0);
  if (!m) return "";
  const t = m < 60 ? `${m} menit` : m < 1440 ? `${+(m / 60).toFixed(1)} jam` : `${+(m / 1440).toFixed(1)} hari`;
  return `≈ ${t} di TF ${$("itTf").value.toUpperCase()}`;
}
function itUpdate() {
  const t = IT.t, comps = t === "combo" || t === "hyper" ? itComps() : [];
  const on = new Set();
  if (t === "ema") ["ma_pair", "ema_only"].forEach((g) => on.add(g));
  if (["rsi", "stoch", "macd"].includes(t)) { on.add(t); on.add("filter"); if ($("itTrendFilter").checked) on.add("matype"); }
  if (t === "adx" || t === "force") on.add(t);
  if (t === "combo") { on.add("combo"); comps.forEach((c) => on.add(c)); if (comps.includes("ma_pair")) on.add("matype"); }
  if (t === "hyper") on.add("combo");                                 // hyperopt: cukup centang indikator, angkanya dicari sendiri
  if (t === "hyper") on.add("hyper");
  $("itCompsNote").textContent = t === "hyper" ? "(pilih minimal 1)" : "(pilih minimal 2)";
  document.querySelectorAll("#tab-indtest .it-grp").forEach((g) => g.classList.toggle("hidden", !on.has(g.dataset.g)));
  document.querySelectorAll("#tab-indtest .it-only-pair").forEach((x) => x.classList.toggle("hidden", !(t === "ema" || comps.includes("ma_pair"))));
  $("tab-indtest").querySelector(".it-filter-len").classList.toggle("hidden", !$("itTrendFilter").checked);
  document.querySelectorAll("#tab-indtest .it-trade, #tab-indtest .it-retest-only, #tab-indtest .it-noema").forEach((x) => x.classList.toggle("hidden", t === "ema"));
  if (t === "hyper") document.querySelectorAll("#tab-indtest .it-nohyper").forEach((x) => x.classList.add("hidden"));
  $("itMaxBarsLbl").textContent = t === "ema" ? "Batas tunggu hasil pantulan (candle)" : "Lama trade maksimal (candle)";
  $("itMinLbl").textContent = t === "ema" ? "Min. kejadian" : "Min. trade";
  document.querySelectorAll("#itPick button").forEach((b) => b.classList.toggle("on", b.dataset.t === t));
  $("itRole").innerHTML = IT_ROLE[t];
  document.querySelectorAll("#tab-indtest .it-dur").forEach((x) => (x.textContent = itDurTxt($(x.dataset.for).value)));
  if (IT.def) {
    const changed = Object.entries(IT_ADV).filter(([id, k]) => String(+$(id).value) !== String(+IT.def.defaults[k])).length;
    $("itAdvNote").textContent = changed ? `${changed} angka diubah dari default` : "semua default · jarang perlu diubah";
    $("itAdvNote").classList.toggle("neg", !!changed);
  }
  const m = $("itEmaMode").value;
  $("itMainLbl").textContent = t === "ema" ? "EMA pertama (angka besar)" : (m === "find_main" || m === "find_both" ? "MA utama (tren, angka besar) — dicoba" : "MA utama (tren, angka besar) — angka kamu");
  $("itSecondLbl").textContent = t === "ema" ? "EMA kedua (angka kecil)" : (m === "find_second" || m === "find_both" ? "MA kedua (struktur, angka kecil) — dicoba" : "MA kedua (struktur, angka kecil) — angka kamu");
  // perkiraan jumlah kombinasi
  const L = (id) => itCountList($(id).value.trim() || (IT.def && IT.def.auto[IT_FIELDS[id]]) || "");
  const g = {
    ma_pair: (() => {
      const V = (id) => itExpand($(id).value.trim() || (IT.def && IT.def.auto[IT_FIELDS[id]]) || "");
      let a = V("itMain"), b = V("itSecond");
      if (m === "test" && t !== "ema") { a = a.slice(0, 1); b = b.slice(0, 1); }
      return a.reduce((n, x) => n + b.filter((y) => (t === "ema" ? x - y >= 30 : x > y)).length, 0);
    })(),
    rsi: L("itRsiLen") * L("itRsiOb"), stoch: L("itStK") * L("itStSmooth") * L("itStD") * L("itStOb"),
    macd: L("itMacdFast") * L("itMacdSlow") * L("itMacdSig"), adx: L("itAdxLen") * L("itAdxTh"), force: L("itFiLen") * L("itFiK") };
  const dims = t === "combo" || t === "hyper" ? comps.map((c) => g[c]) : [g[t === "ema" ? "ma_pair" : t]];
  if (["rsi", "stoch", "macd"].includes(t) && $("itTrendFilter").checked) dims.push(L("itFilterLen"));
  const n = t === "ema" ? L("itBounce") + g.ma_pair : dims.reduce((a, x) => a * x, 1) * (t === "hyper" ? Math.max(1, itCountList($("itHyperSl").value || "1, 1.5, 2")) : 1);
  const pairBad = (t === "ema" || comps.includes("ma_pair")) && g.ma_pair === 0;
  const max = (IT.def && IT.def.max_combos) || 3000;
  const autos = [...document.querySelectorAll("#tab-indtest .it-grp:not(.hidden) input[data-auto]")].filter((x) => !x.value.trim()).map((x) => x.dataset.auto);
  const staged = t !== "hyper" && n > max && dims.length >= 2 && Math.max(...dims) <= max;
  const keep = Math.min(6, Math.max(2, Math.floor(Math.pow(max, 1 / dims.length))));
  const nStaged = dims.reduce((a, x) => a + x, 0) + Math.pow(keep, dims.length);
  if (t === "hyper") {
    $("itCount").innerHTML = comps.length ? `🎛️ ${comps.length} indikator · angka indikator, SL &amp; lama tahan <span class="pos">dicari otomatis</span> · maks ${max.toLocaleString("id-ID")} kombinasi`
      : `<span class="neg">centang minimal 1 indikator</span>`;
    return;
  }
  $("itCount").innerHTML = (staged
    ? `± <b>${n.toLocaleString("id-ID")}</b> kombinasi — terlalu banyak untuk diuji semua, jadi <b class="pos">dicari bertahap</b> (±${nStaged.toLocaleString("id-ID")} uji): tiap indikator dicari sendiri dulu, lalu ${keep} angka terbaik tiap indikator digabung`
    : `± <b>${n.toLocaleString("id-ID")}</b> kombinasi angka akan diuji`) +
    (autos.length ? ` · <span class="pos">dicari otomatis: ${autos.join(", ")}</span>` : "") +
    (t === "hyper" && n > max ? ` · <span class="pos">diambil acak ${max.toLocaleString("id-ID")} kombinasi (seperti hyperopt)</span>` : "") + (n > max && !staged && t !== "hyper" ? ` <span class="neg">— terlalu banyak (maks ${max.toLocaleString("id-ID")}), persempit daftarnya</span>` : "") +
    (pairBad ? ` <span class="neg">— tidak ada pasangan valid: MA utama harus angka LEBIH BESAR dari MA kedua (mis. 200 &amp; 50)</span>` : "");
}
function itParams() {
  const p = { tester: IT.t, trend_filter: $("itTrendFilter").checked, components: itComps() };
  for (const [id, k] of Object.entries(IT_FIELDS)) p[k] = $(id).value;
  p.start = $("itFrom").value ? fromInput($("itFrom").value) : null;
  p.end = $("itTo").value ? fromInput($("itTo").value) : null;
  return p;
}
function itFill(p) {
  for (const [id, k] of Object.entries(IT_FIELDS)) if (p[k] != null && $(id)) $(id).value = p[k];
  $("itTrendFilter").checked = !!p.trend_filter;
  if (p.components) document.querySelectorAll("#itComps input").forEach((x) => (x.checked = p.components.includes(x.value)));
  if (p.tester) IT.t = p.tester === "ema" ? "rsi" : p.tester;            // v4.28: EMA Tester dihapus (pindah ke 📈 Moving Average Analisis)
}
const IT_UI = { state: { id: null } };
async function runIndTest() {
  const scope = $("itScope").value;
  if (scope === "one" && !S.info) return toast("Pilih simbol dulu di atas");
  const symbols = scope === "one" ? [S.info.symbol] : scope === "list" ? $("itSymbols").value.toUpperCase().split(/[\s,;]+/).filter(Boolean) : null;
  if (IT.t === "combo" && itComps().length < 2) return toast("Kombinasi: pilih minimal 2 indikator");
  const params = itParams();
  store.set("itForm", { ...params, scope, symbols: $("itSymbols").value });
  const j = await startJob("/api/indtester", { params, symbols });
  if (j) attachIndTest(j);
}
function attachIndTest(j) {
  $("itRun").disabled = true;
  $("itOut").classList.remove("hidden"); $("itLive").classList.remove("hidden"); $("itBody").innerHTML = "";
  $("itBar").style.width = "2%"; $("itPct").textContent = "0"; $("itTitle").textContent = "Menyiapkan data & menghitung hasil trade tiap candle…";
  $("itRecent").innerHTML = ""; $("itRecent").dataset.last = ""; $("itLead").innerHTML = "muncul setelah selesai"; $("itLead").classList.add("hint");
  $("itDone").textContent = "0/0"; $("itSym").textContent = "—"; $("itEta").textContent = "menghitung…"; $("itElapsed").textContent = "0 dtk";
  startTips("itTip", IT_TIPS);
  const end = () => { $("itRun").disabled = false; $("itLive").classList.add("hidden"); clearInterval(TIP_TIMERS.itTip); };
  studyPoll("indtester", j.id, Object.assign(IT_UI, {
    tick: (st) => {
      const pct = st.total ? (100 * st.done) / st.total : 0;
      $("itBar").style.width = Math.max(pct, 2) + "%"; $("itPct").textContent = Math.floor(pct);
      $("itDone").textContent = `${(st.done || 0).toLocaleString("id-ID")}/${(st.total || 0).toLocaleString("id-ID")}`;
      $("itElapsed").textContent = fmtDur(st.elapsed);
      $("itEta").textContent = st.status === "paused" ? "dijeda" : st.eta ? "±" + fmtDur(st.eta) : st.done ? "hampir…" : "menghitung…";
      const items = (st.recent || []).map((x) => x.symbol.split("|"));
      if (items[0]) $("itSym").textContent = items[0][0];
      $("itTitle").textContent = st.status === "paused" ? "⏸️ Dijeda — klik Lanjutkan untuk meneruskan dari koin yang belum selesai"
        : `Menguji semua kombinasi angka per koin · ${st.workers || 1} proses paralel` + (st.total > 1 && st.done >= st.total / 2 && st.total % 2 === 0 ? "" : "");
      const rec = items.map(([sym, lab]) => `<li><span>${lab === "selesai" ? "✅" : "⚠️"} ${esc(sym)}</span><small class="hint">${esc(lab || "")}</small></li>`).join("");
      if (rec !== $("itRecent").dataset.last) { $("itRecent").innerHTML = rec; $("itRecent").dataset.last = rec; }
    },
    done: (res) => {
      end();
      IT.res = res;
      renderIndTest();
      $("itOut").scrollIntoView({ behavior: "smooth", block: "start" });
      $("itStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${res.elapsed} dtk · 💾 tersimpan`;
    },
    error: (msg) => { end(); $("itBody").innerHTML = `<p class="neg">Gagal: ${esc(String(msg))}</p>`; },
  }));
}
function itVerdict(r, R) {
  const be = R.breakeven, out = [];
  out.push(r.exp_r > 0 ? `✅ Rata-rata <b class="pos">${r.exp_r >= 0 ? "+" : ""}${r.exp_r.toFixed(2)} R</b> per trade (WR ${r.wr.toFixed(0)}% vs WR impas ${be.toFixed(0)}%).`
    : `❌ Rata-rata <b class="neg">${r.exp_r.toFixed(2)} R</b> per trade: masih rugi (WR ${r.wr.toFixed(0)}% di bawah WR impas ${be.toFixed(0)}%).`);
  if (r.edge != null) out.push(r.edge > 3 ? `✅ Lebih baik <b>${r.edge.toFixed(0)} poin</b> dari entry sembarang (WR dasar ${r.base_wr.toFixed(0)}%) → indikatornya membantu.`
    : r.edge >= -3 ? `⚠️ Hampir sama dengan entry sembarang (WR dasar ${r.base_wr.toFixed(0)}%) → indikatornya belum memberi keunggulan.`
    : `❌ Lebih jelek dari entry sembarang (WR dasar ${r.base_wr.toFixed(0)}%) → sinyalnya sering terbalik.`);
  if (r.struct && r.struct.n) out.push(`🧭 MA kedua: dari <b>${r.struct.n}</b> tembusan valid, <b>${r.struct.wr.toFixed(0)}%</b> benar jadi perubahan struktur` +
    (r.struct.bars_med != null ? ` (biasanya ±${r.struct.bars_med.toFixed(0)} candle kemudian)` : "") + "." +
    (r.struct.n < 10 ? ` <span class="neg">⚠️ sampel masih sedikit (&lt; 10 kejadian): pakai periode lebih panjang / lebih banyak koin, atau longgarkan syarat body &amp; volume.</span>` : ""));
  else if (r.struct) out.push("🧭 MA kedua: belum ada tembusan yang memenuhi syarat body &amp; volume di data ini.");
  if (r.sideways_pct != null) out.push(`↔️ Sideways (tidak trade) ±${r.sideways_pct.toFixed(0)}% waktu.`);
  out.push(r.consistent ? `✅ Data uji (30% terakhir): ${r.n_test} trade, WR ${r.wr_test.toFixed(0)}%, ${r.exp_test >= 0 ? "+" : ""}${r.exp_test.toFixed(2)} R → konsisten.`
    : r.n_test ? `⚠️ Data uji (30% terakhir): ${r.n_test} trade, WR ${r.wr_test == null ? "—" : r.wr_test.toFixed(0) + "%"}, ${r.exp_test == null ? "—" : (r.exp_test >= 0 ? "+" : "") + r.exp_test.toFixed(2) + " R"} → belum terbukti di data baru, bisa jadi cuma cocok di masa lalu.`
    : "⚠️ Tidak ada trade di data uji, belum bisa dibuktikan di data baru.");
  return out.map((x) => `<li>${x}</li>`).join("");
}
function itStagedHtml(R) {
  const g = R.staged;
  if (!g) return "";
  const nm = { ma_pair: "MA pasangan", ma_filter: "MA filter", rsi: "RSI", stoch: "Stochastic", macd: "MACD", adx: "ADX", force: "Force Index" };
  return `<div class="it-staged"><b>🪜 Dicari bertahap</b> — ${g.full.toLocaleString("id-ID")} kombinasi terlalu banyak untuk diuji semua.
    <b>Tahap 1:</b> tiap indikator diuji sendiri (${g.stage1.toLocaleString("id-ID")} uji). <b>Tahap 2:</b> ${g.keep} angka terbaik tiap indikator digabung (${g.stage2.toLocaleString("id-ID")} uji).
    <details><summary>Angka terbaik tiap indikator (tahap 1)</summary><ul>${Object.entries(g.picked).map(([k, v]) => `<li><b>${nm[k] || k}:</b> ${v.map(esc).join(" · ")}</li>`).join("")}</ul></details>
    <small class="hint">Pencarian bertahap cepat tapi bisa melewatkan kombinasi yang hanya bagus kalau digabung. Mau lebih teliti: isi daftar angka sendiri yang lebih sempit.</small></div>`;
}
function renderIndTest() {
  if (IT.res && IT.res.ema2) return renderEmaTest();
  if (IT.res && IT.res.hyper) return renderHyper();
  const R = IT.res, P = R.params, ema = P.tester === "ema" || (P.tester === "combo" && (P.components || []).includes("ma_pair"));
  const f2 = (v, d = 0) => (v == null ? "—" : v.toFixed(d));
  const rr = (v) => (v == null ? "—" : `<b class="${v > 0 ? "pos" : "neg"}">${v >= 0 ? "+" : ""}${v.toFixed(2)}</b>`);
  if (!R.rows.length) {
    $("itBody").innerHTML = itStagedHtml(R) + `<h3>Belum ada hasil</h3><p class="hint">${R.n_rows ? `${R.n_rows} kombinasi diuji, tapi semuanya kurang dari ${P.min_trades} trade. Turunkan Min. trade, pakai periode lebih panjang / lebih banyak koin` + (R.staged ? ", atau gabungkan 2 indikator saja (gabungan 3+ indikator jarang terpicu bersamaan)" : "") + "." : "Tidak ada sinyal sama sekali."}</p>` +
      (R.skipped.length ? `<p class="hint">⏭️ ${R.n_skipped || R.skipped.length} koin dilewati: ${R.skipped.map(esc).join("; ")}</p>` : "");
    return;
  }
  const best = R.rows[0];
  const rows = R.rows.map((r, i) => `<tr class="${r.exp_r > 0 ? "" : "dim"}"><td>${i + 1}</td><td><b>${esc(r.label)}</b></td>
    <td class="num">${r.n}<br><small>L ${r.n_long} · S ${r.n_short}</small></td><td class="num"><b>${f2(r.wr)}%</b></td><td class="num">${rr(r.exp_r)}</td>
    <td class="num">${f2(r.base_wr)}%</td><td class="num ${r.edge > 0 ? "pos" : "neg"}">${r.edge == null ? "—" : (r.edge >= 0 ? "+" : "") + r.edge.toFixed(0)}</td>
    ${ema ? `<td class="num">${r.struct && r.struct.n ? `<b>${f2(r.struct.wr)}%</b><br><small>${r.struct.n} kali${r.struct.bars_med != null ? " · ±" + f2(r.struct.bars_med) + " c" : ""}</small>` : "—"}</td>` : ""}
    <td class="num">${r.sideways_pct == null ? "—" : f2(r.sideways_pct) + "%"}</td>
    <td class="num">${r.n_test}<br><small>${r.wr_test == null ? "—" : f2(r.wr_test) + "%"} · ${r.exp_test == null ? "—" : (r.exp_test >= 0 ? "+" : "") + r.exp_test.toFixed(2) + "R"}</small></td>
    <td>${r.consistent ? '<span class="badge pass">✅ konsisten</span>' : '<span class="badge fail">⚠️ belum</span>'}</td>
    <td><button class="mini it-use" data-i="${i}">Test angka ini</button></td>
    <td><button class="mini it-ex" data-i="${i}" title="Lihat trade-nya satu per satu &amp; buka di chart">🔍 Contoh trade</button></td></tr>`).join("");
  const testerName = { ema: "EMA Tester", rsi: "RSI Tester", stoch: "Stochastic Tester", macd: "MACD Tester", adx: "ADX Tester", force: "Force Index Tester", combo: "Kombinasi" }[P.tester];
  $("itBody").innerHTML = `<h3>🧪 ${testerName} · ${P.tf.toUpperCase()} <span class="hint">${R.symbols.length} koin · ${R.candles.toLocaleString("id-ID")} candle · ${R.n_combos.toLocaleString("id-ID")} kombinasi diuji
      · SL ${P.sl_atr}×ATR · RR 1:${P.rr} · WR impas ${R.breakeven.toFixed(0)}%</span></h3>
    ${R.auto && R.auto.length ? `<p class="hint">🔎 Dicari otomatis (kolom dikosongkan): <b>${R.auto.map(esc).join(", ")}</b>.</p>` : ""}
    ${itStagedHtml(R)}
    <div class="it-best"><h4>🏆 Terbaik: ${esc(best.label)}</h4><ul>${itVerdict(best, R)}</ul></div>
    ${R.best_per && R.best_per.length ? (() => {
      const fixMain = P.ema_mode === "find_second";
      return `<h4>📌 ${fixMain ? "MA kedua terbaik untuk tiap MA utama kamu" : "MA utama terbaik untuk tiap MA kedua kamu"}</h4>
      <div class="scroll"><table class="tbl"><tr><th>${fixMain ? "MA utama kamu" : "MA kedua kamu"}</th><th>${fixMain ? "MA kedua terbaik" : "MA utama terbaik"}</th>
        <th class="num">Trade</th><th class="num">WR</th><th class="num">Rata-rata R</th><th class="num">WR struktur</th><th class="num">Data uji</th><th></th></tr>` +
      R.best_per.map((r) => { const mp = r.combo.ma_pair; return `<tr><td><b>${fixMain ? mp.main : mp.second}</b></td><td><b class="pos">${fixMain ? mp.second : mp.main}</b></td>
        <td class="num">${r.n}</td><td class="num">${f2(r.wr)}%</td><td class="num">${rr(r.exp_r)}</td>
        <td class="num">${r.struct && r.struct.n ? f2(r.struct.wr) + "% (" + r.struct.n + ")" : "—"}</td>
        <td class="num">${r.wr_test == null ? "—" : f2(r.wr_test) + "%"} · ${r.exp_test == null ? "—" : (r.exp_test >= 0 ? "+" : "") + r.exp_test.toFixed(2) + "R"}</td>
        <td>${r.consistent ? '<span class="badge pass">✅</span>' : '<span class="badge fail">⚠️</span>'}</td></tr>`; }).join("") + "</table></div>";
    })() : ""}
    ${R.too_few ? `<p class="hint">${R.too_few} kombinasi tidak ditampilkan karena trade-nya &lt; ${P.min_trades}.</p>` : ""}
    <h4>📋 Semua hasil (urut dari terbaik)</h4>
    <div class="scroll"><table class="tbl"><tr><th>#</th><th>Angka</th><th class="num">Trade</th><th class="num">WR</th><th class="num">Rata-rata R</th>
      <th class="num">WR dasar</th><th class="num">Edge</th>${ema ? '<th class="num" title="Akurasi MA kedua memberi tanda struktur berubah">WR struktur</th>' : ""}
      <th class="num">Sideways</th><th class="num">Data uji</th><th></th><th></th><th></th></tr>${rows}</table></div>
    ${R.skipped.length ? `<details class="hint"><summary>⏭️ ${R.n_skipped || R.skipped.length} koin dilewati (tidak ada / kurang data di periode ini)</summary>${R.skipped.map(esc).join("<br>")}${(R.n_skipped || 0) > R.skipped.length ? "<br>…" : ""}</details>` : ""}
    <p class="hint">Baris pudar = belum layak (alasannya di kolom rata-rata). Angka hasil pencarian di 70% data awal; kolom <b>Data uji</b> = 30% data terakhir yang tidak dipakai mencari.</p>
    <div id="itExBox"></div>`;
}
// ---- contoh kejadian: trade satu kombinasi di satu koin, klik untuk buka di Manual Replay (entry / SL / TP digambar)
async function itShowTrades(i, sym) {
  const R = IT.res, r = R.rows[i], box = $("itExBox");
  sym = sym || R.symbols[0];
  IT.exRow = i;
  box.innerHTML = `<h4>🔍 Contoh trade: ${esc(r.label)}</h4><p class="hint">Menghitung…</p>`;
  box.scrollIntoView({ behavior: "smooth", block: "start" });
  try {
    const res = await fetch("/api/indtester/trades", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol: sym, params: r.sl ? { ...R.params, sl_atr: r.sl, ...(r.mb ? { max_bars: r.mb } : {}) } : R.params, combo: r.combo }) });
    const j = await res.json();
    if (!res.ok) throw new Error(j.detail || res.statusText);
    IT.ex = j;
    const list = j.trades.slice().reverse().slice(0, 100);
    box.innerHTML = `<h4>🔍 Contoh trade: ${esc(r.label)}</h4>
      <div class="field" style="max-width:260px"><label>Koin</label><select id="itExSym">${R.symbols.map((s_) => `<option ${s_ === sym ? "selected" : ""}>${esc(s_)}</option>`).join("")}</select></div>
      <p class="hint">${j.n} trade di ${esc(sym)} (ditampilkan ${list.length} terbaru) — sama persis dengan yang dihitung di tabel. Klik baris untuk membuka momen itu di Manual Replay.</p>
      <div class="scroll" style="max-height:420px"><table class="tbl"><tr><th>Waktu (UTC)</th><th>Arah</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP</th><th>Hasil</th><th>Keluar</th><th>Data</th></tr>` +
      (list.length ? list.map((t, k) => `<tr data-itx="${j.trades.length - 1 - k}" title="Buka di chart (entry, SL &amp; TP otomatis digambar)"><td>${fmtTime(t.time).slice(0, 16)}</td>
        <td class="${t.side === "long" ? "pos" : "neg"}">${t.side}</td><td class="num">${pxTxt(t.entry)}</td><td class="num">${pxTxt(t.sl)}</td><td class="num">${pxTxt(t.tp)}</td>
        <td class="${t.win ? "pos" : t.sl_hit ? "neg" : ""}">${t.win ? "✅ TP" : t.sl_hit ? "❌ SL" : `⏱️ waktu habis ${t.r >= 0 ? "+" : ""}${t.r.toFixed(2)}R`}</td>
        <td>${fmtTime(t.exit_time).slice(0, 16)}</td><td class="hint">${t.test ? "uji" : "cari"}</td></tr>`).join("")
        : '<tr><td colspan="8" class="hint">Tidak ada trade di koin ini.</td></tr>') + "</table></div>";
  } catch (err) {
    box.innerHTML = `<h4>🔍 Contoh trade: ${esc(r.label)}</h4><p class="neg">Gagal: ${esc(err.message)}</p>` +
      (R.symbols.length > 1 ? `<div class="field" style="max-width:260px"><label>Coba koin lain</label><select id="itExSym">${R.symbols.map((s_) => `<option ${s_ === sym ? "selected" : ""}>${esc(s_)}</option>`).join("")}</select></div>` : "");
  }
}
// ---- 📈 EMA Tester (v3.75): Tes 1 MA pantulan, Tes 2 pasangan MA (MA kedua jebol → MA pertama tembus & bertahan)
function renderEmaTest() {
  const R = IT.res, P = R.params, X = R.rules || { away: 1, r: 1, tp: 2, hold: 200, gap: 30, min_n: 30 };
  const f0 = (v) => (v == null ? "—" : v.toFixed(0));
  const pc = (v) => (v == null ? "—" : v.toFixed(1) + "%");
  const ok = (b) => (b ? '<span class="badge pass">✅ konsisten</span>' : '<span class="badge fail">⚠️ belum</span>');
  const tf = P.tf.toUpperCase(), dur = (n) => (n == null ? "—" : `${f0(n)} candle <small>${itDurTxt(n)}</small>`);
  const bb = R.bounce[0], pb = R.pairs[0];
  const bRows = R.bounce.map((r, i) => `<tr class="${r.consistent ? "" : "dim"}"><td>${i + 1}</td><td><b>${esc(r.label)}</b></td>
    <td class="num"><b>${r.touch}</b><br><small>${r.per1000 == null ? "" : r.per1000.toFixed(1) + " / 1000 candle"}</small></td>
    <td class="num"><b class="pos">${r.ok}</b><br><small>${pc(r.pct)}</small></td>
    <td class="num"><b class="neg">${r.fail}</b><br><small>${pc(r.pct_fail)}</small></td>
    <td class="num ${r.edge > 0 ? "pos" : "neg"}">${r.edge == null ? "—" : (r.edge >= 0 ? "+" : "") + r.edge.toFixed(1)}</td>
    <td class="num">${dur(r.bars_med)}</td><td class="num">${pc(r.pct_test)}<br><small>${r.n_test} kejadian</small></td><td>${ok(r.consistent)}</td>
    <td><button class="mini it-ema-use" data-k="b" data-i="${i}">Pakai</button> <button class="mini it-ema-ex" data-k="b" data-i="${i}">🔍 Contoh</button></td></tr>`).join("");
  const pRows = R.pairs.map((r, i) => `<tr class="${r.consistent ? "" : "dim"}"><td>${i + 1}</td><td><b>${esc(r.label)}</b></td>
    <td class="num">${r.warn}</td><td class="num"><b class="pos">${pc(r.pct)}</b><br><small>${r.valid} valid</small></td>
    <td class="num"><small>balik ke EMA kedua (tren berlanjut) ${r.balik}<br>tembus EMA pertama lalu balik ${r.tembus_balik}</small></td>
    <td class="num">${dur(r.bars_med)}</td><td class="num">${pc(r.pct_test)}<br><small>${r.n_test} kejadian</small></td><td>${ok(r.consistent)}</td>
    <td><button class="mini it-ema-use" data-k="p" data-i="${i}">Pakai</button> <button class="mini it-ema-ex" data-k="p" data-i="${i}">🔍 Contoh</button></td></tr>`).join("");
  $("itBody").innerHTML = `<h3>📈 EMA Tester · ${tf} <span class="hint">${R.symbols.length} koin · ${R.candles.toLocaleString("id-ID")} candle · ${R.n_bounce} EMA &amp; ${R.n_pairs} pasangan diuji</span></h3>
    ${R.auto && R.auto.length ? `<p class="hint">🔎 Dicari otomatis (kolom dikosongkan): <b>${R.auto.map(esc).join(", ")}</b>.</p>` : ""}
    <div class="it-best"><h4>🏆 Ringkasan</h4><ul>
      ${bb ? `<li><b>Tes 1</b>: <b>${esc(bb.label)}</b> disentuh ${bb.touch}×, mantul minimal ${X.tp}R <b>${bb.ok}×</b> (${pc(bb.pct)}),
        tembus lalu tren berubah <b>${bb.fail}×</b> (${pc(bb.pct_fail)}). Data uji: mantul ${pc(bb.pct_test)}.
        Rata-rata semua EMA ${pc(R.bounce_avg)}. ${bb.consistent ? "✅ konsisten di data uji." : "⚠️ belum konsisten di data uji, hati-hati."}</li>` : "<li>Tes 1: belum ada EMA dengan kejadian cukup.</li>"}
      ${pb ? `<li><b>Tes 2</b>: pasangan terbaik <b>${esc(pb.label)}</b> — dari ${pb.warn}× EMA ${pb.second} dijebol, <b>${pb.valid}×</b> (${pc(pb.pct)}) lanjut tembus EMA ${pb.main}
        dan bertahan ${X.hold} candle (tren berubah), <b>${pb.balik}×</b> balik ke EMA ${pb.second} (tren berlanjut), ${pb.tembus_balik}× tembus lalu balik. Data uji ${pc(pb.pct_test)}.</li>` : "<li>Tes 2: belum ada pasangan dengan kejadian cukup.</li>"}
    </ul></div>
    <h4>1️⃣ EMA: berapa kali disentuh, mantul ${X.tp}R, tembus lalu tren berubah</h4>
    <p class="hint">Dihitung saat tren searah EMA (harga sudah ≥ ${X.away} ATR di atas / di bawah EMA), lalu ekor candle <b>menyentuh</b> EMA.
      <b>1R = ${X.r} ATR</b> saat menyentuh, diukur dari harga EMA saat disentuh. Mana yang lebih dulu: <b>mantul ${X.tp}R</b> = close ${X.tp}R searah tren;
      <b>tembus lalu tren berubah</b> = close ${X.tp}R di seberang EMA. Tidak ada batas waktu. <b>Edge</b> = % mantul dibanding rata-rata semua EMA.</p>
    <div class="scroll"><table class="tbl"><tr><th>#</th><th>EMA</th><th class="num">Disentuh</th><th class="num">Mantul ≥ ${X.tp}R</th><th class="num">Tembus &amp; tren berubah</th><th class="num">Edge</th>
      <th class="num">Median sampai mantul</th><th class="num">Data uji (mantul)</th><th></th><th></th></tr>${bRows || '<tr><td colspan="10" class="hint">Belum ada EMA dengan kejadian cukup.</td></tr>'}</table></div>
    ${R.too_few_b ? `<p class="hint">${R.too_few_b} EMA tidak ditampilkan karena sentuhannya &lt; ${X.min_n}.</p>` : ""}
    <h4>2️⃣ EMA kedua dijebol → EMA pertama tembus = tren berubah</h4>
    <p class="hint">Saat harga di atas (bullish) / di bawah (bearish) kedua EMA, candle close menembus <b>EMA kedua</b> tapi masih tertahan EMA pertama = <b>peringatan</b>
      (harga masuk range antara kedua EMA). <b>Valid (tren berubah)</b> = harga lanjut close menembus <b>EMA pertama</b> dan tidak close balik selama <b>${X.hold} candle</b>.
      <b>Pengecualian</b>: harga balik lagi melewati EMA kedua = <b>tren berlanjut</b>. Tembus EMA pertama tapi close balik sebelum ${X.hold} candle = gagal.
      Pasangan: EMA pertama minimal ${X.gap} lebih besar dari EMA kedua. <b>Median sampai valid</b> = candle dari EMA kedua dijebol sampai EMA pertama ditembus.</p>
    <div class="scroll"><table class="tbl"><tr><th>#</th><th>Pasangan</th><th class="num">Peringatan</th><th class="num">Valid (tren berubah)</th><th class="num">Gagal</th>
      <th class="num">Median sampai valid</th><th class="num">Data uji</th><th></th><th></th></tr>${pRows || '<tr><td colspan="9" class="hint">Belum ada pasangan dengan kejadian cukup.</td></tr>'}</table></div>
    ${R.too_few_p ? `<p class="hint">${R.too_few_p} pasangan tidak ditampilkan karena peringatannya &lt; ${X.min_n}.</p>` : ""}
    ${R.skipped.length ? `<details class="hint"><summary>⏭️ ${R.n_skipped || R.skipped.length} koin dilewati</summary>${R.skipped.map(esc).join("<br>")}</details>` : ""}
    ${R.short && Object.keys(R.short).length ? `<p class="hint">⏳ EMA panjang butuh data minimal 3× panjangnya (EMA 3000 → 9.000 candle). Dilewati di koin yang datanya kurang:
      ${Object.entries(R.short).map(([k, v]) => `${esc(k)} (${v} koin)`).join(", ")}. EMA lain tetap dihitung penuh.</p>` : ""}
    <p class="hint">Angka dari 70% data awal; <b>Data uji</b> = 30% data terakhir. ✅ konsisten = selisih data cari &amp; uji ≤ 10 poin (Tes 1 juga harus &gt; 50%).</p>
    <div id="itExBox"></div>`;
}
// ---- 🎛️ Hyperopt Tester
function renderHyper() {
  const R = IT.res, P = R.params, F = R.folds;
  const pc = (v) => (v == null ? "—" : v.toFixed(0) + "%");
  const rr = (v) => (v == null ? "—" : `<b class="${v > 0 ? "pos" : "neg"}">${v >= 0 ? "+" : ""}${v.toFixed(2)}R</b>`);
  const objTxt = { exp_r: "rata-rata R per trade", wr: "win rate", score: "rata-rata R × √trade" }[R.obj] || R.obj;
  const ov = R.overfit, drop = ov && ov.train > 0 ? Math.round(100 * (1 - ov.test / ov.train)) : null;
  const best = R.rows[0];
  const wt = R.walk_total;
  const verdict = !best ? "Belum ada kombinasi dengan trade cukup." :
    !wt || wt.n < 30 ? `⏳ Trade walk-forward baru ${wt ? wt.n : 0} (butuh ≥ 30) — belum bisa disimpulkan. Tambah koin / periode lebih panjang.` :
    wt && wt.n && wt.exp_r > 0 && R.rows.some((r) => r.passed)
      ? "✅ Optimasi masih bekerja di data baru: walk-forward untung dan ada angka yang stabil + lolos uji."
      : wt && wt.n && wt.exp_r <= 0 ? "⚠️ Walk-forward RUGI: angka terbaik di masa lalu tidak membantu di periode berikutnya — kemungkinan besar overfitting."
      : "⚠️ Belum ada angka yang stabil DAN untung di data uji. Hati-hati memakai angka terbaik.";
  const rows = R.rows.map((r, i) => `<tr class="${r.passed ? "" : "dim"}"><td>${i + 1}</td><td><b>${esc(r.label)}</b></td>
    <td class="num">${r.n}</td><td class="num">${pc(r.wr)}</td><td class="num">${rr(r.exp_r)}</td>
    <td class="num">${r.n_test}<br><small>${pc(r.wr_test)} · ${rr(r.exp_test)}</small></td>
    <td class="num">${r.nb_mean == null ? "—" : rr(r.nb_mean)}<br><small>${r.nb_n} tetangga</small></td>
    <td class="num"><small>${r.folds.map((f) => (f.exp_r == null ? "·" : `<span class="${f.exp_r > 0 ? "pos" : "neg"}">${f.exp_r >= 0 ? "+" : ""}${f.exp_r.toFixed(1)}</span>`)).join(" ")}</small></td>
    <td>${r.passed ? '<span class="badge pass">✅ lolos</span>' : r.robust ? '<span class="badge">stabil, uji belum</span>' : '<span class="badge fail">⚠️ rapuh</span>'}</td>
    <td><button class="mini it-use" data-i="${i}">Test angka ini</button></td>
    <td><button class="mini it-ex" data-i="${i}">🔍 Contoh trade</button></td></tr>`).join("");
  const wf = R.walk.map((w, i) => `<tr><td>Langkah ${i + 1}</td><td>fold 1–${w.train_folds} (${Math.round(100 * w.train_folds / F)}% awal)</td><td>fold ${w.train_folds + 1}</td>
    <td>${w.pick ? esc(w.pick) : "—"}</td><td class="num">${w.train ? rr(w.train.exp_r) : "—"}</td>
    <td class="num">${w.test ? `${w.test.n} trade · ${pc(w.test.wr)} · ${rr(w.test.exp_r)}` : "—"}</td>
    <td class="num">${w.all_test ? rr(w.all_test.exp_r) : "—"}</td></tr>`).join("");
  $("itBody").innerHTML = `<h3>🎛️ Hyperopt Tester · ${P.tf.toUpperCase()} <span class="hint">${R.symbols.length} koin · ${R.candles.toLocaleString("id-ID")} candle ·
      ${R.n_combos.toLocaleString("id-ID")} kombinasi${R.sampled ? ` (acak dari ${R.full.toLocaleString("id-ID")})` : ""} · RR 1:${P.rr} · WR impas ${R.breakeven.toFixed(0)}% · dioptimasi: ${objTxt}</span></h3>
    <div class="it-best"><h4>🧾 Kesimpulan</h4><ul>
      <li>${verdict}</li>
      ${ov ? `<li><b>Overfitting:</b> 10 angka terbaik rata-rata ${rr(ov.train)} di data cari, tapi ${rr(ov.test)} di data uji${drop != null ? ` (turun <b>${drop}%</b>)` : ""}. Makin besar turunnya, makin banyak yang "dihafal" dari data lama.</li>` : ""}
      ${wt && wt.n ? `<li><b>Walk-forward</b> (meniru hyperopt ulang tiap periode): ${wt.n} trade · WR ${pc(wt.wr)} · ${rr(wt.exp_r)} per trade. Ini perkiraan paling jujur kalau kamu memakai hyperopt di trading sungguhan.</li>` : ""}
      <li>Pembanding: <b>semua kombinasi</b> di data uji rata-rata ${rr(R.base_test.exp_r)} (${R.base_test.n.toLocaleString("id-ID")} trade). Angka terbaik harus jelas lebih bagus dari ini.</li>
    </ul></div>
    <h4>📋 Angka terbaik (diurutkan dari data cari 80% awal)</h4>
    <div class="scroll"><table class="tbl"><tr><th>#</th><th>Angka</th><th class="num">Trade</th><th class="num">WR</th><th class="num">Rata-rata R</th>
      <th class="num">Data uji (20%)</th><th class="num" title="Rata-rata R angka di sebelahnya (satu angka digeser ke nilai sebelah). Mirip = stabil, jauh lebih jelek = kebetulan.">Tetangga</th>
      <th class="num" title="Rata-rata R per bagian waktu (fold 1 → ${F})">Per periode</th><th></th><th></th><th></th></tr>${rows || '<tr><td colspan="11" class="hint">Belum ada kombinasi dengan trade cukup.</td></tr>'}</table></div>
    ${R.too_few ? `<p class="hint">${R.too_few.toLocaleString("id-ID")} kombinasi tidak ditampilkan karena trade-nya &lt; ${P.min_trades} di data cari.</p>` : ""}
    <h4>🚶 Walk-forward</h4>
    <div class="scroll"><table class="tbl"><tr><th></th><th>Dicari di</th><th>Dipakai di</th><th>Angka terbaik saat itu</th><th class="num">Hasil saat dicari</th><th class="num">Hasil di periode berikutnya</th><th class="num">Semua kombinasi (pembanding)</th></tr>${wf}</table></div>
    <p class="hint">✅ <b>lolos</b> = untung di data uji, cukup trade, dan <b>stabil</b> (angka tetangganya juga untung, minimal separuh hasil angka terbaik). <b>Rapuh</b> = angka di sebelahnya jauh lebih jelek → kemungkinan besar kebetulan.</p>
    ${R.skipped.length ? `<details class="hint"><summary>⏭️ ${R.n_skipped} koin dilewati</summary>${R.skipped.map(esc).join("<br>")}</details>` : ""}
    <div id="itExBox"></div>`;
}
async function itShowEma(kind, i, sym) {
  const R = IT.res, r = kind === "b" ? R.bounce[i] : R.pairs[i], box = $("itExBox");
  sym = sym || R.symbols[0];
  IT.exEma = { kind, i };
  const item = kind === "b" ? { kind: "bounce", n: r.n } : { kind: "pair", main: r.main, second: r.second };
  box.innerHTML = `<h4>🔍 Contoh kejadian: ${esc(r.label)}</h4><p class="hint">Menghitung…</p>`;
  box.scrollIntoView({ behavior: "smooth", block: "start" });
  const sel = `<div class="field" style="max-width:260px"><label>Koin</label><select id="itExSym">${R.symbols.map((s_) => `<option ${s_ === sym ? "selected" : ""}>${esc(s_)}</option>`).join("")}</select></div>`;
  try {
    const res = await fetch("/api/indtester/trades", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol: sym, params: R.params, item }) });
    const j = await res.json();
    if (!res.ok) throw new Error(j.detail || res.statusText);
    IT.ex = j;
    const list = j.events.slice().reverse().slice(0, 150);
    const NAME = { mantul: ["✅ mantul ≥ 2R", "pos"], berubah: ["❌ tembus lalu tren berubah", "neg"],
      valid: ["✅ valid: tren berubah", "pos"], balik: ["↩️ balik ke EMA kedua (tren berlanjut)", "neg"], tembus_balik: ["🪤 tembus EMA pertama lalu balik", "neg"] };
    box.innerHTML = `<h4>🔍 Contoh kejadian: ${esc(r.label)}</h4>${sel}
      <p class="hint">${j.n} kejadian di ${esc(sym)} (ditampilkan ${list.length} terbaru) — sama persis dengan yang dihitung. Klik baris untuk membuka di Manual Replay
        (garis MA otomatis dipasang di chart).</p>
      <div class="scroll" style="max-height:420px"><table class="tbl"><tr><th>Waktu (UTC)</th><th>${kind === "b" ? "Tren" : "Tren lama"}</th><th class="num">Harga</th>
        <th class="num">${kind === "b" ? "EMA" : "EMA pertama / kedua"}</th><th>Hasil</th><th>Selesai</th><th>Data</th></tr>` +
      (list.length ? list.map((e, k) => { const nm = NAME[e.result] || [e.result, ""];
        return `<tr data-emx="${j.events.length - 1 - k}" title="Buka di chart"><td>${fmtTime(e.time).slice(0, 16)}</td>
          <td class="${e.dir > 0 ? "pos" : "neg"}">${e.dir > 0 ? "naik" : "turun"}</td><td class="num">${pxTxt(e.price)}</td>
          <td class="num">${kind === "b" ? pxTxt(e.ma) : `${pxTxt(e.main)} / ${pxTxt(e.second)}`}</td><td class="${nm[1]}">${nm[0]}</td>
          <td>${fmtTime(e.end_time).slice(0, 16)}</td><td class="hint">${e.test ? "uji" : "cari"}</td></tr>`; }).join("")
        : '<tr><td colspan="7" class="hint">Tidak ada kejadian di koin ini.</td></tr>') + "</table></div>";
  } catch (err) {
    box.innerHTML = `<h4>🔍 Contoh kejadian: ${esc(r.label)}</h4>${sel}<p class="neg">Gagal: ${esc(err.message)}</p>`;
  }
}
// pasang garis MA yang dites di chart (EMA → indikator EMA, SMA → indikator MA); jenis lain tidak ada di chart
function itShowMaOnChart(type, lens) {
  const key = type === "EMA" ? "EMA" : type === "SMA" ? "MA" : null;
  if (!key) return false;
  IND[key] = { ...(IND[key] || {}), on: true, params: lens.join(",") };
  saveInd(key);
  return true;
}
function itUseRow(r) {
  const c = r.combo;
  if (IT.t === "hyper") {                                             // hasil hyperopt -> diuji di tester biasa dengan angka ini
    const keys = Object.keys(c).filter((k) => ["ma_pair", "rsi", "stoch", "macd", "adx", "force"].includes(k));
    IT.t = keys.length === 1 && ["rsi", "stoch", "macd"].includes(keys[0]) ? keys[0] : "combo";
    if (IT.t === "combo") document.querySelectorAll("#itComps input").forEach((x) => { x.checked = keys.includes(x.value); });
    if (r.mb) $("itMaxBars").value = r.mb;
    $("itDir").value = "both";
  }
  if (r.sl) $("itSl").value = r.sl;
  if (c.ma_pair) { $("itMain").value = c.ma_pair.main; $("itSecond").value = c.ma_pair.second; $("itEmaMode").value = "test"; }
  if (c.ma_filter) { $("itFilterLen").value = c.ma_filter.n; }
  if (c.rsi) { $("itRsiLen").value = c.rsi.n; $("itRsiOb").value = c.rsi.ob; }
  if (c.stoch) { $("itStK").value = c.stoch.k; $("itStSmooth").value = c.stoch.smooth; $("itStD").value = c.stoch.d; $("itStOb").value = c.stoch.ob; }
  if (c.macd) { $("itMacdFast").value = c.macd.fast; $("itMacdSlow").value = c.macd.slow; $("itMacdSig").value = c.macd.signal; }
  if (c.adx) { $("itAdxLen").value = c.adx.n; $("itAdxTh").value = c.adx.th; }
  if (c.force) { $("itFiLen").value = c.force.n; $("itFiK").value = c.force.k; }
  itUpdate();
  toast("Angka dipasang ke form (mode test). Ganti TF / periode / koin lalu klik Jalankan untuk mengujinya.");
  $("tab-indtest").querySelector(".bt-form").scrollIntoView({ behavior: "smooth", block: "start" });
}
{
  fetch("/api/indtester/defaults").then((r) => r.json()).then((d) => {
    IT.def = d;
    const opt = (v) => d.ma_types.map((t) => `<option value="${t}">${t}</option>`).join("");
    $("itMaType").innerHTML = opt(); $("itMaType2").innerHTML = '<option value="">sama dengan MA utama</option>' + opt();
    $("itTf").innerHTML = ["5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"].map((t) => `<option value="${t}">${t.toUpperCase()}</option>`).join("");
    itFill(d.defaults);
    for (const [id, k] of Object.entries(IT_FIELDS)) {
      const el = $(id);
      if (el && el.tagName === "INPUT" && d.auto[k]) {
        el.placeholder = "kosong = cari otomatis";
        el.dataset.auto = el.closest(".field").querySelector("label").textContent.replace(/ —.*$/, "").trim();
        el.title = "Kosongkan untuk dicari otomatis dari: " + d.auto[k];
      }
    }
    const f = store.get("itForm", null);
    if (f) { itFill(f); if (f.scope) $("itScope").value = f.scope; if (f.symbols) $("itSymbols").value = f.symbols; }
    $("itListWrap").classList.toggle("hidden", $("itScope").value !== "list");
    itUpdate();
  });
  $("itPick").onclick = (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    if (b.dataset.t === "adx" || b.dataset.t === "force") {        // ADX / Force Index dites seperti Tes SNR (dekat SNR → breakout / respect)
      $("snInd").value = b.dataset.t === "adx" ? "adx" : "adxfi";
      document.querySelector('.tab[data-tab="snrtest"]').click();
      snUpdate();
      return toast(b.dataset.t === "adx" ? "ADX dites di 📍 Tes SNR: nilai ADX saat harga mendekati SNR → peluang breakout / respect."
        : "Force Index digabung dengan ADX di 📍 Tes SNR: arah FI (menuju / melawan SNR) + nilai ADX → peluang breakout / respect.");
    }
    IT.t = b.dataset.t; itUpdate();
  };
  $("tab-indtest").addEventListener("input", (e) => { if (e.target.closest(".bt-form")) itUpdate(); });
  $("tab-indtest").addEventListener("change", (e) => { if (e.target.closest(".bt-form")) itUpdate(); });
  $("itScope").onchange = () => $("itListWrap").classList.toggle("hidden", $("itScope").value !== "list");
  $("itRun").onclick = runIndTest;
  studyBind("indtester", Object.assign(IT_UI, { pause: $("itPause"), cancel: $("itCancel") }), attachIndTest);
  $("itSavedBox").addEventListener("toggle", (e) => { if (e.target.open) savedResults("indtester", $("itSaved"), (res) => {
    IT.res = res; $("itOut").classList.remove("hidden"); $("itLive").classList.add("hidden"); renderIndTest(); $("itOut").scrollIntoView({ behavior: "smooth" }); }); });
  $("itQuick").onclick = (e) => {
    const b = e.target.closest("button"); if (!b) return;
    $("itMaxBars").value = Math.max(2, Math.round((+b.dataset.h * 60) / (IT_TF_MIN[$("itTf").value] || 60)));
    itUpdate();
  };
  $("itAdvReset").onclick = () => {
    for (const [id, k] of Object.entries(IT_ADV)) $(id).value = IT.def.defaults[k];
    itUpdate(); toast("Pengaturan lanjutan dikembalikan ke default");
  };
  $("itBody").addEventListener("click", async (e) => {
    const eu = e.target.closest(".it-ema-use");
    if (eu && IT.res) {
      const r = eu.dataset.k === "b" ? IT.res.bounce[+eu.dataset.i] : IT.res.pairs[+eu.dataset.i];
      if (eu.dataset.k === "b") $("itBounce").value = r.n;
      else { $("itMain").value = r.main; $("itSecond").value = r.second; }
      itUpdate();
      toast("Angka dipasang ke form. Ganti TF / periode / koin lalu klik Jalankan untuk mengujinya.");
      return $("tab-indtest").querySelector(".bt-form").scrollIntoView({ behavior: "smooth", block: "start" });
    }
    const ee = e.target.closest(".it-ema-ex");
    if (ee && IT.res) return itShowEma(ee.dataset.k, +ee.dataset.i);
    const er = e.target.closest("tr[data-emx]");
    if (er && IT.ex && IT.ex.events) {
      const x = IT.ex.events[+er.dataset.emx], J = IT.ex;
      const lens = J.kind === "bounce" ? [J.lines.main] : [J.lines.second, J.lines.main];
      const marks = J.kind === "bounce" ? [{ price: x.ma, color: "#eab308", size: 2, dash: true, label: `EMA ${J.lines.main}` },
        ...(x.r ? [{ price: x.ma + x.dir * 2 * x.r, color: "#26a69a", dash: true, label: "mantul 2R" }, { price: x.ma - x.dir * 2 * x.r, color: "#ef5350", dash: true, label: "tren berubah 2R" }] : [])]
        : [{ price: x.second, color: "#ab47bc", dash: true, label: `EMA kedua ${J.lines.second}` }, { price: x.main, color: "#eab308", size: 2, dash: true, label: `EMA pertama ${J.lines.main}` }];
      const shown = J.ma_type === J.ma_type2 || J.kind === "bounce" ? itShowMaOnChart(J.ma_type, lens) : false;
      const res = { mantul: "mantul ≥ 2R", berubah: "tembus lalu tren berubah (2R di seberang EMA)", valid: "VALID (tren berubah, bertahan 200 candle)", balik: "balik ke EMA kedua (tren berlanjut)",
        tembus_balik: "tembus EMA pertama lalu balik" }[x.result] || x.result;
      await openMoment(J.symbol, J.tf, x.time, marks,
        `${fmtTime(x.time).slice(0, 16)} ${J.symbol} ${J.tf.toUpperCase()}: ${J.kind === "bounce" ? `harga menyentuh EMA ${J.lines.main}` : `EMA kedua ${J.lines.second} dijebol (peringatan)`}. ` +
        `Hasil: ${res} (${fmtTime(x.end_time).slice(0, 16)}). ${shown ? `Indikator ${J.ma_type === "SMA" ? "MA" : "EMA"} di chart diganti ke ${lens.join(", ")}.` : "Garis putus-putus = nilai MA saat kejadian."} Step maju untuk melihat kelanjutannya.`);
      return;
    }
    const b = e.target.closest(".it-use");
    if (b && IT.res) return itUseRow(IT.res.rows[+b.dataset.i]);
    const x = e.target.closest(".it-ex");
    if (x && IT.res) return itShowTrades(+x.dataset.i);
    const tr = e.target.closest("tr[data-itx]");
    if (!tr || !IT.ex) return;
    const t = IT.ex.trades[+tr.dataset.itx];
    await openMoment(IT.ex.symbol, IT.ex.tf, t.time, [
      { price: t.entry, color: "#42a5f5", size: 2, label: `E ${pxTxt(t.entry)}` },
      { price: t.sl, color: "#ef5350", dash: true, label: `SL ${pxTxt(t.sl)}` },
      { price: t.tp, color: "#26a69a", dash: true, label: `TP ${pxTxt(t.tp)}` }],
      `Sinyal ${t.side} ${fmtTime(t.time).slice(0, 16)} (${IT.ex.symbol} ${IT.ex.tf.toUpperCase()}): entry di close candle ini. Hasil: ${t.win ? "TP" : t.sl_hit ? "SL" : "waktu habis"} (${fmtTime(t.exit_time).slice(0, 16)}). Step maju untuk melihat kelanjutannya.`);
  });
  $("itBody").addEventListener("change", (e) => {
    if (e.target.id !== "itExSym" || !IT.res) return;
    if (IT.res.ema2 && IT.exEma) return itShowEma(IT.exEma.kind, IT.exEma.i, e.target.value);
    if (IT.exRow != null) itShowTrades(IT.exRow, e.target.value);
  });
}

// ------------------------------------------------------------------ 🐋 pelacak whale
const WH = { busy: false, timer: null, res: null };
const usdtTxt = (v) => (v >= 1e9 ? (v / 1e9).toFixed(2) + " M" : v >= 1e6 ? (v / 1e6).toFixed(2) + " jt" : (v / 1e3).toFixed(0) + " rb");
const pxTxt = (v) => (+v).toPrecision(6).replace(/\.?0+$/, "");
// 📋 salin angka pakai KOMA (1.8178 -> 1,8178) supaya bisa langsung di-paste di Binance. Dipakai di Whale, Market Structure, Screener.
const cpComma = (v) => String(typeof v === "number" ? pxTxt(v) : v).trim().replace(",", "").replace(".", ",");
const cpB = (v) => (v == null || v === "" || !isFinite(+v) ? "" : `<button type="button" class="cpn" data-cp="${cpComma(v)}" title="Salin ${cpComma(v)} (pakai koma, untuk Binance)">📋</button>`);
document.addEventListener("click", async (e) => {
  const b = e.target.closest && e.target.closest(".cpn");
  if (!b || !b.dataset.cp) return;
  e.preventDefault(); e.stopPropagation();                              // jangan ikut membuka baris / kartu
  await copyText(b.dataset.cp);
  toast(`Disalin: ${b.dataset.cp}`);
}, true);
const sideTag = (s) => `<span class="wh-side ${s === "BUY" ? "buy" : "sell"}">${s}</span>`;
const symCell = (s) => `<a class="symlink wh-sym" data-sym="${s}">${s}</a><a class="ext" target="_blank" rel="noopener" href="https://www.binance.com/en/futures/${s}">↗</a>`;
function renderWhales() {
  const r = WH.res;
  if (!r) return;
  const pct = (v, d = 2) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(d)}%`);
  const coins = r.coins.map((c) => `<tr><td>${symCell(c.symbol)}</td><td class="num">${pxTxt(c.price)}</td>
      <td class="num ${c.chg_24h >= 0 ? "pos" : "neg"}">${pct(c.chg_24h)}</td>
      <td class="num pos">${usdtTxt(c.wall_buy)}</td><td class="num neg">${usdtTxt(c.wall_sell)}</td>
      <td class="num pos">${usdtTxt(c.trade_buy)}</td><td class="num neg">${usdtTxt(c.trade_sell)}</td>
      <td class="num"><div class="wh-bias"><i style="left:50%;width:${Math.abs(c.bias) / 2}%;${c.bias < 0 ? "transform:translateX(-100%);background:#ef5350" : "background:#26a69a"}"></i></div>
        <small class="${c.bias >= 0 ? "pos" : "neg"}">${c.bias >= 0 ? "+" : ""}${c.bias.toFixed(0)}</small></td>
      <td class="num"><b>${c.max_impact.toFixed(2)}%</b></td></tr>`).join("");
  const walls = r.walls.map((w, i) => `<tr><td>${i + 1}</td><td>${symCell(w.symbol)}</td><td>${sideTag(w.side)}</td>
      <td class="num">${pxTxt(w.price)}</td><td class="num">${pct(w.dist_pct)}</td><td class="num"><b>${usdtTxt(w.usdt)}</b></td>
      <td class="num">${w.power_pct == null ? "—" : w.power_pct.toFixed(1) + "%"}</td><td class="num"><b>${w.impact_pct.toFixed(2)}%</b></td>
      <td class="hint">${w.side === "BUY" ? "menahan harga turun di " + pxTxt(w.price) : "menahan harga naik di " + pxTxt(w.price)}</td></tr>`).join("");
  const trades = r.trades.map((t, i) => `<tr><td>${i + 1}</td><td>${symCell(t.symbol)}</td><td>${sideTag(t.side)}</td>
      <td class="num">${pxTxt(t.price)}</td><td class="num"><b>${usdtTxt(t.usdt)}</b></td>
      <td class="num">${t.x_vol_min == null ? "—" : t.x_vol_min.toFixed(1) + "×"}</td><td class="num"><b>${t.impact_pct.toFixed(2)}%</b></td>
      <td>${new Date(t.time).toLocaleTimeString("id-ID")}</td></tr>`).join("");
  const none = (txt) => `<p class="hint">${txt}</p>`;
  $("whCount").textContent = `(${r.walls.length} tembok · ${r.trades.length} transaksi · ${r.coins.length} koin)`;
  $("whOut").innerHTML = `
    <h4>🧭 Tekanan whale per koin <span class="hint">diurutkan dari dampak terbesar</span></h4>
    ${coins ? `<div class="scroll"><table class="tbl"><tr><th>Koin</th><th class="num">Harga</th><th class="num">24 jam</th>
      <th class="num">Tembok BUY</th><th class="num">Tembok SELL</th><th class="num">Transaksi BUY</th><th class="num">Transaksi SELL</th>
      <th class="num">Tekanan</th><th class="num">Dampak maks.</th></tr>${coins}</table></div>` : none("Belum ada whale yang lolos filter. Turunkan min. nilai / min. dampak.")}
    <h4>🧱 Tembok order terbesar (limit) <span class="hint">di harga berapa whale menaruh order</span></h4>
    ${walls ? `<div class="scroll"><table class="tbl"><tr><th>#</th><th>Koin</th><th>Sisi</th><th class="num">Harga</th><th class="num">Jarak</th>
      <th class="num">Nilai USDT</th><th class="num">Kekuatan</th><th class="num">Dampak</th><th>Artinya</th></tr>${walls}</table></div>` : none("Tidak ada tembok yang lolos filter.")}
    <h4>⚡ Transaksi whale terbaru (market) <span class="hint">dari 1000 transaksi terakhir tiap koin</span></h4>
    ${trades ? `<div class="scroll"><table class="tbl"><tr><th>#</th><th>Koin</th><th>Sisi</th><th class="num">Harga</th><th class="num">Nilai USDT</th>
      <th class="num">× vol/menit</th><th class="num">Dampak</th><th>Waktu</th></tr>${trades}</table></div>` : none("Tidak ada transaksi besar yang lolos filter.")}`;
}
// ---- analisa whale 1 koin
// ---- kekuatan tren, perkiraan gerak, SL/TP & pantulan tembok (analisa 1 koin)
function whalePlanHtml(r) {
  const p = r.plan;
  if (!p) return '<p class="hint">Rencana SL/TP & prediksi belum tersedia (data candle H1 kurang).</p>';
  const pct = (v) => `${v >= 0 ? "+" : ""}${v.toFixed(2)}%`;
  const hrs = (h) => (h == null ? "—" : h < 1 ? `±${Math.max(1, Math.round(h * 60))} menit` : h < 48 ? `±${h.toFixed(1)} jam` : `±${(h / 24).toFixed(1)} hari`);
  const reg = { BULLISH: ["📈", "pos"], BEARISH: ["📉", "neg"], SIDEWAYS: ["↔️", ""] }[p.regime];
  const f = p.factors, fx = (v) => `<b class="${v > 0 ? "pos" : v < 0 ? "neg" : ""}">${v > 0 ? "+" : ""}${v.toFixed(0)}</b>`;
  const bar = (lbl, v, cls) => `<div class="wh-str"><span>${lbl}</span><div><i class="${cls}" style="width:${v}%"></i></div><b>${v.toFixed(0)}%</b></div>`;
  const pr = p.pred, up = pr.dir > 0;
  const main = p.regime === "BULLISH" ? "long" : p.regime === "BEARISH" ? "short" : null;
  const planCard = (k) => {
    const x = p.plans[k], isL = k === "long";
    return `<div class="conc-reg wh-plan ${main === k ? "wh-main" : ""}"><h4>${isL ? "🟢 LONG (BUY)" : "🔴 SHORT (SELL)"} ${main === k ? '<span class="badge pass">searah kekuatan</span>' : main ? '<span class="badge fail">melawan kekuatan</span>' : '<span class="badge">sideways: main di tembok</span>'}</h4>
      <table class="tbl"><tr><td>Entry</td><td class="num">${pxTxt(x.entry)}${cpB(x.entry)}</td><td></td></tr>
        <tr><td>SL</td><td class="num neg">${pxTxt(x.sl)}${cpB(x.sl)}</td><td class="num">${pct(x.sl_pct)} <small>· di balik ${x.sl_from}</small></td></tr>
        <tr><td>TP1</td><td class="num pos">${pxTxt(x.tp1)}${cpB(x.tp1)}</td><td class="num">${pct(x.tp1_pct)} <small>· RR 1:${x.rr1 == null ? "—" : x.rr1.toFixed(1)}</small></td></tr>
        <tr><td>TP2</td><td class="num pos">${pxTxt(x.tp2)}${cpB(x.tp2)}</td><td class="num">${pct(x.tp2_pct)} <small>· RR 1:${x.rr2 == null ? "—" : x.rr2.toFixed(1)}</small></td></tr></table>
      <p class="hint">${isL ? "SL di bawah tembok BELI whale terkuat (±3%) + buffer 0.25 ATR H1. TP1 di depan tembok JUAL terdekat, TP2 di tembok JUAL terbesar berikutnya." :
        "SL di atas tembok JUAL whale terkuat (±3%) + buffer 0.25 ATR H1. TP1 di depan tembok BELI terdekat, TP2 di tembok BELI terbesar berikutnya."}
        ${x.rr1 != null && x.rr1 < 1 ? " ⚠️ TP1 lebih dekat dari SL: lebih baik tunggu harga ke tembok dulu (lihat tabel pantulan)." : ""}</p></div>`;
  };
  const touch = p.touch.map((t) => `<tr><td>${sideTag(t.side)}</td><td class="num">${pxTxt(t.price)} <small>${pct(t.dist_pct)}</small></td><td class="num">${usdtTxt(t.usdt)}</td>
      <td>${t.side === "BUY" ? "memantul NAIK" : "turun lagi"} ke <b>${pxTxt(t.target)}</b></td><td class="num"><b class="${t.move_pct >= 0 ? "pos" : "neg"}">${pct(t.move_pct)}</b></td>
      <td>${hrs(t.hours)}${t.capped ? ' <small class="hint">(tertahan tembok lawan)</small>' : ""}</td></tr>`).join("");
  return `
    <div class="wh-cards">
      <div class="conc-reg"><h4>${reg[0]} Kekuatan pasar: <span class="${reg[1]}">${p.regime}</span></h4>
        ${bar("Bullish", p.bull, "b")}${bar("Bearish", p.bear, "r")}${bar("Sideways", p.side, "s")}
        <p class="hint">Faktor (−100…+100): tren EMA 20/50/200 H1 ${fx(f.trend)} · transaksi whale ${fx(f.whale_trades)} · order book ±2% ${fx(f.order_book)} ·
          ADX H1 ${p.adx.toFixed(0)} (${p.adx >= 25 ? "tren kuat" : p.adx >= 20 ? "tren lemah" : "cenderung sideways"})</p></div>
      <div class="conc-reg"><h4>🔮 Perkiraan gerak <span class="hint">dari volatilitas asli koin ini</span></h4><ul>
        <li>Dalam <b>±4 jam</b> biasanya bergerak <b>±${pr.move_4h.toFixed(2)}%</b>${p.regime !== "SIDEWAYS" ? `, condong <b class="${up ? "pos" : "neg"}">${up ? "NAIK" : "TURUN"}</b> → sekitar <b>${pxTxt(r.price * (1 + (up ? 1 : -1) * pr.move_4h / 100))}</b>` : " (bolak-balik di antara tembok)"}.</li>
        <li>Dalam <b>±1 hari</b> biasanya bergerak <b>±${pr.move_1d.toFixed(2)}%</b>${p.regime !== "SIDEWAYS" ? ` → sekitar <b>${pxTxt(r.price * (1 + (up ? 1 : -1) * pr.move_1d / 100))}</b>` : ""}.</li>
        ${pr.to_resist_h != null ? `<li>Ke resistance whale terdekat: ${hrs(pr.to_resist_h)} pada kecepatan rata-rata.</li>` : ""}
        ${pr.to_support_h != null ? `<li>Ke support whale terdekat: ${hrs(pr.to_support_h)} pada kecepatan rata-rata.</li>` : ""}
      </ul><p class="hint">ATR H1 ${pr.atr1h_pct.toFixed(2)}% · ATR harian ${pr.atrd_pct.toFixed(2)}%.</p></div>
    </div>
    <h4>🎯 Rencana SL &amp; TP dari tembok whale</h4>
    <div class="wh-cards">${main === "short" ? planCard("short") + planCard("long") : planCard("long") + planCard("short")}</div>
    <h4>🧲 Kalau harga menyentuh tembok whale ini, perkiraan geraknya</h4>
    ${touch ? `<div class="scroll"><table class="tbl"><tr><th>Tembok</th><th class="num">Harga</th><th class="num">Nilai</th><th>Lalu</th><th class="num">Gerak</th><th>Waktu ±</th></tr>${touch}</table></div>
      <p class="hint">Besar pantulan dihitung dari kekuatan tembok (porsinya dari semua order di sisinya) dan ATR H1 (0.8–3 ATR), dibatasi tembok lawan berikutnya.</p>`
      : '<p class="hint">Tidak ada tembok whale di sekitar harga yang lolos filter.</p>'}
    <p class="hint">⚠️ Semua di bagian ini <b>perkiraan</b>, bukan kepastian. Riwayat order book tidak tersedia publik sehingga tidak bisa di-backtest,
      dan tembok whale bisa ditarik kapan saja. Pakai bersama analisa chart.</p>`;
}
// ---- 🛡️ anti gocekan (stop hunt): alarm lonjakan, zona gocekan, zona tipis, tembok palsu, SL anti-gocekan
function antiGocekHtml(r) {
  const a = r.anti;
  if (!a) return "";
  const pct = (v) => `${v >= 0 ? "+" : ""}${v.toFixed(2)}%`;
  const al = a.alarm, bt = a.backtest;
  const alarm = !al ? "" : `<div class="wh-alarm ${al.level.toLowerCase()}">${al.level === "NORMAL" ? "✅" : "🚨"} <b>${al.level}</b> ·
      5 menit terakhir: volume <b>${al.vol_ratio.toFixed(1)}×</b> normal (puncak ${al.peak_ratio.toFixed(1)}×), harga <b>${pct(al.move5_pct)}</b>
      (${al.dir}, ATR 1m ${al.atr1m_pct.toFixed(2)}%), ${al.buy_share.toFixed(0)}% volume dari pembeli agresif.
      ${al.level === "BAHAYA" ? "Gocekan / lonjakan sedang terjadi: jangan kejar harga, tunggu candle tenang." : al.level === "WASPADA" ? "Aktivitas tidak biasa: hati-hati pasang order dekat harga sekarang." : "Tidak ada lonjakan tidak biasa."}</div>`;
  const zones = a.zones.map((z) => `<tr><td>${z.side === "BAWAH" ? "⬇️" : "⬆️"} ${esc(z.kind)}</td><td class="num">${pxTxt(z.level)} <small>${pct(z.dist_pct)}</small></td>
      <td class="num"><b>${pxTxt(Math.min(z.from, z.to))} – ${pxTxt(Math.max(z.from, z.to))}</b></td><td class="hint">${esc(z.note)}</td></tr>`).join("");
  const thin = a.thin.map((t) => `<li>${pxTxt(t.lo)} – ${pxTxt(t.hi)} <small>(${pct(t.from_pct)} … ${pct(t.to_pct)})</small></li>`).join("");
  const van = a.spoof.vanished.map((v) => `<li>${sideTag(v.side)} ${pxTxt(v.price)} · ${usdtTxt(v.usdt)} USDT · hilang ±${Math.round(v.ago_s)} dtk lalu saat harga mendekat (${pct(v.dist_pct)})</li>`).join("");
  const sl = (k, t) => `<div class="conc-reg"><h4>${t}</h4><p><b class="neg">${pxTxt(a[k].sl)}</b>${cpB(a[k].sl)} <small>(${pct(a[k].pct)})</small></p>
      <ul class="hint">${a[k].reasons.map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div>`;
  return `<h4>🛡️ Anti gocekan <span class="hint">supaya SL tidak kena sapu harga yang tiba-tiba naik / turun lalu balik</span></h4>
    ${alarm}
    <div class="wh-cards">
      <div class="conc-reg"><h4>📊 Backtest gocekan (candle 15M koin ini)</h4>
        <p>Dari <b>${bt.sweeps}</b> kali swing high/low ditembus ekor candle, <b>${bt.fake_pct == null ? "—" : bt.fake_pct.toFixed(0) + "%"}</b> cuma gocekan
          (close balik ke dalam ≤ 4 candle), ${bt.real} tembus beneran.</p>
        <p>Kedalaman tembus gocekan: 50% ≤ <b>${bt.p50 == null ? "—" : bt.p50.toFixed(2)}</b> ATR · 80% ≤ <b>${bt.p80 == null ? "—" : bt.p80.toFixed(2)}</b> ATR ·
          90% ≤ <b>${bt.p90 == null ? "—" : bt.p90.toFixed(2)}</b> ATR <small>(ATR 15M = ${pxTxt(a.atr15)})</small></p>
        <p class="hint">Artinya: SL yang ditaruh lebih dekat dari ${a.pen_atr.toFixed(2)} ATR di balik swing rawan disapu.</p></div>
      ${sl("sl_long", "🟢 SL anti-gocekan LONG")}${sl("sl_short", "🔴 SL anti-gocekan SHORT")}
    </div>
    <h4>🪤 Zona gocekan (tempat SL trader menumpuk) <span class="hint">jangan taruh SL di dalam rentang ini</span></h4>
    ${zones ? `<div class="scroll"><table class="tbl"><tr><th>Zona</th><th class="num">Level</th><th class="num">Rentang sapuan</th><th>Kenapa</th></tr>${zones}</table></div>` : '<p class="hint">Tidak ada swing / angka bulat dekat harga.</p>'}
    <div class="wh-cards">
      <div class="conc-reg"><h4>🕳️ Zona tipis (harga bisa loncat cepat)</h4>${thin ? `<ul>${thin}</ul><p class="hint">Antrean order di sini kurang dari 25% rata-rata. Kalau harga masuk ke sini, gerak bisa cepat dan jauh; jangan taruh SL / limit di tengahnya.</p>` : '<p class="hint">Tidak ada area kosong dalam ±5%: order book cukup rapat.</p>'}</div>
      <div class="conc-reg"><h4>👻 Tembok palsu (spoofing)</h4>${van ? `<ul>${van}</ul><p class="hint">Tembok ini muncul lalu ditarik saat harga mendekat. Jangan jadikan patokan SL.</p>` :
        `<p class="hint">${a.spoof.snapshots < 2 ? "Butuh minimal 2 scan untuk membandingkan. Nyalakan <b>Auto refresh</b> (30 dtk / 1 mnt) supaya tembok yang ditarik ketahuan." : "Belum ada tembok yang ditarik saat harga mendekat."}</p>`}
        <p class="hint">Di tabel support/resistance: <b>✅ n×</b> = tembok terlihat di n scan berturut-turut (lebih bisa dipercaya), <b>baru</b> = baru muncul.</p></div>
    </div>`;
}
// ---- 🧪 cek entry user
function evHtml(ev, where) {
  if (!ev) return "";
  const L = evLines(ev);
  return `<h4>🌊 Elliott Wave & 🏅 kelas bukti <small class="hint">(${esc(where)}; info, tidak mengubah peluang di atas)</small></h4>
    <ul class="wh-checks">${L.map((x) => `<li style="color:${x.c}">${esc(x.t.trim())}</li>`).join("")}
    ${ev.ew_target ? `<li class="hint">🎯 Target gelombang berjalan (rasio Fibonacci umum): ${pxTxt(ev.ew_target)}</li>` : ""}</ul>`;
}
function renderEntryCheck(r) {
  const pct = (v) => `${v >= 0 ? "+" : ""}${v.toFixed(2)}%`;
  const ic = { ok: "✅", warn: "⚠️", bad: "❌" };
  const bt = r.backtest_trend.n >= 30 ? r.backtest_trend : r.backtest_all;
  const v = r.verdict, vcls = v === "PROFIT" ? "pos" : v === "LOSE" ? "neg" : "";
  const slFirst = r.prob == null ? null : 100 - r.prob;
  const edgeTxt = r.edge == null ? "" : r.edge >= 3 ? `Dengan RR 1:${r.rr.toFixed(2)} (butuh WR ${r.breakeven.toFixed(0)}%), entry ini <b class="pos">masih untung secara rata-rata</b> walau ${r.prob < 50 ? "lebih sering kena SL" : "sesekali kena SL"}.`
    : r.edge <= -3 ? `Dengan RR 1:${r.rr.toFixed(2)} (butuh WR ${r.breakeven.toFixed(0)}%), entry ini <b class="neg">rugi secara rata-rata</b>: perbaiki SL / TP / tunggu entry lebih baik.`
    : `Dengan RR 1:${r.rr.toFixed(2)} (butuh WR ${r.breakeven.toFixed(0)}%), entry ini <b>kira-kira impas</b>.`;
  return `<div class="conc-reg wh-check-res v-${vcls || "mid"}"><h4>🧪 Cek entry ${esc(r.symbol)} · ${r.side === "LONG" ? "🟢 LONG" : "🔴 SHORT"}</h4>
    <p>Entry <b>${pxTxt(r.entry)}</b> · SL <b class="neg">${pxTxt(r.sl)}</b> (${pct((r.sl / r.entry - 1) * 100)}) · TP <b class="pos">${pxTxt(r.tp)}</b>
      (${pct((r.tp / r.entry - 1) * 100)}) · RR 1:${r.rr.toFixed(2)} · harga sekarang ${pxTxt(r.price)}</p>
    ${entryStateHtml(r)}
    <div class="wh-verdict ${vcls}">${v === "PROFIT" ? "🟢 Lebih dominan kena TP (PROFIT)" : v === "LOSE" ? "🔴 Lebih dominan kena SL (LOSE)" : "⚪ 50 : 50"}
      <span>peluang TP duluan <b>${r.prob == null ? "—" : r.prob.toFixed(0) + "%"}</b> · SL duluan <b>${slFirst == null ? "—" : slFirst.toFixed(0) + "%"}</b></span></div>
    <div class="wh-split"><i style="width:${r.prob ?? 50}%"></i></div>
    <p>${edgeTxt}</p>
    <ul>
      <li>📊 <b>Backtest asli</b> (±${(r.bt_days || 0).toFixed(0)} hari candle ${esc(String(r.bt_tf || "15m").toUpperCase())} ${esc(r.symbol)}, entry di setiap candle dengan SL ${r.sl_pct.toFixed(2)}% & TP ${r.tp_pct.toFixed(2)}% yang sama,
        batas ${r.bt_limit_h ? r.bt_limit_h.toFixed(0) : "—"} jam per trade — yang belum kena TP dihitung tidak menang):
        semua kondisi <b>${r.backtest_all.wr == null ? "—" : r.backtest_all.wr.toFixed(0) + "%"}</b> kena TP duluan (${r.backtest_all.n} trade, ${r.backtest_all.open || 0} belum selesai);
        saat tren ${esc(r.trend_now)} seperti sekarang <b>${r.backtest_trend.wr == null ? "—" : r.backtest_trend.wr.toFixed(0) + "%"}</b> (${r.backtest_trend.n} trade).</li>
      ${(r.backtest_trend.wr || 0) > (WH.susWr || 85) ? `<li class="neg">⚠️ Hasil backtest sangat tinggi: kemungkinan pasar sedang satu arah kuat di periode ini. Jangan anggap pasti — cek juga TF lebih besar.</li>` : ""}
      <li>🐋 Penyesuaian dari whale & gocekan: <b class="${r.adj >= 0 ? "pos" : "neg"}">${r.adj >= 0 ? "+" : ""}${r.adj.toFixed(0)} poin</b> (detail di bawah).</li>
      ${r.hours_to_tp ? `<li>⏱️ Kalau kena TP, biasanya dalam ±${r.hours_to_tp < 1 ? Math.round(r.hours_to_tp * 60) + " menit" : r.hours_to_tp.toFixed(1) + " jam"} (median backtest).</li>` : ""}
    </ul>
    <h4>Cek satu per satu</h4>
    <ul class="wh-checks">${r.checks.map((x) => `<li>${ic[x.status]} ${esc(x.text)}</li>`).join("")}</ul>
    ${evHtml(r.evidence, "backtest koin ini saja")}
    ${suggestHtml(r)}
    <p class="hint">Peluang dasar dari backtest candle koin ini (bisa dibuktikan). Penyesuaian whale (maks ±12 poin) adalah perkiraan karena riwayat
      order book tidak tersedia. TP & SL tersentuh di candle yang sama dihitung kena SL.</p></div>`;
}
function entryStateHtml(r) {
  const st = r.state || {}, pct = (v) => `${v >= 0 ? "+" : ""}${v.toFixed(2)}%`;
  if (st.status === "running") {
    if (st.done) return `<div class="wh-alarm ${st.done === "TP" ? "normal" : "bahaya"}">${st.done === "TP" ? "🎯 Harga sekarang sudah melewati TP." : "🛑 Harga sekarang sudah melewati SL."} Cek apakah posisi kamu sudah tertutup.</div>`;
    const prog = Math.max(-100, Math.min(100, st.progress_pct));
    return `<div class="wh-state">📍 <b>Posisi sudah berjalan</b> · sekarang <b class="${st.pnl_pct >= 0 ? "pos" : "neg"}">${pct(st.pnl_pct)}</b> dari entry ·
      ${prog >= 0 ? `sudah <b>${prog.toFixed(0)}%</b> perjalanan ke TP` : `mundur <b>${(-prog).toFixed(0)}%</b> dari jarak TP (mendekati SL)`}.
      Peluang di bawah dihitung dari <b>harga sekarang</b> (${pxTxt(r.price)}) ke SL & TP.</div>`;
  }
  const f = st.fill || {};
  const ord = { limit: "LIMIT (menunggu harga datang)", stop: "STOP (menunggu breakout)", market: "hampir di harga sekarang" }[st.order] || st.order;
  return `<div class="wh-state">⏳ <b>Belum kena entry</b> · order ${ord}, entry ${pct(st.dist_pct)} dari harga sekarang ·
    peluang tersentuh dalam 24 jam <b>${f.fill_pct == null ? "—" : f.fill_pct.toFixed(0) + "%"}</b>${f.miss_pct != null ? ` · <b>${f.miss_pct.toFixed(0)}%</b> harga keburu kabur ke arah TP tanpa mengisi entry` : ""}
    ${f.bars_med ? ` · kalau tersentuh, biasanya dalam ±${(f.bars_med * 0.25).toFixed(1)} jam` : ""}.
    Peluang TP/SL di bawah dihitung <b>seandainya entry tersentuh</b>.</div>`;
}
function suggestHtml(r) {
  const g = r.suggest;
  if (!g) return "";
  const pct = (a, b) => `${((a / b - 1) * 100 >= 0 ? "+" : "")}${((a / b - 1) * 100).toFixed(2)}%`;
  const R = (v) => `${v >= 0 ? "+" : ""}${v.toFixed(2)} R`;
  if (g.none) return `<div class="conc-reg wh-sug"><h4>💡 Saran <span class="hint">RR minimal 1:${g.min_rr}</span></h4>
    <p>✅ <b>Setup kamu sudah yang terbaik</b> dari ${g.tried} kombinasi entry / SL / TP yang diuji: tidak ada yang peluang TP-nya
      ≥ ${g.user_wr.toFixed(0)}% <b>dan</b> rata-rata per trade-nya di atas ${R(g.user_exp)} sekaligus.</p>
    ${g.user_exp < 0 ? `<p class="neg">⚠️ Tapi setup kamu sendiri rata-rata masih rugi (${R(g.user_exp)}) — lebih baik tunggu setup lain.</p>` : ""}</div>`;
  if (g.same) return `<div class="conc-reg"><h4>💡 Saran</h4><p>Entry, SL, dan TP kamu sudah sesuai — tidak ada saran perubahan.</p></div>`;
  return `<div class="conc-reg wh-sug"><h4>💡 Saran entry, SL, TP yang lebih baik <span class="hint">RR minimal 1:${g.min_rr} · harus lebih baik di peluang TP & rata-rata per trade</span></h4>
    <table class="tbl"><tr><th></th><th class="num">Punyamu</th><th class="num">Saran</th></tr>
      <tr><td>Entry</td><td class="num">${pxTxt(r.entry)}</td><td class="num"><b>${pxTxt(g.entry)}</b>${cpB(g.entry)} <small>${pct(g.entry, r.price)} dari harga</small></td></tr>
      <tr><td>SL</td><td class="num neg">${pxTxt(r.sl)}</td><td class="num neg"><b>${pxTxt(g.sl)}</b>${cpB(g.sl)} <small>${pct(g.sl, g.entry)}</small></td></tr>
      <tr><td>TP</td><td class="num pos">${pxTxt(r.tp)}</td><td class="num pos"><b>${pxTxt(g.tp)}</b>${cpB(g.tp)} <small>${pct(g.tp, g.entry)}</small></td></tr>
      <tr><td>RR</td><td class="num">1:${r.rr_plan.toFixed(2)}</td><td class="num">1:${g.rr.toFixed(2)}</td></tr>
      <tr><td>Peluang TP duluan <small class="hint">(backtest mentah)</small></td><td class="num">${g.user_wr.toFixed(0)}%</td>
        <td class="num"><b class="pos">${g.wr.toFixed(0)}%</b> <small>backtest ${g.n} trade</small></td></tr>
      <tr><td>Rata-rata hasil per trade <small class="hint">(WR × RR − kalah, dalam R)</small></td>
        <td class="num ${g.user_exp >= 0 ? "pos" : "neg"}">${R(g.user_exp)}</td><td class="num ${g.exp_r >= 0 ? "pos" : "neg"}"><b>${R(g.exp_r)}</b></td></tr>
      <tr><td>Peluang entry tersentuh 24 jam</td><td class="num">${r.state.fill && r.state.fill.fill_pct != null ? r.state.fill.fill_pct.toFixed(0) + "%" : "—"}</td>
        <td class="num">${g.fill_pct == null ? "—" : g.fill_pct.toFixed(0) + "%"}</td></tr></table>
    <ul class="hint">${g.why.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
    <p>✅ Peluang TP <b class="pos">${g.wr - g.user_wr >= 0 ? "+" : ""}${(g.wr - g.user_wr).toFixed(0)} poin</b> dan rata-rata <b class="pos">${(g.exp_r - g.user_exp).toFixed(2)} R lebih baik</b> per trade.</p>
    ${g.exp_r < 0 ? `<p class="neg">⚠️ Saran ini lebih baik dari punyamu, tapi rata-rata <b>masih rugi</b> (${R(g.exp_r)}) di backtest — lebih aman tunggu setup lain / cari koin lain di 🎯 Cari setup terbaik.</p>` : ""}
    <button class="mini" id="whUseSug">Pakai saran ini</button></div>`;
}
// ---------------------------------------------------------------- ⚙️ threshold whale / cari setup
async function loadWhaleCfg() {
  try {
    const j = await (await fetch("/api/whales/config")).json();
    WH.cfg = j; renderWhaleCfg();
  } catch (e) { /* abaikan: pakai default di server */ }
}
function renderWhaleCfg() {
  const j = WH.cfg; if (!j || !$("whCfgForm")) return;
  const v = j.values;
  let changed = 0;
  $("whCfgForm").innerHTML = j.sections.map((sec) => `<h5 class="wh-cfg-h">${esc(sec.title)}</h5><div class="wh-cfg-grid">` + sec.fields.map((f) => {
    const diff = String(v[f.key]) !== String(f.default); if (diff) changed++;
    const tip = esc((f.help ? f.help + " " : "") + "Default: " + f.default);
    const inp = f.choices
      ? `<select data-k="${f.key}">${f.choices.map((c) => `<option value="${esc(String(c))}" ${String(c) === String(v[f.key]) ? "selected" : ""}>${esc(String(c))}</option>`).join("")}</select>`
      : `<input type="number" data-k="${f.key}" value="${v[f.key]}" min="${f.min}" max="${f.max}" step="${f.step}">`;
    return `<label class="wh-cfg-row ${diff ? "wh-cfg-diff" : ""}" title="${tip}"><span>${esc(f.label)}${f.help ? ' <small class="hint">ⓘ</small>' : ""}</span>${inp}</label>`;
  }).join("") + "</div>").join("");
  $("whCfgCount").textContent = changed ? `(${changed} diubah dari default)` : "(semua default)";
  if (j.values["bt.suspicious_wr"] != null) WH.susWr = j.values["bt.suspicious_wr"];
}
async function saveWhaleCfg(reset) {
  const values = {};
  document.querySelectorAll("#whCfgForm [data-k]").forEach((el) => { values[el.dataset.k] = el.value; });
  const r = await fetch("/api/whales/config", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(reset ? { reset: true } : { values }) });
  const j = await r.json();
  if (!r.ok) return toast("Gagal menyimpan: " + (j.detail || r.statusText));
  WH.cfg.values = j.values; renderWhaleCfg();
  const fixed = Object.keys(values).filter((k) => !reset && String(values[k]) !== "" && +values[k] !== +j.values[k] && String(values[k]) !== String(j.values[k]));
  toast(reset ? "Threshold dikembalikan ke default" : "Threshold disimpan — berlaku untuk scan / cek berikutnya" +
    (fixed.length ? ` (${fixed.length} angka di luar batas aman disesuaikan)` : ""));
}
async function runEntryCheck() {
  if ($("whMode").value !== "one") {                     // cek entry selalu untuk 1 koin: pindah ke mode 1 koin otomatis
    if ($("whChkSym").value.trim()) $("whSym").value = $("whChkSym").value.trim();
    $("whMode").value = "one"; whModeChanged();
  }
  const sym = $("whSym").value.trim().toUpperCase(), e = +$("whEntry").value, sl = +$("whSL").value, tp = +$("whTP").value;
  const status = $("whStatus2").value, side = WH.side;
  if (!sym) return toast("Isi koin dulu");
  if (!status) { $("whStatus2").focus(); return toast("Pilih dulu: posisi kamu sudah berjalan atau belum kena entry?"); }
  if (!side) return toast("Pilih dulu arah posisi: BUY atau SELL");
  if (!(e > 0 && sl > 0 && tp > 0)) return toast("Isi entry, SL, dan TP");
  if (side === "BUY" && !(sl < e)) return toast("BUY: SL harus DI BAWAH entry");
  if (side === "BUY" && !(tp > e)) return toast("BUY: TP harus DI ATAS entry");
  if (side === "SELL" && !(sl > e)) return toast("SELL: SL harus DI ATAS entry");
  if (side === "SELL" && !(tp < e)) return toast("SELL: TP harus DI BAWAH entry");
  if (WH.busy) return;
  WH.busy = true;
  $("whCheck").disabled = true;
  $("whLive").classList.remove("hidden");
  $("whTitle").innerHTML = `Menganalisa entry ${esc(sym)}<span class="dots"></span>`;
  $("whPct").textContent = "0"; $("whBar").style.width = "5%";
  store.set("whCheckForm", { e, sl, tp, minrr: $("whMinRR").value, side });
  try {
    const r = await fetch("/api/whales/check", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol: sym, entry: e, sl, tp, status, side, min_usdt: Math.max(1000, +$("whMin").value || 100000),
        min_rr: Math.max(0.5, +$("whMinRR").value || 2) }) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    let st;
    for (;;) {
      st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      const pct = st.total ? (100 * st.done) / st.total : 5;
      $("whPct").textContent = Math.floor(pct); $("whBar").style.width = Math.max(pct, 5) + "%";
      $("whElapsed").textContent = fmtDur(st.elapsed);
      if (st.status !== "running") break;
      await new Promise((ok) => setTimeout(ok, 400));
    }
    if (st.status === "error") throw new Error(st.error);
    WH.coin = st.result.coin;
    WH.check = st.result;
    renderWhaleCoin();
    if ($("whUseSug")) $("whUseSug").onclick = () => {
      const g = WH.check.suggest, d = (v) => +(+v).toPrecision(6);
      $("whEntry").value = d(g.entry); $("whSL").value = d(g.sl); $("whTP").value = d(g.tp);
      toast("Saran dipasang ke form. Klik Cek entry lagi untuk melihat hasilnya.");
    };
    $("whStatus").textContent = `Cek entry ${st.result.symbol} selesai ${new Date().toLocaleTimeString()}`;
  } catch (err) {
    $("whStatus").innerHTML = `<span class="neg">Gagal: ${esc(err.message)}</span>`;
  } finally {
    WH.busy = false;
    $("whCheck").disabled = false;
    setTimeout(() => $("whLive").classList.add("hidden"), 600);
  }
}
function renderWhaleCoin() {
  const r = WH.coin;
  if (!r) return;
  const pct = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(2)}%`);
  const usd = (v) => (v == null ? "lebih dari order book yang terbaca" : usdtTxt(v) + " USDT");
  const maxH = Math.max(1, ...r.heat.map((h) => Math.max(h.bid, h.ask)));
  const heat = [...r.heat].reverse().map((h) => {
    const here = h.from_pct <= 0 && h.to_pct > 0;
    const thin = r.anti && r.anti.thin.some((t) => h.from_pct >= t.from_pct - 1e-9 && h.to_pct <= t.to_pct + 1e-9);
    return `<div class="wh-hrow ${here ? "here" : ""} ${thin ? "thin" : ""}" title="${thin ? "zona tipis: harga bisa loncat cepat" : ""}"><span class="wh-hpx">${pxTxt(h.lo)} <small>${pct(h.from_pct)}</small></span>
      <span class="wh-hbar bid"><i style="width:${(100 * h.bid) / maxH}%"></i><b class="v">${h.bid >= r.min_usdt ? usdtTxt(h.bid) : ""}</b></span>
      <span class="wh-hbar ask"><i style="width:${(100 * h.ask) / maxH}%"></i><b class="v">${h.ask >= r.min_usdt ? usdtTxt(h.ask) : ""}</b></span></div>`;
  }).join("");
  const wallRows = (arr) => arr.map((w, i) => `<tr><td>${i + 1}</td><td>${sideTag(w.side)}</td><td class="num">${pxTxt(w.price)}</td>
      <td class="num">${pct(w.dist_pct)}</td><td class="num"><b>${usdtTxt(w.usdt)}</b></td>
      <td class="num">${w.power_pct == null ? "—" : w.power_pct.toFixed(1) + "%"}</td><td class="num"><b>${w.impact_pct.toFixed(2)}%</b></td>
      <td>${(w.seen || 1) >= 2 ? `<span class="badge pass">✅ ${w.seen}×</span>` : '<span class="badge">baru</span>'}</td></tr>`).join("");
  const tradeRows = (arr) => arr.map((t, i) => `<tr><td>${i + 1}</td><td>${sideTag(t.side)}</td><td class="num">${pxTxt(t.price)}</td>
      <td class="num"><b>${usdtTxt(t.usdt)}</b></td><td class="num">${t.x_vol_min == null ? "—" : t.x_vol_min.toFixed(1) + "×"}</td>
      <td class="num"><b>${t.impact_pct.toFixed(2)}%</b></td><td>${new Date(t.time).toLocaleString("id-ID")}</td></tr>`).join("");
  const wallHead = '<tr><th>#</th><th>Sisi</th><th class="num">Harga</th><th class="num">Jarak</th><th class="num">Nilai</th><th class="num">Kekuatan</th><th class="num">Dampak</th><th>Asli?</th></tr>';
  const tradeHead = '<tr><th>#</th><th>Sisi</th><th class="num">Harga</th><th class="num">Nilai</th><th class="num">× vol/menit</th><th class="num">Dampak</th><th>Waktu</th></tr>';
  const tbl = (head, rows, empty) => (rows ? `<div class="scroll"><table class="tbl">${head}${rows}</table></div>` : `<p class="hint">${empty}</p>`);
  const tb = r.trade_buy + r.trade_sell, bk = r.book_bid2 + r.book_ask2;
  $("whCount").textContent = `(${r.symbol})`;
  $("whOut").innerHTML = `${WH.setups ? `<div class="wh-back"><button class="mini" id="whBackSetups">← Kembali ke hasil scan setup (${WH.setups.setups.length} setup)</button>
      <span class="hint">hasil scan disimpan, tidak perlu scan ulang</span></div>` : ""}
    <div class="wh-head"><h3>${symCell(r.symbol)} <span class="hint">${pxTxt(r.price)} · 24 jam <span class="${r.chg_24h >= 0 ? "pos" : "neg"}">${pct(r.chg_24h)}</span>
      · volume ${usdtTxt(r.vol_24h)} USDT · ${r.n_trades.toLocaleString("id-ID")} transaksi dibaca</span></h3></div>
    ${WH.check && WH.check.symbol === r.symbol ? renderEntryCheck(WH.check) : ""}
    <div class="conc-reg"><h4>🧾 Kesimpulan</h4><ul>${r.lines.map((l) => `<li>${esc(l)}</li>`).join("")}</ul></div>
    ${antiGocekHtml(r)}
    ${whalePlanHtml(r)}
    <div class="wh-cards">
      <div class="conc-reg"><h4>⚖️ Transaksi whale (market)</h4>
        <div class="wh-split"><i style="width:${tb ? (100 * r.trade_buy) / tb : 50}%"></i></div>
        <p><span class="pos">BELI ${usdtTxt(r.trade_buy)}</span> · <span class="neg">JUAL ${usdtTxt(r.trade_sell)}</span> · selisih
          <b class="${r.trade_buy >= r.trade_sell ? "pos" : "neg"}">${usdtTxt(Math.abs(r.trade_buy - r.trade_sell))}</b></p></div>
      <div class="conc-reg"><h4>📚 Order book ±2%</h4>
        <div class="wh-split"><i style="width:${bk ? (100 * r.book_bid2) / bk : 50}%"></i></div>
        <p><span class="pos">antre BELI ${usdtTxt(r.book_bid2)}</span> · <span class="neg">antre JUAL ${usdtTxt(r.book_ask2)}</span></p></div>
      <div class="conc-reg"><h4>🚀 USDT untuk menggerakkan harga</h4><table class="tbl"><tr><th>Gerak</th><th class="num">Naik (market buy)</th><th class="num">Turun (market sell)</th></tr>
        ${Object.entries(r.move).sort((a, b) => parseFloat(a[0]) - parseFloat(b[0])).map(([p, m]) => `<tr><td>${p}%</td><td class="num">${usd(m.up)}</td><td class="num">${usd(m.down)}</td></tr>`).join("")}</table></div>
    </div>
    <h4>🗺️ Peta likuiditas ±5% <span class="hint">hijau = antrean BELI (support), merah = antrean JUAL (resistance) · garis tebal = harga sekarang</span></h4>
    <div class="wh-heat">${heat}</div>
    <div class="wh-cards">
      <div><h4>🟢 Support whale (tembok BELI terbesar)</h4>${tbl(wallHead, wallRows(r.supports), "Tidak ada tembok BELI yang lolos filter.")}</div>
      <div><h4>🔴 Resistance whale (tembok JUAL terbesar)</h4>${tbl(wallHead, wallRows(r.resistances), "Tidak ada tembok JUAL yang lolos filter.")}</div>
    </div>
    <h4>💰 Transaksi whale terbesar</h4>${tbl(tradeHead, tradeRows(r.biggest_trades), "Tidak ada transaksi besar yang lolos filter.")}
    <h4>⚡ Transaksi whale terbaru</h4>${tbl(tradeHead, tradeRows(r.trades), "Tidak ada transaksi besar yang lolos filter.")}`;
}
$("whChkSym").addEventListener("input", () => { $("whSym").value = $("whChkSym").value; });
$("whSym").addEventListener("input", () => { $("whChkSym").value = $("whSym").value; });
function whModeChanged() {
  const one = $("whMode").value === "one";
  document.querySelectorAll(".wh-one").forEach((e) => e.classList.toggle("hidden", !one));
  document.querySelectorAll(".wh-all").forEach((e) => e.classList.toggle("hidden", one));
  if (one && !$("whSym").value && S.info) $("whSym").value = S.info.symbol;
  $("whChkSym").value = $("whSym").value || $("whChkSym").value || (S.info ? S.info.symbol : "");
  $("whRun").textContent = one ? "Analisa whale koin ini" : "Lacak whale";
}
// ---- 🎯 cari setup terbaik di banyak koin (RR diatur user)
// kartu visual entry untuk 1 setup 🎯 (mesin gambar sama dengan Screener Market Structure)
// 🧭 flow whale per setup (info) + teks
function flowTxt(f) {
  if (!f) return null;
  const arah = f.lean > 0 ? "condong NAIK" : f.lean < 0 ? "condong TURUN" : "netral";
  return { t: `🧭 Flow whale ${f.tf ? f.tf.toUpperCase() : ""}: ${arah} → ${f.agree === "agree" ? "searah setup ✓" : f.agree === "against" ? "MELAWAN setup ⚠" : "tidak memberi arah"}${f.verdict && f.verdict.conflict ? " (sinyal flow bertentangan)" : ""}`,
    c: f.agree === "agree" ? "#36e3a1" : f.agree === "against" ? "#ff8a8a" : "#c9d1db" };
}
function whSpec(s) {
  if (!s || !s.candles || s.candles.length < 2) return null;
  const long = s.side === "BUY", mk = /^market/i.test(s.how || "");
  const last = s.candles[s.candles.length - 1];
  const R = { symbol: s.symbol, tf: "15m", icon: "🐋", sub: "Whale · 🎯 Cari setup terbaik", candles: s.candles, nbar: 80, proj: s.proj || null,
    now_time: last[0] + 15 * 60000, now_price: s.price,
    walls: (s.walls_vis || []).map((w) => ({ price: w.price, color: w.side === "BUY" ? "#22d3ee" : "#f472b6",
      label: `tembok ${w.side === "BUY" ? "BELI" : "JUAL"} ${usdtTxt(w.usdt)} USDT` })),
    boxes: [["ENTRY", pxTxt(s.entry), "#60a5fa", esc(s.how).slice(0, 34)],
      ["STOP LOSS", pxTxt(s.sl), "#ff6b73", `risiko ${s.sl_pct.toFixed(2)}% · anti-gocekan`],
      ["TAKE PROFIT", pxTxt(s.tp), "#36e3a1", `RR 1:${s.rr} · +${s.tp_pct.toFixed(2)}%`],
      ["ENTRY TERSENTUH 24J", s.fill_pct == null ? "—" : `${s.fill_pct.toFixed(0)}%`, "#e6ebf2", mk ? "entry di harga sekarang" : "peluang limit terisi"],
      ["BACKTEST", `${s.wr.toFixed(0)}% WR · ${s.exp_r >= 0 ? "+" : ""}${s.exp_r.toFixed(2)}R`, s.exp_r > 0 ? "#e6ebf2" : "#ff6b73",
        s.exp_test != null ? `uji 30% terakhir ${s.exp_test >= 0 ? "+" : ""}${s.exp_test.toFixed(2)}R ${s.proven ? "✓" : "⚠"}` : `${s.n} trade · TF ${String(s.bt_tf || "").toUpperCase()}`]],
    footer: `Tren ${s.regime || "?"}${s.aligned ? " (searah ✓)" : " (tidak searah)"}${s.blocked ? ` · tembok lawan di ${s.blocked}` : ""}${s.alarm && s.alarm !== "NORMAL" ? ` · alarm ${s.alarm}` : ""} · garis ungu/pink = tembok order whale`,
    lines: [`Backtest: ${s.n} trade · WR ${s.wr.toFixed(0)}% · ${s.exp_r >= 0 ? "+" : ""}${s.exp_r.toFixed(2)}R/trade · entry tersentuh 24j ${s.fill_pct == null ? "—" : s.fill_pct.toFixed(0) + "%"}`,
      `Tren ${s.regime || "?"}${s.aligned ? " (searah)" : " (tidak searah)"}${s.blocked ? ` · tembok lawan di ${s.blocked}` : ""}`] };
  const okS = s.usable != null ? s.usable : s.exp_r > 0, pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), r2 = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(2)}R`);
  R.insights = [
    { t: `🎯 ${long ? "BUY" : "SELL"} ${mk ? "MARKET" : "LIMIT"} ${pxTxt(s.entry)} · SL ${pxTxt(s.sl)} (anti-gocekan, ${s.sl_pct.toFixed(2)}%) · TP ${pxTxt(s.tp)} (1:${s.rr}) · entry tersentuh 24 jam ${pc(s.fill_pct)}`, c: "#e6ebf2", b: true },
    { t: `📊 Backtest ${s.n} trade (TF ${String(s.bt_tf || "").toUpperCase()}): WR ${pc(s.wr)} · ${r2(s.exp_r)}/trade · 30% data terakhir: ${s.exp_test == null ? "—" : `WR ${pc(s.wr_test)} · ${r2(s.exp_test)} (${s.n_test} trade)`} ${s.proven ? "✓ terbukti" : "⚠ belum terbukti"}`,
      c: s.proven && s.exp_r > 0 ? "#36e3a1" : "#f5c451" },
    heavyLine(s, `backtest ${s.n} trade`),
    ...evLines(s.evidence),
    paLine(R),
    flowTxt(s.flow),
    { t: `🧭 Tren ${s.regime || "?"}${s.aligned ? " (searah ✓)" : " (tidak searah ⚠)"}${s.blocked ? ` · tembok lawan di ${s.blocked} (bisa menahan harga sebelum TP)` : ""}${s.alarm && s.alarm !== "NORMAL" ? ` · alarm ${s.alarm}` : ""}`, c: "#c9d1db" },
    okS ? { t: `✅ Kesimpulan: rata-rata untung — boleh dipasang, SL wajib.${s.proven === false ? " (info: belum terbukti di 30% data terakhir)" : ""}${s.fill_ok === false ? ` (info: entry jarang tersentuh ${s.fill_pct == null ? "" : s.fill_pct.toFixed(0) + "%"})` : ""}${s.flow && s.flow.agree === "against" ? " (info: flow whale sekarang melawan)" : ""}`, c: "#36e3a1", b: true }
      : { t: `⏳ Kesimpulan: JANGAN dipasang — ${s.why_not || "rata-rata rugi"}.`, c: "#ff8a8a", b: true }];
  const B = { dir: long ? 0 : 1, price_entry: s.entry, price_sl: s.sl, price_tp: s.tp, rr: s.rr, entry: mk ? "market" : "limit",
    entry_txt: s.how, risk_pct: s.sl_pct, live: s.usable != null ? s.usable : s.exp_r > 0,
    usable: s.usable != null ? s.usable : s.exp_r > 0, why_not: s.why_not, fill_ok: s.fill_ok, profit_ok: s.exp_r > 0 && s.proven !== false,
    status: (s.usable != null ? s.usable : s.exp_r > 0) ? (mk ? "aktif · entry market sekarang" : "aktif · pasang limit") : `${s.why_not || "rata-rata rugi"} · jangan dipasang` };
  return { R, B };
}
function whCardHtml() {
  const L = WH.setups && WH.setups.setups;
  if (!L || !L.length) return "";
  const i = Math.min(WH.setSel || 0, L.length - 1), sp = whSpec(L[i]);
  if (!sp) return "";
  return `<div class="msc-out wh-vis"><div class="msc-card">${MSC.card(sp.R, sp.B, false)}</div>
    <div class="msc-btns">${L.map((s, k) => `<button class="mini wh-vsel${k === i ? " on" : ""}" data-i="${k}">${k + 1}. ${esc(s.symbol.replace(/USDT$/, ""))} ${s.side === "BUY" ? "🟢" : "🔴"} 1:${s.rr}</button>`).join("")}
      <span style="flex:1"></span><button class="mini wh-vcopy" data-i="${i}">📋 Salin sinyal</button><button class="mini wh-vdl" data-i="${i}">⬇ Unduh gambar</button></div></div>`;
}
function flowTestHtml(ft) {
  if (!ft) return "";
  if (ft.error) return `<p class="hint">🧭 Flow whale gagal dibaca: ${esc(ft.error)}</p>`;
  const o = ft.overall, pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), c = (p, k) => `${pc(o[p][k].wr)} <small>(${o[p][k].n})</small>`;
  return `<div class="wh-flowtest ${o.helps ? "pass" : ""}">🧭 <b>Uji gabungan flow</b> (trade backtest setup yang tampil, saat data flow tersedia):
    WR saat flow <b>searah</b> ${c("test", "agree")} vs <b>melawan</b> ${c("test", "against")} di 30% waktu terakhir ·
    data cari: ${c("fit", "agree")} vs ${c("fit", "against")} → <b>${esc(o.verdict)}</b>${o.helps ? " — flow searah lebih sering menang (info)" : ""} · <b>flow hanya INFO, tidak menyaring setup</b>.
    <small class="hint">Cara membaca flow dipelajari dari 70% waktu awal saja. Trade backtest diambil tiap candle (tumpang tindih), jadi jumlahnya terlihat besar.</small></div>`;
}
function gradeBadge(ev, done) {
  if (!ev) return done ? "—" : `<small class="hint">menghitung…</small>`;
  if (ev.n_items == null) return `<small class="hint" title="${esc(ev.note || "")}">—</small>`;
  const g = ev.grade, cls = { A: "pass", C: "fail" }[g] || "";
  return g ? `<span class="badge ${cls}" title="${ev.agree} bukti searah · ${ev.against} melawan">${g}</span> <small>${ev.agree}/${ev.n_items}</small>`
    : `<small class="hint" title="${esc(ev.note || "")}">— ${ev.agree}/${ev.n_items}</small>`;
}
function renderSetups() {
  const R = WH.setups;
  if (!R) return;
  const pct = (v) => `${v >= 0 ? "+" : ""}${v.toFixed(2)}%`;
  const rrTxt = R.rrs.map((x) => "1:" + x).join(" / ");
  const ok = (s) => (s.usable != null ? s.usable : s.exp_r > 0);
  const rows = R.setups.map((s, i) => `<tr class="${ok(s) ? "" : "muted-row"}"><td>${i + 1}</td><td>${symCell(s.symbol)}</td><td>${sideTag(s.side)}</td>
      <td class="num"><b>1:${s.rr}</b><br><small>impas ${(100 / (1 + s.rr)).toFixed(0)}%</small></td>
      <td class="num"><b>${pxTxt(s.entry)}</b>${cpB(s.entry)}<br><small>${esc(s.how)}</small></td>
      <td class="num neg">${pxTxt(s.sl)}${cpB(s.sl)}<br><small>${pct(-s.sl_pct * (s.side === "BUY" ? 1 : -1))}</small></td>
      <td class="num pos">${pxTxt(s.tp)}${cpB(s.tp)}<br><small>${pct(s.tp_pct * (s.side === "BUY" ? 1 : -1))}</small></td>
      <td class="num"><b>${s.wr.toFixed(0)}%</b>${s.too_good ? " ⚠️" : ""}<br><small>${s.n} trade · ${esc(String(s.bt_tf || "").toUpperCase())}</small>
        ${s.n_moves != null ? `<br><small title="Trade yang tidak tumpang tindih (1 posisi sekali jalan): jumlah pergerakan harga yang benar-benar berbeda">${s.n_moves} gerak beda</small>` : ""}
        ${s.bt_kind === "limit" ? '<br><small class="hint" title="Backtest dimulai saat harga benar-benar menyentuh harga limit">uji: saat limit tersentuh</small>' : ""}
        ${s.trend_mixed ? '<br><small class="warn" title="Trade dengan kondisi tren sama seperti sekarang kurang dari sampel minimal, jadi backtest memakai semua candle (naik &amp; turun dicampur)">⚠ tren campur</small>' : ""}</td>
      <td class="num"><b class="${s.exp_r > 0 ? "pos" : "neg"}">${s.exp_r >= 0 ? "+" : ""}${s.exp_r.toFixed(2)} R</b>
        ${s.exp_test != null ? `<br><small class="${s.exp_test > 0 ? "pos" : "neg"}">uji ${s.exp_test >= 0 ? "+" : ""}${s.exp_test.toFixed(2)} R (${s.n_test})</small>` : ""}
        ${s.max_loss_streak != null ? `<br><small title="Kalah beruntun terpanjang · drawdown terdalam (urut waktu)">😓 ${s.max_loss_streak}× · −${s.max_dd.toFixed(1)}R</small>` : ""}
        ${s.usable != null ? `<br>${s.usable ? '<span class="badge pass">✅ layak</span>' : `<span class="badge fail" title="${esc(s.why_not || "")}">⚠ ${esc(s.why_not || "")}</span>`}` : ""}</td>
      <td class="num">${s.fill_pct == null ? "—" : s.fill_pct.toFixed(0) + "%"}</td>
      <td>${gradeBadge(s.evidence, R.flow_test !== undefined || !R.partial)}</td>
      <td>${s.aligned ? '<span class="badge pass">searah</span>' : `<span class="badge fail">${esc(s.regime || "?")}</span>`}
        ${s.blocked ? `<br><small class="hint">tembok di ${esc(s.blocked)}</small>` : ""}${s.alarm !== "NORMAL" ? `<br><small class="neg">alarm ${esc(s.alarm)}</small>` : ""}</td>
      <td>${s.flow ? `${s.flow.lean > 0 ? "▲" : s.flow.lean < 0 ? "▼" : "↔"} ${s.flow.agree === "agree" ? '<span class="badge pass">searah</span>' : s.flow.agree === "against" ? '<span class="badge fail">melawan</span>' : '<span class="badge">netral</span>'}` : R.flow_test ? "—" : `<small class="hint">menghitung…</small>`}</td>
      <td><button class="mini wh-vsel" data-i="${i}" title="Tampilkan kartu visual entry setup ini di atas">🖼 Visual</button>
        <button class="mini wh-setcheck" data-i="${i}">${WH.setDone && WH.setDone.has(i) ? "✓ Sudah dicek" : "Cek detail"}</button>
        <button class="mini wh-setex" data-i="${i}" title="Lihat entry-entry backtest-nya satu per satu &amp; buka di chart">🔍 Contoh trade</button></td></tr>`).join("");
  const keys = R.rrs.map((x) => String(x));
  const cmp = R.rrs.length > 1 ? R.compare.map((g) => `<tr><td>${symCell(g.symbol)}</td><td>${sideTag(g.side)}</td>
      ${keys.map((k) => { const v = g.rr[k]; if (!v) return "<td class='num'>—</td>";
        const best = k === g.best_rr;
        return `<td class="num ${best ? "wh-best" : ""}">${v.wr.toFixed(0)}%<br><b class="${v.exp_r > 0 ? "pos" : "neg"}">${v.exp_r >= 0 ? "+" : ""}${v.exp_r.toFixed(2)} R</b>${best ? " 🏆" : ""}</td>`; }).join("")}
      <td>${g.aligned ? '<span class="badge pass">searah</span>' : `<span class="badge fail">${esc(g.regime || "?")}</span>`}</td></tr>`).join("") : "";
  $("whCount").textContent = `(${R.setups.length} setup)`;
  $("whOut").innerHTML = whCardHtml() + (R.partial ? `<div class="wh-partial">⏳ <b>Hasil sementara</b> — scan masih berjalan (${R.scanned}/${R.target} koin). Urutan bisa berubah saat koin lain selesai dicek.</div>` : "") +
    `<h3>🎯 Setup terbaik · RR ${rrTxt} <span class="hint">${R.scanned} koin · ${R.n_usable != null ? `<b>${R.n_usable} layak dipasang</b> · ` : ""}${R.n_good} setup rata-rata untung${R.min_wr ? ` · WR ≥ ${R.min_wr}% (${R.n_shown} dari ${R.n_all})` : ""}</span></h3>
    ${flowTestHtml(R.flow_test)}
    ${R.n_usable === 0 && !R.partial ? `<div class="wh-alarm waspada">⏳ <b>JANGAN ENTRY DULU.</b> Tidak ada setup yang <b>rata-rata untung</b> di koin-koin ini sekarang — jangan dipaksakan. Setup di bawah hanya untuk dipelajari.</div>` : ""}
    ${R.only_aligned ? `<p class="hint">🧭 Hanya setup searah kondisi pasar${R.n_against ? ` · <b>${R.n_against}</b> setup melawan / sideways disembunyikan (tidak dicatat ke Jurnal)` : ""}.</p>` : ""}
    ${R.n_good ? "" : `<div class="wh-alarm waspada">⚠️ Tidak ada setup yang rata-rata untung${R.min_wr ? ` dengan WR ≥ ${R.min_wr}%` : ""} di koin-koin ini sekarang. Coba RR / Min. WR lain, arah lain, atau tunggu — jangan dipaksakan.</div>`}
    ${R.setups.some((s) => s.too_good) ? `<div class="wh-alarm waspada">⚠️ Ada setup dengan WR &gt; ${WH.susWr || 85}% (⚠️): biasanya karena pasar sedang satu arah kuat di periode backtest. Jangan dianggap pasti.</div>` : ""}
    <div class="scroll"><table class="tbl"><tr><th>#</th><th>Koin</th><th>Arah</th><th class="num">RR</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP</th>
      <th class="num">WR backtest</th><th class="num">Rata-rata / trade</th><th class="num">Entry tersentuh 24j</th><th title="Kelas A/B/C dari bukti tambahan (Elliott, D1, BTC sesuai korelasi, kekuatan vs BTC, sapuan likuiditas, sesi). Tidak menyaring setup.">🏅 Kelas</th><th>Tren</th><th title="Flow whale sekarang (OI, taker, long/short top trader, funding) dibanding arah setup">🧭 Flow</th><th></th></tr>${rows ||
      `<tr><td colspan="14" class="hint">Tidak ada setup dengan WR ≥ ${R.min_wr}%. Turunkan Min. WR atau pakai RR lebih kecil.</td></tr>`}</table></div>
    ${cmp ? `<h4>📊 Perbandingan RR per koin <span class="hint">WR &amp; rata-rata per trade tiap RR · 🏆 = RR terbaik koin itu (rata-rata × peluang entry tersentuh)</span></h4>
      <div class="scroll"><table class="tbl"><tr><th>Koin</th><th>Arah</th>${R.rrs.map((x) => `<th class="num">1:${x}<br><small>impas ${(100 / (1 + x)).toFixed(0)}%</small></th>`).join("")}<th>Tren</th></tr>${cmp}</table></div>` : ""}
    <p class="hint">WR dari backtest candle koin itu: SL &lt; 1.5% pakai ±15 hari candle 15M (batas 2 hari per trade), SL lebar pakai ±62 hari candle 1H (batas 5 hari);
      entry market di setiap candle / entry limit mulai saat harga menyentuh limit, jarak SL & TP sama, kondisi tren seperti sekarang ("⚠ tren campur" = sampel kurang, semua candle dipakai); TP & SL di candle sama = kalah; <b>belum kena TP dalam batas waktu = tidak menang</b>.
      <b>✅ Layak</b> (v4.33) = rata-rata untung <b>dan</b> untung di data cari (70% awal) <b>dan</b> di data uji (30% terakhir, cukup trade) <b>dan</b> cukup <b>gerak beda</b> (trade yang tidak tumpang tindih) <b>dan</b> WR tidak mencurigakan — bisa diatur di ⚙️ Threshold › Syarat setup layak.
      <b>Rata-rata / trade</b> = WR × RR − kalah, dalam R (risiko). RR kecil → WR tinggi tapi untung per menang kecil; RR besar → WR rendah tapi untung per menang besar.
      Diurutkan dari rata-rata × peluang entry tersentuh. Baris pudar = belum layak (alasannya di kolom rata-rata). Klik <b>Cek detail</b> untuk analisa lengkap,
      <b>🔍 Contoh trade</b> untuk melihat entry backtest-nya satu per satu.</p>
    <div id="whExBox"></div>`;
}
// ---- contoh kejadian 🎯 Cari setup: entry backtest satu setup (data terbaru Binance), klik untuk buka di Manual Replay
async function whShowTrades(i) {
  const s = WH.setups.setups[i], box = $("whExBox");
  box.innerHTML = `<h4>🔍 Contoh trade: ${esc(s.symbol)} ${esc(s.side)} RR 1:${s.rr}</h4><p class="hint">Mengambil data candle dari Binance…</p>`;
  box.scrollIntoView({ behavior: "smooth", block: "start" });
  try {
    const res = await fetch("/api/whales/setup_trades", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol: s.symbol, side: s.side, sl_pct: s.sl_pct, tp_pct: s.tp_pct,
        ...(s.bt_kind === "limit" ? { dist_pct: Math.abs(s.entry / s.price - 1) * 100, down: s.entry < s.price } : {}) }) });
    const j = await res.json();
    if (!res.ok) throw new Error(j.detail || res.statusText);
    WH.ex = j;
    const st = j.stats, list = j.trades.slice().reverse().slice(0, 150);
    const same = st.n === s.n && Math.abs((st.wr ?? 0) - s.wr) < 0.05;
    box.innerHTML = `<h4>🔍 Contoh trade: ${esc(s.symbol)} ${sideTag(s.side)} RR 1:${s.rr} · SL ${s.sl_pct.toFixed(2)}% · TP ${s.tp_pct.toFixed(2)}%</h4>
      <p class="hint">Backtest ${j.tf.toUpperCase()}: entry di close <b>setiap candle</b>${j.trend_filter ? " yang trennya sama seperti sekarang (EMA20 vs EMA50)" : ""}, batas ${j.max_bars} candle per trade.
        ${st.n} trade · menang ${st.wins} · kalah ${st.losses} · belum kena ${st.open} · WR ${st.wr == null ? "—" : st.wr.toFixed(1) + "%"}
        ${same ? "— sama dengan hasil scan." : `<span class="neg">— beda dengan hasil scan (WR ${s.wr.toFixed(1)}%, ${s.n} trade) karena candle baru sudah masuk sejak scan.</span>`}
        Ditampilkan ${list.length} terbaru. Klik baris untuk membuka di Manual Replay (butuh data lokal sampai tanggal itu).</p>
      <div class="scroll" style="max-height:420px"><table class="tbl"><tr><th>Waktu (UTC)</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP</th><th>Hasil</th><th>Selesai</th></tr>` +
      list.map((t, k) => `<tr data-whx="${j.trades.length - 1 - k}" title="Buka di chart"><td>${fmtTime(t.time).slice(0, 16)}</td><td class="num">${pxTxt(t.entry)}</td>
        <td class="num">${pxTxt(t.sl)}</td><td class="num">${pxTxt(t.tp)}</td>
        <td class="${t.result > 0 ? "pos" : t.result < 0 ? "neg" : ""}">${t.result > 0 ? "✅ TP" : t.result < 0 ? "❌ SL" : "⏱️ belum kena (dihitung tidak menang)"}</td>
        <td>${fmtTime(t.exit_time).slice(0, 16)}</td></tr>`).join("") + "</table></div>";
  } catch (err) {
    box.innerHTML = `<h4>🔍 Contoh trade: ${esc(s.symbol)}</h4><p class="neg">Gagal: ${esc(err.message)}</p>`;
  }
}
// ---- 🧭 flow whale: OI, taker, long/short top trader, funding (riwayat ±30 hari) vs arah normal
async function runFlow() {
  if (WH.busy) return toast("Masih ada proses whale yang berjalan, tunggu selesai dulu.");
  const sym = ($("whFlowSym").value || $("symbol").value || "").trim().toUpperCase();
  if (!sym) return toast("Isi koin dulu, mis. BTCUSDT");
  const body = { symbol: sym, tf: $("whFlowTf").value, coins: +$("whFlowCoins").value };
  store.set("whFlowForm", body);
  WH.busy = true; $("whFlowRun").disabled = true;
  $("whStatus").innerHTML = `Membaca flow whale ${esc(sym)}<span class="dots"></span>`;
  $("whOut").innerHTML = `<div class="card evalcard msc-empty"><h3>⏳ Flow whale ${esc(sym)} ${esc(body.tf.toUpperCase())}<span class="dots"></span></h3><p class="hint">Mengambil OI, taker, long/short &amp; funding ±30 hari dari Binance${body.coins ? ` untuk ${body.coins + 1} koin` : ""}.</p></div>`;
  try {
    const r = await fetch("/api/whales/flow", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    let st;
    for (;;) {
      st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (st.status !== "running") break;
      if (st.total) $("whStatus").innerHTML = `Mengambil data flow ${st.done}/${st.total} koin<span class="dots"></span>`;
      await new Promise((ok) => setTimeout(ok, 500));
    }
    if (st.status === "error") throw new Error(st.error);
    if (!st.result) throw new Error(`berhenti tanpa hasil (status: ${st.status})`);
    WH.flow = st.result;
    $("whStatus").textContent = `Flow whale ${WH.flow.symbol} · ${WH.flow.n_samples} sampel dari ${WH.flow.n_coins} koin · ${WH.flow.elapsed} dtk`;
    renderFlow();
  } catch (ex) {
    $("whStatus").textContent = "⚠️ " + ex.message;
    $("whOut").innerHTML = `<div class="card evalcard msc-empty"><h3>⚠️ Flow whale gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { WH.busy = false; $("whFlowRun").disabled = false; }
}
function flowSpec(F) {
  const b = F.best, cur = F.current || {}, now = F.now || {}, pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`);
  const sgn = (v, d = 2) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(d)}`);
  const short = (t) => (t || "—").replace(/^harga (naik|turun) \+ /, "").replace(/ \(.*\)$/, "");
  const badge = b ? { text: b.dir > 0 ? "▲ CONDONG NAIK" : "▼ CONDONG TURUN", color: b.dir > 0 ? "#16c784" : "#ea3943", status: "terbukti di 30% waktu terakhir", statusColor: "#16c784" }
    : F.conflict ? { text: "⚠ SINYAL BERTENTANGAN", color: "#f5a524", status: "jangan pakai flow sebagai arah" }
    : { text: "⏸ FLOW BELUM MEMBERI ARAH", color: "#8b96a5", status: "tidak ada sinyal yang unggul & terbukti" };
  const kes = b ? [`${b.dir > 0 ? "▲ Naik" : "▼ Turun"} ${pc(b.dir > 0 ? b.pct_up : b.pct_down)}`, b.dir > 0 ? "#36e3a1" : "#ff6b73",
      `normal ${pc(b.dir > 0 ? F.base.pct_up : F.base.pct_down)} · ${sgn(b.edge, 0)}% · ${b.edge_txt}`]
    : F.conflict ? ["⚠ Bertentangan", "#f5c451", "sinyal terbukti saling berlawanan"] : ["— Tidak unggul", "#8b96a5", `normal naik ${pc(F.base.pct_up)}`];
  const ins = F.rows.map((r) => ({
    t: `${r.proven ? "✓" : "·"} ${r.name}: ${r.state} → ${r.dir > 0 ? "naik" : "turun"} 2 ATR duluan ${pc(r.dir > 0 ? r.pct_up : r.pct_down)} (normal ${pc(r.dir > 0 ? F.base.pct_up : F.base.pct_down)}, ${sgn(r.edge, 0)}% ${r.edge_txt}; 30% terakhir ${r.edge_test == null ? "—" : sgn(r.edge_test, 0) + "%"}, ${r.n} sampel)`,
    c: r.proven && r.edge > 0 ? (r.dir > 0 ? "#36e3a1" : "#ff8a8a") : "#8b96a5", b: r.proven && r.edge > 0 }));
  ins.push(b ? { t: `✅ Kesimpulan: flow whale sekarang condong ${b.dir > 0 ? "NAIK" : "TURUN"} (${b.name}) — terbukti di data terbaru. Pakai sebagai penguat arah, bukan sinyal entry sendiri.`, c: "#36e3a1", b: true }
    : F.conflict ? { t: "⚠ Kesimpulan: sinyal flow yang terbukti saling bertentangan — jangan ambil arah dari flow sekarang.", c: "#f5c451", b: true }
    : { t: "⏸ Kesimpulan: tidak ada sinyal flow yang unggul DAN terbukti di 30% waktu terakhir — flow sekarang tidak memberi arah.", c: "#8b96a5", b: true });
  const R = { symbol: F.symbol, tf: F.tf, icon: "🐋", sub: "Whale · 🧭 Flow whale", candles: F.candles, nbar: 64,
    now_time: F.now_time, now_price: F.now_price, badge, insights: ins,
    footer: `${F.n_samples} sampel · ${F.n_coins} koin · ±${F.days} hari · hasil = ±${F.move_atr} ATR duluan dalam ${F.horizon} candle · perubahan dihitung ${F.window} candle`,
    boxes: [["OPEN INTEREST", cur.oi_chg == null ? "—" : `${sgn(cur.oi_chg)}%`, cur.oi_chg > 0 ? "#36e3a1" : "#ff6b73", short(now.oi)],
      ["TAKER BUY", cur.taker_buy == null ? "—" : `${cur.taker_buy.toFixed(1)}%`, (cur.taker_buy || 0) > 50 ? "#36e3a1" : "#ff6b73", now.taker || "—"],
      ["LONG/SHORT TOP", cur.ls == null ? "—" : cur.ls.toFixed(3), cur.ls_prev != null && cur.ls > cur.ls_prev ? "#36e3a1" : "#ff6b73", cur.ls_prev != null ? `sebelumnya ${cur.ls_prev.toFixed(3)}` : (now.ls || "—")],
      ["FUNDING", cur.funding == null ? "—" : `${sgn(cur.funding, 4)}%`, (cur.funding || 0) > 0 ? "#f5c451" : "#60a5fa", now.fr ? short(now.fr) : "—"],
      ["KESIMPULAN ARAH", kes[0], kes[1], kes[2]]],
    lines: ins.map((x) => x.t) };
  return R;
}
function renderFlow() {
  const F = WH.flow, R = flowSpec(F), pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), sg = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(1)}%`);
  $("whOut").innerHTML = `<div class="msc-out"><div class="msc-card">${MSC.card(R, null, false)}</div>
    <div class="msc-btns"><span style="flex:1"></span><button class="mini" id="whFlowCopy">📋 Salin hasil</button><button class="mini" id="whFlowDl">⬇ Unduh gambar</button></div>
    <details class="card evalcard msc-more"><summary><b>📄 Detail lengkap</b> <small class="hint">tabel sinyal &amp; cara baca</small></summary>
    ${F.errors && F.errors.length ? `<p class="hint">⚠️ Koin dilewati: ${F.errors.map(esc).join(" · ")}</p>` : ""}
    <div class="scroll"><table class="tbl"><tr><th>Sinyal</th><th>Keadaan sekarang</th><th class="num">Sampel</th><th class="num">Naik / turun duluan</th><th class="num">Keunggulan</th><th class="num">70% awal</th><th class="num">30% terakhir</th><th></th></tr>` +
      F.rows.map((r) => `<tr${F.best && r.name === F.best.name ? ' class="wh-best"' : ""}><td>${esc(r.name)}</td><td>${esc(r.state)}</td><td class="num">${r.n}</td>
        <td class="num">${pc(r.pct_up)} / ${pc(r.pct_down)}</td><td class="num ${r.edge > 0 ? "pos" : "neg"}">${sg(r.edge)} <small>${esc(r.edge_txt)}</small></td>
        <td class="num">${sg(r.edge_fit)}</td><td class="num">${sg(r.edge_test)} <small>(${r.n_test})</small></td><td>${r.proven && r.edge > 0 ? "✅ terbukti" : ""}</td></tr>`).join("") +
      `<tr><td><b>Normal</b> (semua sampel)</td><td>—</td><td class="num">${F.base.n}</td><td class="num">${pc(F.base.pct_up)} / ${pc(F.base.pct_down)}</td><td colspan="4"></td></tr></table></div>
    <ul class="hint"><li>Keadaan dihitung di candle yang sudah close, dari perubahan ${F.window} candle terakhir; sampel riwayat diambil tiap ${F.window} candle supaya tidak tumpang tindih.</li>
      <li><b>Keunggulan</b> = % arah mayoritas dikurangi % normal. <b>Terbukti</b> = keunggulan positif di 70% waktu awal <b>dan</b> 30% waktu terakhir (≥ 30 sampel, ≥ 10 di data uji).</li>
      <li>Kalau dua sinyal terbukti tapi arahnya berlawanan, tidak ada kesimpulan arah.</li>
      <li>Binance hanya menyimpan ±30 hari data OI / long-short, jadi sampelnya terbatas. Gunakan sebagai penguat arah, bukan sinyal entry sendiri.</li></ul></details></div>`;
}
// ---- 📼 perekam order book + uji tembok
const OBR = { st: null };
async function obRefresh() {
  try {
    const st = await (await fetch("/api/orderbook/rec")).json();
    OBR.st = st;
    const c = st.cfg || {};
    $("obToggle").textContent = c.on ? "⏹ Matikan perekam" : "⏺ Nyalakan perekam";
    $("obToggle").classList.toggle("primary", !c.on);
    if (!OBR.edited) { $("obCoins").value = c.coins || "20"; $("obInt").value = String(c.interval_min || 5); $("obMin").value = c.min_usdt || 100000; }
    const ago = st.last ? `${Math.round((Date.now() - st.last) / 60000)} menit lalu (${st.last_n} koin)` : "belum pernah";
    $("obStatus").innerHTML = `${c.on ? (st.running ? "🔴 <b>Merekam</b>" : "⚠️ Menyala tapi belum berjalan") : "⏸ Mati"} · rekaman: <b>${st.coins}</b> koin · <b>${st.snapshots.toLocaleString("id-ID")}</b> snapshot · <b>${st.days.toFixed(1)}</b> hari · ${st.size_mb.toFixed(1)} MB · terakhir ${ago}` +
      (st.days < 14 ? ` · <span class="hint">uji tembok butuh ±2 minggu rekaman</span>` : "") + (st.errors && st.errors.length ? `<br><small class="neg">⚠️ ${st.errors.slice(-2).map(esc).join(" · ")}</small>` : "");
  } catch (ex) { $("obStatus").textContent = "⚠️ " + ex.message; }
}
async function obToggle() {
  const on = !(OBR.st && OBR.st.cfg && OBR.st.cfg.on);
  const body = { on, coins: $("obCoins").value.trim() || "20", interval_min: +$("obInt").value, min_usdt: +$("obMin").value || 100000 };
  const r = await fetch("/api/orderbook/rec", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const j = await r.json();
  if (!r.ok) return toast(j.detail || r.statusText);
  OBR.edited = false;
  toast(on ? "Perekam order book menyala — biarkan aplikasi tetap terbuka / laptop menyala." : "Perekam dimatikan.");
  setTimeout(obRefresh, on ? 4000 : 300);
  obRefresh();
}
async function obTest() {
  if (WH.busy) return toast("Masih ada proses whale yang berjalan.");
  WH.busy = true; $("obTest").disabled = true;
  $("whOut").innerHTML = `<div class="card evalcard msc-empty"><h3>⏳ Menguji tembok dari rekaman<span class="dots"></span></h3><p class="hint">Mengambil candle 5M sejak awal rekaman dari Binance.</p></div>`;
  try {
    const r = await fetch("/api/orderbook/test", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    let st;
    for (;;) { st = await (await fetch(`/api/screener/job/${j.id}`)).json(); if (st.status !== "running") break; await new Promise((ok) => setTimeout(ok, 700)); }
    if (st.status === "error") throw new Error(st.error);
    const R = st.result, pc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), G = R.groups;
    const row = (k) => `<tr><td>${esc(k)}</td><td class="num">${G[k].touched}</td><td class="num">${G[k].n}</td><td class="num"><b>${pc(G[k].bounce_pct)}</b></td></tr>`;
    $("whOut").innerHTML = `<div class="card evalcard"><h3>📼 Uji tembok dari rekaman <small class="hint">${R.coins.length} koin · ${R.coins.reduce((a, x) => a + x.snapshots, 0).toLocaleString("id-ID")} snapshot</small></h3>
      <div class="wh-flowtest ${R.edge != null && R.edge >= 5 ? "pass" : ""}"><b>${esc(R.verdict)}</b>${R.edge != null ? ` — tembok bertahan mantul ${pc(G["tembok bertahan"].bounce_pct)} vs pembanding ${pc(G["pembanding (tanpa tembok)"].bounce_pct)} (${R.edge >= 0 ? "+" : ""}${R.edge.toFixed(0)} poin)` : ""}.</div>
      <div class="scroll"><table class="tbl"><tr><th>Kelompok</th><th class="num">Tersentuh</th><th class="num">Jelas (mantul / tembus)</th><th class="num">Mantul</th></tr>${Object.keys(G).map(row).join("")}</table></div>
      ${Object.keys(R.sizes).length ? `<h4>Tembok bertahan per ukuran</h4><div class="scroll"><table class="tbl"><tr><th>Ukuran</th><th class="num">Jelas</th><th class="num">Mantul</th></tr>${Object.entries(R.sizes).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="num">${v.n}</td><td class="num">${pc(v.bounce_pct)}</td></tr>`).join("")}</table></div>` : ""}
      <ul class="hint"><li><b>Mantul</b> = sesudah menyentuh tembok (±${R.rules.touch_atr} ATR 5M), harga bergerak ${R.rules.bounce_atr} ATR menjauh searah tembok sebelum close menembus ${R.rules.break_atr} ATR. Ditunggu maks ${R.rules.wait_hours} jam.</li>
        <li><b>Bertahan</b> = terlihat ≥ ${R.rules.min_seen} snapshot berturut-turut. <b>Spoof</b> = hilang saat harga sudah mendekat ≥ 50% tapi belum menyentuh.</li>
        <li><b>Pembanding</b> = level di setengah jarak tembok dari harga, sisi sama, waktu sama, tanpa tembok. Tembok terbukti kalau mantulnya ≥ 5 poin lebih sering (≥ 30 kejadian).</li></ul></div>`;
  } catch (ex) {
    $("whOut").innerHTML = `<div class="card evalcard msc-empty"><h3>⚠️ Uji tembok gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { WH.busy = false; $("obTest").disabled = false; }
}
async function runSetups() {
  if (WH.busy) return;
  WH.busy = true;
  $("whSetRun").disabled = true;
  const rrs = $("whSetRR").value.split(/[,;\s]+/).map(Number).filter((x) => x >= 0.5 && x <= 10);
  if (!rrs.length) { WH.busy = false; $("whSetRun").disabled = false; return toast("Isi RR, mis. 2 atau 1, 1.5, 2, 3"); }
  const coinTxt = $("whSetCoins").value.trim();
  let coins = 20, symbols = null;
  if (/^\d+$/.test(coinTxt)) coins = Math.max(1, Math.min(2000, +coinTxt));
  else if (/^(semua|all)$/i.test(coinTxt)) coins = 2000;
  else if (coinTxt) symbols = [...new Set(coinTxt.toUpperCase().split(/[,;\s]+/).filter(Boolean).map((x) => x.endsWith("USDT") ? x : x + "USDT"))];
  if (symbols && !symbols.length) symbols = null;
  const body = { rr: rrs, side: $("whSetSide").value, coins: symbols ? symbols.length : coins, symbols, coins_txt: coinTxt, top: +$("whSetTop").value,
    min_wr: Math.max(0, +$("whSetMinWR").value || 0), min_usdt: Math.max(1000, +$("whMin").value || 100000), only_aligned: $("whSetAligned").checked };
  store.set("whSetForm", body);
  $("whLive").classList.remove("hidden");
  $("whPct").textContent = "0"; $("whBar").style.width = "1%"; $("whRecent").innerHTML = ""; $("whRecent").dataset.last = "";
  $("whTitle").innerHTML = `Mencari setup RR ${rrs.map((x) => "1:" + x).join(" / ")} di ${body.coins >= 2000 ? "semua" : body.coins} koin<span class="dots"></span>` +
    (body.coins > 100 ? `<br><small class="hint">Koin banyak: Binance membatasi jumlah permintaan per menit, jadi scan otomatis jalan pelan (±25–30 koin/menit, 300 koin ≈ 10–12 menit) supaya tidak diblokir.</small>` : "");
  try {
    const r = await fetch("/api/whales/setups", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    let st, lastKey = "";
    WH.scanning = true; WH.setups = null; WH.setDone = new Set(); WH.setSel = 0;
    $("whOut").innerHTML = `<p class="hint wh-wait">⏳ Setup yang sudah ketemu akan langsung muncul di sini selama scan berjalan…</p>`;
    for (;;) {
      st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      // hasil sementara: tampilkan setup yang sudah ketemu tanpa menunggu scan selesai
      const P = st.partial;
      if (st.status === "running" && P) {
        const key = `${P.scanned}|${P.n_all}`;
        if (key !== lastKey) { lastKey = key; WH.setups = P; renderSetups(); }
      }
      const pct = st.total ? (100 * st.done) / st.total : 0;
      $("whPct").textContent = Math.floor(pct); $("whBar").style.width = Math.max(pct, 1) + "%";
      $("whDone").textContent = `${st.done}/${st.total || "?"}`; $("whElapsed").textContent = fmtDur(st.elapsed);
      $("whEta").textContent = st.status !== "running" ? "0 dtk" : st.eta == null ? "menghitung…" : "±" + fmtDur(st.eta);
      whBinance(st);
      const rec = st.recent.map((x) => `<li><span>${x.error ? "⚠️" : "✅"} ${esc(x.symbol)}</span></li>`).join("");
      if (rec !== $("whRecent").dataset.last) { $("whRecent").innerHTML = rec; $("whRecent").dataset.last = rec; }   // gambar ulang hanya kalau berubah
      if (st.status !== "running") break;
      await new Promise((ok) => setTimeout(ok, 600));
    }
    if (st.status === "error") throw new Error(st.error);
    WH.setups = st.result; WH.scanning = false;
    $("whStatus").textContent = `Setup RR ${st.result.rrs.map((x) => "1:" + x).join(" / ")} · ${st.result.scanned} koin dalam ${st.result.elapsed} dtk` +
      (st.result.skipped ? ` · ${st.result.skipped} koin datanya kurang/gagal → diganti koin berikutnya` : "") +
      (!body.symbols && body.coins > st.result.available && body.coins < 2000 ? ` · koin futures USDT yang ada cuma ${st.result.available}` : "") +
      (st.result.scanned < st.result.target ? ` · hanya ${st.result.scanned} dari ${st.result.target} yang datanya cukup` : "") +
      (st.result.n_errors ? ` · ${st.result.n_errors} koin gagal/tidak ada: ${st.result.errors.map((e) => e.split(":")[0]).join(", ")}` : "");
    renderSetups();
  } catch (e) {
    $("whStatus").innerHTML = `<span class="neg">Gagal: ${esc(e.message)}</span>`;
  } finally {
    WH.busy = false; WH.scanning = false;
    $("whSetRun").disabled = false;
    setTimeout(() => $("whLive").classList.add("hidden"), 800);
  }
}
// ---- 🐋 Whale: status koneksi Binance di panel progres (menunggu batas / IP diblokir / koneksi gagal / scan lain masih jalan)
function whBinance(st) {
  let el = $("whBn");
  if (!el) { el = document.createElement("div"); el.id = "whBn"; el.className = "hint"; $("whTitle").insertAdjacentElement("afterend", el); }
  const b = st.binance, L = [];
  if (b && b.code === "batas") L.push(`⏳ <b>Menunggu batas Binance</b>: ${esc(b.text)}${b.wait_s ? ` · lanjut otomatis ±${Math.ceil(b.wait_s)} dtk` : ""}`);
  else if (b && b.code === "blokir") L.push(`⛔ <b class="neg">${esc(b.text)}</b> — tunggu sampai waktu itu, lalu scan lagi`);
  else if (b && b.code === "koneksi") L.push(`📡 <b class="neg">${esc(b.text)}</b>`);
  else if (b && st.status === "running") L.push(`📡 Binance OK · jatah dipakai ${b.weight}/2400 per menit${st.done ? "" : " · koin pertama sedang dianalisa (bisa ±20–60 dtk)"}`);
  if (st.running_jobs > 1) L.push(`⚠️ Ada <b>${st.running_jobs - 1} scan lain</b> yang masih berjalan di belakang (menu lain) — berbagi jatah Binance, jadi lebih lambat.`);
  el.innerHTML = L.join("<br>");
}
async function runWhales(silent) {
  if (WH.busy) return;
  WH.busy = true;
  $("whRun").disabled = true;
  const one = $("whMode").value === "one";
  const body = { coins: +$("whCoins").value, top: +$("whTop").value, min_usdt: Math.max(1000, +$("whMin").value || 100000), min_impact: +$("whImpact").value,
    mode: $("whMode").value, symbol: $("whSym").value.trim().toUpperCase() };
  if (one && !body.symbol) { WH.busy = false; $("whRun").disabled = false; return toast("Isi koin dulu, mis. BTCUSDT"); }
  store.set("whForm", body);
  if (!silent) {
    $("whLive").classList.remove("hidden");
    $("whPct").textContent = "0"; $("whBar").style.width = "1%"; $("whRecent").innerHTML = "";
    $("whTitle").innerHTML = 'Mengambil daftar koin dari Binance<span class="dots"></span>';
  }
  try {
    const r = await fetch(one ? "/api/whales/coin" : "/api/whales/start", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    let st;
    for (;;) {
      st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (!silent) {
        const pct = st.total ? (100 * st.done) / st.total : 0;
        $("whPct").textContent = Math.floor(pct);
        $("whBar").style.width = Math.max(pct, 1) + "%";
        $("whDone").textContent = `${st.done}/${st.total || "?"}`;
        $("whElapsed").textContent = fmtDur(st.elapsed);
        $("whEta").textContent = st.status !== "running" ? "0 dtk" : st.eta == null ? "menghitung…" : "±" + fmtDur(st.eta);
        $("whTitle").innerHTML = st.status === "running" ? (one ? `Menganalisa ${esc(body.symbol)}<span class="dots"></span>` : `Membaca order book &amp; transaksi ${st.total || ""} koin<span class="dots"></span>`) : "Selesai! 🐋";
        $("whRecent").innerHTML = st.recent.map((x) => `<li><span>${x.error ? "⚠️" : "✅"} ${esc(x.symbol)}</span></li>`).join("");
      }
      if (st.status !== "running") break;
      await new Promise((ok) => setTimeout(ok, 500));
    }
    if (st.status === "error") throw new Error(st.error);
    if (one) {
      WH.coin = st.result;
      if (WH.check && WH.check.symbol !== WH.coin.symbol) WH.check = null;
      $("whStatus").textContent = `Update ${new Date(WH.coin.time).toLocaleTimeString()} · ${WH.coin.symbol} dalam ${WH.coin.elapsed} dtk`;
      renderWhaleCoin();
    } else {
      WH.res = st.result;
      $("whStatus").textContent = `Update ${new Date(WH.res.time).toLocaleTimeString()} · ${WH.res.scanned} koin dalam ${WH.res.elapsed} dtk` +
        (WH.res.errors ? ` · ${WH.res.errors} gagal` : "");
      renderWhales();
    }
  } catch (e) {
    $("whStatus").innerHTML = `<span class="neg">Gagal: ${esc(e.message)}</span><br>Kalau Binance diblokir di jaringan lu: ganti DNS ke 1.1.1.1 / 8.8.8.8, atau pakai VPN.`;
  } finally {
    WH.busy = false;
    $("whRun").disabled = false;
    setTimeout(() => $("whLive").classList.add("hidden"), silent ? 0 : 1000);
  }
}
{
  const f = store.get("whForm", null);
  if (f) { $("whCoins").value = f.coins; $("whTop").value = f.top; $("whMin").value = f.min_usdt; $("whImpact").value = f.min_impact;
    if (f.mode) $("whMode").value = f.mode; if (f.symbol) $("whSym").value = f.symbol; }
  $("whMode").onchange = whModeChanged;
  $("whCheck").onclick = runEntryCheck;
  $("whSetRun").onclick = runSetups;
  $("whFlowRun").onclick = runFlow;
  $("obToggle").onclick = obToggle;
  $("obTest").onclick = obTest;
  ["obCoins", "obInt", "obMin"].forEach((id) => $(id).addEventListener("input", () => { OBR.edited = true; }));
  obRefresh(); setInterval(() => { if ($("tab-whale").classList.contains("active")) obRefresh(); }, 60000);
  { const f = store.get("whFlowForm", null); if (f) { $("whFlowSym").value = f.symbol || ""; $("whFlowTf").value = f.tf || "1h"; $("whFlowCoins").value = String(f.coins ?? 20); } }
  $("whOut").addEventListener("click", async (e) => {
    if (!WH.flow || !e.target.closest("#whFlowCopy, #whFlowDl")) return;
    const R = flowSpec(WH.flow);
    if (e.target.id === "whFlowCopy") { await copyText(MSC.signal(R, null)); return toast("Hasil disalin 📋"); }
    try { await MSC.download(R, null); } catch (ex) { toast("Gagal membuat gambar: " + ex.message); }
  });
  $("whSavedBox").addEventListener("toggle", (e) => { if (e.target.open) savedResults("whsetups", $("whSaved"), (res) => {
    WH.setups = res; WH.setDone = new Set(); WH.scanning = false; renderSetups(); }); });
  $("whCfgSave").onclick = () => saveWhaleCfg(false);
  $("whCfgReset").onclick = () => { if (confirm("Kembalikan semua threshold ke default?")) saveWhaleCfg(true); };
  loadWhaleCfg();
  { const sf = store.get("whSetForm", null); if (sf) { $("whSetRR").value = Array.isArray(sf.rr) ? sf.rr.join(", ") : sf.rr; $("whSetSide").value = sf.side;
    $("whSetCoins").value = sf.coins_txt || sf.coins; $("whSetTop").value = sf.top; if (sf.min_wr != null) $("whSetMinWR").value = sf.min_wr; if (sf.only_aligned != null) $("whSetAligned").checked = !!sf.only_aligned; } }
  $("whFillPx").onclick = () => { if (WH.coin) $("whEntry").value = WH.coin.price; else toast("Analisa koinnya dulu (tombol di atas) untuk tahu harga sekarang"); };
  { const cf = store.get("whCheckForm", null); if (cf) { $("whEntry").value = cf.e; $("whSL").value = cf.sl; $("whTP").value = cf.tp; if (cf.minrr) $("whMinRR").value = cf.minrr; } }
  // pilih arah BUY / SELL (wajib), label SL / TP ikut menjelaskan posisinya
  const setSide = (sd) => {
    WH.side = sd;
    document.querySelectorAll(".wh-side-pick button").forEach((b) => b.classList.toggle("on", b.dataset.side === sd));
    $("whSL").placeholder = sd === "SELL" ? "SL (di ATAS entry)" : sd === "BUY" ? "SL (di BAWAH entry)" : "stop loss";
    $("whTP").placeholder = sd === "SELL" ? "TP (di BAWAH entry)" : sd === "BUY" ? "TP (di ATAS entry)" : "take profit";
    $("whSideHint").textContent = sd === "SELL" ? "SELL / SHORT: SL di atas entry, TP di bawah entry." : sd === "BUY" ? "BUY / LONG: SL di bawah entry, TP di atas entry." : $("whSideHint").textContent;
  };
  document.querySelectorAll(".wh-side-pick button").forEach((b) => (b.onclick = () => setSide(b.dataset.side)));
  const minTxt = () => { const v = +$("whMin").value; $("whMinTxt").textContent = v > 0 ? `= ${usdtTxt(v)} USDT` : ""; };
  $("whMin").addEventListener("input", minTxt);
  minTxt();
  whModeChanged();
  fetch("/api/symbols").then((r) => r.json()).then((j) => { $("whSymList").innerHTML = (j.symbols || []).map((x) => `<option value="${x}">`).join(""); }).catch(() => {});
  $("whRun").onclick = () => runWhales(false);
  $("whAuto").onchange = () => {
    clearInterval(WH.timer);
    const s = +$("whAuto").value;
    if (s) WH.timer = setInterval(() => document.querySelector("#tab-whale.active") && runWhales(true), s * 1000);
  };
  $("whOut").addEventListener("click", (e) => {
    if (!e.target.closest("#whBackSetups") || !WH.setups) return;
    renderSetups();
    $("whStatus").textContent = `Hasil scan setup (${new Date(WH.setups.time || Date.now()).toLocaleTimeString()})`;
    window.scrollTo(0, WH.setScroll || 0);
  });
  $("whOut").addEventListener("click", async (e) => {
    const v = e.target.closest(".wh-vsel, .wh-vcopy, .wh-vdl");
    if (v && WH.setups) {
      const sp = whSpec(WH.setups.setups[+v.dataset.i]);
      if (v.classList.contains("wh-vsel")) {
        WH.setSel = +v.dataset.i; renderSetups();
        const c = document.querySelector("#whOut .wh-vis"); if (c) c.scrollIntoView({ behavior: "smooth", block: "start" });
      } else if (sp && v.classList.contains("wh-vcopy")) { await copyText(MSC.signal(sp.R, sp.B)); toast("Sinyal disalin 📋"); }
      else if (sp) { try { await MSC.download(sp.R, sp.B); } catch (ex) { toast("Gagal membuat gambar: " + ex.message); } }
      return;
    }
    const x = e.target.closest(".wh-setex");
    if (x && WH.setups) {
      if (WH.scanning) return toast("Scan masih berjalan. Tunggu selesai dulu untuk melihat contoh trade.");
      return whShowTrades(+x.dataset.i);
    }
    const tr = e.target.closest("tr[data-whx]");
    if (!tr || !WH.ex) return;
    const t = WH.ex.trades[+tr.dataset.whx];
    await openMoment(WH.ex.symbol, WH.ex.tf, t.time, [
      { price: t.entry, color: "#42a5f5", size: 2, label: `E ${pxTxt(t.entry)}` },
      { price: t.sl, color: "#ef5350", dash: true, label: `SL ${pxTxt(t.sl)}` },
      { price: t.tp, color: "#26a69a", dash: true, label: `TP ${pxTxt(t.tp)}` }],
      `Entry ${WH.ex.side} ${fmtTime(t.time).slice(0, 16)} (${WH.ex.symbol} ${WH.ex.tf.toUpperCase()}) di close candle ini. Hasil: ${t.result > 0 ? "TP" : t.result < 0 ? "SL" : "belum kena dalam batas waktu"} (${fmtTime(t.exit_time).slice(0, 16)}). Step maju untuk melihat kelanjutannya.`);
  });
  $("whOut").addEventListener("click", (e) => {
    const b = e.target.closest(".wh-setcheck");
    if (!b || !WH.setups) return;
    if (WH.scanning) return toast("Scan masih berjalan. Tunggu selesai dulu untuk Cek detail (hasilnya tetap tampil di sini).");
    const s = WH.setups.setups[+b.dataset.i], d = (v) => +(+v).toPrecision(6);
    (WH.setDone = WH.setDone || new Set()).add(+b.dataset.i);
    WH.setScroll = window.scrollY;
    $("whMode").value = "one"; whModeChanged();
    $("whSym").value = s.symbol;
    $("whStatus2").value = "pending";
    document.querySelector(`.wh-side-pick [data-side="${s.side}"]`).click();
    $("whEntry").value = d(s.entry); $("whSL").value = d(s.sl); $("whTP").value = d(s.tp);
    $("whMinRR").value = s.rr;
    runEntryCheck();
  });
  $("whOut").addEventListener("click", async (e) => {
    const a = e.target.closest(".wh-sym");
    if (!a) return;
    const sym = a.dataset.sym;
    if (!e.shiftKey && $("whMode").value === "all") {        // klik koin di ranking = analisa detail koin itu
      $("whMode").value = "one"; $("whSym").value = sym; whModeChanged();
      return runWhales(false);
    }
    if (!(await loadSymbol(sym))) return toast(`Data lokal ${sym} belum ada. Jalankan update_data.bat dulu.`);
    $("symbol").value = sym;
    $("startAt").value = toInput(S.info.end);
    document.querySelector('.tab[data-tab="replay"]').click();
  });
}

// ------------------------------------------------------------------ buka di HP
async function renderHpPanel() {
  const el = $("hpPanel");
  if (location.hostname !== "127.0.0.1" && location.hostname !== "localhost") {
    el.innerHTML = `<h3>Sudah dibuka dari perangkat lain</h3><p class="hint">Alamat ini: <code>${location.origin}</code></p>`;
    return;
  }
  let r;
  try { r = await (await fetch("/api/lan")).json(); } catch (e) { el.textContent = "Gagal membaca alamat."; return; }
  if (!r.lan_mode) {
    el.innerHTML = `<h3>Buka di HP</h3><ol><li>Tutup jendela <b>run.bat</b>.</li><li>Jalankan <b>run_hp.bat</b>.</li>
      <li>Klik tombol 📱 HP ini lagi untuk melihat alamat &amp; QR code.</li></ol>
      <p class="hint">HP dan PC harus di Wi-Fi yang sama, atau keduanya memakai Tailscale (lihat README).</p>`;
    return;
  }
  if (!r.urls.length) { el.innerHTML = '<h3>Buka di HP</h3><p class="hint">PC tidak terhubung ke jaringan.</p>'; return; }
  const main = r.urls.find((u) => u.kind !== "Tailscale") || r.urls[0];
  let qr = "";
  if (window.qrcode) {
    const q = qrcode(0, "M");
    q.addData(main.url);
    q.make();
    qr = `<div class="qr">${q.createImgTag(5, 0)}</div>`;
  }
  el.innerHTML = `<h3>Buka di HP</h3>${qr}<p class="hint" style="text-align:center">Scan dengan kamera HP</p>` +
    r.urls.map((u) => `<div><span class="muted">${u.kind}:</span> <code>${u.url}</code></div>`).join("") +
    `<p class="hint">${r.pin ? "HP akan diminta PIN (ACCESS_PIN di config.bat)." :
      "Tanpa PIN: siapa pun di Wi-Fi yang sama bisa membuka. Atur ACCESS_PIN di config.bat kalau di Wi-Fi umum."}</p>`;
}
$("btnHp").addEventListener("click", (e) => {
  e.stopPropagation();
  const open = $("hpPanel").classList.toggle("open");
  if (open) renderHpPanel();
});
document.addEventListener("click", (e) => { if (!e.target.closest(".popwrap.hp")) $("hpPanel").classList.remove("open"); });

// ------------------------------------------------------------------ init
async function init() {
  bindSeg("sideSeg", "side", "side");
  bindSeg("typeSeg", "type", "type");
  renderDrawBar();
  renderIndPanel();
  const prefs = store.get("prefs", {});
  if (prefs.margin != null) $("cfgMargin").checked = prefs.margin;
  if (prefs.sound != null) $("cfgSound").checked = prefs.sound;
  if (prefs.volume != null) $("cfgVolume").value = prefs.volume;
  if (prefs.sizeMode) $("sizeMode").value = prefs.sizeMode;
  if (prefs.sizeVal) $("sizeUsdt").value = prefs.sizeVal;
  ["price", "tp", "sl", "sizeUsdt", "sizeMode"].forEach((id) => $(id).addEventListener("input", () => {
    renderPreview(); syncPrefs();
    for (const id of S.drawIds) {   // label untung/rugi di kotak Long/Short ikut dihitung ulang
      const o = chart.getOverlayById(id);
      if (o && o.name === "position") chart.overrideOverlay({ id, extendData: { ...o.extendData } });
    }
    if (S.selected && chart.getOverlayById(S.selected)) selectDrawing(S.selected);
  }));
  $("typeSeg").addEventListener("click", () => setTimeout(renderPreview));
  const syncPrefs = () => {
    document.querySelector(".settings").classList.toggle("margin-on", $("cfgMargin").checked);
    store.set("prefs", { margin: $("cfgMargin").checked, sound: $("cfgSound").checked, volume: +$("cfgVolume").value,
      sizeMode: $("sizeMode").value, sizeVal: $("sizeUsdt").value });
  };
  ["cfgMargin", "cfgSound", "cfgVolume"].forEach((id) => $(id).addEventListener("change", syncPrefs));
  syncPrefs();
  $("btnTestSound").onclick = () => { Sound.fill(); setTimeout(() => Sound.bell(), 400); setTimeout(() => Sound.loss(), 2000); };
  Object.keys(IND).forEach(applyIndicator);
  document.querySelectorAll(".tab").forEach((b) => b.addEventListener("click", () => {
    const msGrp = b.dataset.tab === "stratlab" || b.dataset.tab === "msa";       // Penemu Strategi = sub-tab Market Structure
    document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x === b || (msGrp && x.dataset.tab === "msa")));
    document.querySelectorAll(".tabpane").forEach((p) => p.classList.toggle("active", p.id === "tab-" + b.dataset.tab));
    document.querySelectorAll(".ms-subtabs button[data-sub]").forEach((x) => x.classList.toggle("on", x.dataset.sub === b.dataset.tab));
    if (b.dataset.tab === "replay") setTimeout(() => chart.resize());
  }));
  document.querySelectorAll(".ms-subtabs").forEach((bar) => bar.addEventListener("click", (e) => {
    const x = e.target.closest("button[data-sub]");
    if (x) document.querySelector(`.tab[data-tab="${x.dataset.sub}"]`).click();
  }));
  $("tfButtons").addEventListener("click", async (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    S.tf = b.dataset.tf;
    renderTfButtons();
    if (S.started) await send({ cmd: "set_tf", tf: S.tf });
    applyDrawVisibility();
  });
  $("ordersTbl").addEventListener("click", (e) => {
    const id = e.target.dataset.cancel;
    if (id) send({ cmd: "cancel", id: +id });
  });
  $("btnStart").onclick = startReplay;
  $("btnStep").onclick = () => step(false);
  $("btnStepBase").onclick = () => step(true);
  $("btnBack").onclick = () => stepBack(false);
  $("btnBackBase").onclick = () => stepBack(true);
  $("btnPlay").onclick = togglePlay;
  $("btnOrder").onclick = placeOrder;
  $("btnClose").onclick = () => S.started && send({ cmd: "close" });
  $("btnCancelAll").onclick = () => S.started && send({ cmd: "cancel_all" });
  $("btnRun").onclick = () => ($("btScope").value === "one" ? runBacktest() : runBacktestAll());
  $("btScope").value = store.get("btScope", "one");
  $("btSymbols").value = store.get("btSymbols", "");
  $("btScope").onchange = scopeChanged;
  scopeChanged();
  $("btAllSearch").oninput = renderAllTable;
  $("btAllCsv").onclick = exportAllCsv;
  $("btAllCancel").onclick = () => BA.id && fetch(`/api/backtest_all/${BA.id}/cancel`, { method: "POST" });
  bindPauseBtn($("btAllPause"), "backtest", () => BA.id, () => { BA.wasPaused = true; clearTimeout(BA.timer); pollAll(); });
  fetch("/api/cpu").then((r) => r.json()).then((c) => { $("btWorkers").placeholder = workersHint(c); $("fbWorkers").placeholder = workersHint(c); $("f2Workers").placeholder = workersHint(c); });
  resumeRunning();
  $("btStrategy").onchange = () => { onStrategyChange(); renderSaved(); gridVisible(); };
  $("btnGrid").onclick = runGrid;
  $("btCopy").onclick = copyCurrent;
  $("btForm").addEventListener("change", (e) => { if (e.target.tagName === "SELECT") updateAtrTags(); });
  FIBS[1].init();
  FIBS[2].init();
  for (const id of ["btAutoSave", "fbAutoSave", "f2AutoSave"]) {
    $(id).checked = !!store.get(id, false);
    $(id).addEventListener("change", () => store.set(id, $(id).checked));
  }
  $("btPaste").onclick = () => { $("btPasteBox").classList.toggle("hidden"); $("btPasteText").focus(); };
  $("btPasteClose").onclick = () => $("btPasteBox").classList.add("hidden");
  $("btPasteApply").onclick = () => {
    try {
      const { strategy, params } = parseThreshold($("btPasteText").value);
      if (!Object.keys(params).length) return toast("Tidak ada parameter yang terbaca");
      applyThreshold(strategy, params);
      $("btPasteBox").classList.add("hidden");
    } catch (err) { toast("Teks tidak bisa dibaca: " + err.message); }
  };
  $("btnSave").onclick = saveCurrent;
  $("btSavedFilter").onchange = renderSaved;
  $("btSavedCompare").onclick = compareSaved;
  $("btSaved").querySelector(".ev-cancel").onclick = () => $("btSaved")._job && fetch(`/api/backtest_all/${$("btSaved")._job}/cancel`, { method: "POST" });
  loadSaved();
  $("btReset").onclick = () => {
    const s = STRATS.find((x) => x.name === $("btStrategy").value);
    store.set("params:" + s.name, {});
    renderParamForm(s, s.params);
  };
  $("symbol").addEventListener("change", async (e) => {
    if (await loadSymbol(e.target.value.trim().toUpperCase())) startReplay();
  });
  document.addEventListener("keydown", (e) => {
    if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName)) return;
    if (e.key === "ArrowRight") { e.preventDefault(); step(e.shiftKey); }
    if (e.key === "ArrowLeft") { e.preventDefault(); stepBack(e.shiftKey); }
    if (e.key === " ") { e.preventDefault(); togglePlay(); }
    if ((e.key === "Delete" || e.key === "Backspace") && S.selected) { chart.removeOverlay(S.selected); selectDrawing(null); }
    if (e.key === "Escape" && S.selected && !S.drawing) selectDrawing(null);
    if (e.key === "Escape" && S.pendingPos) { S.pendingPos = null; renderDrawBar(); }
    if (e.key === "Escape" && S.drawing) { chart.removeOverlay(S.drawing); S.drawing = null; renderDrawBar(); }
  });

  await connect();
  const { symbols, data_dir } = await (await fetch("/api/symbols")).json();
  $("symbols").innerHTML = symbols.map((s) => `<option value="${s}">`).join("");
  if (!symbols.length) toast(`Tidak ada file .npz di ${data_dir}`);
  const last = store.get("symbol", null);
  const sym = symbols.includes(last) ? last : symbols.includes("BTCUSDT") ? "BTCUSDT" : symbols[0];
  if (sym) {
    $("symbol").value = sym;
    if (await loadSymbol(sym)) await startReplay();   // chart langsung tampil, tidak kosong
  }
  loadStrategies();
  initScreener();
}
init();

// ------------------------------------------------------------------ 🧠 Teknikal Analisis Pro Advance (logika baru)
const TAP = { res: null, sel: null, busy: false };
const tapDec = (d) => d === "ENTRY" ? '<span class="badge pass">✅ ENTRY</span>' : d === "TUNGGU" ? '<span class="badge">⏳ TUNGGU</span>' : '<span class="badge fail">❌ JANGAN</span>';
const tapPc = (v) => (v == null ? "—" : `${(+v).toFixed(0)}%`), tapR = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${(+v).toFixed(2)}R`);
async function tapRun() {
  if (TAP.busy) return;
  const mode = $("tapMode").value;
  const raw = ($("tapCoins").value || "30").trim();
  const body = { mode, symbol: $("tapSym").value.trim(), coins: /^\d+$/.test(raw) ? +raw : raw, style: $("tapStyle").value, hist: +$("tapHist").value || 30 };
  TAP.busy = true; $("tapRun").disabled = true; TAP.sel = null; TAP.res = null; TAP.t0 = Date.now(); TAP.nShown = -1;
  $("tapOut").innerHTML = "";
  tapProgress({ done: 0, total: 0, recent: [], elapsed: 0 }, body);
  try {
    const r = await fetch("/api/tapro/scan", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    for (;;) {
      const st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (st.status === "error") throw new Error(st.error);
      if (st.status === "done") { TAP.res = st.result; break; }
      tapProgress(st, body);
      const P = st.partial;
      if (P && P.phase === "scan" && P.rows && P.rows.length !== TAP.nShown) {          // setup yang sudah ketemu langsung tampil
        const had = !!TAP.sel; TAP.nShown = P.rows.length; TAP.res = P;
        if (mode === "one" && !had && P.rows[0] && P.full[P.rows[0].symbol]) TAP.sel = P.rows[0].symbol;
        tapRender(had);
      }
      await new Promise((ok) => setTimeout(ok, 700));
    }
    const R = TAP.res;
    $("tapProg").innerHTML = "";
    $("tapStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${R.style_name} · riwayat ${R.learn.coins.length} koin (${R.learn.n_rows} kejadian) · ${R.rows.length} koin dibaca` +
      (R.note && R.note.length ? " · ⚠️ " + R.note.join(" · ") : "") + (R.errors && R.errors.length ? ` · gagal: ${R.errors.length}` : "");
    if (mode === "one" && R.rows[0] && R.full[R.rows[0].symbol]) TAP.sel = R.rows[0].symbol;
    tapRender();
  } catch (ex) {
    $("tapStatus").textContent = "⚠️ " + ex.message; $("tapProg").innerHTML = "";
    $("tapOut").innerHTML = `<div class="card evalcard"><h3>⚠️ Gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { TAP.busy = false; $("tapRun").disabled = false; }
}
// panel progres: fase, persen, waktu berjalan & perkiraan sisa, koin terbaru, jumlah keputusan sementara
function tapProgress(st, body) {
  const P = st.partial || {}, ph = P.phase || (st.done ? "riwayat" : "mulai");
  const hd = P.hist_done != null ? P.hist_done : 0, ht = P.hist_total || body.hist, sd = P.done || 0, stt = P.total || (body.mode === "one" ? 1 : "…");
  const pct = st.total ? Math.min(100, (100 * st.done) / st.total) : 0;
  const fmt = (s) => (s == null ? "—" : s >= 60 ? `${Math.floor(s / 60)} mnt ${Math.round(s % 60)} dtk` : `${Math.round(s)} dtk`);
  const rows = P.rows || [], cnt = (d) => rows.filter((x) => x.decision === d).length, none = rows.filter((x) => !x.decision).length;
  const rec = (st.recent || []).slice(0, 8).map((r) => `<span class="chip${r.error ? " neg" : ""}">${r.error ? "⚠️ " : ""}${esc(String(r.symbol).replace(/^riwayat /, ""))}</span>`).join(" ");
  const steps = [["riwayat", `1️⃣ Backtest riwayat ${hd}/${ht} koin lokal`, "mencari semua kejadian setup A–D 2 tahun terakhir & menguji tiap cara entry (pertama kali saja; sesudahnya dipakai dari file)"],
    ["scan", `2️⃣ Scan live ${sd}/${stt} koin`, "candle live Binance → setup yang berlaku sekarang → entry / SL / TP1 / TP2 → sentimen · order book · fundamental (6 koin sekaligus)"]];
  $("tapProg").innerHTML = `<div class="card evalcard tap-prog"><h3>⏳ Menganalisa · ${esc(P.style_name || ($("tapStyle").selectedOptions[0] || {}).text || "")}<span class="dots"></span></h3>
    <div class="tap-bar"><i style="width:${pct.toFixed(1)}%"></i><b>${pct.toFixed(0)}%</b></div>
    <div class="tap-steps">${steps.map(([k, t, h]) => `<div class="${ph === k ? "on" : (k === "riwayat" && ph === "scan") ? "done" : ""}"><b>${(k === "riwayat" && ph === "scan") ? "✅ " : ""}${t}</b><small>${h}</small></div>`).join("")}</div>
    <p>⏱️ berjalan <b>${fmt(st.elapsed)}</b> · perkiraan sisa <b>${fmt(st.eta)}</b>${ph === "scan" ? ` · sementara: <b class="pos">✅ ${cnt("ENTRY")} ENTRY</b> · <b>⏳ ${cnt("TUNGGU")} TUNGGU</b> · <b class="neg">❌ ${cnt("JANGAN")} JANGAN</b> · ${none} tanpa setup` : ""}</p>
    ${rec ? `<p class="hint">Baru diproses: ${rec}</p>` : ""}
    <p class="hint">💡 ${ph === "scan" ? "Koin yang sudah selesai langsung muncul di tabel di bawah dan kartunya bisa dibuka tanpa menunggu scan selesai." : "Backtest riwayat hanya dihitung ulang kalau data candle diperbarui atau pilihan gaya / jumlah koin riwayat berubah."}</p></div>`;
}
function tapSpec(sym, p, A) {
  const long = p.dir === 1, mk = p.entry_kind === "market", C = p.card;
  const R = { symbol: sym, tf: A.tf, icon: "🧠", sub: `TA Pro Advance · ${p.setup}`, candles: C.candles, nbar: 100, proj: C.proj, now_time: C.now_time + 1, now_price: C.now_price,
    walls: [{ price: p.price_tp2, color: "#16c784", label: `TP2 1:${p.rr2} · ${pxTxt(p.price_tp2)}` }],
    boxes: [["ENTRY", pxTxt(p.price_entry), "#60a5fa", `${mk ? "market" : "limit"} · ${esc(p.entry_name)}`.slice(0, 36)],
      ["STOP LOSS", pxTxt(p.price_sl), "#ff6b73", `risiko ${p.risk_pct.toFixed(2)}%`],
      ["TAKE PROFIT 1", pxTxt(p.price_tp1), "#36e3a1", "1:2 · ambil 50%, SL ke entry"],
      ["TAKE PROFIT 2", pxTxt(p.price_tp2), "#16c784", `1:${p.rr2} · sisa posisi`],
      ["PELUANG TP1", tapPc(p.prob), p.prob >= 50 ? "#36e3a1" : "#ff6b73", `${p.prob_src} · kelas ${p.class}`]],
    footer: `${p.decision} · ${p.why} · garis hijau tipis = TP2`,
    insights: [{ t: `🧠 ${p.decision}: ${p.why}`, c: p.decision === "ENTRY" ? "#36e3a1" : p.decision === "TUNGGU" ? "#f5c451" : "#ff8a8a", b: true },
      { t: `📊 Backtest ${p.stats.n} trade: peluang TP1 ${tapPc(p.stats.wr)} (cari ${tapPc(p.stats.wr_fit)} · uji ${tapPc(p.stats.wr_test)}) · ${tapR(p.stats.exp_r)}/trade · mantul bersih ${tapPc(p.stats.clean_pct)}`, c: "#e6ebf2" }] };
  const B = { dir: long ? 0 : 1, price_entry: p.price_entry, price_sl: p.price_sl, price_tp: p.price_tp1, rr: 2, entry: mk ? "market" : "limit",
    entry_txt: p.entry_name, risk_pct: p.risk_pct, live: true, usable: p.decision === "ENTRY", fill_pct: p.stats.fill_pct,
    status: p.decision === "ENTRY" ? (mk ? "ENTRY · market sekarang" : "ENTRY · pasang limit") : `${p.decision} · ${p.why}` };
  return { R, B };
}
function tapPillars(p) {
  const ic = (s) => (s === "ok" ? "✅" : s === "warn" ? "⚠️" : s === "info" ? "ℹ️" : "⛔");
  const list = (o) => o && o.items && o.items.length ? `<ul>${o.items.map(([k, v, st]) => `<li>${ic(st)} <b>${esc(k)}</b>: ${esc(v)}</li>`).join("")}</ul>` : `<p class="hint">${esc((o && o.note) || "tidak ada data")}</p>`;
  const S = p.stats, M = S.model;
  const w = M && M.weights ? Object.entries(M.weights).map(([k, v]) => `<span class="chip">${esc(k)} ${v >= 0 ? "+" : ""}${v}</span>`).join(" ") : "";
  return `<div class="tap-pillars">
    <div class="conc-reg"><h4>1️⃣ Teknikal & price action <span class="hint">di-backtest</span></h4><ul>
      <li>Setup <b>${esc(p.setup)}</b> · ${p.side} · entry <b>${esc(p.entry_name)}</b> (sinyal ${p.age} candle lalu)</li>
      ${S.live_bt ? `<li>🧱 Entry depan tembok ${S.wall ? `${pxTxt(S.wall.price)} (${(S.wall.usdt / 1e3).toFixed(0)} rb USDT, terlihat ${S.wall.seen}×)` : ""} — tidak bisa diuji di riwayat setup, dinilai <b>cara Whale</b> dari ${S.n} candle koin ini: peluang TP1 <b>${tapPc(S.wr)}</b> · terisi 24 jam ${tapPc(S.fill_pct)}</li>`
        : `<li>Backtest ${S.n} trade (data uji ${S.n_test}): peluang TP1 duluan cari <b>${tapPc(S.wr_fit)}</b> · uji <b>${tapPc(S.wr_test)}</b> · tersentuh 24 jam ${tapPc(S.fill_pct)}${S.fill_ok === false ? " (info: jarang tersentuh)" : ""}</li>`}
      <li>Rata-rata (rumus Whale di TP1 1:2 = WR × 2 − kalah): <b>${tapR(S.exp_r)}</b>${S.live_bt ? "" : ` · cari ${tapR(S.exp_fit)} · uji ${tapR(S.exp_test)}${S.proven === false ? " (info: belum terbukti di 30% terakhir)" : ""}`}</li>
      ${S.live_bt ? "" : `<li>Info hasil nyata TP1 50% + TP2 1:${S.tp2}: ${tapR(S.exp_tp2)} per trade · kalah beruntun terpanjang ${S.max_loss_streak}×</li>`}
      <li>🏓 Mantul bersih ${tapPc(S.clean_pct)} · ⏳ main dulu ${tapPc(S.main_pct)} · TP2 tercapai: ${Object.entries(S.reach_tp2 || {}).map(([k, v]) => `1:${(+k).toFixed(0)} ${tapPc(v)}`).join(" · ")}</li>
      <li>Model peluang: ${M ? (M.proven ? `✅ terbukti di data uji (sinyal p ≥ 50%: TP1 ${tapPc(M.test_wr_sel)} dari ${M.test_n_sel}, ${tapR(M.test_exp_sel)})` : "⚠️ belum terbukti → pakai rata-rata setup") : "data belum cukup"} ${w ? `<br><small>bobot faktor (dari data cari): ${w}</small>` : ""}</li></ul></div>
    <div class="conc-reg"><h4>2️⃣ Sentimen <span class="hint">live · tidak di-backtest (Fear &amp; Greed ikut model)</span></h4>${list(p.checks.sentiment)}</div>
    <div class="conc-reg"><h4>3️⃣ Order book <span class="hint">live · info (seperti Whale) · tembok dipakai untuk entry &amp; SL</span></h4>${list(p.checks.orderbook)}</div>
    <div class="conc-reg"><h4>4️⃣ Fundamental <span class="hint">CoinGecko · pemeriksa / veto</span></h4>${list(p.checks.fundamental)}</div></div>
    ${p.alts && p.alts.length ? `<details><summary><b>🔁 Cara entry lain yang diuji</b> <small class="hint">dipakai yang lolos syarat → paling sering mantul bersih → R/sinyal</small></summary><div class="scroll"><table class="tbl"><tr><th>Entry</th><th class="num">Terisi</th><th class="num">Peluang TP1 (cari · uji)</th><th class="num">R/trade (rumus Whale)</th><th class="num">Mantul bersih</th><th>Lolos</th></tr>` +
      p.alts.map((a) => `<tr><td>${esc(a.entry)}</td><td class="num">${tapPc(a.fill_pct)}</td><td class="num">${a.live_bt ? `${tapPc(a.wr)} (candle koin ini)` : `${tapPc(a.wr_fit)} · ${tapPc(a.wr_test)}`}</td><td class="num">${tapR(a.exp_r)}</td><td class="num">${tapPc(a.clean_pct)}</td><td>${a.ok ? "✅" : "—"}</td></tr>`).join("") + `</table></div></details>` : ""} + tapExamples(p)`;
}
// 🔍 contoh trade riwayat untuk setup × arah × entry yang dipilih (klik = buka di Manual Replay)
function tapExamples(p) {
  const S = p.stats, X = S.examples || [];
  if (S.live_bt) return `<details><summary><b>🔍 Contoh trade</b> <small class="hint">tidak ada — entry depan tembok tidak bisa diuji di riwayat setup (riwayat order book tidak ada)</small></summary></details>`;
  if (!X.length) return "";
  const A = TAP.res && TAP.sel && TAP.res.full[TAP.sel], tf = (A && A.tf) || "15m";
  const nw = X.filter((x) => x.filled && x.win).length, nl = X.filter((x) => x.filled && !x.win).length, nf = X.filter((x) => !x.filled).length;
  return `<details><summary><b>🔍 Contoh trade</b> <small class="hint">${X.length} kejadian terbaru · ✅ TP1 ${nw} · ❌ ${nl} · tidak terisi ${nf} · klik baris = buka di Manual Replay</small></summary>
    <div class="scroll" style="max-height:380px"><table class="tbl"><tr><th>Waktu (UTC)</th><th>Koin</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP1</th><th class="num">TP2</th><th>Terisi</th><th>Hasil</th><th>Data</th><th>🏓</th></tr>` +
    X.slice().reverse().map((x, i) => `<tr data-tapx="${X.length - 1 - i}" title="Buka di chart"><td>${fmtTime(x.t).slice(0, 16)}</td><td>${esc(x.sym)}</td>
      <td class="num">${pxTxt(x.e)}</td><td class="num neg">${pxTxt(x.sl)}</td><td class="num pos">${pxTxt(x.tp1)}</td><td class="num pos">${pxTxt(x.tp2)}</td>
      <td>${x.filled ? (x.fb ? `✅ ${pcDur(x.fb, tf)}` : "✅ market") : "❌ tidak terisi"}</td>
      <td class="${x.filled ? (x.win ? "pos" : x.res === "SL" ? "neg" : "") : ""}">${x.filled ? `${esc(x.res)} (${x.R >= 0 ? "+" : ""}${x.R.toFixed(2)}R)` : "—"}</td>
      <td>${x.test ? "uji" : "cari"}</td><td>${x.filled ? (x.clean ? "✅" : "—") : ""}</td></tr>`).join("") + `</table></div></details>`;
}
function tapRender(onlyTable) {
  const R = TAP.res, box = $("tapOut");
  if (!R) return;
  const rank = (x) => ({ ENTRY: 3, TUNGGU: 2, JANGAN: 1 }[x.decision] || 0);
  const rows = (R.rows || []).slice().sort((a, b) => rank(b) - rank(a) || (b.score || 0) - (a.score || 0));
  const tbl = rows.length ? `<div class="scroll"><table class="tbl tap-tbl"><tr><th>Koin</th><th>Keputusan</th><th>Setup</th><th>Sinyal</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP1 (1:2)</th><th class="num">TP2</th><th class="num">Peluang TP1</th><th class="num">Terisi</th><th class="num">🏓 Mantul bersih</th><th class="num">⏳ Main dulu</th><th class="num">R/trade</th><th>Kelas</th><th>⚠️</th></tr>` +
    rows.map((x) => x.decision ? `<tr data-tap="${esc(x.symbol)}" class="${TAP.sel === x.symbol ? "on" : ""}" title="Buka kartu visual & analisa"><td><b>${esc(x.symbol)}</b>${x.source === "lokal" ? ' <small class="hint">lokal</small>' : ""}</td><td>${tapDec(x.decision)}</td><td><small>${esc(x.code)} · ${esc(x.setup)}</small></td>
      <td class="${x.dir === 1 ? "pos" : "neg"}">${x.dir === 1 ? "▲ BUY" : "▼ SELL"} ${x.entry_kind === "market" ? "MARKET" : "LIMIT"}</td>
      <td class="num">${pxTxt(x.price_entry)}${cpB(x.price_entry)}</td><td class="num neg">${pxTxt(x.price_sl)}${cpB(x.price_sl)}</td><td class="num pos">${pxTxt(x.price_tp1)}${cpB(x.price_tp1)}</td><td class="num pos">${pxTxt(x.price_tp2)}${cpB(x.price_tp2)} <small>1:${x.rr2}</small></td>
      <td class="num"><b>${tapPc(x.prob)}</b> <small>${x.prob_src === "model" ? "model" : "rata²"}</small></td><td class="num">${tapPc(x.fill_pct)}</td><td class="num">${tapPc(x.clean_pct)}</td><td class="num">${tapPc(x.main_pct)}</td><td class="num">${tapR(x.exp_r)}</td>
      <td>${esc(x.class)} <small>${x.score}</small></td><td>${x.n_warn || ""}</td></tr>`
      : `<tr class="muted-row"><td>${esc(x.symbol)}</td><td colspan="14"><span class="hint">tidak ada setup A–D yang masih berlaku sekarang · tren TF besar ${x.trend > 0 ? "naik" : x.trend < 0 ? "turun" : "tidak jelas"}</span></td></tr>`).join("") + `</table></div>`
    : `<p>Tidak ada koin yang dibaca.</p>`;
  const LR = R.learn || { setups: [], coins: [], n_rows: 0 };
  const ok = (LR.setups || []).filter((x) => x.ok);
  const setupTbl = `<details class="card evalcard"><summary><b>📚 Hasil backtest semua setup</b> <small class="hint">${LR.n_rows} kejadian di ${LR.coins.length} koin lokal · ${ok.length} kombinasi setup × arah × entry lolos syarat${LR.from_file ? " · dari file tersimpan" : ""}</small></summary>
    <div class="scroll" style="max-height:420px"><table class="tbl"><tr><th>Setup</th><th>Arah</th><th>Entry</th><th class="num">Trade</th><th class="num">Terisi</th><th class="num">TP1 cari · uji</th><th class="num">R/trade cari · uji</th><th class="num">TP2</th><th class="num">Mantul bersih</th><th>Model</th><th>Lolos</th></tr>` +
    (LR.setups || []).map((x) => `<tr><td>${esc(x.code)}</td><td>${x.d === 1 ? "▲" : "▼"}</td><td>${esc(x.entry)}</td><td class="num">${x.n} <small>(${x.n_test})</small></td><td class="num">${tapPc(x.fill_pct)}</td>
      <td class="num">${tapPc(x.wr_fit)} · ${tapPc(x.wr_test)}</td><td class="num">${tapR(x.exp_fit)} · ${tapR(x.exp_test)}</td><td class="num">1:${x.tp2}</td><td class="num">${tapPc(x.clean_pct)}</td><td>${x.model_proven ? "✅" : "—"}</td><td>${x.ok ? "✅" : "—"}</td></tr>`).join("") + `</table></div></details>`;
  let det = "";
  const A = TAP.sel && R.full[TAP.sel];
  if (A) {
    const P = A.plans, k = Math.min(TAP.plan || 0, P.length - 1), p = P[k], sp = tapSpec(A.symbol, p, A);
    det = `<div class="card evalcard"><h3>🧠 ${esc(A.symbol)} · ${tapDec(p.decision)} <small class="hint">${esc(p.why)}</small></h3>
      <div class="msc-out"><div class="msc-card">${MSC.card(sp.R, sp.B, false)}</div>
      <div class="msc-btns">${P.map((q, i) => `<button class="mini tap-plan${i === k ? " on" : ""}" data-i="${i}">${i + 1}. ${q.code} ${q.side === "BUY" ? "🟢" : "🔴"} ${tapPc(q.prob)}</button>`).join("")}<span style="flex:1"></span>
        <button class="mini" id="tapCopy">📋 Salin sinyal</button><button class="mini" id="tapDl">⬇ Unduh gambar</button><button class="mini" id="tapReplay">▶ Putar ulang animasi</button></div></div>
      <p class="tap-copy">Entry <b>${pxTxt(p.price_entry)}</b>${cpB(p.price_entry)} · SL <b class="neg">${pxTxt(p.price_sl)}</b>${cpB(p.price_sl)} · TP1 <b class="pos">${pxTxt(p.price_tp1)}</b>${cpB(p.price_tp1)} · TP2 <b class="pos">${pxTxt(p.price_tp2)}</b>${cpB(p.price_tp2)} <small class="hint">📋 = salin pakai koma</small></p>
      ${p.sl_reasons && p.sl_reasons.length ? `<p class="hint">🛡️ SL anti-gocekan (logika Whale${p.sl_walls ? " + tembok order book live" : ", order book tidak terbaca"}): ${esc(p.sl_reasons.join("; "))}</p>` : ""}
      ${tapPillars(p)}</div>`;
  }
  const tblHtml = `<div class="card evalcard"><h3>📋 ${R.partial ? "⏳ Hasil sementara · " : ""}Hasil ${rows.filter((x) => x.decision === "ENTRY").length} ENTRY · ${rows.filter((x) => x.decision === "TUNGGU").length} TUNGGU <small class="hint">${rows.length} koin · klik baris untuk kartu visual & analisa 4 pilar</small></h3>${tbl}</div>` ;
  if (onlyTable && $("tapTbl")) { $("tapTbl").innerHTML = tblHtml + setupTbl; return; }   // kartu yang sedang dibuka tidak diulang
  box.innerHTML = `<div id="tapDet">${det}</div><div id="tapTbl">${tblHtml + setupTbl}</div>`;
}
{
  $("tapMode").onchange = () => { const one = $("tapMode").value === "one"; $("tapOneF").classList.toggle("hidden", !one); $("tapManyF").classList.toggle("hidden", one); };
  $("tapRun").onclick = tapRun;
  $("tapOut").addEventListener("click", async (e) => {
    const R = TAP.res;
    if (!R) return;
    const pl = e.target.closest(".tap-plan");
    if (pl) { TAP.plan = +pl.dataset.i; return tapRender(); }
    const A = TAP.sel && R.full[TAP.sel];
    if (A && ["tapCopy", "tapDl", "tapReplay"].includes(e.target.id)) {
      const p = A.plans[Math.min(TAP.plan || 0, A.plans.length - 1)], sp = tapSpec(A.symbol, p, A);
      if (e.target.id === "tapCopy") { await copyText(MSC.signal(sp.R, sp.B) + `\nTP2 ${pxTxt(p.price_tp2)} (1:${p.rr2})`); return toast("Sinyal disalin 📋"); }
      if (e.target.id === "tapDl") { try { await MSC.download(sp.R, sp.B); } catch (ex) { toast("Gagal membuat gambar: " + ex.message); } return; }
      return tapRender();
    }
    const tx = e.target.closest("tr[data-tapx]");
    if (tx && A) {
      const p = A.plans[Math.min(TAP.plan || 0, A.plans.length - 1)], x = (p.stats.examples || [])[+tx.dataset.tapx];
      if (!x) return;
      await openMoment(x.sym, R.tf || A.tf, x.t, [
        { price: x.e, color: "#42a5f5", size: 2, label: `E ${pxTxt(x.e)}` },
        { price: x.sl, color: "#ef5350", dash: true, label: `SL ${pxTxt(x.sl)}` },
        { price: x.tp1, color: "#26a69a", dash: true, label: `TP1 ${pxTxt(x.tp1)}` },
        { price: x.tp2, color: "#26a69a", dash: true, label: `TP2 ${pxTxt(x.tp2)}` }],
        `🧠 TA Pro · ${p.code} ${p.setup} · ${x.d === 1 ? "BUY" : "SELL"} · entry ${p.entry_name} di ${x.sym} ${fmtTime(x.t).slice(0, 16)} UTC. ` +
        `${x.filled ? (x.fb ? `Limit terisi ${pcDur(x.fb, R.tf || A.tf)} kemudian. ` : "") + `Hasil: ${x.res} (${x.R.toFixed(2)}R).` : "Limit tidak terisi."} Step maju untuk melihat.`);
      return;
    }
    const tr = e.target.closest("tr[data-tap]");
    if (tr && R.full[tr.dataset.tap]) { TAP.sel = tr.dataset.tap; TAP.plan = 0; tapRender(); $("tapOut").scrollIntoView({ behavior: "smooth", block: "start" }); }
  });
}
// ------------------------------------------------------------------ 🧩 Chart Pattern Screener & 🔄 Find Reversal (tab Screener)
const CPT = { res: null, sel: null, busy: false, nShown: -1, mode: "pattern", slots: { pattern: { res: null, sel: null }, reversal: { res: null, sel: null } } };
// sub-tab Screener: 📊 filter (screener lama) · 🧩 Chart Pattern · 🔄 Find Reversal — tiap sub-tab menyimpan hasilnya sendiri
function scrSub(sub) {
  document.querySelectorAll(".scr-subtabs button[data-ssub]").forEach((x) => x.classList.toggle("on", x.dataset.ssub === sub));
  $("scrFilterPane").classList.toggle("hidden", sub !== "filter");
  $("cpPane").classList.toggle("hidden", sub === "filter");
  if (sub === "filter") return;
  CPT.slots[CPT.mode] = { res: CPT.res, sel: CPT.sel };
  CPT.mode = sub; CPT.res = CPT.slots[sub].res; CPT.sel = CPT.slots[sub].sel;
  $("cpTitle").firstChild.textContent = sub === "reversal" ? "🔄 Find Reversal (fresh & terkonfirmasi) " : "🧩 Chart Pattern Screener ";
  $("cpRun").textContent = sub === "reversal" ? "🔄 Scan reversal" : "🧩 Scan pola";
  $("cpStatus").textContent = CPT.slots[sub].status || "";
  $("cpProg").innerHTML = CPT.busy && CPT.runMode === sub ? $("cpProg").innerHTML : "";
  if (CPT.res) cpRender(); else $("cpOut").innerHTML = "";
}
const cpPc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), cpR = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(2)}R`);
async function cpRun() {
  if (CPT.busy) return;
  const raw = ($("cpCoins").value || "50").trim();
  const runMode = CPT.mode;
  const body = { mode: runMode, tf: $("cpTf").value, coins: /^\d+$/.test(raw) ? +raw : raw, swing: $("cpSwing").value,
    fresh: +$("cpFresh").value || 10, hist: +$("cpHist").value || 30, wait: $("cpWait").checked };
  try { localStorage.setItem("cpForm", JSON.stringify(body)); } catch (e) { /* abaikan */ }
  CPT.busy = true; CPT.runMode = runMode; $("cpRun").disabled = true; CPT.sel = null; CPT.res = null; CPT.nShown = -1; $("cpOut").innerHTML = "";
  CPT.slots[runMode] = { res: null, sel: null };
  const here = () => CPT.mode === runMode;                                // hasil masuk ke sub-tab yang memulai scan
  const setRes = (r) => { if (here()) CPT.res = r; else CPT.slots[runMode].res = r; };
  cpProgress({ done: 0, total: 0, recent: [] }, body);
  try {
    const r = await fetch("/api/cpat/scan", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    for (;;) {
      const st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (st.status === "error") throw new Error(st.error);
      if (st.status === "done") { setRes(st.result); break; }
      if (here()) cpProgress(st, body);
      const P = st.partial;
      if (P && P.phase === "scan" && P.rows && P.rows.length !== CPT.nShown) { CPT.nShown = P.rows.length; setRes(P); if (here() && CPT.sel == null) cpRender(); }
      await new Promise((ok) => setTimeout(ok, 700));
    }
    const R = here() ? CPT.res : CPT.slots[runMode].res;
    $("cpProg").innerHTML = "";
    const nv = R.rows.filter((x) => x.status === "valid").length;
    const stx = `Selesai ${new Date().toLocaleTimeString()} · ${R.mode === "reversal" ? "Find Reversal" : "Chart Pattern"} ${R.tf.toUpperCase()} · ${R.scanned} koin dibaca · ✅ ${nv} valid · ⏳ ${R.rows.length - nv} menunggu · backtest ${R.learn.coins.length} koin lokal (${R.learn.n_rows} trade)` +
      (R.note && R.note.length ? " · ⚠️ " + R.note.join(" · ") : "") + (R.errors && R.errors.length ? ` · gagal: ${R.errors.length}` : "");
    CPT.slots[runMode].status = stx;
    if (here()) { $("cpStatus").textContent = stx; if (CPT.sel == null) cpRender(); }
  } catch (ex) {
    CPT.slots[runMode].status = "⚠️ " + ex.message;
    if (here()) $("cpStatus").textContent = "⚠️ " + ex.message;
    $("cpProg").innerHTML = "";
    $("cpOut").innerHTML = `<div class="card evalcard"><h3>⚠️ Gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { CPT.busy = false; $("cpRun").disabled = false; }
}
function cpProgress(st, body) {
  const P = st.partial || {}, ph = P.phase || "riwayat", pct = st.total ? Math.min(100, (100 * st.done) / st.total) : 0;
  const fmt = (s) => (s == null ? "—" : s >= 60 ? `${Math.floor(s / 60)} mnt ${Math.round(s % 60)} dtk` : `${Math.round(s)} dtk`);
  const rows = P.rows || [], nv = rows.filter((x) => x.status === "valid").length;
  const rec = (st.recent || []).slice(0, 8).map((r) => `<span class="chip${r.error ? " neg" : ""}">${r.error ? "⚠️ " : ""}${esc(String(r.symbol).replace(/^riwayat /, ""))}</span>`).join(" ");
  const steps = [["riwayat", `1️⃣ Backtest pola ${P.hist_done || 0}/${P.hist_total || body.hist} koin lokal`, "semua pola di riwayat TF ini × entry × TP (pertama kali saja; sesudahnya dari file)"],
    ["scan", `2️⃣ Scan live ${P.done || 0}/${P.total || "…"} koin`, "candle live Binance → pola valid / menunggu → entry · SL anti-gocekan (+ tembok) · TP"]];
  $("cpProg").innerHTML = `<div class="card evalcard tap-prog"><h3>⏳ Mencari ${body.mode === "reversal" ? "reversal" : "chart pattern"} · ${esc(body.tf.toUpperCase())}<span class="dots"></span></h3>
    <div class="tap-bar"><i style="width:${pct.toFixed(1)}%"></i><b>${pct.toFixed(0)}%</b></div>
    <div class="tap-steps">${steps.map(([k, t, h]) => `<div class="${ph === k ? "on" : (k === "riwayat" && ph === "scan") ? "done" : ""}"><b>${(k === "riwayat" && ph === "scan") ? "✅ " : ""}${t}</b><small>${h}</small></div>`).join("")}</div>
    <p>⏱️ berjalan <b>${fmt(st.elapsed)}</b> · perkiraan sisa <b>${fmt(st.eta)}</b>${ph === "scan" ? ` · sementara: <b class="pos">✅ ${nv} valid</b> · <b>⏳ ${rows.length - nv} menunggu</b>` : ""}</p>
    ${rec ? `<p class="hint">Baru diproses: ${rec}</p>` : ""}</div>`;
}
function cpSpec(p, R) {
  const long = p.dir === 1, mk = p.entry_kind === "market", S = p.stats || {}, wait = p.status === "wait";
  const C = (R.candles || {})[p.symbol] || [];
  const Rv = { symbol: p.symbol, tf: R.tf, icon: p.kind === "find reversal" ? "🔄" : "🧩", sub: `${p.name} · ${wait ? "menunggu" : "valid"}`, candles: C, nbar: 110,
    proj: p.proj, now_time: C.length ? C[C.length - 1][0] + 1 : Date.now(), now_price: C.length ? C[C.length - 1][4] : p.price_entry,
    pat: { lines: p.lines, shape: p.shape, pts: p.pts, trigger: wait && p.code !== "rv" ? p.trigger : null, dir: p.dir },
    boxes: [[wait ? "ENTRY*" : "ENTRY", pxTxt(p.price_entry), "#60a5fa", `${mk ? "market" : "limit"} · ${p.entry_txt}`.slice(0, 36)],
      ["STOP LOSS", pxTxt(p.price_sl), "#ff6b73", `anti-gocekan · risiko ${p.risk_pct.toFixed(2)}%`],
      ["TAKE PROFIT", pxTxt(p.price_tp), "#36e3a1", `${p.tp_txt} · RR 1:${(p.rr || 0).toFixed(2)}`],
      ["WR BACKTEST", cpPc(S.wr), (S.wr || 0) >= 50 ? "#36e3a1" : "#f5c451", S.n ? `${S.n} trade · ${cpR(S.exp_r)}/trade` : "belum ada backtest"],
      ["LAYAK?", S.ok ? "✅ YA" : "❌ BELUM", S.ok ? "#36e3a1" : "#ff6b73", S.ok ? "rata-rata untung (seperti Whale)" : S.n ? "rata-rata rugi / sampel < 30" : "tanpa backtest"]],
    footer: wait ? "⏳ menunggu · entry* berlaku kalau pola valid" : `✅ valid · break ${p.age} candle lalu`,
    insights: [{ t: wait ? `⏳ Kenapa menunggu: ${p.why}` : `✅ Valid: ${p.valid_txt} (${p.age} candle lalu).`, c: wait ? "#f5c451" : "#36e3a1", b: true },
      { t: `📊 Backtest pola ini (${S.entry_txt || "—"} · TP ${S.tp_txt || "—"}): ${S.n || 0} trade · WR ${cpPc(S.wr)} · ${cpR(S.exp_r)}/trade · data uji ${cpR(S.exp_test)} · tersentuh ${cpPc(S.fill_pct)}`, c: "#e6ebf2" }] };
  if (wait) Rv.badge = { text: `⏳ MENUNGGU · ${long ? "BUY" : "SELL"}*`, color: "#f5a524", status: p.code === "rv" ? "tunggu konfirmasi swing" : `tunggu close ${long ? ">" : "<"} ${pxTxt(p.trigger)}`, statusColor: "#f5a524" };
  else if (!S.ok) Rv.badge = { text: `${long ? "▲ BUY" : "▼ SELL"} · BELUM LAYAK`, color: "#8b96a5", status: S.n ? "rata-rata rugi di backtest" : "belum ada backtest", statusColor: "#ea3943" };
  const B = { dir: long ? 0 : 1, price_entry: p.price_entry, price_sl: p.price_sl, price_tp: p.price_tp, rr: Math.max(1, Math.floor(p.rr || 1)), entry: mk ? "market" : "limit",
    entry_txt: p.entry_txt, risk_pct: p.risk_pct, live: true, usable: !wait && !!S.ok, fill_pct: S.fill_pct,
    status: wait ? "menunggu konfirmasi" : mk ? "VALID · entry market" : "VALID · pasang limit" };
  return { R: Rv, B };
}
function cpRender() {
  const R = CPT.res, box = $("cpOut");
  if (!R) return;
  const rows = R.rows || [];
  const tbl = rows.length ? `<div class="card evalcard"><h3>${R.mode === "reversal" ? "🔄 Reversal" : "🧩 Chart pattern"} · ${esc((R.tf || "").toUpperCase())} <small class="hint">${rows.length} sinyal · klik baris untuk kartu visual, entry, contoh trade</small></h3>
    <div class="scroll" style="max-height:460px"><table class="tbl"><tr><th>Koin</th><th>Pola</th><th>Status</th><th>Kenapa / sejak</th><th class="num">Pemicu</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP</th><th class="num">RR</th><th class="num">WR</th><th class="num">R/trade</th><th>Layak</th></tr>` +
    rows.map((x, i) => { const S = x.stats || {}, w = x.status === "wait";
      return `<tr data-cpi="${i}" class="${CPT.sel === i ? "on" : ""}" title="Buka kartu visual"><td><b>${esc(x.symbol)}</b>${x.source === "lokal" ? ' <small class="hint">lokal</small>' : ""}</td>
      <td><span class="${x.dir === 1 ? "pos" : "neg"}">${x.dir === 1 ? "▲" : "▼"}</span> ${esc(x.name)}</td>
      <td>${w ? '<span class="badge warn">⏳ menunggu</span>' : '<span class="badge pass">✅ valid</span>'}</td>
      <td><small>${w ? esc((x.why || "").split(". Valid")[0]).slice(0, 90) : `break ${x.age} candle lalu · ${esc(x.entry_txt)}`}</small></td>
      <td class="num">${w && x.trigger != null && x.code !== "rv" ? `${x.dir === 1 ? ">" : "<"} ${pxTxt(x.trigger)}` : "—"}</td>
      <td class="num">${pxTxt(x.price_entry)}${w ? "*" : ""}${cpB(x.price_entry)}</td><td class="num neg">${pxTxt(x.price_sl)}${cpB(x.price_sl)}</td><td class="num pos">${pxTxt(x.price_tp)}${cpB(x.price_tp)}</td>
      <td class="num">1:${(x.rr || 0).toFixed(2)}</td><td class="num">${cpPc(S.wr)}</td><td class="num">${cpR(S.exp_r)}</td><td>${S.ok ? "✅" : "—"}</td></tr>`; }).join("") +
    `</table></div><p class="hint">* = entry yang berlaku kalau pola valid (belum aktif). 📋 = salin angka pakai koma.</p></div>`
    : `<div class="card evalcard"><p>Belum ada pola ${R.partial ? "(scan masih berjalan)" : "di koin yang di-scan — coba TF lain, swing 3, atau koin lebih banyak"}.</p></div>`;
  let det = "";
  const p = CPT.sel != null ? rows[CPT.sel] : null;
  if (p) {
    const sp = cpSpec(p, R), S = p.stats || {}, X = p.examples || [];
    const nw = X.filter((x) => x.filled && x.res === "TP").length, nl = X.filter((x) => x.filled && x.res !== "TP").length;
    det = `<div class="card evalcard"><div class="msc-card">${MSC.card(sp.R, sp.B, false)}</div>
      <div class="msc-btns"><span style="flex:1"></span><button class="mini" id="cpCopy">📋 Salin sinyal</button><button class="mini" id="cpDl">⬇ Unduh gambar</button><button class="mini" id="cpReplay">▶ Putar ulang animasi</button></div>
      <p class="tap-copy">${p.status === "wait" ? "Entry*" : "Entry"} <b>${pxTxt(p.price_entry)}</b>${cpB(p.price_entry)} · SL <b class="neg">${pxTxt(p.price_sl)}</b>${cpB(p.price_sl)} · TP <b class="pos">${pxTxt(p.price_tp)}</b>${cpB(p.price_tp)} <small class="hint">📋 = salin pakai koma</small></p>
      <ul class="hint">
        <li><b>${esc(p.name)}</b> (${esc(p.kind)}) · valid kalau: ${esc(p.valid_txt)}${p.status === "wait" ? ` · <b>⏳ ${esc(p.why)}</b>` : ` · ✅ break ${p.age} candle lalu`}</li>
        <li>Entry: ${esc(p.entry_txt)} · TP: ${esc(p.tp_txt)} (dipilih dari measured move / RR 1:2 / 1:3 yang terbaik di backtest)</li>
        <li>🛡️ SL anti-gocekan (logika Whale${p.sl_walls ? " + tembok order book live" : ", tanpa tembok"}): ${esc((p.sl_reasons || []).join("; "))}</li>
        <li>📊 Backtest ${S.n || 0} trade di riwayat: WR ${cpPc(S.wr)} · rata-rata ${cpR(S.exp_r)}/trade · data cari ${cpR(S.exp_fit)} · data uji ${cpR(S.exp_test)}${S.proven === false ? " (info: belum terbukti di 30% terakhir)" : ""} · limit tersentuh ${cpPc(S.fill_pct)}${S.fill_ok === false ? " (info: jarang tersentuh)" : ""} · median lama ${pcDur(S.bars_med, R.tf)}</li>
        <li>${S.ok ? "✅ Layak (seperti Whale): sampel ≥ 30 &amp; rata-rata untung." : "❌ Belum layak: rata-rata rugi atau sampel &lt; 30 — hanya untuk dipelajari."}</li></ul>
      ${X.length ? `<details><summary><b>🔍 Contoh trade</b> <small class="hint">${X.length} kejadian terbaru pola ini (semua koin riwayat) · ✅ TP ${nw} · ❌ ${nl} · klik baris = buka di Manual Replay</small></summary>
        <div class="scroll" style="max-height:380px"><table class="tbl"><tr><th>Waktu break (UTC)</th><th>Koin</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP</th><th>Terisi</th><th>Hasil</th><th>Data</th></tr>` +
        X.slice().reverse().map((x, i) => `<tr data-cpx="${X.length - 1 - i}" title="Buka di chart"><td>${fmtTime(x.t).slice(0, 16)}</td><td>${esc(x.sym)}</td><td class="num">${pxTxt(x.e)}</td><td class="num neg">${pxTxt(x.sl)}</td><td class="num pos">${pxTxt(x.tp)}</td>
          <td>${x.filled ? (x.fb ? `✅ ${pcDur(x.fb, R.tf)}` : "✅ market") : "❌ tidak terisi"}</td><td class="${x.res === "TP" ? "pos" : x.res === "SL" ? "neg" : ""}">${x.filled ? `${esc(x.res)} (${cpR(x.R)})` : "—"}</td><td>${x.test ? "uji" : "cari"}</td></tr>`).join("") +
        `</table></div></details>` : `<p class="hint">🔍 Belum ada contoh trade untuk pola ini di riwayat koin lokal.</p>`}</div>`;
  }
  if (p) {                                                              // tampilan kartu: tabel disembunyikan, ada tombol kembali
    const n = rows.length;
    box.innerHTML = `<div class="cp-nav"><button class="mini" id="cpBack">← Kembali ke daftar (${n} sinyal)</button><span class="hint">${CPT.sel + 1} / ${n} · ${esc(p.symbol)} · ${esc(p.name)}</span><span style="flex:1"></span>
      <button class="mini" id="cpPrev" ${CPT.sel <= 0 ? "disabled" : ""}>◀ Sebelumnya</button><button class="mini" id="cpNext" ${CPT.sel >= n - 1 ? "disabled" : ""}>Berikutnya ▶</button></div>` + det;
  } else box.innerHTML = tbl;
}
{
  const tfs = ["5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"];
  $("cpTf").innerHTML = tfs.map((t) => `<option value="${t}">${t.toUpperCase()}</option>`).join("");
  let f = {};
  try { f = JSON.parse(localStorage.getItem("cpForm") || "{}") || {}; } catch (e) { f = {}; }
  $("cpTf").value = f.tf || "1h"; if (f.coins != null) $("cpCoins").value = f.coins;
  $("cpSwing").value = String(f.swing || "3"); if (f.fresh) $("cpFresh").value = f.fresh; if (f.hist) $("cpHist").value = f.hist; if (f.wait === false) $("cpWait").checked = false;
  $("cpRun").onclick = cpRun;
  document.querySelector(".scr-subtabs").addEventListener("click", (e) => { const b = e.target.closest("button[data-ssub]"); if (b) scrSub(b.dataset.ssub); });
  $("cpOut").addEventListener("click", async (e) => {
    const R = CPT.res;
    if (!R) return;
    const p = CPT.sel != null ? R.rows[CPT.sel] : null;
    if (p && ["cpCopy", "cpDl", "cpReplay"].includes(e.target.id)) {
      const sp = cpSpec(p, R);
      if (e.target.id === "cpCopy") { await copyText(MSC.signal(sp.R, sp.B) + (p.status === "wait" ? `\n⏳ ${p.why}` : "")); return toast("Sinyal disalin 📋"); }
      if (e.target.id === "cpDl") { try { await MSC.download(sp.R, sp.B); } catch (ex) { toast("Gagal membuat gambar: " + ex.message); } return; }
      return cpRender();
    }
    const tx = e.target.closest("tr[data-cpx]");
    if (tx && p) {
      const x = (p.examples || [])[+tx.dataset.cpx];
      if (!x) return;
      await openMoment(x.sym, R.tf, x.t, [
        { price: x.e, color: "#42a5f5", size: 2, label: `E ${pxTxt(x.e)}` },
        { price: x.sl, color: "#ef5350", dash: true, label: `SL ${pxTxt(x.sl)}` },
        { price: x.tp, color: "#26a69a", dash: true, label: `TP ${pxTxt(x.tp)}` }].concat((x.pts || []).filter((q) => q[2]).map((q) => ({ point: true, time: q[0], price: q[1], label: q[2] }))),
        `🧩 ${p.name} di ${x.sym}, break ${fmtTime(x.t).slice(0, 16)} UTC. ${x.filled ? (x.fb ? `Limit terisi ${pcDur(x.fb, R.tf)} kemudian. ` : "") + `Hasil: ${x.res} (${cpR(x.R)}).` : "Limit tidak terisi."} Step maju untuk melihat.`);
      return;
    }
    if (["cpBack", "cpPrev", "cpNext"].includes(e.target.id)) {
      CPT.sel = e.target.id === "cpBack" ? null : Math.max(0, Math.min(R.rows.length - 1, CPT.sel + (e.target.id === "cpNext" ? 1 : -1)));
      cpRender(); $("cpPane").scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const tr = e.target.closest("tr[data-cpi]");
    if (tr && !e.target.closest(".cpb, .cp-ic, button")) { CPT.sel = +tr.dataset.cpi; cpRender(); $("cpPane").scrollTo({ top: 0, behavior: "smooth" }); }
  });
}
// ------------------------------------------------------------------ 🧠 TA Pro › 💧 Liquidity Sweep backtest (sub-tab)
const SWP = { res: null, busy: false };
const swPc = (v) => (v == null ? "—" : `${v.toFixed(0)}%`), swR = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(2)}R`);
function tapSub(sub) {
  document.querySelectorAll(".tap-subtabs button[data-tsub]").forEach((x) => x.classList.toggle("on", x.dataset.tsub === sub));
  $("tapMain").classList.toggle("hidden", sub !== "main");
  $("swPane").classList.toggle("hidden", sub !== "sweep");
}
async function swRun() {
  if (SWP.busy) return;
  const body = { tf: $("swTf").value, hist: +$("swHist").value || 30 };
  SWP.busy = true; $("swRun").disabled = true; $("swOut").innerHTML = "";
  const fmt = (x) => (x == null ? "—" : x >= 60 ? `${Math.floor(x / 60)} mnt ${Math.round(x % 60)} dtk` : `${Math.round(x)} dtk`);
  try {
    const r = await fetch("/api/sweep/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    for (;;) {
      const st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (st.status === "error") throw new Error(st.error);
      if (st.status === "done") { SWP.res = st.result; break; }
      swProgress(st, body, fmt);
      await new Promise((ok) => setTimeout(ok, 800));
    }
    $("swProg").innerHTML = "";
    const R = SWP.res;
    $("swStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${R.tf.toUpperCase()} · ${R.n_events} sweep di ${R.coins.length} koin lokal · ${R.n_trades || R.n_rows} trade diuji${R.from_file ? " · dari file tersimpan" : ` · ${R.elapsed} dtk`} · 💾 tersimpan di 📂 Hasil tersimpan`;
    swRender();
    if ($("swSavedBox").open) savedResults("sweeplab", $("swSaved"), swOpenSaved);
  } catch (ex) {
    $("swProg").innerHTML = ""; $("swStatus").textContent = "⚠️ " + ex.message;
    $("swOut").innerHTML = `<div class="card evalcard"><h3>⚠️ Gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { SWP.busy = false; $("swRun").disabled = false; }
}
// panel progres: fase, persen, waktu, jumlah sweep & trade sejauh ini, koin terbaru, ringkasan sementara
function swProgress(st, body, fmt) {
  const P = st.partial || {}, ph = P.phase || "riwayat", pct = ph === "analisa" ? 99 : st.total ? (100 * st.done) / st.total : 0;
  const steps = [["riwayat", `1️⃣ Cari sweep & uji trade · ${P.done || st.done || 0}/${P.total || st.total || "?"} koin`, "level likuiditas → sweep → 3 konfirmasi × 3 entry × 3 TP (beberapa koin sekaligus)"],
    ["analisa", "2️⃣ Nilai tiap penyaring & cari kombinasi", "data cari 70% · data uji 30%"]];
  const chips = (P.per_coin || []).slice().reverse().map((c) => `<span class="chip">${esc(c.sym)} · ${c.sweeps} sweep</span>`).join(" ");
  const B = P.best, helps = (P.filters || []).filter((f) => f.helps).slice(0, 4);
  $("swProg").innerHTML = `<div class="card evalcard tap-prog"><h3>⏳ Backtest sweep ${esc(body.tf.toUpperCase())} · ${body.hist} koin lokal<span class="dots"></span></h3>
    <div class="tap-bar"><i style="width:${pct.toFixed(1)}%"></i><b>${pct.toFixed(0)}%</b></div>
    <div class="tap-steps">${steps.map(([k, t, h]) => `<div class="${ph === k ? "on" : k === "riwayat" && ph === "analisa" ? "done" : ""}"><b>${k === "riwayat" && ph === "analisa" ? "✅ " : ""}${t}</b><small>${h}</small></div>`).join("")}</div>
    <p>⏱️ berjalan <b>${fmt(st.elapsed)}</b> · perkiraan sisa <b>${ph === "analisa" ? "sebentar lagi" : fmt(st.eta)}</b>${P.n_events != null ? ` · <b>${P.n_events.toLocaleString("id-ID")}</b> sweep ditemukan` : ""}${P.candles ? ` · ${(P.candles / 1e6).toFixed(1)} jt candle dibaca` : ""}</p>
    ${chips ? `<p class="hint">Baru selesai: ${chips}</p>` : ""}
    ${B ? `<div class="sw-live"><b>📊 Sementara</b> (${(P.coins || []).length} koin): cara terbaik <b>${esc(B.txt)}</b> → ${B.all.n} trade · WR ${swPc(B.all.wr)} · <b class="${(B.all.exp || 0) > 0 ? "pos" : "neg"}">${swR(B.all.exp)}/trade</b>
      ${helps.length ? `<br>Penyaring yang sejauh ini menaikkan: ${helps.map((f) => `<b>${esc(f.group)}: ${esc(f.val)}</b> (${swR(f.up_fit)})`).join(", ")}` : ""}</div>` : ""}
    ${P.skipped && P.skipped.length ? `<p class="hint">⚠️ dilewati: ${P.skipped.map(esc).join(" · ")}</p>` : ""}</div>`;
}
function swRow(lab, S, extra) {
  return `<td class="num">${S.all.n}</td><td class="num">${swPc(S.all.wr)}</td><td class="num"><b class="${(S.all.exp || 0) > 0 ? "pos" : "neg"}">${swR(S.all.exp)}</b></td>
    <td class="num">${swR(S.fit.exp)}</td><td class="num">${swR(S.test.exp)}</td>${extra || ""}`;
}
function swDur(h) { if (h == null) return "—"; return h < 24 ? `${+h.toFixed(h < 10 ? 1 : 0)} jam` : `${(h / 24).toFixed(1).replace(".", ",")} hari`; }
function swReg(x) { return x.reg ? `${esc(x.reg)} · ${swDur(x.dur_h)}` : "—"; }
function swRsi(v) { return v == null ? "—" : `<span class="${v >= 70 ? "neg" : v <= 30 ? "pos" : ""}">${Math.round(v)}</span>`; }
function swRender() {
  const R = SWP.res, box = $("swOut");
  if (!R || !R.best) { box.innerHTML = `<div class="card evalcard"><p>Tidak ada sweep yang bisa diuji di data ini.</p></div>`; return; }
  const B = R.best, base = R.base, F = R.filters || [];
  const verdict = (f) => f.helps ? '<span class="badge pass">✅ menaikkan</span>' : (f.up_fit || 0) >= 0.05 && f.fit.n >= 30 ? '<span class="badge warn">⚠️ naik di data cari saja</span>'
    : (f.up_fit || 0) <= -0.05 && f.fit.n >= 30 ? '<span class="badge fail">❌ menurunkan</span>' : '<span class="hint">— beda kecil / sampel sedikit</span>';
  const bar = (u) => { if (u == null) return ""; const w = Math.min(60, Math.abs(u) * 60); return `<span class="sw-bar ${u >= 0 ? "up" : "dn"}" style="width:${w}px"></span>`; };
  let g0 = "";
  const ftbl = F.map((f) => { const head = f.group !== g0 ? `<tr class="sw-g"><td colspan="9"><b>${esc(f.group)}</b></td></tr>` : ""; g0 = f.group;
    return head + `<tr><td>${esc(f.val)}</td>${swRow("", f)}<td class="num">${f.up_fit == null ? "—" : swR(f.up_fit)} ${bar(f.up_fit)}</td><td class="num">${f.up_test == null ? "—" : swR(f.up_test)}</td><td>${verdict(f)}</td></tr>`; }).join("");
  const helps = F.filter((f) => f.helps), hurts = F.filter((f) => (f.up_fit || 0) <= -0.05 && f.fit.n >= 30 && (f.up_test || 0) < 0);
  const C = R.combo || {}, last = C.steps && C.steps.length ? C.steps[C.steps.length - 1] : null;
  const steps = (C.steps || []).map((s, i) => `<tr><td>${i + 1}. + ${esc(s.add)}</td>${swRow("", s)}</tr>`).join("");
  const conf = (R.conf || []).map((c) => `<tr><td>${esc(c.txt.split(" · ")[0])}${c.key === B.key ? " ⭐" : ""}</td>${swRow("", c)}<td>${c.ok ? "✅" : "—"}</td></tr>`).join("");
  const caras = (R.caras || []).map((c) => `<tr><td>${esc(c.txt)}${c.key === B.key ? " ⭐" : ""}</td>${swRow("", c, `<td class="num">${swPc(c.all.fill)}</td>`)}<td>${c.ok ? "✅" : "—"}</td></tr>`).join("");
  const SLT = R.sl_table || [];
  const sltbl = SLT.map((r) => `<tr${r.is_best ? ' class="sw-best"' : ""}><td><b>${esc(r.txt)}</b>${r.is_best ? " ⭐" : ""}</td>` +
    (r.best ? `${swRow("", r.best)}<td>${r.best.ok ? "✅" : "—"}</td><td><small>${esc(r.best.txt.split(" · ").slice(0, 3).join(" · "))}</small></td>` : `<td colspan="7" class="hint">tidak ada trade</td>`) +
    `<td class="num">${r.same && r.same.all.n ? `${r.same.all.n} · <b class="${(r.same.all.exp || 0) > 0 ? "pos" : "neg"}">${swR(r.same.all.exp)}</b>` : "—"}</td></tr>`).join("");
  const X = R.examples || [];
  const H = `<tr><th></th><th class="num">Trade</th><th class="num">WR</th><th class="num">R/trade</th><th class="num">Data cari</th><th class="num">Data uji</th>`;
  box.innerHTML = `<div class="card evalcard" id="swVis"></div><div class="card evalcard"><h3>💧 Ringkasan · ${esc(R.tf.toUpperCase())} · ${R.n_events} sweep di ${R.coins.length} koin</h3>
      <ul>
        <li>Cara terbaik ⭐: <b>${esc(B.txt)}</b> → ${B.all.n} trade · WR ${swPc(B.all.wr)} · <b class="${(B.all.exp || 0) > 0 ? "pos" : "neg"}">${swR(B.all.exp)}/trade</b> (data cari ${swR(B.fit.exp)} · data uji ${swR(B.test.exp)}) · ${B.ok ? "✅ layak (seperti Whale: ≥ 30 trade & rata-rata untung)" : "❌ belum layak"}</li>
        <li>Penyaring yang <b class="pos">terbukti menaikkan</b>: ${helps.length ? helps.map((f) => `<b>${esc(f.group)}: ${esc(f.val)}</b> (${swR(f.up_fit)} cari · ${swR(f.up_test)} uji)`).join(", ") : "<i>tidak ada</i>"}</li>
        <li>Penyaring yang <b class="neg">menurunkan</b> (sebaiknya dihindari): ${hurts.length ? hurts.map((f) => `<b>${esc(f.group)}: ${esc(f.val)}</b>`).join(", ") : "<i>tidak ada</i>"}</li>
        <li>Kombinasi terbaik: ${C.labels && C.labels.length ? `<b>${C.labels.map(esc).join(" + ")}</b> → ${last.all.n} trade · WR ${swPc(last.all.wr)} · ${swR(last.all.exp)}/trade (uji ${swR(last.test.exp)}) ${C.proven ? '<span class="badge pass">✅ terbukti di data uji</span>' : '<span class="badge warn">⚠️ belum terbukti di data uji</span>'}` : "<i>tidak ada penyaring yang menaikkan ≥ +0,05R dengan sampel cukup</i>"}</li>
      </ul></div>
    ${SLT.length ? `<div class="card evalcard"><h3>🛡️ SL terbaik untuk ${esc(R.tf.toUpperCase())} <small class="hint">tiap pilihan SL dengan cara terbaiknya sendiri · kolom terakhir = cara juara ⭐ (konfirmasi, entry, TP sama) kalau SL-nya diganti · TP minimal RR 1:2</small></h3>
      <div class="scroll"><table class="tbl">${H}<th>Layak</th><th>Cara terbaik dgn SL ini</th><th class="num">Cara ⭐ dgn SL ini</th></tr>${sltbl}</table></div>
      <p class="hint">SL ATR = harga entry ∓ k × ATR(14) TF sinyal saat konfirmasi (tanpa batas 4%). SL anti-gocekan = cara lama (ekor sweep ± 0,2 ATR digabung SL Whale, maks 4%).</p></div>` : ""}
    <div class="card evalcard"><h3>🎛️ Efek tiap penyaring <small class="hint">pada cara terbaik ⭐ · tanpa penyaring: ${base.all.n} trade · ${swR(base.all.exp)}/trade (cari ${swR(base.fit.exp)} · uji ${swR(base.test.exp)})</small></h3>
      <div class="scroll"><table class="tbl">${H}<th class="num">vs tanpa penyaring (cari)</th><th class="num">vs (uji)</th><th>Kesimpulan</th></tr>${ftbl}</table></div></div>
    <div class="card evalcard"><h3>🧩 Kombinasi terbaik <small class="hint">penyaring ditambah satu per satu (dipilih di data cari, dicek di data uji)</small></h3>
      ${steps ? `<div class="scroll"><table class="tbl">${H}</tr><tr><td>tanpa penyaring</td>${swRow("", base)}</tr>${steps}</table></div>` : `<p class="hint">Tidak ada kombinasi yang menaikkan hasil dengan sampel ≥ 30.</p>`}</div>
    <div class="card evalcard"><h3>✅ Konfirmasi <small class="hint">entry, TP & SL sama dengan cara terbaik</small></h3>
      <div class="scroll"><table class="tbl">${H}<th>Layak</th></tr>${conf}</table></div></div>
    <details class="card evalcard"><summary><b>📋 Semua cara (konfirmasi × entry × TP × SL)</b> <small class="hint">${(R.caras || []).length} teratas dari ${R.n_caras || (R.caras || []).length} · urut layak lalu R per sinyal</small></summary>
      <div class="scroll"><table class="tbl">${H}<th class="num">Terisi</th><th>Layak</th></tr>${caras}</table></div></details>
    ${X.length ? `<details class="card evalcard" open><summary><b>🔍 Contoh trade</b> <small class="hint">${X.length} terbaru${C.labels && C.labels.length ? " dengan kombinasi terbaik" : " cara terbaik"} · klik baris = gambar visual di atas</small></summary>
      <div class="scroll" style="max-height:380px"><table class="tbl"><tr><th>Sweep (UTC)</th><th>Koin</th><th>Arah</th><th>Level</th><th class="num">Entry</th><th class="num">SL</th><th class="num">TP</th><th>SL</th><th class="num">ADX</th><th class="num">RSI entry → hit</th><th>Kondisi market (lama)</th><th>Hasil</th><th>Sesi</th><th>Data</th></tr>` +
      X.slice().reverse().map((x, i) => `<tr data-swx="${X.length - 1 - i}" title="Buka di chart"><td>${fmtTime(x.t).slice(0, 16)}</td><td>${esc(x.sym)}</td><td class="${x.d === 1 ? "pos" : "neg"}">${x.d === 1 ? "▲ BUY" : "▼ SELL"}</td>
        <td><small>${(x.types || []).map((t) => esc(t)).join(", ")} ${pxTxt(x.L)}</small></td><td class="num">${pxTxt(x.e)}</td><td class="num neg">${pxTxt(x.sl)}</td><td class="num pos">${pxTxt(x.tp)}</td>
        <td><small>${!x.slm || x.slm === "anti" ? "anti-gocek" : esc(x.slm.slice(3).replace(".", ",")) + " ATR"}</small></td><td class="num">${x.adx == null ? "—" : x.adx.toFixed(0)}</td><td class="num">${x.filled ? `${swRsi(x.rsi_e)} → ${swRsi(x.rsi_x)}` : "—"}</td><td><small>${swReg(x)}</small></td>
        <td class="${x.res === "TP" ? "pos" : x.res === "SL" ? "neg" : ""}">${x.filled ? `${esc(x.res)} (${swR(x.R)})` : "tidak terisi"}</td><td><small>${esc(x.sess)}</small></td><td>${x.test ? "uji" : "cari"}</td></tr>`).join("") + `</table></div></details>` : ""}`;
  const firstWin = X.slice().reverse().findIndex((x) => x.res === "TP");
  if (X.length) swVisual(firstWin >= 0 ? X.length - 1 - firstWin : X.length - 1); else $("swVis").remove();
}
function swOpenSaved(res) { SWP.res = res; $("swStatus").textContent = `Hasil tersimpan dibuka · ${String(res.tf).toUpperCase()} · ${res.n_events} sweep di ${(res.coins || []).length} koin`; swRender(); }
// 🖼️ gambar visual 1 contoh trade dari candle lokal: level yang disapu, candle sweep, entry / SL / TP & hasil asli
async function swVisual(idx) {
  const R = SWP.res, x = R && R.examples[idx], box = $("swVis");
  if (!x || !box) return;
  SWP.vis = idx;
  box.innerHTML = `<h3>🖼️ Contoh visual <small class="hint">memuat candle ${esc(x.sym)}…</small></h3>`;
  let D;
  try { const r = await fetch(`/api/sweep/candles?sym=${encodeURIComponent(x.sym)}&tf=${R.tf}&t=${x.t}`); D = await r.json(); if (!r.ok) throw new Error(D.detail || r.statusText); }
  catch (e) { box.innerHTML = `<h3>🖼️ Contoh visual</h3><p class="hint">Candle lokal ${esc(x.sym)} tidak bisa dibaca: ${esc(e.message)}</p>`; return; }
  const C = D.candles, s0 = D.i, W = 1100, Hh = 360, L0 = 10, L1 = 980, T0 = 14, B0 = 330;
  const jE = s0 + (x.jo || 0), jF = jE + (x.fb || 0), jX = x.xo != null ? s0 + x.xo : Math.min(C.length - 1, jF + 20);
  const lv = [x.e, x.sl, x.tp, x.L];
  let lo = Math.min(...C.map((c) => c[3]), ...lv), hi = Math.max(...C.map((c) => c[2]), ...lv); const pad = (hi - lo) * 0.06; lo -= pad; hi += pad;
  const X_ = (i) => L0 + (L1 - L0) * (i + 0.5) / C.length, Y = (v) => B0 - (B0 - T0) * (v - lo) / (hi - lo), bw = Math.max(2, (L1 - L0) / C.length * 0.6);
  let g = "";
  for (let k = 0; k <= 4; k++) { const v = lo + (hi - lo) * k / 4; g += `<line x1="${L0}" x2="${L1}" y1="${Y(v)}" y2="${Y(v)}" stroke="var(--border)"/><text x="${L1 + 6}" y="${Y(v) + 4}" fill="var(--muted)" font-size="10">${pxTxt(v)}</text>`; }
  const up = x.d === 1, zx0 = X_(jF), zx1 = X_(Math.max(jX, jF + 1));
  g += `<rect x="${zx0}" width="${zx1 - zx0}" y="${Y(Math.max(x.e, x.tp))}" height="${Math.abs(Y(x.e) - Y(x.tp))}" fill="var(--up)" opacity=".12"/>`;
  g += `<rect x="${zx0}" width="${zx1 - zx0}" y="${Y(Math.max(x.e, x.sl))}" height="${Math.abs(Y(x.e) - Y(x.sl))}" fill="var(--down)" opacity=".12"/>`;
  g += `<line x1="${L0}" x2="${L1}" y1="${Y(x.L)}" y2="${Y(x.L)}" stroke="var(--warn)" stroke-width="1.6" stroke-dasharray="7 4"/><text x="${L0 + 4}" y="${Y(x.L) + (up ? 14 : -6)}" fill="var(--warn)" font-size="11" font-weight="700">level disapu (${(x.types || []).join(", ")}) ${pxTxt(x.L)}</text>`;
  C.forEach((c, i) => { const col = c[4] >= c[1] ? "var(--up)" : "var(--down)", X0 = X_(i);
    g += `<line x1="${X0}" x2="${X0}" y1="${Y(c[2])}" y2="${Y(c[3])}" stroke="${col}"/><rect x="${X0 - bw / 2}" width="${bw}" y="${Y(Math.max(c[1], c[4]))}" height="${Math.max(1, Math.abs(Y(c[1]) - Y(c[4])))}" fill="${col}"/>`; });
  const sw = C[s0];
  if (sw) g += `<rect x="${X_(s0) - bw}" width="${bw * 2}" y="${Y(sw[2]) - 4}" height="${Y(sw[3]) - Y(sw[2]) + 8}" fill="none" stroke="var(--warn)" stroke-width="2" rx="3"/><text x="${X_(s0)}" y="${up ? Y(sw[3]) + 18 : Y(sw[2]) - 10}" text-anchor="middle" fill="var(--warn)" font-size="11" font-weight="700">SWEEP</text>`;
  if (x.jo) g += `<circle cx="${X_(jE)}" cy="${Y(C[jE] ? C[jE][4] : x.e)}" r="5" fill="none" stroke="var(--accent)" stroke-width="2"/><text x="${X_(jE)}" y="${Y(C[jE] ? C[jE][4] : x.e) - 9}" text-anchor="middle" fill="var(--accent)" font-size="10" font-weight="700">konfirmasi</text>`;
  const hl = (v, col, lab, dash) => { g += `<line x1="${zx0}" x2="${zx1}" y1="${Y(v)}" y2="${Y(v)}" stroke="${col}" stroke-width="1.8" ${dash ? 'stroke-dasharray="5 4"' : ""}/><text x="${zx1 + 4}" y="${Y(v) + 4}" fill="${col}" font-size="11" font-weight="700">${lab} ${pxTxt(v)}</text>`; };
  hl(x.e, "var(--accent)", "ENTRY"); hl(x.sl, "var(--down)", "SL", true); hl(x.tp, "var(--up)", "TP", true);
  if (x.filled && C[jX]) { const ok = x.res === "TP", yv = ok ? x.tp : x.res === "SL" ? x.sl : C[jX][4];
    g += `<circle cx="${X_(jX)}" cy="${Y(yv)}" r="7" fill="none" stroke="${ok ? "var(--up)" : "var(--down)"}" stroke-width="2.5"/><text x="${X_(jX)}" y="${Y(yv) + (ok === up ? -12 : 20)}" text-anchor="middle" fill="${ok ? "var(--up)" : "var(--down)"}" font-size="11" font-weight="800">${ok ? "✅ TP" : x.res === "SL" ? "❌ SL" : "⏱ waktu habis"}</text>`; }
  const n = R.examples.length;
  box.innerHTML = `<h3>🖼️ Contoh visual · ${esc(x.sym)} · ${x.d === 1 ? "sweep low → BUY" : "sweep high → SELL"} · ${fmtTime(x.t).slice(0, 16)} UTC
      <small class="hint">${idx + 1}/${n} · ${x.filled ? `${esc(x.res)} (${swR(x.R)})` : "limit tidak terisi"} · sesi ${esc(x.sess)} · ${x.test ? "data uji" : "data cari"}</small></h3>
    <div class="sw-info"><span>🛡️ SL: <b>${esc((R.sl_table || []).find((r) => r.sl === x.slm)?.txt || x.slm || "anti")}</b></span><span>📈 ADX saat sweep: <b>${x.adx == null ? "—" : x.adx.toFixed(1)}</b></span>
      <span>RSI entry → hit: <b>${x.filled ? `${swRsi(x.rsi_e)} → ${swRsi(x.rsi_x)}` : "—"}</b></span><span>🌐 Market: <b>${swReg(x)}</b></span><span>RR 1:${(x.rr || 0).toFixed(2).replace(".", ",")}</span></div>
    <svg viewBox="0 0 ${W} ${Hh}" class="sw-svg" role="img" aria-label="Contoh trade sweep">${g}</svg>
    <div class="msc-btns"><button class="mini" data-swv="-1" ${idx <= 0 ? "disabled" : ""}>◀ Sebelumnya</button><button class="mini" data-swv="1" ${idx >= n - 1 ? "disabled" : ""}>Berikutnya ▶</button>
      <span style="flex:1"></span><button class="mini" data-swreplay="${idx}">▶ Buka di Manual Replay</button></div>
    <p class="hint">Garis kuning putus-putus = level likuiditas yang disapu · kotak kuning = candle sweep (ekor tembus, close balik) · lingkaran biru = candle konfirmasi · area hijau / merah = TP / SL sampai trade selesai (candle asli dari data lokal). Kondisi market: ADX(14) ≥ 20 = trend, &lt; 20 = sideway; bullish/bearish dari close vs EMA50 & arah EMA50; lama = berapa lama status trend/sideway itu sudah berjalan saat sweep.</p>`;
}
{
  document.querySelector(".tap-subtabs").addEventListener("click", (e) => { const b = e.target.closest("button[data-tsub]"); if (b) tapSub(b.dataset.tsub); });
  $("swRun").onclick = swRun;
  $("swSavedBox").addEventListener("toggle", () => { if ($("swSavedBox").open) savedResults("sweeplab", $("swSaved"), swOpenSaved); });
  $("swOut").addEventListener("click", async (e) => {
    if (!SWP.res) return;
    const nv = e.target.closest("[data-swv]");
    if (nv) { swVisual(SWP.vis + +nv.dataset.swv); return; }
    const tv = e.target.closest("tr[data-swx]");
    if (tv) { swVisual(+tv.dataset.swx); $("swVis").scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    const tr = e.target.closest("[data-swreplay]");
    if (!tr) return;
    const x = SWP.res.examples[+tr.dataset.swreplay];
    await openMoment(x.sym, SWP.res.tf, x.t, [
      { price: x.L, color: "#f0b90b", dash: true, label: `level disapu ${pxTxt(x.L)}` },
      { price: x.e, color: "#42a5f5", size: 2, label: `E ${pxTxt(x.e)}` },
      { price: x.sl, color: "#ef5350", dash: true, label: `SL ${pxTxt(x.sl)}` },
      { price: x.tp, color: "#26a69a", dash: true, label: `TP ${pxTxt(x.tp)}` }],
      `💧 Sweep ${x.d === 1 ? "low → BUY" : "high → SELL"} di ${x.sym} ${fmtTime(x.t).slice(0, 16)} UTC (level ${(x.types || []).join(", ")}). Hasil: ${x.filled ? `${x.res} (${swR(x.R)})` : "limit tidak terisi"}. Step maju untuk melihat.`);
  });
}
// ---- 📚 Info Trading (tab sendiri): materi dimuat & diputar saat tab dibuka
document.querySelector('.tab[data-tab="edu"]').addEventListener("click", () => { if (window.EDU) EDU.load(); });
// ---- 🕘 History Update (tab sendiri): riwayat versi + alur kerja tiap menu
document.querySelector('.tab[data-tab="hist"]').addEventListener("click", () => { if (window.HIST) HIST.load(); });
// ------------------------------------------------------------------ 🛡️ SL Backtest (tab sendiri)
const SBT = { res: null, busy: false, vis: 0 };
const SB_STRAT = { whale: "🐋 Whale · 🎯 Cari setup", ms: "📐 Market Structure · Scan banyak koin", tapro: "🧠 TA Pro Advance", cpat: "🧩 Chart Pattern", rev: "🔄 Find Reversal" };
const SB_RES = { win: ["WIN", "pos"], tp1: ["TP1 (+1R)", "pos"], half: ["½ TP1 (+0,5R)", ""], sl: ["SL", "neg"], lose: ["LOSE", "neg"] };
const sbK = (k) => (k == null ? "—" : `${String(k).replace(".", ",")} ATR`);
async function sbRun() {
  if (SBT.busy) return;
  const body = { strat: $("sbStrat").value, tf: $("sbTf").value, hist: +$("sbHist").value || 30 };
  SBT.busy = true; $("sbRun").disabled = true; $("sbOut").innerHTML = "";
  const fmt = (x) => (x == null ? "—" : x >= 60 ? `${Math.floor(x / 60)} mnt ${Math.round(x % 60)} dtk` : `${Math.round(x)} dtk`);
  try {
    const r = await fetch("/api/slbt/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    for (;;) {
      const st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (st.status === "error") throw new Error(st.error);
      if (st.status === "done") { SBT.res = st.result; break; }
      sbProgress(st, body, fmt);
      await new Promise((ok) => setTimeout(ok, 800));
    }
    $("sbProg").innerHTML = "";
    const R = SBT.res;
    $("sbStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${SB_STRAT[R.strat]} · ${R.tf.toUpperCase()} · ${R.n} trade di ${R.coins.length} koin lokal${R.from_file ? " · dari file tersimpan" : ` · ${R.elapsed} dtk`} · 💾 tersimpan di 📂 Hasil tersimpan`;
    sbRender();
    if ($("sbSavedBox").open) savedResults("slbt", $("sbSaved"), sbOpenSaved);
  } catch (ex) {
    $("sbProg").innerHTML = ""; $("sbStatus").textContent = "⚠️ " + ex.message;
    $("sbOut").innerHTML = `<div class="card evalcard"><h3>⚠️ Gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { SBT.busy = false; $("sbRun").disabled = false; }
}
function sbProgress(st, body, fmt) {
  const P = st.partial || {}, ph = P.phase || "riwayat", pct = ph === "analisa" ? 99 : st.total ? (100 * st.done) / st.total : 0;
  const steps = [["riwayat", `1️⃣ Cari sinyal & uji 12 SL · ${P.done || st.done || 0}/${P.total || st.total || "?"} koin`, "SL default + SL ATR 1 … 6 tiap trade (beberapa koin sekaligus)"],
    ["analisa", "2️⃣ Hitung SL terbaik", "ATR paling sering WIN · kotak ATR · 30% data terakhir"]];
  const chips = (P.per_coin || []).slice().reverse().map((c) => `<span class="chip">${esc(c.sym)} · ${c.n} trade</span>`).join(" ");
  const B = P.best, D = P.default;
  $("sbProg").innerHTML = `<div class="card evalcard tap-prog"><h3>⏳ SL Backtest · ${esc(SB_STRAT[body.strat])} · ${esc(body.tf.toUpperCase())} · ${body.hist} koin lokal<span class="dots"></span></h3>
    <div class="tap-bar"><i style="width:${pct.toFixed(1)}%"></i><b>${pct.toFixed(0)}%</b></div>
    <div class="tap-steps">${steps.map(([k, t, h]) => `<div class="${ph === k ? "on" : k === "riwayat" && ph === "analisa" ? "done" : ""}"><b>${k === "riwayat" && ph === "analisa" ? "✅ " : ""}${t}</b><small>${h}</small></div>`).join("")}</div>
    <p>⏱️ berjalan <b>${fmt(st.elapsed)}</b> · perkiraan sisa <b>${ph === "analisa" ? "sebentar lagi" : fmt(st.eta)}</b>${P.n != null ? ` · <b>${P.n.toLocaleString("id-ID")}</b> trade diuji` : ""}${P.candles ? ` · ${(P.candles / 1e6).toFixed(1)} jt candle dibaca` : ""}</p>
    ${chips ? `<p class="hint">Baru selesai: ${chips}</p>` : ""}
    ${B ? `<div class="sw-live"><b>📊 Sementara</b> (${(P.coins || []).length} koin): ⭐ SL terbaik <b>${sbK(B.k)}</b> → ${B.all.win} WIN dari ${P.n} trade (WR ${swPc(B.all.wr)} · ${swR(B.all.exp)}/trade)
      ${D && D.n ? ` · SL default strategi: WR ${swPc(D.wr)} · ${swR(D.exp)}/trade` : ""} · lewat ATR 6 (benar-benar LOSE): ${swPc(P.lose_pct)}</div>` : ""}
    ${P.skipped && P.skipped.length ? `<p class="hint">⚠️ dilewati: ${P.skipped.map(esc).join(" · ")}</p>` : ""}</div>`;
}
function sbRender() {
  const R = SBT.res, box = $("sbOut");
  if (!R || !R.n) { box.innerHTML = `<div class="card evalcard"><p>Tidak ada trade yang bisa diuji di data ini (sinyal ${R ? R.n_sig || 0 : 0}).</p></div>`; return; }
  const B = R.best, BB = R.best_box, D = R.default, rows = R.rows || [];
  const maxW = Math.max(1, ...rows.map((r) => r.all.win)), maxB = Math.max(1, ...rows.map((r) => r.box_n));
  const cnt = (S) => `<td class="num pos">${S.win}</td><td class="num">${S.tp1}</td><td class="num">${S.half}</td><td class="num neg">${S.sl}</td><td class="num neg">${S.lose}</td>
    <td class="num"><b>${swPc(S.wr)}</b></td><td class="num"><b class="${(S.exp || 0) > 0 ? "pos" : "neg"}">${swR(S.exp)}</b></td>`;
  const tbl = `<tr class="sw-g"><td><b>SL default strategi</b> <small class="hint">(anti-gocekan)</small></td>${cnt(D)}<td class="num">${swPc(R.default_test.wr)}</td><td colspan="3" class="hint">pembanding</td></tr>` +
    rows.map((r) => `<tr${r.k === B.k ? ' class="sw-best"' : ""}><td><span class="sb-k">${sbK(r.k)}</span>${r.k === B.k ? " ⭐" : ""}<span class="sb-bar" style="width:${(60 * r.all.win / maxW).toFixed(0)}px"></span></td>${cnt(r.all)}
      <td class="num">${swPc(r.all_test.wr)}</td><td class="num">${r.box_n} <span class="sb-bar box" style="width:${(50 * r.box_n / maxB).toFixed(0)}px"></span>${r.k === BB.k ? " 📦" : ""}</td><td class="num pos">${r.box_win}</td><td class="num">${swPc(r.saved_pct)}</td></tr>`).join("");
  const en = (R.by_entry || []).map((x) => `<tr><td>${esc(x.en)}</td><td class="num">${x.n}</td><td class="num">${swPc(x.def_wr)}</td><td>${x.best_k ? `${sbK(x.best_k)} · ${x.best_win} WIN (${swPc(x.best_pct)})` : "—"}</td><td class="num neg">${swPc(x.lose_pct)}</td></tr>`).join("");
  const X = R.examples || [], mp = R.mae_p || {};
  box.innerHTML = `<div class="card evalcard" id="sbVis"></div>
    <div class="card evalcard"><h3>🛡️ Ringkasan · ${esc(SB_STRAT[R.strat])} · ${esc(R.tf.toUpperCase())} · ${R.n.toLocaleString("id-ID")} trade di ${R.coins.length} koin</h3><ul>
      <li>⭐ <b>SL terbaik untuk ${esc(R.tf.toUpperCase())}: ${sbK(B.k)}</b> (TP ${sbK(2 * B.k)} = RR 1:2) → <b class="pos">${B.all.win} WIN</b> dari ${R.n} trade · WR <b>${swPc(B.all.wr)}</b> · <b class="${(B.all.exp || 0) > 0 ? "pos" : "neg"}">${swR(B.all.exp)}/trade</b> · 30% data terakhir: WR ${swPc(B.all_test.wr)} (${swR(B.all_test.exp)})</li>
      <li>SL default strategi: WR ${swPc(D.wr)} · ${swR(D.exp)}/trade (${D.win} WIN · ${D.sl} kena SL)</li>
      <li>📦 Kotak ATR (caramu, per trade): paling banyak WIN di <b>${sbK(BB.k)}</b> (${BB.box_win} WIN). Trade yang harganya lewat ATR 6 = <b class="neg">benar-benar LOSE: ${R.lose} (${swPc(R.lose_pct)})</b></li>
      <li>Harga bergerak melawan entry (sampai trade selesai, dalam ATR): separuh trade ≤ <b>${(mp["50"] || 0).toFixed(2)}</b> · 75% ≤ ${(mp["75"] || 0).toFixed(2)} · 90% ≤ ${(mp["90"] || 0).toFixed(2)}</li></ul>
      <p class="hint">⭐ dipilih dari "kalau SL ini dipakai ke semua trade" (paling banyak WIN). Kotak ATR selalu condong ke ATR kecil — trade yang langsung jalan selalu masuk kotak ATR 1 — jadi dipakai sebagai sebaran kedalaman SL, bukan pemilih utama.</p></div>
    <div class="card evalcard"><h3>📋 Tiap SL ATR <small class="hint">kiri: kalau SL itu dipakai ke SEMUA trade · kanan: kotak ATR per trade (ATR terkecil yang tidak tersentuh) · batas 5 hari sejak entry</small></h3>
      <div class="scroll"><table class="tbl"><tr><th>SL</th><th class="num">WIN</th><th class="num">TP1</th><th class="num">½</th><th class="num">SL</th><th class="num">LOSE</th><th class="num">WR</th><th class="num">R/trade</th><th class="num">WR uji 30%</th><th class="num">📦 Kotak</th><th class="num">WIN di kotak</th><th class="num">Selamat s/d ATR ini</th></tr>${tbl}</table></div>
      <p class="hint">WIN = sampai TP RR 1:2 (+2R) · TP1 = waktu habis tapi pernah RR 1:1 (+1R) · ½ = waktu habis di area entry–TP (+0,5R) · SL = kena SL (−1R) · LOSE = waktu habis masih di area SL (−1R). "Selamat s/d ATR ini" = % trade yang tidak kena SL kalau SL-nya selebar itu.</p></div>
    ${en ? `<details class="card evalcard"><summary><b>🎯 Per jenis entry</b> <small class="hint">kotak ATR yang paling sering WIN per entry</small></summary><div class="scroll"><table class="tbl"><tr><th>Entry</th><th class="num">Trade</th><th class="num">WR SL default</th><th>Kotak ATR terbanyak WIN</th><th class="num">Lewat ATR 6</th></tr>${en}</table></div></details>` : ""}
    ${X.length ? `<details class="card evalcard" open><summary><b>🔍 Contoh trade</b> <small class="hint">${X.length} terbaru · klik baris = gambar visual di atas</small></summary>
      <div class="scroll" style="max-height:380px"><table class="tbl"><tr><th>Sinyal (UTC)</th><th>Koin</th><th>Arah</th><th>Entry</th><th class="num">Harga entry</th><th>SL default</th><th class="num">Melawan maks</th><th>📦 Kotak</th><th class="num">SL</th><th class="num">TP</th><th>Hasil</th><th>Data</th></tr>` +
      X.slice().reverse().map((x, i) => { const rs = SB_RES[x.res] || [x.res, ""], dr = SB_RES[x.def] || [x.def, ""];
        return `<tr data-sbx="${X.length - 1 - i}" title="Gambar visual"><td>${fmtTime(x.t).slice(0, 16)}</td><td>${esc(x.sym)}</td><td class="${x.d === 1 ? "pos" : "neg"}">${x.d === 1 ? "▲ LONG" : "▼ SHORT"}</td><td><small>${esc(x.en)}</small></td>
        <td class="num">${pxTxt(x.e)}</td><td class="${dr[1]}"><small>${pxTxt(x.sl0)} → ${dr[0]}</small></td><td class="num">${x.mae.toFixed(2)} ATR</td><td><b>${x.box ? sbK(x.box) : "lewat 6 ATR"}</b></td>
        <td class="num neg">${pxTxt(x.sl)}</td><td class="num pos">${pxTxt(x.tp)}</td><td class="${rs[1]}">${rs[0]} (${swR(x.R)})</td><td>${x.test ? "uji" : "cari"}</td></tr>`; }).join("") + `</table></div></details>` : ""}`;
  const lose = X.slice().reverse().findIndex((x) => x.def === "sl" && x.res === "win");
  if (X.length) sbVisual(lose >= 0 ? X.length - 1 - lose : X.length - 1); else $("sbVis").remove();
}
function sbOpenSaved(res) { SBT.res = res; $("sbStatus").textContent = `Hasil tersimpan dibuka · ${SB_STRAT[res.strat] || res.strat} · ${String(res.tf).toUpperCase()} · ${res.n} trade`; sbRender(); }
// 🖼️ 1 contoh trade: entry, SL default, garis ATR 1…6, kotak ATR, TP kotak & hasil (candle asli data lokal)
async function sbVisual(idx) {
  const R = SBT.res, x = R && R.examples[idx], box = $("sbVis");
  if (!x || !box) return;
  SBT.vis = idx;
  box.innerHTML = `<h3>🖼️ Contoh visual <small class="hint">memuat candle ${esc(x.sym)}…</small></h3>`;
  let D;
  try { const r = await fetch(`/api/slbt/candles?sym=${encodeURIComponent(x.sym)}&tf=${R.tf}&t=${x.t}&after=${Math.max(x.xo, x.def_xo) + 25}`); D = await r.json(); if (!r.ok) throw new Error(D.detail || r.statusText); }
  catch (e) { box.innerHTML = `<h3>🖼️ Contoh visual</h3><p class="hint">Candle lokal ${esc(x.sym)} tidak bisa dibaca: ${esc(e.message)}</p>`; return; }
  const C = D.candles, s0 = D.i, W = 1100, Hh = 380, L0 = 10, L1 = 940, T0 = 14, B0 = 350, up = x.d === 1;
  const jF = s0 + x.fb, jX = Math.min(C.length - 1, s0 + x.xo), jD = Math.min(C.length - 1, s0 + x.def_xo);
  const kmax = 6, lvAt = (k) => x.e - x.d * k * x.A;
  const lv = [x.e, x.sl0, x.tp, lvAt(kmax), x.tp0];
  let lo = Math.min(...C.map((c) => c[3]), ...lv), hi = Math.max(...C.map((c) => c[2]), ...lv); const pad = (hi - lo) * 0.05; lo -= pad; hi += pad;
  const X_ = (i) => L0 + (L1 - L0) * (i + 0.5) / C.length, Y = (v) => B0 - (B0 - T0) * (v - lo) / (hi - lo), bw = Math.max(1.5, (L1 - L0) / C.length * 0.6);
  let g = "";
  const zx0 = X_(jF), zx1 = X_(Math.max(jX, jF + 1));
  g += `<rect x="${zx0}" width="${zx1 - zx0}" y="${Math.min(Y(x.e), Y(x.tp))}" height="${Math.abs(Y(x.e) - Y(x.tp))}" fill="var(--up)" opacity=".12"/>`;
  g += `<rect x="${zx0}" width="${zx1 - zx0}" y="${Math.min(Y(x.e), Y(x.sl))}" height="${Math.abs(Y(x.e) - Y(x.sl))}" fill="var(--down)" opacity=".12"/>`;
  for (const k of (R.ks || []).map(Number)) {                       // garis ATR 1 … 6
    const v = lvAt(k), isB = x.box && +x.box === k;
    g += `<line x1="${zx0}" x2="${L1}" y1="${Y(v)}" y2="${Y(v)}" stroke="${isB ? "var(--down)" : "var(--muted)"}" stroke-width="${isB ? 2 : 0.7}" stroke-dasharray="${isB ? "6 3" : "2 4"}" opacity="${isB ? 1 : 0.7}"/>`;
    if (Number.isInteger(k) || isB) g += `<text x="${L1 + 4}" y="${Y(v) + 4}" fill="${isB ? "var(--down)" : "var(--muted)"}" font-size="${isB ? 11 : 9}" font-weight="${isB ? 800 : 400}">${isB ? "SL kotak " : ""}${sbK(k)}</text>`;
  }
  C.forEach((c, i) => { const col = c[4] >= c[1] ? "var(--up)" : "var(--down)", X0 = X_(i);
    g += `<line x1="${X0}" x2="${X0}" y1="${Y(c[2])}" y2="${Y(c[3])}" stroke="${col}"/><rect x="${X0 - bw / 2}" width="${bw}" y="${Y(Math.max(c[1], c[4]))}" height="${Math.max(1, Math.abs(Y(c[1]) - Y(c[4])))}" fill="${col}"/>`; });
  const hl = (v, col, lab, dash, x1) => { g += `<line x1="${zx0}" x2="${x1 || zx1}" y1="${Y(v)}" y2="${Y(v)}" stroke="${col}" stroke-width="1.8" ${dash ? 'stroke-dasharray="5 4"' : ""}/><text x="${(x1 || zx1) + 4}" y="${Y(v) + 4}" fill="${col}" font-size="11" font-weight="700">${lab} ${pxTxt(v)}</text>`; };
  hl(x.sl0, "var(--warn)", "SL default", true, X_(Math.max(jD, jF + 1)));
  hl(x.e, "var(--accent)", "ENTRY"); hl(x.tp, "var(--up)", "TP 1:2", true);
  g += `<circle cx="${X_(s0)}" cy="${Y(C[s0] ? C[s0][4] : x.e)}" r="5" fill="none" stroke="var(--accent)" stroke-width="2"/><text x="${X_(s0)}" y="${Y(C[s0] ? C[s0][4] : x.e) + (up ? 20 : -10)}" text-anchor="middle" fill="var(--accent)" font-size="10" font-weight="700">sinyal</text>`;
  const mv = x.e - x.d * x.mae * x.A;                                 // titik harga paling jauh melawan entry
  g += `<line x1="${zx0}" x2="${zx1}" y1="${Y(mv)}" y2="${Y(mv)}" stroke="var(--warn)" stroke-width="1" opacity=".8"/><text x="${zx0 + 4}" y="${Y(mv) + (up ? 13 : -5)}" fill="var(--warn)" font-size="10">melawan maks ${x.mae.toFixed(2)} ATR</text>`;
  if (C[jD] && x.def === "sl") g += `<text x="${X_(jD)}" y="${Y(x.sl0) + (up ? 16 : -8)}" text-anchor="middle" fill="var(--warn)" font-size="10" font-weight="700">✖ SL default kena</text>`;
  if (C[jX]) { const ok = x.res === "win" || x.res === "tp1", yv = x.res === "win" ? x.tp : x.res === "sl" ? x.sl : C[jX][4];
    g += `<circle cx="${X_(jX)}" cy="${Y(yv)}" r="7" fill="none" stroke="${ok ? "var(--up)" : x.res === "half" ? "var(--warn)" : "var(--down)"}" stroke-width="2.5"/><text x="${X_(jX)}" y="${Y(yv) + (ok === up ? -12 : 20)}" text-anchor="middle" fill="${ok ? "var(--up)" : "var(--down)"}" font-size="11" font-weight="800">${(SB_RES[x.res] || [x.res])[0]}</text>`; }
  const n = R.examples.length;
  box.innerHTML = `<h3>🖼️ Contoh visual · ${esc(x.sym)} · ${x.d === 1 ? "LONG" : "SHORT"} · ${fmtTime(x.t).slice(0, 16)} UTC <small class="hint">${idx + 1}/${n} · ${esc(x.en)} · ${x.test ? "data uji" : "data cari"}</small></h3>
    <div class="sw-info"><span>SL default: <b>${(SB_RES[x.def] || [x.def])[0]}</b></span><span>Melawan entry maks: <b>${x.mae.toFixed(2)} ATR</b></span><span>📦 Kotak: <b>${x.box ? sbK(x.box) : "lewat 6 ATR = LOSE"}</b></span>
      <span>Hasil: <b>${(SB_RES[x.res] || [x.res])[0]} (${swR(x.R)})</b></span><span>ATR(14): ${pxTxt(x.A)}</span></div>
    <svg viewBox="0 0 ${W} ${Hh}" class="sw-svg" role="img" aria-label="Contoh trade SL Backtest">${g}</svg>
    <div class="msc-btns"><button class="mini" data-sbv="-1" ${idx <= 0 ? "disabled" : ""}>◀ Sebelumnya</button><button class="mini" data-sbv="1" ${idx >= n - 1 ? "disabled" : ""}>Berikutnya ▶</button>
      <span style="flex:1"></span><button class="mini" data-sbreplay="${idx}">▶ Buka di Manual Replay</button></div>
    <p class="hint">Garis kuning putus-putus = SL default strategi · garis titik abu-abu = SL ATR 1 … 6 dari entry · garis merah tebal = SL kotak ATR trade ini · area hijau / merah = TP (RR 1:2 dari SL kotak) / SL sampai trade selesai · garis kuning tipis = harga paling jauh melawan entry (melawan maks). Candle asli dari data lokal.</p>`;
}
{
  $("sbRun").onclick = sbRun;
  $("sbSavedBox").addEventListener("toggle", () => { if ($("sbSavedBox").open) savedResults("slbt", $("sbSaved"), sbOpenSaved); });
  $("sbOut").addEventListener("click", async (e) => {
    if (!SBT.res) return;
    const nv = e.target.closest("[data-sbv]");
    if (nv) { sbVisual(SBT.vis + +nv.dataset.sbv); return; }
    const tv = e.target.closest("tr[data-sbx]");
    if (tv) { sbVisual(+tv.dataset.sbx); $("sbVis").scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    const tr = e.target.closest("[data-sbreplay]");
    if (!tr) return;
    const x = SBT.res.examples[+tr.dataset.sbreplay];
    await openMoment(x.sym, SBT.res.tf, x.t, [
      { price: x.e, color: "#42a5f5", size: 2, label: `E ${pxTxt(x.e)}` },
      { price: x.sl0, color: "#f0b90b", dash: true, label: `SL default ${pxTxt(x.sl0)}` },
      { price: x.sl, color: "#ef5350", dash: true, label: `SL ${x.box ? sbK(x.box) : "6 ATR"} ${pxTxt(x.sl)}` },
      { price: x.tp, color: "#26a69a", dash: true, label: `TP ${pxTxt(x.tp)}` }],
      `🛡️ ${x.d === 1 ? "LONG" : "SHORT"} ${x.sym} ${fmtTime(x.t).slice(0, 16)} UTC (${x.en}). SL default: ${(SB_RES[x.def] || [x.def])[0]} · kotak ${x.box ? sbK(x.box) : "lewat 6 ATR"} → ${(SB_RES[x.res] || [x.res])[0]}. Step maju untuk melihat.`);
  });
}
// ------------------------------------------------------------------ 📈 Moving Average Analisis (tab sendiri)
const MAA = { res: null, busy: false, vis: 0, D: null };
const MA_IND = { rsi: "RSI", macd: "MACD", stoch: "Stochastic" };
const maName = (R, p) => `${MA_IND[R.ind]} ${p}${R.ind === "macd" ? ` (${p}/${Math.max(p + 1, Math.round(p * 26 / 12))}/${Math.max(2, Math.round(p * 9 / 12))})` : ""}`;
const maDist = (v) => (v == null ? "—" : v >= 0 ? `${v.toFixed(2).replace(".", ",")} ATR di ${"sisinya"}` : `menembus ${(-v).toFixed(2).replace(".", ",")} ATR`);
const maFail = (R) => (R && R.fail_atr) || 1;                       // v4.29: 2,5 ATR (hasil lama tersimpan: 1 ATR)
const maFailTxt = (R) => `${String(maFail(R)).replace(".", ",")} ATR`;
const maPt = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(2).replace(".", ",")}`);
async function maRun() {
  if (MAA.busy) return;
  const auto = $("maLenMode").value === "auto";
  const body = { ma_type: $("maType").value, ma_len: auto ? "auto" : +$("maLen").value || 200, ma_auto: auto, ind: $("maInd").value, mode: $("maMode").value, tf: $("maTf").value, hist: +$("maHist").value || 30 };
  MAA.busy = true; $("maRun").disabled = true; $("maOut").innerHTML = "";
  const fmt = (x) => (x == null ? "—" : x >= 60 ? `${Math.floor(x / 60)} mnt ${Math.round(x % 60)} dtk` : `${Math.round(x)} dtk`);
  try {
    const r = await fetch("/api/maa/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    for (;;) {
      const st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (st.status === "error") throw new Error(st.error);
      if (st.status === "done") { MAA.res = st.result; break; }
      maProgress(st, body, fmt);
      await new Promise((ok) => setTimeout(ok, 800));
    }
    $("maProg").innerHTML = "";
    const R = MAA.res;
    $("maStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${R.ma_type.toUpperCase()} ${R.ma_len}${R.ma_auto ? " (otomatis)" : ""} + ${MA_IND[R.ind]} · ${R.tf.toUpperCase()} · ${R.coins.length} koin lokal${R.from_file ? " · dari file tersimpan" : ` · ${R.elapsed} dtk`} · 💾 tersimpan di 📂 Hasil tersimpan`;
    maRender();
    if ($("maSavedBox").open) savedResults("maa", $("maSaved"), maOpenSaved);
  } catch (ex) {
    $("maProg").innerHTML = ""; $("maStatus").textContent = "⚠️ " + ex.message;
    $("maOut").innerHTML = `<div class="card evalcard"><h3>⚠️ Gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { MAA.busy = false; $("maRun").disabled = false; }
}
function maProgress(st, body, fmt) {
  const P = st.partial || {}, auto = !!body.ma_auto, ph = P.phase || (auto ? "scan_ma" : "riwayat"), frac = st.total ? st.done / st.total : 0;
  const pct = ph === "analisa" ? 99 : !auto ? 100 * frac : ph === "scan_ma" ? 80 * frac : 80 + 18 * frac;
  const np = body.mode === "auto" ? 56 : 6, SB = P.scan_best;
  const maTxt = auto ? (SB && ph !== "scan_ma" ? `${body.ma_type.toUpperCase()} ${SB.m}` : `${body.ma_type.toUpperCase()} otomatis 13–993`) : `${body.ma_type.toUpperCase()} ${body.ma_len}`;
  const steps = auto ? [["scan_ma", `1️⃣ Cari periode MA · 99 MA (13–993) × ${np} setelan ${MA_IND[body.ind]} · ${ph === "scan_ma" ? `${st.done || 0}/${st.total || "?"} koin` : "selesai"}`, "indikator OB/OS → ekor cuma menyentuh MA → respect / gagal / poin"],
    ["detail", `2️⃣ Detail & contoh ${maTxt} · ${ph === "detail" ? `${st.done || 0}/${st.total || "?"} koin` : ph === "analisa" ? "selesai" : "menunggu"}`, "tabel tiap setelan + contoh sinyal untuk visual"],
    ["analisa", "3️⃣ Urutkan & simpan", "skor poin per sinyal · data uji 30% terakhir"]] : [["riwayat", `1️⃣ Cari sentuhan ${body.ma_type.toUpperCase()} ${body.ma_len} & uji ${np} setelan ${MA_IND[body.ind]} · ${P.done || st.done || 0}/${P.total || st.total || "?"} koin`, "sentuh MA ≤ 0,3 ATR → indikator OB/OS → respect ≥ 2 ATR sebelum melawan 2,5 ATR (beberapa koin sekaligus)"],
    ["analisa", "2️⃣ Urutkan setelan", "skor poin per sinyal · data uji 30% terakhir"]];
  const chips = (P.per_coin || []).slice().reverse().map((c) => `<span class="chip">${esc(c.sym)} · ${c.n.toLocaleString("id-ID")} sentuhan${auto && ph === "scan_ma" ? " (99 MA)" : ""}</span>`).join(" ");
  const B = P.best, base = P.base;
  const order = steps.map((x) => x[0]), cur = order.indexOf(ph);
  $("maProg").innerHTML = `<div class="card evalcard tap-prog"><h3>⏳ ${esc(maTxt)}${auto && ph !== "scan_ma" ? " (otomatis)" : ""} + ${MA_IND[body.ind]} · ${esc(body.tf.toUpperCase())} · ${body.hist} koin lokal<span class="dots"></span></h3>
    <div class="tap-bar"><i style="width:${pct.toFixed(1)}%"></i><b>${pct.toFixed(0)}%</b></div>
    <div class="tap-steps">${steps.map(([k, t, h], j) => `<div class="${j === cur ? "on" : j < cur ? "done" : ""}"><b>${j < cur ? "✅ " : ""}${t}</b><small>${h}</small></div>`).join("")}</div>
    <p>⏱️ berjalan <b>${fmt(st.elapsed)}</b> · perkiraan sisa <b>${ph === "analisa" ? "sebentar lagi" : auto && ph === "scan_ma" ? `${fmt(st.eta)} (+ tahap 2)` : fmt(st.eta)}</b>${P.n_touch != null ? ` · <b>${P.n_touch.toLocaleString("id-ID")}</b> sentuhan MA` : ""}${P.candles ? ` · ${(P.candles / 1e6).toFixed(1)} jt candle dibaca` : ""}</p>
    ${chips ? `<p class="hint">Baru selesai: ${chips}</p>` : ""}
    ${SB && ph === "scan_ma" ? `<div class="sw-live"><b>📊 Sementara</b> (${(P.coins || []).length} koin): ⭐ pasangan terbaik <b>${esc(body.ma_type.toUpperCase())} ${SB.m} + ${esc(MA_IND[body.ind])} ${SB.p}</b> → ${SB.n} sinyal · respect ${swPc(SB.resp)} · skor <b class="${(SB.score || 0) > 0 ? "pos" : "neg"}">${maPt(SB.score)}</b> · skor uji ${maPt(SB.t_score)}</div>` : ""}
    ${B ? `<div class="sw-live"><b>📊 Sementara</b> (${(P.coins || []).length} koin): ⭐ <b>${esc(MA_IND[body.ind])} ${B.p}</b> → ${B.n} sinyal · respect ${swPc(B.resp)} · skor <b class="${(B.score || 0) > 0 ? "pos" : "neg"}">${maPt(B.score)}</b>
      ${base && base.n ? ` · tanpa indikator: respect ${swPc(base.resp)} · skor ${maPt(base.score)}` : ""}</div>` : ""}
    ${P.skipped && P.skipped.length ? `<p class="hint">⚠️ dilewati: ${P.skipped.map(esc).join(" · ")}</p>` : ""}</div>`;
}
function maRender() {
  const R = MAA.res, box = $("maOut");
  if (!R || !R.best) { box.innerHTML = `<div class="card evalcard"><p>Tidak ada sinyal yang bisa diuji (sentuhan MA ${R ? R.n_touch || 0 : 0}).</p></div>`; return; }
  const B = R.best, base = R.base, rows = R.rows || [], maN = `${R.ma_type.toUpperCase()} ${R.ma_len}`;
  const maxS = Math.max(0.01, ...rows.filter((r) => r.ok).map((r) => Math.abs(r.score || 0)));
  const shown = R.mode === "auto" ? rows.slice(0, 15) : rows;
  const row = (r, lab, cls) => `<tr${cls ? ` class="${cls}"` : ""}><td>${lab}</td><td class="num">${r.n.toLocaleString("id-ID")}</td><td class="num">${swPc(r.resp)}</td><td class="num">${swPc(r.lv3)}</td><td class="num">${swPc(r.lv4)}</td><td class="num">${swPc(r.lv5)}</td>
    <td class="num neg">${swPc(r.fail)}</td><td class="num"><b class="${(r.score || 0) > 0 ? "pos" : "neg"}">${maPt(r.score)}</b></td><td class="num ${(r.t_score || 0) > 0 ? "pos" : "neg"}">${maPt(r.t_score)}</td>`;
  const tbl = shown.map((r) => row(r, `<b>${esc(maName(R, r.p))}</b>${r.p === B.p ? " ⭐" : ""}<span class="sb-bar" style="width:${(70 * Math.max(0, r.score || 0) / maxS).toFixed(0)}px"></span>`, r.p === B.p ? "sw-best" : "") + `<td>${r.ok ? "✅" : `<span class="hint">&lt; ${30} sinyal</span>`}</td></tr>`).join("")
    + row(base, `<span class="hint">Tanpa indikator (semua sentuhan ${esc(maN)})</span>`, "sw-g") + `<td class="hint">pembanding</td></tr>`;
  let chart = "";
  if (R.mode === "auto") {                                           // grafik skor per periode 5–60
    const all = rows.slice().sort((a, b) => a.p - b.p), W = 1100, Hh = 130, mid = 62, sc = 50 / maxS, bw = (W - 40) / all.length;
    chart = `<svg viewBox="0 0 ${W} ${Hh}" class="sw-svg" role="img" aria-label="Skor per periode"><line x1="20" x2="${W - 10}" y1="${mid}" y2="${mid}" stroke="var(--border)"/>` +
      all.map((r, i) => { const v = r.score || 0, x = 20 + i * bw, h = Math.min(55, Math.abs(v) * sc), col = r.p === B.p ? "var(--accent)" : !r.ok ? "var(--muted)" : v > 0 ? "var(--up)" : "var(--down)";
        return `<rect x="${x + 1}" width="${Math.max(2, bw - 3)}" y="${v >= 0 ? mid - h : mid}" height="${Math.max(1, h)}" fill="${col}" opacity="${r.ok ? 0.85 : 0.35}"><title>${MA_IND[R.ind]} ${r.p}: skor ${maPt(r.score)} · ${r.n} sinyal</title></rect>` +
          (r.p % 5 === 0 || r.p === B.p ? `<text x="${x + bw / 2}" y="${Hh - 4}" text-anchor="middle" fill="${r.p === B.p ? "var(--accent)" : "var(--muted)"}" font-size="10" font-weight="${r.p === B.p ? 800 : 400}">${r.p}</text>` : ""); }).join("") +
      `<text x="22" y="12" fill="var(--muted)" font-size="11">skor per periode ${MA_IND[R.ind]} (otomatis 5–60) · abu-abu = sinyal &lt; 30</text></svg>`;
  }
  const X = R.examples || [];
  const scanCard = R.ma_auto && R.scan ? maScanCard(R) : "";
  box.innerHTML = `<div class="card evalcard" id="maVis"></div>${scanCard}
    <div class="card evalcard"><h3>📈 Ringkasan · ${esc(maN)}${R.ma_auto ? " (otomatis)" : ""} + ${MA_IND[R.ind]} · ${esc(R.tf.toUpperCase())} · ${R.coins.length} koin · ${R.n_touch.toLocaleString("id-ID")} sentuhan ${esc(maN)}</h3><ul>
      <li>⭐ <b>Setelan paling cocok: ${esc(maName(R, B.p))}</b> → ${B.n.toLocaleString("id-ID")} sinyal · respect ≥ 2 ATR <b class="pos">${swPc(B.resp)}</b> · ≥ 3 ATR ${swPc(B.lv3)} · ≥ 5 ATR ${swPc(B.lv5)} · skor <b class="${(B.score || 0) > 0 ? "pos" : "neg"}">${maPt(B.score)} poin/sinyal</b> · 30% data terakhir: respect ${swPc(B.t_resp)} (skor ${maPt(B.t_score)}) ${B.ok ? "" : '<span class="badge warn">⚠️ sinyal &lt; 30</span>'}</li>
      <li>Tanpa indikator (semua sentuhan ${esc(maN)}): respect ${swPc(base.resp)} · skor ${maPt(base.score)} → ${esc(MA_IND[R.ind])} ${B.p} ${R.up_vs_base == null ? "" : R.up_vs_base > 0 ? `<b class="pos">menaikkan ${maPt(R.up_vs_base)} poin</b>` : `<b class="neg">tidak menaikkan (${maPt(R.up_vs_base)} poin)</b>`}</li>
      <li>Arah: harap naik (di atas MA + ${R.ind === "macd" ? "histogram berbalik naik" : "oversold"}) ${swPc(B.resp_up)} respect dari ${B.n_up} · harap turun (di bawah MA + ${R.ind === "macd" ? "histogram berbalik turun" : "overbought"}) ${swPc(B.resp_dn)} dari ${B.n_dn}</li></ul>
      <p class="hint">Poin: sampai 2 ATR = 1 · 3 ATR +0,5 · 4 ATR +0,5 · ≥ 5 ATR +0,5 · gagal (melawan ${maFailTxt(R)} dulu / 5 hari habis) = −1. Dinilai kalau ≥ 30 sinyal.</p></div>
    <div class="card evalcard"><h3>📋 Tiap setelan ${MA_IND[R.ind]} <small class="hint">urut dari skor · skor uji = 30% data terakhir${R.mode === "auto" ? " · 15 teratas dari 56" : ""}</small></h3>
      <div class="scroll"><table class="tbl"><tr><th>Setelan</th><th class="num">Sinyal</th><th class="num">Respect ≥ 2 ATR</th><th class="num">≥ 3 ATR</th><th class="num">≥ 4 ATR</th><th class="num">≥ 5 ATR</th><th class="num">Gagal</th><th class="num">Skor</th><th class="num">Skor uji</th><th>Layak</th></tr>${tbl}</table></div>${chart}</div>
    ${X.length ? `<details class="card evalcard" open><summary><b>🔍 Contoh sinyal</b> <small class="hint">${X.length} terbaru dengan ${esc(maName(R, B.p))} · klik baris = gambar visual + animasi di atas</small></summary>
      <div class="scroll" style="max-height:380px"><table class="tbl"><tr><th>Waktu (UTC)</th><th>Koin</th><th>Arah</th><th class="num">Harga</th><th class="num">${esc(maN)}</th><th class="num">${MA_IND[R.ind]} ${B.p}</th><th class="num">Ekor ke MA</th><th class="num">Melawan maks</th><th class="num">Bergerak maks</th><th>Hasil</th><th class="num">Poin</th><th>Data</th></tr>` +
      X.slice().reverse().map((x, i) => `<tr data-max="${X.length - 1 - i}" title="Gambar visual"><td>${fmtTime(x.t).slice(0, 16)}</td><td>${esc(x.sym)}</td><td class="${x.d === 1 ? "pos" : "neg"}">${x.d === 1 ? "▲ harap naik" : "▼ harap turun"}</td>
        <td class="num">${pxTxt(x.c)}</td><td class="num">${pxTxt(x.ma)}</td><td class="num">${x.v == null ? "—" : String(x.v).replace(".", ",")}</td><td class="num">${maDist(x.dist)}</td><td class="num">${x.adv.toFixed(2)} ATR</td><td class="num">${x.mx.toFixed(2)} ATR</td>
        <td class="${x.resp ? "pos" : "neg"}">${x.resp ? `respect ${x.lv >= 5 ? "≥ 5" : x.lv} ATR` : `gagal (melawan ${maFailTxt(R)} dulu / waktu habis)`}</td><td class="num ${x.pt > 0 ? "pos" : "neg"}">${maPt(x.pt)}</td><td>${x.test ? "uji" : "cari"}</td></tr>`).join("") + `</table></div></details>` : ""}`;
  const w = X.slice().reverse().findIndex((x) => x.resp && x.lv >= 3);
  if (X.length) maVisual(w >= 0 ? X.length - 1 - w : X.length - 1); else $("maVis").remove();
}
// 🔎 hasil cari periode MA otomatis: skor terbaik per MA, 15 pasangan teratas, peta skor MA × periode indikator
function maScanCard(R) {
  const S = R.scan, B = S.best, mas = S.mas || [], MT = R.ma_type.toUpperCase(), I = MA_IND[R.ind];
  const okM = mas.filter((r) => r.ok), maxS = Math.max(0.01, ...okM.map((r) => Math.abs(r.score || 0)));
  const anyNeg = okM.some((r) => (r.score || 0) < 0), W = 1100, Hh = anyNeg ? 150 : 100, mid = anyNeg ? 72 : 82, bw = (W - 40) / Math.max(1, mas.length);
  const bars = mas.map((r, i) => { const v = r.ok ? r.score || 0 : 0, x = 20 + i * bw, h = Math.min(anyNeg ? 62 : 64, Math.abs(v) * (anyNeg ? 60 : 64) / maxS), col = r.m === B.m ? "var(--accent)" : !r.ok ? "var(--muted)" : v > 0 ? "var(--up)" : "var(--down)";
    return `<rect x="${x + 0.5}" width="${Math.max(1.5, bw - 1.5)}" y="${v >= 0 ? mid - h : mid}" height="${Math.max(1, h)}" fill="${col}" opacity="${r.ok ? 0.85 : 0.3}"><title>${MT} ${r.m} + ${I} ${r.p}: skor ${maPt(r.score)} · ${r.n} sinyal · uji ${maPt(r.t_score)}</title></rect>` +
      ((r.m - 13) % 100 === 0 && Math.abs(r.m - B.m) > 30 || r.m === B.m ? `<text x="${x + bw / 2}" y="${Hh - 4}" text-anchor="middle" fill="${r.m === B.m ? "var(--accent)" : "var(--muted)"}" font-size="10" font-weight="${r.m === B.m ? 800 : 400}">${r.m}</text>` : ""); }).join("");
  const chart = `<svg viewBox="0 0 ${W} ${Hh}" class="sw-svg" role="img" aria-label="Skor terbaik per periode MA"><line x1="20" x2="${W - 10}" y1="${mid}" y2="${mid}" stroke="var(--border)"/>${bars}
    <text x="22" y="12" fill="var(--muted)" font-size="11">skor terbaik tiap periode ${MT} (dengan periode ${I} terbaiknya) · abu-abu = sinyal &lt; 30 · arahkan kursor untuk detail</text></svg>`;
  const ps = R.periods || [], G = S.grid || {}, ms = mas.map((r) => r.m), cw = (W - 70) / Math.max(1, ms.length), ch = Math.max(4, Math.min(14, 230 / Math.max(1, ps.length)));
  let hm = "";
  ps.forEach((p, j) => { ms.forEach((m, i) => { const v = (G[String(m)] || {})[String(p)];
    const col = v == null ? "var(--panel2)" : v > 0 ? `rgba(38,166,154,${Math.min(1, 0.15 + v / maxS)})` : `rgba(239,83,80,${Math.min(1, 0.15 + -v / maxS)})`;
    hm += `<rect x="${50 + i * cw}" y="${16 + j * ch}" width="${cw - 0.5}" height="${ch - 0.5}" fill="${col}"${m === B.m && p === B.p ? ' stroke="var(--accent)" stroke-width="2"' : ""}><title>${MT} ${m} + ${I} ${p}: ${v == null ? "sinyal < 30" : "skor " + maPt(v)}</title></rect>`; });
    if (ps.length <= 12 || p % 5 === 0) hm += `<text x="46" y="${16 + j * ch + ch - 1}" text-anchor="end" fill="var(--muted)" font-size="9">${p}</text>`; });
  ms.forEach((m, i) => { if ((m - 13) % 100 === 0) hm += `<text x="${50 + i * cw + cw / 2}" y="${16 + ps.length * ch + 12}" text-anchor="middle" fill="var(--muted)" font-size="9">${m}</text>`; });
  const hH = 16 + ps.length * ch + 18;
  const heat = `<svg viewBox="0 0 ${W} ${hH}" class="sw-svg" role="img" aria-label="Peta skor"><text x="50" y="11" fill="var(--muted)" font-size="11">peta skor: kanan = periode ${MT} (13 → 993) · bawah = periode ${I} · hijau = skor positif · merah = negatif · kosong = sinyal &lt; 30 · kotak biru = ⭐</text>${hm}</svg>`;
  const top = (S.top || []).map((r) => `<tr${r.m === B.m && r.p === B.p ? ' class="sw-best"' : ""}><td><b>${MT} ${r.m} + ${esc(maName(R, r.p))}</b>${r.m === B.m && r.p === B.p ? " ⭐" : ""}</td><td class="num">${r.n}</td><td class="num">${swPc(r.resp)}</td><td class="num">${swPc(r.lv3)}</td><td class="num">${swPc(r.lv5)}</td><td class="num neg">${swPc(r.fail)}</td>
    <td class="num"><b class="${(r.score || 0) > 0 ? "pos" : "neg"}">${maPt(r.score)}</b></td><td class="num ${(r.t_score || 0) > 0 ? "pos" : "neg"}">${maPt(r.t_score)} <small class="hint">(${r.t_n})</small></td></tr>`).join("");
  const bm = mas.find((r) => r.m === B.m) || {};
  return `<div class="card evalcard"><h3>🔎 Periode MA terbaik untuk ${esc(R.tf.toUpperCase())} <small class="hint">${(S.mas_tested || ms).length} periode ${MT} (13–993, tiap 10) × ${ps.length} setelan ${I} = ${(S.n_combo || 0).toLocaleString("id-ID")} pasangan diuji · ${S.elapsed != null ? `${S.elapsed} dtk` : ""}</small></h3>
    <ul><li>⭐ <b>${MT} ${B.m} + ${esc(maName(R, B.p))}</b> → ${B.n} sinyal · respect ≥ 2 ATR <b>${swPc(B.resp)}</b> · skor <b class="${(B.score || 0) > 0 ? "pos" : "neg"}">${maPt(B.score)}</b> · 30% data terakhir: skor ${maPt(B.t_score)} dari ${B.t_n} sinyal ${(B.t_score || 0) > 0 ? '<span class="badge pass">✅ tetap untung di data uji</span>' : '<span class="badge warn">⚠️ tidak bertahan di data uji</span>'}</li>
      <li>Semua sentuhan ${MT} ${B.m} tanpa indikator: skor ${maPt(bm.base_score)} (${bm.base_n || 0} sentuhan) — detail ${MT} ${B.m} ada di kartu di bawah.</li></ul>
    ${chart}${heat}
    <div class="scroll"><table class="tbl"><tr><th>15 pasangan teratas</th><th class="num">Sinyal</th><th class="num">Respect ≥ 2 ATR</th><th class="num">≥ 3 ATR</th><th class="num">≥ 5 ATR</th><th class="num">Gagal</th><th class="num">Skor</th><th class="num">Skor uji (sinyal)</th></tr>${top}</table></div>
    <p class="hint">⚠️ ${(S.n_combo || 0).toLocaleString("id-ID")} pasangan diuji sekaligus, jadi pasangan teratas bisa tinggi karena kebetulan (apalagi kalau sinyalnya sedikit). Pakai yang skor ujinya juga positif dan sinyalnya banyak; MA di sekitar ⭐ yang skornya mirip (lihat grafik) lebih bisa dipercaya daripada 1 angka yang menonjol sendiri.</p></div>`;
}
function maOpenSaved(res) { MAA.res = res; $("maStatus").textContent = `Hasil tersimpan dibuka · ${res.ma_type.toUpperCase()} ${res.ma_len} + ${MA_IND[res.ind]} · ${String(res.tf).toUpperCase()}`; maRender(); }
// 🖼️ candle asli + MA + panel indikator; sesudah candle sentuh, candle berikutnya muncul bertahap + garis arah harga (animasi)
async function maVisual(idx, replay) {
  const R = MAA.res, x = R && R.examples[idx], box = $("maVis");
  if (!x || !box) return;
  MAA.vis = idx;
  const p = R.best.p;
  if (!replay || !MAA.D || MAA.D.key !== `${idx}`) {
    box.innerHTML = `<h3>🖼️ Contoh visual <small class="hint">memuat candle ${esc(x.sym)}…</small></h3>`;
    try {
      const q = new URLSearchParams({ sym: x.sym, tf: R.tf, t: x.t, ma_type: R.ma_type, ma_len: R.ma_len, ind: R.ind, p, after: Math.max(60, x.xo + 30) });
      const r = await fetch(`/api/maa/visual?${q}`); const D = await r.json(); if (!r.ok) throw new Error(D.detail || r.statusText);
      MAA.D = { key: `${idx}`, ...D };
    } catch (e) { box.innerHTML = `<h3>🖼️ Contoh visual</h3><p class="hint">Candle lokal ${esc(x.sym)} tidak bisa dibaca: ${esc(e.message)}</p>`; return; }
  }
  const D = MAA.D, C = D.candles, s0 = D.i, up = x.d === 1, A = x.A, e = x.c;
  const W = 1100, L0 = 10, L1 = 960, T0 = 14, B0 = 300, PT = 320, PB = 420, Hh = 432;
  const jX = Math.min(C.length - 1, s0 + x.xo);
  const FA = maFail(R), eF = e - x.d * FA * A;
  const lv = [e + x.d * 5 * A, eF, ...D.ma.filter((v) => v != null)];
  let lo = Math.min(...C.map((c) => c[3]), ...lv), hi = Math.max(...C.map((c) => c[2]), ...lv); const pad = (hi - lo) * 0.04; lo -= pad; hi += pad;
  const X_ = (i) => L0 + (L1 - L0) * (i + 0.5) / C.length, Y = (v) => B0 - (B0 - T0) * (v - lo) / (hi - lo), bw = Math.max(1.5, (L1 - L0) / C.length * 0.6);
  const nf = Math.max(1, C.length - 1 - s0), step = Math.min(0.08, 4.5 / nf), dl = (i) => (0.6 + (i - s0) * step).toFixed(2);
  let g = "";
  const lvY = [2, 3, 4, 5].map((k) => Y(e + x.d * k * A)).concat([Y(eF)]);   // angka grid di dekat label target / gagal tidak ditulis
  for (let k = 0; k <= 4; k++) { const v = lo + (hi - lo) * k / 4, yy = Y(v); g += `<line x1="${L0}" x2="${L1}" y1="${yy}" y2="${yy}" stroke="var(--border)"/>${lvY.some((q) => Math.abs(q - yy) < 14) ? "" : `<text x="${L1 + 6}" y="${yy + 4}" fill="var(--muted)" font-size="10">${pxTxt(v)}</text>`}`; }
  // garis MA (masa lalu langsung, masa depan ikut animasi)
  const pts = (a, b) => D.ma.slice(a, b + 1).map((v, k) => (v == null ? null : `${X_(a + k)},${Y(v)}`)).filter(Boolean).join(" ");
  g += `<polyline fill="none" stroke="var(--warn)" stroke-width="2" points="${pts(0, s0)}"/><polyline class="late" style="animation-delay:${dl(s0 + 1)}s" fill="none" stroke="var(--warn)" stroke-width="2" points="${pts(s0, C.length - 1)}"/>`;
  g += `<text x="${X_(2)}" y="${Y(D.ma[2] ?? D.ma[s0]) + (up ? 16 : -8)}" fill="var(--warn)" font-size="11" font-weight="700">${esc(R.ma_type.toUpperCase())} ${R.ma_len}</text>`;
  // target 2..5 ATR & batas gagal
  const hitAt = (k) => { for (let i = s0 + 1; i < C.length; i++) { if (up ? C[i][2] >= e + k * A : C[i][3] <= e - k * A) return i; } return null; };
  for (const k of [2, 3, 4, 5]) {
    const v = e + x.d * k * A, hj = x.resp && k <= x.mx ? hitAt(k) : null;
    g += `<line x1="${X_(s0)}" x2="${L1}" y1="${Y(v)}" y2="${Y(v)}" stroke="var(--up)" stroke-dasharray="5 4" opacity="${k === 2 ? 1 : 0.6}"/><text x="${L1 + 6}" y="${Y(v) + 4}" fill="var(--up)" font-size="11" font-weight="${k === 2 ? 700 : 400}">${k} ATR</text>`;
    if (hj != null && hj <= jX) g += `<g class="late" style="animation-delay:${dl(hj)}s"><circle cx="${X_(hj)}" cy="${Y(v)}" r="5" fill="var(--up)"/><text x="${X_(hj) + 8}" y="${Y(v) + (up ? -6 : 14)}" fill="var(--up)" font-size="10" font-weight="700">✓ ${k} ATR</text></g>`;
  }
  g += `<line x1="${X_(s0)}" x2="${L1}" y1="${Y(eF)}" y2="${Y(eF)}" stroke="var(--down)" stroke-dasharray="5 4"/><text x="${L1 + 6}" y="${Y(eF) + 4}" fill="var(--down)" font-size="11">gagal −${maFailTxt(R)}</text>`;
  // candle: sebelum & saat sentuh tampil, sesudahnya muncul satu per satu
  C.forEach((c, i) => { const col = c[4] >= c[1] ? "var(--up)" : "var(--down)", X0 = X_(i), an = i > s0 ? ` class="fut" style="animation-delay:${dl(i)}s"` : "";
    g += `<g${an}><line x1="${X0}" x2="${X0}" y1="${Y(c[2])}" y2="${Y(c[3])}" stroke="${col}"/><rect x="${X0 - bw / 2}" width="${bw}" y="${Y(Math.max(c[1], c[4]))}" height="${Math.max(1, Math.abs(Y(c[1]) - Y(c[4])))}" fill="${col}"/></g>`; });
  // titik sentuh + jalur arah harga (close ke close) sampai hasil
  const sy = Y(up ? C[s0][3] : C[s0][2]);
  g += `<circle cx="${X_(s0)}" cy="${sy}" r="9" fill="none" stroke="var(--accent)" stroke-width="2.5"/><circle class="pulse" cx="${X_(s0)}" cy="${sy}" r="9" fill="none" stroke="var(--accent)" stroke-width="2"/>
    <line x1="${X_(s0)}" x2="${X_(s0)}" y1="${T0 + 6}" y2="${sy - 10}" stroke="var(--accent)" stroke-width="1" stroke-dasharray="2 3" opacity=".7"/>
    <text x="${Math.min(L1 - 150, Math.max(L0 + 150, X_(s0)))}" y="${T0 + 2}" text-anchor="middle" fill="var(--accent)" font-size="11" font-weight="700" paint-order="stroke" stroke="var(--panel)" stroke-width="3">sentuh MA + ${MA_IND[R.ind]} ${R.ind === "macd" ? "berbalik" : up ? "oversold" : "overbought"} → ${up ? "▲ harap naik" : "▼ harap turun"}</text>`;
  const path = [`${X_(s0)},${Y(e)}`]; for (let i = s0 + 1; i <= jX; i++) path.push(`${X_(i)},${Y(C[i][4])}`);
  const dur = Math.max(0.5, (jX - s0) * step);
  g += `<polyline class="path" style="--dur:${dur.toFixed(2)}s;animation-delay:0.6s" fill="none" stroke="${x.resp ? "var(--up)" : "var(--down)"}" stroke-width="2.4" stroke-linejoin="round" opacity=".9" points="${path.join(" ")}"/>`;
  if (C[jX]) { const yv = x.resp ? e + x.d * Math.min(5, x.lv) * A : (x.adv >= FA ? eF : C[jX][4]);
    g += `<g class="late" style="animation-delay:${dl(jX)}s"><circle cx="${X_(jX)}" cy="${Y(yv)}" r="8" fill="none" stroke="${x.resp ? "var(--up)" : "var(--down)"}" stroke-width="2.5"/><text x="${X_(jX)}" y="${Y(yv) + ((x.resp === up) ? -14 : 22)}" text-anchor="middle" fill="${x.resp ? "var(--up)" : "var(--down)"}" font-size="12" font-weight="800">${x.resp ? `✅ respect ${x.lv >= 5 ? "≥ 5" : x.lv} ATR` : "❌ gagal"}</text></g>`; }
  // panel indikator
  g += `<rect x="${L0}" width="${L1 - L0}" y="${PT}" height="${PB - PT}" fill="var(--panel2)"/>`;
  const I = D.ind, line = (arr, a, b, Yp) => arr.slice(a, b + 1).map((v, k) => (v == null ? null : `${X_(a + k)},${Yp(v)}`)).filter(Boolean).join(" ");
  const twoPart = (arr, Yp, col, w) => `<polyline fill="none" stroke="${col}" stroke-width="${w}" points="${line(arr, 0, s0, Yp)}"/><polyline class="late" style="animation-delay:${dl(s0 + 1)}s" fill="none" stroke="${col}" stroke-width="${w}" points="${line(arr, s0, C.length - 1, Yp)}"/>`;
  let iv = "";
  if (R.ind === "macd") {
    const vals = [...I.hist, ...I.macd, ...I.signal].filter((v) => v != null), m = Math.max(1e-12, ...vals.map(Math.abs)), mid = (PT + PB) / 2, Yp = (v) => mid - (v / m) * (PB - PT) * 0.45;
    g += `<line x1="${L0}" x2="${L1}" y1="${mid}" y2="${mid}" stroke="var(--muted)" stroke-dasharray="3 3"/>`;
    I.hist.forEach((v, i) => { if (v == null) return; const an = i > s0 ? ` class="fut" style="animation-delay:${dl(i)}s"` : "";
      g += `<rect${an} x="${X_(i) - bw / 2}" width="${bw}" y="${Math.min(mid, Yp(v))}" height="${Math.max(1, Math.abs(Yp(v) - mid))}" fill="${v >= 0 ? "var(--up)" : "var(--down)"}" opacity=".55"/>`; });
    g += twoPart(I.macd, Yp, "#42a5f5", 1.4) + twoPart(I.signal, Yp, "#ff9800", 1.2);
    iv = I.hist[s0];
    g += `<circle cx="${X_(s0)}" cy="${Yp(iv ?? 0)}" r="5" fill="var(--accent)"/>`;
  } else {
    const Yp = (v) => PB - (PB - PT) * v / 100, ob = R.ind === "rsi" ? [30, 70] : [20, 80], arr = R.ind === "rsi" ? I.rsi : I.k;
    ob.forEach((v) => { g += `<line x1="${L0}" x2="${L1}" y1="${Yp(v)}" y2="${Yp(v)}" stroke="var(--muted)" stroke-dasharray="3 3"/><text x="${L1 + 6}" y="${Yp(v) + 4}" fill="var(--muted)" font-size="10">${v}</text>`; });
    g += twoPart(arr, Yp, "#a78bfa", 1.6);
    if (R.ind === "stoch") g += twoPart(I.d, Yp, "#ff9800", 1.1);
    iv = arr[s0];
    g += `<circle cx="${X_(s0)}" cy="${Yp(iv ?? 50)}" r="5" fill="var(--accent)"/><text x="${X_(s0) + 8}" y="${Yp(iv ?? 50) + (up ? 14 : -6)}" fill="var(--accent)" font-size="10" font-weight="700">${iv == null ? "" : iv.toFixed(1).replace(".", ",")}</text>`;
  }
  g += `<text x="${L0 + 4}" y="${PT + 12}" fill="#a78bfa" font-size="11" font-weight="700">${esc(maName(R, p))}${R.ind === "stoch" ? " · %K ungu · %D oranye" : R.ind === "macd" ? " · MACD biru · signal oranye · histogram" : ""}</text>`;
  const n = R.examples.length;
  box.innerHTML = `<h3>🖼️ Contoh visual · ${esc(x.sym)} · ${esc(R.tf.toUpperCase())} · ${up ? "harga di atas MA turun menyentuh MA → harap NAIK" : "harga di bawah MA naik menyentuh MA → harap TURUN"} · ${fmtTime(x.t).slice(0, 16)} UTC
      <small class="hint">${idx + 1}/${n} · ${x.test ? "data uji" : "data cari"}</small></h3>
    <div class="sw-info"><span>${esc(maName(R, p))} saat sentuh: <b>${x.v == null ? "—" : String(x.v).replace(".", ",")}</b></span><span>Ekor ke MA: <b>${maDist(x.dist)}</b></span><span>Melawan maks: <b>${x.adv.toFixed(2)} ATR</b></span>
      <span>Hasil: <b class="${x.resp ? "pos" : "neg"}">${x.resp ? `respect ${x.lv >= 5 ? "≥ 5" : x.lv} ATR (${maPt(x.pt)} poin) · bergerak maks ${x.mx.toFixed(1).replace(".", ",")} ATR dalam 5 hari` : "gagal (−1 poin)"}</b></span></div>
    <svg viewBox="0 0 ${W} ${Hh}" class="sw-svg ma-anim" role="img" aria-label="Contoh sinyal Moving Average Analisis">${g}</svg>
    <div class="msc-btns"><button class="mini" data-mav="-1" ${idx <= 0 ? "disabled" : ""}>◀ Sebelumnya</button><button class="mini" data-mav="1" ${idx >= n - 1 ? "disabled" : ""}>Berikutnya ▶</button>
      <button class="mini" data-maplay="1">🔁 Putar ulang animasi</button><span style="flex:1"></span><button class="mini" data-mareplay="${idx}">▶ Buka di Manual Replay</button></div>
    <p class="hint">Garis kuning = ${esc(R.ma_type.toUpperCase())} ${R.ma_len} · lingkaran biru = candle sentuh MA saat syarat indikator terpenuhi · sesudahnya candle asli muncul bertahap dan garis ${x.resp ? "hijau" : "merah"} menunjukkan ke mana harga bergerak · garis hijau putus-putus = target 2 / 3 / 4 / 5 ATR dari close sinyal (✓ saat tersentuh) · garis merah = batas gagal (melawan ${maFailTxt(R)}) · panel bawah = ${esc(maName(R, p))}.</p>`;
}
{
  $("maRun").onclick = maRun;
  const maLenUi = () => $("maLen").classList.toggle("hidden", $("maLenMode").value === "auto");   // otomatis: kotak angka disembunyikan
  $("maLenMode").onchange = maLenUi;
  maLenUi();
  $("maSavedBox").addEventListener("toggle", () => { if ($("maSavedBox").open) savedResults("maa", $("maSaved"), maOpenSaved); });
  $("maOut").addEventListener("click", async (e) => {
    if (!MAA.res) return;
    const nv = e.target.closest("[data-mav]");
    if (nv) { maVisual(MAA.vis + +nv.dataset.mav); return; }
    if (e.target.closest("[data-maplay]")) { maVisual(MAA.vis, true); return; }
    const tv = e.target.closest("tr[data-max]");
    if (tv) { maVisual(+tv.dataset.max); $("maVis").scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    const tr = e.target.closest("[data-mareplay]");
    if (!tr) return;
    const R = MAA.res, x = R.examples[+tr.dataset.mareplay];
    await openMoment(x.sym, R.tf, x.t, [
      { price: x.ma, color: "#f0b90b", dash: true, label: `${R.ma_type.toUpperCase()} ${R.ma_len} ${pxTxt(x.ma)}` },
      { price: x.c, color: "#42a5f5", size: 2, label: `sinyal ${pxTxt(x.c)}` },
      { price: x.c + x.d * 2 * x.A, color: "#26a69a", dash: true, label: "2 ATR" },
      { price: x.c - x.d * maFail(R) * x.A, color: "#ef5350", dash: true, label: `gagal −${maFailTxt(R)}` }],
      `📈 ${x.sym} ${fmtTime(x.t).slice(0, 16)} UTC: harga menyentuh ${R.ma_type.toUpperCase()} ${R.ma_len} + ${MA_IND[R.ind]} ${R.best.p} → harap ${x.d === 1 ? "naik" : "turun"}. Hasil: ${x.resp ? `respect ${x.mx.toFixed(1)} ATR` : "gagal"}. Step maju untuk melihat.`);
  });
}
// ------------------------------------------------------------------ 🧭 Penentu Arah (tab sendiri)
const ARB = { res: null, busy: false, vis: 0, D: null, filt: "all" };
const AR_STRAT = { whale: "🐋 Whale · 🎯 Cari setup", ms: "📐 Market Structure", tapro: "🧠 TA Pro Advance", cpat: "🧩 Chart Pattern", rev: "🔄 Find Reversal", sweep: "💧 Liquidity Sweep", maa: "📈 MA Analisis (EMA 200 + RSI 14)" };
const arP = (v, d = 1) => (v == null ? "—" : `${v.toFixed(d).replace(".", ",")}%`);
const arPt = (v) => (v == null ? "—" : `${v >= 0 ? "+" : "−"}${Math.abs(v).toFixed(1).replace(".", ",")} poin`);
const arDir = (d) => (d === 1 ? `<span class="pos">▲ LONG</span>` : `<span class="neg">▼ SHORT</span>`);
const arN = (v) => (v == null ? "—" : (+v).toLocaleString("id-ID"));
async function arRun() {
  if (ARB.busy) return;
  const groups = [...document.querySelectorAll("#arGroups input:checked")].map((x) => x.value);
  if (!groups.length) { $("arStatus").textContent = "⚠️ pilih minimal 1 faktor model"; return; }
  const body = { strat: $("arStrat").value, tf: $("arTf").value, hist: +$("arHist").value || 30, groups };
  ARB.busy = true; $("arRun").disabled = true; $("arOut").innerHTML = "";
  const fmt = (x) => (x == null ? "—" : x >= 60 ? `${Math.floor(x / 60)} mnt ${Math.round(x % 60)} dtk` : `${Math.round(x)} dtk`);
  try {
    const r = await fetch("/api/arb/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.detail || r.statusText);
    for (;;) {
      const st = await (await fetch(`/api/screener/job/${j.id}`)).json();
      if (st.status === "error") throw new Error(st.error);
      if (st.status === "done") { ARB.res = st.result; break; }
      arProgress(st, body, fmt);
      await new Promise((ok) => setTimeout(ok, 700));
    }
    $("arProg").innerHTML = "";
    const R = ARB.res;
    $("arStatus").textContent = `Selesai ${new Date().toLocaleTimeString()} · ${AR_STRAT[R.strat]} · ${R.tf.toUpperCase()} · ${arN(R.n)} sinyal di ${R.coins.length} koin lokal${R.from_file ? " · dari file tersimpan" : ` · ${R.elapsed} dtk`} · 💾 tersimpan di 📂 Hasil tersimpan`;
    arRender();
    if ($("arSavedBox").open) savedResults("arb", $("arSaved"), arOpenSaved);
  } catch (ex) {
    $("arProg").innerHTML = ""; $("arStatus").textContent = "⚠️ " + ex.message;
    $("arOut").innerHTML = `<div class="card evalcard"><h3>⚠️ Gagal</h3><p>${esc(ex.message)}</p></div>`;
  } finally { ARB.busy = false; $("arRun").disabled = false; }
}
function arProgress(st, body, fmt) {
  const P = st.partial || {}, ph = P.phase || (body.groups.includes("flow") ? "flow" : "sinyal");
  const useFlow = body.groups.includes("flow");
  const order = useFlow ? ["flow", "sinyal", "model", "faktor"] : ["sinyal", "model", "faktor"];
  const pi = order.indexOf(ph);
  const pct = ph === "model" ? 96 : ph === "faktor" ? 98 : st.total ? (100 * st.done) / st.total : 0;
  const L = { flow: [`Ambil flow whale Binance · ${ph === "flow" ? `${P.done || 0}/${P.total || "?"}` : "selesai"} koin`, "OI · taker · long/short top trader · funding (±30 hari)"],
    sinyal: [`Putar ulang sinyal & catat faktor · ${ph === "sinyal" ? `${P.done || 0}/${P.total || "?"}` : pi > order.indexOf("sinyal") ? "selesai" : "…"} koin`, "jawaban ±2 ATR duluan · beberapa koin sekaligus"],
    model: ["Model belajar 70% awal & cari ambang yakin", "regresi logistik · ambang dipilih di data yang tidak dipelajari"], faktor: ["Uji 30% terakhir & pengaruh tiap faktor", "model dihitung ulang tanpa tiap grup faktor"] };
  const chips = (P.per_coin || []).slice().reverse().map((c) => `<span class="chip">${esc(c.sym)} · ${c.n} sinyal · asli ${arP(c.orig, 0)} benar</span>`).join(" ");
  $("arProg").innerHTML = `<div class="card evalcard tap-prog"><h3>⏳ Penentu Arah · ${esc(AR_STRAT[body.strat])} · ${esc(body.tf.toUpperCase())} · ${body.hist} koin lokal<span class="dots"></span></h3>
    <div class="tap-bar"><i style="width:${pct.toFixed(1)}%"></i><b>${pct.toFixed(0)}%</b></div>
    <div class="tap-steps">${order.map((k, i) => `<div class="${i === pi ? "on" : i < pi ? "done" : ""}"><b>${i < pi ? "✅ " : ""}${i + 1}️⃣ ${L[k][0]}</b><small>${L[k][1]}</small></div>`).join("")}</div>
    <p>⏱️ berjalan <b>${fmt(st.elapsed)}</b> · perkiraan sisa <b>${pi >= order.indexOf("model") ? "sebentar lagi" : fmt(st.eta)}</b>${P.n != null ? ` · <b>${arN(P.n)}</b> sinyal tercatat` : ""}${P.candles ? ` · ${(P.candles / 1e6).toFixed(1)} jt candle dibaca` : ""}${useFlow && P.flow_ok != null ? ` · flow ${P.flow_ok} koin` : ""}</p>
    ${chips ? `<p class="hint">Baru selesai: ${chips}</p>` : ""}
    ${P.n ? `<div class="sw-live"><b>📊 Sementara</b> (${(P.coins || []).length} koin): arah asli strategi benar <b>${arP(P.orig)}</b> dari ${arN(P.n_move)} sinyal yang bergerak 2 ATR · LONG ${arP(P.long_pct, 0)} / SHORT ${arP(100 - (P.long_pct || 0), 0)}</div>` : ""}
    ${P.flow_err && P.flow_err.length ? `<p class="hint">⚠️ flow gagal: ${P.flow_err.map(esc).join(" · ")}</p>` : ""}
    ${P.skipped && P.skipped.length ? `<p class="hint">⚠️ dilewati: ${P.skipped.map(esc).join(" · ")}</p>` : ""}</div>`;
}
function arRender() {
  const R = ARB.res, box = $("arOut");
  if (!R) return;
  if (R.error || !R.test) {
    const L = R.live || {};
    box.innerHTML = `<div class="card evalcard"><h3>🧭 Belum bisa menilai</h3><p>${esc(R.error || "tidak ada hasil")}</p>${L.n ? `<p class="hint">Arah asli strategi benar ${arP(L.orig)} dari ${arN(L.n_move)} sinyal yang bergerak.</p>` : ""}<p class="hint">Coba tambah jumlah koin lokal atau pilih TF lebih kecil.</p></div>`;
    return;
  }
  const A = R.all, T = R.test, thr = R.thr, ok = R.proven;
  const verdict = ok ? `<p class="ar-ok">✅ <b>Terbukti di data uji</b>: akurasi ${arPt(R.gain_test)} dengan jumlah sinyal sama (${arP(T.orig)} → <b>${arP(T.arb)}</b>). R/trade (RR 1:2): ${swR(T.R_orig)} → <b>${swR(T.R_arb)}</b>. Yang dibalik benar ${arP(T.flip_right)} (uji z ${R.z == null ? "—" : R.z.toFixed(2).replace(".", ",")}).</p>`
    : `<p class="ar-no">❌ <b>Tidak membantu — tetap pakai arah asli strategi.</b> ${thr == null ? "Di data belajar tidak ada ambang yang menaikkan akurasi." : `Di data uji: ${arP(T.orig)} → ${arP(T.arb)} (${arPt(R.gain_test)}), ${arN(T.flips)} dibalik, yang dibalik benar ${arP(T.flip_right)}${R.z != null ? ` (uji z ${R.z.toFixed(2).replace(".", ",")} — syarat ≥ 1,64)` : ""}.`}</p>`;
  const box3 = `<div class="ar-big">
      <div><small>Arah asli strategi</small><b>${arP(A.orig)}</b><small>benar · ${arN(A.n)} sinyal · data uji ${arP(T.orig)}</small></div>
      <div class="${ok ? "good" : ""}"><small>Dengan 🧭 penentu arah</small><b>${arP(A.arb)}</b><small>benar · ${arN(A.n)} sinyal (sama) · data uji ${arP(T.arb)}</small></div>
      <div><small>Yang dibalik model</small><b>${arN(A.flips)}</b><small>sinyal (${arP(A.flip_pct)}) · ambang yakin ${thr == null ? "—" : `≥ ${Math.round(thr * 100)}%`} · setelah dibalik benar ${arP(A.flip_right, 0)}</small></div></div>`;
  const conf = (R.conf || []).map((c) => `<tr class="${c.dec === "flip" ? "sw-best" : ""}"><td>${Math.round(c.lo * 100)}–${c.hi > 1 ? 100 : Math.round(c.hi * 100)}%</td><td class="num">${arN(c.n)}</td><td class="num">${arP(c.orig, 0)}</td><td class="num"><b>${arP(c.flipped, 0)}</b></td>
      <td class="num hint">${arN(c.n_train)} · ${arP(c.flipped_train, 0)}</td><td>${c.dec === "flip" ? "✅ dibalik" : c.dec === "part" ? "sebagian (ambang di tengah)" : "tidak dibalik (di bawah ambang)"}</td></tr>`).join("");
  const imp = (R.imp || []).map((x) => `<tr><td>${esc(x.name)}</td><td class="num"><b class="${x.drop > 0.05 ? "pos" : x.drop < -0.05 ? "neg" : ""}">${arPt(x.drop)}</b></td><td class="num">${arP(x.acc_without)}</td>
      <td class="hint">${x.drop > 0.05 ? "membantu" : x.drop < -0.05 ? "malah mengganggu → bisa dimatikan" : "hampir tidak berpengaruh"}${x.g === "flow" ? (R.use_flow ? ` · data flow hanya ${arN(R.flow_rows)} sinyal (±30 hari)` : " · flow tidak dipakai (Binance tidak terjangkau / dimatikan)") : ""}</td></tr>`).join("");
  const uni = (R.uni || []).map((u) => { const a = u.all, t = u.test, lab = u.unsigned ? ["tinggi / ya", "rendah / tidak"] : ["mendukung arah", "melawan arah"];
      return `<tr><td>${esc(u.name)}${u.g === "flow" ? ' <small class="hint">(30 hari)</small>' : ""}</td><td class="num">${arP(a.acc_hi, 0)} <small class="hint">(${arN(a.n_hi)})</small></td><td class="num">${arP(a.acc_lo, 0)} <small class="hint">(${arN(a.n_lo)})</small></td>
      <td class="num"><b class="${(u.diff || 0) > 1 ? "pos" : (u.diff || 0) < -1 ? "neg" : ""}">${arPt(u.diff)}</b></td><td class="num">${arPt(u.diff_test)}</td><td class="hint">${esc(lab[0])} vs ${esc(lab[1])}${u.arti ? ` · ${esc(u.arti)}` : ""}</td></tr>`; }).join("");
  const X = R.examples || [];
  box.innerHTML = `<div class="card evalcard"><h3>🧭 Ringkasan · ${esc(AR_STRAT[R.strat])} · ${esc(R.tf.toUpperCase())} · ${R.coins.length} koin · ${arN(R.n)} sinyal</h3>
      ${box3}${verdict}
      <p class="hint">Data belajar ${arN(R.train.n)} sinyal · data uji ${arN(T.n)} sinyal · tidak bergerak 2 ATR dalam 5 hari: ${arN(A.neutral)} (tidak dihitung benar/salah)${R.use_flow ? ` · flow whale: ${R.flow_coins} koin, ${arN(R.flow_rows)} sinyal punya data flow` : " · flow whale tidak dipakai"}${R.flow_err && R.flow_err.length ? ` · ⚠️ flow gagal ${R.flow_err.length} koin` : ""}.</p></div>
    <div class="card evalcard" id="arVis"></div>
    <div class="card evalcard"><h3>📊 Per tingkat keyakinan model <small class="hint">data uji · sinyal yang arah modelnya berlawanan dengan arah strategi</small></h3>
      <div class="scroll"><table class="tbl"><tr><th>Yakin arah sebaliknya</th><th class="num">Sinyal</th><th class="num">Arah asli benar</th><th class="num">Kalau dibalik benar</th><th class="num">Data belajar (sinyal · dibalik benar)</th><th>Keputusan</th></tr>${conf}</table></div></div>
    <div class="card evalcard"><h3>🧩 Faktor paling berpengaruh <small class="hint">akurasi data uji turun berapa kalau grup faktor itu dibuang (model &amp; ambang dihitung ulang)</small></h3>
      <div class="scroll"><table class="tbl"><tr><th>Grup faktor</th><th class="num">Pengaruh</th><th class="num">Akurasi tanpa grup ini</th><th>Arti</th></tr>${imp}</table></div>
      <details><summary class="hint">Rincian per faktor: akurasi arah asli saat faktor mendukung vs melawan arah sinyal</summary><div class="scroll"><table class="tbl"><tr><th>Faktor</th><th class="num">Benar saat mendukung / tinggi</th><th class="num">Benar saat melawan / rendah</th><th class="num">Selisih</th><th class="num">Selisih data uji</th><th>Keterangan</th></tr>${uni}</table></div>
      <p class="hint">Faktor flow hanya dari sinyal yang punya data flow Binance (±30 hari terakhir), jadi sampelnya kecil.</p></details></div>
    ${X.length ? `<details class="card evalcard" open><summary><b>🔍 Contoh sinyal</b> <small class="hint">data uji · semua yang dibalik + sinyal terbaru lainnya · klik baris = visual</small></summary>
      <div class="msc-btns"><button class="mini ${ARB.filt === "all" ? "on" : ""}" data-arf="all">Semua (${X.length})</button><button class="mini ${ARB.filt === "flip" ? "on" : ""}" data-arf="flip">Dibalik (${X.filter((x) => x.flip).length})</button></div>
      <div class="scroll" style="max-height:380px"><table class="tbl" id="arTbl"></table></div></details>` : ""}`;
  arTable();
  const fi = X.map((x, i) => [x, i]).filter(([x]) => x.flip && x.ok).map(([, i]) => i);
  if (X.length) arVisual(fi.length ? fi[fi.length - 1] : X.length - 1); else $("arVis").remove();
}
function arTable() {
  const X = ARB.res.examples || [], el = $("arTbl");
  if (!el) return;
  const rows = X.map((x, i) => [x, i]).filter(([x]) => ARB.filt === "all" || x.flip).reverse();
  el.innerHTML = `<tr><th>Waktu (UTC)</th><th>Koin</th><th>Arah strategi</th><th>Arah model</th><th class="num">Yakin sebaliknya</th><th>Dipakai</th><th>Hasil</th><th class="num">R (1:2)</th><th>Data</th></tr>` +
    rows.map(([x, i]) => `<tr data-arx="${i}" title="Gambar visual" class="${i === ARB.vis ? "sel" : ""}"><td>${fmtTime(x.t).slice(0, 16)}</td><td>${esc(x.sym)}</td><td>${arDir(x.d)}</td><td>${arDir(x.p >= 50 ? -x.d : x.d)}</td><td class="num">${arP(x.p, 0)}</td>
      <td><b>${x.used === 1 ? "LONG" : "SHORT"}</b>${x.flip ? " (dibalik)" : x.p >= 50 ? ' <small class="hint">(di bawah ambang)</small>' : ""}</td>
      <td class="${x.ok == null ? "" : x.ok ? "pos" : "neg"}">${x.ok == null ? "tidak bergerak" : x.ok ? "✅ benar" : "❌ salah"}</td><td class="num">${swR(x.R)}</td><td>${x.test ? "uji" : "cari"}</td></tr>`).join("");
}
function arOpenSaved(res) { ARB.res = res; ARB.filt = "all"; $("arStatus").textContent = `Hasil tersimpan dibuka · ${AR_STRAT[res.strat] || res.strat} · ${String(res.tf).toUpperCase()} · ${arN(res.n)} sinyal`; arRender(); }
// 🖼️ 1 contoh sinyal: arah strategi vs arah model, target ±2 ATR, candle sesudah sinyal muncul bertahap (candle asli data lokal)
async function arVisual(idx, replay) {
  const R = ARB.res, x = R && R.examples[idx], box = $("arVis");
  if (!x || !box) return;
  ARB.vis = idx;
  document.querySelectorAll("#arTbl tr.sel").forEach((t) => t.classList.remove("sel"));
  const tr0 = document.querySelector(`#arTbl tr[data-arx="${idx}"]`); if (tr0) tr0.classList.add("sel");
  if (!replay || !ARB.D || ARB.D.key !== `${idx}`) {
    box.innerHTML = `<h3>🖼️ Contoh visual <small class="hint">memuat candle ${esc(x.sym)}…</small></h3>`;
    try { const r = await fetch(`/api/arb/candles?sym=${encodeURIComponent(x.sym)}&tf=${R.tf}&t=${x.t}&after=${Math.max(40, x.xo + 25)}`); const D = await r.json(); if (!r.ok) throw new Error(D.detail || r.statusText); ARB.D = { key: `${idx}`, ...D }; }
    catch (e) { box.innerHTML = `<h3>🖼️ Contoh visual</h3><p class="hint">Candle lokal ${esc(x.sym)} tidak bisa dibaca: ${esc(e.message)}</p>`; return; }
  }
  const C = ARB.D.candles, s0 = ARB.D.i, e = x.c, A = x.A, W = 1100, Hh = 380, L0 = 10, L1 = 940, T0 = 18, B0 = 360;
  const up2 = e + 2 * A, dn2 = e - 2 * A, jX = Math.min(C.length - 1, s0 + x.xo);
  let lo = Math.min(...C.map((c) => c[3]), dn2), hi = Math.max(...C.map((c) => c[2]), up2); const pad = (hi - lo) * 0.05; lo -= pad; hi += pad;
  const X_ = (i) => L0 + (L1 - L0) * (i + 0.5) / C.length, Y = (v) => B0 - (B0 - T0) * (v - lo) / (hi - lo), bw = Math.max(1.5, (L1 - L0) / C.length * 0.6);
  const nf = Math.max(1, C.length - 1 - s0), step = Math.min(0.08, 4.5 / nf), dl = (i) => (0.6 + (i - s0) * step).toFixed(2);
  const modelD = x.p >= 50 ? -x.d : x.d, colU = x.used === 1 ? "var(--up)" : "var(--down)";
  let g = "";
  for (const [v, lab, d] of [[up2, "+2 ATR", 1], [dn2, "−2 ATR", -1]]) {
    const isUsed = d === x.used;
    g += `<line x1="${X_(s0)}" x2="${L1}" y1="${Y(v)}" y2="${Y(v)}" stroke="${isUsed ? "var(--up)" : "var(--down)"}" stroke-width="${isUsed ? 1.8 : 1.2}" stroke-dasharray="6 4"/><text x="${L1 + 6}" y="${Y(v) + 4}" fill="${isUsed ? "var(--up)" : "var(--down)"}" font-size="11" font-weight="700">${lab} ${isUsed ? "target" : "salah arah"}</text>`;
  }
  g += `<line x1="${X_(s0)}" x2="${L1}" y1="${Y(e)}" y2="${Y(e)}" stroke="var(--muted)" stroke-dasharray="2 4"/><text x="${L1 + 6}" y="${Y(e) + 4}" fill="var(--muted)" font-size="10">close ${pxTxt(e)}</text>`;
  C.forEach((c, i) => { const col = c[4] >= c[1] ? "var(--up)" : "var(--down)", X0 = X_(i), an = i > s0 ? ` class="fut" style="animation-delay:${dl(i)}s"` : "";
    g += `<g${an}><line x1="${X0}" x2="${X0}" y1="${Y(c[2])}" y2="${Y(c[3])}" stroke="${col}"/><rect x="${X0 - bw / 2}" width="${bw}" y="${Y(Math.max(c[1], c[4]))}" height="${Math.max(1, Math.abs(Y(c[1]) - Y(c[4])))}" fill="${col}"/></g>`; });
  // panah arah strategi (merah/hijau putus) & arah model
  const ax = X_(s0), ay = Y(e), len = Math.min(110, (L1 - ax) * 0.5), hgt = (B0 - T0) * 0.22;
  const arrow = (d, col, dash, lab, dy) => { const y2 = ay - d * hgt; return `<line x1="${ax}" y1="${ay}" x2="${ax + len}" y2="${y2}" stroke="${col}" stroke-width="2.5" ${dash ? 'stroke-dasharray="6 4"' : ""} marker-end="url(#arHead${dash ? "S" : "M"})"/>
    <text x="${ax + len + 6}" y="${y2 + dy}" fill="${col}" font-size="11" font-weight="800" paint-order="stroke" stroke="var(--panel)" stroke-width="3">${lab}</text>`; };
  const mk = (id, col) => `<marker id="${id}" markerWidth="8" markerHeight="8" refX="5" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="${col}"/></marker>`;
  g = `<defs>${mk("arHeadS", x.d === 1 ? "var(--up)" : "var(--down)")}${mk("arHeadM", x.flip ? "var(--accent)" : "var(--muted)")}</defs>` + g;
  g += arrow(x.d, x.d === 1 ? "var(--up)" : "var(--down)", true, `arah strategi: ${x.d === 1 ? "LONG" : "SHORT"}`, x.d === modelD ? -8 : 4);
  if (modelD !== x.d) g += arrow(modelD, x.flip ? "var(--accent)" : "var(--muted)", false, `🧭 model: ${modelD === 1 ? "LONG" : "SHORT"} (yakin ${Math.round(x.p)}%)${x.flip ? " → dipakai" : " · di bawah ambang"}`, 4);
  g += `<circle cx="${ax}" cy="${ay}" r="7" fill="none" stroke="var(--accent)" stroke-width="2.5"/><circle class="pulse" cx="${ax}" cy="${ay}" r="7" fill="none" stroke="var(--accent)" stroke-width="2"/>`;
  const path = [`${ax},${ay}`]; for (let i = s0 + 1; i <= jX; i++) path.push(`${X_(i)},${Y(C[i][4])}`);
  const dur = Math.max(0.5, (jX - s0) * step);
  g += `<polyline class="path" style="--dur:${dur.toFixed(2)}s;animation-delay:0.6s" fill="none" stroke="${x.y === 0 ? "var(--muted)" : x.y === 1 ? "var(--up)" : "var(--down)"}" stroke-width="2.4" stroke-linejoin="round" opacity=".9" points="${path.join(" ")}"/>`;
  if (C[jX]) { const yv = x.y === 1 ? up2 : x.y === -1 ? dn2 : C[jX][4], okc = x.ok == null ? "var(--muted)" : x.ok ? "var(--up)" : "var(--down)";
    g += `<g class="late" style="animation-delay:${dl(jX)}s"><circle cx="${X_(jX)}" cy="${Y(yv)}" r="8" fill="none" stroke="${okc}" stroke-width="2.5"/><text x="${Math.min(L1 - 60, X_(jX))}" y="${Y(yv) + (x.y === 1 ? -14 : 22)}" text-anchor="middle" fill="${okc}" font-size="12" font-weight="800" paint-order="stroke" stroke="var(--panel)" stroke-width="3">${x.y === 0 ? "tidak bergerak 2 ATR" : `${x.y === 1 ? "naik" : "turun"} 2 ATR duluan · ${x.ok ? "✅ arah dipakai benar" : "❌ arah dipakai salah"}`}</text></g>`; }
  const f = x.f || {}, n = R.examples.length, sg = (v) => (v > 0 ? "naik" : v < 0 ? "turun" : "datar");
  box.innerHTML = `<h3>🖼️ Contoh sinyal${x.flip ? " yang dibalik" : ""} · ${esc(x.sym)} · ${esc(R.tf.toUpperCase())} · sinyal asli ${x.d === 1 ? "LONG" : "SHORT"} → 🧭 dipakai ${x.used === 1 ? "LONG" : "SHORT"} · ${fmtTime(x.t).slice(0, 16)} UTC
      <small class="hint">${idx + 1}/${n} · ${x.test ? "data uji" : "data cari"}</small></h3>
    <div class="sw-info"><span>Yakin arah asli salah: <b>${arP(x.p, 0)}</b></span><span>Tren 4H: <b>${sg(f.htf4)}</b></span><span>BTC 4H: <b>${sg(f.btc4)}</b></span><span>RSI: <b>${f.rsi == null ? "—" : Math.round(50 + 50 * f.rsi)}</b></span>
      <span>ADX: <b>${f.adx == null ? "—" : Math.round(50 * f.adx)}</b></span><span>Delta volume 12 candle: <b>${f.delta == null ? "—" : `${f.delta > 0 ? "beli" : "jual"} ${Math.abs(100 * f.delta).toFixed(0)}%`}</b></span>
      ${f.f_tk ? `<span>Taker 1 periode flow: <b>${f.f_tk > 0 ? "beli" : "jual"} dominan</b></span>` : ""}${f.f_oi ? `<span>OI × harga: <b>${f.f_oi > 0 ? "naik searah" : "berlawanan"}</b></span>` : ""}
      <span>Hasil: <b class="${x.ok == null ? "" : x.ok ? "pos" : "neg"}">${x.ok == null ? "tidak bergerak" : x.ok ? "benar" : "salah"} · ${swR(x.R)}</b>${x.flip ? ` <small class="hint">(arah asli ${x.orig_ok ? "benar" : "salah"})</small>` : ""}</span></div>
    <svg viewBox="0 0 ${W} ${Hh}" class="sw-svg ma-anim" role="img" aria-label="Contoh sinyal Penentu Arah">${g}</svg>
    <div class="msc-btns"><button class="mini" data-arv="-1" ${idx <= 0 ? "disabled" : ""}>◀ Sebelumnya</button><button class="mini" data-arv="1" ${idx >= n - 1 ? "disabled" : ""}>Berikutnya ▶</button>
      <button class="mini" data-arplay="1">🔁 Putar ulang animasi</button><span style="flex:1"></span><button class="mini" data-arreplay="${idx}">▶ Buka di Manual Replay</button></div>
    <p class="hint">Candle asli data lokal · lingkaran biru = candle sinyal (close) · panah putus-putus = arah asli strategi · panah biru = arah model 🧭 (hanya muncul kalau model berlawanan) · garis putus hijau = target ±2 ATR arah yang dipakai, merah = sisi lawan · sesudah sinyal candle muncul bertahap dan garis menunjukkan ke mana harga pergi.</p>`;
}
{
  $("arRun").onclick = arRun;
  $("arSavedBox").addEventListener("toggle", () => { if ($("arSavedBox").open) savedResults("arb", $("arSaved"), arOpenSaved); });
  $("arOut").addEventListener("click", async (e) => {
    if (!ARB.res) return;
    const fl = e.target.closest("[data-arf]");
    if (fl) { ARB.filt = fl.dataset.arf; document.querySelectorAll("[data-arf]").forEach((b) => b.classList.toggle("on", b === fl)); arTable(); return; }
    const nv = e.target.closest("[data-arv]");
    if (nv) { arVisual(ARB.vis + +nv.dataset.arv); return; }
    if (e.target.closest("[data-arplay]")) { arVisual(ARB.vis, true); return; }
    const tv = e.target.closest("tr[data-arx]");
    if (tv) { arVisual(+tv.dataset.arx); $("arVis").scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    const tr = e.target.closest("[data-arreplay]");
    if (!tr) return;
    const x = ARB.res.examples[+tr.dataset.arreplay];
    await openMoment(x.sym, ARB.res.tf, x.t, [
      { price: x.c, color: "#42a5f5", size: 2, label: `close sinyal ${pxTxt(x.c)}` },
      { price: x.c + 2 * x.A, color: x.used === 1 ? "#26a69a" : "#ef5350", dash: true, label: "+2 ATR" },
      { price: x.c - 2 * x.A, color: x.used === -1 ? "#26a69a" : "#ef5350", dash: true, label: "−2 ATR" }],
      `🧭 ${x.sym} ${fmtTime(x.t).slice(0, 16)} UTC: strategi ${x.d === 1 ? "LONG" : "SHORT"}, model yakin ${Math.round(x.p)}% arah sebaliknya → dipakai ${x.used === 1 ? "LONG" : "SHORT"}. Hasil: ${x.ok == null ? "tidak bergerak" : x.ok ? "benar" : "salah"}. Step maju untuk melihat.`);
  });
}
