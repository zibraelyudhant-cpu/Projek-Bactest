// 🕘 History Update: riwayat semua versi (catatan rilis asli tiap zip) + bandingkan 2 versi + alur kerja tiap menu.
// Data: /static/history_data.json.
(() => {
  const root = document.getElementById("histPane");
  if (!root) return;
  const H = { data: null, view: "list", menu: "", q: "", a: null, b: null, open: new Set() };
  const e = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  // markdown sederhana -> HTML (judul, tebal, kode, daftar, tabel, paragraf)
  function md(src) {
    const L = String(src || "").replace(/\r/g, "").split("\n"), out = [];
    let i = 0;
    const inl = (t) => e(t).replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>").replace(/(^|\W)_([^_]+)_(?=\W|$)/g, "$1<i>$2</i>");
    while (i < L.length) {
      const s = L[i];
      if (/^\s*\|.*\|\s*$/.test(s)) {                              // tabel
        const rows = [];
        while (i < L.length && /^\s*\|.*\|\s*$/.test(L[i])) { rows.push(L[i]); i++; }
        const cells = (r) => r.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
        const body = rows.filter((r) => !/^\s*\|[\s:|-]+\|\s*$/.test(r));
        out.push(`<div class="scroll"><table class="tbl">${body.map((r, k) => `<tr>${cells(r).map((c) => (k === 0 ? `<th>${inl(c)}</th>` : `<td>${inl(c)}</td>`)).join("")}</tr>`).join("")}</table></div>`);
        continue;
      }
      if (/^\s*```/.test(s)) {                                       // blok kode
        const buf = []; i++;
        while (i < L.length && !/^\s*```/.test(L[i])) { buf.push(L[i]); i++; }
        i++; out.push(`<pre>${e(buf.join("\n"))}</pre>`); continue;
      }
      if (/^\s*([-*•]|\d+\.)\s+/.test(s)) {                          // daftar (boleh bertingkat)
        const ol = /^\s*\d+\./.test(s), items = [];
        while (i < L.length && /^\s*([-*•]|\d+\.)\s+/.test(L[i])) {
          const ind = L[i].match(/^\s*/)[0].length;
          let t = L[i].replace(/^\s*([-*•]|\d+\.)\s+/, ""); i++;
          while (i < L.length && /^\s{2,}\S/.test(L[i]) && !/^\s*([-*•]|\d+\.)\s+/.test(L[i])) { t += " " + L[i].trim(); i++; }   // baris lanjutan
          items.push(`<li${ind >= 2 ? ' class="sub"' : ""}>${inl(t)}</li>`);
        }
        out.push(ol ? `<ol>${items.join("")}</ol>` : `<ul>${items.join("")}</ul>`); continue;
      }
      if (/^#{1,6}\s/.test(s)) { out.push(`<h5>${inl(s.replace(/^#+\s*/, ""))}</h5>`); i++; continue; }
      if (!s.trim()) { i++; continue; }
      const buf = [];
      while (i < L.length && L[i].trim() && !/^\s*([-*•]|\d+\.)\s+|^\s*\||^#{1,6}\s|^\s*```/.test(L[i])) { buf.push(L[i]); i++; }
      out.push(`<p>${inl(buf.join(" "))}</p>`);
    }
    return out.join("");
  }

  const V = () => H.data.versions;
  const vnum = (v) => { const [a, b] = v.split("."); return +a * 1000 + +b; };
  const match = (x) => (!H.menu || x.menus.includes(H.menu)) && (!H.q || (x.v + " " + x.title + " " + x.notes + " " + x.req.join(" ")).toLowerCase().includes(H.q));
  function card(x, open) {
    return `<div class="hist-v${open ? " open" : ""}" data-v="${e(x.v)}">
      <div class="hist-h"><b>v${e(x.v)}</b><span class="hint">${e(x.date)}</span><span class="hist-t">${e(x.title)}</span>
        <span class="hist-tags">${x.menus.map((m) => `<span class="chip">${e(m)}</span>`).join("")}</span><span class="hist-arr">${open ? "▾" : "▸"}</span></div>
      ${open ? `<div class="hist-b">
        ${x.req.length ? `<div class="hist-req"><h5>🗣️ Permintaan / obrolanmu sejak versi sebelumnya</h5>${x.req.map((r) => `<blockquote>${e(r)}</blockquote>`).join("")}</div>` : ""}
        <h5>📝 Yang diubah (catatan rilis asli)</h5><div class="hist-md">${md(x.notes)}</div>
        ${x.readme ? `<details class="hist-sub"><summary><b>📖 Catatan di README versi ini</b></summary><div class="hist-md">${md(x.readme)}</div></details>` : ""}
        ${codeHtml(x)}</div>` : ""}</div>`;
  }
  // 🔧 perubahan kode: dibaca langsung dari zip versi sebelumnya -> versi ini
  function codeHtml(x) {
    const c = x.code;
    if (!c) return `<p class="hint">🔧 Perubahan kode tidak tersedia (zip versi sebelumnya tidak ada) — label menu versi ini diambil dari isi catatan.</p>`;
    const list = (arr, max = 400) => arr.length ? `<ul class="hist-code">${arr.slice(0, max).map((t) => `<li><code>${e(t)}</code></li>`).join("")}</ul>` : '<p class="hint">—</p>';
    const dt = c.tests - c.tests_prev;
    return `<div class="hist-codebox"><h5>🔧 Perubahan kode v${e(c.from)} → v${e(x.v)} <span class="hint">(dibaca langsung dari isi zip; label menu di atas berasal dari sini)</span></h5>
      ${c.parts.length ? `<table class="tbl"><tr><th>Menu › fitur yang kodenya berubah</th><th class="num">baris</th></tr>${c.parts.map(([p, n]) => `<tr><td>${e(p)}</td><td class="num">${n}</td></tr>`).join("")}</table>` : '<p class="hint">Tidak ada menu yang berubah (hanya tampilan / nomor versi).</p>'}
      <p>🧪 Tes otomatis: <b>${c.tests}</b> ${dt ? `(${dt > 0 ? "+" : ""}${dt} dari versi sebelumnya)` : "(sama)"}${c.rt_new.length ? ` · 🆕 endpoint: ${c.rt_new.map((r) => `<code>${e(r)}</code>`).join(" ")}` : ""}${c.rt_del.length ? ` · 🗑️ endpoint dihapus: ${c.rt_del.map((r) => `<code>${e(r)}</code>`).join(" ")}` : ""}</p>
      <details class="hist-sub"><summary>📁 File yang berubah (${c.files.length})</summary>${list(c.files)}</details>
      ${c.fn_new.length ? `<details class="hist-sub"><summary>🆕 Fungsi baru (${c.fn_new.length})</summary>${list(c.fn_new)}</details>` : ""}
      ${c.fn_del.length ? `<details class="hist-sub"><summary>🗑️ Fungsi dihapus (${c.fn_del.length})</summary>${list(c.fn_del)}</details>` : ""}</div>`;
  }
  function filters() {
    return `<div class="hist-f"><select id="histMenu"><option value="">Semua menu</option>${H.data.menu_names.map((m) => `<option ${m === H.menu ? "selected" : ""}>${e(m)}</option>`).join("")}</select>
      <input id="histQ" placeholder="cari kata (mis. mantul, WR, swing)…" value="${e(H.q)}">
      <span class="hint">Label menu: dari bagian KODE yang berubah (v2.8 ke atas); v1.1–v2.7 dari isi catatan.</span></div>`;
  }
  function render() {
    if (!H.data) return;
    const tabs = [["list", "📜 Riwayat versi"], ["cmp", "⚖️ Bandingkan versi"], ["flow", "🧭 Alur kerja tiap menu"]]
      .map(([k, t]) => `<button data-view="${k}" class="${H.view === k ? "on" : ""}">${t}</button>`).join("");
    let body = "";
    if (H.view === "list") {
      const L = V().filter(match);
      body = filters() + `<p class="hint">${L.length} dari ${V().length} versi · terbaru di atas · klik versi untuk membuka isinya. Versi aplikasi yang sedang jalan: <b>v${e(window.APP_VERSION || "?")}</b>.</p>` +
        L.map((x) => card(x, H.open.has(x.v))).join("");
    } else if (H.view === "cmp") {
      const opts = (sel) => V().map((x) => `<option value="${e(x.v)}" ${x.v === sel ? "selected" : ""}>v${e(x.v)} · ${e(x.date)}</option>`).join("");
      const a = H.a || (V()[1] || V()[0]).v, b = H.b || V()[0].v;
      const lo = Math.min(vnum(a), vnum(b)), hi = Math.max(vnum(a), vnum(b));
      const L = V().filter((x) => vnum(x.v) > lo && vnum(x.v) <= hi && match(x));
      const per = {};
      for (const x of L) for (const m of x.menus) per[m] = (per[m] || 0) + 1;
      const col = (sel, id, side) => {
        const x = V().find((y) => y.v === sel);
        return `<div class="hist-col"><div class="hist-colh"><b>${side}</b> <select id="${id}">${opts(sel)}</select>
          ${x ? x.menus.map((m) => `<span class="chip">${e(m)}</span>`).join("") : ""}</div>
          <div class="hist-colb">${x ? card(x, true) : ""}</div></div>`;
      };
      const between = V().filter((x) => vnum(x.v) > lo && vnum(x.v) < hi && match(x)).reverse();
      body = `<div class="hist-f"><select id="histMenu"><option value="">Semua menu</option>${H.data.menu_names.map((m) => `<option ${m === H.menu ? "selected" : ""}>${e(m)}</option>`).join("")}</select>
          <span>Dari <b>v${e(lo === vnum(a) ? a : b)}</b> ke <b>v${e(hi === vnum(b) ? b : a)}</b>: <b>${L.length}</b> versi perubahan${H.menu ? ` yang menyentuh <b>${e(H.menu)}</b>` : ""}.
          ${Object.keys(per).length ? "Paling sering diubah: " + Object.entries(per).sort((p, q) => q[1] - p[1]).map(([m, n]) => `<span class="chip">${e(m)} ${n}×</span>`).join(" ") : ""}</span></div>
        ${between.length ? `<div class="hist-between"><span class="hint">Versi di antaranya (klik = tampilkan di kolom kanan):</span> ${between.map((x) => `<button class="mini" data-pick="${e(x.v)}" title="${e(x.title)}">v${e(x.v)}</button>`).join("")}</div>` : ""}
        <div class="hist-cmp">${col(a, "histA", "⬅ Versi A")}${col(b, "histB", "Versi B ➡")}</div>`;
    } else {
      body = `<p class="hint">Alur kerja (workflow) tiap menu & fitur: apa yang kamu isi, apa yang dihitung aplikasi di belakang, dan cara membaca hasilnya.</p>` +
        H.data.menus.map((m) => `<details class="hist-menu"><summary><b>${e(m.name)}</b> <span class="hint">${e(m.goal)}</span></summary>
          ${m.features.map((f) => `<div class="hist-feat"><h5>${e(f.name)}</h5><ol>${f.steps.map((s) => `<li>${e(s)}</li>`).join("")}</ol>${f.notes ? `<p class="hint">💡 ${e(f.notes)}</p>` : ""}</div>`).join("")}</details>`).join("");
    }
    root.innerHTML = `<div class="hist"><h3>🕘 History Update</h3><div class="hist-tabs">${tabs}</div>${body}</div>`;
  }
  root.addEventListener("click", (ev) => {
    const b = ev.target.closest("[data-view]");
    if (b) { H.view = b.dataset.view; return render(); }
    const pk = ev.target.closest("[data-pick]");
    if (pk) { H.b = pk.dataset.pick; return render(); }
    const h = ev.target.closest(".hist-h");
    if (h && H.view === "list") { const v = h.parentElement.dataset.v; H.open.has(v) ? H.open.delete(v) : H.open.add(v); render(); }
  });
  root.addEventListener("change", (ev) => {
    if (ev.target.id === "histMenu") { H.menu = ev.target.value; render(); }
    if (ev.target.id === "histA") { H.a = ev.target.value; render(); }
    if (ev.target.id === "histB") { H.b = ev.target.value; render(); }
  });
  let qt = 0;
  root.addEventListener("input", (ev) => {
    if (ev.target.id !== "histQ") return;
    clearTimeout(qt);
    qt = setTimeout(() => { H.q = ev.target.value.trim().toLowerCase(); render(); const q = document.getElementById("histQ"); if (q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }, 250);
  });
  async function load() {
    if (H.data) return render();
    root.innerHTML = '<p class="hint">Memuat riwayat…</p>';
    try {
      H.data = await (await fetch("/static/history_data.json?v=" + (window.APP_VERSION || ""))).json();
      H.open.add(H.data.versions[0].v);
      render();
    } catch (ex) { root.innerHTML = `<p class="neg">Gagal memuat riwayat: ${e(ex.message)}</p>`; }
  }
  window.HIST = { load, state: H, md };
})();
