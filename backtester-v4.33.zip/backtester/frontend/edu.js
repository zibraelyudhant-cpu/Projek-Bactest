// 📚 Info Trading: animasi edukasi dari candle ASLI (data: /static/edu_data.json, dibuat tools/edu_build.py).
// Satu mesin gambar untuk semua topik. Anotasi muncul tepat saat candle-nya terbentuk (k = garis, z = zona, t = label,
// s = garis miring, b = sorot candle). Kecepatan 20 bar/detik; candle penting (slow) diperlambat, berhenti sejenak di pause.
// Opsional per contoh: ov = garis indikator di atas harga (MA, Bollinger, VWAP), band = isi di antara 2 garis ov,
// pane = panel indikator di bawah chart (RSI, Stochastic, MACD, ADX, ATR, volume, Force Index). Anotasi dengan pn=1
// digambar di panel bawah. Semua ikut terbentuk candle per candle.
(() => {
  const root = document.getElementById("eduPane");
  if (!root) return;
  const MON = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
  const fmtT = (ms) => { const d = new Date(ms); return `${String(d.getUTCDate()).padStart(2, "0")} ${MON[d.getUTCMonth()]} ${String(d.getUTCHours()).padStart(2, "0")}:${String(d.getUTCMinutes()).padStart(2, "0")}`; };
  const E = { data: null, topic: 0, scn: 0, D: null, k: 0, frac: 0, playing: false, speed: 1, last: 0, hold: null, lo: 0, hi: 1, raf: 0 };
  const W = 1000, H0 = 480, L = 8, Rp = 96, T = 16, B = 28;
  let H = H0, PB = H0 - B, P0 = 0, P1 = 0;              // PB = bawah area harga; P0..P1 = panel indikator (kalau ada)
  root.innerHTML = `<div class="edu">
    <div class="edu-topics" id="eduTopics"></div>
    <div class="edu-gloss hidden" id="eduGloss"></div>
    <div class="edu-head"><h3 id="eduTitle"></h3><p class="hint" id="eduDesc"></p><div class="edu-scn" id="eduScn"></div></div>
    <div class="edu-main" id="eduMain">
      <div class="edu-card">
        <svg id="eduSvg" viewBox="0 0 ${W} ${H}"></svg>
        <div class="edu-cap"><div class="edu-step" id="eduStep"></div><div class="edu-txt" id="eduTxt"></div><div class="edu-why" id="eduWhy"></div></div>
        <div class="edu-ctl">
          <button id="eduRestart" title="ulang">⏮</button><button id="eduPlay">▶</button><button id="eduNext" title="maju 1 candle">⏭</button>
          <input id="eduSeek" type="range" min="0" max="1000" value="0">
          <span class="edu-sp"><button data-s="0.5">10 bar/dtk</button><button data-s="1" class="on">20 bar/dtk</button><button data-s="2">40 bar/dtk</button></span>
        </div>
      </div>
      <div class="edu-card edu-steps"><h4>Langkah-langkah</h4><div id="eduSteps"></div></div>
    </div>
    <p class="hint" id="eduSrc"></p></div>`;
  const $e = (id) => document.getElementById(id);
  const svg = $e("eduSvg");
  const N = () => E.D.C.length;
  const X = (i) => L + (i + 0.5) * ((W - L - Rp) / (N() + 4));
  const cw = () => Math.max(2, ((W - L - Rp) / (N() + 4)) * 0.66);
  const Y = (p) => T + (E.hi - p) / (E.hi - E.lo) * (PB - T);
  const YP = (v) => P0 + 6 + (E.phi - v) / (E.phi - E.plo || 1) * (P1 - P0 - 12);
  const YY = (a, v) => (a.pn ? YP(v) : Y(v));
  const dec = () => { const p = E.D.C[0][4]; return p >= 1000 ? 1 : p >= 100 ? 2 : p >= 1 ? 3 : 5; };
  function scale() {
    const D = E.D;
    let lo = Math.min(...D.C.map((c) => c[3])), hi = Math.max(...D.C.map((c) => c[2]));
    for (const a of D.ann) if (!a.pn) for (const p of [a.p, a.p1, a.p2]) if (p != null) { lo = Math.min(lo, p); hi = Math.max(hi, p); }
    for (const o of D.ov || []) for (const v of o.v) if (v != null) { lo = Math.min(lo, v); hi = Math.max(hi, v); }
    const pd = (hi - lo) * 0.07; E.lo = lo - pd; E.hi = hi + pd;
    const pn = D.pane;
    if (pn) {
      const ph = pn.h || 140;
      H = H0 + ph + 4; PB = H0 - 14; P0 = H0 - 4; P1 = P0 + ph;
      let a = Infinity, b = -Infinity;
      for (const sr of pn.series) for (const v of sr.v) if (v != null) { a = Math.min(a, v); b = Math.max(b, v); }
      for (const l of pn.levels || []) { a = Math.min(a, l.v); b = Math.max(b, l.v); }
      if (pn.lo != null) a = pn.lo;
      if (pn.hi != null) b = pn.hi;
      if (pn.series.some((sr) => sr.type === "hist" || sr.type === "vol")) a = Math.min(a, 0);
      const q = (b - a) * 0.06 || 1; E.plo = pn.lo != null ? a : a - q; E.phi = pn.hi != null ? b : b + q;
    } else { H = H0; PB = H0 - B; P0 = P1 = 0; }
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  }
  const num = (v) => (Math.abs(v) >= 1000 ? v.toFixed(0) : Math.abs(v) >= 100 ? v.toFixed(1) : Math.abs(v) >= 1 ? v.toFixed(2) : v.toPrecision(3));
  // garis indikator sampai candle ke-i saja (indikator juga "terbentuk" candle per candle)
  const path = (v, upto, yf) => { let d = "", pen = false; for (let j = 0; j <= upto && j < v.length; j++) { if (v[j] == null) { pen = false; continue; } d += `${pen ? "L" : "M"}${X(j).toFixed(1)},${yf(v[j]).toFixed(1)}`; pen = true; } return d; };
  function forming(c, f) {                               // candle yang sedang terbentuk: open -> ekstrem -> close
    const [t, o, h, l, cl] = c, wickDown = (o - l) > (h - Math.max(o, cl)) * 1.5;
    const pts = cl < o && !wickDown ? [o, h, l, cl] : [o, l, h, cl];
    const seg = Math.min(2.999, f * 3), si = Math.floor(seg), q = seg - si;
    const p = pts[si] + (pts[si + 1] - pts[si]) * q, seen = pts.slice(0, si + 1).concat([p]);
    return [t, o, Math.max(...seen), Math.min(...seen), p];
  }
  function candle(c, i) {
    const [, o, h, l, cl] = c, col = cl >= o ? "#26a69a" : "#ef5350", x = X(i), w = cw();
    return `<line x1="${x}" x2="${x}" y1="${Y(h)}" y2="${Y(l)}" stroke="${col}" stroke-width="1"/><rect x="${x - w / 2}" y="${Math.min(Y(o), Y(cl))}" width="${w}" height="${Math.max(1, Math.abs(Y(o) - Y(cl)))}" fill="${col}"/>`;
  }
  const pill = (x, y, t, col, anchor = "middle") => {
    const w = t.length * 6.2 + 10, x0 = anchor === "middle" ? x - w / 2 : anchor === "end" ? x - w : x;
    return `<rect x="${x0}" y="${y - 11}" width="${w}" height="16" rx="5" fill="#0b0f14e6" stroke="${col}88"/><text x="${x0 + w / 2}" y="${y + 1}" text-anchor="middle" fill="${col}" font-size="10.5" font-weight="700">${esc(t)}</text>`;
  };
  const vis = (a, i) => i >= a.from && (a.until == null || i < a.until);
  function draw() {
    const D = E.D, n = N(), i = Math.min(E.k, n - 1), C = D.C;
    let g = `<rect width="${W}" height="${H}" fill="#0f131a"/>`;
    const rng = E.hi - E.lo, st0 = Math.pow(10, Math.floor(Math.log10(rng / 5))), st = [1, 2, 5, 10].map((m) => m * st0).find((x) => rng / x <= 7);
    for (let p = Math.ceil(E.lo / st) * st; p <= E.hi; p += st) if (Y(p) <= PB) g += `<line x1="${L}" x2="${W - Rp}" y1="${Y(p)}" y2="${Y(p)}" stroke="#1a212b"/><text x="${W - Rp + 6}" y="${Y(p) + 4}" fill="#5b6576" font-size="10.5">${(+p.toFixed(8)).toString()}</text>`;
    const tstep = Math.max(20, Math.round(n / 5)), yb = P1 ? P1 : PB;
    for (let j = Math.round(tstep / 2); j < n; j += tstep) g += `<line x1="${X(j)}" x2="${X(j)}" y1="${T}" y2="${yb}" stroke="#161c25"/><text x="${X(j)}" y="${H - 9}" text-anchor="middle" fill="#5b6576" font-size="10.5">${fmtT(C[j][0])}</text>`;
    const iv = E.k < n ? E.k : n - 1;                  // indikator sampai candle yang sedang terbentuk
    const ptags = [];
    if (D.pane) {                                      // panel bawah: kotak, level, garis / histogram
      const pn = D.pane;
      g += `<rect x="${L}" y="${P0}" width="${W - Rp - L}" height="${P1 - P0}" fill="#0c1016" stroke="#1c2430"/>`;
      for (const l of pn.levels || []) g += `<line x1="${L}" x2="${W - Rp}" y1="${YP(l.v)}" y2="${YP(l.v)}" stroke="${l.c || "#3a4452"}" stroke-dasharray="4 4"/><text x="${W - Rp + 6}" y="${YP(l.v) + 4}" fill="${l.c || "#5b6576"}" font-size="10">${esc(l.t != null ? l.t : num(l.v))}</text>`;
      for (const sr of pn.series) {
        if (sr.type === "hist" || sr.type === "vol") {
          const w = Math.max(1, cw()), y0 = YP(0);
          for (let j = 0; j <= iv && j < sr.v.length; j++) {
            const v = sr.v[j]; if (v == null) continue;
            const col = sr.type === "vol" ? (C[j][4] >= C[j][1] ? "#26a69a" : "#ef5350") : v >= 0 ? (sr.c || "#26a69a") : (sr.c2 || "#ef5350");
            g += `<rect x="${X(j) - w / 2}" y="${Math.min(y0, YP(v))}" width="${w}" height="${Math.max(1, Math.abs(YP(v) - y0))}" fill="${col}" fill-opacity="${sr.op || 0.75}"/>`;
          }
        } else g += `<path d="${path(sr.v, iv, YP)}" fill="none" stroke="${sr.c}" stroke-width="${sr.w || 1.4}" stroke-dasharray="${sr.dash || ""}"/>`;
        const lv = sr.v[Math.min(iv, sr.v.length - 1)];
        if (lv != null && sr.type !== "vol") ptags.push({ y: YP(lv), t: num(lv), c: sr.c || "#8b96a5" });
      }
      g += `<text x="${L + 6}" y="${P0 + 14}" fill="#c9d1dc" font-size="11" font-weight="700">${esc(pn.title)}</text>`;
      let lx = L + 12 + pn.title.length * 6.6;
      for (const sr of pn.series) if (sr.n) { g += `<text x="${lx}" y="${P0 + 14}" fill="${sr.c || "#8b96a5"}" font-size="10.5">${esc(sr.n)}</text>`; lx += sr.n.length * 6 + 12; }
    }
    if (D.band) {                                      // isi di antara dua garis (mis. Bollinger Band)
      const a = D.ov[D.band.a].v, b = D.ov[D.band.b].v; let up = "", dn = "";
      for (let j = 0; j <= iv && j < a.length; j++) if (a[j] != null && b[j] != null) { up += `${up ? "L" : "M"}${X(j).toFixed(1)},${Y(a[j]).toFixed(1)}`; dn = `L${X(j).toFixed(1)},${Y(b[j]).toFixed(1)}` + dn; }
      if (up) g += `<path d="${up}${dn}Z" fill="${D.band.c}" fill-opacity="${D.band.op || 0.08}"/>`;
    }
    const tags = [], over = [], labs = [];
    for (const a of D.ann) {                             // zona & garis di bawah candle, label di atas candle
      if (!vis(a, i)) continue;
      if (a.k === "z") {
        const x0 = X(a.i0) - 3, x1 = a.i1 == null ? W - Rp : X(a.i1) + 3, y1 = YY(a, Math.max(a.p1, a.p2)), y2 = YY(a, Math.min(a.p1, a.p2));
        g += `<rect x="${x0}" y="${y1}" width="${Math.max(2, x1 - x0)}" height="${Math.max(1, y2 - y1)}" fill="${a.c}" fill-opacity="${a.op}" stroke="${a.c}" stroke-opacity=".35"/>`;
        if (a.label) labs.push({ x: x0 + 4, y: y1 + 12, t: a.label, c: a.c, anchor: "start", pn: a.pn });
      } else if (a.k === "h") {
        const x0 = X(a.i0) - 3, x1 = a.i1 == null ? W - Rp : X(a.i1) + 3;
        g += `<line x1="${x0}" x2="${x1}" y1="${YY(a, a.p)}" y2="${YY(a, a.p)}" stroke="${a.c}" stroke-width="${a.w || 1.3}" stroke-dasharray="${a.dash || ""}"/>`;
        if (a.tag && !a.pn) tags.push([a.p, a.tag, a.c]);
      } else if (a.k === "s") {
        g += `<line x1="${X(a.i1)}" x2="${X(a.i2)}" y1="${YY(a, a.p1)}" y2="${YY(a, a.p2)}" stroke="${a.c}" stroke-width="${a.w || 1.6}" stroke-dasharray="${a.dash || ""}" stroke-opacity=".9"/>`;
      } else over.push(a);
    }
    for (const o of D.ov || []) g += `<path d="${path(o.v, iv, Y)}" fill="none" stroke="${o.c}" stroke-width="${o.w || 1.5}" stroke-dasharray="${o.dash || ""}" stroke-opacity="${o.op || 0.95}"/>`;
    for (let j = 0; j < Math.min(E.k, n); j++) g += candle(C[j], j);
    if (E.k < n) g += candle(forming(C[E.k], E.frac), E.k);
    for (const a of over) {
      if (a.k === "b") {
        const c = C[a.i];
        g += `<rect x="${X(a.i) - 7}" y="${Y(c[2]) - 5}" width="14" height="${Y(c[3]) - Y(c[2]) + 10}" rx="4" fill="none" stroke="${a.c}" stroke-dasharray="3 3"/>`;
      } else if (a.k === "t") {
        const up = a.pos !== "below", y = up ? YY(a, a.p) - (a.pill ? 14 : 7) : YY(a, a.p) + (a.pill ? 20 : 14);
        labs.push(a.pill ? { x: X(a.i) + (a.anchor === "start" ? 6 : a.anchor === "end" ? -6 : 0), y, t: a.text, c: a.c, anchor: a.anchor || "middle", pill: true, dir: up ? -1 : 1, pn: a.pn }
          : { x: X(a.i), y, t: a.text, c: a.c, anchor: "middle", dir: up ? -1 : 1, pn: a.pn });
      }
    }
    // label tidak boleh saling menumpuk: geser naik/turun (lalu ke samping) sampai ada tempat kosong
    const placed = [];
    if (D.ov && D.ov.length) {                         // keterangan garis indikator (kiri atas) + nilai sekarang
      let lx = L + 6;
      for (const o of D.ov) {
        if (!o.n) continue;
        const v = o.v[Math.min(iv, o.v.length - 1)], t = `${o.n}${v != null ? " " + num(v) : ""}`;
        g += `<text x="${lx}" y="${T + 12}" fill="${o.c}" font-size="10.5" font-weight="700" stroke="#0f131a" stroke-width="3" paint-order="stroke">${esc(t)}</text>`;
        placed.push({ x0: lx, x1: lx + t.length * 6.3, y0: T, y1: T + 16 }); lx += t.length * 6.3 + 14;
      }
    }
    const hit = (b) => placed.some((q) => b.x0 < q.x1 + 3 && b.x1 > q.x0 - 3 && b.y0 < q.y1 + 2 && b.y1 > q.y0 - 2);
    for (const l of labs) {
      const w = l.pill ? l.t.length * 6.2 + 10 : l.t.length * 6.3, h = 16;
      const bx = (x, y) => { const x0 = l.anchor === "middle" ? x - w / 2 : l.anchor === "end" ? x - w : x; return { x0, x1: x0 + w, y0: y - 12, y1: y - 12 + h }; };
      const d = l.dir || 1, tries = [];
      for (let k = 0; k <= 6; k++) for (const dx of [0, w * 0.6, -w * 0.6]) tries.push([dx, d * k * 17], [dx, -d * k * 17]);
      const lo_ = l.pn ? P0 + 18 : T - 4, hi_ = l.pn ? P1 + 2 : PB + 4;
      let best = tries.find(([dx, dy]) => { const b = bx(l.x + dx, l.y + dy); return b.y0 > lo_ && b.y1 < hi_ && b.x0 > L - 4 && b.x1 < W - Rp && !hit(b); }) || [0, 0];
      const x = l.x + best[0], y = l.y + best[1];
      placed.push(bx(x, y));
      g += l.pill ? pill(x, y, l.t, l.c, l.anchor)
        : `<text x="${x}" y="${y}" text-anchor="${l.anchor}" fill="${l.c}" font-size="10.5" font-weight="800" stroke="#0f131a" stroke-width="3" paint-order="stroke">${esc(l.t)}</text>`;
    }
    const lp = E.k < n ? forming(C[E.k], E.frac)[4] : C[n - 1][4];
    g += `<line x1="${L}" x2="${W - Rp}" y1="${Y(lp)}" y2="${Y(lp)}" stroke="#ffffff26" stroke-dasharray="2 4"/>`;
    tags.push([lp, "", "#e6ebf2"]);
    const tg = tags.map(([p, t, c]) => ({ y: Y(p), p, t, c })).sort((a, b) => a.y - b.y);
    for (let j = 1; j < tg.length; j++) if (tg[j].y - tg[j - 1].y < 17) tg[j].y = tg[j - 1].y + 17;
    ptags.sort((a, b) => a.y - b.y);
    for (let j = 1; j < ptags.length; j++) if (ptags[j].y - ptags[j - 1].y < 15) ptags[j].y = ptags[j - 1].y + 15;
    for (const x of ptags) g += `<rect x="${W - Rp + 2}" y="${x.y - 7}" width="${Rp - 30}" height="14" rx="3" fill="${x.c}"/><text x="${W - Rp + 6}" y="${x.y + 4}" fill="#0b0f14" font-size="9.5" font-weight="800">${esc(x.t)}</text>`;
    for (const x of tg) g += `<rect x="${W - Rp + 2}" y="${x.y - 8}" width="${Rp - 4}" height="16" rx="3" fill="${x.c}"/><text x="${W - Rp + 6}" y="${x.y + 4}" fill="#0b0f14" font-size="${x.t ? 9.5 : 10.5}" font-weight="800">${esc(`${x.t ? x.t + " " : ""}${x.p.toFixed(dec())}`)}</text>`;
    svg.innerHTML = g;
    const ST = D.steps;
    let a = 0;
    ST.forEach((q, j) => { if (i >= q[3]) a = j; });
    const q = ST[a], formingSlow = D.slow.includes(E.k) && E.frac < 0.999 && E.k < n;
    $e("eduStep").textContent = `${a + 1} · ${q[0].toUpperCase()}${formingSlow ? " (candle sedang terbentuk…)" : ""}`;
    $e("eduTxt").textContent = q[1];
    $e("eduWhy").textContent = q[2];
    document.querySelectorAll("#eduSteps .edu-st").forEach((el, j) => { el.classList.toggle("on", j === a); el.classList.toggle("done", j < a); });
    $e("eduSeek").value = Math.round(((Math.min(E.k, n) + (E.k < n ? E.frac : 0)) / n) * 1000);
    $e("eduPlay").textContent = E.playing ? "⏸" : "▶";
  }
  const dur = (i) => (E.D.slow.includes(i) ? 1200 : 50) / E.speed;      // 20 bar/detik
  function stopHold() { clearTimeout(E.hold); E.hold = null; }
  function tick(ts) {
    E.raf = 0;
    if (!E.playing || E.hold) { E.last = 0; return; }
    if (!root.offsetParent) { E.playing = false; draw(); return; }      // tab tidak terlihat: berhenti
    if (E.last) E.frac += (ts - E.last) / dur(E.k);
    E.last = ts;
    while (E.frac >= 1 && E.k < N()) {
      E.frac -= 1; E.k++;
      if (E.D.pause.includes(E.k)) { E.frac = 0; E.hold = setTimeout(() => { E.hold = null; E.last = 0; loop(); }, 1700 / E.speed); break; }
    }
    if (E.k >= N()) { E.k = N(); E.frac = 0; E.playing = false; }
    draw();
    loop();
  }
  function loop() { if (!E.raf && E.playing && !E.hold) E.raf = requestAnimationFrame(tick); }
  function play(on) { E.playing = on; E.last = 0; draw(); loop(); }
  function open(ti, si, autoplay = true) {
    stopHold();
    showGloss(false);
    E.topic = ti; E.scn = si; E.D = E.data[ti].scenarios[si]; E.k = 0; E.frac = 0;
    const tp = E.data[ti];
    topicBar(ti);
    $e("eduTitle").textContent = tp.title;
    $e("eduDesc").textContent = tp.desc;
    $e("eduScn").innerHTML = tp.scenarios.length > 1 ? tp.scenarios.map((s, j) => `<button data-s="${j}" class="${j === si ? "on" : ""}">${esc(s.title)}</button>`).join("") : "";
    $e("eduSteps").innerHTML = E.D.steps.map((q, j) => `<div class="edu-st" data-j="${j}"><b>${j + 1}. ${esc(q[0])}</b><p>${esc(q[1])}</p></div>`).join("");
    $e("eduSrc").textContent = `Data asli: ${E.D.sym} Perpetual · TF ${E.D.tf.toUpperCase()} · ${fmtT(E.D.C[0][0])} – ${fmtT(E.D.C[N() - 1][0])} UTC (Binance Futures). ` +
      "Contoh sejarah yang dicari otomatis untuk belajar — bukan sinyal, dan tidak setiap kejadian berakhir sebaik ini.";
    scale();
    play(autoplay);
  }
  function topicBar(ti) {
    let h = `<button data-gl="1" class="edu-glbtn ${ti < 0 ? "on" : ""}">📖 Kamus ${E.gloss.length} istilah</button>`, grp = null;
    E.data.forEach((x, j) => {                         // dikelompokkan: Price Action & SMC · Indikator · Pola & alat
      const gname = x.group || "Price Action & SMC";
      if (gname !== grp) { h += `<span class="edu-grp">${esc(gname)}</span>`; grp = gname; }
      h += `<button data-t="${j}" class="${j === ti ? "on" : ""}">${esc(x.title)}</button>`;
    });
    $e("eduTopics").innerHTML = h;
  }
  function showGloss(on) {
    $e("eduGloss").classList.toggle("hidden", !on);
    for (const id of ["eduMain", "eduSrc"]) $e(id).classList.toggle("hidden", on);
    root.querySelector(".edu-head").classList.toggle("hidden", on);
  }
  function glossary(q) {
    stopHold(); E.playing = false;
    topicBar(-1); showGloss(true);
    const box = $e("eduGloss");
    if (!box.dataset.ready) {
      box.innerHTML = `<div class="edu-gl-top"><b>📖 Kamus istilah Price Action + SMC/ICT</b> <input id="eduQ" placeholder="cari istilah… (mis. OB, sweep, premium)">
        <span class="hint">klik ▶ untuk melihat animasinya, langsung di langkah yang menunjukkan istilah itu</span></div><div id="eduGlList" class="edu-gl-list"></div>`;
      box.dataset.ready = "1";
      $e("eduQ").addEventListener("input", (e) => renderGl(e.target.value));
    }
    renderGl(q || $e("eduQ").value || "");
  }
  function renderGl(q) {
    const s = q.trim().toLowerCase();
    $e("eduGlList").innerHTML = E.gloss.filter((g) => !s || (g.term + " " + g.def).toLowerCase().includes(s)).map((g) => {
      const t = g.topic != null ? E.data[g.topic] : null;
      return `<div class="edu-gl"><span class="edu-gl-no">${g.no}</span><div><b>${esc(g.term)}</b><p>${esc(g.def)}</p></div>
        ${t ? `<button data-go="${g.no}" title="${esc(t.title)}">▶ lihat animasi</button>` : '<span class="hint">—</span>'}</div>`;
    }).join("") || '<p class="hint">Tidak ada istilah yang cocok.</p>';
  }
  function goTerm(no) {
    const g = E.gloss.find((x) => x.no === no);
    if (!g || g.topic == null) return;
    open(g.topic, g.scn, false);
    E.k = Math.max(0, E.D.steps[g.step][3]); E.frac = 0;
    toast && toast(`📖 ${g.term}: diputar mulai langkah "${E.D.steps[g.step][0]}"`);
    play(true);
  }
  root.addEventListener("click", (e) => {
    const b = e.target.closest("button, .edu-st");
    if (!b || !E.data) return;
    if (b.dataset.gl) return glossary();
    if (b.dataset.go) return goTerm(+b.dataset.go);
    if (b.dataset.t != null) return open(+b.dataset.t, 0);
    if (b.dataset.s != null && b.closest("#eduScn")) return open(E.topic, +b.dataset.s);
    if (b.dataset.s != null && b.closest(".edu-sp")) { E.speed = +b.dataset.s; root.querySelectorAll(".edu-sp button").forEach((x) => x.classList.toggle("on", x === b)); return; }
    if (b.classList.contains("edu-st")) { stopHold(); E.k = Math.max(0, E.D.steps[+b.dataset.j][3]); E.frac = 0; return play(true); }
    if (b.id === "eduRestart") { stopHold(); E.k = 0; E.frac = 0; return play(true); }
    if (b.id === "eduPlay") { if (E.k >= N()) { E.k = 0; E.frac = 0; } stopHold(); return play(!E.playing); }
    if (b.id === "eduNext") { stopHold(); E.playing = false; if (E.k < N()) { E.k++; E.frac = 0; } return draw(); }
  });
  $e("eduSeek").addEventListener("input", (e) => { stopHold(); E.playing = false; const v = e.target.value / 1000 * N(); E.k = Math.floor(v); E.frac = v - E.k; draw(); });
  async function load(autoplay) {
    if (E.data) return play(autoplay !== false && !E.playing ? true : E.playing);
    try {
      const j = await (await fetch("/static/edu_data.json?v=" + (window.APP_VERSION || ""))).json();
      E.data = j.topics || j;
      E.gloss = j.glossary || [];
      open(0, 0, autoplay !== false);
    } catch (ex) { root.innerHTML = `<p class="neg">Gagal memuat materi: ${esc(ex.message)}</p>`; }
  }
  window.EDU = { load, set(k, f) { stopHold(); E.playing = false; E.k = k; E.frac = f; draw(); }, open, glossary, goTerm, state: E };
})();
