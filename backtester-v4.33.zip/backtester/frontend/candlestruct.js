// 🔬 Struktur candle (Manual Replay)
// Klik kanan candle di chart -> lihat isinya di TF kecil (popup beranimasi) atau buka di TF kecil + garis batas.
// Bisa pilih candle bebas (mis. beberapa doji) untuk dibandingkan berdampingan, rentang beberapa candle, atau 1 minggu (W -> D1).
// Data diminta ke server lewat perintah replay "struct": hanya candle yang sudah terjadi menurut waktu replay.
(() => {
  const DAY = 86_400_000, WEEK = 7 * DAY, MONDAY = 4 * DAY;   // 1970-01-05 = Senin (minggu Binance mulai Senin 00:00 UTC)
  const MAXSEL = 12;
  const UP = COLORS.up, DN = COLORS.down, GOLD = "#f0b90b", BLUE = "#3b82f6", MUT = "#7d8696", TXT = "#d5dae3";
  const FONT = "system-ui,-apple-system,Segoe UI,sans-serif";
  const CS = { sel: [], from: null, low: null, menu: null, view: null };
  const chartEl = $("chart");

  // ---------------------------------------------------------------- util
  const tfMs = (tf) => (tf === "1w" ? WEEK : TF_SEC[tf] * 1000);
  const tfName = (tf) => ({ "1w": "W", "1d": "D1" }[tf] || tf.toUpperCase());
  const p2 = (n) => String(n).padStart(2, "0");
  const dstr = (ms) => { const d = new Date(ms); return `${d.getUTCFullYear()}-${p2(d.getUTCMonth() + 1)}-${p2(d.getUTCDate())}`; };
  const hm = (ms) => { const d = new Date(ms); return `${p2(d.getUTCHours())}:${p2(d.getUTCMinutes())}`; };
  const when = (ms) => (ms % DAY === 0 ? dstr(ms) : `${dstr(ms)} ${hm(ms)}`);
  const px = (v) => (+v).toFixed(DEC);
  const pct = (v, d = 1) => `${v >= 0 ? "" : "−"}${Math.abs(v).toFixed(d)}%`;
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const key = (it) => `${it.t0}-${it.t1}`;
  const sub = (it) => (it.kind === "week" ? DAY : tfMs(it.tf));   // durasi 1 candle besar di dalam item

  function mkItem(kind, tf, t0, t1) {
    const n = Math.round((t1 - t0) / (kind === "week" ? DAY : tfMs(tf)));
    const label = kind === "week" ? `W · minggu ${dstr(t0)}`
      : kind === "range" ? `${n} candle ${tfName(tf)} · ${when(t0)} → ${when(t1 - tfMs(tf))}`
        : `${tfName(tf)} · ${when(t0)}`;
    return { kind, tf, t0, t1, n, label };
  }
  // TF kecil yang masuk akal untuk semua item: lebih kecil dari candle-nya, 2..2000 candle per item
  function lowOptions(items) {
    const tfs = (S.info && S.info.timeframes) || [];
    return tfs.filter((tf) => items.every((it) => {
      const ms = tfMs(tf), span = it.t1 - it.t0;
      return (ms < sub(it) || (it.kind === "week" && ms === DAY)) && span / ms >= 2 && span / ms <= 2000;
    }));
  }
  function pickLow(items, opts) {
    if (CS.low && opts.includes(CS.low)) return CS.low;
    const span = Math.max(...items.map((i) => (i.t1 - i.t0) / i.n));    // pilih yang memberi ±24 candle kecil per candle besar
    return opts.slice().sort((a, b) => Math.abs(Math.log(span / tfMs(a) / 24)) - Math.abs(Math.log(span / tfMs(b) / 24)))[0];
  }

  // ---------------------------------------------------------------- tanda di chart
  kc.registerOverlay({
    name: "csMark", totalStep: 3, needDefaultPointFigure: false, needDefaultXAxisFigure: false, needDefaultYAxisFigure: false,
    createPointFigures: ({ overlay, coordinates: c, bounding, barSpace }) => {
      if (c.length < 2) return [];
      const d = overlay.extendData || {}, hb = (barSpace && barSpace.halfBar) || 3, col = d.color || GOLD;
      const x0 = Math.min(c[0].x, c[1].x) - hb - 2, x1 = Math.max(c[0].x, c[1].x) + hb + 2, xm = (x0 + x1) / 2;
      return [
        { type: "rect", ignoreEvent: true, attrs: { x: x0, y: 2, width: x1 - x0, height: bounding.height - 4 },
          styles: { style: "stroke_fill", color: hexA(col, 0.09), borderColor: col, borderSize: 1.5, borderRadius: 4,
            borderStyle: d.dashed ? "dashed" : "solid", borderDashedValue: [4, 3] } },
        { type: "circle", ignoreEvent: true, attrs: { x: xm, y: bounding.height - 16, r: 9 }, styles: { style: "fill", color: col } },
        { type: "text", ignoreEvent: true, attrs: { x: xm, y: bounding.height - 16, text: String(d.n), align: "center", baseline: "middle" },
          styles: { ...txtSt("#111", 10), weight: "bold" } },
      ];
    },
  });
  // garis batas candle besar saat dibuka di TF kecil
  kc.registerOverlay({
    name: "csFrame", totalStep: 7, needDefaultPointFigure: false, needDefaultXAxisFigure: false, needDefaultYAxisFigure: false,
    createPointFigures: ({ overlay, coordinates: c, bounding, barSpace }) => {
      if (c.length < 6) return [];
      const d = overlay.extendData, hb = (barSpace && barSpace.halfBar) || 3, out = [];
      const x0 = c[0].x - hb - 1, x1 = c[1].x + hb + 1, W = bounding.width, Hh = bounding.height, col = d.c >= d.o ? UP : DN;
      if (d.dim) for (const [a, b] of [[0, x0], [x1, W]]) if (b > a)
        out.push({ type: "rect", ignoreEvent: true, attrs: { x: a, y: 0, width: b - a, height: Hh }, styles: { style: "fill", color: "rgba(12,14,19,0.62)" } });
      out.push({ type: "rect", ignoreEvent: true, attrs: { x: x0, y: 0, width: x1 - x0, height: Hh }, styles: { style: "fill", color: hexA(BLUE, 0.05) } });
      for (const x of [x0, x1]) out.push({ type: "line", ignoreEvent: true, attrs: { coordinates: [{ x, y: 0 }, { x, y: Hh }] }, styles: { style: "solid", color: BLUE, size: 1.5 } });
      for (let k = 6; k < c.length; k++) { const x = c[k].x - hb - 1;
        out.push({ type: "line", ignoreEvent: true, attrs: { coordinates: [{ x, y: 0 }, { x, y: Hh }] }, styles: { style: "dashed", dashedValue: [3, 4], color: hexA(BLUE, 0.6), size: 1 } }); }
      const lv = [[c[0].y, `${d.tfl} HIGH ${px(d.h)}`, GOLD], [c[1].y, `${d.tfl} LOW ${px(d.l)}`, GOLD], [c[4].y, `OPEN ${px(d.o)}`, MUT], [c[5].y, `CLOSE ${px(d.c)}`, col]];
      const ly = lv.map((v, i) => ({ y: v[0], i })).sort((p, q) => p.y - q.y);   // label tidak saling menimpa
      for (let j = 1; j < ly.length; j++) ly[j].y = Math.max(ly[j].y, ly[j - 1].y + 17);
      for (const { y: yl, i } of ly) {
        const [y, t, cl] = lv[i];
        out.push({ type: "line", ignoreEvent: true, attrs: { coordinates: [{ x: x0, y }, { x: x1, y }] }, styles: { style: "dashed", dashedValue: [6, 4], color: cl, size: 1 } });
        out.push({ type: "text", ignoreEvent: true, attrs: { x: x1 + 4, y: yl, text: t, align: "left", baseline: "middle" },
          styles: { color: "#111", backgroundColor: cl, size: 10, paddingLeft: 4, paddingRight: 4, paddingTop: 2, paddingBottom: 2, borderRadius: 2, borderSize: 0 } });
      }
      out.push({ type: "text", ignoreEvent: true, attrs: { x: x0 + 6, y: Hh - 8, text: `◀ ${d.label}`, align: "left", baseline: "bottom" },
        styles: { color: "#fff", backgroundColor: BLUE, size: 11, paddingLeft: 5, paddingRight: 5, paddingTop: 3, paddingBottom: 3, borderRadius: 3, borderSize: 0 } });
      const marks = [[c[2], d.firstHigh ? "①" : "②", -1], [c[3], d.firstHigh ? "②" : "①", 1]];
      for (const [p, t, s] of marks) {
        out.push({ type: "circle", ignoreEvent: true, attrs: { x: p.x, y: p.y, r: 6 }, styles: { style: "stroke", borderColor: GOLD, borderSize: 2 } });
        out.push({ type: "text", ignoreEvent: true, attrs: { x: p.x, y: p.y + s * 16, text: t, align: "center", baseline: "middle" }, styles: txtSt(GOLD, 13) });
      }
      return out;
    },
  });

  function renderMarks() {
    chart.removeOverlay({ groupId: "csMark" });
    const cur = tfMs(S.tf);
    const mark = (it, n, extra) => {
      const a = Math.floor(it.t0 / cur) * cur, b = Math.max(a, Math.floor((it.t1 - 1) / cur) * cur);
      chart.createOverlay({ name: "csMark", groupId: "csMark", lock: true, points: [{ timestamp: a, value: 0 }, { timestamp: b, value: 0 }], extendData: { n, ...extra } });
    };
    CS.sel.forEach((it, i) => mark(it, i + 1));
    if (CS.from) mark({ t0: CS.from.t, t1: CS.from.t + tfMs(CS.from.tf) }, "↔", { dashed: true, color: BLUE });
    renderBar();
  }

  // ---------------------------------------------------------------- bar pilihan (di atas chart)
  const bar = document.createElement("div");
  bar.className = "cs-bar";
  chartEl.appendChild(bar);
  function renderBar() {
    if (!CS.sel.length && !CS.from) { bar.style.display = "none"; return; }
    bar.style.display = "";
    const chips = CS.sel.map((it, i) => `<span class="cs-chip"><b>${i + 1}</b> ${esc(it.label)}<button data-rm="${i}" title="keluarkan">✕</button></span>`).join("");
    bar.innerHTML = (CS.from ? `<span class="cs-hint">↔ Rentang mulai ${esc(when(CS.from.t))} — klik kanan candle akhirnya</span><button data-a="fromX">batal</button>` : "")
      + (CS.sel.length ? `<span class="cs-hint">🔬 ${CS.sel.length} dipilih</span>${chips}<button class="cs-go" data-a="cmp">🖼 Bandingkan isinya</button><button data-a="clr">✖ Kosongkan</button>` : "");
  }
  bar.addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    if (b.dataset.rm != null) CS.sel.splice(+b.dataset.rm, 1);
    if (b.dataset.a === "fromX") CS.from = null;
    if (b.dataset.a === "clr") CS.sel = [];
    if (b.dataset.a === "cmp") return openViewer(CS.sel.slice());
    renderMarks();
  });
  ["pointerdown", "mousedown", "wheel", "touchstart"].forEach((ev) => bar.addEventListener(ev, (e) => e.stopPropagation()));

  // ---------------------------------------------------------------- menu klik kanan
  chartEl.addEventListener("contextmenu", (e) => {
    if (!S.started || e.target.closest(".cs-bar")) return;
    if (!menuAt(e.clientX, e.clientY)) return;
    e.preventDefault();
  });
  // HP: tekan lama (±0,6 dtk tanpa bergeser) juga membuka menu
  let press = null;
  chartEl.addEventListener("pointerdown", (e) => {
    if (e.pointerType !== "touch" || !S.started || e.target.closest(".cs-bar")) return;
    clearTimeout(press && press.tm);
    press = { x: e.clientX, y: e.clientY, tm: setTimeout(() => { if (press) menuAt(press.x, press.y); press = null; }, 600) };
  }, true);
  const cancelPress = (e) => { if (press && (e.type !== "pointermove" || Math.hypot(e.clientX - press.x, e.clientY - press.y) > 10)) { clearTimeout(press.tm); press = null; } };
  ["pointerup", "pointercancel", "pointermove"].forEach((ev) => chartEl.addEventListener(ev, cancelPress, true));
  function menuAt(cx, cy) {
    if (CS.menu) return true;
    const r = chartEl.getBoundingClientRect();
    const pt = chart.convertFromPixel([{ x: cx - r.left, y: cy - r.top }], { paneId: "candle_pane" });
    const list = chart.getDataList(), i = pt && pt[0] ? pt[0].dataIndex : -1;
    if (!(i >= 0 && i < list.length)) return false;
    openMenu(cx, cy, list[i]);
    return true;
  }
  function closeMenu() { if (CS.menu) { CS.menu.remove(); CS.menu = null; } }
  document.addEventListener("pointerdown", (e) => { if (CS.menu && !CS.menu.contains(e.target)) closeMenu(); }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeMenu(); closeViewer(); } });

  function openMenu(x, y, k) {
    closeMenu();
    const tf = S.tf, dur = tfMs(tf), it = mkItem("one", tf, k.timestamp, k.timestamp + dur);
    const inSel = CS.sel.findIndex((s) => key(s) === key(it));
    const col = k.close >= k.open ? UP : DN, rng = k.high - k.low;
    const body = rng > 0 ? (100 * Math.abs(k.close - k.open)) / rng : 0;
    let rangeIt = null;
    if (CS.from && CS.from.tf === tf && CS.from.t !== k.timestamp) {
      const a = Math.min(CS.from.t, k.timestamp), b = Math.max(CS.from.t, k.timestamp) + dur;
      rangeIt = mkItem("range", tf, a, b);
    }
    const week = ["4h", "6h", "8h", "12h", "1d"].includes(tf) ? Math.floor((k.timestamp - MONDAY) / WEEK) * WEEK + MONDAY : null;
    const opts = lowOptions([it]);
    const m = document.createElement("div");
    m.className = "cs-menu";
    m.innerHTML = `<div class="cs-mhead"><span class="cs-dot" style="background:${col}"></span><b>Candle ${tfName(tf)}</b> ${esc(when(k.timestamp))}
        <div class="cs-msub">badan ${body.toFixed(0)}% · range ${pct((100 * rng) / k.open, 2)}${body <= 15 ? " · <b style='color:" + GOLD + "'>doji</b>" : ""}</div></div>
      ${rangeIt ? `<button data-a="rgo">✔ Akhiri rentang di sini → lihat (${rangeIt.n} candle)</button><button data-a="radd">➕ Akhiri rentang &amp; masukkan ke perbandingan</button><div class="cs-sep"></div>` : ""}
      <button data-a="view" ${opts.length ? "" : "disabled"}>🔬 <b>Lihat isi candle ini</b> <span class="cs-k">animasi</span></button>
      ${inSel >= 0 ? `<button data-a="del">➖ Keluarkan dari perbandingan</button>`
        : `<button data-a="add" ${CS.sel.length >= MAXSEL || !opts.length ? "disabled" : ""}>➕ Tambah ke perbandingan <span class="cs-k">${CS.sel.length}/${MAXSEL}</span></button>`}
      ${CS.from && !rangeIt ? `<button data-a="fromX">✖ Batal pilih rentang</button>` : `<button data-a="from">↔ Pilih rentang mulai dari candle ini…</button>`}
      ${week != null ? `<button data-a="week">📅 Lihat 1 minggu ini (W → D1)</button>` : ""}
      ${CS.sel.length ? `<button data-a="cmp">🖼 Bandingkan semua pilihan (${CS.sel.length})</button>` : ""}
      <div class="cs-sep"></div>
      <div class="cs-row"><span>📉 Buka di TF kecil + garis:</span>${opts.map((t) => `<button class="cs-tf" data-low="${t}">${tfName(t)}</button>`).join("") || "<i>tidak ada TF lebih kecil</i>"}</div>
      ${CS.framed ? `<button data-a="unframe">🧹 Hapus garis struktur</button>` : ""}`;
    document.body.appendChild(m);
    const w = m.offsetWidth, h = m.offsetHeight;
    m.style.left = `${Math.max(6, Math.min(x, innerWidth - w - 6))}px`;
    m.style.top = `${Math.max(6, Math.min(y, innerHeight - h - 6))}px`;
    CS.menu = m;
    m.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (!b || b.disabled) return;
      closeMenu();
      const a = b.dataset.a;
      if (b.dataset.low) return openOnChart([it], b.dataset.low);
      if (a === "view") return openViewer([it]);
      if (a === "add") CS.sel.push(it);
      if (a === "del") CS.sel.splice(inSel, 1);
      if (a === "from") CS.from = { t: k.timestamp, tf };
      if (a === "fromX") CS.from = null;
      if (a === "rgo") { CS.from = null; renderMarks(); return openViewer([rangeIt]); }
      if (a === "radd") { CS.from = null; if (CS.sel.length < MAXSEL) CS.sel.push(rangeIt); }
      if (a === "week") return openViewer([mkItem("week", "1w", week, week + WEEK)], "1d");
      if (a === "cmp") return openViewer(CS.sel.slice());
      if (a === "unframe") { chart.removeOverlay({ groupId: "csFrame" }); CS.framed = false; }
      renderMarks();
    });
  }

  // ---------------------------------------------------------------- ambil data
  async function fetchStruct(items, low) {
    const r = await send({ cmd: "struct", low, ranges: items.map((i) => [i.t0, i.t1]) });
    if (r.type !== "struct") return null;
    return r.items.map((x, i) => ({ ...x, it: items[i] }));
  }

  // ---------------------------------------------------------------- buka di TF kecil + garis
  async function openOnChart(items, low) {
    if (!S.started) return;
    const data = await fetchStruct(items, low);
    if (!data) return;
    if (S.tf !== low) { const r = await send({ cmd: "set_tf", tf: low }); if (r.type !== "init") return; }
    const lowMs = tfMs(low), first = Math.min(...items.map((i) => i.t0)), last = Math.max(...items.map((i) => i.t1));
    let list = chart.getDataList(), loaded = 0;
    while (list.length && list[0].timestamp > first - 30 * lowMs) {          // muat candle lama sampai rentangnya kelihatan
      if (loaded > 40000) { toast("Candle itu terlalu jauh di belakang untuk TF ini — pilih TF kecil yang lebih besar"); break; }
      const h = await send({ cmd: "history", tf: low, before: list[0].timestamp, n: 5000 });
      if (h.type !== "history" || !h.bars.length) break;
      await new Promise((ok) => chart.applyMoreData(h.bars.map(toK), true, ok));
      loaded += h.bars.length;
      list = chart.getDataList();
    }
    chart.removeOverlay({ groupId: "csFrame" });
    CS.framed = true;
    for (const d of data) {
      if (!d.big) continue;
      const b = d.bars, it = d.it, tLast = b[b.length - 1].time * 1000, subs = [];
      for (let t = it.t0 + sub(it); t < it.t1 && t <= tLast; t += sub(it)) subs.push({ timestamp: t, value: d.big.high });
      chart.createOverlay({ name: "csFrame", groupId: "csFrame", lock: true,
        points: [{ timestamp: it.t0, value: d.big.high }, { timestamp: tLast, value: d.big.low },
          { timestamp: b[d.i_high].time * 1000, value: d.big.high }, { timestamp: b[d.i_low].time * 1000, value: d.big.low },
          { timestamp: it.t0, value: d.big.open }, { timestamp: tLast, value: d.big.close }, ...subs],
        extendData: { label: it.label + (d.done ? "" : " (masih terbentuk)"), tfl: it.kind === "week" ? "W" : tfName(it.tf),
          h: d.big.high, l: d.big.low, o: d.big.open, c: d.big.close, firstHigh: d.first === "high", dim: data.length === 1 } });
    }
    const bars = (last - first) / lowMs, w = chartEl.clientWidth || 800;
    chart.setBarSpace(Math.max(1, Math.min(24, (w * 0.62) / bars)));
    list = chart.getDataList();
    const iEnd = list.findIndex((x) => x.timestamp >= last - lowMs);
    const bsp = chart.getBarSpace(), vis = w / (typeof bsp === "number" ? bsp : bsp.bar);
    if (iEnd >= 0) chart.scrollToDataIndex(Math.min(list.length - 1, iEnd + Math.floor((vis - bars) / 2)));
    renderMarks();
    toast(`Chart pindah ke ${tfName(low)} · garis biru = batas candle, ① ② = urutan high/low`);
  }

  // ---------------------------------------------------------------- popup beranimasi
  const modal = document.createElement("div");
  modal.className = "cs-modal";
  modal.style.display = "none";
  document.body.appendChild(modal);
  modal.addEventListener("pointerdown", (e) => { if (e.target === modal) closeViewer(); });

  function closeViewer() {
    if (!CS.view) return;
    cancelAnimationFrame(CS.view.raf);
    CS.view = null;
    modal.style.display = "none";
    modal.innerHTML = "";
  }

  async function openViewer(items, low) {
    if (!S.started || !items.length) return;
    const opts = lowOptions(items);
    if (!opts.length) return toast("Tidak ada TF yang lebih kecil untuk candle ini");
    low = low && opts.includes(low) ? low : pickLow(items, opts);
    const data = await fetchStruct(items, low);
    if (!data) return;
    CS.low = low;
    if (CS.view) cancelAnimationFrame(CS.view.raf);
    const v = (CS.view = { items, low, opts, data, p: 0, playing: true, speed: CS.view ? CS.view.speed : 1, last: 0, raf: 0 });
    const n = data.length, cols = n === 1 ? 1 : n === 2 || n === 4 ? 2 : 3;
    modal.innerHTML = `<div class="cs-box">
      <div class="cs-top">
        <div><div class="cs-title">🔬 Struktur candle · ${esc(S.info ? S.info.symbol : "")}</div>
          <div class="cs-sub">${n === 1 ? esc(items[0].label) : `${n} candle dibandingkan`} · isi dilihat di TF
            ${opts.map((t) => `<button class="cs-tf ${t === low ? "on" : ""}" data-low="${t}">${tfName(t)}</button>`).join("")}</div></div>
        <div class="cs-acts"><button data-a="chart" title="pindah chart ke TF kecil + garis batas">📉 Buka di chart</button>
          <button data-a="png">⬇ Gambar</button><button data-a="x" class="cs-x">✕</button></div>
      </div>
      <div class="cs-grid" style="grid-template-columns:repeat(${cols},minmax(0,1fr))">${data.map((d, i) => `<div class="cs-panel" data-i="${i}"></div>`).join("")}</div>
      <div class="cs-player">
        <button data-a="restart" title="ulang">⏮</button><button data-a="play" class="cs-play">⏸</button>
        <input type="range" min="0" max="1000" value="0" class="cs-seek">
        <span class="cs-time"></span>
        <span class="cs-speed">${[0.5, 1, 2, 4].map((s) => `<button data-sp="${s}" class="${s === v.speed ? "on" : ""}">${s}×</button>`).join("")}</span>
      </div></div>`;
    modal.style.display = "";
    const seek = modal.querySelector(".cs-seek");
    seek.oninput = () => { v.p = seek.value / 1000; v.playing = false; draw(); };
    modal.querySelector(".cs-box").onclick = (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      if (b.dataset.low) return openViewer(items, b.dataset.low);
      if (b.dataset.sp) { v.speed = +b.dataset.sp; modal.querySelectorAll(".cs-speed button").forEach((x) => x.classList.toggle("on", x === b)); return; }
      const a = b.dataset.a;
      if (a === "x") return closeViewer();
      if (a === "play") { if (v.p >= 1) v.p = 0; v.playing = !v.playing; v.last = 0; draw(); if (v.playing) loop(); }
      if (a === "restart") { v.p = 0; v.playing = true; v.last = 0; draw(); loop(); }
      if (a === "chart") { closeViewer(); openOnChart(items, low); }
      if (a === "png") downloadPng(v);
    };
    draw();
    loop();
  }

  function loop() {
    const v = CS.view;
    if (!v) return;
    cancelAnimationFrame(v.raf);
    const nMax = Math.max(...v.data.map((d) => d.expected));
    const total = Math.min(9000, Math.max(3500, nMax * 180)) / v.speed;    // ±3,5–9 detik di 1×
    const tick = (ts) => {
      if (CS.view !== v || !v.playing) return;
      if (v.last) v.p = Math.min(1, v.p + ((ts - v.last) / total) * 1);
      v.last = ts;
      draw();
      if (v.p >= 1) { v.playing = false; draw(); return; }
      v.raf = requestAnimationFrame(tick);
    };
    v.last = 0;
    v.raf = requestAnimationFrame(tick);
  }

  function draw() {
    const v = CS.view;
    if (!v) return;
    const big = v.data.length === 1;
    const sig = v.data.map((d) => Math.min(d.bars.length, Math.ceil(v.p * d.expected))).join(",") + (v.p >= 1 ? "E" : "");
    if (sig !== v.sig) {        // gambar ulang hanya saat ada candle baru (animasi candle baru tidak terulang tiap frame)
      v.sig = sig;
      modal.querySelectorAll(".cs-panel").forEach((el, i) => { el.innerHTML = panelSvg(v.data[i], v.p, big, i + 1, v.data.length > 1) + panelInfo(v.data[i], v.p); });
    }
    const seek = modal.querySelector(".cs-seek");
    if (seek && document.activeElement !== seek) seek.value = Math.round(v.p * 1000);
    const pb = modal.querySelector(".cs-play");
    if (pb) pb.textContent = v.playing ? "⏸" : "▶";
    const d0 = v.data[0], k = Math.min(d0.bars.length, Math.ceil(v.p * d0.expected));
    const tm = modal.querySelector(".cs-time");
    if (tm) tm.textContent = k ? `${tfName(v.low)} ke-${k}/${d0.expected}${v.data.length === 1 ? ` · ${when(d0.bars[k - 1].time * 1000)} UTC` : ""}` : "mulai";
  }

  // satu panel SVG: kiri = candle besar yang sedang terbentuk, kanan = candle kecil muncul satu per satu
  function panelSvg(d, p, large, num, showNum, still) {
    const W = large ? 1040 : 440, H = large ? 430 : 320;
    const it = d.it, fs = large ? 1 : 1.12;
    if (!d.big) return `<svg viewBox="0 0 ${W} 120" width="100%"><text x="${W / 2}" y="60" fill="${MUT}" font-family="${FONT}" font-size="14" text-anchor="middle">Belum ada data untuk candle ini di waktu replay sekarang</text></svg>`;
    const bars = d.bars, nExp = Math.max(d.expected, bars.length);
    const k = still ? bars.length : Math.min(bars.length, Math.ceil(p * d.expected));
    const end = still || p >= 1 || k >= bars.length && p * d.expected >= bars.length;
    const lowMs = (bars.length > 1 ? bars[1].time - bars[0].time : 0) * 1000 || (it.t1 - it.t0) / nExp;
    const L = { l: large ? 120 : 66, r: large ? 100 : 86, t: 44, b: 52 };
    const volH = large ? 46 : 32, pw = W - L.l - L.r, ph = H - L.t - L.b - volH - 6;
    const hi = d.big.high, lo = d.big.low, padv = (hi - lo) * 0.08 || hi * 0.001, top = hi + padv, bot = lo - padv;
    const Y = (v) => L.t + ((top - v) / (top - bot)) * ph;
    const slot = pw / nExp, X = (i) => L.l + slot * (i + 0.5), bw = Math.max(1, Math.min(slot * 0.66, 22));
    const vMax = Math.max(...bars.map((b) => b.volume)) || 1, vy = L.t + ph + 6 + volH;
    const g = [];
    g.push(`<rect width="${W}" height="${H}" fill="#121721" rx="12"/>`);
    // sesi (Asia / London / New York) bila isinya intraday
    const spanMs = it.t1 - it.t0;
    if (lowMs <= 3_600_000 && spanMs <= 2 * DAY) {
      const sess = [[0, 7, "Asia", "#8b5cf6"], [7, 13, "London", "#3b82f6"], [13, 21, "New York", "#f59e0b"]];
      for (let day = Math.floor(it.t0 / DAY) * DAY; day < it.t1; day += DAY) for (const [a, b, nm, cl] of sess) {
        const s0 = Math.max(it.t0, day + a * 3_600_000), s1 = Math.min(it.t1, day + b * 3_600_000);
        if (s1 <= s0) continue;
        const xa = L.l + ((s0 - it.t0) / spanMs) * pw, xb = L.l + ((s1 - it.t0) / spanMs) * pw;
        g.push(`<rect x="${xa}" y="${L.t}" width="${xb - xa}" height="${ph + volH + 6}" fill="${cl}" fill-opacity=".055"/>`
          + `<text x="${(xa + xb) / 2}" y="${H - 34}" fill="${cl}" fill-opacity=".85" font-size="${10.5 * fs}" text-anchor="middle">${nm}</text>`);
      }
    }
    // label harga di sumbu kanan: O / H / L / C sebagai label berwarna, angka grid hanya kalau tidak bertabrakan
    const shownK = still ? bars.length : Math.min(bars.length, Math.ceil(p * d.expected));
    const sh = bars.slice(0, shownK);
    const tags = [[d.big.open, "O", MUT]];
    if (sh.length) {
      tags.push([Math.max(...sh.map((b) => b.high)), "H", GOLD], [Math.min(...sh.map((b) => b.low)), "L", GOLD]);
      if (end) tags.push([d.big.close, "C", d.big.close >= d.big.open ? UP : DN]);
    }
    const th = 17 * fs, ty = tags.map(([v]) => Y(v)).map((y, i) => ({ y, i })).sort((a, b) => a.y - b.y);
    for (let j = 1; j < ty.length; j++) ty[j].y = Math.max(ty[j].y, ty[j - 1].y + th);
    for (let j = 0; j <= 4; j++) { const v = bot + ((top - bot) * j) / 4, y = Y(v);
      g.push(`<line x1="${L.l}" x2="${W - L.r}" y1="${y}" y2="${y}" stroke="#1e2531"/>`);
      if (ty.every((t) => Math.abs(t.y - y) > th)) g.push(`<text x="${W - L.r + 8}" y="${y + 4}" fill="#5b6576" font-size="${10 * fs}">${px(v)}</text>`); }
    const tagSvg = () => ty.map(({ y, i }) => { const [v, t, c] = tags[i];
      return `<rect x="${W - L.r + 3}" y="${y - th / 2}" width="${L.r - 8}" height="${th - 2}" rx="3" fill="${c}"/>`
        + `<text x="${W - L.r + 8}" y="${y + 3.5 * fs}" fill="#0b0f14" font-size="${10.5 * fs}" font-weight="700">${t} ${px(v)}</text>`; }).join("");
    // batas candle besar di dalam rentang / minggu
    const sd = sub(it);
    for (let t = it.t0 + sd; t < it.t1; t += sd) { const x = L.l + ((t - it.t0) / spanMs) * pw;
      g.push(`<line x1="${x}" x2="${x}" y1="${L.t - 6}" y2="${L.t + ph + volH + 6}" stroke="${BLUE}" stroke-opacity=".55" stroke-dasharray="3 4"/>`
        + `<text x="${x + 4}" y="${L.t + 4}" fill="${BLUE}" font-size="${10 * fs}">${esc(it.kind === "week" ? dstr(t).slice(5) : when(t).slice(5))}</text>`); }
    // candle besar yang sedang terbentuk (kiri)
    const shown = bars.slice(0, k);
    let cur = null, ih = -1, il = -1;
    if (shown.length) {
      let h = -Infinity, l = Infinity;
      shown.forEach((b, i) => { if (b.high > h) { h = b.high; ih = i; } if (b.low < l) { l = b.low; il = i; } });
      cur = { o: shown[0].open, h, l, c: shown[shown.length - 1].close };
    }
    const bx = L.l / 2, bwid = large ? 34 : 20;
    g.push(`<text x="${bx}" y="${L.t - 10}" fill="${MUT}" font-size="${10 * fs}" text-anchor="middle">${it.kind === "week" ? "W" : tfName(it.tf)}${it.kind === "range" ? ` ×${it.n}` : ""}${large ? (end ? (d.done ? " selesai" : " berjalan") : " terbentuk…") : ""}</text>`);
    g.push(`<rect x="${bx - bwid / 2 - 8}" y="${L.t - 4}" width="${bwid + 16}" height="${ph + 8}" rx="8" fill="#0d1118" stroke="#222a37"/>`);
    if (cur) {
      const cc = cur.c >= cur.o ? UP : DN;
      g.push(`<line x1="${bx}" x2="${bx}" y1="${Y(cur.h)}" y2="${Y(cur.l)}" stroke="${cc}" stroke-width="2.5"/>`
        + `<rect x="${bx - bwid / 2}" y="${Math.min(Y(cur.o), Y(cur.c))}" width="${bwid}" height="${Math.max(2, Math.abs(Y(cur.o) - Y(cur.c)))}" fill="${cc}" rx="2"/>`
        + `<line x1="${bx + bwid / 2 + 8}" x2="${L.l}" y1="${Y(cur.c)}" y2="${Y(cur.c)}" stroke="${cc}" stroke-opacity=".5" stroke-dasharray="2 3"/>`);
    }
    // garis open, high & low sejauh ini
    g.push(`<line x1="${L.l}" x2="${W - L.r}" y1="${Y(d.big.open)}" y2="${Y(d.big.open)}" stroke="${MUT}" stroke-dasharray="5 5" stroke-opacity=".7"/>`);
    if (cur) for (const [v, i] of [[cur.h, ih], [cur.l, il]])
      g.push(`<line x1="${X(i)}" x2="${W - L.r}" y1="${Y(v)}" y2="${Y(v)}" stroke="${GOLD}" stroke-width="${end ? 1.4 : 1}" stroke-dasharray="${end ? "6 4" : "2 3"}"/>`);
    if (end) { const cc = d.big.close >= d.big.open ? UP : DN;
      g.push(`<line x1="${L.l}" x2="${W - L.r}" y1="${Y(d.big.close)}" y2="${Y(d.big.close)}" stroke="${cc}" stroke-dasharray="5 5"/>`); }
    g.push(tagSvg());
    // candle kecil
    shown.forEach((b, i) => {
      const cc = b.close >= b.open ? UP : DN, x = X(i), nw = !still && i === k - 1 && !end ? ' class="cs-new"' : "";
      g.push(`<g${nw}><line x1="${x}" x2="${x}" y1="${Y(b.high)}" y2="${Y(b.low)}" stroke="${cc}" stroke-width="${slot > 6 ? 1.2 : 1}"/>`
        + `<rect x="${x - bw / 2}" y="${Math.min(Y(b.open), Y(b.close))}" width="${bw}" height="${Math.max(1, Math.abs(Y(b.open) - Y(b.close)))}" fill="${cc}" rx="${bw > 5 ? 1.5 : 0}"/>`
        + `<rect x="${x - bw / 2}" y="${vy - (b.volume / vMax) * volH}" width="${bw}" height="${(b.volume / vMax) * volH}" fill="${cc}" fill-opacity=".35"/></g>`);
    });
    // penanda high / low baru (saat animasi) dan urutan ① ② di akhir
    if (cur && !end) {
      const nb = k - 1;
      if (ih === nb && nb > 0) g.push(`<g class="cs-pop"><circle cx="${X(ih)}" cy="${Y(cur.h)}" r="7" fill="none" stroke="${GOLD}" stroke-width="2"/><text x="${X(ih)}" y="${Y(cur.h) - 12}" fill="${GOLD}" font-size="${11 * fs}" text-anchor="middle" font-weight="700">▲ high baru</text></g>`);
      if (il === nb && nb > 0) g.push(`<g class="cs-pop"><circle cx="${X(il)}" cy="${Y(cur.l)}" r="7" fill="none" stroke="${GOLD}" stroke-width="2"/><text x="${X(il)}" y="${Y(cur.l) + 20}" fill="${GOLD}" font-size="${11 * fs}" text-anchor="middle" font-weight="700">▼ low baru</text></g>`);
    }
    if (end) {
      const hFirst = d.i_high < d.i_low;
      for (const [i, v, isH] of [[d.i_high, hi, true], [d.i_low, lo, false]]) {
        const y = Y(v), n1 = isH === hFirst ? "①" : "②", dy = isH ? -13 : 23, t = bars[i].time * 1000;
        const lx = Math.max(L.l + 34 * fs, Math.min(W - L.r - 34 * fs, X(i)));
        g.push(`<circle cx="${X(i)}" cy="${y}" r="7" fill="none" stroke="${GOLD}" stroke-width="2.2"/>`
          + `<text x="${lx}" y="${y + dy}" fill="${GOLD}" font-size="${12.5 * fs}" text-anchor="middle" font-weight="800" paint-order="stroke" stroke="#121721" stroke-width="4">${n1} ${spanMs > 2 * DAY ? dstr(t).slice(5) + (t % DAY ? " " + hm(t) : "") : hm(t)}</text>`);
      }
    }
    // sumbu waktu
    const step = Math.max(1, Math.ceil(nExp / (large ? 8 : 5)));
    for (let i = 0; i < nExp; i += step) { const t = it.t0 + i * lowMs;
      g.push(`<text x="${X(i)}" y="${H - 16}" fill="#5b6576" font-size="${10 * fs}" text-anchor="middle">${spanMs > 2 * DAY ? dstr(t).slice(5) + (t % DAY ? " " + hm(t) : "") : hm(t)}</text>`); }
    // judul panel
    const st = d.stats;
    g.push(`${showNum ? `<circle cx="20" cy="18" r="10" fill="${GOLD}"/><text x="20" y="22" fill="#111" font-size="11" text-anchor="middle" font-weight="800">${num}</text>` : ""}`
      + `<text x="${showNum ? 36 : 14}" y="22" fill="${TXT}" font-size="${13 * fs}" font-weight="700">${esc(it.label)}</text>`
      + `<text x="${W - 14}" y="22" fill="${MUT}" font-size="${11 * fs}" text-anchor="end">range ${pct(st.range_pct, 2)} · ${st.change_pct >= 0 ? "naik" : "turun"} ${pct(Math.abs(st.change_pct), 2)}${d.done ? "" : " · masih terbentuk"}</text>`);
    return `<svg viewBox="0 0 ${W} ${H}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="${FONT}">${g.join("")}</svg>`;
  }

  function panelInfo(d, p) {
    if (!d.big) return "";
    if (p < 1) return `<div class="cs-info"><span class="cs-small">⏳ tunggu candle selesai terbentuk… (tebak dulu: high atau low duluan?)</span></div>`;
    const end = true, st = d.stats, hFirst = d.i_high < d.i_low, b = d.bars;
    const kind = st.body_pct <= 15 ? "doji" : st.body_pct >= 70 ? (st.change_pct >= 0 ? "marubozu naik" : "marubozu turun")
      : st.upper_pct >= 50 ? "sumbu atas panjang" : st.lower_pct >= 50 ? "sumbu bawah panjang" : st.change_pct >= 0 ? "candle naik" : "candle turun";
    const tf2 = (ms) => (d.it.t1 - d.it.t0 > 2 * DAY ? (ms % DAY ? `${dstr(ms).slice(5)} ${hm(ms)}` : dstr(ms).slice(5)) : hm(ms));
    const order = d.first === "sama" ? "high & low di candle yang sama"
      : `${hFirst ? "HIGH" : "LOW"} dulu (${tf2(b[hFirst ? d.i_high : d.i_low].time * 1000)}) → ${hFirst ? "LOW" : "HIGH"} (${tf2(b[hFirst ? d.i_low : d.i_high].time * 1000)})`;
    const seg = (w, c, t) => `<span style="flex:${Math.max(w, 0.0001)};background:${c}" title="${t}"></span>`;
    return `<div class="cs-info ${end ? "on" : ""}">
      <span class="cs-pill ${hFirst ? "dn" : "up"}">${order}</span>
      <span class="cs-pill">${kind}</span>
      <span class="cs-anat" title="sumbu atas · badan · sumbu bawah">${seg(st.upper_pct, "#5b6576", "sumbu atas")}${seg(st.body_pct, st.change_pct >= 0 ? UP : DN, "badan")}${seg(st.lower_pct, "#5b6576", "sumbu bawah")}</span>
      <span class="cs-small">atas ${st.upper_pct.toFixed(0)}% · badan ${st.body_pct.toFixed(0)}% · bawah ${st.lower_pct.toFixed(0)}%</span></div>`;
  }

  async function downloadPng(v) {
    const n = v.data.length, cols = n === 1 ? 1 : n === 2 || n === 4 ? 2 : 3, large = n === 1;
    const pw = large ? 1040 : 440, ph = large ? 430 : 320, gap = 12, head = 44;
    const rows = Math.ceil(n / cols), W = cols * pw + (cols + 1) * gap, H = head + rows * (ph + gap) + gap;
    let inner = "";
    v.data.forEach((d, i) => {
      const x = gap + (i % cols) * (pw + gap), y = head + Math.floor(i / cols) * (ph + gap);
      inner += panelSvg(d, 1, large, i + 1, n > 1, true).replace("<svg ", `<svg x="${x}" y="${y}" width="${pw}" height="${ph}" `).replace(' width="100%"', "");
    });
    const sym = S.info ? S.info.symbol : "";
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" font-family="${FONT}">
      <rect width="${W}" height="${H}" fill="#0b0f14"/><text x="${gap + 4}" y="29" fill="${GOLD}" font-size="17" font-weight="800">🔬 Struktur candle · ${esc(sym)} · isi di TF ${tfName(v.low)}</text>
      <text x="${W - gap - 4}" y="29" fill="${MUT}" font-size="12" text-anchor="end">① ② = urutan high / low · Cryptodant</text>${inner}</svg>`;
    const url = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml;charset=utf-8" }));
    try {
      const img = new Image();
      await new Promise((ok, no) => { img.onload = ok; img.onerror = no; img.src = url; });
      const cv = document.createElement("canvas"); cv.width = W * 2; cv.height = H * 2;
      const ctx = cv.getContext("2d"); ctx.scale(2, 2); ctx.drawImage(img, 0, 0);
      const blob = await new Promise((ok) => cv.toBlob(ok, "image/png"));
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
      a.download = `${sym}_struktur_${dstr(v.items[0].t0)}_${v.low}.png`;
      a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    } finally { URL.revokeObjectURL(url); }
  }

  window.CStruct = { renderMarks, openViewer, openOnChart, mkItem, state: CS };
})();
