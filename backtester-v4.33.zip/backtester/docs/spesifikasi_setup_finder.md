# Spesifikasi lengkap: Pencari Setup Terbaik (Whale + Backtest)

Dokumen ini adalah blueprint untuk membangun ulang fitur **🎯 Cari setup terbaik** dari nol.
Nilai **Default** = nilai yang sekarang dipakai di `backend/whales.py` (v3.44).
Kolom **Rentang** = batas yang masih masuk akal kalau mau dijadikan setelan.

Prinsip: analisa teknikal saja (WR & RR), tanpa uang / ukuran posisi. Semua angka probabilitas berasal
dari backtest candle; data whale (order book) **tidak bisa di-backtest** dan hanya dipakai untuk menaruh level.

---

## 1. Alur besar

```
INPUT: daftar RR, arah (BUY/SELL/keduanya), jumlah koin / daftar koin, Min. WR, Min. nilai tembok, jumlah ditampilkan
1. Universe koin  : USDT perpetual status TRADING, urut volume 24 jam
2. Per koin (paralel 3 thread, dengan pengganti kalau gagal):
   2.1 Ambil data live (ticker, order book, transaksi, candle)
   2.2 Deteksi tembok whale, tembok asli/palsu
   2.3 Swing, gocekan (wick backtest), angka bulat, zona
   2.4 Regime pasar (Bullish/Bearish/Sideways) & alarm lonjakan
   2.5 SL anti-gocekan per arah
   2.6 Kandidat entry per arah
   2.7 Per RR: TP, backtest WR, peluang tersentuh, rata-rata R, skor -> kandidat terbaik
3. Gabung semua koin: filter Min. WR, urut skor, ambil N teratas, tabel perbandingan RR
OUTPUT: tabel setup + perbandingan RR + status (koin di-scan, dilewati, gagal)
```

---

## 2. Universe koin

| Parameter | Default | Rentang | Keterangan |
|---|---|---|---|
| Jenis kontrak | USDT perpetual, status TRADING | – | dari `/fapi/v1/exchangeInfo` |
| Urutan | volume 24 jam (quoteVolume) terbesar | – | dari `/fapi/v1/ticker/24hr` |
| Jumlah koin | 20 | 1 – semua | "semua" = seluruh USDT perpetual |
| Daftar manual | – | – | `btc, eth, sol` → otomatis + `USDT` |
| Koin gagal | diganti koin berikutnya | – | supaya minta N = N koin ter-scan |
| Paralel | 3 thread | 2 – 5 | lebih banyak = cepat kena rate limit |

## 3. Batas permintaan Binance (wajib)

| Parameter | Default | Keterangan |
|---|---|---|
| Batas weight | 2400 / menit (aturan Binance) | header `X-MBX-USED-WEIGHT-1M` |
| Rem otomatis | > 2000 → tunggu menit berikutnya | sisakan cadangan |
| HTTP 418 / 429 | tunggu `Retry-After`, ulang | maks 4 percobaan |
| Gagal jaringan | ulang 4× (jeda 1, 2, 3 dtk) | |
| Perkiraan kecepatan | ±25–30 koin / menit | ±70–80 weight per koin |

Permintaan per koin: ticker (1), depth 500 (10), aggTrades ×1–2 (20 per permintaan), klines 15M ×1000 (5),
klines 1H ×300 + 1D ×30 (regime), klines 1M ×61 (alarm), klines backtest ×1500 (10). Cache per koin supaya
data TF yang sama tidak diambil dua kali.

---

## 4. Tembok whale (order book)

| Parameter | Default | Rentang | Keterangan |
|---|---|---|---|
| Kedalaman order book | 500 level (scan), 1000 (1 koin) | 100 – 1000 | |
| Min. nilai tembok | 50 000 USDT (scan) / 100 000 (pelacak) | 10 rb – 5 jt | bisa diketik |
| Rentang "kekuatan" | ±2% dari harga | 1 – 5% | porsi tembok vs total antrean |
| Dampak (impact) | simulasi market order sebesar tembok menyapu sisi lawan | – | % gerak harga |
| Tembok dipakai | 10 dengan dampak terbesar | 5 – 20 | |
| Jarak maks tembok untuk entry / SL | 3% | 1 – 5% | |
| Tembok "asli" | terlihat ≥ 2 scan berturut-turut | 2 – 5 | |
| Toleransi posisi tembok | 0.05% | 0.02 – 0.1% | dianggap tembok yang sama |
| Toleransi nilai | ≥ 50% nilai sebelumnya | 30 – 80% | |
| Tembok palsu (spoof) | hilang saat harga mendekat (sisa < 30%) | – | |

## 5. Transaksi besar (aggTrades)

| Parameter | Default | Keterangan |
|---|---|---|
| Jumlah transaksi dibaca | 1000 – 2000 terakhir | |
| Min. nilai transaksi | sama dengan Min. nilai tembok | |
| Ukuran relatif | nilai ÷ volume rata-rata per menit (× vol/menit) | |
| Tekanan whale | (BELI − JUAL) ÷ (BELI + JUAL) × 100 | −100 … +100 |

## 6. Swing, gocekan, zona

| Parameter | Default | Rentang | Keterangan |
|---|---|---|---|
| TF | 15M, 1000 candle | – | |
| ATR | 14 | 10 – 20 | ATR15m; ATR H1 ≈ 2 × ATR15m kalau tidak ada |
| Swing (fractal) | 3 candle kiri & kanan | 2 – 5 | baru dipakai setelah terkonfirmasi |
| Swing terdekat dicari di | 200 candle terakhir | 100 – 400 | maks 3 swing per sisi |
| Lookahead sapuan | 96 candle (1 hari) | 48 – 192 | |
| Definisi gocekan | ditembus ekor lalu close balik ≤ 4 candle | 2 – 6 | selain itu = tembus beneran |
| Kedalaman gocekan | **p90** (ATR) | p80 – p95 | 90% gocekan tidak sedalam ini; default 1.0 ATR kalau tak ada data |
| Angka bulat | langkah sesuai harga, jarak ≤ 2% | 1 – 3% | |
| Lebar zona swing | swing ± p90 × ATR | | |
| Lebar zona angka bulat | ± 0.5 × p90 × ATR | | |
| Zona tipis | antrean < 25% median, rentang ±5% | 15 – 35% | harga bisa loncat |

## 7. Regime pasar (label searah / melawan tren)

| Faktor | Bobot | Rumus |
|---|---|---|
| Tren H1 | 45% | rata-rata tanda (harga−EMA20, EMA20−EMA50, EMA50−EMA200) × 100 |
| Tekanan transaksi whale | 30% | lihat bagian 5 |
| Order book ±2% | 25% | (bid − ask) ÷ (bid + ask) × 100 |
| Porsi sideways | – | clip(100 × (1 − ADX/40), 10, 85); ADX H1 14 |

`bull = (100 − side) × (0.5 + skor/200)`, `bear = 100 − side − bull`; regime = yang terbesar.
Data: 300 candle H1 + 30 candle D1. Minimal 60 candle H1, kalau kurang regime = tidak ada.

## 8. Alarm lonjakan

| Parameter | Default | Keterangan |
|---|---|---|
| Data | 61 candle 1M | |
| Basis volume | median volume 56 menit sebelumnya | |
| WASPADA | volume 5 menit ≥ 3× basis ATAU gerak ≥ 2 × ATR1m | |
| BAHAYA | puncak volume ≥ 5× basis DAN gerak ≥ 3 × ATR1m | |

---

## 9. SL anti-gocekan

Kandidat (ambil yang **paling jauh** dari harga):

| Kandidat | Rumus (BUY; SELL kebalikannya) |
|---|---|
| Swing | swing low terdekat − (p90 + 0.1) × ATR15m |
| Tembok | tembok BELI terbesar (≤ 3%, utamakan yang asli) − 0.25 × ATR H1 |
| Cadangan | harga − 1.5 × ATR H1 (kalau tidak ada swing / tembok) |

Penyesuaian:

| Aturan | Default | Keterangan |
|---|---|---|
| Lewati angka bulat | geser ke angka bulat − (0.5 × p90 + 0.1) × ATR | kalau SL jatuh di zona angka bulat |
| Batas jarak SL | 4% dari harga | **catatan:** batas ini bisa menaruh SL kembali di zona gocekan. Di Cek entry dipakai SL tanpa batas (`raw`). Disarankan: tolak setup kalau SL harus dipotong, jangan dipotong diam-diam |

## 10. Kandidat entry (per arah)

| Kandidat | Rumus (BUY; SELL kebalikannya) | Jenis |
|---|---|---|
| Market | harga sekarang | market |
| Depan tembok | tembok BELI terbesar (≤ 3%) + 0.1 × ATR15m | limit |
| Depan swing | swing low terdekat + 0.15 × ATR15m | limit |

Syarat valid: `SL < entry ≤ harga` (BUY) / `harga ≤ entry < SL` (SELL), risiko > 0.

## 11. TP

`TP = entry ± RR × |entry − SL|`. RR diisi user (boleh beberapa sekaligus, maks 6, rentang 0.5 – 10).

## 12. Backtest WR (inti angka peluang)

| Parameter | Default | Rentang | Keterangan |
|---|---|---|---|
| Pemilihan TF | SL < 1.5% → 15M; SL ≥ 1.5% → 1H | 1 – 2% | |
| Jumlah candle | 1500 (15M ≈ 15 hari, 1H ≈ 62 hari) | 1000 – 1500 per permintaan | lebih panjang = beberapa permintaan |
| Batas waktu per trade | 15M: 192 candle (2 hari); 1H: 120 candle (5 hari) | | |
| Entry uji | close **setiap** candle, jarak SL% & TP% sama | | |
| Filter tren | hanya candle dengan EMA20 vs EMA50 (TF backtest) sama seperti sekarang | | |
| Sampel minimal | 30 trade; kalau kurang, pakai semua candle | 30 – 100 | |
| TP & SL di candle yang sama | dihitung **kalah** | | konservatif |
| Tidak kena apa-apa sampai batas waktu | dihitung **tidak menang** | | jangan dibuang (WR jadi palsu) |
| Candle tanpa masa depan penuh | tidak dipakai | | hindari hasil yang belum diketahui |
| WR curiga | > 85% → tanda ⚠️ | 80 – 90% | biasanya data satu arah |

## 13. Peluang entry tersentuh (limit)

| Parameter | Default | Keterangan |
|---|---|---|
| Data | candle 15M ×1000 | |
| Jendela | 96 candle (24 jam) | |
| Entry ≤ 0.02% dari harga | dianggap 100% (market) | |

## 14. Skor & urutan

| Rumus | |
|---|---|
| Rata-rata R | `WR × RR − (1 − WR)` |
| WR impas | `100 ÷ (1 + RR)` (RR 1:2 → 33%, 1:3 → 25%) |
| Skor | `rata-rata R × peluang tersentuh ÷ 100` |
| Per koin | 1 kandidat skor tertinggi per (arah, RR) |
| Tampil | WR ≥ Min. WR, urut skor, ambil N teratas (default 10) |
| "Rata-rata untung" | rata-rata R > 0 |
| RR terbaik per koin (🏆) | skor tertinggi di antara RR yang diuji |

## 15. Label di tabel (tidak mengubah skor)

searah / melawan tren (bagian 7) · tembok lawan terbesar di antara entry dan TP · alarm (bagian 8) · ⚠️ WR > 85%
· median waktu sampai TP (jam) · TF backtest & jumlah trade.

---

## 16. Cek entry & saran (fitur pendamping)

| Parameter | Default | Keterangan |
|---|---|---|
| Status posisi | wajib dipilih user (berjalan / belum kena entry) | tidak ditebak otomatis |
| Arah | wajib dipilih user (BUY / SELL) | |
| Penyesuaian whale & gocekan | 0.6 × jumlah poin cek, dibatasi ±12 poin | peluang akhir dibatasi 3 – 97% |
| Min. RR saran | 1:2 | user bisa ubah |
| Syarat saran tampil | WR saran ≥ WR user **dan** rata-rata R > punya user + 0.02 | kalau tidak ada: "setup kamu sudah yang terbaik" |
| Saran masih rugi | tampil peringatan merah | |

---

## 17. Contoh file konfigurasi

> Di aplikasi ini semua angka di atas sudah bisa diubah dari tab **Whale → ⚙️ Threshold** dan disimpan di
> `saved/whale_config.json` (hanya angka yang beda dari default). Daftar kunci lengkap: `backend/whale_cfg.py`.
> Contoh struktur lain di bawah untuk kalau kamu membangun software sendiri:

```json
{
  "universe": {"coins": 20, "threads": 3},
  "rate_limit": {"brake_weight": 2000, "retries": 4},
  "walls": {"min_usdt": 50000, "depth": 500, "max_dist_pct": 3, "real_seen": 2, "tol_pct": 0.05, "top": 10},
  "swing": {"tf": "15m", "candles": 1000, "fractal": 3, "lookback": 200, "atr": 14},
  "gocek": {"lookahead": 96, "reclaim_bars": 4, "depth_pct": 90},
  "round_number": {"max_dist_pct": 2},
  "sl": {"swing_buf_atr": 0.1, "wall_buf_atr1h": 0.25, "fallback_atr1h": 1.5, "round_buf": 0.1, "max_pct": 4, "cap_mode": "reject"},
  "entry": {"wall_buf_atr": 0.1, "swing_buf_atr": 0.15},
  "rr": [1, 1.5, 2, 3],
  "backtest": {"sl_tf_switch_pct": 1.5, "candles": 1500, "max_bars_15m": 192, "max_bars_1h": 120,
               "trend_filter": "ema20_vs_ema50", "min_trades": 30, "same_candle": "loss", "timeout": "not_win",
               "suspicious_wr": 85},
  "fill": {"window_15m": 96, "market_tol_pct": 0.02},
  "rank": {"min_wr": 0, "show": 10},
  "regime": {"w_trend": 0.45, "w_trades": 0.30, "w_book": 0.25, "adx_full": 40, "side_clip": [10, 85]},
  "alarm": {"warn_vol": 3, "warn_move_atr": 2, "danger_peak": 5, "danger_move_atr": 3}
}
```

## 18. Cara menguji software-nya

1. **Server Binance palsu** (data candle, depth, aggTrades yang bisa diatur) supaya tes tidak tergantung internet.
2. Tes wajib:
   - WR tidak 100% palsu: trade yang tidak selesai dihitung tidak menang.
   - RR kecil → WR tidak lebih rendah dari RR besar (SL sama, TP lebih dekat).
   - Min. WR benar-benar menyaring; minta N koin = N koin ter-scan (koin gagal diganti).
   - SL BUY selalu di bawah entry, TP di atas (kebalikannya untuk SELL).
   - Saran tidak pernah lebih jelek dari setup user.
   - Tidak ada lookahead: hasil candle ke-i hanya memakai candle sesudah i untuk menilai, bukan untuk memilih.
3. **Validasi keluar-sampel** (disarankan, belum ada): pilih setup dengan data lama, cek hasilnya di data sesudahnya.
   Kalau WR keluar-sampel jauh di bawah WR backtest, threshold-nya terlalu dipaskan ke masa lalu.

## 19. Batasan yang harus diterima

- WR = sifat pergerakan koin untuk jarak SL/TP itu, bukan bukti momen sekarang spesial.
- Order book tidak punya riwayat → tembok tidak ikut backtest; tembok bisa ditarik kapan saja.
- Data 15–62 hari bisa kebetulan satu arah.
- Belum memperhitungkan fee / slippage: rata-rata R yang sangat tipis (< ±0.1–0.2 R) belum tentu untung di trading asli.
