import numpy as np

from backend.data import TF_MS
from backend.indicators import EMAStream, adx, atr, bos_bias, pivots, sma
from backend.strategy import Strategy


class BreakoutSNR(Strategy):
    """Breakout S/R searah trend besar.
    1. Trend besar (trend_tf, default D1): market structure = arah BOS terakhir (swing fractal),
       divalidasi EMA 50: LONG hanya kalau struktur bullish DAN close trend_tf di atas EMA 50
       (SHORT kebalikannya), dan ADX trend_tf >= 25 (adx_min, 0 = mati).
    2. S/R di TF entry (tf, default H1) = swing high / swing low terakhir yang sudah terkonfirmasi.
    3. Breakout: candle tf close menembus S/R itu (candle pertama yang close di luar level),
       opsional volume >= vol_mult x MA volume (vol_mult 0 = mati).
    4. Entry (parameter entry): limit_level = limit order di level S/R yang ter-breakout (retest, batal setelah
       expire_bars candle), market = langsung, atau limit_close / limit_pct / limit_atr dari close breakout.
    5. SL = sl_atr x ATR dari harga entry, TP = rr x risiko."""

    timeframe = "1h"
    param_help = {
        "trend_tf": "TF untuk membaca arah trend (bukan TF entry)",
        "tf": "TF entry: tempat mencari breakout S/R",
        "trend_swing": "Market structure trend_tf: ukuran swing (fractal N candle kiri & kanan)",
        "trend_ema": "Validasi trend: long hanya kalau close trend_tf di atas EMA ini (short di bawah)",
        "adx_min": "ADX trend_tf minimal agar boleh entry (0 = tanpa filter)",
        "sr_swing": "S/R di TF entry = swing high/low terakhir (fractal N candle)",
        "entry": "limit_level = limit di level S/R yang ditembus (retest); market = langsung; lainnya lihat daftar",
    }
    params = {
        "trend_tf": "1d",
        "tf": "1h",
        "trend_swing": 3,        # fractal untuk market structure trend_tf
        "trend_ema": 50,         # validasi: close trend_tf di atas/bawah EMA ini
        "adx_len": 14,
        "adx_min": 25,           # ADX trend_tf minimal (0 = tanpa filter ADX)
        "sr_swing": 3,           # fractal untuk swing high/low (S/R) di tf
        "vol_ma": 20,
        "vol_mult": 1.5,         # 0 = tanpa filter volume
        "entry": "limit_level",  # limit_level = limit di level S/R yang ditembus (retest), market = langsung
        "limit_offset_pct": 0.2, "limit_atr": 0.5, "expire_bars": 12,
        "atr_len": 14,
        "sl_atr": 1.0,
        "rr": 2.0,
        "risk_usdt": 0.5,
        "risk_pct": 1.0,
        "long": True,
        "short": True,
    }

    def on_start(self, ctx):
        self.trend_t, self.trend = None, 0
        self.ema = EMAStream(self.p.trend_ema)

    def update_trend(self, ctx):
        p = self.p
        d = ctx.closed(p.trend_tf, 400 if self.ema.value is None else 5)
        e = self.ema.update(d)
        d = ctx.closed(p.trend_tf, 300)
        self.trend = 0
        if e is None or len(d) < 4 * p.trend_swing + 2:
            return
        bias = bos_bias(d.h, d.l, d.c, p.trend_swing)
        if p.adx_min > 0:
            a = adx(d.h, d.l, d.c, p.adx_len)[-1]
            if not (np.isfinite(a) and a >= p.adx_min):
                return
        if bias > 0 and d.c[-1] > e:
            self.trend = 1
        elif bias < 0 and d.c[-1] < e:
            self.trend = -1

    def on_bar(self, ctx):
        p = self.p
        t = ctx.now // TF_MS[p.trend_tf]
        if t != self.trend_t:                      # dihitung ulang tiap candle trend_tf baru
            self.trend_t = t
            self.update_trend(ctx)
        if self.trend == 0 or not ctx.position.flat or ctx.open_orders():
            return
        b = ctx.closed(p.tf, 200)
        if len(b) < max(p.vol_ma, p.atr_len) + 2 * p.sr_swing + 2:
            return
        hi, lo = pivots(b.h, b.l, p.sr_swing)
        c = b.c[-1]
        if self.trend > 0 and p.long and len(hi):
            lvl = b.h[hi[-1]]                          # resistance terakhir
            if not (c > lvl >= b.c[-2]):
                return
            side = "buy"
        elif self.trend < 0 and p.short and len(lo):
            lvl = b.l[lo[-1]]                          # support terakhir
            if not (c < lvl <= b.c[-2]):
                return
            side = "sell"
        else:
            return
        if p.vol_mult > 0:
            va = sma(b.v[:-1], p.vol_ma)[-1]
            if not (va > 0 and b.v[-1] >= p.vol_mult * va):
                return
        a = atr(b.h, b.l, b.c, p.atr_len)[-1]
        entry, kind = ctx.limit_price(side, c, p, level=lvl)
        d = 1 if side == "buy" else -1
        sl = entry - d * p.sl_atr * a                 # SL = ATR dari harga entry sebenarnya
        tp = entry + d * p.rr * p.sl_atr * a
        ctx.trade(side, entry, sl, tp, p.risk_usdt, p.risk_pct, kind, p.expire_bars if kind == "limit" else None)
