from backend.data import TF_MS
from backend.strategy import Strategy


class CRT(Strategy):
    """Candle Range Theory. Candle HTF sebelumnya = range (CRT high/low). Candle HTF berikutnya menyapu
    low range (wick di bawahnya) lalu close kembali di dalam range -> setup LONG ke CRT high
    (kebalikannya untuk SHORT). Entry langsung di candle berikutnya, atau (kalau confirm_tf diisi)
    tunggu konfirmasi break struktur di TF kecil selama 1 candle HTF. SL di ujung sapuan, TP di sisi lain range.
    Entry: market, atau limit di CRT Low/High (level yang disapu) / di 50% range."""

    timeframe = "4h"
    param_help = {
        "htf": "TF candle range (CRT High/Low)",
        "confirm_tf": "TF konfirmasi break struktur sebelum entry (kosong = tanpa konfirmasi)",
        "mss_lookback": "Konfirmasi: close tembus high/low N candle confirm_tf sebelumnya",
        "entry": "limit_level = limit di CRT Low (long) / CRT High (short); limit_mid = di 50% range; market = langsung; limit_close/pct/atr = dari close konfirmasi",
        "expire_bars": "Limit order batal kalau tidak tersentuh dalam N candle (TF konfirmasi, atau htf kalau tanpa konfirmasi)",
        "sl_buffer_pct": "SL = ujung sapuan ± N%",
        "tp_mode": "range = TP di sisi seberang range (CRT High untuk long); rr = TP = rr x risiko",
        "min_rr": "Setup dilewati kalau RR ke target kurang dari ini",
    }
    params = {
        "htf": "4h",            # TF candle range
        "confirm_tf": "",       # "" = entry langsung; isi mis. "15m" / "5m" untuk konfirmasi break struktur
        "mss_lookback": 5,      # konfirmasi: close tembus high/low N candle confirm_tf terakhir
        "entry": "limit_level", # limit_level = CRT Low/High, limit_mid = 50% range, market, limit_close/pct/atr
        "limit_offset_pct": 0.2, "limit_atr": 0.5,
        "expire_bars": 3,       # limit batal setelah N candle (TF on_bar)
        "sl_buffer_pct": 0.05,
        "tp_mode": "range",     # "range" = TP di sisi lain range, "rr" = TP = rr x risiko
        "rr": 2.0, "min_rr": 1.0,   # setup dilewati kalau RR ke target < min_rr
        "risk_usdt": 0.5, "risk_pct": 1.0,
        "long": True, "short": True,
    }

    def __init__(self, **kw):
        super().__init__(**kw)
        self.timeframe = self.p.confirm_tf or self.p.htf

    def on_start(self, ctx):
        self.setup = None

    def on_bar(self, ctx):
        p = self.p
        if ctx.now % TF_MS[p.htf] == 0:          # candle HTF baru saja close
            self.setup = None
            hb = ctx.closed(p.htf, 3)
            if len(hb) >= 2:
                rh, rl, l, h, c = hb.h[-2], hb.l[-2], hb.l[-1], hb.h[-1], hb.c[-1]
                if p.long and l < rl < c < rh:
                    self.setup = ("buy", l, rh, rl, (rh + rl) / 2, ctx.now + TF_MS[p.htf])
                elif p.short and h > rh > c > rl:
                    self.setup = ("sell", h, rl, rh, (rh + rl) / 2, ctx.now + TF_MS[p.htf])
        if not self.setup or not ctx.position.flat or ctx.open_orders():
            return
        side, sweep, target, level, mid, expire = self.setup
        if ctx.now > expire:
            self.setup = None
            return
        b = ctx.closed(self.timeframe, p.mss_lookback + 2)
        c = b.c[-1]
        if p.confirm_tf:   # konfirmasi: break struktur kecil searah setup
            if side == "buy" and not c > b.h[-p.mss_lookback - 1:-1].max():
                return
            if side == "sell" and not c < b.l[-p.mss_lookback - 1:-1].min():
                return
        buf = p.sl_buffer_pct / 100
        d = 1 if side == "buy" else -1
        sl = sweep * (1 - d * buf)
        entry, kind = ctx.limit_price(side, c, p, level=level, mid=mid, sl=sl)
        tp = target if p.tp_mode == "range" else entry + d * p.rr * abs(entry - sl)
        risk = abs(entry - sl)
        if d * (tp - entry) > 0 and abs(tp - entry) >= p.min_rr * risk:
            ctx.trade(side, entry, sl, tp, p.risk_usdt, p.risk_pct, kind, p.expire_bars if kind == "limit" else None)
        self.setup = None


class CRTDaily(CRT):
    """CRT dengan range candle D1, konfirmasi di H1."""
    params = {**CRT.params, "htf": "1d", "confirm_tf": "1h", "expire_bars": 24}


class CRTScalp(CRT):
    """CRT scalping: range candle H1, konfirmasi break struktur di M5."""
    params = {**CRT.params, "htf": "1h", "confirm_tf": "5m", "mss_lookback": 5, "expire_bars": 12}
