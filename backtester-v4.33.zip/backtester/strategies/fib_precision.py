import numpy as np

from backend.data import TF_MS
from backend.fibstudy import regime_at
from backend.indicators import atr, pivots
from backend.mining import tf_series
from backend.strategy import Strategy


class FibPrecision(Strategy):
    """FibPrecision: limit entry di level Fibonacci yang paling presisi (hasil tab Studi Fibonacci).
    1. Gelombang di TF `tf`: swing low -> swing high (naik) atau swing high -> swing low (turun), fractal `swing`,
       panjang minimal min_leg_atr x ATR14. Fibonacci ditarik dari ujung gelombang (0) ke anchor (1.0) saat swing
       ujungnya terkonfirmasi.
    2. Kondisi pasar di `regime_tf`: Bullish = BOS terakhir naik + close di atas EMA50 + ADX >= adx_min,
       Bearish = kebalikannya, selain itu Sideways.
    3. Level limit dipilih per kondisi pasar x arah gelombang (lvl_bull_up = BUY di koreksi gelombang naik saat
       bullish, lvl_bear_down = SELL di koreksi gelombang turun saat bearish, dst.). 0 = tidak trade di kondisi itu.
       Limit hanya dipasang kalau level belum tersentuh saat Fibonacci digambar.
    4. SL = di level fibo sl_level (default 1.0) + sl_buffer_atr x ATR. TP = level `target` (0 = high/low gelombang, -0.272 / -0.618
       = extension).
    5. Limit batal kalau candle close tembus 0 (harga lanjut tanpa koreksi), close tembus 1.0 (BOS), atau lewat
       max_bars candle. Sama persis dengan aturan di Studi Fibonacci."""

    timeframe = "15m"
    param_help = {
        "tf": "TF fibo & entry",
        "regime_tf": "TF untuk menentukan kondisi pasar (Bullish / Bearish / Sideways)",
        "swing": "Fractal swing N candle kiri & kanan",
        "min_leg_atr": "Jarak swing low-high minimal N x ATR14 (filter swing kecil)",
        "adx_min": "ADX regime_tf minimal untuk dianggap tren (di bawah ini = Sideways)",
        "lvl_bull_up": "Bullish, koreksi searah tren: level BUY limit (0 = tidak trade)",
        "lvl_bull_down": "Bullish, koreksi melawan tren: level SELL limit (0 = tidak trade, disarankan 0)",
        "lvl_bear_up": "Bearish, koreksi melawan tren: level BUY limit (0 = tidak trade, disarankan 0)",
        "lvl_bear_down": "Bearish, koreksi searah tren: level SELL limit (0 = tidak trade)",
        "lvl_side_up": "Sideways: level BUY limit (0 = tidak trade)",
        "lvl_side_down": "Sideways: level SELL limit (0 = tidak trade)",
        "target": "TP: 0 = high/low terakhir (BUY: high, SELL: low), -0.272 / -0.618 = extension",
        **{f"tp_{k}": f"TP khusus {n} (kosong = pakai target)" for k, n in (("bull_up", "Bullish searah tren"),
           ("bear_down", "Bearish searah tren"), ("side_up", "Sideways BUY"), ("side_down", "Sideways SELL"),
           ("bull_down", "Bullish melawan tren"), ("bear_up", "Bearish melawan tren"))},
        **{f"sl_{k}": f"SL khusus {n} di angka fibo (0 = pakai sl_level)" for k, n in (("bull_up", "Bullish searah tren"),
           ("bear_down", "Bearish searah tren"), ("side_up", "Sideways BUY"), ("side_down", "Sideways SELL"),
           ("bull_down", "Bullish melawan tren"), ("bear_up", "Bearish melawan tren"))},
        "sl_level": "SL di angka fibo: 1.0 = tepat di swing awal, 1.13 / 1.272 = lebih longgar, 0.886 = lebih ketat (lihat 'SL terbaik / aman' di Studi Fibonacci)",
        "sl_buffer_atr": "SL = level sl_level -/+ N x ATR14 (0 = tepat di angka fibo)",
        "max_bars": "Limit batal setelah N candle sejak Fibonacci digambar",
    }
    params = {
        "tf": "15m", "regime_tf": "4h", "swing": 3, "min_leg_atr": 2.0, "adx_min": 20,
        "lvl_bull_up": 0.618, "lvl_bull_down": 0.0, "lvl_bear_up": 0.0, "lvl_bear_down": 0.618,
        "lvl_side_up": 0.0, "lvl_side_down": 0.0,
        "target": "0", "sl_level": 1.0, "sl_buffer_atr": 0.1, "max_bars": 300,
        "tp_bull_up": "", "tp_bear_down": "", "tp_side_up": "", "tp_side_down": "", "tp_bull_down": "", "tp_bear_up": "",
        "sl_bull_up": 0.0, "sl_bear_down": 0.0, "sl_side_up": 0.0, "sl_side_down": 0.0, "sl_bull_down": 0.0, "sl_bear_up": 0.0,
        "risk_usdt": 0.5, "risk_pct": 1.0,
    }
    param_choices = {**Strategy.param_choices, "target": ["0.5", "0.382", "0.236", "0", "-0.272", "-0.414", "-0.618"],
                     **{f"tp_{k}": ["", "0.5", "0.382", "0.236", "0", "-0.272", "-0.414", "-0.618"] for k in ("bull_up", "bull_down", "bear_up", "bear_down", "side_up", "side_down")}}

    def on_start(self, ctx):
        self.leg = None      # gelombang yang limit-nya sedang menunggu

    def level_for(self, reg, d):
        key = {1: "bull", -1: "bear", 0: "side"}[reg] + ("_up" if d > 0 else "_down")
        return float(getattr(self.p, "lvl_" + key, 0) or 0), key

    def on_bar(self, ctx):
        p = self.p
        b = ctx.closed(p.tf, 300)
        n = len(b)
        if n < 60:
            return
        c = b.c[-1]
        # kelola limit yang menunggu: batal kalau gelombang selesai (close tembus 0 / 1.0) atau kadaluarsa
        if self.leg and ctx.open_orders() and ctx.position.flat:
            lg = self.leg
            lg["age"] += 1
            if lg["d"] * (c - lg["p0"]) > 0 or lg["d"] * (lg["p100"] - c) > 0 or lg["age"] >= p.max_bars:
                ctx.cancel_all()
                self.leg = None
        if not ctx.position.flat:
            return
        j = n - 1 - p.swing                                 # swing yang baru terkonfirmasi di candle ini
        hi, lo = pivots(b.h, b.l, p.swing)
        for d, ends, anchors in ((1, hi, lo), (-1, lo, hi)):
            if not len(ends) or ends[-1] != j:
                continue
            k = np.searchsorted(anchors, j) - 1
            if k < 0:
                continue
            i = anchors[k]
            if d > 0 and b.h[j] < b.h[i:j + 1].max() or d < 0 and b.l[j] > b.l[i:j + 1].min():
                continue
            a = atr(b.h, b.l, b.c, 14)[j]
            top, bot = (b.h[j], b.l[i]) if d > 0 else (b.h[i], b.l[j])
            rng = top - bot
            if not np.isfinite(a) or rng <= 0 or rng < p.min_leg_atr * a:
                continue
            rb = ctx.closed(p.regime_tf, 600)
            reg = regime_at(tf_series(rb), len(rb) - 1, p.adx_min) if len(rb) else None
            if reg is None:
                continue
            x, key = self.level_for(reg, d)
            if x <= 0:
                continue
            p0 = top if d > 0 else bot
            lvl = lambda f: p0 - d * f * rng   # noqa: E731
            px = lvl(x)
            after = b.l[j + 1:] if d > 0 else b.h[j + 1:]
            if (after.min() <= px if d > 0 else after.max() >= px) or d * (c - px) <= 0:
                continue                                    # level sudah tersentuh sebelum Fibonacci digambar
            sl_lv = float(getattr(p, "sl_" + key, 0) or 0) or float(p.sl_level)   # SL khusus kondisi ini, atau umum
            sl_lv = max(sl_lv, x + 0.01)                          # SL harus di luar harga entry
            sl = lvl(sl_lv) - d * p.sl_buffer_atr * a
            tp = lvl(float(getattr(p, "tp_" + key, "") or p.target))   # TP khusus kondisi ini, atau umum
            if ctx.open_orders():
                ctx.cancel_all()                            # gelombang baru menggantikan limit lama
            side = "buy" if d > 0 else "sell"
            if ctx.trade(side, px, sl, tp, p.risk_usdt, p.risk_pct, "limit", None, f"{key} {x:g}"):
                self.leg = {"d": d, "p0": p0, "p100": lvl(1.0), "age": 0}
            return
