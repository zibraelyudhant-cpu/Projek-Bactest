import numpy as np

from backend.data import TF_MS
from backend.indicators import EMAStream, atr, fvg, pivots, sma
from backend.strategy import Strategy


class BreakoutFibo(Strategy):
    """Breakout + Fibonacci (H1 arah, M5 entry).
    1. H1: close di atas EMA 50 & EMA 200 = bullish, di bawah keduanya = bearish (selain itu tidak trade).
    2. M5: breakout S/R searah H1 = candle close menembus swing high terakhir (bullish) / swing low terakhir (bearish)
       dengan volume >= vol_mult x MA20 volume.
    3. Tunggu swing high baru (bullish) / swing low baru (bearish) terbentuk setelah breakout, lalu tarik fibo dari
       swing low -> swing high (0 = high, 1 = low; bearish kebalikannya). Breakout batal kalau close balik melewati
       level yang ditembus atau swing baru tidak muncul dalam max_wait_bars.
    4. Entry LIMIT di zona zone_top..zone_bottom (0.382-0.618). entry_at = confluence: pakai FVG (belum terisi) atau
       S/R yang ditembus (sekarang jadi support/resistance) kalau ada di zona, kalau tidak ada pakai entry_fib.
       entry_at = fib: selalu di entry_fib.
    5. SL = sl_atr x ATR M5 dari entry. TP1 = RR tp1_rr. TP2 = fibo tp2_level (angka negatif = lewat ujung swing,
       mis. -0.272 = '1.272' kalau fibo ditarik terbalik). tp_mode: tp1 / tp2 / split (50:50).
    Tombol 'Cari angka fibo terbaik' menguji semua kombinasi angka entry x TP untuk setup yang sama."""

    timeframe = "5m"
    fib_grid = True           # punya tombol 'Cari angka fibo terbaik'
    param_help = {
        "trend_tf": "TF arah (H1)", "tf": "TF entry / breakout (M5)",
        "ema_fast": "EMA cepat di trend_tf", "ema_slow": "EMA lambat di trend_tf",
        "sr_swing": "S/R = swing high / low terakhir (fractal N kiri & kanan) di TF entry",
        "vol_ma": "Periode rata-rata volume", "vol_mult": "Volume candle breakout minimal N x rata-rata (0 = mati)",
        "swing": "Swing baru setelah breakout (fractal N kiri & kanan)",
        "max_wait_bars": "Batas candle menunggu swing baru setelah breakout",
        "zone_top": "Batas zona retest yang dangkal (0.382)", "zone_bottom": "Batas zona retest yang dalam (0.618)",
        "entry_at": "confluence = FVG / S/R yang ditembus di zona (kalau tidak ada: entry_fib); fib = selalu di entry_fib",
        "entry_fib": "Angka fibo entry limit (0.5, 0.618, ...)",
        "use_fvg": "Hitung FVG sebagai konfluensi", "use_snr": "Hitung S/R yang ditembus (S/R flip) sebagai konfluensi",
        "sl_atr": "SL = N x ATR TF entry dari harga entry",
        "tp_mode": "tp1 = semua di TP1 | tp2 = semua di TP2 | split = 50% TP1, 50% TP2",
        "tp1_rr": "TP1 = RR ini (1:2)", "tp2_level": "TP2 = angka fibo (0 = ujung swing, -0.13 .. -0.618 = lewat ujung swing)",
        "expire_bars": "Limit batal kalau tidak tersentuh dalam N candle",
        "sell_same": "SELL pakai entry_fib & tp2_level yang sama dengan BUY (matikan untuk angka SELL sendiri)",
        "entry_fib_sell": "Angka fibo entry limit khusus SELL (dipakai kalau sell_same mati)",
        "tp2_level_sell": "TP2 fibo khusus SELL (dipakai kalau sell_same mati)",
    }
    params = {
        "trend_tf": "1h", "tf": "5m", "ema_fast": 50, "ema_slow": 200,
        "sr_swing": 3, "vol_ma": 20, "vol_mult": 1.6, "swing": 3, "max_wait_bars": 48,
        "zone_top": 0.382, "zone_bottom": 0.618, "entry_at": "confluence", "entry_fib": 0.5,
        "use_fvg": True, "use_snr": True,
        "sl_atr": 2.0, "tp_mode": "tp1", "tp1_rr": 2.0, "tp2_level": -0.272, "expire_bars": 48,
        "sell_same": True, "entry_fib_sell": 0.5, "tp2_level_sell": -0.272,
        "risk_usdt": 0.5, "risk_pct": 1.0, "long": True, "short": True,
    }
    param_choices = {**Strategy.param_choices, "tp_mode": ["tp1", "tp2", "split"], "entry_at": ["confluence", "fib"]}

    def on_start(self, ctx):
        p = self.p
        self.ef, self.es = EMAStream(p.ema_fast), EMAStream(p.ema_slow)
        self.h_t, self.bias = None, 0
        self.pend = None          # breakout yang menunggu swing baru
        self.used = set()
        self.setups = []          # semua setup fibo (untuk 'Cari angka fibo terbaik')

    def update_bias(self, ctx):
        p = self.p
        first = self.ef.value is None
        hb = ctx.closed(p.trend_tf, 1000 if first else 5)
        f, s = self.ef.update(hb), self.es.update(hb)
        self.bias = 0
        if f is None or not len(hb):
            return
        c = hb.c[-1]
        self.bias = 1 if c > f and c > s else -1 if c < f and c < s else 0

    def on_bar(self, ctx):
        p = self.p
        t = ctx.now // TF_MS[p.trend_tf]
        if t != self.h_t:
            self.h_t = t
            self.update_bias(ctx)
        b = ctx.closed(p.tf, 300)
        n = len(b)
        if n < max(p.vol_ma, 20) + 4 * p.sr_swing + 5:
            return
        h, l, c, v = b.h, b.l, b.c, b.v
        if self.pend:
            self.track(ctx, b)
            return
        if self.bias == 0 or not ctx.position.flat or ctx.open_orders():
            return
        d = self.bias
        if (d > 0 and not p.long) or (d < 0 and not p.short):
            return
        hi, lo = pivots(h, l, p.sr_swing)
        piv = hi if d > 0 else lo
        if not len(piv):
            return
        q = piv[-1]
        lvl = h[q] if d > 0 else l[q]
        if not (d * (c[-1] - lvl) > 0 and d * (c[-2] - lvl) <= 0):
            return
        if p.vol_mult > 0:
            va = sma(v[:-1], p.vol_ma)[-1]
            if not (va > 0 and v[-1] >= p.vol_mult * va):
                return
        key = (int(b.t[q]), d)
        if key in self.used:
            return
        self.used.add(key)
        # titik awal impuls: low terendah (bullish) sejak swing S/R yang ditembus
        a_idx = q + int(np.argmin(l[q:]) if d > 0 else np.argmax(h[q:]))
        self.pend = {"d": d, "lvl": lvl, "t_brk": int(b.t[-1]), "t_a": int(b.t[a_idx]), "age": 0}

    def track(self, ctx, b):
        p = self.p
        pd = self.pend
        d = pd["d"]
        h, l, c, t = b.h, b.l, b.c, b.t
        n = len(c)
        pd["age"] += 1
        if d * (c[-1] - pd["lvl"]) < 0 or pd["age"] > p.max_wait_bars:   # breakout gagal / swing tidak muncul
            self.pend = None
            return
        i_brk = int(np.searchsorted(t, pd["t_brk"]))
        j = n - 1 - p.swing                                  # swing yang baru terkonfirmasi di candle ini
        if j <= i_brk:
            return
        hi, lo = pivots(h, l, p.swing)
        piv = hi if d > 0 else lo
        if not len(piv) or piv[-1] != j:
            return
        i_a = max(0, int(np.searchsorted(t, pd["t_a"])))
        if d > 0:
            B, A = h[j], l[i_a:j + 1].min()
            if B < h[i_brk:j + 1].max():
                return
        else:
            B, A = l[j], h[i_a:j + 1].max()
            if B > l[i_brk:j + 1].min():
                return
        self.pend = None
        rng = abs(B - A)
        if rng <= 0:
            return
        lv = lambda x: B - d * x * rng                       # noqa: E731  harga angka fibo x (0 = B, 1 = A)
        ztop, zbot = lv(p.zone_top), lv(p.zone_bottom)
        zlo, zhi = min(ztop, zbot), max(ztop, zbot)
        a = atr(b.h, b.l, b.c, 14)[-1]
        if not np.isfinite(a) or a <= 0:
            return
        # konfluensi di zona: S/R yang ditembus (sekarang jadi support/resistance) dan FVG yang belum terisi
        conf = []
        if p.use_snr and zlo <= pd["lvl"] <= zhi:
            conf.append(pd["lvl"])
        if p.use_fvg:
            for k in fvg(h, l, d > 0):
                if k < i_brk - 2 or k > j:
                    continue
                g_lo, g_hi = (h[k - 2], l[k]) if d > 0 else (h[k], l[k - 2])
                after = l[k + 1:] if d > 0 else h[k + 1:]
                if len(after) and (after.min() < g_lo if d > 0 else after.max() > g_hi):
                    continue                                 # FVG sudah terisi penuh
                if g_hi >= zlo and g_lo <= zhi:
                    conf.append(min(g_hi, zhi) if d > 0 else max(g_lo, zlo))
        conf_px = (max(conf) if d > 0 else min(conf)) if conf else None
        self.setups.append({"t": int(ctx.now), "d": d, "A": float(A), "B": float(B), "atr": float(a),
                            "conf": None if conf_px is None else float(conf_px)})
        if not ctx.position.flat or ctx.open_orders():
            return
        own = d < 0 and not p.sell_same
        e_fib = p.entry_fib_sell if own else p.entry_fib
        t_fib = p.tp2_level_sell if own else p.tp2_level
        entry = conf_px if (p.entry_at == "confluence" and conf_px is not None) else lv(e_fib)
        if d * (c[-1] - entry) <= 0:
            return                                           # harga sudah di bawah entry: bukan retest lagi
        side = "buy" if d > 0 else "sell"
        sl = entry - d * p.sl_atr * a
        tp1 = entry + d * p.tp1_rr * abs(entry - sl)
        tp2 = lv(t_fib)
        if p.tp_mode == "split" and d * (tp2 - entry) > 0:
            ctx.trade(side, entry, sl, tp1, p.risk_usdt / 2, p.risk_pct / 2, "limit", p.expire_bars, "tp1")
            ctx.trade(side, entry, sl, tp2, p.risk_usdt / 2, p.risk_pct / 2, "limit", p.expire_bars, "tp2")
        else:
            tp = tp2 if p.tp_mode == "tp2" and d * (tp2 - entry) > 0 else tp1
            ctx.trade(side, entry, sl, tp, p.risk_usdt, p.risk_pct, "limit", p.expire_bars)
