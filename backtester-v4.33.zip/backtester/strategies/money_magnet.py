import numpy as np

from backend.data import TF_MS
from backend.indicators import atr, pivots
from backend.strategy import Strategy


class MoneyMagnetScalping(Strategy):
    """Money Magnet Scalping (H1 -> M5 CRT). Entry LIMIT di CE (50% FVG).
    1. Bias H1 (candle H1 tertutup terakhir): posisi harga di range candle itu, < 50% = discount, >= 50% = premium.
       Range / ATR14 H1: < 0.70 skip, 0.70-1.50 valid (+1 poin), 1.50-2.00 hati-hati (0 poin), > 2.00 skip.
    2. Liquidity M5 (28 candle terakhir): swing fractal 2-2, maksimal 3 swing terbaru per sisi, minimal 2 swing high
       dan 2 swing low. ATR M5 = RMA 14 dari 35 candle tertutup.
    3. Sweep dalam 14 candle terakhir menembus swing low (long) / swing high (short) minimal 0.10 x ATR.
       Reclaim (close kembali ke dalam) maks 8 candle sejak sweep, lalu displacement maks 5 candle setelah reclaim;
       atau continuation: displacement maks 10 candle setelah sweep tanpa reclaim.
       Displacement: body >= 0.8 x ATR, body/range >= 60%, membentuk FVG >= 0.10 x ATR.
       CE (50% FVG) harus di sisi yang benar dari ekstrem sweep.
    4. Skor maks 16: setup lengkap +11, searah posisi H1 (long di discount / short di premium) +2,
       range H1 valid +1, RR ke target >= 3.5 +2 (3.0-3.5 +1). Minimal min_score (12), A+ mulai 14.
    5. Entry LIMIT di CE. SL = ekstrem sweep -/+ 0.15 x ATR; dilewati kalau jarak entry-SL < 0.8 x ATR.
       TP1 = RR 2. TP2 = swing liquidity berlawanan dengan RR >= 3, kalau tidak ada RR 3.
       tp_mode: tp1 / tp2 / split (50% di TP1, 50% di TP2). Entry maks 2% dari harga (BUY di bawah harga).
       Limit batal setelah expire_bars candle M5 (36 = ~3 jam; 288 = 24 jam seperti evaluator Jurnal).
    6. Filter korelasi BTC (M15, 20 candle): BTC bergerak < ±0.15% = ranging (tanpa efek); korelasi >= 0.75 dan BTC
       berlawanan arah = sinyal diblokir; 0.50-0.75 berlawanan = tetap entry (tag 'btc-warn'); < 0.50 tanpa efek."""

    timeframe = "5m"
    param_help = {
        "htf": "TF bias (candle tertutup terakhir) — default H1",
        "tf": "TF eksekusi / liquidity — default M5",
        "htf_bars": "Jumlah candle H1 yang diambil (untuk ATR14 H1); minimal 20",
        "tf_bars": "Jumlah candle M5 yang diambil; minimal 30",
        "range_min": "Range candle H1 / ATR14 H1 di bawah ini = skip",
        "range_valid_max": "Range/ATR sampai nilai ini = valid (+1 poin)",
        "range_max": "Range/ATR di atas ini = skip (antara valid_max dan ini = hati-hati, 0 poin)",
        "liq_window": "Jendela liquidity M5 (candle)",
        "swing": "Fractal swing N-N (2 = 2 candle kiri & kanan)",
        "max_swings": "Maksimal swing terbaru per sisi yang dipakai",
        "min_swings": "Minimal jumlah swing high DAN swing low di jendela liquidity",
        "atr_bars": "ATR M5 dihitung dari N candle tertutup terakhir (RMA 14)",
        "sweep_window": "Sweep harus terjadi dalam N candle terakhir",
        "sweep_min_atr": "Penetrasi sweep minimal N x ATR M5",
        "reclaim_window": "Reclaim (close kembali ke dalam level) maks N candle sejak sweep",
        "disp_window": "Displacement maks N candle setelah reclaim",
        "cont_window": "Continuation (tanpa reclaim): displacement maks N candle setelah sweep",
        "disp_body_atr": "Body candle displacement minimal N x ATR M5",
        "body_ratio": "Body / range candle displacement minimal (0.6 = 60%)",
        "fvg_min_atr": "Ukuran FVG minimal N x ATR M5",
        "min_score": "Skor minimal untuk entry (maks 16)",
        "aplus_score": "Skor mulai dianggap A+ (hanya label)",
        "sl_buffer_atr": "SL = ekstrem sweep -/+ N x ATR M5",
        "min_sl_atr": "Jarak entry-SL minimal N x ATR M5, kalau kurang sinyal dilewati",
        "tp1_rr": "TP1 = RR ini",
        "tp2_min_rr": "TP2 = swing liquidity berlawanan dengan RR minimal ini; kalau tidak ada = RR ini",
        "tp_mode": "tp1 = semua di TP1 | tp2 = semua di TP2 | split = 50% di TP1, 50% di TP2",
        "max_entry_dist_pct": "Jarak harga entry ke harga sekarang maksimal (%)",
        "expire_bars": "Limit batal setelah N candle M5 (36 = ~3 jam, 288 = 24 jam)",
        "btc_filter": "Pakai filter korelasi BTC",
        "btc_symbol": "Simbol acuan (butuh data lokalnya; kalau tidak ada, filter dilewati)",
        "btc_tf": "TF korelasi BTC",
        "btc_bars": "Jumlah candle untuk korelasi & gerak BTC",
        "btc_flat_pct": "BTC bergerak kurang dari ±N% = ranging, tanpa efek",
        "corr_block": "Korelasi >= ini dan BTC berlawanan arah = sinyal diblokir",
        "corr_warn": "Korelasi antara ini dan corr_block, BTC berlawanan = tetap entry dengan peringatan",
        "entry": "limit_level = limit di CE (50% FVG); market = langsung; lainnya lihat daftar",
    }
    params = {
        "htf": "1h", "tf": "5m", "htf_bars": 72, "tf_bars": 36,
        "range_min": 0.70, "range_valid_max": 1.50, "range_max": 2.00,
        "liq_window": 28, "swing": 2, "max_swings": 3, "min_swings": 2, "atr_bars": 35,
        "sweep_window": 14, "sweep_min_atr": 0.10, "reclaim_window": 8, "disp_window": 5, "cont_window": 10,
        "disp_body_atr": 0.8, "body_ratio": 0.6, "fvg_min_atr": 0.10,
        "min_score": 12, "aplus_score": 14,
        "sl_buffer_atr": 0.15, "min_sl_atr": 0.8, "tp1_rr": 2.0, "tp2_min_rr": 3.0, "tp_mode": "tp1",
        "max_entry_dist_pct": 2.0,
        "entry": "limit_level", "limit_offset_pct": 0.2, "limit_atr": 0.5, "expire_bars": 36,
        "btc_filter": True, "btc_symbol": "BTCUSDT", "btc_tf": "15m", "btc_bars": 20, "btc_flat_pct": 0.15,
        "corr_block": 0.75, "corr_warn": 0.50,
        "risk_usdt": 0.5, "risk_pct": 1.0, "long": True, "short": True,
    }
    param_choices = {**Strategy.param_choices, "tp_mode": ["tp1", "tp2", "split"]}
    atr_tf = {"range_min": ["htf"], "range_valid_max": ["htf"], "range_max": ["htf"]}   # Range/ATR14 dari candle H1

    def on_start(self, ctx):
        self.used = set()     # sweep yang sudah dievaluasi (satu sinyal per sweep)
        self.h1_key, self.h1 = None, None

    # ------------------------------------------------------------ fase 1: bias H1
    def h1_info(self, ctx):
        p = self.p
        key = ctx.now // TF_MS[p.htf]
        if key != self.h1_key:
            self.h1_key = key
            hb = ctx.closed(p.htf, p.htf_bars)
            self.h1 = None
            if len(hb) >= 20:
                a = atr(hb.h, hb.l, hb.c, 14)[-1]
                rng = hb.h[-1] - hb.l[-1]
                if np.isfinite(a) and a > 0 and rng > 0:
                    self.h1 = (hb.h[-1], hb.l[-1], rng / a)
        return self.h1

    # ------------------------------------------------------------ fase 2-3: liquidity, sweep, displacement
    def find_setup(self, b, a, d):
        """Cari setup terbaru arah d (+1 long / -1 short). Return dict atau None. 'pending' = belum lengkap."""
        p = self.p
        n = len(b)
        h, l, o, c = b.h, b.l, b.o, b.c
        off = n - p.liq_window
        hi, lo = pivots(h[off:], l[off:], p.swing)
        hi, lo = hi[-p.max_swings:] + off, lo[-p.max_swings:] + off
        if len(hi) < p.min_swings or len(lo) < p.min_swings:
            return None
        levels = lo if d > 0 else hi
        for k in range(n - 1, n - 1 - p.sweep_window, -1):            # sweep terbaru dulu
            if k < 1:
                break
            conf = [j for j in levels if j + p.swing < k]               # swing sudah terkonfirmasi sebelum sweep
            swept = [j for j in conf if (l[k] <= l[j] - p.sweep_min_atr * a if d > 0 else h[k] >= h[j] + p.sweep_min_atr * a)]
            if not swept:
                continue
            j = min(swept, key=lambda j: l[j]) if d > 0 else max(swept, key=lambda j: h[j])   # liquidity terdalam
            lvl = l[j] if d > 0 else h[j]
            key = (int(b.t[k]), d)
            if key in self.used:
                return None
            # reclaim: close kembali ke dalam level
            r = next((i for i in range(k, min(n, k + p.reclaim_window + 1)) if d * (c[i] - lvl) > 0), None)
            last = min(n - 2, max(k + p.cont_window, r + p.disp_window if r is not None else -1))
            disp = None
            for i in range(k + 1 if r is None else min(k + 1, r), last + 1):
                in_win = (r is not None and r <= i <= r + p.disp_window) or (k < i <= k + p.cont_window)
                if not in_win or i < 1:
                    continue
                body, rngc = d * (c[i] - o[i]), h[i] - l[i]
                if body < p.disp_body_atr * a or rngc <= 0 or body / rngc < p.body_ratio:
                    continue
                gap = (l[i + 1] - h[i - 1]) if d > 0 else (l[i - 1] - h[i + 1])
                if gap < p.fvg_min_atr * a:
                    continue
                disp = i
                break
            if disp is None:
                # jendela sudah lewat -> sweep ini selesai; kalau belum, tunggu candle berikutnya
                deadline = max(k + p.cont_window, r + p.disp_window if r is not None else 0)
                if n - 2 >= deadline:
                    self.used.add(key)
                return None
            i = disp
            fvg_lo, fvg_hi = (h[i - 1], l[i + 1]) if d > 0 else (h[i + 1], l[i - 1])
            ce = (fvg_lo + fvg_hi) / 2
            ext = l[k:i + 2].min() if d > 0 else h[k:i + 2].max()
            self.used.add(key)
            if d * (ce - ext) <= 0:                                      # CE harus di sisi benar dari ekstrem sweep
                return None
            return {"k": k, "level": lvl, "disp": i, "ce": ce, "ext": ext, "reclaim": r is not None,
                    "opp": (h[hi] if d > 0 else l[lo])}
        return None

    # ------------------------------------------------------------ filter BTC
    def btc_check(self, ctx, d):
        p = self.p
        if not p.btc_filter:
            return "ok"
        bt = ctx.closed_symbol(p.btc_symbol, p.btc_tf, p.btc_bars)
        me = ctx.closed(p.btc_tf, p.btc_bars)
        if bt is None or len(bt) < p.btc_bars or len(me) < p.btc_bars or bt.t[-1] != me.t[-1]:
            return "ok"
        move = (bt.c[-1] / bt.c[0] - 1) * 100
        if abs(move) < p.btc_flat_pct:
            return "ok"
        r1, r2 = np.diff(np.log(bt.c)), np.diff(np.log(me.c))
        if r1.std() == 0 or r2.std() == 0:
            return "ok"
        corr = float(np.corrcoef(r1, r2)[0, 1])
        if np.sign(move) == -d:
            if corr >= p.corr_block:
                return "block"
            if corr >= p.corr_warn:
                return "warn"
        return "ok"

    # ------------------------------------------------------------ utama
    def on_bar(self, ctx):
        p = self.p
        if not ctx.position.flat or ctx.open_orders():
            return
        b = ctx.closed(p.tf, max(p.tf_bars, p.atr_bars, p.liq_window))
        if len(b) < 30 or len(b) < p.liq_window:
            return
        a = atr(b.h[-p.atr_bars:], b.l[-p.atr_bars:], b.c[-p.atr_bars:], 14)[-1]
        if not (np.isfinite(a) and a > 0):
            return
        h1 = self.h1_info(ctx)
        if h1 is None:
            return
        h1_hi, h1_lo, ratio = h1
        if ratio < p.range_min or ratio > p.range_max:
            return
        price = b.c[-1]
        pos = (price - h1_lo) / (h1_hi - h1_lo)
        for d in (1, -1):
            if (d > 0 and not p.long) or (d < 0 and not p.short):
                continue
            s = self.find_setup(b, a, d)
            if s is None:
                continue
            entry_ref = s["ce"]
            sl = s["ext"] - d * p.sl_buffer_atr * a
            side = "buy" if d > 0 else "sell"
            entry, kind = ctx.limit_price(side, price, p, level=entry_ref, mid=entry_ref, sl=sl)
            R = d * (entry - sl)
            if R < p.min_sl_atr * a:
                continue
            if kind == "limit" and (d * (price - entry) <= 0 or abs(price - entry) / price * 100 > p.max_entry_dist_pct):
                continue
            tp1 = entry + d * p.tp1_rr * R
            opp = [x for x in s["opp"] if d * (x - entry) / R >= p.tp2_min_rr]
            tp2 = (min(opp) if d > 0 else max(opp)) if opp else entry + d * p.tp2_min_rr * R
            rr_t = d * (tp2 - entry) / R
            score = 11 + (2 if (d > 0 and pos < 0.5) or (d < 0 and pos >= 0.5) else 0) \
                + (1 if p.range_min <= ratio <= p.range_valid_max else 0) \
                + (2 if rr_t >= 3.5 else 1 if rr_t >= 3.0 else 0)
            if score < p.min_score:
                continue
            btc = self.btc_check(ctx, d)
            if btc == "block":
                continue
            tag = ("A+" if score >= p.aplus_score else "A") + (" reclaim" if s["reclaim"] else " continuation") + \
                (" btc-warn" if btc == "warn" else "")
            exp = p.expire_bars if kind == "limit" else None
            if p.tp_mode == "split":
                ctx.trade(side, entry, sl, tp1, p.risk_usdt / 2, p.risk_pct / 2, kind, exp, tag)
                ctx.trade(side, entry, sl, tp2, p.risk_usdt / 2, p.risk_pct / 2, kind, exp, tag)
            else:
                ctx.trade(side, entry, sl, tp2 if p.tp_mode == "tp2" else tp1, p.risk_usdt, p.risk_pct, kind, exp, tag)
            return
