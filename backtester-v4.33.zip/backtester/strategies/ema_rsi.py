from backend.indicators import EMAStream, atr, rsi
from backend.strategy import Strategy


class EmaRsi(Strategy):
    """EMA cross (fast memotong slow) + filter RSI + filter tren EMA 200. Entry market di candle berikutnya.
    SL = sl_atr x ATR dari harga entry, TP = rr x risiko. Entry bisa market atau limit (limit_level = di EMA fast)."""

    timeframe = "1h"
    params = {
        "tf": "1h",
        "fast": 9, "slow": 21,
        "rsi_len": 14, "rsi_long": 55, "rsi_short": 45,   # long hanya kalau RSI >= 55, short kalau <= 45
        "trend_ema": 200,                                 # long hanya di atas EMA ini (0 = tanpa filter)
        "atr_len": 14, "sl_atr": 1.5,
        "entry": "market",   # limit_level = limit di EMA fast
        "limit_offset_pct": 0.2, "limit_atr": 0.5, "expire_bars": 6,
        "rr": 2.0, "risk_usdt": 0.5, "risk_pct": 1.0,
        "long": True, "short": True,
    }

    def __init__(self, **kw):
        super().__init__(**kw)
        self.timeframe = self.p.tf

    def on_start(self, ctx):
        p = self.p
        self.fast, self.slow = EMAStream(p.fast), EMAStream(p.slow)
        self.trend = EMAStream(p.trend_ema) if p.trend_ema else None

    def on_bar(self, ctx):
        p = self.p
        first = self.fast.value is None
        b = ctx.closed(p.tf, 1000 if first else max(p.rsi_len, p.atr_len) * 10)
        f, s = self.fast.update(b), self.slow.update(b)
        tr = self.trend.update(b) if self.trend else None
        if self.fast.prev is None or len(b) < p.rsi_len * 3 or not ctx.position.flat or ctx.open_orders():
            return
        c = b.c[-1]
        cross_up = self.fast.prev <= self.slow.prev and f > s
        cross_dn = self.fast.prev >= self.slow.prev and f < s
        if not (cross_up or cross_dn):
            return
        r = rsi(b.c, p.rsi_len)[-1]          # dihitung hanya saat ada cross (lebih cepat)
        a = atr(b.h, b.l, b.c, p.atr_len)[-1]
        side = "buy" if cross_up and p.long and r >= p.rsi_long and (tr is None or c > tr) else \
            "sell" if cross_dn and p.short and r <= p.rsi_short and (tr is None or c < tr) else None
        if side:
            d = 1 if side == "buy" else -1
            entry, kind = ctx.limit_price(side, c, p, level=f)
            sl = entry - d * p.sl_atr * a               # SL = sl_atr x ATR dari harga entry sebenarnya
            ctx.trade(side, entry, sl, entry + d * p.rr * p.sl_atr * a, p.risk_usdt, p.risk_pct, kind,
                      p.expire_bars if kind == "limit" else None)


class EmaRsiScalp(EmaRsi):
    """Preset scalping EMA + RSI di M5 (EMA 9/21, RSI 14, tren EMA 200 M5)."""
    params = {**EmaRsi.params, "tf": "5m", "sl_atr": 1.2, "rr": 1.5}
