import numpy as np

from backend.data import TF_MS
from backend.indicators import adx, sma
from backend.strategy import Strategy


class BreakoutD1H1(Strategy):
    """Breakout S/R H1 searah trend D1 (TF bisa diganti lewat trend_tf & tf).
    D1 hanya untuk ARAH TREND: close D1 di atas high 20 hari = trend naik, di bawah low 20 hari = trend turun
    (metode Donchian), plus ADX D1 >= 25. ENTRY di H1: candle H1 close menembus S/R (high/low 48 candle H1
    sebelumnya) searah trend D1, volume >= 1.5x MA20. SL di swing low/high H1, TP = rr x risiko. Satu posisi sekaligus."""

    timeframe = "1h"   # on_bar dipanggil setiap candle H1 close
    param_help = {
        "trend_tf": "TF untuk membaca arah trend (bukan TF entry)",
        "tf": "TF entry: tempat mencari breakout S/R",
        "trend_donchian": "Arah trend: close trend_tf tembus high N candle = naik, tembus low N candle = turun",
        "adx_min": "ADX trend_tf minimal agar boleh entry (0 = tanpa filter)",
        "sr_lookback": "S/R di TF entry = high/low tertinggi N candle sebelumnya",
        "sl_lookback": "SL di low/high terendah N candle TF entry terakhir",
        "sl_buffer_pct": "Jarak tambahan SL dari swing (%)",
    }
    params = {
        "trend_tf": "1d",      # TF arah besar
        "tf": "1h",            # TF entry
        "trend_donchian": 20,  # ARAH TREND (bukan entry): close trend_tf tembus high/low N candle -> trend naik/turun
        "adx_len": 14,
        "adx_min": 25,         # ADX D1 minimal
        "sr_lookback": 48,     # H1: S/R = high/low tertinggi N candle sebelumnya
        "vol_ma": 20,
        "vol_mult": 1.5,       # volume candle breakout >= 1.5 x MA20 volume
        "sl_lookback": 10,     # SL di low/high terendah N candle H1 terakhir
        "sl_buffer_pct": 0.1,  # jarak tambahan SL (%)
        "entry": "market",   # limit_level = limit di level S/R yang ditembus
        "limit_offset_pct": 0.2, "limit_atr": 0.5, "expire_bars": 12,
        "rr": 2.0,
        "risk_usdt": 0.5,      # rugi kalau kena SL (USDT). Isi 0 untuk pakai risk_pct
        "risk_pct": 1.0,       # dipakai kalau risk_usdt = 0: % equity per trade
        "long": True,
        "short": True,
    }

    def on_start(self, ctx):
        self.day = None
        self.bias = 0
        self.adx_ok = False

    def update_daily(self, ctx):
        """Dihitung ulang sekali per hari, hanya dari candle D1 yang sudah close."""
        p = self.p
        d = ctx.closed(p.trend_tf, 400)
        self.bias, self.adx_ok = 0, False
        n = p.trend_donchian
        if len(d) <= n + 2 * p.adx_len:
            return
        bias = 0
        for i in range(n, len(d)):   # status arah: berganti hanya saat breakout berlawanan
            if d.c[i] > d.h[i - n:i].max():
                bias = 1
            elif d.c[i] < d.l[i - n:i].min():
                bias = -1
        self.bias = bias
        a = adx(d.h, d.l, d.c, p.adx_len)[-1]
        self.adx_ok = bool(np.isfinite(a) and a >= p.adx_min)

    def on_bar(self, ctx):
        p = self.p
        day = ctx.now // TF_MS[p.trend_tf]
        if day != self.day:
            self.day = day
            self.update_daily(ctx)
        if not self.adx_ok or self.bias == 0 or not ctx.position.flat or ctx.open_orders():
            return

        h1 = ctx.closed(p.tf, max(p.sr_lookback, p.vol_ma, p.sl_lookback) + 2)
        if len(h1) < p.sr_lookback + 1:
            return
        c, v = h1.c[-1], h1.v[-1]
        vol_avg = sma(h1.v[:-1], p.vol_ma)[-1]            # MA20 volume sebelum candle breakout
        if not (vol_avg > 0 and v >= p.vol_mult * vol_avg):
            return
        res = h1.h[-p.sr_lookback - 1:-1].max()            # S/R dari candle sebelumnya
        sup = h1.l[-p.sr_lookback - 1:-1].min()
        buf = 1 + p.sl_buffer_pct / 100

        if self.bias > 0 and p.long and c > res:
            sl = h1.l[-p.sl_lookback:].min() / buf
            if sl < c:
                ctx.enter("buy", c, sl, p, rr=p.rr, level=res)
        elif self.bias < 0 and p.short and c < sup:
            sl = h1.h[-p.sl_lookback:].max() * buf
            if sl > c:
                ctx.enter("sell", c, sl, p, rr=p.rr, level=sup)
