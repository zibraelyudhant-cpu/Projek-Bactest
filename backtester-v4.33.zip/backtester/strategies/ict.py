import numpy as np

from backend.data import TF_MS
from backend.indicators import EMAStream, fvg, pivots
from backend.strategy import Strategy


class ICT(Strategy):
    """ICT (versi mekanis: liquidity sweep -> MSS -> FVG), hanya di killzone:
    1. Likuiditas = swing low terakhir (long) yang terbentuk sebelum jendela sweep.
    2. Sweep: dalam sweep_window candle terakhir, harga menembus di bawah level itu.
    3. Market Structure Shift: candle close di atas swing high terakhir sebelum sweep (displacement).
    4. Entry limit di FVG bullish yang terbentuk setelah sweep (tepi atas atau tengah FVG).
       SL di bawah low sweep, TP = rr x risiko. Order batal setelah expire_bars candle.
    Killzone dalam jam UTC: London 07-10, New York 12-15 (sesuaikan musim: NY 13-16 saat musim dingin)."""

    timeframe = "15m"
    params = {
        "tf": "15m",
        "killzones": "7-10,12-15",   # jam UTC, format "mulai-selesai" dipisah koma; "" = semua jam
        "swing": 3,
        "sweep_window": 12,          # sweep dicari di N candle terakhir
        "entry": "limit_level",      # limit_level = tepi FVG, limit_mid = tengah FVG (CE), market = langsung
        "limit_offset_pct": 0.2, "limit_atr": 0.5,
        "bias_tf": "1h", "bias_ema": 50,   # filter: long hanya di atas EMA bias_tf (0 = tanpa filter)
        "sl_buffer_pct": 0.03,
        "expire_bars": 8,
        "rr": 2.0, "risk_usdt": 0.5, "risk_pct": 1.0,
        "long": True, "short": True,
    }

    def __init__(self, **kw):
        super().__init__(**kw)
        self.timeframe = self.p.tf
        self.zones = [tuple(int(x) for x in z.split("-")) for z in self.p.killzones.split(",") if "-" in z]

    def on_start(self, ctx):
        self.ema = EMAStream(self.p.bias_ema) if self.p.bias_ema else None
        self.used = set()   # sweep yang sudah dipakai (satu entry per sweep)

    def in_killzone(self, ctx):
        if not self.zones:
            return True
        hour = (ctx.now - TF_MS[self.p.tf]) // 3_600_000 % 24   # jam candle yang baru close
        return any(a <= hour < b for a, b in self.zones)

    def on_bar(self, ctx):
        p = self.p
        bias = 0
        if self.ema:
            hb = ctx.closed(p.bias_tf, 600 if self.ema.value is None else 5)
            e = self.ema.update(hb)
            bias = 0 if e is None else (1 if hb.c[-1] > e else -1)
        if not self.in_killzone(ctx) or not ctx.position.flat or ctx.open_orders():
            return
        b = ctx.closed(p.tf, 120)
        if len(b) < 40:
            return
        hi, lo = pivots(b.h, b.l, p.swing)
        if p.long and bias >= 0:
            self.setup(ctx, b, hi, lo, 1)
        if p.short and bias <= 0 and ctx.position.flat and not ctx.open_orders():
            self.setup(ctx, b, hi, lo, -1)

    def setup(self, ctx, b, hi, lo, d):
        p, n = self.p, len(b)
        w0 = n - p.sweep_window
        liq = lo[lo < w0] if d > 0 else hi[hi < w0]           # likuiditas sebelum jendela sweep
        if not len(liq):
            return
        level = b.l[liq[-1]] if d > 0 else b.h[liq[-1]]
        win = b.l[w0:] if d > 0 else b.h[w0:]
        s = w0 + int(np.argmin(win) if d > 0 else np.argmax(win))   # candle sweep
        if (d > 0 and b.l[s] >= level) or (d < 0 and b.h[s] <= level) or s >= n - 1:
            return
        key = (int(b.t[s]), d)
        if key in self.used:
            return
        mss_src = hi[hi < s] if d > 0 else lo[lo < s]          # swing terakhir sebelum sweep
        if not len(mss_src):
            return
        mss = b.h[mss_src[-1]] if d > 0 else b.l[mss_src[-1]]
        broke = b.c[s + 1:] > mss if d > 0 else b.c[s + 1:] < mss
        if not broke.any() or not broke[-1] or (len(broke) > 1 and broke[:-1].any()):
            return                                            # MSS harus terjadi di candle yang baru close
        gaps = [i for i in fvg(b.h, b.l, d > 0) if i > s]
        if not gaps:
            return
        g = gaps[-1]
        top, bot = (b.l[g], b.h[g - 2]) if d > 0 else (b.l[g - 2], b.h[g])
        buf = p.sl_buffer_pct / 100
        if d > 0:
            sl = b.l[s] * (1 - buf)
            placed = ctx.enter("buy", b.c[-1], sl, p, rr=p.rr, level=top, mid=(top + bot) / 2)
        else:
            sl = b.h[s] * (1 + buf)
            placed = ctx.enter("sell", b.c[-1], sl, p, rr=p.rr, level=bot, mid=(top + bot) / 2)
        if placed:
            self.used.add(key)


class ICTScalp(ICT):
    """ICT scalping: M5 di killzone, filter bias EMA 50 M15."""
    params = {**ICT.params, "tf": "5m", "bias_tf": "15m", "sweep_window": 12, "expire_bars": 6}
