import numpy as np

from backend.data import TF_MS
from backend.indicators import EMAStream, adx, force_index, fvg, pivots
from backend.strategy import Strategy


class RetestPullback(Strategy):
    """Retest / Pullback ke zona Fibonacci 0.5-0.618 dengan konfluensi (H1 arah, M5 entry).
    1. H1: bullish kalau close di atas EMA 26 & EMA 60, bearish kalau di bawah keduanya; ADX > 25;
       Force Index EMA 2 H1 positif untuk long, negatif untuk short.
    2. M5: close di atas/bawah EMA 26 & 60, wajib searah H1.
    3. Struktur M5: muncul Swing High baru yang lebih tinggi dari swing high sebelumnya (long) /
       Swing Low baru yang lebih rendah (short). Fibonacci ditarik dari Swing Low ke Swing High.
    4. Zona entry = retracement 0.5-0.618. Wajib ada konfluensi di dalam zona dari 200 candle M5 terakhir:
       FVG, Order Block, S/R (swing lama), atau role reversal (resistance lama yang sudah ditembus jadi support).
       FVG/OB hanya dihitung kalau masih fresh (fresh_only).
    5. Entry limit di konfluensi terdekat di dalam zona (entry_at = "fib" untuk limit di level entry_fib).
    6. SL di bawah Swing Low acuan (- buffer), TP = Fibonacci extension 1.272 (tp_ext). Lewati kalau RR < min_rr."""

    timeframe = "5m"
    param_help = {
        "trend_tf": "TF arah utama (H1)",
        "tf": "TF entry / struktur (M5)",
        "ema_fast": "EMA cepat untuk filter tren (H1 dan M5)",
        "ema_slow": "EMA lambat untuk filter tren (H1 dan M5)",
        "adx_min": "ADX trend_tf harus di atas nilai ini (0 = mati)",
        "fi_len": "Force Index trend_tf = EMA N dari (perubahan close x volume). Long kalau > 0, short kalau < 0",
        "ltf_trend": "M5 wajib searah (close di atas/bawah EMA fast & slow M5)",
        "swing": "Swing = fractal N candle kiri & kanan di M5",
        "scan_bars": "Jumlah candle M5 yang dipindai untuk konfluensi",
        "fib_top": "Batas zona retracement yang dekat harga (0.5)",
        "fib_bottom": "Batas zona retracement yang dalam (0.618)",
        "min_confluence": "Minimal jumlah JENIS konfluensi di zona (FVG / OB / S/R / role reversal)",
        "use_fvg": "Hitung FVG sebagai konfluensi", "use_ob": "Hitung Order Block sebagai konfluensi",
        "use_sr": "Hitung S/R (swing lama) sebagai konfluensi",
        "use_rr": "Hitung role reversal (resistance jadi support / sebaliknya) sebagai konfluensi",
        "fresh_only": "FVG / OB hanya dihitung kalau masih fresh: FVG belum terisi penuh, OB belum ditembus harga",
        "entry_at": "confluence = limit di konfluensi terdekat dalam zona; fib = limit di level entry_fib",
        "entry_fib": "Level Fibonacci untuk entry_at = fib (mis. 0.5, 0.559, 0.618)",
        "entry": "limit_level = limit di harga entry_at; limit_mid = tengah zona; market = langsung; lainnya lihat daftar",
        "sl_buffer_pct": "SL = Swing Low acuan - N% (long) / Swing High + N% (short)",
        "tp_ext": "TP = Fibonacci extension (1.272 atau 1.618)",
        "min_rr": "Setup dilewati kalau RR (ke TP) kurang dari ini",
        "expire_bars": "Limit batal kalau tidak tersentuh dalam N candle M5",
    }
    params = {
        "trend_tf": "1h", "tf": "5m",
        "ema_fast": 26, "ema_slow": 60,
        "adx_len": 14, "adx_min": 25,
        "fi_len": 2,
        "ltf_trend": True,
        "swing": 3, "scan_bars": 200,
        "fib_top": 0.5, "fib_bottom": 0.618,
        "min_confluence": 1, "use_fvg": True, "use_ob": True, "use_sr": True, "use_rr": True, "fresh_only": True,
        "entry_at": "confluence", "entry_fib": 0.5,
        "entry": "limit_level", "limit_offset_pct": 0.2, "limit_atr": 0.5, "expire_bars": 24,
        "sl_buffer_pct": 0.05, "tp_ext": 1.272, "min_rr": 1.0,
        "risk_usdt": 0.5, "risk_pct": 1.0,
        "long": True, "short": True,
    }
    param_choices = {**Strategy.param_choices, "entry_at": ["confluence", "fib"]}

    def on_start(self, ctx):
        p = self.p
        self.h_fast, self.h_slow = EMAStream(p.ema_fast), EMAStream(p.ema_slow)
        self.l_fast, self.l_slow = EMAStream(p.ema_fast), EMAStream(p.ema_slow)
        self.h_t, self.bias = None, 0
        self.used = set()   # swing yang sudah dipakai (satu setup per swing baru)

    # ------------------------------------------------------------------ H1
    def update_trend(self, ctx):
        p = self.p
        first = self.h_fast.value is None
        h = ctx.closed(p.trend_tf, 600 if first else 5)
        f, s = self.h_fast.update(h), self.h_slow.update(h)
        self.bias = 0
        h = ctx.closed(p.trend_tf, 100)            # analisa 100 candle H1
        if f is None or len(h) < p.adx_len * 3:
            return
        c = h.c[-1]
        if p.adx_min > 0:
            a = adx(h.h, h.l, h.c, p.adx_len)[-1]
            if not (np.isfinite(a) and a > p.adx_min):
                return
        fi = force_index(h.c, h.v, p.fi_len)[-1]
        if c > f and c > s and fi > 0:
            self.bias = 1
        elif c < f and c < s and fi < 0:
            self.bias = -1

    # ------------------------------------------------------------------ M5
    def on_bar(self, ctx):
        p = self.p
        t = ctx.now // TF_MS[p.trend_tf]
        if t != self.h_t:
            self.h_t = t
            self.update_trend(ctx)
        first = self.l_fast.value is None
        b = ctx.closed(p.tf, 1000 if first else max(p.scan_bars, 50))
        lf, ls = self.l_fast.update(b), self.l_slow.update(b)
        if self.bias == 0 or lf is None or not ctx.position.flat or ctx.open_orders():
            return
        b = ctx.closed(p.tf, p.scan_bars)
        n = len(b)
        if n < 4 * p.swing + 10:
            return
        c = b.c[-1]
        if p.ltf_trend and not ((self.bias > 0 and c > lf and c > ls) or (self.bias < 0 and c < lf and c < ls)):
            return
        hi, lo = pivots(b.h, b.l, p.swing)
        # swing baru = swing yang BARU terkonfirmasi di candle ini (indeks n-1-swing)
        if self.bias > 0 and p.long and len(hi) >= 2 and hi[-1] == n - 1 - p.swing:
            self.setup(ctx, b, hi, lo, 1)
        elif self.bias < 0 and p.short and len(lo) >= 2 and lo[-1] == n - 1 - p.swing:
            self.setup(ctx, b, hi, lo, -1)

    def setup(self, ctx, b, hi, lo, d):
        p = self.p
        h, l, o, c = b.h, b.l, b.o, b.c
        last = c[-1]
        if d > 0:
            j, j0 = hi[-1], hi[-2]
            if not h[j] > h[j0]:                    # harus Swing High baru (lebih tinggi)
                return
            a = j0 + int(np.argmin(l[j0:j + 1]))     # Swing Low acuan = low terendah di antara dua swing high
            sw_lo, sw_hi = l[a], h[j]
        else:
            j, j0 = lo[-1], lo[-2]
            if not l[j] < l[j0]:                    # harus Swing Low baru (lebih rendah)
                return
            a = j0 + int(np.argmax(h[j0:j + 1]))
            sw_lo, sw_hi = l[j], h[a]
        key = (int(b.t[j]), d)
        if key in self.used:
            return
        rng = sw_hi - sw_lo
        if rng <= 0:
            return
        # zona 0.5-0.618: long diukur turun dari Swing High, short naik dari Swing Low
        if d > 0:
            z_near, z_far = sw_hi - p.fib_top * rng, sw_hi - p.fib_bottom * rng
            anchor, tp = sw_lo, sw_lo + p.tp_ext * rng
        else:
            z_near, z_far = sw_lo + p.fib_top * rng, sw_lo + p.fib_bottom * rng
            anchor, tp = sw_hi, sw_hi - p.tp_ext * rng
        zlo, zhi = min(z_near, z_far), max(z_near, z_far)
        if d * (last - z_far) <= 0:                  # harga sudah tembus zona: setup batal
            self.used.add(key)
            return

        cands, kinds = [], set()

        def add(kind, lo_, hi_):
            if hi_ >= zlo and lo_ <= zhi:            # tumpang tindih dengan zona
                kinds.add(kind)
                cands.append(min(hi_, zhi) if d > 0 else max(lo_, zlo))   # sisi zona yang paling dekat harga

        skip = {j, a}
        def fresh(after, lvl):   # long: belum ada low di bawah lvl sejak terbentuk (short: high di atas lvl)
            if not p.fresh_only or not len(after):
                return True
            return after.min() > lvl if d > 0 else after.max() < lvl

        if p.use_fvg:
            for i in fvg(h, l, d > 0):
                if d > 0 and fresh(l[i + 1:], h[i - 2]):        # FVG belum terisi penuh
                    add("fvg", h[i - 2], l[i])
                elif d < 0 and fresh(h[i + 1:], l[i - 2]):
                    add("fvg", h[i], l[i - 2])
        if p.use_ob:
            for i in range(len(c) - 3):
                if d > 0 and c[i] < o[i] and c[i + 1:i + 4].max() > h[i] and fresh(l[i + 1:], l[i]):
                    add("ob", l[i], h[i])                        # bearish lalu ditembus ke atas, belum ditembus balik
                elif d < 0 and c[i] > o[i] and c[i + 1:i + 4].min() < l[i] and fresh(h[i + 1:], h[i]):
                    add("ob", l[i], h[i])
        sw_hi_idx, sw_lo_idx = hi[hi < j] if d > 0 else hi, lo[lo < j] if d < 0 else lo
        if p.use_sr:
            for i in sw_hi_idx:
                if i not in skip:
                    add("sr", h[i], h[i])
            for i in sw_lo_idx:
                if i not in skip:
                    add("sr", l[i], l[i])
        if p.use_rr:                                 # role reversal: level lama yang sudah ditembus close
            levels = sw_hi_idx if d > 0 else sw_lo_idx
            for i in levels:
                lvl = h[i] if d > 0 else l[i]
                after = c[i + 1:j + 1]
                if i not in skip and len(after) and (after.max() > lvl if d > 0 else after.min() < lvl):
                    add("rr", lvl, lvl)
        if len(kinds) < p.min_confluence:
            return
        self.used.add(key)

        sl = anchor * (1 - d * p.sl_buffer_pct / 100)
        fib_px = sw_hi - p.entry_fib * rng if d > 0 else sw_lo + p.entry_fib * rng
        level = (max(cands) if d > 0 else min(cands)) if (p.entry_at == "confluence" and cands) else fib_px
        side = "buy" if d > 0 else "sell"
        entry, kind = ctx.limit_price(side, last, p, level=level, mid=(zlo + zhi) / 2, sl=sl)
        risk = abs(entry - sl)
        if risk > 0 and d * (tp - entry) > 0 and abs(tp - entry) / risk >= p.min_rr:
            ctx.trade(side, entry, sl, tp, p.risk_usdt, p.risk_pct, kind, p.expire_bars if kind == "limit" else None,
                      tag="+".join(sorted(kinds)))
