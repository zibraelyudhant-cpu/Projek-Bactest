import numpy as np

from backend.strategy import Strategy


def ema(x, n):
    a = 2 / (n + 1)
    out = np.empty_like(x)
    out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = a * x[i] + (1 - a) * out[i - 1]
    return out


class EmaCross(Strategy):
    """Contoh: EMA cross (default H1). Entry default limit 0.2% di bawah/atas close (entry = limit_pct),
    SL di swing low/high 10 bar, TP = rr x risk. Limit kadaluarsa setelah 3 bar."""

    timeframe = "1h"
    params = {"tf": "1h", "fast": 20, "slow": 50, "risk_usdt": 0.0, "risk_pct": 1.0, "rr": 2.0,
              "entry": "limit_pct", "limit_offset_pct": 0.2, "limit_atr": 0.5, "expire_bars": 3}

    def on_bar(self, ctx):
        p = self.p
        bars = ctx.closed(p.tf, p.slow * 4)
        if len(bars) < p.slow * 2:
            return
        c = bars.c
        f, s = ema(c, p.fast), ema(c, p.slow)
        up = f[-2] <= s[-2] and f[-1] > s[-1]
        down = f[-2] >= s[-2] and f[-1] < s[-1]
        if not ctx.position.flat or ctx.open_orders() or not (up or down):
            return
        if up:
            sl = bars.l[-10:].min()
            if sl < c[-1]:
                ctx.enter("buy", c[-1], sl, p, rr=p.rr)
        else:
            sl = bars.h[-10:].max()
            if sl > c[-1]:
                ctx.enter("sell", c[-1], sl, p, rr=p.rr)
