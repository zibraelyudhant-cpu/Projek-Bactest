import numpy as np

from backend.data import TF_MS
from backend.indicators import bos_bias, fvg, pivots
from backend.strategy import Strategy


class SMC(Strategy):
    """Smart Money Concepts (versi mekanis):
    1. Bias HTF = arah Break of Structure (BOS) terakhir di HTF.
    2. Di TF entry, tunggu BOS searah bias: close menembus swing high terakhir (long).
    3. Order Block = candle bearish terakhir sebelum kaki impuls yang menembus struktur
       (opsional wajib ada FVG di kaki impuls itu = displacement).
    4. Limit order di tepi OB (retest), SL di bawah OB / low kaki impuls, TP = rr x risiko.
       Order batal kalau tidak tersentuh dalam expire_bars candle."""

    timeframe = "1h"
    params = {
        "tf": "1h", "htf": "4h",
        "swing": 3,             # swing = fractal N candle kiri & kanan (TF entry)
        "htf_swing": 3,
        "ob_search": 5,         # cari candle OB maksimal N candle sebelum low kaki impuls
        "entry": "limit_level", # limit_level = tepi OB, limit_mid = tengah OB, market = langsung di close BOS
        "limit_offset_pct": 0.2, "limit_atr": 0.5,
        "require_fvg": True,
        "sl_buffer_pct": 0.05,
        "expire_bars": 12,
        "rr": 2.0, "risk_usdt": 0.5, "risk_pct": 1.0,
        "long": True, "short": True,
    }

    def __init__(self, **kw):
        super().__init__(**kw)
        self.timeframe = self.p.tf

    def on_start(self, ctx):
        self.bias, self.htf_t = 0, None

    def on_bar(self, ctx):
        p = self.p
        hb_t = ctx.now // TF_MS[p.htf]
        if hb_t != self.htf_t:                    # bias dihitung ulang tiap candle HTF baru
            self.htf_t = hb_t
            hb = ctx.closed(p.htf, 300)
            self.bias = bos_bias(hb.h, hb.l, hb.c, p.htf_swing)
        if not ctx.position.flat or ctx.open_orders():
            return
        b = ctx.closed(p.tf, 150)
        if len(b) < 30:
            return
        hi, lo = pivots(b.h, b.l, p.swing)
        if self.bias > 0 and p.long and len(hi):
            self.long_setup(ctx, b, hi[-1])
        elif self.bias < 0 and p.short and len(lo):
            self.short_setup(ctx, b, lo[-1])

    def long_setup(self, ctx, b, j):
        p = self.p
        lvl = b.h[j]
        if not (b.c[-1] > lvl and b.c[-2] <= lvl):          # BOS: candle pertama yang close di atas swing high
            return
        m = j + int(np.argmin(b.l[j:]))                       # low kaki impuls (setelah swing high)
        bear = [i for i in range(m, max(m - p.ob_search, 0) - 1, -1) if b.c[i] < b.o[i]]
        ob = bear[0] if bear else m
        if p.require_fvg and not any(i > m for i in fvg(b.h, b.l, True)):
            return
        top, bot = b.h[ob], b.l[ob]
        sl = min(bot, b.l[m]) * (1 - p.sl_buffer_pct / 100)
        ctx.enter("buy", b.c[-1], sl, p, rr=p.rr, level=top, mid=(top + bot) / 2)

    def short_setup(self, ctx, b, j):
        p = self.p
        lvl = b.l[j]
        if not (b.c[-1] < lvl and b.c[-2] >= lvl):
            return
        m = j + int(np.argmax(b.h[j:]))
        bull = [i for i in range(m, max(m - p.ob_search, 0) - 1, -1) if b.c[i] > b.o[i]]
        ob = bull[0] if bull else m
        if p.require_fvg and not any(i > m for i in fvg(b.h, b.l, False)):
            return
        top, bot = b.h[ob], b.l[ob]
        sl = max(top, b.h[m]) * (1 + p.sl_buffer_pct / 100)
        ctx.enter("sell", b.c[-1], sl, p, rr=p.rr, level=bot, mid=(top + bot) / 2)


class SMCScalp(SMC):
    """SMC scalping: bias H1, entry M5."""
    params = {**SMC.params, "tf": "5m", "htf": "1h", "expire_bars": 24, "rr": 2.0}
