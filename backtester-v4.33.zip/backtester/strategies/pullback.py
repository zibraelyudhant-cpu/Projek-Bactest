from backend.indicators import EMAStream, atr
from backend.strategy import Strategy


class Pullback(Strategy):
    """Ikut tren, masuk saat pullback. Tren: close HTF di atas EMA HTF dan EMA fast > EMA slow di TF entry.
    Pullback: dalam N candle terakhir harga menyentuh EMA fast. Konfirmasi: candle bullish yang close di atas
    EMA fast dan di atas high candle sebelumnya (kebalikannya untuk short). SL di ujung pullback - buffer ATR."""

    timeframe = "1h"
    params = {
        "tf": "1h", "htf": "4h", "htf_ema": 50,
        "ema_fast": 20, "ema_slow": 50,
        "pullback_bars": 5,      # sentuhan ke EMA fast dicari di N candle terakhir
        "atr_len": 14, "sl_atr_buffer": 0.3,
        "entry": "market",   # limit_level = limit di EMA fast
        "limit_offset_pct": 0.2, "limit_atr": 0.5, "expire_bars": 6,
        "rr": 2.0, "risk_usdt": 0.5, "risk_pct": 1.0,
        "long": True, "short": True,
    }

    def __init__(self, **kw):
        super().__init__(**kw)
        self.timeframe = self.p.tf

    def on_start(self, ctx):
        p = self.p
        self.ef, self.es, self.he = EMAStream(p.ema_fast), EMAStream(p.ema_slow), EMAStream(p.htf_ema)

    def on_bar(self, ctx):
        p = self.p
        first = self.ef.value is None
        b = ctx.closed(p.tf, 1000 if first else p.atr_len * 10)
        hb = ctx.closed(p.htf, 600 if first else 5)
        f, s, he = self.ef.update(b), self.es.update(b), self.he.update(hb)
        if he is None or len(b) < p.ema_slow or not ctx.position.flat or ctx.open_orders():
            return
        k, c, o = p.pullback_bars, b.c[-1], b.o[-1]
        a = lambda: atr(b.h, b.l, b.c, p.atr_len)[-1]   # noqa: E731  (dihitung hanya saat ada sinyal)
        if p.long and hb.c[-1] > he and f > s:
            if b.l[-k:].min() <= f and c > f and c > o and c > b.h[-2]:
                sl = b.l[-k:].min() - p.sl_atr_buffer * a()
                ctx.enter("buy", c, sl, p, rr=p.rr, level=f)
        elif p.short and hb.c[-1] < he and f < s:
            if b.h[-k:].max() >= f and c < f and c < o and c < b.l[-2]:
                sl = b.h[-k:].max() + p.sl_atr_buffer * a()
                ctx.enter("sell", c, sl, p, rr=p.rr, level=f)


class PullbackScalp(Pullback):
    """Preset scalping pullback: tren M15/H1, entry M5."""
    params = {**Pullback.params, "tf": "5m", "htf": "1h", "rr": 1.5}
