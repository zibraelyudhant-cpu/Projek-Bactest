"""Download candle Binance USDT-M Futures dari data.binance.vision -> {SIMBOL}_{tf}.npz

Yang diunduh hanya TF terkecil (default 5m). TF lain (15m, 1h, 4h, 1d) dirakit dari situ,
jadi semua TF pasti konsisten. Kalau file sudah ada, hanya bulan terakhir ke depan yang diunduh
ulang (update), data lama tetap disimpan.

Contoh:
  python tools/download_binance.py --symbols BTCUSDT ETHUSDT
  python tools/download_binance.py --all
  python tools/download_binance.py --all --start 2024-01-01 --out "D:\\Data Candle Binance\\all"
"""
import argparse
import datetime as dt
import io
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from concurrent.futures import ThreadPoolExecutor

import numpy as np

MIRRORS = [os.environ.get("BINANCE_VISION_URL", "https://data.binance.vision"),
           "https://s3-ap-northeast-1.amazonaws.com/data.binance.vision"]
LIST_URL = os.environ.get("BINANCE_VISION_LIST", "https://s3-ap-northeast-1.amazonaws.com/data.binance.vision")
PREFIX = "data/futures/um"
TF_MS = {"1m": 60_000, "3m": 180_000, "5m": 300_000, "15m": 900_000, "30m": 1_800_000, "1h": 3_600_000,
         "2h": 7_200_000, "4h": 14_400_000, "6h": 21_600_000, "8h": 28_800_000, "12h": 43_200_000, "1d": 86_400_000}
DEFAULT_OUT = r"D:\Data Candle Binance\all"


def fetch(path, tries=4):
    """Ambil file dari mirror pertama yang bisa diakses. Return None kalau 404 (file memang tidak ada)."""
    last = None
    for attempt in range(tries):
        for base in MIRRORS:
            try:
                with urllib.request.urlopen(f"{base}/{urllib.parse.quote(path)}", timeout=60) as r:
                    return r.read()
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    return None
                last = e
            except Exception as e:  # koneksi putus, timeout, diblokir: coba mirror berikutnya
                last = e
        time.sleep(2 ** attempt)
    raise RuntimeError(f"gagal download {path}: {last}")


def list_symbols():
    """Semua simbol USDT perpetual yang ada di arsip (termasuk yang sudah delisting)."""
    ns = "{http://s3.amazonaws.com/doc/2006-03-01/}"
    out, marker = [], ""
    while True:
        url = f"{LIST_URL}?delimiter=/&prefix={PREFIX}/monthly/klines/&marker={marker}"
        with urllib.request.urlopen(url, timeout=60) as r:
            root = ET.fromstring(r.read())
        for p in root.iter(ns + "Prefix"):
            name = p.text.rstrip("/").split("/")[-1]
            if p.text.count("/") > 4 and name.endswith("USDT") and "_" not in name:
                out.append(name)
        nxt = root.find(ns + "NextMarker")
        if root.findtext(ns + "IsTruncated") != "true" or nxt is None:
            break
        marker = nxt.text
    return sorted(set(out))


def parse_zip(blob):
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        text = z.read(z.namelist()[0]).decode()
    rows = [ln.split(",") for ln in text.splitlines() if ln and ln[0].isdigit()]  # lewati header
    if not rows:
        return np.zeros((0, 6))
    a = np.array([r[:6] for r in rows], dtype=np.float64)
    if a[0, 0] > 1e14:  # mikrodetik -> milidetik
        a[:, 0] //= 1000
    return a


def file_list(sym, tf, start, end, today):
    """(path_bulanan, [path_harian...]) per bulan; bulan berjalan pakai file harian."""
    jobs = []
    m = dt.date(start.year, start.month, 1)
    while m <= end:
        nxt = dt.date(m.year + (m.month == 12), m.month % 12 + 1, 1)
        days = [m + dt.timedelta(d) for d in range((nxt - m).days)]
        days = [d for d in days if start <= d <= end]
        monthly = None if nxt > dt.date(today.year, today.month, 1) else \
            f"{PREFIX}/monthly/klines/{sym}/{tf}/{sym}-{tf}-{m:%Y-%m}.zip"
        daily = [f"{PREFIX}/daily/klines/{sym}/{tf}/{sym}-{tf}-{d:%Y-%m-%d}.zip" for d in days]
        if monthly:
            jobs.append((monthly, daily))
        else:
            jobs.extend((None, [d]) for d in daily)   # bulan berjalan: file harian diunduh paralel
        m = nxt
    return jobs


def download_month(job):
    monthly, daily = job
    if monthly:
        blob = fetch(monthly)
        if blob is not None:
            return [parse_zip(blob)]
    # file bulanan belum terbit (awal bulan) atau bulan berjalan: pakai harian
    return [parse_zip(b) for b in (fetch(p) for p in daily) if b is not None]


def aggregate(a, ms):
    if not len(a):
        return a
    g = (a[:, 0] // ms * ms).astype(np.int64)
    keys, idx = np.unique(g, return_index=True)
    end = np.r_[idx[1:], len(a)] - 1
    return np.column_stack([keys, a[idx, 1], np.maximum.reduceat(a[:, 2], idx), np.minimum.reduceat(a[:, 3], idx),
                            a[end, 4], np.add.reduceat(a[:, 5], idx)])


def save(path, a):
    tmp = path + ".tmp.npz"
    np.savez_compressed(tmp, t=a[:, 0].astype(np.int64), o=a[:, 1], h=a[:, 2], l=a[:, 3], c=a[:, 4], v=a[:, 5])
    os.replace(tmp, path)


def load(path):
    with np.load(path) as z:
        return np.column_stack([z["t"].astype(np.float64)] + [z[k].astype(np.float64) for k in "ohlcv"])


def update_symbol(sym, args, pool):
    base_tf = min(args.tfs, key=TF_MS.get)
    base_path = os.path.join(args.out, f"{sym}_{base_tf}.npz")
    start = args.start
    old = None
    if os.path.exists(base_path) and not args.full:
        old = load(base_path)
        if len(old):
            last = dt.datetime.fromtimestamp(old[-1, 0] / 1000, dt.timezone.utc).date()
            start = max(start, dt.date(last.year, last.month, 1))  # bulan terakhir diunduh ulang
    if start > args.end:
        return f"{sym}: sudah terbaru"
    parts = [p for res in pool.map(download_month, file_list(sym, base_tf, start, args.end, args.today)) for p in res]
    new = np.concatenate(parts) if parts else np.zeros((0, 6))
    if not len(new) and old is None:
        return f"{sym}: tidak ada data di rentang ini"
    start_ms = int(dt.datetime.combine(args.start, dt.time(), dt.timezone.utc).timestamp() * 1000)
    if old is None:
        a = new[new[:, 0] >= start_ms]
    elif len(new):
        a = np.concatenate([old[old[:, 0] < new[0, 0]], new])   # data lama + bulan terakhir yang diperbarui
    else:
        a = old
    a = a[np.unique(a[:, 0], return_index=True)[1]]
    os.makedirs(args.out, exist_ok=True)
    for tf in args.tfs:
        save(os.path.join(args.out, f"{sym}_{tf}.npz"), a if tf == base_tf else aggregate(a, TF_MS[tf]))
    first = dt.datetime.fromtimestamp(a[0, 0] / 1000, dt.timezone.utc)
    last = dt.datetime.fromtimestamp(a[-1, 0] / 1000, dt.timezone.utc)
    return f"{sym}: {len(a)} bar {base_tf}, {first:%Y-%m-%d} -> {last:%Y-%m-%d %H:%M} UTC (+{len(new)} baru)"


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")   # nama koin non-ASCII aman di console Windows
    today = dt.datetime.now(dt.timezone.utc).date()
    ap = argparse.ArgumentParser(description="Download candle Binance Futures (USDT-M) ke format .npz")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--symbols", nargs="+", help="contoh: BTCUSDT ETHUSDT")
    g.add_argument("--all", action="store_true", help="semua simbol USDT perpetual di arsip")
    ap.add_argument("--start", default=str(today - dt.timedelta(days=730)), help="YYYY-MM-DD (default: 2 tahun lalu)")
    ap.add_argument("--end", default=str(today - dt.timedelta(days=1)), help="YYYY-MM-DD (default: kemarin)")
    ap.add_argument("--tfs", nargs="+", default=["5m", "15m", "1h", "4h", "1d"], help="TF yang disimpan")
    ap.add_argument("--out", default=os.environ.get("DATA_DIR", DEFAULT_OUT), help="folder tujuan")
    ap.add_argument("--workers", type=int, default=8, help="jumlah download paralel")
    ap.add_argument("--full", action="store_true", help="unduh ulang semua (abaikan file yang sudah ada)")
    args = ap.parse_args()
    args.start, args.end, args.today = dt.date.fromisoformat(args.start), dt.date.fromisoformat(args.end), today
    args.tfs = [t for t in args.tfs if t in TF_MS]

    syms = list_symbols() if args.all else [s.upper() for s in args.symbols]
    print(f"{len(syms)} simbol, {args.start} s/d {args.end}, TF {' '.join(args.tfs)} -> {args.out}", flush=True)
    failed = []
    with ThreadPoolExecutor(args.workers) as pool:
        for i, sym in enumerate(syms, 1):
            try:
                print(f"[{i}/{len(syms)}] {update_symbol(sym, args, pool)}", flush=True)
            except Exception as e:
                failed.append(sym)
                print(f"[{i}/{len(syms)}] {sym}: GAGAL - {e}", flush=True)
    if failed:
        print("\nGagal:", " ".join(failed), "\nJalankan ulang perintah yang sama untuk mencoba lagi.",
              "\nKalau gagal terus: Binance mungkin memblokir IP jaringan kamu -> nyalakan VPN (atau ganti DNS ke 1.1.1.1), lalu ulangi.")
        sys.exit(1)
    print("\nSelesai.")


if __name__ == "__main__":
    main()
