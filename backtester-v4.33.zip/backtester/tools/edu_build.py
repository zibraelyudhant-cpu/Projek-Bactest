"""Bangun data menu 📚 Info Trading dari candle ASLI (Binance Futures).

Pemakaian:  python tools/edu_build.py <folder candle json> [frontend/edu_data.json]
Folder berisi file <SIMBOL>_<TF>.json = [[open_time_ms, open, high, low, close, volume], ...] (urut waktu).

Untuk tiap topik, contoh dicari OTOMATIS dengan aturan yang tertulis di fungsi find_*. Hasilnya: potongan candle asli
(±150-200 candle) + anotasi (garis, zona, label) yang muncul tepat saat candle-nya terbentuk + langkah penjelasan.
"""
import glob
import json
import os
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from backend.evidence import _impulse_ok, zigzag  # noqa: E402
from backend.indicators import atr, pivots  # noqa: E402

COL = {"gold": "#f0b90b", "up": "#26a69a", "dn": "#ef5350", "vio": "#c4b5fd", "blue": "#3b82f6", "mut": "#8b96a5",
       "cyan": "#22d3ee", "pink": "#f472b6"}


class Series:
    def __init__(self, path):
        d = np.array(json.load(open(path)), float)
        self.name = os.path.basename(path)[:-5]
        self.sym, self.tf = self.name.split("_")
        self.t, self.o, self.h, self.l, self.c = d[:, 0].astype(np.int64), d[:, 1], d[:, 2], d[:, 3], d[:, 4]
        self.v = d[:, 5] if d.shape[1] > 5 else np.ones(len(d))          # volume (topik indikator)
        self.a = atr(self.h, self.l, self.c, 14)
        self.n = len(self.c)

    def window(self, a0, a1):
        a0, a1 = max(0, int(a0)), min(self.n, int(a1))
        dec = 2 if self.c[a0] >= 100 else 4
        C = [[int(self.t[i]), round(float(self.o[i]), dec), round(float(self.h[i]), dec), round(float(self.l[i]), dec),
              round(float(self.c[i]), dec)] for i in range(a0, a1)]
        return a0, C


def _f(x):
    return round(float(x), 6)


# ------------------------------------------------------------------ anotasi (indeks relatif ke potongan)
def hline(p, i0, i1=None, col="gold", dash="6 4", tag=None, show=None, until=None, w=1.3):
    return {"k": "h", "p": _f(p), "i0": int(i0), "i1": None if i1 is None else int(i1), "c": COL.get(col, col), "dash": dash,
            "tag": tag, "from": int(i0 if show is None else show), "until": until, "w": w}


def zone(p1, p2, i0, i1=None, col="gold", show=None, until=None, op=0.12, label=None):
    return {"k": "z", "p1": _f(p1), "p2": _f(p2), "i0": int(i0), "i1": None if i1 is None else int(i1), "c": COL.get(col, col),
            "from": int(i0 if show is None else show), "until": until, "op": op, "label": label}


def label(i, p, text, col="gold", pos="above", show=None, pill=False, anchor="middle"):
    return {"k": "t", "i": int(i), "p": _f(p), "text": text, "c": COL.get(col, col), "pos": pos,
            "from": int(i if show is None else show), "pill": pill, "anchor": anchor}


def seg(i1, p1, i2, p2, col="vio", show=None, dash="", w=1.6):
    return {"k": "s", "i1": int(i1), "p1": _f(p1), "i2": int(i2), "p2": _f(p2), "c": COL.get(col, col), "from": int(i2 if show is None else show),
            "dash": dash, "w": w}


def box(i, col="gold", show=None):
    return {"k": "b", "i": int(i), "c": COL.get(col, col), "from": int(i if show is None else show)}


def scenario(S, a0, C, title, steps, ann, slow=(), pause=(), note=""):
    return {"title": title, "sym": S.sym, "tf": S.tf, "C": C, "steps": steps, "ann": ann, "slow": [int(x) for x in slow],
            "pause": [int(x) for x in pause], "note": note}


# ------------------------------------------------------------------ 1. liquidity sweep (+ breakdown asli)
def _pool(S, s, lo_i, tol=0.3):
    A = S.a[s]
    sl = [i for i in lo_i if s - 120 <= i <= s - 4 and i + 3 < s]
    for base in sorted(sl, key=lambda i: S.l[i]):
        grp = sorted(int(i) for i in sl if abs(S.l[i] - S.l[base]) <= tol * A)
        if len(grp) >= 2:
            return grp, float(min(S.l[i] for i in grp))
    return None, None


def find_sweep(S):
    """Equal lows (>= 2 sentuhan, belum pernah ditembus) -> ekor menembus 0.25-2 ATR & close balik -> high kecil ditembus
    (MSS) <= 12 candle -> harga sampai high range sebelum menembus ekor sweep."""
    hi_i, lo_i = pivots(S.h, S.l, 3)
    out = []
    for s in range(150, S.n - 40):
        A = S.a[s]
        if not A > 0:
            continue
        G, L = _pool(S, s, lo_i)
        if not G or G[-1] < s - 60 or G[-1] - G[0] < 12:
            continue
        if S.c[G[0]:s].min() < L - 0.05 * A or S.l[G[0]:s].min() < L - 0.05 * A:
            continue
        top = S.h[G[0]:s].max()
        if top - L < 2.5 * A or not (L - 2 * A < S.l[s] < L - 0.25 * A and S.c[s] > L):
            continue
        mh = G[-1] + int(np.argmax(S.h[G[-1]:s]))
        mss = next((j for j in range(s + 1, min(S.n, s + 12)) if S.c[j] > S.h[mh]), None)
        if mss is None or S.l[s + 1:mss + 1].min() < S.l[s]:
            continue
        tgt = next((j for j in range(mss, min(S.n, mss + 80)) if S.h[j] >= top), None)
        if tgt is None or S.l[mss:tgt + 1].min() < S.l[s]:
            continue
        out.append({"s": s, "G": G, "L": L, "top": float(top), "topi": G[0] + int(np.argmax(S.h[G[0]:s])), "mh": mh, "mss": mss,
                    "tgt": tgt, "score": len(G) * 10 - (tgt - G[0]) / 20 + (S.tf == "1h") * 5})   # 1H lebih mudah dibaca
    return out


def build_sweep(S, x):
    s, G, L, A = x["s"], x["G"], x["L"], S.a[x["s"]]
    a0, C = S.window(G[0] - 70, x["tgt"] + 20)
    r = lambda i: i - a0                                    # noqa: E731
    entry, sl, top = float(S.c[s]), float(S.l[s] - 0.15 * A), x["top"]
    ann = [zone(L, L - 0.9 * A, r(G[0]), r(s), col="dn", op=0.08, label="SSL (sell-side liquidity)", show=r(G[1])),
           hline(L, r(G[0]), col="gold", tag="SUPPORT", show=r(G[1])),
           *[label(r(g), S.l[g], f"EQL {q + 1}", pos="below") for q, g in enumerate(G)],
           zone(min(S.o[s], S.c[s]), S.l[s], r(s), r(s) + 10, col="gold", show=r(s) + 1, op=0.2, label="REJECTION BLOCK"),
           hline(S.h[x["mh"]], r(x["mh"]), r(x["mss"]), col="vio", dash="", show=r(x["mh"]) + 1),
           label(r(x["mh"]), S.h[x["mh"]], "high kecil", col="vio", show=r(x["mh"]) + 1),
           label(r(x["mss"]), S.h[x["mh"]], "ditembus = MSS ✓", col="vio", pos="below", pill=True, anchor="start"),
           hline(top, r(x["topi"]), col="up", tag="HIGH RANGE", show=r(G[1])),
           box(r(s)), label(r(s), S.l[s], "SWEEP: ekor tembus, close balik ✓", pos="below", pill=True, anchor="end", show=r(s) + 1),
           zone(top, entry, r(s) + 1, col="up", show=r(s) + 2, op=0.08), zone(entry, sl, r(s) + 1, col="dn", show=r(s) + 2, op=0.08),
           hline(entry, r(s) + 1, col="blue", dash="", tag="ENTRY", show=r(s) + 2), hline(sl, r(s) + 1, col="dn", dash="", tag="SL", show=r(s) + 2),
           label(r(x["tgt"]), S.h[x["tgt"]], "✅ TP kena", col="#36e3a1", pill=True)]
    steps = [["Konteks", "Harga turun lalu mulai bergerak mendatar. Perhatikan di mana harga berhenti turun.", "", 0],
             ["Likuiditas menumpuk (EQL & SSL)", f"Low di level yang sama tersentuh {len(G)}× (≈ {L:.6g}) = EQUAL LOWS (EQL) → support terlihat jelas oleh SEMUA orang.",
              "LIKUIDITAS = order yang menunggu. Di bawah EQL menumpuk SL pembeli & SELL STOP trader breakout = SSL (sell-side liquidity, area merah).", r(G[0])],
             ["Mendekati support lagi", "High kecil terakhir terbentuk (garis ungu), lalu harga turun lagi ke support. Tembus atau mantul?", "", r(x["mh"]) + 1],
             ["SWEEP / STOP HUNT!", "Ekor candle menembus support → semua SL & sell stop kena sekaligus = order JUAL market. Inilah STOP HUNT (perburuan stop loss).",
              "Pemain besar memakai order jual itu untuk mengisi BELI dalam jumlah besar.", r(s)],
             ["Close kembali di atas", "Candle sweep CLOSE lagi di atas support dengan ekor bawah panjang → tembusnya PALSU. Area ekor itu = REJECTION BLOCK (zona kuning): harga ditolak keras di sana.",
              "Yang terjebak sekarang: penjual breakout. SL mereka di atas jadi bahan bakar naik.", r(s) + 1],
             ["Ide entry", f"Agresif: BUY di close candle sweep ({entry:.6g}). SL di bawah ujung ekor ({sl:.6g}). TP di high range ({top:.6g}).",
              "Konservatif: tunggu high kecil (garis ungu) ditembus dulu (MSS), baru entry.", r(s) + 2],
             ["MSS & ke target", "High kecil ditembus → struktur berubah naik (MSS), harga lanjut ke high range di atas → TP kena.",
              "Likuiditas di atas (SL penjual) adalah sasaran berikutnya.", r(x["mss"])]]
    return scenario(S, a0, C, "✅ Sweep — tembus palsu lalu berbalik", steps, ann, slow=[r(s)], pause=[r(G[-1]) + 1, r(s) + 1, r(s) + 2])


def find_breakdown(S):
    hi_i, lo_i = pivots(S.h, S.l, 3)
    out = []
    for s in range(150, S.n - 45):
        A = S.a[s]
        G, L = _pool(S, s, lo_i)
        if not G or G[-1] < s - 60 or G[-1] - G[0] < 12:
            continue
        if S.c[G[0]:s].min() < L - 0.05 * A or S.l[G[0]:s].min() < L - 0.05 * A or S.h[G[0]:s].max() - L < 2.5 * A:
            continue
        if not S.c[s] < L - 0.3 * A or S.c[s + 1:s + 9].max() > L or S.l[s:s + 40].min() > L - 3 * A:
            continue
        rt = s + 1 + int(np.argmax(S.h[s + 1:s + 9]))
        out.append({"s": s, "G": G, "L": L, "rt": rt, "low": s + int(np.argmin(S.l[s:s + 40])),
                    "mh": G[-1] + int(np.argmax(S.h[G[-1]:s])), "score": len(G) * 10})
    return out


def build_breakdown(S, x):
    s, G, L, A = x["s"], x["G"], x["L"], S.a[x["s"]]
    a0, C = S.window(G[0] - 60, x["low"] + 35)
    r = lambda i: i - a0                                    # noqa: E731
    ann = [zone(L, L - 0.9 * A, r(G[0]), r(s), col="dn", op=0.08),
           hline(L, r(G[0]), col="gold", tag="SUPPORT", show=r(G[1]), until=r(s) + 1),
           hline(L, r(G[0]), col="dn", tag="RESIST", show=r(s) + 1),
           *[label(r(g), S.l[g], str(q + 1), pos="below") for q, g in enumerate(G)],
           box(r(s), col="dn"), label(r(s), S.l[s], "close di bawah support ✗", col="dn", pos="below", pill=True, anchor="end", show=r(s) + 1),
           label(r(x["rt"]), S.h[x["rt"]], "✗ retest gagal", col="dn", pill=True, show=r(x["rt"]) + 1)]
    steps = [["Konteks", "Harga bergerak lalu membentuk area bawah yang sama.", "", 0],
             ["Likuiditas menumpuk", f"Low di level yang sama tersentuh {len(G)}× (≈ {L:.6g}) → support jelas.",
              "SL pembeli & sell stop menumpuk di bawahnya (area merah tipis).", r(G[0])],
             ["Mendekati support lagi", "Harga turun lagi ke support. Tembus atau mantul?", "", r(x["mh"]) + 1],
             ["Tembus… tunggu CLOSE", "Candle menembus support — dan kali ini CLOSE di bawahnya.",
              "Ini BUKAN sweep. Jangan BUY hanya karena 'sudah tembus support'.", r(s)],
             ["Retest gagal", "Harga mencoba naik lagi, tapi tidak bisa close di atas support → support berubah jadi resistance.", "", r(x["rt"])],
             ["Lanjut turun", "Harga terus turun mencari likuiditas di bawah berikutnya.", "Bedanya dengan sweep: posisi CLOSE candle, bukan ekornya.", r(x["rt"]) + 1]]
    return scenario(S, a0, C, "❌ Bukan sweep — breakdown asli", steps, ann, slow=[r(s)], pause=[r(G[-1]) + 1, r(s) + 1, r(x["rt"]) + 1])


# ------------------------------------------------------------------ 2. market structure: BOS & CHoCH
def _swings(S, n=4):
    hi, lo = pivots(S.h, S.l, n)
    sw = sorted([(int(i), 1, float(S.h[i])) for i in hi] + [(int(i), -1, float(S.l[i])) for i in lo])
    out = []                                               # bergantian high / low (ambil yang paling ekstrem)
    for x in sw:
        if out and out[-1][1] == x[1]:
            if (x[1] == 1 and x[2] > out[-1][2]) or (x[1] == -1 and x[2] < out[-1][2]):
                out[-1] = x
            continue
        out.append(x)
    return out


def find_structure(S, n=4):
    """Tren naik: >= 3 high naik (HH) & low naik (HL) berturut-turut, tiap HH ditembus close (BOS), lalu close menembus HL
    terakhir (CHoCH) dan harga turun >= 2 ATR sesudahnya."""
    sw = _swings(S, n)
    out = []
    for k in range(6, len(sw) - 1):
        seq = sw[k - 6:k + 1]                              # L H L H L H L ... diakhiri low (HL terakhir)
        if seq[-1][1] != -1:
            continue
        lows = [x for x in seq if x[1] == -1]
        highs = [x for x in seq if x[1] == 1]
        if len(highs) < 3 or not all(b[2] > a[2] for a, b in zip(lows, lows[1:])) or not all(b[2] > a[2] for a, b in zip(highs, highs[1:])):
            continue
        hl = seq[-1]
        nxt_hi = next((x for x in sw[k + 1:k + 2] if x[1] == 1), None)
        start = hl[0] + n
        if nxt_hi and nxt_hi[2] > highs[-1][2]:
            continue                                       # tren masih lanjut (HH baru)
        ch = next((j for j in range(start, min(S.n, start + 60)) if S.c[j] < hl[2]), None)
        if ch is None or S.h[hl[0]:ch].max() > highs[-1][2]:
            continue
        drop = S.l[ch:min(S.n, ch + 40)].min()
        if hl[2] - drop < 2 * S.a[ch]:
            continue
        span = ch - seq[0][0]
        if not 60 <= span <= 170:
            continue
        out.append({"seq": seq, "ch": ch, "hl": hl, "end": min(S.n - 1, ch + 30), "score": len(highs) * 10 - abs(span - 110) / 10})
    return out


def build_structure(S, x, n=4):
    seq, ch, hl = x["seq"], x["ch"], x["hl"]
    a0, C = S.window(seq[0][0] - 25, x["end"] + 5)
    r = lambda i: i - a0                                    # noqa: E731
    ann, steps = [], [["Swing High & Swing Low", "MARKET STRUCTURE = urutan titik balik harga. SWING HIGH = puncak (ada candle lebih rendah di kiri & kanannya), SWING LOW = lembah. Label muncul setelah titiknya terkonfirmasi.", "", 0]]
    prev_h = prev_l = None
    for i, typ, p in seq:
        conf = i + n                                       # swing baru diketahui n candle sesudahnya
        if typ == 1:
            lab = "HH" if prev_h is not None and p > prev_h else "Swing High"
            ann.append(label(r(i), p, lab, col="up" if lab == "HH" else "mut", show=r(conf)))
            prev_h_i, prev_h = i, p
        else:
            lab = "HL" if prev_l is not None and p > prev_l else "Swing Low"
            ann.append(label(r(i), p, lab, col="up" if lab == "HL" else "mut", pos="below", show=r(conf)))
            prev_l = p
    # BOS: close menembus high sebelumnya
    highs = [x_ for x_ in seq if x_[1] == 1]
    first_bos = None
    for h0 in highs:
        j = next((j for j in range(h0[0] + 1, ch) if S.c[j] > h0[2]), None)
        if j is None:
            continue
        ann += [hline(h0[2], r(h0[0]), r(j), col="up", dash="4 3", show=r(j), w=1.2), label(r(j), h0[2], "BOS", col="up", pill=True, show=r(j))]
        first_bos = first_bos or j
    if first_bos:
        ann.append(label(r(first_bos), S.l[first_bos:ch].min(), "TREN NAIK = HH + HL", col="up", pos="below", pill=True, anchor="start", show=r(first_bos)))
        steps.append(["Tren naik & BOS", "TREN NAIK = high makin tinggi (HH) & low makin tinggi (HL). Close menembus high sebelumnya = BOS (Break of Structure) → tren BERLANJUT.",
                      "Selama high terus naik (HH) & low terus naik (HL), tren naik masih sehat. Cari BUY di HL.", r(first_bos)])
    steps.append(["HL terakhir = garis pertahanan", f"Low terakhir yang lebih tinggi (HL ≈ {hl[2]:.6g}) adalah titik yang harus dijaga pembeli.",
                  "Kalau HL ini ditembus close, struktur naik RUSAK.", r(hl[0] + n)])
    ann += [hline(hl[2], r(hl[0]), r(ch), col="dn", dash="6 4", tag="HL TERAKHIR", show=r(hl[0] + n)),
            box(r(ch), col="dn"), label(r(ch), hl[2], "CHoCH = REVERSAL (berbalik turun)", col="dn", pos="below", pill=True, anchor="start", show=r(ch))]
    sw_all = _swings(S, n)
    last_h = max(x_[2] for x_ in seq if x_[1] == 1)
    last_l = hl[2]
    for i, typ, p in sw_all:
        if i <= hl[0] or i + n >= x["end"] or i < ch - 8:
            continue
        if typ == 1:
            ann.append(label(r(i), p, "LH" if p < last_h else "HH", col="dn", show=r(i + n)))
            last_h = p
        else:
            ann.append(label(r(i), p, "LL" if p < last_l else "HL", col="dn", pos="below", show=r(i + n)))
            last_l = p
    steps += [["CHoCH = Reversal", "Close menembus HL terakhir = CHoCH (Change of Character) → tren naik selesai dan BERBALIK (REVERSAL): penjual mengambil alih.",
               "Jangan BUY lagi di sini. Tunggu struktur turun (LH/LL) atau tanda naik baru.", r(ch)],
              ["Setelah CHoCH", "Harga turun. Struktur baru: LOWER HIGH (LH = puncak lebih rendah) & LOWER LOW (LL = lembah lebih rendah) → tren turun.", "BOS = tren lanjut · CHoCH = tren berubah.", r(ch) + 1]]
    return scenario(S, a0, C, "Market Structure: BOS & CHoCH", steps, ann, slow=[r(ch)], pause=[r(ch) + 1])


# ------------------------------------------------------------------ 3. order block
def find_ob(S):
    """Bullish OB = candle turun terakhir sebelum dorongan naik kuat (>= 2.5 ATR dalam 4 candle) yang menembus high 20
    candle (BOS). Harga lalu kembali menyentuh zona OB (>= 6 candle kemudian), close tidak menembus bawah OB, dan naik
    >= 2 ATR dari sentuhan."""
    out = []
    for i in range(30, S.n - 60):
        A = S.a[i]
        if not (A > 0 and S.c[i] < S.o[i]):
            continue
        j4 = i + 4
        if S.c[i + 1] <= S.o[i + 1] or S.h[i + 1:j4 + 1].max() - S.l[i] < 3.5 * A:
            continue
        if S.h[i + 1:j4 + 1].max() <= S.h[i - 20:i].max():
            continue                                       # dorongan harus menembus high sebelumnya (BOS)
        top, bot = max(S.o[i], S.c[i]), S.l[i]
        touch = next((k for k in range(j4 + 3, min(S.n, j4 + 60)) if S.l[k] <= top), None)
        if touch is None or S.c[j4:touch + 1].min() < bot or S.l[touch] < bot - 0.2 * A:
            continue
        up = S.h[touch:min(S.n, touch + 30)].max()
        if up - S.l[touch] < 2 * A or S.l[touch:touch + 30].min() < bot:
            continue
        if top - bot < 0.6 * A:
            continue                                       # zona terlalu tipis (sulit dilihat)
        out.append({"i": i, "top": float(top), "bot": float(bot), "touch": touch, "end": min(S.n - 1, touch + 30),
                    "score": (S.h[i + 1:j4 + 1].max() - S.l[i]) / A * 2 + (up - S.l[touch]) / A - (touch - i) / 15})
    return out


def build_ob(S, x):
    i, t = x["i"], x["touch"]
    a0, C = S.window(i - 60, x["end"] + 5)
    r = lambda k: k - a0                                    # noqa: E731
    bos_lv = float(S.h[i - 20:i].max())
    bos_i = next(k for k in range(i + 1, i + 6) if S.h[k] > bos_lv)
    mt = (S.o[i] + S.c[i]) / 2
    ann = [box(r(i), col="cyan", show=r(i) + 2),
           zone(x["top"], x["bot"], r(i), r(t) + 1, col="cyan", show=r(i) + 2, op=0.16, label="ORDER BLOCK = POI"),
           hline(mt, r(i), r(t) + 1, col="cyan", dash="2 3", tag="MT 50%", show=r(i) + 2, w=1),
           label(r(i) + 2, S.h[i + 1:i + 5].max(), "DISPLACEMENT", col="up", pill=True, show=r(i) + 3),
           hline(bos_lv, r(i) - 20, r(bos_i), col="up", dash="4 3", show=r(bos_i)), label(r(bos_i), bos_lv, "BOS", col="up", pill=True, show=r(bos_i)),
           label(r(t), S.l[t], "harga kembali ke OB → mantul ✓", col="cyan", pos="below", pill=True, anchor="start", show=r(t) + 1)]
    steps = [["Konteks", "Perhatikan candle-candle sebelum harga bergerak kencang.", "", 0],
             ["Displacement", "Harga naik kencang beberapa candle sekaligus (DISPLACEMENT = gerak besar & cepat satu arah) dan menembus high sebelumnya (BOS).",
              "Gerak sekencang ini biasanya tanda order beli besar masuk.", r(i) + 1],
             ["Order Block = POI", "Candle TURUN terakhir sebelum dorongan itu = ORDER BLOCK (kotak biru), sebuah POI (Point of Interest = zona yang kita tunggu). Garis tengahnya = MEAN THRESHOLD (50% badan candle OB).",
              "Pemain besar diperkirakan mengumpulkan posisi di sini. Kalau harga kembali dan close melewati mean threshold, OB mulai melemah.", r(i) + 2],
             ["Menunggu harga kembali", "Harga sempat naik jauh, lalu turun lagi pelan-pelan menuju zona OB.", "Jangan kejar harga di atas; tunggu di zona.", r(i) + 6],
             ["Sentuh OB → mantul", "Harga menyentuh zona OB dan berbalik naik, tanpa close di bawah zona.",
              "Ide entry: BUY di zona OB, SL di bawah OB. Kalau candle CLOSE di bawah OB → OB gagal, keluar.", r(t)],
             ["Lanjut naik", "Pembeli besar mempertahankan zona OB, harga melanjutkan arah dorongan awal.", "", r(t) + 1]]
    return scenario(S, a0, C, "Order Block", steps, ann, slow=[r(t)], pause=[r(i) + 2, r(t) + 1])


# ------------------------------------------------------------------ 4. fair value gap
def find_fvg(S):
    """Bullish FVG: low candle i > high candle i-2, celah >= 0.6 ATR. Harga kembali mengisi celah (>= 5 candle kemudian),
    close tidak menembus bawah celah, lalu naik >= 2 ATR."""
    out = []
    for i in range(40, S.n - 60):
        A = S.a[i]
        g_lo, g_hi = S.h[i - 2], S.l[i]
        if not (A > 0 and g_hi - g_lo >= 0.6 * A):
            continue
        fill = next((k for k in range(i + 5, min(S.n, i + 60)) if S.l[k] <= g_hi), None)
        if fill is None or S.c[i:fill + 1].min() < g_lo:
            continue
        up = S.h[fill:min(S.n, fill + 30)].max()
        if up - S.l[fill] < 2 * A or S.l[fill:fill + 25].min() < g_lo - 0.3 * A:
            continue
        out.append({"i": i, "lo": float(g_lo), "hi": float(g_hi), "fill": fill, "end": min(S.n - 1, fill + 30),
                    "score": (g_hi - g_lo) / A * 3 + (up - S.l[fill]) / A - (fill - i) / 25})
    return out


def build_fvg(S, x):
    i, f = x["i"], x["fill"]
    a0, C = S.window(i - 55, x["end"] + 5)
    r = lambda k: k - a0                                    # noqa: E731
    ann = [box(r(i) - 1, col="pink", show=r(i)),
           zone(x["hi"], x["lo"], r(i) - 2, r(f) + 1, col="pink", show=r(i), op=0.2, label="FVG / IMBALANCE"),
           hline((x["hi"] + x["lo"]) / 2, r(i) - 2, r(f) + 1, col="pink", dash="1 3", tag="CE 50%", show=r(i), w=1),
           hline(x["hi"], r(i) - 2, col="pink", dash="2 3", tag="FVG ATAS", show=r(i), until=r(f) + 2, w=1),
           hline(x["lo"], r(i) - 2, col="pink", dash="2 3", tag="FVG BAWAH", show=r(i), until=r(f) + 2, w=1),
           label(r(i) - 2, S.h[i - 2], "1", col="pink", pos="above", show=r(i)),
           label(r(i), S.l[i], "3", col="pink", pos="below", show=r(i)),
           label(r(f), S.l[f], "celah terisi → mantul ✓", col="pink", pos="below", pill=True, anchor="start", show=r(f) + 1)]
    steps = [["Konteks", "Perhatikan saat harga naik sangat cepat.", "", 0],
             ["3 candle: celah terbentuk", "Candle tengah naik sangat kencang sampai low candle ke-3 masih DI ATAS high candle ke-1 (tanda 1 & 3). Ruang di antaranya (zona pink) = FAIR VALUE GAP, disebut juga IMBALANCE. Garis tengahnya = CE (Consequent Encroachment, 50% celah).",
              "Di celah itu hampir tidak ada transaksi dua arah → harga 'tidak adil' / belum seimbang.", r(i)],
             ["Harga menjauh", "Harga terus naik, meninggalkan celah di bawah.", "Celah ini sering menjadi magnet: harga cenderung kembali mengisinya.", r(i) + 1],
             ["Celah diisi", "Harga turun kembali ke dalam celah (zona pink) …", "", r(f)],
             ["Mantul dari FVG", "… lalu berbalik naik tanpa close di bawah celah. FVG bekerja seperti support.",
              "Ide entry: BUY di dalam celah, SL di bawah celah. Close di bawah celah = FVG gagal.", r(f) + 1]]
    return scenario(S, a0, C, "Fair Value Gap (FVG)", steps, ann, slow=[r(i), r(f)], pause=[r(i) + 1, r(f) + 1])


# ------------------------------------------------------------------ 5. support / resistance flip
def find_flip(S):
    """Resistance (>= 2 high setara, belum ditembus) -> close menembus >= 0.3 ATR -> retest dari atas (low dalam 0.4 ATR dari
    level, close tetap di atas) -> naik >= 2.5 ATR."""
    hi_i, _ = pivots(S.h, S.l, 3)
    out = []
    for b in range(120, S.n - 50):
        A = S.a[b]
        hs = [i for i in hi_i if b - 110 <= i <= b - 4 and i + 3 < b]
        G = None
        for base in sorted(hs, key=lambda i: -S.h[i]):
            grp = sorted(int(i) for i in hs if abs(S.h[i] - S.h[base]) <= 0.3 * A)
            if len(grp) >= 2:
                G, R = grp, float(max(S.h[i] for i in grp))
                break
        if not G or G[-1] - G[0] < 10 or S.c[G[0]:b].max() > R or not S.c[b] > R + 0.3 * A or S.c[b - 1] > R:
            continue
        rt = next((k for k in range(b + 2, min(S.n, b + 30)) if S.l[k] <= R + 0.4 * A), None)
        if rt is None or S.c[b:rt + 1].min() < R - 0.1 * A or S.l[rt] < R - 0.6 * A:
            continue
        up = S.h[rt:min(S.n, rt + 40)].max()
        if up - R < 2.5 * A or S.l[rt:rt + 30].min() < R - 0.6 * A:
            continue
        out.append({"b": b, "G": G, "R": R, "rt": rt, "end": min(S.n - 1, rt + 35), "score": len(G) * 10 + (up - R) / A})
    return out


def build_flip(S, x):
    b, G, R, rt = x["b"], x["G"], x["R"], x["rt"]
    a0, C = S.window(G[0] - 50, x["end"] + 5)
    r = lambda k: k - a0                                    # noqa: E731
    ann = [hline(R, r(G[0]), col="dn", tag="RESISTANCE", show=r(G[1]), until=r(b) + 1),
           hline(R, r(G[0]), col="up", tag="SUPPORT", show=r(b) + 1),
           *[label(r(g), S.h[g], str(q + 1), col="dn") for q, g in enumerate(G)],
           box(r(b), col="up"), label(r(b), S.h[b], "close di atas resistance ✓", col="up", pill=True, anchor="end", show=r(b) + 1),
           label(r(rt), S.l[rt], "retest dari atas: bertahan ✓", col="up", pos="below", pill=True, anchor="start", show=r(rt) + 1)]
    steps = [["Konteks", "Perhatikan atap yang menahan harga.", "", 0],
             ["Resistance", f"RESISTANCE = 'atap' tempat harga berkali-kali ditolak turun (di sini {len(G)}×, ≈ {R:.6g}). Kebalikannya SUPPORT = 'lantai' tempat harga ditahan naik.", "Penjual menunggu di resistance, pembeli di support.", r(G[1])],
             ["Breakout", "BREAKOUT = candle CLOSE menembus level. Di sini close di atas resistance → penjual di level itu habis / kalah.", "Yang penting close, bukan sekadar ekor.", r(b)],
             ["Flip: resistance jadi support", "Garis berubah hijau: bekas resistance sekarang diharapkan menjadi support.",
              "Trader yang terlambat beli & penjual yang kena SL ingin masuk lagi di harga breakout.", r(b) + 1],
             ["Retest", "RETEST = harga kembali menguji level yang baru ditembus. Di sini harga turun menguji dari ATAS … dan bertahan (tidak close di bawahnya).",
              "Ide entry: BUY saat retest bertahan, SL di bawah level. Close kembali di bawah level = breakout palsu.", r(rt)],
             ["Lanjut naik", "Support baru bekerja, harga melanjutkan kenaikan.", "", r(rt) + 1]]
    return scenario(S, a0, C, "Support / Resistance Flip", steps, ann, slow=[r(b), r(rt)], pause=[r(b) + 1, r(rt) + 1])


# ------------------------------------------------------------------ 6. fibonacci retracement
FIB = [0.0, 0.382, 0.5, 0.618, 0.786, 1.0]


def find_fib(S):
    """Dorongan naik low -> high (>= 6 ATR, swing zigzag 2 ATR), koreksi berhenti di 0.5-0.786, lalu menembus high
    dorongan."""
    piv, _ = zigzag(S.h, S.l, S.a, 2.0)
    out = []
    for q in range(len(piv) - 2):
        (i0, p0, t0, _), (i1, p1, t1, c1), (i2, p2, t2, c2) = piv[q], piv[q + 1], piv[q + 2]
        if t0 != -1 or t1 != 1 or i0 < 45:
            continue                                       # butuh konteks >= 45 candle sebelum dorongan
        A = S.a[i1]
        if p1 - p0 < 6 * A or i1 - i0 > 60:
            continue
        rt = (p1 - p2) / (p1 - p0)
        if not 0.5 <= rt <= 0.79:
            continue
        brk = next((k for k in range(i2, min(S.n, i2 + 60)) if S.h[k] > p1), None)
        if brk is None:
            continue
        out.append({"i0": i0, "p0": p0, "i1": i1, "p1": p1, "c1": c1, "i2": i2, "p2": p2, "c2": c2, "rt": rt, "brk": brk,
                    "end": min(S.n - 1, brk + 15), "score": -abs(rt - 0.618) * 10 - (brk - i0) / 60})
    return out


def build_fib(S, x):
    a0, C = S.window(x["i0"] - 40, x["end"] + 5)
    r = lambda k: k - a0                                    # noqa: E731
    p0, p1 = x["p0"], x["p1"]
    lv = lambda f: p1 - (p1 - p0) * f                       # noqa: E731
    show = r(x["c1"])
    ann = [seg(r(x["i0"]), p0, r(x["i1"]), p1, col="mut", dash="4 4", show=show, w=1.2)]
    for f in FIB:
        col = "gold" if f in (0.5, 0.618) else "mut"
        ann.append(hline(lv(f), r(x["i0"]), col=col, dash="" if f in (0, 1) else "5 4", tag={0.0: "0 HIGH", 1.0: "1 LOW"}.get(f, f"{f:g}"), show=show, w=1.0))
    ann += [zone(lv(0.5), lv(0.786), r(x["i1"]), r(x["i2"]) + 3, col="gold", show=show, op=0.10, label="zona emas 0.5–0.786"),
            label(r(x["i2"]), x["p2"], f"koreksi {x['rt'] * 100:.0f}% → mantul ✓", col="gold", pos="below", pill=True, anchor="start", show=r(x["c2"])),
            label(r(x["brk"]), p1, "tembus high dorongan ✓", col="up", pill=True, show=r(x["brk"]))]
    steps = [["Konteks", "Perhatikan gerakan naik yang kuat.", "", 0],
             ["Dorongan selesai", f"Harga naik dari {p0:.6g} ke {p1:.6g}, lalu berbalik (swing high terkonfirmasi). Tarik Fibonacci dari LOW ke HIGH dorongan.",
              "Level Fibonacci = seberapa dalam koreksinya (dalam % dari dorongan).", show],
             ["Pullback / retracement", "Turunnya harga sesudah dorongan = PULLBACK; seberapa dalamnya diukur dengan RETRACEMENT Fibonacci. Koreksi sehat biasanya berhenti di 0.5 – 0.618 (– 0.786): 'zona emas' untuk mencari BUY.",
              "Lebih dalam dari 0.786 → dorongan awal mulai diragukan; di bawah 1.0 (low dorongan) → batal.", show + 1],
             ["Mantul di zona", f"Koreksi berhenti di ±{x['rt'] * 100:.0f}% dan harga berbalik naik.",
              "Ide entry: BUY di zona emas dengan konfirmasi (candle penolakan), SL di bawah 0.786 / low dorongan.", r(x["c2"])],
             ["Lanjut tren", "Harga kembali menembus high dorongan → tren naik berlanjut.", "", r(x["brk"])]]
    return scenario(S, a0, C, "Fibonacci Retracement", steps, ann, slow=[r(x["i2"])], pause=[show + 1, r(x["c2"]) + 1])


# ------------------------------------------------------------------ 7. elliott wave
def find_elliott(S):
    """Impuls 5 gelombang (aturan baku, swing zigzag 2 ATR) lalu koreksi A-B-C (B tidak melewati puncak gel. 5)."""
    piv, _ = zigzag(S.h, S.l, S.a, 2.0)
    out = []
    for q in range(len(piv) - 8):
        P = piv[q:q + 9]
        for s in (1, -1):
            if P[0][2] != -s:
                continue
            pr = [x[1] for x in P]
            if not _impulse_ok(pr[:6], s):
                continue
            A_, B_, C_ = pr[6], pr[7], pr[8]
            if not (s * (pr[5] - A_) > 0 and s * (B_ - A_) > 0 and s * (pr[5] - B_) > 0 and s * (A_ - C_) > 0):
                continue
            span = P[8][3] - P[0][0]
            if not 70 <= span <= 210:
                continue
            w = [abs(pr[k + 1] - pr[k]) for k in range(5)]
            if w[0] < 0.3 * w[2] or w[4] < 0.3 * w[2] or P[1][0] - P[0][0] < 6 or s * (pr[5] - pr[3]) <= 0:
                continue
            tot = abs(pr[5] - pr[0])
            if not (0.3 * tot <= abs(pr[5] - A_) <= 0.8 * tot and s * (C_ - pr[0]) > 0):   # koreksi di dalam area impuls
                continue                                   # gelombang 1 & 5 terlalu kecil -> sulit dilihat
            out.append({"P": P, "s": s, "end": min(S.n - 1, P[8][3] + 10), "score": -abs(span - 140) / 20 + (w[2] / max(w[0], 1e-9) > 1.2) * 3})
    return out


def build_elliott(S, x):
    P, s = x["P"], x["s"]
    a0, C = S.window(P[0][0] - 25, x["end"] + 5)
    r = lambda k: k - a0                                    # noqa: E731
    names = ["0", "1", "2", "3", "4", "5", "A", "B", "C"]
    ann = []
    for q in range(len(P)):
        i, p, t, conf = P[q]
        up = t == 1
        if q:
            ip, pp, _, _ = P[q - 1]
            ann.append(seg(r(ip), pp, r(i), p, col="vio" if q <= 5 else "gold", show=r(conf), w=1.8))
        ann.append(label(r(i), p, names[q], col="vio" if q <= 5 else "gold", pos="above" if up else "below", show=r(conf)))
    dname = "naik" if s == 1 else "turun"
    steps = [["Konteks", f"Elliott Wave: tren bergerak dalam 5 gelombang searah (impuls) lalu 3 gelombang koreksi (A-B-C). Contoh ini impuls {dname}.",
              "Titik dihitung otomatis dengan aturan baku; gelombang baru diberi angka setelah terkonfirmasi (harga berbalik ≥ 2 ATR).", 0],
             ["Gelombang 1", "Gerak pertama searah tren baru.", "", r(P[1][3])],
             ["Gelombang 2", "Koreksi — TIDAK boleh melewati awal gelombang 1.", "Ini aturan wajib; kalau dilanggar, hitungannya salah.", r(P[2][3])],
             ["Gelombang 3", "Biasanya gelombang terkuat & terpanjang, melewati ujung gelombang 1.", "Gelombang 3 tidak boleh yang terpendek di antara 1, 3, 5.", r(P[3][3])],
             ["Gelombang 4", "Koreksi kedua — tidak boleh masuk wilayah gelombang 1.", "", r(P[4][3])],
             ["Gelombang 5", "Dorongan terakhir, melewati ujung gelombang 3. Sering lebih lemah (momentum mulai habis).", "Setelah 5 gelombang selesai, waspada koreksi besar.", r(P[5][3])],
             ["Koreksi A-B-C", ("Setelah impuls selesai, harga bergerak berlawanan dalam 3 gelombang: A (turun), B (pantulan naik), C (turun lagi)."
                                if s == 1 else "Setelah impuls selesai, harga bergerak berlawanan dalam 3 gelombang: A (naik), B (turun sedikit), C (naik lagi)."),
              "B tidak melewati ujung gelombang 5. Akhir C sering jadi awal impuls baru.", r(P[6][3])],
             ["Koreksi selesai", "Gelombang C selesai → siklus lengkap 1-2-3-4-5-A-B-C.", "", r(P[8][3])]]
    return scenario(S, a0, C, f"Elliott Wave: impuls 5 gelombang + koreksi ABC ({dname})", steps, ann, pause=[r(P[5][3]) + 1, r(P[8][3]) + 1])


# ------------------------------------------------------------------ cermin (mencari contoh arah turun dengan finder arah naik)
class Mirror(Series):
    """Harga dicerminkan (x -> -x). Indeks candle tetap sama, jadi builder memakai harga asli dari seri aslinya."""

    def __init__(self, S):                                # noqa: D107 - tidak memanggil Series.__init__ (tanpa file)
        self.__dict__.update(S.__dict__)
        self.base = S
        self.o, self.h, self.l, self.c = -S.o, -S.l, -S.h, -S.c

    def window(self, a0, a1):
        return self.base.window(a0, a1)


def mirrored(finder):
    return lambda S: finder(Mirror(S))


# ------------------------------------------------------------------ 8. fakeout di resistance (BSL, EQH, distribusi)
def build_fakeout(S, x):
    """x dari find_sweep pada harga cermin: EQH disapu ke atas, close balik di bawah, low kecil ditembus, ke low range."""
    s, G, A = x["s"], x["G"], S.a[x["s"]]
    R, low, lowi, mli, mss, tgt = -x["L"], -x["top"], x["topi"], x["mh"], x["mss"], x["tgt"]
    a0, C = S.window(G[0] - 70, tgt + 20)
    r = lambda i: i - a0                                    # noqa: E731
    entry, sl = float(S.c[s]), float(S.h[s] + 0.15 * A)
    ann = [zone(R, R + 0.9 * A, r(G[0]), r(s), col="up", op=0.08, label="BSL (buy-side liquidity)", show=r(G[1])),
           hline(R, r(G[0]), col="gold", tag="RESIST", show=r(G[1])),
           *[label(r(g), S.h[g], f"EQH {q + 1}") for q, g in enumerate(G)],
           hline(S.l[mli], r(mli), r(mss), col="vio", dash="", show=r(mli) + 1),
           label(r(mli), S.l[mli], "low kecil", col="vio", pos="below", show=r(mli) + 1),
           label(r(mss), S.l[mli], "ditembus = MSS ✓", col="vio", pos="below", pill=True, anchor="start"),
           hline(low, r(lowi), col="dn", tag="LOW RANGE", show=r(G[1])),
           box(r(s)), label(r(s), S.h[s], "FAKEOUT: tembus atas, close balik ✗", pill=True, anchor="end", show=r(s) + 1),
           zone(entry, low, r(s) + 1, col="up", show=r(s) + 2, op=0.08), zone(sl, entry, r(s) + 1, col="dn", show=r(s) + 2, op=0.08),
           hline(entry, r(s) + 1, col="blue", dash="", tag="SELL", show=r(s) + 2), hline(sl, r(s) + 1, col="dn", dash="", tag="SL", show=r(s) + 2),
           label(r(tgt), S.l[tgt], "✅ TP kena", col="#36e3a1", pos="below", pill=True)]
    steps = [["Konteks", "Harga naik lalu mulai mendatar di bawah 'atap'.", "", 0],
             ["EQH & BSL", f"High di level yang sama tersentuh {len(G)}× (≈ {R:.6g}) = EQUAL HIGHS (EQH) → resistance jelas.",
              "Di atas EQH menumpuk SL penjual & BUY STOP trader breakout = BSL (buy-side liquidity, area hijau). Pemain besar yang ingin JUAL butuh order beli ini.", r(G[0])],
             ["Distribusi di bawah atap", "Harga berputar di bawah resistance: pemain besar diam-diam membagikan (DISTRIBUSI) posisi ke pembeli yang terlambat.", "", r(mli) + 1],
             ["Tembus ke atas…", "Ekor candle menembus resistance → buy stop & SL penjual kena = order BELI market. Terlihat seperti breakout!",
              "Order beli itu dipakai pemain besar untuk mengisi JUAL dalam jumlah besar.", r(s)],
             ["FAKEOUT", "Candle CLOSE lagi di bawah resistance → breakout PALSU = FAKEOUT. Pembeli breakout terjebak.", "", r(s) + 1],
             ["Ide entry SELL", f"Agresif: SELL di close candle fakeout ({entry:.6g}). SL di atas ujung ekor ({sl:.6g}). TP di low range ({low:.6g}).",
              "Konservatif: tunggu low kecil (garis ungu) ditembus dulu (MSS).", r(s) + 2],
             ["MSS & ke target", "Low kecil ditembus → struktur berubah turun (MSS), harga turun ke low range (likuiditas di bawah = SSL) → TP kena.", "", r(mss)]]
    return scenario(S, a0, C, "Fakeout di resistance (sapuan BSL)", steps, ann, slow=[r(s)], pause=[r(G[-1]) + 1, r(s) + 1, r(s) + 2])


# ------------------------------------------------------------------ 9. range -> compression -> breakout -> expansion
def find_range(S):
    """Range 40-70 candle selebar 2.5-6 ATR dengan >= 2 sentuhan atap (EQH) & lantai (EQL), ditembus close lalu bergerak
    >= 2.5 ATR dalam 5 candle (displacement). Compression = rata-rata panjang candle sepertiga akhir < 75% sepertiga awal."""
    hi_i, lo_i = pivots(S.h, S.l, 2)
    out = []
    for b in range(90, S.n - 25):
        A = S.a[b]
        if not A > 0:
            continue
        for W in (70, 55, 40):
            a = b - W
            top, bot = S.h[a:b].max(), S.l[a:b].min()
            if not 2.5 * A <= top - bot <= 6 * A:
                continue
            up = S.c[b] > top + 0.15 * A and S.c[b - 1] <= top
            dn = S.c[b] < bot - 0.15 * A and S.c[b - 1] >= bot
            if not (up or dn):
                continue
            ext = (S.h[b:b + 5].max() - top) if up else (bot - S.l[b:b + 5].min())
            if ext < 2.5 * A:
                continue
            hold = S.c[b:b + 13]
            if (up and hold.min() < top - 0.2 * A) or (dn and hold.max() > bot + 0.2 * A):
                continue                                   # harus bertahan di luar range (expansion sungguhan)
            th = sorted(int(i) for i in hi_i if a <= i < b - 2 and S.h[i] >= top - 0.35 * A)
            tl = sorted(int(i) for i in lo_i if a <= i < b - 2 and S.l[i] <= bot + 0.35 * A)
            if len(th) < 2 or len(tl) < 2:
                continue
            third = W // 3
            r1 = (S.h[a:a + third] - S.l[a:a + third]).mean()
            r3 = (S.h[b - third:b] - S.l[b - third:b]).mean()
            comp = bool(r3 < 0.75 * r1)
            out.append({"b": b, "a": a, "top": float(top), "bot": float(bot), "up": bool(up), "th": th, "tl": tl, "comp": comp,
                        "end": min(S.n - 1, b + 25), "score": len(th) + len(tl) + comp * 4 + ext / A - abs(W - 55) / 30})
            break
    return out


def build_range(S, x):
    a, b, top, bot, up = x["a"], x["b"], x["top"], x["bot"], x["up"]
    mid, third = (top + bot) / 2, (b - a) // 3
    a0, C = S.window(a - 35, x["end"] + 3)
    r = lambda i: i - a0                                    # noqa: E731
    s0 = r(max(x["th"][1], x["tl"][1])) + 2                 # range baru terlihat setelah atap & lantai tersentuh 2x
    phase = "AKUMULASI" if up else "DISTRIBUSI"
    ann = [zone(top, bot, r(a), r(b), col="mut", op=0.06, label=f"RANGE / KONSOLIDASI ({phase})", show=s0),
           hline(top, r(a), r(b), col="dn", dash="5 4", tag="RANGE HIGH", show=s0), hline(bot, r(a), r(b), col="up", dash="5 4", tag="RANGE LOW", show=s0),
           hline(mid, r(a), r(b), col="mut", dash="2 4", tag="EQ 50%", show=s0 + 1),
           *[label(r(i), S.h[i], "EQH", col="dn", show=max(r(i), s0)) for i in x["th"]],
           *[label(r(i), S.l[i], "EQL", col="up", pos="below", show=max(r(i), s0)) for i in x["tl"]],
           box(r(b), col="up" if up else "dn"),
           label(r(b), S.h[b] if up else S.l[b], "BREAKOUT + DISPLACEMENT", col="up" if up else "dn", pos="above" if up else "below",
                 pill=True, anchor="end", show=r(b) + 1),
           label(min(r(x["end"]) - 4, r(b) + 12), S.h[b:x["end"]].max() if up else S.l[b:x["end"]].min(), "EXPANSION", col="up" if up else "dn",
                 pos="above" if up else "below", pill=True, show=r(b) + 5)]
    steps = [["Konteks", "Perhatikan saat harga berhenti bergerak searah dan mulai mondar-mandir.", "", 0],
             ["Range / Konsolidasi", "Harga mondar-mandir di antara atap & lantai yang sama = RANGE, disebut juga KONSOLIDASI. Pembeli & penjual sedang seimbang.",
              f"Range sering jadi tempat pemain besar {'mengumpulkan posisi beli = AKUMULASI' if up else 'membagikan posisi = DISTRIBUSI'} sebelum harga bergerak jauh.", s0],
             ["EQH, EQL & dealing range", "Puncak-puncak sejajar = EQH, lembah-lembah sejajar = EQL → likuiditas di kedua sisi range. Range ini juga DEALING RANGE: garis EQ 50% memisahkan bagian atas (premium) & bawah (discount).",
              "", s0 + 1]]
    ci = max(r(b - third), s0 + 2)
    if x["comp"] and ci < r(b):
        ann.append(zone(top, bot, r(b - third), r(b), col="vio", op=0.12, label="COMPRESSION (menyempit)", show=ci))
        steps.append(["Compression", "Candle makin kecil, gerak makin sempit = COMPRESSION: energi dikumpulkan sebelum bergerak.",
                      "Sesudah compression biasanya datang gerak besar — arahnya baru diketahui saat breakout.", ci])
    steps += [["Breakout + displacement", f"Candle CLOSE menembus {'atap' if up else 'lantai'} range dengan gerak besar & cepat (DISPLACEMENT).",
               "Close di luar range = breakout sah; kalau cuma ekor lalu kembali ke dalam = fakeout.", r(b)],
              ["Expansion", f"Harga bergerak jauh {'ke atas' if up else 'ke bawah'} meninggalkan range = EXPANSION.",
               "Siklus pasar: konsolidasi → compression → expansion → konsolidasi lagi.", r(b) + 2]]
    return scenario(S, a0, C, f"Range → breakout {'naik (akumulasi)' if up else 'turun (distribusi)'}", steps, ann, slow=[r(b)],
                    pause=[s0 + 1, r(b) + 1])


def find_range_up(S):
    return [x for x in find_range(S) if x["up"]]


def find_range_dn(S):
    return [x for x in find_range(S) if not x["up"]]


# ------------------------------------------------------------------ 10. premium, discount & OTE
def find_pd(S):
    return [dict(x, score=-abs(x["rt"] - 0.705) * 10 - (x["brk"] - x["i0"]) / 60) for x in find_fib(S) if 0.62 <= x["rt"] <= 0.79]


def build_pd(S, x):
    a0, C = S.window(x["i0"] - 30, x["end"] + 5)
    r = lambda k: k - a0                                    # noqa: E731
    p0, p1 = x["p0"], x["p1"]
    eq, o_hi, o_lo = (p0 + p1) / 2, p1 - (p1 - p0) * 0.62, p1 - (p1 - p0) * 0.79
    show = r(x["c1"])
    end = r(x["brk"])
    ann = [hline(p1, r(x["i0"]), col="dn", dash="", tag="RANGE HIGH", show=show, w=1), hline(p0, r(x["i0"]), col="up", dash="", tag="RANGE LOW", show=show, w=1),
           zone(p1, eq, r(x["i1"]), end, col="dn", op=0.07, label="PREMIUM (mahal) → tempat SELL", show=show + 1),
           zone(eq, p0, r(x["i1"]), end, col="up", op=0.07, label="DISCOUNT (murah) → tempat BUY", show=show + 1),
           hline(eq, r(x["i0"]), col="mut", dash="4 4", tag="EQ 50%", show=show),
           zone(o_hi, o_lo, r(x["i1"]), end, col="gold", op=0.18, label="OTE 0.62–0.79", show=show + 2),
           label(r(x["i2"]), x["p2"], f"masuk OTE ({x['rt'] * 100:.0f}%) → mantul ✓", pos="below", pill=True, anchor="start", show=r(x["c2"])),
           label(r(x["brk"]), p1, "tembus range high ✓", col="up", pill=True, show=r(x["brk"]))]
    steps = [["Konteks", "Perhatikan dorongan naik yang kuat.", "", 0],
             ["Dealing range", f"Dari low dorongan ({p0:.6g}) ke high-nya ({p1:.6g}) = DEALING RANGE: area harga yang sedang 'diperdagangkan'.",
              "Garis tengahnya = EQ 50% (equilibrium, harga 'wajar').", show],
             ["Premium & Discount", "Di atas EQ = PREMIUM (harga mahal, tempat mencari SELL). Di bawah EQ = DISCOUNT (harga murah, tempat mencari BUY).",
              "Dalam tren naik: tunggu harga turun ke discount, jangan BUY di premium. Kumpulan zona (OB, FVG, dll.) di premium/discount = PDA (Premium/Discount Array).", show + 1],
             ["OTE (Optimal Trade Entry)", "Bagian terdalam discount, 0.62–0.79 dari range = OTE: entry dengan risiko kecil & target jauh.", "", show + 2],
             ["Masuk OTE → mantul", f"Pullback berhenti di ±{x['rt'] * 100:.0f}% (di dalam OTE) lalu harga berbalik naik.",
              "Ide entry: BUY di OTE, SL di bawah range low, TP di/atas range high.", r(x["c2"])],
             ["Lanjut", "Harga menembus range high → tren lanjut.", "", r(x["brk"])]]
    return scenario(S, a0, C, "Premium, Discount & OTE", steps, ann, slow=[r(x["i2"])], pause=[show + 2, r(x["c2"]) + 1])


# ------------------------------------------------------------------ 11. supply & demand zone
def find_demand(S):
    """Drop-base-rally: 2-5 candle kecil (badan <= 0.6 ATR, lebar total <= 1.6 ATR) sesudah turun >= 1.5 ATR, lalu candle
    naik besar & reli >= 3 ATR dalam 4 candle. Harga kembali ke zona (>= 6 candle kemudian), bertahan, lalu naik >= 2 ATR."""
    out = []
    for j in range(30, S.n - 70):
        A = S.a[j]
        if not A > 0:
            continue
        for k in (2, 3, 4, 5):
            bs = slice(j, j + k)
            if np.abs(S.c[bs] - S.o[bs]).max() > 0.6 * A or S.h[bs].max() - S.l[bs].min() > 1.6 * A:
                continue
            zt, zb, e = float(S.h[bs].max()), float(S.l[bs].min()), j + k
            if S.h[j - 6:j].max() - zb < 1.5 * A or S.c[e] <= S.o[e] or S.c[e] - S.o[e] < A or S.h[e:e + 4].max() - zt < 3 * A:
                continue
            t = next((m for m in range(e + 6, min(S.n, e + 70)) if S.l[m] <= zt), None)
            if t is None or S.c[e:t + 1].min() < zb or S.l[t] < zb - 0.2 * A:
                continue
            up = S.h[t:min(S.n, t + 30)].max()
            if up - S.l[t] < 2 * A or S.l[t:t + 25].min() < zb:
                continue
            out.append({"j": j, "k": k, "e": e, "touch": t, "end": min(S.n - 1, t + 30),
                        "score": (S.h[e:e + 4].max() - zt) / A + (up - S.l[t]) / A + k * 0.5 - (t - e) / 30})
            break
    return out


def _build_sd(S, x, supply):
    j, k, e, t = x["j"], x["k"], x["e"], x["touch"]
    zt, zb = float(S.h[j:j + k].max()), float(S.l[j:j + k].min())
    a0, C = S.window(j - 60, x["end"] + 5)
    r = lambda i: i - a0                                    # noqa: E731
    nm, col = ("SUPPLY ZONE", "dn") if supply else ("DEMAND ZONE", "up")
    leg = S.l[e:e + 4].min() if supply else S.h[e:e + 4].max()
    ann = [zone(zt, zb, r(j), r(t) + 1, col=col, op=0.17, label=nm, show=r(e) + 1),
           label(r(j) + k // 2, zt if supply else zb, "BASE", col=col, pos="above" if supply else "below", show=r(e) + 1),
           label(r(e) + 1, leg, "DROP (leg out)" if supply else "RALLY (leg out)", col=col, pos="below" if supply else "above", pill=True, show=r(e) + 2),
           label(r(t), S.h[t] if supply else S.l[t], "kembali ke zona → ditolak ✓" if supply else "kembali ke zona → mantul ✓", col=col,
                 pos="above" if supply else "below", pill=True, anchor="start", show=r(t) + 1)]
    steps = [["Konteks", f"Perhatikan harga {'naik' if supply else 'turun'} lalu berhenti sebentar.", "", 0],
             ["Base", "Beberapa candle kecil berdempetan = BASE: keseimbangan sesaat sebelum gerak besar.", "", r(j)],
             ["Leg out", f"Dari base, harga {'anjlok' if supply else 'meroket'} dengan candle besar → order {'jual' if supply else 'beli'} besar masuk di base.", "", r(e)],
             [nm, f"Area base itu = {nm}: zona tempat {'penawaran (penjual)' if supply else 'permintaan (pembeli)'} besar muncul. Pola: "
                  f"{'RALLY – BASE – DROP' if supply else 'DROP – BASE – RALLY'}.",
              "Mirip order block, tapi zonanya seluruh base (beberapa candle), bukan satu candle.", r(e) + 1],
             ["Kembali ke zona", f"Harga {'naik' if supply else 'turun'} kembali ke dalam zona …", "", r(t)],
             ["Reaksi", f"… lalu {'ditolak turun' if supply else 'mantul naik'}. Ide entry: {'SELL' if supply else 'BUY'} di zona, SL di {'atas' if supply else 'bawah'} zona.",
              "Close menembus zona = zona gagal (sisa order sudah habis).", r(t) + 1]]
    return scenario(S, a0, C, f"{'Supply' if supply else 'Demand'} Zone", steps, ann, slow=[r(t)], pause=[r(e) + 1, r(t) + 1])


def build_demand(S, x):
    return _build_sd(S, x, False)


def build_supply(S, x):
    return _build_sd(S, x, True)


# ------------------------------------------------------------------ 12. breaker & mitigation block
def find_failed_ob(S):
    """OB bullish (dorongan >= 3 ATR menembus high 20 candle) yang kemudian GAGAL: close < bawah OB - 0.3 ATR. Lalu harga
    menguji zona dari bawah (high >= bawah OB, tanpa close di atas OB) dan turun >= 2.5 ATR. Breaker = sebelum gagal sempat
    membuat high baru (sapu likuiditas atas); mitigation = gagal membuat high baru (lower high)."""
    out = []
    for i in range(30, S.n - 80):
        A = S.a[i]
        if not (A > 0 and S.c[i] < S.o[i]):
            continue
        j4 = i + 4
        legh = S.h[i + 1:j4 + 1].max()
        if S.c[i + 1] <= S.o[i + 1] or legh - S.l[i] < 3 * A or legh <= S.h[i - 20:i].max():
            continue
        top, bot = float(max(S.o[i], S.c[i])), float(S.l[i])
        if top - bot < 0.5 * A:
            continue
        brk = next((m for m in range(j4 + 3, min(S.n, j4 + 70)) if S.c[m] < bot - 0.3 * A), None)
        if brk is None:
            continue
        pk = j4 + int(np.argmax(S.h[j4:brk]))
        if pk <= j4 + 1:
            continue
        rt = next((m for m in range(brk + 1, min(S.n, brk + 30)) if S.h[m] >= bot), None)
        if rt is None or S.c[brk + 1:rt + 1].max() > top:
            continue
        drop = S.h[rt] - S.l[rt:min(S.n, rt + 30)].min()
        if drop < 2.5 * A:
            continue
        w0, w1 = max(0, i - 50), min(S.n, rt + 20)
        if (S.h[w0:w1] - S.l[w0:w1]).max() > 5 * A:
            continue                                       # ada candle ekstrem -> bagian penting tergencet di chart
        kind = "breaker" if S.h[pk] > legh + 0.2 * A else "mitigation"
        out.append({"i": i, "top": top, "bot": bot, "pk": pk, "brk": brk, "rt": rt, "kind": kind, "end": min(S.n - 1, rt + 20),
                    "score": drop / A - (brk - i) / 30})
    return out


def find_breaker(S):
    return [x for x in find_failed_ob(S) if x["kind"] == "breaker"]


def find_mitigation(S):
    return [x for x in find_failed_ob(S) if x["kind"] == "mitigation"]


def build_failed_ob(S, x):
    i, pk, brk, rt, top, bot = x["i"], x["pk"], x["brk"], x["rt"], x["top"], x["bot"]
    br = x["kind"] == "breaker"
    nm = "BREAKER BLOCK" if br else "MITIGATION BLOCK"
    a0, C = S.window(i - 50, x["end"] + 3)
    r = lambda k: k - a0                                    # noqa: E731
    ann = [zone(top, bot, r(i), r(brk), col="cyan", op=0.16, label="ORDER BLOCK (bullish)", show=r(i) + 2),
           zone(top, bot, r(brk), r(rt) + 6, col="dn", op=0.2, label=nm, show=r(brk) + 1),
           label(r(pk), S.h[pk], "high baru (sapu BSL)" if br else "gagal buat high baru (lower high)", col="up" if br else "gold", pill=True, show=r(pk) + 2),
           box(r(brk), col="dn"), label(r(brk), S.l[brk], "close di bawah OB → OB gagal", col="dn", pos="below", pill=True, anchor="start", show=r(brk) + 1),
           label(r(rt), S.h[rt], "retest dari bawah → ditolak ✓", col="dn", pill=True, show=r(rt) + 1)]
    steps = [["Konteks", "Perhatikan dorongan naik yang kuat — dan apa yang terjadi kalau zona asalnya tidak bertahan.", "", 0],
             ["Order block terbentuk", "Candle turun terakhir sebelum dorongan naik = order block bullish (kotak biru).", "", r(i) + 2],
             (["Sapu high", "Harga sempat membuat high baru — menyapu likuiditas di atas (BSL) …", "", r(pk) + 2] if br else
              ["Gagal membuat high baru", "Harga naik lagi tapi TIDAK mampu melewati high sebelumnya (lower high) → pembeli melemah.", "", r(pk) + 2]),
             ["OB gagal", "… lalu harga turun dan CLOSE di bawah order block. Pembeli di OB itu sekarang rugi (terjebak).", "", r(brk)],
             [nm, ("OB yang gagal SESUDAH high disapu = BREAKER BLOCK. Fungsinya berbalik: dari support menjadi RESISTANCE." if br else
                   "OB yang gagal TANPA membuat high baru = MITIGATION BLOCK. Fungsinya juga berbalik menjadi resistance."),
              "Pembeli yang terjebak ingin keluar impas (mitigasi kerugian) saat harga kembali ke zona → muncul tekanan jual.", r(brk) + 1],
             ["Retest → ditolak", "Harga naik menguji zona dari bawah, lalu ditolak turun.", f"Ide entry: SELL di zona {nm.lower()}, SL di atas zona.", r(rt)],
             ["Lanjut turun", "Zona yang berbalik fungsi menahan harga, tren turun berlanjut.", "", r(rt) + 1]]
    return scenario(S, a0, C, nm.title(), steps, ann, slow=[r(brk), r(rt)], pause=[r(brk) + 1, r(rt) + 1])


# ------------------------------------------------------------------ 13. inducement (IDM)
def find_idm(S):
    """OB yang berhasil (find_ob) dengan low kecil (swing 2) di antara dorongan dan sentuhan OB, berada >= 0.3 ATR di atas
    OB, lalu ditembus sebelum harga sampai di OB = inducement tersapu."""
    _, lo_i = pivots(S.h, S.l, 2)
    out = []
    for x in find_ob(S):
        i, t, top = x["i"], x["touch"], x["top"]
        A = S.a[i]
        for m in lo_i:
            if not (i + 6 <= m <= t - 4 and S.l[m] > top + 0.3 * A):
                continue
            q = next((k for k in range(m + 3, t + 1) if S.l[k] < S.l[m]), None)
            if q is None or q >= t:
                continue
            out.append(dict(x, m=int(m), q=int(q), score=x["score"] + 2))
            break
    return out


def build_idm(S, x):
    sc = build_ob(S, x)
    a0 = int(S.t.searchsorted(sc["C"][0][0]))
    r = lambda k: k - a0                                    # noqa: E731
    m, q = x["m"], x["q"]
    sc["ann"] += [hline(S.l[m], r(m), r(q), col="gold", dash="3 3", show=r(m) + 2, w=1.2),
                  label(r(m), S.l[m], "IDM", col="gold", pos="below", pill=True, show=r(m) + 2),
                  label(r(q), S.l[q], "IDM tersapu → pembeli awal kena SL", col="gold", pos="below", pill=True, anchor="start", show=r(q) + 1)]
    st = [s_ for s_ in sc["steps"] if s_[3] < r(m) + 2]
    st += [["Inducement (IDM)", "Dalam perjalanan turun ke OB, harga membuat low kecil (garis kuning) = INDUCEMENT: 'umpan' agar trader BUY terlalu cepat di sini.",
            "SL mereka ada di bawah low kecil itu — likuiditas tambahan yang dibutuhkan pemain besar sebelum harga sampai di POI.", r(m) + 2],
           ["IDM tersapu", "Harga menembus low kecil → pembeli yang masuk terlalu cepat kena SL.", "Pelajaran: tunggu harga sampai di POI (OB), jangan masuk di inducement.", r(q)],
           ["Sampai di POI → mantul", "Sesudah IDM tersapu, harga menyentuh order block (POI) dan berbalik naik.", "", r(x["touch"])],
           ["Lanjut naik", "", "", r(x["touch"]) + 1]]
    sc["steps"] = st
    sc["title"] = "Inducement (IDM) → POI"
    sc["slow"] = sorted(set(sc["slow"] + [r(q)]))
    sc["pause"] = sorted(set(sc["pause"] + [r(q) + 1]))
    return sc


# ------------------------------------------------------------------ kamus 50 istilah -> (topik, contoh, judul langkah)
GLOSSARY = [
    ("Market Structure (MS)", "Urutan titik balik harga (swing high & swing low) yang menunjukkan siapa yang menguasai pasar.", "structure", 0, "Swing High"),
    ("Trend", "Arah utama harga. Naik = HH + HL, turun = LH + LL.", "structure", 0, "Tren naik"),
    ("Support", "'Lantai' tempat harga berkali-kali tertahan naik karena pembeli menunggu di sana.", "flip", 0, "Resistance"),
    ("Resistance", "'Atap' tempat harga berkali-kali ditolak turun karena penjual menunggu di sana.", "flip", 0, "Resistance"),
    ("Swing High", "Puncak: high yang lebih tinggi dari candle-candle di kiri & kanannya.", "structure", 0, "Swing High"),
    ("Swing Low", "Lembah: low yang lebih rendah dari candle-candle di kiri & kanannya.", "structure", 0, "Swing High"),
    ("Higher High (HH)", "Puncak baru yang lebih tinggi dari puncak sebelumnya — ciri tren naik.", "structure", 0, "Tren naik"),
    ("Higher Low (HL)", "Lembah baru yang lebih tinggi dari lembah sebelumnya — ciri tren naik.", "structure", 0, "Tren naik"),
    ("Lower High (LH)", "Puncak baru yang lebih rendah dari puncak sebelumnya — ciri tren turun.", "structure", 0, "Setelah CHoCH"),
    ("Lower Low (LL)", "Lembah baru yang lebih rendah dari lembah sebelumnya — ciri tren turun.", "structure", 0, "Setelah CHoCH"),
    ("Breakout", "Candle CLOSE menembus level penting (support/resistance/range).", "flip", 0, "Breakout"),
    ("Retest", "Harga kembali menguji level yang baru saja ditembus.", "flip", 0, "Retest"),
    ("Fakeout", "Breakout palsu: harga menembus level, lalu close kembali ke dalam.", "fakeout", 0, "FAKEOUT"),
    ("Reversal", "Pembalikan arah tren (mis. dari naik menjadi turun).", "structure", 0, "CHoCH"),
    ("Pullback", "Gerak mundur sementara melawan tren sebelum tren berlanjut.", "fib", 0, "Pullback"),
    ("Retracement", "Ukuran seberapa dalam pullback, biasanya dengan Fibonacci (0.382, 0.5, 0.618, 0.786).", "fib", 0, "Pullback"),
    ("Consolidation", "Harga bergerak menyamping dalam rentang sempit; pembeli & penjual seimbang.", "range", 0, "Range"),
    ("Range", "Area harga di antara atap & lantai yang sama, tempat harga mondar-mandir.", "range", 0, "Range"),
    ("Liquidity", "Kumpulan order yang menunggu (stop loss, buy/sell stop) di sekitar high & low yang jelas.", "sweep", 0, "Likuiditas"),
    ("Liquidity Sweep", "Harga menembus sebentar area likuiditas untuk memicu order-order itu, lalu berbalik.", "sweep", 0, "SWEEP"),
    ("Stop Hunt", "Gerak harga yang 'memburu' stop loss di balik high/low yang jelas.", "sweep", 0, "SWEEP"),
    ("Equal High (EQH)", "Beberapa puncak di level hampir sama — ada likuiditas (BSL) di atasnya.", "fakeout", 0, "EQH"),
    ("Equal Low (EQL)", "Beberapa lembah di level hampir sama — ada likuiditas (SSL) di bawahnya.", "sweep", 0, "Likuiditas"),
    ("Break of Structure (BOS)", "Close menembus swing searah tren → tren berlanjut.", "structure", 0, "Tren naik"),
    ("Change of Character (CHoCH)", "Close menembus swing terakhir yang menjaga tren → tren berubah arah.", "structure", 0, "CHoCH"),
    ("Market Structure Shift (MSS)", "Perubahan struktur yang dikonfirmasi tembusnya high/low kecil, sering sesudah sweep.", "sweep", 0, "MSS"),
    ("Order Block (OB)", "Candle berlawanan terakhir sebelum dorongan kuat; zona tempat pemain besar diperkirakan masuk.", "ob", 0, "Order Block"),
    ("Fair Value Gap (FVG)", "Celah 3 candle (low candle 3 > high candle 1 atau sebaliknya) akibat gerak sangat cepat.", "fvg", 0, "3 candle"),
    ("Supply Zone", "Zona base sebelum harga anjlok; tempat penjual besar muncul.", "sd", 1, "SUPPLY"),
    ("Demand Zone", "Zona base sebelum harga meroket; tempat pembeli besar muncul.", "sd", 0, "DEMAND"),
    ("Displacement", "Gerak besar & cepat satu arah (beberapa candle besar) tanda order besar masuk.", "ob", 0, "Displacement"),
    ("Imbalance (IMB)", "Ketidakseimbangan beli/jual yang meninggalkan celah harga — sama dengan FVG.", "fvg", 0, "3 candle"),
    ("Premium Zone", "Bagian atas dealing range (di atas 50%): harga mahal, tempat mencari SELL.", "pd", 0, "Premium"),
    ("Discount Zone", "Bagian bawah dealing range (di bawah 50%): harga murah, tempat mencari BUY.", "pd", 0, "Premium"),
    ("PDA (Premium Discount Array)", "Kumpulan zona (OB, FVG, dll.) yang dinilai berdasarkan posisinya di premium atau discount.", "pd", 0, "Premium"),
    ("Point of Interest (POI)", "Zona yang ditandai & ditunggu untuk entry (mis. OB, FVG, demand).", "ob", 0, "Order Block"),
    ("Breaker Block", "Order block yang gagal sesudah high disapu, lalu berbalik fungsi (support → resistance).", "breaker", 0, "BREAKER"),
    ("Mitigation Block", "Order block yang gagal tanpa membuat high baru, lalu berbalik fungsi.", "breaker", 1, "MITIGATION"),
    ("Rejection Block", "Area ekor panjang tempat harga ditolak keras.", "sweep", 0, "Close kembali"),
    ("Inducement (IDM)", "'Umpan': high/low kecil sebelum POI yang memancing trader masuk terlalu cepat, lalu disapu.", "ob", 1, "Inducement"),
    ("Dealing Range", "Rentang dari swing low ke swing high yang sedang diperdagangkan; dibagi premium & discount.", "pd", 0, "Dealing range"),
    ("Consequent Encroachment (CE)", "Titik tengah (50%) sebuah FVG.", "fvg", 0, "3 candle"),
    ("Optimal Trade Entry (OTE)", "Zona 0.62–0.79 retracement: entry dengan risiko kecil searah tren.", "pd", 0, "OTE"),
    ("Buy Side Liquidity (BSL)", "Likuiditas di atas high (SL penjual & buy stop).", "fakeout", 0, "EQH"),
    ("Sell Side Liquidity (SSL)", "Likuiditas di bawah low (SL pembeli & sell stop).", "sweep", 0, "Likuiditas"),
    ("Accumulation", "Fase range ketika pemain besar mengumpulkan posisi beli sebelum harga naik.", "range", 0, "Range"),
    ("Distribution", "Fase range ketika pemain besar membagikan/menjual posisi sebelum harga turun.", "range", 1, "Range"),
    ("Expansion", "Gerak besar meninggalkan range/konsolidasi.", "range", 0, "Expansion"),
    ("Compression", "Gerak harga makin sempit (candle makin kecil) sebelum gerak besar.", "range", 0, "Compression"),
    ("Mean Threshold", "Titik tengah (50%) badan candle order block.", "ob", 0, "Order Block"),
]


TOPICS = [
    ("sweep", "💧 Liquidity Sweep", "Harga sengaja menyapu stop loss di bawah support, lalu berbalik. (Likuiditas, EQL, SSL, stop hunt, rejection block, MSS)",
     [(find_sweep, build_sweep), (find_breakdown, build_breakdown)]),
    ("fakeout", "🎭 Fakeout & BSL", "Breakout palsu di resistance: likuiditas di atas EQH (BSL) disapu, lalu harga turun.",
     [(mirrored(find_sweep), build_fakeout)]),
    ("structure", "🧱 Market Structure", "Swing high/low, tren (HH/HL, LH/LL), BOS (tren lanjut) & CHoCH (reversal).", [(find_structure, build_structure)]),
    ("range", "📦 Range & Expansion", "Konsolidasi/range, EQH-EQL, dealing range, compression, breakout + displacement, expansion, akumulasi & distribusi.",
     [(lambda S: [x for x in find_range_up(S) if x["comp"]], build_range), (find_range_dn, build_range)]),
    ("ob", "🟦 Order Block & IDM", "Order block (POI), displacement, mean threshold — dan inducement sebelum POI.", [(find_ob, build_ob), (find_idm, build_idm)]),
    ("fvg", "🩷 Fair Value Gap", "Celah 3 candle (imbalance) & CE 50%, sering diisi kembali.", [(find_fvg, build_fvg)]),
    ("sd", "🟩 Supply & Demand", "Zona base sebelum gerak besar: demand (drop-base-rally) & supply (rally-base-drop).",
     [(find_demand, build_demand), (mirrored(find_demand), build_supply)]),
    ("breaker", "🔻 Breaker & Mitigation", "Order block yang gagal lalu berbalik fungsi menjadi resistance.", [(find_breaker, build_failed_ob), (find_mitigation, build_failed_ob)]),
    ("flip", "🔁 Support / Resistance Flip", "Support, resistance, breakout, retest: resistance yang ditembus menjadi support.", [(find_flip, build_flip)]),
    ("fib", "📐 Fibonacci Retracement", "Pullback & retracement: seberapa dalam koreksi untuk mencari entry searah tren.", [(find_fib, build_fib)]),
    ("pd", "⚖️ Premium, Discount & OTE", "Dealing range, equilibrium 50%, premium/discount (PDA) & OTE 0.62–0.79.", [(find_pd, build_pd)]),
    ("elliott", "🌊 Elliott Wave", "Impuls 5 gelombang + koreksi A-B-C dengan aturan baku.", [(find_elliott, build_elliott)]),
]
PIN = {("sweep", 0): ("ETHUSDT_1h", 1793761200000), ("sweep", 1): ("ETHUSDT_1h", 1793304000000)}   # contoh yang sudah disetujui


MIN_FILL = 0.06                                         # median tinggi candle >= 6% tinggi chart (candle tidak kekecilan)


def _key(x):
    return x.get("s", x.get("i", x.get("i1", x.get("b", x.get("j", 0)))))


def _fill(sc):
    if isinstance(sc, list):                            # builder yang menghasilkan beberapa contoh sekaligus
        sc = sc[0]
    C = np.array(sc["C"], float)
    return float(np.median(C[:, 2] - C[:, 3]) / max(1e-12, C[:, 2].max() - C[:, 3].min()))


def build_all(folder):
    series = [Series(p) for p in sorted(glob.glob(os.path.join(folder, "*_*.json")))]
    topics, used = [], set()
    from tools.edu_ind import TOPICS_IND                # topik indikator, pola & alat (file terpisah)
    allt = [(k, t, d, "Price Action & SMC", p) for k, t, d, p in TOPICS] + list(TOPICS_IND)
    for key, title, desc, group, parts in allt:
        scns = []
        if group != "Price Action & SMC":
            used = set()                                    # topik indikator/pola: contoh boleh sama dengan topik lain, tidak dalam 1 topik
        for pi, (finder, builder) in enumerate(parts):
            pin, cands = PIN.get((key, pi)), []
            for S in series:
                for x in finder(S):
                    ki = _key(x)
                    if any(nm_ == S.name and abs(int(ki) - k_) < 80 for nm_, k_ in used):
                        continue                            # kejadian yang sama / berdekatan tidak dipakai 2x
                    cands.append((S, x))
            pinned = [c for c in cands if pin and c[0].name == pin[0] and int(c[0].t[_key(c[1])]) == pin[1]]
            pick = None
            if pinned:
                pick = (pinned[0], builder(*pinned[0]))
            else:                                           # skor tertinggi yang candle-nya cukup BESAR di layar
                fallback = None
                for c in sorted(cands, key=lambda c: -c[1]["score"])[:60]:
                    sc = builder(*c)
                    f = _fill(sc)
                    if f >= MIN_FILL:
                        pick = (c, sc)
                        break
                    if fallback is None or f > fallback[2]:
                        fallback = (c, sc, f)
                if pick is None and fallback:
                    pick = fallback[:2]
            if pick:
                (S, x), sc = pick
                used.add((S.name, int(_key(x))))
                scns.extend(sc if isinstance(sc, list) else [sc])
        topics.append({"key": key, "title": title, "desc": desc, "group": group, "scenarios": scns})
        print(f"{title}: {len(scns)}/{len(parts)} contoh " + ", ".join(f"{s_['sym']} {s_['tf']} ({len(s_['C'])} candle)" for s_ in scns))
    gloss = []
    for no, (term, d, key, si, step) in enumerate(GLOSSARY, 1):
        g = {"no": no, "term": term, "def": d, "topic": None, "scn": si, "step": None}
        ti = next((q for q, t in enumerate(topics) if t["key"] == key), None)
        if ti is not None and si < len(topics[ti]["scenarios"]):
            stp = topics[ti]["scenarios"][si]["steps"]
            j = next((q for q, x in enumerate(stp) if x[0].lower().startswith(step.lower()) or step.lower() in x[0].lower()), None)
            if j is not None:
                g["topic"], g["step"] = ti, j
        if g["topic"] is None:
            print("  ⚠ istilah tanpa animasi:", term)
        gloss.append(g)
    return {"topics": topics, "glossary": gloss}


def download(folder, symbols=("BTCUSDT", "ETHUSDT", "SOLUSDT"), tfs=("1h", "15m"), limit=1500):
    """Unduh candle terbaru dari Binance Futures (butuh internet; kalau diblokir nyalakan VPN)."""
    from backend.screener import Client
    c = Client()
    os.makedirs(folder, exist_ok=True)
    for sym in symbols:
        for tf in tfs:
            k = c.get("/fapi/v1/klines", symbol=sym, interval=tf, limit=limit)
            rows = [[int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5])] for r in k[:-1]]   # tanpa candle berjalan
            with open(os.path.join(folder, f"{sym}_{tf}.json"), "w") as f:
                json.dump(rows, f)
            print("unduh", sym, tf, len(rows))


if __name__ == "__main__":
    if sys.argv[1:2] == ["--download"]:                   # python tools/edu_build.py --download [folder]
        src = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, "saved", "edu_src")
        download(src)
        sys.argv = [sys.argv[0], src]
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, "frontend", "edu_data.json")
    data = build_all(src)
    with open(dst, "w") as f:
        json.dump(data, f, separators=(",", ":"))
    print("ditulis:", dst, os.path.getsize(dst) // 1024, "KB")
