"""Cek kualitas data: gap, OHLC tidak wajar, dan konsistensi TF besar vs agregasi base TF (M5).

Pakai:  python tools/validate_data.py "D:\\Data Candle Binance\\all" [SIMBOL ...]
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.data import TF_MS, DataStore  # noqa: E402


def check_symbol(store, sym):
    base_tf = store.base_tf(sym)
    b = store.get(sym, base_tf)
    msgs = []
    for tf in store.file_timeframes(sym):
        a = store.get(sym, tf)
        gaps = int((np.diff(a.t) > TF_MS[tf]).sum())
        bad = int(((a.h < np.maximum(a.o, a.c)) | (a.l > np.minimum(a.o, a.c))).sum())
        line = f"  {tf:>4}: {len(a):>7} bar, gap={gaps}, ohlc_aneh={bad}"
        if tf != base_tf and len(a):
            # agregasi base -> tf, bandingkan hanya bucket yang base-nya lengkap
            k = TF_MS[tf] // TF_MS[base_tf]
            grp = (b.t // TF_MS[tf]) * TF_MS[tf]
            keys, start, cnt = np.unique(grp, return_index=True, return_counts=True)
            full = cnt == k
            keys, start = keys[full], start[full]
            idx = np.searchsorted(a.t, keys)
            ok = (idx < len(a)) & (a.t[np.minimum(idx, len(a) - 1)] == keys)
            idx, start = idx[ok], start[ok]
            end = start + k
            hi = np.array([b.h[s:e].max() for s, e in zip(start, end)])
            lo = np.array([b.l[s:e].min() for s, e in zip(start, end)])
            tol = 1e-9 * np.maximum(1, np.abs(a.c[idx]))
            mism = ((np.abs(a.o[idx] - b.o[start]) > tol) | (np.abs(a.c[idx] - b.c[end - 1]) > tol)
                    | (np.abs(a.h[idx] - hi) > tol) | (np.abs(a.l[idx] - lo) > tol))
            line += f", beda_vs_{base_tf}={int(mism.sum())}/{len(idx)}"
        msgs.append(line)
    return msgs


if __name__ == "__main__":
    data_dir = sys.argv[1] if len(sys.argv) > 1 else r"D:\Data Candle Binance\all"
    store = DataStore(data_dir, cache_size=8)
    syms = [s.upper() for s in sys.argv[2:]] or store.symbols()
    print(f"{len(store.symbols())} simbol di {data_dir}")
    for s in syms:
        info = store.info(s)
        print(s, "base", info["base_tf"], np.datetime64(info["start"], "ms"), "->", np.datetime64(info["end"], "ms"))
        print("\n".join(check_symbol(store, s)))
