"""📚 Info Trading — topik INDIKATOR, POLA & ALAT (dipakai tools/edu_build.py).

Semua contoh dicari otomatis dari candle ASLI dengan aturan tertulis di fungsi find_*. Indikator dihitung dari seluruh seri
(jadi sudah "panas" di awal potongan), lalu dipotong sesuai jendela contoh dan ikut terbentuk candle per candle di layar.
Garis di atas harga = `ov`, isi di antara dua garis = `band`, panel bawah = `pane` (anotasi panel memakai pn=1).
"""
import numpy as np

from tools.edu_build import COL, box, hline, label, pivots, seg, zone

# ------------------------------------------------------------------ rumus indikator (numpy, tanpa look-ahead)


def _first(x):
    ok = np.flatnonzero(np.isfinite(x))
    return int(ok[0]) if len(ok) else len(x)


def sma(x, n):
    x = np.asarray(x, float)
    out = np.full(len(x), np.nan)
    if len(x) >= n:
        cs = np.cumsum(np.insert(np.nan_to_num(x), 0, 0.0))
        out[n - 1:] = (cs[n:] - cs[:-n]) / n
        f = _first(x)
        out[:f + n - 1] = np.nan
    return out


def _smooth(x, alpha, seed_n):
    x = np.asarray(x, float)
    out = np.full(len(x), np.nan)
    f = _first(x)
    if f + seed_n > len(x):
        return out
    out[f + seed_n - 1] = np.mean(x[f:f + seed_n])
    for i in range(f + seed_n, len(x)):
        out[i] = out[i - 1] + alpha * (x[i] - out[i - 1])
    return out


def ema(x, n):
    return _smooth(x, 2.0 / (n + 1), n)


def rma(x, n):                                  # Wilder / SMMA
    return _smooth(x, 1.0 / n, n)


def wma(x, n):
    x = np.asarray(x, float)
    w = np.arange(1, n + 1, dtype=float)
    out = np.full(len(x), np.nan)
    for i in range(n - 1, len(x)):
        seg_ = x[i - n + 1:i + 1]
        if np.all(np.isfinite(seg_)):
            out[i] = float(seg_ @ w / w.sum())
    return out


def hma(x, n):
    return wma(2 * wma(x, n // 2) - wma(x, n), int(round(np.sqrt(n))))


def dema(x, n):
    e = ema(x, n)
    return 2 * e - ema(e, n)


def tema(x, n):
    e = ema(x, n)
    ee = ema(e, n)
    return 3 * e - 3 * ee + ema(ee, n)


def vwma(c, v, n):
    return sma(c * v, n) / sma(v, n)


def rsi(c, n=14):
    d = np.diff(c, prepend=np.nan)
    up, dn = rma(np.where(d > 0, d, 0.0), n), rma(np.where(d < 0, -d, 0.0), n)
    up[0] = dn[0] = np.nan
    with np.errstate(divide="ignore", invalid="ignore"):
        return 100 - 100 / (1 + up / dn)


def stoch(h, l, c, n=14, k=3, d=3):
    from numpy.lib.stride_tricks import sliding_window_view as sw
    hh, ll = np.full(len(c), np.nan), np.full(len(c), np.nan)
    hh[n - 1:], ll[n - 1:] = sw(h, n).max(1), sw(l, n).min(1)
    with np.errstate(divide="ignore", invalid="ignore"):
        raw = 100 * (c - ll) / (hh - ll)
    K = sma(raw, k)
    return K, sma(K, d)


def macd(c, f=12, s=26, sg=9):
    m = ema(c, f) - ema(c, s)
    sig = ema(m, sg)
    return m, sig, m - sig


def force(c, v, n=13):
    return ema(np.diff(c, prepend=np.nan) * v, n)


def adx(h, l, c, n=14):
    up, dn = np.diff(h, prepend=np.nan), -np.diff(l, prepend=np.nan)
    pdm = np.where((up > dn) & (up > 0), up, 0.0)
    mdm = np.where((dn > up) & (dn > 0), dn, 0.0)
    pc = np.roll(c, 1)
    tr = np.maximum.reduce([h - l, np.abs(h - pc), np.abs(l - pc)])
    tr[0] = h[0] - l[0]
    pdm[0] = mdm[0] = np.nan
    a = rma(tr, n)
    with np.errstate(divide="ignore", invalid="ignore"):
        pdi, mdi = 100 * rma(pdm, n) / a, 100 * rma(mdm, n) / a
        dx = 100 * np.abs(pdi - mdi) / (pdi + mdi)
    return rma(dx, n), pdi, mdi


def boll(c, n=20, k=2.0):
    m = sma(c, n)
    sd = np.full(len(c), np.nan)
    for i in range(n - 1, len(c)):
        sd[i] = np.std(c[i - n + 1:i + 1])
    return m, m + k * sd, m - k * sd


def vwap_daily(t, h, l, c, v):
    """VWAP yang mulai ulang tiap hari (00:00 UTC). Titik awal hari diberi NaN di indeks sebelumnya supaya garis putus."""
    day = (np.asarray(t, np.int64) // 86_400_000)
    tp = (h + l + c) / 3
    out = np.full(len(c), np.nan)
    pv = vv = 0.0
    for i in range(len(c)):
        if i == 0 or day[i] != day[i - 1]:
            pv = vv = 0.0
        pv += tp[i] * v[i]
        vv += v[i]
        out[i] = pv / vv if vv else np.nan
    return out, day


def zz(h, l, a, min_leg, n=3):
    """Swing (fractal n) yang jaraknya dari swing sebelumnya >= min_leg x ATR. -> [(idx, harga, +1 high / -1 low)]"""
    hi, lo = pivots(h, l, n)
    ev = sorted([(int(i), 1) for i in hi] + [(int(i), -1) for i in lo])
    out = []
    for i, t in ev:
        p = float(h[i] if t == 1 else l[i])
        if out and out[-1][2] == t:
            if (t == 1 and p > out[-1][1]) or (t == -1 and p < out[-1][1]):
                out[-1] = (i, p, t)
            continue
        A = a[i] if np.isfinite(a[i]) else 0
        if out and abs(p - out[-1][1]) < min_leg * A:
            continue
        out.append((i, p, t))
    return out


# ------------------------------------------------------------------ bantuan potongan & skenario


def _r(v):
    return None if v is None or not np.isfinite(v) else float(f"{float(v):.6g}")


def cut(x, a0, a1):
    return [_r(v) for v in np.asarray(x, float)[a0:a1]]


def ov(name, v, a0, a1, col, w=1.5, dash=""):
    return {"n": name, "v": cut(v, a0, a1), "c": COL.get(col, col), "w": w, "dash": dash}


def sr(name, v, a0, a1, col, typ="line", w=1.4, c2=None):
    d = {"n": name, "v": cut(v, a0, a1), "c": COL.get(col, col), "type": typ, "w": w}
    if c2:
        d["c2"] = COL.get(c2, c2)
    return d


def pane(title, series, levels=(), h=140, lo=None, hi=None):
    return {"title": title, "series": series, "levels": [{"v": v, "c": COL.get(c, c), "t": t} for v, c, t in levels], "h": h, "lo": lo, "hi": hi}


def P(a):
    """Anotasi untuk panel bawah."""
    a["pn"] = 1
    return a


def scn(S, a0, C, title, steps, ann, slow=(), pause=(), **extra):
    n = len(C)
    cl = lambda v: None if v is None else max(0, min(n - 1, int(v)))  # noqa: E731 - indeks selalu di dalam potongan
    for q in steps:
        q[3] = cl(q[3])
    steps = sorted(steps, key=lambda q: q[3])
    steps[0][3] = 0
    for a in ann:
        for k in ("i", "i0", "i1", "i2", "from"):
            if a.get(k) is not None:
                a[k] = cl(a[k])
    slow = [cl(x) for x in slow]
    pause = [x for x in (cl(x) for x in pause) if x > 0]
    d = {"title": title, "sym": S.sym, "tf": S.tf, "C": C, "steps": steps, "ann": ann, "slow": [int(x) for x in slow],
         "pause": [int(x) for x in pause], "note": ""}
    d.update(extra)
    return d


def _ok(S, a0, a1):
    return a0 >= 0 and a1 <= S.n


def _bigbar(S, a0, a1, k=5.0):
    """Potongan yang punya candle raksasa (> k ATR) bikin chart gepeng: dilewati."""
    return bool(np.any((S.h[a0:a1] - S.l[a0:a1]) > k * np.nan_to_num(S.a[a0:a1], nan=1e18)))


def _move(S, j, d, bars):
    """Gerak searah d (+1 naik / -1 turun) paling jauh dalam `bars` candle sesudah j, dalam ATR."""
    e = min(S.n, j + 1 + bars)
    if e <= j + 1:
        return 0.0
    return float(((S.h[j + 1:e].max() - S.c[j]) if d == 1 else (S.c[j] - S.l[j + 1:e].min())) / S.a[j])


def _peak(S, j, d, bars):
    e = min(S.n, j + 1 + bars)
    return int(j + 1 + (np.argmax(S.h[j + 1:e]) if d == 1 else np.argmin(S.l[j + 1:e])))


# ================================================================== 1. RSI divergence


def find_rsi_div(S, d=1):
    r = rsi(S.c)
    hi, lo = pivots(S.h, S.l, 4)
    Pv, px = (lo, S.l) if d == 1 else (hi, S.h)
    out = []
    for a, b in zip(Pv, Pv[1:]):
        if not 8 <= b - a <= 45 or a < 60 or b + 45 >= S.n or not (np.isfinite(r[a]) and np.isfinite(r[b])):
            continue
        if d == 1 and not (px[b] < px[a] - 0.15 * S.a[b] and r[b] > r[a] + 4 and r[a] < 33):
            continue
        if d == -1 and not (px[b] > px[a] + 0.15 * S.a[b] and r[b] < r[a] - 4 and r[a] > 67):
            continue
        mid = S.h[a:b].max() if d == 1 else S.l[a:b].min()
        conf = next((j for j in range(b + 1, min(S.n, b + 20)) if (S.c[j] > mid if d == 1 else S.c[j] < mid)), None)
        if conf is None:
            continue
        mv = _move(S, b, d, 45)
        if mv < 4 or _bigbar(S, a - 55, b + 45):
            continue
        out.append({"i": int(b), "a": int(a), "conf": int(conf), "mid": float(mid), "d": d, "score": mv + abs(r[b] - r[a]) / 4})
    return out


def build_rsi_div(S, x):
    d, a, b, cf = x["d"], x["a"], x["i"], x["conf"]
    a0, C = S.window(a - 55, b + 45)
    rel = lambda i: i - a0  # noqa: E731
    r = rsi(S.c)
    px = S.l if d == 1 else S.h
    up = d == 1
    pk = _peak(S, b, d, 45)
    w = "LOW" if up else "HIGH"
    dv = min(rel(b) + 2, rel(cf) - 1)                   # divergence diketahui sebelum konfirmasi
    ann = [label(rel(a), px[a], f"{w} 1", col="mut", pos="below" if up else "above"),
           P(label(rel(a), r[a], f"RSI {r[a]:.0f}", col="mut", pos="below" if up else "above")),
           seg(rel(a), px[a], rel(b), px[b], col="dn" if up else "up", show=rel(b), w=2),
           label(rel(b), px[b], "LOWER LOW harga" if up else "HIGHER HIGH harga", col="dn" if up else "up", pos="below" if up else "above", pill=True, show=rel(b)),
           P(seg(rel(a), r[a], rel(b), r[b], col="up" if up else "dn", show=rel(b), w=2)),
           P(label(rel(b), r[b], "HIGHER LOW RSI" if up else "LOWER HIGH RSI", col="up" if up else "dn", pos="below" if up else "above", pill=True, show=rel(b))),
           label(rel(b), x["mid"], "BULLISH DIVERGENCE" if up else "BEARISH DIVERGENCE", col="gold", pill=True, show=dv, anchor="start"),
           hline(x["mid"], rel(a), rel(cf), col="vio", dash="4 3", show=dv, tag="KONFIRMASI"),
           box(rel(cf), col="gold"),
           label(rel(pk), S.h[pk] if up else S.l[pk], f"{'naik' if up else 'turun'} {_move(S, b, d, 45):.1f} ATR", col="up" if up else "dn", pos="above" if up else "below", pill=True, show=rel(pk))]
    steps = [["Konteks", f"Harga {'turun' if up else 'naik'}. Panel bawah = RSI 14 (kekuatan gerak 0–100): di atas 70 = jenuh beli (overbought), di bawah 30 = jenuh jual (oversold).",
              "RSI mengukur seberapa kuat dorongan harga, bukan arah tren.", 0],
             [f"{w} pertama", f"Harga membuat {'low' if up else 'high'} dan RSI {r[a]:.0f} ({'oversold' if up else 'overbought'}).", "Catat posisi harga DAN RSI di titik ini.", min(rel(a) + 4, dv - 1)],
             ["Divergence", f"Harga membuat {'LOWER LOW (lebih rendah)' if up else 'HIGHER HIGH (lebih tinggi)'}, tapi RSI membuat {'HIGHER LOW (lebih tinggi)' if up else 'LOWER HIGH (lebih rendah)'} = DIVERGENCE: harga bergerak, tenaganya melemah.",
              f"{'Penjual' if up else 'Pembeli'} mulai kehabisan tenaga. Ini PERINGATAN, belum sinyal entry.", dv],
             ["Konfirmasi", f"Close {'menembus high' if up else 'menembus low'} di antara dua titik (garis ungu) = struktur ikut berbalik. Baru di sini divergence dianggap valid.",
              "Divergence tanpa konfirmasi sering gagal: harga bisa terus jalan dan divergence muncul berkali-kali.", rel(cf)],
             ["Hasil", f"Harga {'naik' if up else 'turun'} {_move(S, b, d, 45):.1f} ATR. SL umum: di luar ujung {w.lower()} kedua.",
              "Divergence REGULAR = tanda berbalik. Divergence HIDDEN (harga HL, RSI LL) = tanda tren lanjut.", rel(cf) + 2]]
    return scn(S, a0, C, "Bullish divergence (harga LL, RSI HL)" if up else "Bearish divergence (harga HH, RSI LH)", steps, ann, slow=[rel(b), rel(cf)], pause=[dv + 1, rel(cf) + 1],
               pane=pane("RSI 14", [sr("RSI", r, a0, a0 + len(C), "vio")], [(70, "dn", "70"), (50, "mut", "50"), (30, "up", "30")], lo=0, hi=100))


# ================================================================== 2. Stochastic


def find_stoch_cross(S):
    K, D = stoch(S.h, S.l, S.c)
    e50 = ema(S.c, 50)
    out = []
    for j in range(80, S.n - 35):
        if not (K[j - 1] <= D[j - 1] and K[j] > D[j] and K[j] < 25 and D[j] < 25):
            continue
        if not (e50[j] > e50[j - 10] and S.c[j] > e50[j] - 1.5 * S.a[j]):
            continue                                    # searah tren naik
        mv = _move(S, j, 1, 30)
        dd = (S.c[j] - S.l[j + 1:j + 10].min()) / S.a[j]
        if mv < 3.5 or dd > 1.2 or _bigbar(S, j - 90, j + 35):
            continue
        out.append({"i": j, "score": mv - dd})
    return out


def build_stoch_cross(S, x):
    j = x["i"]
    a0, C = S.window(j - 90, j + 35)
    rel = lambda i: i - a0  # noqa: E731
    K, D = stoch(S.h, S.l, S.c)
    e50 = ema(S.c, 50)
    pk = _peak(S, j, 1, 30)
    ann = [P(label(rel(j), K[j], "%K potong %D di bawah 20", col="up", pos="below", pill=True, show=rel(j))),
           box(rel(j), col="gold"), label(rel(j), S.l[j], "sinyal BUY", col="up", pos="below", pill=True, show=rel(j)),
           label(rel(pk), S.h[pk], f"naik {_move(S, j, 1, 30):.1f} ATR", col="up", pill=True, show=rel(pk))]
    steps = [["Konteks", "Panel bawah = Stochastic (14,3,3): posisi close di dalam rentang 14 candle terakhir (0–100). Garis biru %K (cepat), oranye %D (rata-rata %K).",
              "Di atas 80 = dekat puncak rentang (overbought), di bawah 20 = dekat dasar (oversold). Garis EMA 50 = arah tren.", 0],
             ["Tren naik + koreksi", "EMA 50 menanjak = tren naik. Harga koreksi sampai Stochastic turun ke bawah 20.", "Cari BUY hanya searah tren: koreksi di tren naik.", max(1, rel(j) - 12)],
             ["Sinyal", "%K memotong %D ke atas, keduanya di bawah 20 = momentum koreksi habis, mulai naik lagi.", "Entry di close candle sinyal, SL di bawah low koreksi.", rel(j)],
             ["Hasil", f"Harga naik {_move(S, j, 1, 30):.1f} ATR.", "Stochastic paling bagus di koreksi tren atau sideways; di tren sangat kuat, ia bisa lama tertahan di atas 80 / bawah 20.", rel(j) + 3]]
    return scn(S, a0, C, "Potong naik di bawah 20 (searah tren)", steps, ann, slow=[rel(j)], pause=[rel(j) + 1],
               ov=[ov("EMA 50", e50, a0, a0 + len(C), "gold")],
               pane=pane("Stochastic 14,3,3", [sr("%K", K, a0, a0 + len(C), "blue"), sr("%D", D, a0, a0 + len(C), "#fb923c")],
                         [(80, "dn", "80"), (20, "up", "20")], lo=0, hi=100))


def find_stoch_trap(S):
    K, _ = stoch(S.h, S.l, S.c)
    out, j = [], 80
    while j < S.n - 30:
        if K[j] < 20:
            e = j
            while e < S.n - 1 and K[e + 1] < 25:
                e += 1
            drop = (S.c[j] - S.l[j:e + 1].min()) / S.a[j]
            if e - j >= 12 and drop >= 4 and not _bigbar(S, j - 60, e + 30):
                out.append({"i": j, "e": e, "score": drop + (e - j) / 5})
            j = e + 1
        j += 1
    return out


def build_stoch_trap(S, x):
    j, e = x["i"], x["e"]
    a0, C = S.window(j - 60, e + 30)
    rel = lambda i: i - a0  # noqa: E731
    K, D = stoch(S.h, S.l, S.c)
    lo_i = j + int(np.argmin(S.l[j:e + 1]))
    ann = [P(zone(0, 20, rel(j), rel(e), col="dn", op=0.12, show=rel(j), label="tertahan di bawah 20")),
           label(rel(j), S.h[j], "Stochastic < 20: 'murah'?", col="gold", pill=True, show=rel(j)),
           label(rel(lo_i), S.l[lo_i], f"tetap turun {(S.c[j] - S.l[lo_i]) / S.a[j]:.1f} ATR", col="dn", pos="below", pill=True, show=rel(lo_i))]
    steps = [["Konteks", "Stochastic turun ke bawah 20 (oversold). Banyak pemula langsung BUY karena merasa harga sudah 'murah'.", "Oversold ≠ pasti naik.", 0],
             ["Jebakan oversold", f"Stochastic tertahan di bawah 20 selama {e - j} candle, sementara harga terus turun.", "Di tren turun kuat, oversold bisa bertahan lama: penjual tetap dominan.", rel(j)],
             ["Pelajaran", "Tunggu %K memotong %D ke atas DAN harga membuat struktur naik (high kecil ditembus) sebelum BUY.", "Indikator momentum dipakai untuk TIMING searah tren, bukan untuk melawan tren.", rel(e)]]
    return scn(S, a0, C, "Jebakan: oversold lama di tren turun", steps, ann, slow=[rel(j)], pause=[rel(j) + 1],
               pane=pane("Stochastic 14,3,3", [sr("%K", K, a0, a0 + len(C), "blue"), sr("%D", D, a0, a0 + len(C), "#fb923c")],
                         [(80, "dn", "80"), (20, "up", "20")], lo=0, hi=100))


# ================================================================== 3. semua tipe Moving Average


def find_vturn(S):
    """Dasar berbentuk V tajam (turun cepat lalu naik cepat): di sini beda lag antar-MA paling kelihatan."""
    lo = pivots(S.h, S.l, 6)[1]
    c = S.c
    MA = None
    out = []
    for b in lo:
        if b < 260 or b + 45 >= S.n or S.l[b] > S.l[b - 60:b + 45].min():
            continue
        fall = (S.h[b - 25:b].max() - S.l[b]) / S.a[b]
        rise = _move(S, b, 1, 25)
        if fall < 6 or rise < 6 or _bigbar(S, b - 70, b + 45):
            continue
        if MA is None:
            MA = {k: f(c, 20) for k, f in (("sma", sma), ("hma", hma), ("rma", rma), ("tema", tema), ("ema", ema))}
        t = {k: _turn(v, b, b + 40) for k, v in MA.items()}
        if None in t.values() or not (t["hma"] < t["ema"] < t["sma"] and t["tema"] < t["rma"]):
            continue                                    # contoh yang memperlihatkan urutan lag dengan jelas
        out.append({"i": int(b), "score": min(fall, rise) + (t["sma"] - t["hma"])})
    return out


def _turn(ma, b, e):
    """Titik balik MA = titik TERENDAH garis MA di sekitar dasar harga (sesudahnya MA naik)."""
    w = ma[b - 5:e]
    if not np.any(np.isfinite(w)):
        return None
    return int(b - 5 + np.nanargmin(w))


def _build_ma(S, x, kind):
    b = x["i"]
    a0, C = S.window(b - 70, b + 45)
    a1 = a0 + len(C)
    rel = lambda i: i - a0  # noqa: E731
    c, n = S.c, 20
    if kind == 1:
        L = [("SMA 20", sma(c, n), "gold", "SMA (Simple): rata-rata biasa, semua candle bobotnya sama → paling lambat."),
             ("EMA 20", ema(c, n), "blue", "EMA (Exponential): candle terbaru diberi bobot lebih → lebih cepat dari SMA. Paling banyak dipakai."),
             ("WMA 20", wma(c, n), "pink", "WMA (Weighted): bobot naik lurus 1,2,3…20 → di antara SMA dan EMA."),
             ("HMA 20", hma(c, n), "cyan", "HMA (Hull): dirancang hampir tanpa lag → paling cepat berbalik, tapi juga paling sering 'goyang'.")]
        title = "SMA vs EMA vs WMA vs HMA"
    else:
        L = [("SMMA/RMA 20", rma(c, n), "gold", "SMMA / RMA (Smoothed, Wilder): sangat halus & lambat. Dipakai di dalam RSI, ATR, ADX."),
             ("VWMA 20", vwma(c, S.v, n), "pink", "VWMA (Volume Weighted): candle dengan volume besar diberi bobot lebih → mengikuti 'uang besar'."),
             ("DEMA 20", dema(c, n), "blue", "DEMA (Double EMA): EMA yang dikurangi lag-nya → lebih cepat dari EMA."),
             ("TEMA 20", tema(c, n), "cyan", "TEMA (Triple EMA): lag dikurangi lagi → sangat cepat, mirip HMA.")]
        title = "SMMA/RMA, VWMA, DEMA, TEMA"
    ann, turns = [], []
    for nm, v, col, _ in L:
        t = _turn(v, b, min(S.n, b + 40))
        if t is not None:
            turns.append((t, nm, col, v))
    turns.sort()
    for t, nm, col, v in turns:
        ann.append(label(rel(t), v[t], f"{nm.split()[0]} berbalik", col=col, pos="below", show=rel(t)))
    first, last = (turns[0], turns[-1]) if turns else (None, None)
    steps = [["Konteks", "Satu periode (20) untuk semua garis, supaya kelihatan bedanya: yang beda hanya CARA menghitung rata-rata.", "Makin cepat garis = makin cepat sinyal, tapi makin sering sinyal palsu.", 0]]
    steps += [[nm.split()[0], txt, "", max(1, rel(b) - 30 + 6 * k)] for k, (nm, _, _, txt) in enumerate(L)]
    steps.append(["Lag (keterlambatan)", "Harga berbalik naik di dasar. Perhatikan label: MA yang cepat berbalik lebih dulu, yang lambat paling akhir." +
                  (f" {first[1]} duluan, {last[1]} terakhir ({last[0] - first[0]} candle kemudian)." if first else ""),
                  "MA cepat → entry lebih awal tapi sering tertipu di sideways. MA lambat → lebih tenang, entry telat.", rel(b) + 2])
    return scn(S, a0, C, title, steps, ann, slow=[rel(b)], pause=[rel(b) + 1],
               ov=[ov(nm, v, a0, a1, col, w=1.6) for nm, v, col, _ in L])


def build_ma1(S, x):
    return _build_ma(S, x, 1)


def build_ma2(S, x):
    return _build_ma(S, x, 2)


def find_golden(S):
    e50, e200 = ema(S.c, 50), ema(S.c, 200)
    out = []
    for j in range(300, S.n - 60):
        if e50[j - 1] <= e200[j - 1] and e50[j] > e200[j]:
            mv = _move(S, j, 1, 60)
            if mv >= 4 and not _bigbar(S, j - 120, j + 60, 6.0):
                out.append({"i": j, "score": mv})
    return out


def build_golden(S, x):
    j = x["i"]
    a0, C = S.window(j - 120, j + 60)
    a1 = a0 + len(C)
    rel = lambda i: i - a0  # noqa: E731
    e50, e200 = ema(S.c, 50), ema(S.c, 200)
    pk = _peak(S, j, 1, 60)
    ann = [label(rel(j), e50[j], "GOLDEN CROSS", col="gold", pos="below", pill=True, show=rel(j)), box(rel(j), col="gold"),
           label(rel(pk), S.h[pk], f"+{_move(S, j, 1, 60):.1f} ATR", col="up", pill=True, show=rel(pk))]
    steps = [["Konteks", "EMA 50 (kuning) = tren menengah, EMA 200 (ungu) = tren besar. Harga di bawah keduanya = tren turun.", "", 0],
             ["Mendatar", "EMA 50 mulai mendatar lalu naik mendekati EMA 200: tekanan jual melemah.", "", max(1, rel(j) - 40)],
             ["Golden cross", "EMA 50 memotong EMA 200 ke atas = GOLDEN CROSS: tren menengah berbalik naik. Kebalikannya (memotong ke bawah) = DEATH CROSS.",
              "Sinyal lambat (MA panjang) → bagus untuk arah besar, bukan untuk entry presisi.", rel(j)],
             ["Hasil", f"Harga naik {_move(S, j, 1, 60):.1f} ATR. Sesudah golden cross, EMA 50 sering jadi support dinamis.", "Di sideways, golden/death cross bisa bolak-balik (whipsaw).", rel(j) + 3]]
    return scn(S, a0, C, "EMA 50/200: golden cross", steps, ann, slow=[rel(j)], pause=[rel(j) + 1],
               ov=[ov("EMA 50", e50, a0, a1, "gold", w=1.8), ov("EMA 200", e200, a0, a1, "vio", w=1.8)])


# ================================================================== 4. Force Index


def find_force(S):
    fi = force(S.c, S.v, 13)
    e = ema(S.c, 50)
    out = []
    for j in range(80, S.n - 35):
        if not (fi[j - 1] <= 0 < fi[j] and e[j] > e[j - 8]):
            continue
        mv = _move(S, j, 1, 30)
        dd = (S.c[j] - S.l[j + 1:j + 8].min()) / S.a[j]
        if mv >= 4 and dd < 1.2 and fi[j - 15:j].min() < 0 and not _bigbar(S, j - 80, j + 35):
            out.append({"i": j, "score": mv - dd})
    return out


def build_force(S, x):
    j = x["i"]
    a0, C = S.window(j - 80, j + 35)
    rel = lambda i: i - a0  # noqa: E731
    fi = force(S.c, S.v, 13)
    lo_i = j - 15 + int(np.argmin(fi[j - 15:j]))
    pk = _peak(S, j, 1, 30)
    ann = [P(label(rel(lo_i), fi[lo_i], "penjual dominan", col="dn", pos="below", show=rel(lo_i))),
           P(label(rel(j), 0, "naik ke atas 0", col="up", pill=True, show=rel(j))), box(rel(j), col="gold"),
           label(rel(pk), S.h[pk], f"naik {_move(S, j, 1, 30):.1f} ATR", col="up", pill=True, show=rel(pk))]
    steps = [["Konteks", "Panel bawah = Force Index 13 = (close − close sebelumnya) × volume, dihaluskan EMA 13. Menggabungkan ARAH, BESAR gerak, dan VOLUME.",
              "Di atas 0 = pembeli lebih kuat, di bawah 0 = penjual lebih kuat. Batang makin tinggi = tenaga makin besar.", 0],
             ["Koreksi", "Saat koreksi, Force Index turun di bawah 0: penjual sementara menguasai.", "Di tren naik (EMA 50 menanjak), ini koreksi biasa.", rel(lo_i)],
             ["Kembali ke atas 0", "Force Index naik lagi ke atas 0 = pembeli kembali menguasai → sinyal lanjut naik searah tren.", "Lebih kuat kalau batangnya tinggi (volume besar ikut mendorong).", rel(j)],
             ["Hasil", f"Harga naik {_move(S, j, 1, 30):.1f} ATR.", "Force Index tidak dipakai sendirian: tetap cek struktur & arah tren.", rel(j) + 3]]
    return scn(S, a0, C, "Force Index kembali ke atas 0", steps, ann, slow=[rel(j)], pause=[rel(j) + 1],
               ov=[ov("EMA 50", ema(S.c, 50), a0, a0 + len(C), "gold")],
               pane=pane("Force Index 13", [sr("FI", fi, a0, a0 + len(C), "up", typ="hist", c2="dn")], [(0, "mut", "0")]))


# ================================================================== 5. MACD


def find_macd(S, d=1):
    m, s, _ = macd(S.c)
    out = []
    for j in range(80, S.n - 40):
        cross = (m[j - 1] <= s[j - 1] and m[j] > s[j] and m[j] < 0) if d == 1 else (m[j - 1] >= s[j - 1] and m[j] < s[j] and m[j] > 0)
        if not cross:
            continue
        mv = _move(S, j, d, 40)
        adv = ((S.c[j] - S.l[j + 1:j + 10].min()) if d == 1 else (S.h[j + 1:j + 10].max() - S.c[j])) / S.a[j]
        if mv >= 5 and adv < 1.2 and not _bigbar(S, j - 80, j + 40):
            out.append({"i": j, "d": d, "score": mv - adv})
    return out


def build_macd(S, x):
    j, d = x["i"], x["d"]
    up = d == 1
    a0, C = S.window(j - 80, j + 40)
    rel = lambda i: i - a0  # noqa: E731
    m, s, hg = macd(S.c)
    z = next((k for k in range(j, min(S.n, j + 40)) if (m[k] > 0 if up else m[k] < 0)), None)
    pk = _peak(S, j, d, 40)
    ann = [P(label(rel(j), m[j], "MACD potong signal ke " + ("atas" if up else "bawah"), col="up" if up else "dn", pos="below" if up else "above", pill=True, show=rel(j))),
           box(rel(j), col="gold"),
           label(rel(pk), S.h[pk] if up else S.l[pk], f"{'naik' if up else 'turun'} {_move(S, j, d, 40):.1f} ATR", col="up" if up else "dn", pos="above" if up else "below", pill=True, show=rel(pk))]
    if z is not None:
        ann.append(P(label(rel(z), 0, "lewat garis 0", col="gold", pos="above" if up else "below", show=rel(z))))
    steps = [["Konteks", "Panel bawah = MACD (12,26,9). Garis biru MACD = EMA 12 − EMA 26. Garis oranye = signal (EMA 9 dari MACD). Batang = selisih keduanya (histogram).",
              "MACD di bawah 0 = EMA cepat di bawah EMA lambat (tren turun), di atas 0 = tren naik.", 0],
             ["Histogram mengecil", f"Batang histogram makin pendek = tenaga {'turun' if up else 'naik'} melemah, walau harga masih {'turun' if up else 'naik'}.", "Ini peringatan dini.", max(1, rel(j) - 8)],
             ["Cross", f"MACD memotong signal ke {'atas' if up else 'bawah'} {'di bawah' if up else 'di atas'} garis 0 = momentum berbalik {'naik' if up else 'turun'}.",
              f"Cross yang terjadi jauh {'di bawah' if up else 'di atas'} 0 biasanya lebih kuat (berbalik dari kondisi ekstrem).", rel(j)],
             ["Konfirmasi", f"MACD {'naik melewati' if up else 'turun melewati'} garis 0 = tren ikut berganti.", "", rel(z) if z is not None else rel(j) + 5],
             ["Hasil", f"Harga {'naik' if up else 'turun'} {_move(S, j, d, 40):.1f} ATR.", "Di sideways MACD sering cross bolak-balik → saring dengan struktur / TF besar.", (rel(z) if z is not None else rel(j) + 5) + 2]]
    return scn(S, a0, C, "Bullish cross di bawah 0" if up else "Bearish cross di atas 0", steps, ann, slow=[rel(j)], pause=[rel(j) + 1],
               pane=pane("MACD 12,26,9", [sr("hist", hg, a0, a0 + len(C), "up", typ="hist", c2="dn"), sr("MACD", m, a0, a0 + len(C), "blue"),
                                          sr("signal", s, a0, a0 + len(C), "#fb923c")], [(0, "mut", "0")]))


# ================================================================== 6. Chart pattern


def find_double(S, d=1):
    hi, lo = pivots(S.h, S.l, 5)
    Pv = lo if d == 1 else hi
    px = S.l if d == 1 else S.h
    out = []
    for a, b in zip(Pv, Pv[1:]):
        if not 15 <= b - a <= 60 or a < 50 or b + 60 >= S.n:
            continue
        A = S.a[b]
        if abs(px[a] - px[b]) > 0.6 * A:
            continue
        neck = S.h[a:b].max() if d == 1 else S.l[a:b].min()
        ext = min(px[a], px[b]) if d == 1 else max(px[a], px[b])
        hgt = abs(neck - ext)
        if hgt < 3 * A:
            continue
        br = next((j for j in range(b + 1, min(S.n, b + 30)) if (S.c[j] > neck if d == 1 else S.c[j] < neck)), None)
        if br is None or (S.l[b + 1:br + 1].min() < ext if d == 1 else S.h[b + 1:br + 1].max() > ext):
            continue
        tgt = neck + d * hgt
        hit = next((j for j in range(br, min(S.n, br + 60)) if (S.h[j] >= tgt if d == 1 else S.l[j] <= tgt)), None)
        if hit is None or _bigbar(S, a - 45, hit + 15):
            continue
        out.append({"i": int(b), "a": int(a), "br": br, "hit": hit, "neck": float(neck), "tgt": float(tgt), "ext": float(ext), "d": d, "score": hgt / A})
    return out


def build_double(S, x):
    a, b, br, hit, d = x["a"], x["i"], x["br"], x["hit"], x["d"]
    up = d == 1
    a0, C = S.window(a - 45, hit + 15)
    rel = lambda i: i - a0  # noqa: E731
    px = S.l if up else S.h
    nm = "Double bottom (W)" if up else "Double top (M)"
    k2 = max(rel(b) + 1, min(rel(b) + 5, rel(br) - 2))   # dasar/puncak kedua terlihat sebelum breakout
    ann = [label(rel(a), px[a], "dasar 1" if up else "puncak 1", col="up" if up else "dn", pos="below" if up else "above", pill=True, show=rel(a) + 5),
           label(rel(b), px[b], "dasar 2" if up else "puncak 2", col="up" if up else "dn", pos="below" if up else "above", pill=True, show=k2),
           hline(x["neck"], rel(a), rel(hit), col="gold", dash="6 4", tag="NECKLINE", show=k2),
           box(rel(br), col="gold"),
           hline(x["tgt"], rel(br), rel(hit) + 5, col="up" if up else "dn", dash="4 3", tag="TARGET", show=rel(br)),
           label(rel(hit), x["tgt"], "target tercapai ✓", col="up" if up else "dn", pos="above" if up else "below", pill=True, show=rel(hit))]
    steps = [["Konteks", f"Harga {'turun' if up else 'naik'} lalu membentuk {'dasar' if up else 'puncak'} pertama.", "", 0],
             [f"{'Dasar' if up else 'Puncak'} kedua", f"Harga kembali ke level yang hampir sama lalu gagal {'tembus ke bawah' if up else 'tembus ke atas'} = {nm}.",
              f"{'Penjual' if up else 'Pembeli'} 2× gagal melewati level itu.", k2],
             ["Neckline", f"Garis kuning = NECKLINE ({'high' if up else 'low'} di antara dua {'dasar' if up else 'puncak'}). Pola BELUM jadi sebelum neckline ditembus.", "", min(k2 + 1, rel(br) - 1)],
             ["Breakout", f"Close menembus neckline = pola terkonfirmasi. Entry di sini atau saat retest neckline.", f"SL di balik {'dasar' if up else 'puncak'} kedua.", rel(br)],
             ["Target", "Target umum = tinggi pola (jarak dasar/puncak ke neckline) diproyeksikan dari neckline.", "Pola klasik juga bisa gagal; target hanya perkiraan.", rel(hit)]]
    return scn(S, a0, C, nm, steps, ann, slow=[rel(br)], pause=[rel(br) + 1])


def find_hs(S):
    hi, lo = pivots(S.h, S.l, 5)
    out = []
    for p1, p2, p3 in zip(hi, hi[1:], hi[2:]):
        if p1 < 40 or p3 + 60 >= S.n or not (8 <= p2 - p1 <= 40 and 8 <= p3 - p2 <= 40):
            continue
        A = S.a[p2]
        if not (S.h[p2] > max(S.h[p1], S.h[p3]) + 1.0 * A and abs(S.h[p1] - S.h[p3]) < 1.2 * A):
            continue
        t1 = p1 + int(np.argmin(S.l[p1:p2]))
        t2 = p2 + int(np.argmin(S.l[p2:p3]))
        neck = lambda j: S.l[t1] + (S.l[t2] - S.l[t1]) * (j - t1) / (t2 - t1)  # noqa: E731
        br = next((j for j in range(p3 + 1, min(S.n, p3 + 25)) if S.c[j] < neck(j)), None)
        if br is None:
            continue
        hgt = S.h[p2] - neck(p2)
        tgt = neck(br) - hgt
        hit = next((j for j in range(br, min(S.n, br + 60)) if S.l[j] <= tgt), None)
        if hit is None or S.h[p3:br + 1].max() > S.h[p2] or _bigbar(S, p1 - 35, hit + 12):
            continue
        out.append({"i": int(p2), "p1": int(p1), "p3": int(p3), "t1": t1, "t2": t2, "br": br, "hit": hit, "tgt": float(tgt), "score": hgt / A})
    return out


def build_hs(S, x):
    p1, p2, p3, t1, t2, br, hit = (x[k] for k in ("p1", "i", "p3", "t1", "t2", "br", "hit"))
    a0, C = S.window(p1 - 35, hit + 12)
    rel = lambda i: i - a0  # noqa: E731
    k3 = max(rel(p3) + 1, min(rel(p3) + 5, rel(br) - 1))
    nk = lambda j: S.l[t1] + (S.l[t2] - S.l[t1]) * (j - t1) / (t2 - t1)  # noqa: E731
    ann = [label(rel(p1), S.h[p1], "bahu kiri", col="dn", pill=True, show=rel(p1) + 5),
           label(rel(p2), S.h[p2], "kepala", col="dn", pill=True, show=rel(p2) + 5),
           label(rel(p3), S.h[p3], "bahu kanan", col="dn", pill=True, show=k3),
           seg(rel(t1), nk(t1), rel(br) + 3, nk(br + 3), col="gold", show=rel(t2) + 3, w=1.8),
           label(rel(t1), S.l[t1], "neckline", col="gold", pos="below", show=rel(t2) + 3),
           box(rel(br), col="gold"),
           hline(x["tgt"], rel(br), rel(hit) + 5, col="dn", dash="4 3", tag="TARGET", show=rel(br)),
           label(rel(hit), x["tgt"], "target tercapai ✓", col="dn", pos="below", pill=True, show=rel(hit))]
    steps = [["Konteks", "Harga membuat puncak pertama = BAHU KIRI.", "", 0],
             ["Kepala", "Harga naik lagi membuat puncak lebih tinggi = KEPALA, lalu turun.", "", rel(p2) + 5],
             ["Bahu kanan", "Naik lagi tapi GAGAL melewati kepala (puncak lebih rendah) = BAHU KANAN. Tenaga pembeli habis.", "Ini juga lower high pertama.", k3],
             ["Neckline patah", "Close menembus NECKLINE (garis yang menghubungkan dua lembah) = pola Head & Shoulders terkonfirmasi.", "SL di atas bahu kanan.", rel(br)],
             ["Target", "Target umum = tinggi kepala ke neckline, diproyeksikan ke bawah dari titik tembus.",
              "Kebalikannya (Inverse Head & Shoulders) = tanda berbalik naik.", rel(hit)]]
    return scn(S, a0, C, "Head & Shoulders", steps, ann, slow=[rel(br)], pause=[rel(br) + 1])


def find_flag(S):
    out = []
    for p0 in range(40, S.n - 80):
        A = S.a[p0]
        for L in range(5, 15):
            p1 = p0 + L
            pole = S.h[p1] - S.l[p0]
            if pole < 4.5 * A or S.l[p0] != S.l[p0:p1 + 1].min() or S.h[p1] != S.h[p0:p1 + 1].max():
                continue
            fl = None
            for F in range(6, 26):
                e = p1 + F
                if e >= S.n - 40:
                    break
                if S.h[p1 + 1:e + 1].max() > S.h[p1]:
                    break
                if S.h[p1] - S.l[p1 + 1:e + 1].min() > 0.5 * pole:
                    break
                if S.c[e + 1] > S.h[p1:e + 1].max():
                    fl = e
                    break
            if fl is None or fl - p1 < 6:
                continue
            br = fl + 1
            cont = (S.h[br:br + 40].max() - S.c[br])
            if cont >= 0.5 * pole and not _bigbar(S, p0 - 35, br + 35, 7.0):
                out.append({"i": int(p1), "p0": p0, "fl": fl, "br": br, "score": pole / A + cont / A})
            break
    return out


def build_flag(S, x):
    p0, p1, fl, br = x["p0"], x["i"], x["fl"], x["br"]
    a0, C = S.window(p0 - 35, br + 35)
    rel = lambda i: i - a0  # noqa: E731
    top, bot = S.h[p1:fl + 1].max(), S.l[p1 + 1:fl + 1].min()
    pole = S.h[p1] - S.l[p0]
    pk = _peak(S, br, 1, 35)
    ann = [seg(rel(p0), S.l[p0], rel(p1), S.h[p1], col="up", show=rel(p1), w=2.2),
           label(rel(p0 + (p1 - p0) // 2), (S.l[p0] + S.h[p1]) / 2, "TIANG (pole)", col="up", pill=True, anchor="end", show=rel(p1)),
           zone(top, bot, rel(p1), rel(fl), col="gold", op=0.12, show=rel(fl), label="BENDERA (konsolidasi)"),
           box(rel(br), col="gold"),
           hline(S.c[br] + pole, rel(br), rel(br) + 30, col="up", dash="4 3", tag="TARGET ±tiang", show=rel(br)),
           label(rel(pk), S.h[pk], f"+{(S.h[pk] - S.c[br]) / S.a[br]:.1f} ATR", col="up", pill=True, show=rel(pk))]
    steps = [["Konteks", "Harga naik sangat cepat dalam sedikit candle = TIANG (pole).", "Gerak cepat = pembeli besar masuk.", 0],
             ["Bendera", "Harga istirahat menyamping / sedikit turun dengan candle kecil = BENDERA. Koreksinya dangkal (≤ setengah tiang).",
              "Pembeli tidak keluar; yang terjadi hanya ambil untung sebentar.", rel(p1) + 3],
             ["Breakout", "Close menembus atas bendera = tren melanjutkan. Entry di close breakout, SL di bawah bendera.", "", rel(br)],
             ["Target", "Target umum = panjang tiang diproyeksikan dari titik breakout.", "Bear flag = kebalikannya (tiang turun, bendera naik pelan).", rel(br) + 3]]
    return scn(S, a0, C, "Bull flag", steps, ann, slow=[rel(br)], pause=[rel(br) + 1])


# ================================================================== 7. Candlestick pattern


def _body(S, j):
    return abs(S.c[j] - S.o[j])


def find_candle(S, kind):
    hi, lo = pivots(S.h, S.l, 5)
    piv = set(int(i) for i in (hi if kind == "bear_engulf" else lo))
    out = []
    for j in range(40, S.n - 25):
        A = S.a[j]
        near = any(k in piv for k in (j - 2, j - 1, j))
        if not near:
            continue
        o, h, l, c = S.o[j], S.h[j], S.l[j], S.c[j]
        ok = False
        if kind == "bull_engulf":
            ok = S.c[j - 1] < S.o[j - 1] and c > o and o <= S.c[j - 1] and c >= S.o[j - 1] and _body(S, j) >= 1.3 * _body(S, j - 1) and _body(S, j) >= 0.8 * A
        elif kind == "bear_engulf":
            ok = S.c[j - 1] > S.o[j - 1] and c < o and o >= S.c[j - 1] and c <= S.o[j - 1] and _body(S, j) >= 1.3 * _body(S, j - 1) and _body(S, j) >= 0.8 * A
        elif kind == "hammer":
            bd = _body(S, j)
            ok = (min(o, c) - l) >= 2.5 * max(bd, 0.05 * A) and (h - max(o, c)) <= 0.6 * max(bd, 0.1 * A) and (h - l) >= 1.2 * A
        elif kind == "morning":
            ok = (S.o[j - 2] - S.c[j - 2]) >= 1.0 * A and _body(S, j - 1) <= 0.3 * A and c > o and c > (S.o[j - 2] + S.c[j - 2]) / 2
        if not ok:
            continue
        d = -1 if kind == "bear_engulf" else 1
        mv = _move(S, j, d, 20)
        if mv >= 3 and not _bigbar(S, j - 40, j + 25):
            out.append({"i": j, "kind": kind, "score": mv})
    return out


CANDLE_TXT = {
    "bull_engulf": ("Bullish engulfing", "Candle hijau yang BADANNYA menelan seluruh badan candle merah sebelumnya, muncul di dasar.",
                    "Pembeli mengambil alih penuh dalam satu candle. Paling kuat di support / sesudah sweep."),
    "bear_engulf": ("Bearish engulfing", "Candle merah yang BADANNYA menelan seluruh badan candle hijau sebelumnya, muncul di puncak.",
                    "Penjual mengambil alih penuh. Paling kuat di resistance."),
    "hammer": ("Hammer / pin bar", "Badan kecil di atas, EKOR BAWAH panjang (≥ 2,5× badan). Harga sempat dijual jauh lalu ditolak kembali naik.",
               "Ekor panjang = penolakan (rejection). Versi terbalik di puncak = shooting star."),
    "morning": ("Morning star", "3 candle: merah besar → candle kecil / doji (ragu-ragu) → hijau yang menutup di atas tengah candle merah pertama.",
                "Doji = keseimbangan; candle ketiga = pembeli menang. Kebalikannya di puncak = evening star."),
}


def build_candle(S, x):
    j, kind = x["i"], x["kind"]
    d = -1 if kind == "bear_engulf" else 1
    up = d == 1
    a0, C = S.window(j - 40, j + 25)
    rel = lambda i: i - a0  # noqa: E731
    nm, what, why = CANDLE_TXT[kind]
    first = j - (2 if kind == "morning" else 1 if "engulf" in kind else 0)
    ann = [box(rel(k), col="gold", show=rel(j)) for k in range(first, j + 1)]
    ann.append(label(rel(j), S.l[j] if up else S.h[j], nm.upper(), col="gold", pos="below" if up else "above", pill=True, show=rel(j)))
    if kind == "morning":
        ann.append(label(rel(j - 1), S.h[j - 1], "ragu (doji)", col="mut", show=rel(j)))
    pk = _peak(S, j, d, 20)
    ann.append(label(rel(pk), S.h[pk] if up else S.l[pk], f"{'naik' if up else 'turun'} {_move(S, j, d, 20):.1f} ATR", col="up" if up else "dn",
                     pos="above" if up else "below", pill=True, show=rel(pk)))
    steps = [["Konteks", f"Harga {'turun ke area bawah' if up else 'naik ke area atas'}. Perhatikan bentuk candle saat harga sampai di ujung gerak.", "", 0],
             [nm, what, why, rel(j)],
             ["Konfirmasi & hasil", f"Candle berikutnya melanjutkan arah → pola valid. Harga {'naik' if up else 'turun'} {_move(S, j, d, 20):.1f} ATR.",
              "Pola candle hanya kuat di LOKASI penting (support/resistance, sweep, zona). Di tengah range artinya kecil.", rel(j) + 1]]
    return scn(S, a0, C, nm, steps, ann, slow=[rel(first), rel(j)], pause=[rel(j) + 1])


# ================================================================== 8. ADX


def find_adx(S):
    ax, pdi, mdi = adx(S.h, S.l, S.c)
    out = []
    for j in range(80, S.n - 45):
        if not (ax[j - 1] < 25 <= ax[j]) or np.nanmax(ax[j - 20:j - 3]) >= 22:
            continue
        d = 1 if pdi[j] > mdi[j] else -1
        mv = _move(S, j, d, 45)
        if mv >= 5 and not _bigbar(S, j - 70, j + 45):
            out.append({"i": j, "d": d, "score": mv})
    return out


def build_adx(S, x):
    j, d = x["i"], x["d"]
    up = d == 1
    a0, C = S.window(j - 70, j + 45)
    rel = lambda i: i - a0  # noqa: E731
    ax, pdi, mdi = adx(S.h, S.l, S.c)
    pk = _peak(S, j, d, 45)
    ann = [P(zone(0, 20, rel(j) - 45, rel(j) - 3, col="mut", op=0.10, show=rel(j) - 3, label="ADX < 20: lemah / sideways")),
           P(label(rel(j), 25, "ADX tembus 25", col="gold", pill=True, show=rel(j))),
           box(rel(j), col="gold"),
           label(rel(j), S.l[j] if up else S.h[j], f"{'+DI' if up else '−DI'} di atas → {'naik' if up else 'turun'}", col="up" if up else "dn", pos="below" if up else "above", pill=True, show=rel(j)),
           label(rel(pk), S.h[pk] if up else S.l[pk], f"{'naik' if up else 'turun'} {_move(S, j, d, 45):.1f} ATR", col="up" if up else "dn", pos="above" if up else "below", pill=True, show=rel(pk))]
    steps = [["Konteks", "Panel bawah: ADX (putih) = KEKUATAN tren 0–100, tanpa arah. +DI (hijau) = dorongan naik, −DI (merah) = dorongan turun.",
              "ADX tidak bilang naik/turun; arah dilihat dari +DI vs −DI.", 0],
             ["Sideways", "ADX di bawah 20 = tren lemah / sideways: strategi breakout sering gagal, main di dalam range.", "", max(1, rel(j) - 25)],
             ["Tren mulai", f"ADX naik menembus 25 = tren mulai kuat. {'+DI' if up else '−DI'} di atas {'−DI' if up else '+DI'} → arah {'NAIK' if up else 'TURUN'}.",
              "Masuk searah DI yang di atas; jangan melawan saat ADX naik.", rel(j)],
             ["Hasil", f"Harga {'naik' if up else 'turun'} {_move(S, j, d, 45):.1f} ATR. Saat ADX mulai turun dari puncak = tren melambat (bukan berarti berbalik).", "", rel(j) + 3]]
    return scn(S, a0, C, "Sideways → tren (ADX > 25)", steps, ann, slow=[rel(j)], pause=[rel(j) + 1],
               pane=pane("ADX 14", [sr("ADX", ax, a0, a0 + len(C), "#e6ebf2", w=1.8), sr("+DI", pdi, a0, a0 + len(C), "up"), sr("−DI", mdi, a0, a0 + len(C), "dn")],
                         [(25, "gold", "25"), (20, "mut", "20")], lo=0))


# ================================================================== 9. ATR


def find_atr(S):
    out = []
    for j in range(140, S.n - 40):
        win = S.a[j - 100:j + 1]
        if S.a[j] > np.nanmin(win) * 1.05:
            continue
        e = min(S.n, j + 30)
        mx = np.nanmax(S.a[j:e])
        rng = S.h[j - 25:j + 1].max() - S.l[j - 25:j + 1].min()
        br = next((k for k in range(j + 1, e) if S.c[k] > S.h[j - 25:j + 1].max() or S.c[k] < S.l[j - 25:j + 1].min()), None)
        if br is None or mx < 2 * S.a[j] or rng > 7 * S.a[j] or _bigbar(S, j - 70, j + 40, 8.0):
            continue
        out.append({"i": j, "br": br, "score": mx / S.a[j]})
    return out


def build_atr(S, x):
    j, br = x["i"], x["br"]
    a0, C = S.window(j - 70, j + 40)
    rel = lambda i: i - a0  # noqa: E731
    A = S.a
    d = 1 if S.c[br] > S.c[j] else -1
    sl = S.c[br] - d * 1.5 * A[br]
    mx = j + int(np.nanargmax(A[j:min(S.n, j + 30)]))
    ann = [P(label(rel(j), A[j], "ATR terendah: market tenang", col="mut", pos="below", pill=True, show=rel(j))),
           box(rel(br), col="gold"),
           hline(sl, rel(br), rel(br) + 15, col="dn", dash="5 4", tag="SL 1.5 ATR", show=rel(br)),
           P(label(rel(mx), A[mx], f"ATR {A[mx] / A[j]:.1f}× lebih besar", col="gold", pill=True, show=rel(mx)))]
    steps = [["Konteks", "Panel bawah = ATR 14 (Average True Range) = rata-rata panjang candle 14 terakhir, dalam satuan harga. ATR = ukuran VOLATILITAS, bukan arah.",
              "", 0],
             ["Volatilitas rendah", "Candle kecil-kecil, ATR di titik terendah = market tenang / menumpuk tenaga.", "Sesudah tenang lama biasanya datang gerak besar.", rel(j)],
             ["Ekspansi", "Breakout: candle membesar, ATR naik tajam.", "SL harus mengikuti ATR: kalau ATR besar, SL ketat akan gampang kena 'gocekan'.", rel(br)],
             ["Pakai ATR untuk SL", f"Contoh: SL = 1.5 × ATR dari entry (garis merah). Ukuran posisi = risiko ÷ jarak SL, jadi saat ATR besar posisi dikecilkan.",
              "Itu juga alasan app ini memakai ATR untuk SL anti-gocekan & swing minimal.", rel(br) + 2]]
    return scn(S, a0, C, "ATR: tenang → ekspansi", steps, ann, slow=[rel(br)], pause=[rel(br) + 1],
               pane=pane("ATR 14", [sr("ATR", A, a0, a0 + len(C), "gold", w=1.8)], (), lo=0))


# ================================================================== 10. Volume


def _volma(S):
    return sma(S.v, 20)


def find_vol_break(S, good=True):
    vm = _volma(S)
    out = []
    for j in range(60, S.n - 30):
        top = S.h[j - 30:j].max()
        bot = S.l[j - 30:j].min()
        if not (S.c[j] > top and S.c[j - 1] <= top) or (top - bot) > 7 * S.a[j]:
            continue
        r = S.v[j] / vm[j] if vm[j] else 0
        if good:
            mv = _move(S, j, 1, 30)
            if r >= 2.0 and mv >= 4 and S.l[j + 1:j + 10].min() > bot and not _bigbar(S, j - 60, j + 30, 6.0):
                out.append({"i": j, "top": float(top), "r": float(r), "score": r + mv})
        else:
            back = next((k for k in range(j + 1, min(S.n, j + 6)) if S.c[k] < top), None)
            drop = (top - S.l[j + 1:j + 25].min()) / S.a[j]
            if r <= 1.1 and back is not None and drop >= 2 and not _bigbar(S, j - 60, j + 30, 6.0):
                out.append({"i": j, "top": float(top), "r": float(r), "back": back, "score": drop + (1.2 - r) * 3})
    return out


def find_vol_bad(S):
    return find_vol_break(S, False)


def build_vol(S, x):
    j, top = x["i"], x["top"]
    good = "back" not in x
    a0, C = S.window(j - 60, j + 30)
    rel = lambda i: i - a0  # noqa: E731
    vm = _volma(S)
    ann = [hline(top, rel(j) - 30, rel(j) + 8, col="gold", dash="6 4", tag="RESISTANCE", show=rel(j) - 1), box(rel(j), col="gold"),
           P(label(rel(j), S.v[j], f"volume {x['r']:.1f}× rata-rata", col="up" if good else "dn", pill=True, show=rel(j)))]
    if good:
        pk = _peak(S, j, 1, 30)
        ann.append(label(rel(pk), S.h[pk], f"lanjut {_move(S, j, 1, 30):.1f} ATR", col="up", pill=True, show=rel(pk)))
        steps = [["Konteks", "Panel bawah = VOLUME per candle (hijau = candle naik, merah = candle turun) + garis rata-rata 20 candle.",
                  "Volume = berapa banyak yang ditransaksikan → menunjukkan seberapa serius sebuah gerakan.", 0],
                 ["Range", "Harga tertahan di bawah resistance; volume biasa-biasa saja.", "", max(1, rel(j) - 20)],
                 ["Breakout bervolume", f"Close menembus resistance dengan volume {x['r']:.1f}× rata-rata = banyak pelaku ikut membeli → breakout bisa dipercaya.",
                  "Breakout valid: candle besar + close di luar level + volume ≥ ±1.5–2× rata-rata.", rel(j)],
                 ["Hasil", f"Harga melanjutkan {_move(S, j, 1, 30):.1f} ATR. Saat harga naik lagi tapi volume makin kecil = tenaga mulai habis.", "", rel(j) + 3]]
        title = "Breakout + volume besar (valid)"
    else:
        ann.append(box(rel(x["back"]), col="dn"))
        ann.append(label(rel(x["back"]), S.l[x["back"]], "balik ke bawah = fakeout", col="dn", pos="below", pill=True, show=rel(x["back"])))
        steps = [["Konteks", "Panel bawah = VOLUME + garis rata-rata 20 candle.", "", 0],
                 ["Breakout sepi", f"Close menembus resistance, tapi volume hanya {x['r']:.1f}× rata-rata (tidak ada lonjakan).",
                  "Tidak banyak pelaku yang ikut → rawan breakout palsu.", rel(j)],
                 ["Gagal", "Harga kembali ke bawah resistance = FAKEOUT. Yang membeli breakout terjebak.", "Lebih aman tunggu close kuat + volume, atau retest.", rel(x["back"])]]
        title = "Breakout volume kecil (gagal)"
    return scn(S, a0, C, title, steps, ann, slow=[rel(j)], pause=[rel(j) + 1],
               pane=pane("Volume", [sr("", S.v, a0, a0 + len(C), "mut", typ="vol"), sr("rata-rata 20", vm, a0, a0 + len(C), "gold", w=1.5)], (), h=120, lo=0))


# ================================================================== 11. Bollinger Band


def find_bb_squeeze(S):
    m, u, lo_ = boll(S.c)
    bw = (u - lo_) / m
    out = []
    for j in range(160, S.n - 35):
        if not np.isfinite(bw[j]) or bw[j] > np.nanmin(bw[j - 120:j + 1]) * 1.02:
            continue
        br = next((k for k in range(j + 1, min(S.n, j + 15)) if S.c[k] > u[k] or S.c[k] < lo_[k]), None)
        if br is None:
            continue
        d = 1 if S.c[br] > u[br] else -1
        mv = _move(S, br, d, 30)
        if mv >= 5 and not _bigbar(S, j - 80, br + 30):
            out.append({"i": j, "br": br, "d": d, "score": mv})
    return out


def build_bb_squeeze(S, x):
    j, br, d = x["i"], x["br"], x["d"]
    up = d == 1
    a0, C = S.window(j - 80, br + 30)
    a1 = a0 + len(C)
    rel = lambda i: i - a0  # noqa: E731
    m, u, lo_ = boll(S.c)
    pk = _peak(S, br, d, 30)
    ann = [label(rel(j), u[j], "SQUEEZE: band paling sempit", col="gold", pill=True, show=rel(j)),
           box(rel(br), col="gold"),
           label(rel(br), S.h[br] if up else S.l[br], f"close di luar band {'atas' if up else 'bawah'}", col="up" if up else "dn", pos="above" if up else "below", pill=True, show=rel(br)),
           label(rel(pk), S.h[pk] if up else S.l[pk], f"{'naik' if up else 'turun'} {_move(S, br, d, 30):.1f} ATR", col="up" if up else "dn", pos="above" if up else "below", pill=True, show=rel(pk))]
    steps = [["Konteks", "Bollinger Band (20, 2): garis tengah = SMA 20, band atas/bawah = ± 2 standar deviasi. Band melebar saat volatil, menyempit saat tenang.",
              "Sekitar 90% close biasanya berada di dalam band.", 0],
             ["Squeeze", "Band menyempit sampai paling sempit dalam ±120 candle = SQUEEZE: market menumpuk tenaga.", "Squeeze tidak memberi arah, hanya tanda gerak besar akan datang.", rel(j)],
             ["Breakout", f"Close keluar band {'atas' if up else 'bawah'} = arah ledakan. Entry searah, SL di sisi seberang garis tengah.", "", rel(br)],
             ["Walking the band", f"Di tren kuat harga bisa terus 'menempel' band {'atas' if up else 'bawah'}. Menyentuh band BUKAN otomatis sinyal berbalik.",
              f"Keluar saat close kembali ke dalam / melewati garis tengah. Hasil: {_move(S, br, d, 30):.1f} ATR.", rel(br) + 4]]
    return scn(S, a0, C, "Squeeze → breakout", steps, ann, slow=[rel(br)], pause=[rel(br) + 1],
               ov=[ov("BB atas", u, a0, a1, "blue", w=1.2), ov("SMA 20", m, a0, a1, "gold", w=1.2, dash="5 4"), ov("BB bawah", lo_, a0, a1, "blue", w=1.2)],
               band={"a": 0, "b": 2, "c": COL["blue"], "op": 0.07})


def find_bb_revert(S):
    m, u, lo_ = boll(S.c)
    ax, _, _ = adx(S.h, S.l, S.c)
    out = []
    for j in range(80, S.n - 25):
        if not (S.c[j] < lo_[j] and np.nanmax(ax[j - 20:j + 1]) < 20 and (S.h[j] - S.l[j]) < 2 * S.a[j]):
            continue                                    # benar-benar sideways: ADX < 20 selama 20 candle, candle tidak meledak
        hit = next((k for k in range(j + 1, min(S.n, j + 20)) if S.h[k] >= m[k]), None)
        if hit is None or S.l[j + 1:hit + 1].min() < S.l[j] - 0.5 * S.a[j] or S.l[hit:hit + 10].min() < S.l[j] or _bigbar(S, j - 70, j + 25):
            continue
        out.append({"i": j, "hit": hit, "score": (m[j] - S.c[j]) / S.a[j]})
    return out


def build_bb_revert(S, x):
    j, hit = x["i"], x["hit"]
    a0, C = S.window(j - 70, j + 25)
    a1 = a0 + len(C)
    rel = lambda i: i - a0  # noqa: E731
    m, u, lo_ = boll(S.c)
    ann = [box(rel(j), col="gold"), label(rel(j), S.l[j], "close di bawah band (sideways)", col="up", pos="below", pill=True, show=rel(j)),
           label(rel(hit), m[hit], "kembali ke garis tengah ✓", col="gold", pill=True, show=rel(hit))]
    steps = [["Konteks", "Market SIDEWAYS (ADX < 20): band datar, harga bolak-balik di antara band atas dan bawah.", "", 0],
             ["Keluar band bawah", "Close di bawah band bawah saat sideways = harga 'terlalu jauh' dari rata-ratanya.", "Di sideways, ekstrem cenderung kembali ke tengah (mean reversion).", rel(j)],
             ["Kembali ke tengah", "Harga kembali ke garis tengah (SMA 20) = target wajar mean reversion.",
              "JANGAN pakai cara ini saat tren kuat / squeeze breakout: di sana sentuhan band justru tanda kuat.", rel(hit)]]
    return scn(S, a0, C, "Sideways: kembali ke tengah", steps, ann, slow=[rel(j)], pause=[rel(j) + 1],
               ov=[ov("BB atas", u, a0, a1, "blue", w=1.2), ov("SMA 20", m, a0, a1, "gold", w=1.2, dash="5 4"), ov("BB bawah", lo_, a0, a1, "blue", w=1.2)],
               band={"a": 0, "b": 2, "c": COL["blue"], "op": 0.07})


# ================================================================== 12. VWAP


def find_vwap(S, d=1):
    if S.tf not in ("15m", "5m", "30m"):
        return []
    vw, day = vwap_daily(S.t, S.h, S.l, S.c, S.v)
    out = []
    for j in range(100, S.n - 30):
        k0 = j - int(np.sum(day[:j + 1] == day[j])) + 1          # awal hari
        if j - k0 < 24:
            continue
        side_ok = (np.mean(S.c[k0 + 4:j] > vw[k0 + 4:j]) if d == 1 else np.mean(S.c[k0 + 4:j] < vw[k0 + 4:j])) >= 0.85   # hari itu harga hampir selalu di satu sisi
        touch = (S.l[j] <= vw[j] < S.c[j]) if d == 1 else (S.h[j] >= vw[j] > S.c[j])
        if not (side_ok and touch):
            continue
        nx = slice(j + 1, min(S.n, j + 12))
        if (np.any(S.c[nx] < vw[nx] - 0.3 * S.a[j]) if d == 1 else np.any(S.c[nx] > vw[nx] + 0.3 * S.a[j])):
            continue                                    # mantul yang langsung jebol bukan contoh yang bersih
        mv = _move(S, j, d, 25)
        if mv >= 2.0 and not _bigbar(S, j - 70, j + 30, 6.0):
            out.append({"i": j, "k0": k0, "d": d, "score": mv})
    return out


def build_vwap(S, x):
    j, d, k0 = x["i"], x["d"], x["k0"]
    up = d == 1
    a0, C = S.window(j - 70, j + 30)
    a1 = a0 + len(C)
    rel = lambda i: i - a0  # noqa: E731
    vw, day = vwap_daily(S.t, S.h, S.l, S.c, S.v)
    vw = vw.copy()
    for k in range(a0 + 1, a1):
        if day[k] != day[k - 1]:
            vw[k - 1] = np.nan                                    # garis putus di pergantian hari
    pk = _peak(S, j, d, 25)
    ann = [label(rel(k0), S.h[k0] if up else S.l[k0], "hari baru: VWAP mulai ulang", col="mut", pos="above" if up else "below", show=rel(k0))] if k0 >= a0 else []
    ann += [box(rel(j), col="gold"),
           label(rel(j), S.l[j] if up else S.h[j], f"{'mantul' if up else 'ditolak'} di VWAP", col="up" if up else "dn", pos="below" if up else "above", pill=True, show=rel(j)),
           label(rel(pk), S.h[pk] if up else S.l[pk], f"{'naik' if up else 'turun'} {_move(S, j, d, 25):.1f} ATR", col="up" if up else "dn", pos="above" if up else "below", pill=True, show=rel(pk))]
    steps = [["Konteks", "VWAP (garis kuning) = harga rata-rata hari ini yang ditimbang VOLUME, dihitung ulang tiap 00:00 UTC. Dipakai trader besar sebagai 'harga wajar' hari itu.",
              "Harga di atas VWAP = pembeli menguasai hari ini; di bawah = penjual.", 0],
             ["Sepanjang hari", f"Harga terus {'di atas' if up else 'di bawah'} VWAP = hari {'bullish' if up else 'bearish'}.", "", max(1, rel(j) - 15)],
             [f"{'Pullback' if up else 'Rally'} ke VWAP", f"Harga kembali menyentuh VWAP lalu close {'di atas' if up else 'di bawah'} lagi = {'mantul' if up else 'ditolak'}.",
              f"Entry searah, SL sedikit {'di bawah' if up else 'di atas'} VWAP.", rel(j)],
             ["Hasil", f"Harga {'naik' if up else 'turun'} {_move(S, j, d, 25):.1f} ATR. Kalau harga close jauh menembus VWAP, bias hari itu berubah.",
              "VWAP paling berguna untuk intraday / scalping (TF kecil).", rel(j) + 3]]
    return scn(S, a0, C, "Mantul di VWAP (hari naik)" if up else "Ditolak di VWAP (hari turun)", steps, ann, slow=[rel(j)], pause=[rel(j) + 1],
               ov=[ov("VWAP", vw, a0, a1, "gold", w=2)])


# ================================================================== 13. swing minimal 1–5 ATR


def find_swingk(S):
    if S.tf != "1h":
        return []
    out = []
    for j in range(200, S.n - 10, 25):
        a0 = j - 180
        if _bigbar(S, a0, j + 1, 5.0):
            continue
        rng = (S.h[a0:j].max() - S.l[a0:j].min()) / np.nanmedian(S.a[a0:j])
        sw = [s_ for s_ in zz(S.h, S.l, S.a, 1.0) if a0 <= s_[0] < j]
        if 25 <= rng <= 45 and len(sw) >= 12:
            out.append({"i": a0, "e": j, "score": len(zz(S.h[a0:j], S.l[a0:j], S.a[a0:j], 3.0)) + rng / 10})
    return out


def build_swingk(S, x):
    a0_, e = x["i"], x["e"]
    a0, C = S.window(a0_, e)
    rel = lambda i: i - a0  # noqa: E731
    res = []
    for k in (1, 2, 3, 4, 5):
        sw = [s_ for s_ in zz(S.h[:e], S.l[:e], S.a[:e], float(k)) if a0 <= s_[0] < e]   # sampai candle terakhir potongan
        ann = []
        for (i1, p1, _), (i2, p2, t2) in zip(sw, sw[1:]):
            ann.append(seg(rel(i1), p1, rel(i2), p2, col="gold", show=min(len(C) - 1, rel(i2) + 3), w=1.8))
        for i, p, t in sw:
            ann.append(label(rel(i), p, "H" if t == 1 else "L", col="up" if t == 1 else "dn", pos="above" if t == 1 else "below", show=min(len(C) - 1, rel(i) + 3)))
        A = float(np.nanmedian(S.a[a0:e]))
        steps = [["Konteks", f"Swing = titik balik (puncak H / lembah L). Syarat di sini: jarak dari swing sebelumnya minimal {k} × ATR (ATR ±{A:.4g}).",
                  "ATR = rata-rata panjang candle, jadi batas ini otomatis menyesuaikan volatilitas koin.", 0],
                 ["Hasil", f"Dengan minimal {k} ATR ada {len(sw)} swing di potongan ini. " +
                  ("Hampir semua goyangan ikut dihitung → struktur 'ramai', cocok untuk scalping tapi banyak noise." if k == 1 else
                   "Goyangan kecil mulai diabaikan → struktur lebih bersih." if k == 2 else
                   "Hanya swing menengah → bagus untuk swing trading intraday." if k == 3 else
                   "Hanya gelombang besar → tren besar kelihatan jelas, sinyal jarang." if k == 4 else
                   "Hanya gerakan sangat besar → seperti melihat TF jauh lebih besar."),
                  "Bandingkan tab 1–5 ATR: chart sama, yang beda hanya syarat ukuran swing. Makin besar angkanya, makin sedikit & besar swing-nya.", max(1, len(C) // 3)],
                 ["Pakai yang mana?", "Di 🔎 Scan banyak koin (Market Structure) pilihan 'Swing minimal' memakai aturan yang sama. 1 ATR = default.",
                  "Swing terlalu kecil = label LH/HL di goyangan kecil yang tidak berarti. Terlalu besar = pola jarang muncul.", len(C) - 5]]
        res.append(scn(S, a0, C, f"Swing minimal {k} ATR", steps, ann))
    return res


# ================================================================== 14–15. Fibonacci tools & extension berbasis tren


def find_abc(S):
    hi, lo = pivots(S.h, S.l, 5)
    out = []
    for a in lo:
        if a < 40:
            continue
        bs = [b for b in hi if a < b <= a + 50]
        if not bs:
            continue
        b = max(bs, key=lambda k: S.h[k])
        A = S.a[b]
        imp = S.h[b] - S.l[a]
        if imp < 8 * A or S.l[a:b + 1].min() < S.l[a]:
            continue
        cs = [c for c in lo if b < c <= b + 40]
        if not cs:
            continue
        c = min(cs, key=lambda k: S.l[k])
        rt = (S.h[b] - S.l[c]) / imp
        if not 0.38 <= rt <= 0.79 or S.h[b + 1:c + 1].max() > S.h[b]:
            continue
        e = min(S.n, c + 70)
        reach = (S.h[c:e].max() - S.l[c]) / imp
        if reach < 1.0 or S.l[c + 1:e].min() < S.l[c] or _bigbar(S, a - 30, e, 6.0):
            continue
        out.append({"i": int(b), "a": int(a), "c": int(c), "rt": float(rt), "reach": float(reach), "score": imp / A + reach * 5})
    return out


FIB_COL = {0.236: "mut", 0.382: "cyan", 0.5: "gold", 0.618: "#fb923c", 0.786: "pink"}


def build_fib_tools(S, x):
    a, b, c = x["a"], x["i"], x["c"]
    imp = S.h[b] - S.l[a]
    e = min(S.n, c + 60)
    hit_e = next((k for k in range(c, e) if S.h[k] >= S.h[b] + 0.272 * imp), e - 1)
    a0, C = S.window(a - 30, min(S.n, hit_e + 15))
    rel = lambda i: i - a0  # noqa: E731
    ann = [seg(rel(a), S.l[a], rel(b), S.h[b], col="vio", show=rel(b) + 5, dash="5 4"),
           label(rel(a), S.l[a], "0% / 1 (awal)", col="vio", pos="below", show=rel(b) + 5),
           label(rel(b), S.h[b], "puncak (0)", col="vio", show=rel(b) + 5)]
    for r_, col in FIB_COL.items():
        p = S.h[b] - r_ * imp
        ann.append(hline(p, rel(b), rel(c) + 12, col=col, dash="4 3", tag=f"{r_:g}", show=rel(b) + 5, w=1.1))
    ann += [box(rel(c), col="gold"), label(rel(c), S.l[c], f"mantul di {x['rt']:.2f}", col="up", pos="below", pill=True, show=rel(c) + 3)]
    for r_ in (1.272, 1.618):
        ann.append(hline(S.h[b] + (r_ - 1) * imp, rel(c), None, col="up", dash="6 4", tag=f"EXT {r_:g}", show=rel(c) + 3, w=1.2))
    steps = [["Konteks", "Harga naik kuat (impuls) dari lembah ke puncak. Fibonacci ditarik dari AWAL ke UJUNG impuls itu.", "", 0],
             ["Level retracement", "Garis 0.236, 0.382, 0.5, 0.618, 0.786 = seberapa dalam koreksi dibanding impuls. 0.5–0.618 paling sering dipakai ('golden zone').",
              "0.236 = koreksi dangkal (tren sangat kuat); 0.786 = koreksi dalam (tren mulai lemah).", rel(b) + 5],
             ["Pantulan", f"Koreksi berhenti di ±{x['rt']:.2f} lalu naik lagi. Entry di area ini dengan konfirmasi candle; SL di bawah 0.786 / di bawah lembah.", "", rel(c)],
             ["Extension (target)", "Fib EXTENSION 1.272 & 1.618 (di atas puncak) = target TP umum saat tren lanjut.",
              "Extension 2 titik ini dihitung dari impuls yang sama. Versi 3 titik ada di topik 'Fib Extension berbasis tren'.", rel(c) + 3]]
    return scn(S, a0, C, "Retracement + extension", steps, ann, slow=[rel(c)], pause=[rel(c) + 1])


def build_fib_trend(S, x):
    a, b, c = x["a"], x["i"], x["c"]
    imp = S.h[b] - S.l[a]
    lv = {0.618: S.l[c] + 0.618 * imp, 1.0: S.l[c] + imp, 1.618: S.l[c] + 1.618 * imp}
    e = min(S.n, c + 70)
    hit = next((k for k in range(c, e) if S.h[k] >= lv[1.0]), e - 1)
    a0, C = S.window(a - 30, min(S.n, hit + 15))
    rel = lambda i: i - a0  # noqa: E731
    ann = [label(rel(a), S.l[a], "A", col="vio", pos="below", pill=True, show=rel(b) + 5),
           label(rel(b), S.h[b], "B", col="vio", pill=True, show=rel(b) + 5),
           seg(rel(a), S.l[a], rel(b), S.h[b], col="vio", show=rel(b) + 5, dash="5 4"),
           label(rel(c), S.l[c], "C", col="vio", pos="below", pill=True, show=rel(c) + 5),
           seg(rel(b), S.h[b], rel(c), S.l[c], col="vio", show=rel(c) + 5, dash="5 4")]
    for r_, p in lv.items():
        ann.append(hline(p, rel(c), None, col="up" if r_ >= 1 else "cyan", dash="6 4", tag=f"{r_:g}", show=rel(c) + 5, w=1.2))
    ann.append(label(rel(hit), lv[1.0], "target 1.0 tercapai ✓", col="up", pill=True, show=rel(hit)))
    steps = [["Konteks", "Fib extension BERBASIS TREN (3 titik): A = awal impuls, B = ujung impuls, C = akhir koreksi.", "", 0],
             ["A → B", "Gelombang naik pertama (A ke B) = ukuran dorongan pembeli.", "", rel(b) + 5],
             ["Koreksi B → C", "Harga koreksi ke C lalu mantul (lembah lebih tinggi dari A = tren masih naik).", "", rel(c) + 5],
             ["Proyeksi dari C", "Panjang A→B ditempel di C: 0.618 = target dekat, 1.0 = gerak sama panjang (paling sering), 1.618 = tren kuat.",
              "Bedanya dengan extension 2 titik: titik awal proyeksi = C (akhir koreksi), bukan puncak B.", rel(c) + 6],
             ["Hasil", f"Harga mencapai level 1.0 (AB = CD).", "Pakai sebagai TP bertahap: sebagian di 1.0, sisanya ke 1.618.", rel(hit)]]
    return scn(S, a0, C, "Trend-based fib extension (A-B-C)", steps, ann, slow=[rel(c)], pause=[rel(c) + 6])


# ================================================================== 16. trendline & dynamic SNR


def find_trendline(S):
    lo = pivots(S.h, S.l, 4)[1]
    out = []
    for a, b in zip(lo, lo[1:]):
        if not 15 <= b - a <= 60 or a < 30 or S.l[b] <= S.l[a] + 0.5 * S.a[b]:
            continue
        sl = (S.l[b] - S.l[a]) / (b - a)
        line = lambda j: S.l[a] + sl * (j - a)  # noqa: E731
        t3 = None
        for j in range(b + 5, min(S.n - 30, b + 60)):
            if S.c[j] < line(j) - 0.3 * S.a[j]:
                break
            if S.l[j] <= line(j) + 0.3 * S.a[j] and _move(S, j, 1, 15) >= 3:
                t3 = j
                break
        if t3 is None:
            continue
        brk = next((j for j in range(t3 + 5, min(S.n, t3 + 80)) if S.c[j] < line(j) - 0.5 * S.a[j]), None)
        if brk is None or brk + 15 >= S.n or _bigbar(S, a - 25, brk + 15):
            continue
        out.append({"i": int(b), "a": int(a), "t3": t3, "brk": brk, "score": _move(S, t3, 1, 15) + (brk - a) / 30})
    return out


def build_trendline(S, x):
    a, b, t3, brk = x["a"], x["i"], x["t3"], x["brk"]
    a0, C = S.window(a - 25, brk + 15)
    rel = lambda i: i - a0  # noqa: E731
    sl = (S.l[b] - S.l[a]) / (b - a)
    line = lambda j: S.l[a] + sl * (j - a)  # noqa: E731
    ann = [label(rel(a), S.l[a], "sentuhan 1", col="mut", pos="below", show=rel(a) + 4),
           label(rel(b), S.l[b], "sentuhan 2", col="mut", pos="below", show=rel(b) + 4),
           seg(rel(a), line(a), rel(brk) + 10, line(brk + 10), col="up", show=rel(b) + 4, w=1.8),
           box(rel(t3), col="gold"), label(rel(t3), S.l[t3], "sentuhan 3: mantul", col="up", pos="below", pill=True, show=rel(t3)),
           box(rel(brk), col="dn"), label(rel(brk), S.l[brk], "trendline patah", col="dn", pos="below", pill=True, show=rel(brk))]
    steps = [["Konteks", "Tren naik membuat lembah yang makin tinggi.", "", 0],
             ["Tarik trendline", "Hubungkan 2 lembah (higher low) = TRENDLINE naik. Garis ini bergerak naik mengikuti waktu = support DINAMIS (levelnya berubah tiap candle).",
              "Beda dengan support horizontal yang levelnya tetap.", rel(b) + 4],
             ["Sentuhan ke-3", "Harga turun menyentuh trendline lalu mantul = trendline 'terbukti'. Makin banyak sentuhan, makin dihormati.", "Entry di sentuhan dengan konfirmasi, SL di bawah garis.", rel(t3)],
             ["Patah", "Close jelas di bawah trendline = tren naik melemah / berakhir. Garis yang patah sering berubah jadi resistance saat di-retest.",
              "Trendline patah = PERINGATAN; konfirmasi dengan struktur (lower low / CHoCH).", rel(brk)]]
    return scn(S, a0, C, "Trendline: 3 sentuhan lalu patah", steps, ann, slow=[rel(t3), rel(brk)], pause=[rel(t3) + 1, rel(brk) + 1])


def find_ema_dyn(S):
    e = ema(S.c, 20)
    e50 = ema(S.c, 50)
    out = []
    for j in range(100, S.n - 90, 10):
        touches = []
        k = j
        while k < j + 80:
            if e[k] > e50[k] and e[k] > e[k - 5] and S.l[k] <= e[k] + 0.1 * S.a[k] and S.c[k] > e[k] and _move(S, k, 1, 10) >= 1.5:
                touches.append(k)
                k += 8
            else:
                k += 1
        brk = any(S.c[m] < e50[m] for m in range(j, j + 80))
        if len(touches) >= 3 and not brk and not _bigbar(S, j - 20, j + 90):
            out.append({"i": j, "t": touches, "score": len(touches) + _move(S, j, 1, 80) / 5})
    return out


def build_ema_dyn(S, x):
    j = x["i"]
    a0, C = S.window(j - 20, j + 90)
    a1 = a0 + len(C)
    rel = lambda i: i - a0  # noqa: E731
    e = ema(S.c, 20)
    ann = []
    x = dict(x, t=x["t"][:4])
    for n_, t in enumerate(x["t"], 1):
        ann += [box(rel(t), col="gold"), label(rel(t), S.l[t], f"mantul {n_}", col="up", pos="below", show=rel(t))]
    steps = [["Konteks", "Garis biru = EMA 20, kuning = EMA 50. Di tren naik sehat, EMA 20 di atas EMA 50 dan keduanya menanjak.", "", 0],
             ["Support dinamis", "Setiap koreksi berhenti di sekitar EMA 20 lalu naik lagi: EMA bertindak sebagai SUPPORT DINAMIS yang ikut naik.",
              "Banyak trader menaruh order di MA populer (20/50/200), jadi MA itu benar-benar dihormati.", rel(x["t"][0])],
             ["Kapan berhenti berlaku", "Kalau close tembus ke bawah EMA 50 / EMA mulai mendatar, support dinamis melemah.",
              "Di sideways MA dilewati bolak-balik dan tidak berguna sebagai support.", rel(x["t"][-1]) + 2]]
    return scn(S, a0, C, "EMA 20 sebagai support dinamis", steps, ann, slow=[rel(x["t"][0])], pause=[rel(x["t"][0]) + 1],
               ov=[ov("EMA 20", e, a0, a1, "blue", w=1.8), ov("EMA 50", ema(S.c, 50), a0, a1, "gold", w=1.6)])


# ================================================================== 17. kemiringan tren & tanda reversal


def slope(S, n=50, k=10):
    e = ema(S.c, n)
    return e, (e - np.roll(e, k)) / S.a


def find_slope(S):
    e, s = slope(S)
    hi = pivots(S.h, S.l, 4)[0]
    out = []
    for j in range(260, S.n - 70, 5):
        if not s[j] >= 1.2:
            continue
        fl = next((k for k in range(j, min(S.n, j + 70)) if s[k] <= 0.2), None)
        if fl is None:
            continue
        rv = next((k for k in range(fl, min(S.n, fl + 50)) if s[k] <= -0.8), None)
        if rv is None:
            continue
        top = j + int(np.argmax(S.h[j:fl + 10]))
        lh = next((int(h_) for h_ in hi if top < h_ <= rv and S.h[h_] < S.h[top] - 0.3 * S.a[h_]), None)
        if lh is None or _bigbar(S, j - 50, rv + 20):
            continue
        out.append({"i": j, "fl": fl, "rv": rv, "top": top, "lh": lh, "score": s[j] - s[rv]})
    return out


def build_slope(S, x):
    j, fl, rv, top, lh = x["i"], x["fl"], x["rv"], x["top"], x["lh"]
    a0, C = S.window(j - 50, rv + 20)
    a1 = a0 + len(C)
    rel = lambda i: i - a0  # noqa: E731
    e, s = slope(S)
    ann = [P(label(rel(j), s[j], "curam = tren kuat", col="up", pill=True, show=rel(j))),
           label(rel(top), S.h[top], "puncak", col="mut", show=rel(top) + 4),
           P(label(rel(fl), s[fl], "melandai / datar", col="gold", pill=True, show=rel(fl))),
           label(rel(lh), S.h[lh], "LOWER HIGH", col="dn", pill=True, show=rel(lh) + 4),
           P(label(rel(rv), s[rv], "menukik = tren turun", col="dn", pos="below", pill=True, show=rel(rv)))]
    steps = [["Konteks", "Garis kuning = EMA 50. Panel bawah = KEMIRINGAN EMA 50: berapa ATR EMA naik/turun dalam 10 candle. Positif = menanjak, negatif = menurun.",
              "Kemiringan > +0.5 = tren naik kuat, −0.5…+0.5 = lemah / datar, < −0.5 = tren turun kuat.", 0],
             ["Tren kuat", "Kemiringan tinggi: EMA menanjak curam, koreksi dangkal.", "Searah tren = peluang paling besar.", rel(j)],
             ["Tanda: melandai", "Kemiringan turun ke dekat 0 walau harga masih tinggi = tenaga tren habis.", "Bukan sinyal jual; berhenti cari BUY baru.", rel(fl)],
             ["Tanda: lower high", "Harga gagal membuat puncak baru (LOWER HIGH) = pembeli makin lemah.", "Tanda lain: divergence RSI/MACD, trendline patah, volume naik di candle merah.", rel(lh) + 4],
             ["Reversal", "Kemiringan menukik di bawah −0.5 dan struktur LH/LL = tren berbalik TURUN.", "Urutannya bisa sedikit berbeda (di contoh ini lower high muncul duluan), tapi tanda-tanda ini biasanya datang berdekatan sebelum tren berbalik.", rel(rv)]]
    return scn(S, a0, C, "Kemiringan tren & tanda reversal", steps, ann, slow=[rel(fl), rel(rv)], pause=[rel(fl) + 1, rel(rv) + 1],
               ov=[ov("EMA 50", e, a0, a1, "gold", w=1.8)],
               pane=pane("Kemiringan EMA 50 (ATR / 10 candle)", [sr("kemiringan", s, a0, a1, "up", typ="hist", c2="dn")], [(0.5, "up", "+0.5"), (0, "mut", "0"), (-0.5, "dn", "−0.5")]))


# ================================================================== daftar topik baru


def _l(f, *a):
    return lambda S: f(S, *a)


TOPICS_IND = [
    ("rsi_div", "📉 RSI Divergence", "Harga dan RSI berlawanan arah = tenaga gerak melemah (regular & hidden divergence).", "Indikator",
     [(_l(find_rsi_div, 1), build_rsi_div), (_l(find_rsi_div, -1), build_rsi_div)]),
    ("stoch", "〰️ Stochastic", "Posisi close di rentang 14 candle: overbought/oversold, cross %K–%D, dan jebakannya.", "Indikator",
     [(find_stoch_cross, build_stoch_cross), (find_stoch_trap, build_stoch_trap)]),
    ("ma", "📏 Semua tipe Moving Average", "SMA, EMA, WMA, HMA, SMMA/RMA, VWMA, DEMA, TEMA: bedanya cara menghitung & kecepatan (lag), plus golden cross.", "Indikator",
     [(find_vturn, build_ma1), (find_vturn, build_ma2), (find_golden, build_golden)]),
    ("force", "💪 Force Index", "Arah × besar gerak × volume: siapa yang lebih kuat, pembeli atau penjual.", "Indikator", [(find_force, build_force)]),
    ("macd", "📊 MACD", "Selisih EMA 12 & 26, signal, histogram, cross & garis nol.", "Indikator",
     [(_l(find_macd, 1), build_macd), (_l(find_macd, -1), build_macd)]),
    ("adx", "🧭 ADX", "Kekuatan tren (bukan arah) + DI+/DI− untuk arah. Sideways vs tren.", "Indikator", [(find_adx, build_adx)]),
    ("atr", "📐 ATR", "Volatilitas: rata-rata panjang candle. Dipakai untuk SL, ukuran posisi & swing minimal.", "Indikator", [(find_atr, build_atr)]),
    ("volume", "📶 Cara baca Volume", "Breakout bervolume (valid) vs breakout sepi (rawan palsu).", "Indikator",
     [(find_vol_break, build_vol), (find_vol_bad, build_vol)]),
    ("bb", "🎯 Bollinger Band", "Squeeze → breakout, walking the band, dan mean reversion saat sideways.", "Indikator",
     [(find_bb_squeeze, build_bb_squeeze), (find_bb_revert, build_bb_revert)]),
    ("vwap", "⚓ VWAP", "Harga rata-rata harian berbobot volume: bias intraday, mantul & tolak.", "Indikator",
     [(_l(find_vwap, 1), build_vwap), (_l(find_vwap, -1), build_vwap)]),
    ("chartpat", "🔺 Chart Pattern", "Double bottom/top, Head & Shoulders, bull flag: neckline, breakout & target.", "Pola & alat",
     [(_l(find_double, 1), build_double), (_l(find_double, -1), build_double), (find_hs, build_hs), (find_flag, build_flag)]),
    ("candle", "🕯️ Candlestick Pattern", "Engulfing, hammer/pin bar, morning star — dan kenapa LOKASI-nya penting.", "Pola & alat",
     [(_l(find_candle, "bull_engulf"), build_candle), (_l(find_candle, "hammer"), build_candle), (_l(find_candle, "bear_engulf"), build_candle),
      (_l(find_candle, "morning"), build_candle)]),
    ("swingk", "🪜 Swing minimal 1–5 ATR", "Apa arti 'swing minimal 1/2/3/4/5 ATR': chart sama, syarat ukuran swing berbeda.", "Pola & alat", [(find_swingk, build_swingk)]),
    ("fibtools", "📐 Fibonacci Tools", "Semua level retracement (0.236–0.786) + extension 1.272 / 1.618 untuk target.", "Pola & alat", [(find_abc, build_fib_tools)]),
    ("fibext", "🎯 Fib Extension berbasis tren", "Extension 3 titik A-B-C: proyeksi target 0.618 / 1.0 / 1.618 dari akhir koreksi.", "Pola & alat", [(find_abc, build_fib_trend)]),
    ("trendline", "📈 Trendline & SNR dinamis", "Trendline 3 sentuhan, patah = peringatan, dan EMA sebagai support dinamis.", "Pola & alat",
     [(find_trendline, build_trendline), (find_ema_dyn, build_ema_dyn)]),
    ("slope", "📐 Kemiringan tren & tanda reversal", "Cara mengukur kemiringan tren (EMA 50 dalam ATR) & urutan tanda-tanda berbalik.", "Pola & alat", [(find_slope, build_slope)]),
]
