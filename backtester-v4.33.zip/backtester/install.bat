@echo off
REM Instal library Python yang dibutuhkan (cukup sekali per laptop, atau setelah update besar).
cd /d "%~dp0"
python --version
if errorlevel 1 (
  echo.
  echo Python belum terpasang atau belum masuk PATH. Lihat README langkah 1.
  pause
  exit /b 1
)
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Instalasi gagal. Cek koneksi internet lalu jalankan install.bat lagi.
  pause
  exit /b 1
)
echo.
echo Instalasi selesai.
echo Belum punya data candle? Jalankan update_data.bat. Sudah punya? Langsung run.bat.
pause
